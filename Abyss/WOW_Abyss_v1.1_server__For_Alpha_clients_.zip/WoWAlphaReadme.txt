1. Extract the WoW client files 1-4 in succession.
2. Start with the first WoW.Alpha.ANi and unzip it, it should all unzip together.
3. Put the extracted WoW files wherever you want.
(I'll use F:\WoW because that's where I put it)
4. In F:\WoW create a file called wow.ses (save it as .ses)
5. Open it with notepad or something and on the first line
   put a name (account name) and the second line put a second name (password.)
   You won't ever use these so just put random crap.
6. Create a shortcut to the WoWClient icon.
7. Right click on the shortcut, and in the Target, put this: F:\WoW\WoWClient.exe -uptodate
8. If you want, create a file and name it realmlist.wtf and in this (opened with notepad)
   type: realmlist localhost
9. Double click on the Abyss server icon.
10. Go to options and set it to what continent/city you want to start off at.
11. Skip the Model and Packet Logging thing.
12. In the Server Info box, type: Localhost
13. Hit OK and go back to the main menu, and click on Start Server
14. Double click on the WoWClient shortcut.  Something should popup, just hit OK.
15. At the login screen, click on Change Server and click on Abyss.
    (If you didn't set the realmlist.wtf open up the console and type: realmlist localhost)
16. Hit the Login button if you aren't already in.
17. Create a character, and enjoy!

Tips: While in game, open up the console and type: speed 1-59 (1 being the slowest and 59 being the fastest) to run faster.
Type swimspeed 1-59 to get the same effect in water.  If you want to worldport, open the console and type: Worldport 0 x y z
X being the north/south value, Y being the east/west value, and Z being the height value.