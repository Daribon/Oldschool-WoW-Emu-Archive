// (c) AbyssX Group
#if !defined(ITEMDBENVIRONMENT_H)
#define ITEMDBENVIRONMENT_H

#include "CommonEnvironment.h"

#include "ItemDataStructs.h"
#include "ItemPrototype.h"
#include "ItemDatabase.h"

#endif
