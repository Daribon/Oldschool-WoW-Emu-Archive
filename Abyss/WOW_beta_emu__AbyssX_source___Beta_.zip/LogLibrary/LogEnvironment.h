// (c) AbyssX Group
#if !defined(LOGENVIRONMENT_H)
#define LOGENVIRONMENT_H

//! Other libs we depend on.
#include "../Common/Common.h"
#include "../ConfigLibrary/ConfigEnvironment.h"

//! Our own includes.
#include "LogManager.h"

#endif
