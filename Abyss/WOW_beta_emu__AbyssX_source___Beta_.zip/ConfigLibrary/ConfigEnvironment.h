// (c) AbyssX Group
#if !defined(CONFIGENVIRONMENT_H)
#define CONFIGENVIRONMENT_H

//! Other libs we depend on.
#include "../Common/Common.h"

//! Our own includes.
#include "dotconfpp/dotconfpp.h"
#include "Config.h"

#endif
