// (c) AbyssX Group
#if !defined(COMPRESSIONENVIRONMENT_H)
#define COMPRESSIONENVIRONMENT_H

//! Other libs we depend on.
#include "../../Common/Common.h"

//! Our own includes.
#include "Compressor.h"
#include "zlib/zlib.h"

#endif
