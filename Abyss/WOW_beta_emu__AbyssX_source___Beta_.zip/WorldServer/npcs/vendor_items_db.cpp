// (c) AbyssX Group
#include "../WorldEnvironment.h"

#ifdef NPCS

VENDOR_DB::VENDOR_DB()
{
}

VENDOR_DB::~VENDOR_DB()
{
}

#endif
