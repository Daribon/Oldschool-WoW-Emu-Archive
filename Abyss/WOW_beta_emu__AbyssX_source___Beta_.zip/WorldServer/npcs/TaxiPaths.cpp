// (c) AbyssX Group
#include "../WorldEnvironment.h"

#ifdef NPCS

TaxiPaths::TaxiPaths()
{
}

TaxiPaths::~TaxiPaths()
{
}

#endif