// (c) AbyssX Group
#include "../WorldEnvironment.h"

#ifdef NPCS

TaxiNodes::TaxiNodes()
{
}

TaxiNodes::~TaxiNodes()
{
}

#endif