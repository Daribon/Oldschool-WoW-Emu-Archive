#if !defined(VENDOR_ITEMS_DB_H)
#define VENDOR_ITEMS_DB_H

#ifdef NPCS

class VENDOR_DB
{
	public:
		VENDOR_DB();
		~VENDOR_DB();

		DoubleWord VEntry;
		DoubleWord IEntry;
};

#endif

#endif