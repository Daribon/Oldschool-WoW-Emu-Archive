// (c) AbyssX Group
#include "../WorldEnvironment.h"

#ifdef NPCS

TaxiPathNodes::TaxiPathNodes()
{
}

TaxiPathNodes::~TaxiPathNodes()
{
}

#endif