// (c) AbyssX Group
#include "../WorldEnvironment.h"

// Constructor: GameObject.
GameObject::GameObject(QuadWord objectGuid, const char *name) :
	Object(objectGuid, name)
{
}

// Destructor: ~GameObject.
GameObject::~GameObject()
{
}
