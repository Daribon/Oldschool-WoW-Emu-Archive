// (c) AbyssX Group
#include "../WorldEnvironment.h"

#ifdef SPELLS

// Constructor: Spell.
Spell::Spell()
{
}

// Destructor: ~Spell.
Spell::~Spell()
{
}

#endif