// (c) AbyssX Group
#include "../WorldEnvironment.h"

WorldPort::WorldPort()
{
}

WorldPort::~WorldPort()
{
}
