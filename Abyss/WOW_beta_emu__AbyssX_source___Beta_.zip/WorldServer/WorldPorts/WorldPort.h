// (c) AbyssX Group
#if !defined(WORLDPORT_H)
#define WORLDPORT_H

class WorldPort
{
	public:
		WorldPort();
		~WorldPort();

		string mName;
		Float mX, mY, mZ;
		Byte mMap;
};

#endif
