// (c) AbyssX Group
#include "../WorldEnvironment.h"

#ifdef ITEMS

Item::Item()
{
	memset(&ItemDATA,0x00,sizeof(ItemDATA));
}

Item::~Item()
{
}

#endif