// (c) AbyssX Group
#include "../WorldEnvironment.h"

#ifdef EVENTSYSTEM

Timer::Timer()
{
}

Timer::~Timer()
{
}

#endif