// (c) AbyssX Group
#if !defined(MESSAGEENVIRONMENT_H)
#define MESSAGEENVIRONMENT_H

#include "CommonEnvironment.h"
//#include "NetworkLibrary.h"
#include "ObjectEnvironment.h"

// Message library predeclarations
class ChatCommand;
//class MessageManager;

// Message library
#include "ChatCommand.h"
//#include "MessageManager.h"

#endif
