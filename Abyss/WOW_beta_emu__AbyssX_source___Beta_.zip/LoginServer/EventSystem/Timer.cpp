// (c) AbyssX Group
#include "../LoginEnvironment.h"

#ifdef EVENTSYSTEM

Timer::Timer()
{
}

Timer::~Timer()
{
}

#endif