#include "stdafx.h"
#include "GameObject.h"

CGameObject::CGameObject(void):CWoWObject(OBJ_GAMEOBJECT)
{
}

CGameObject::~CGameObject(void)
{
}
