#include "stdafx.h"
#include "DynamicObject.h"

CDynamicObject::CDynamicObject(void):CWoWObject(OBJ_DYNAMICOBJECT)
{
}

CDynamicObject::~CDynamicObject(void)
{
}
