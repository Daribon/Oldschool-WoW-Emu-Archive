#pragma once
#include "WoWObject.h"

struct GameObjectData
{
};

class CGameObject :
	public CWoWObject
{
public:
	CGameObject(void);
	~CGameObject(void);
};
