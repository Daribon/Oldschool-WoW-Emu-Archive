#pragma once
#include "WoWObject.h"

struct DynamicObjectData
{
};

class CDynamicObject :
	public CWoWObject
{
public:
	CDynamicObject(void);
	~CDynamicObject(void);
};
