#include "Zone.h"

CZone::CZone(void):CWoWObject(OBJ_ZONE)
{
}

CZone::~CZone(void)
{
}
