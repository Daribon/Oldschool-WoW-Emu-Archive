#include "Container.h"
#include "Globals.h"

// this may not be necessary, may be deleted.
CContainer::CContainer(void):CWoWObject(OBJ_CONTAINER)
{
}

CContainer::~CContainer(void)
{
}
