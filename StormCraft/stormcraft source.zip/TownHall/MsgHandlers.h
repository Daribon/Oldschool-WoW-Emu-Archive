
extern void InstallMessageHandlers(class CClient *pClient);
extern void InstallGameMessageHandlers(class CClient *pClient);
extern void RemoveGameMessageHandlers(class CClient *pClient);
