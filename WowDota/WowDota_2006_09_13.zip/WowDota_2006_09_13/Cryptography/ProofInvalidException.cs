using System;
using System.Collections.Generic;
using System.Text;

namespace Cryptography
{
	public class InvalidProofException : Exception
	{
		public InvalidProofException(SRP authenticator)
			: base("Invalid proof for " + authenticator.ToString())
		{
		}
	}
}
