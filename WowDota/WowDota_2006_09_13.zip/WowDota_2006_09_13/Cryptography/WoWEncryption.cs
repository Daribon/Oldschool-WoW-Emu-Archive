using System;
using System.Collections.Generic;
using System.Security.Cryptography;

namespace Cryptography
{
	public class WoWPacket : SymmetricAlgorithm
	{
		public WoWPacket(BigInteger key)
		{
			KeyValue = key.getBytesLE();
			IVValue = new byte[1];
			IVValue[0] = 0;
		}

		public WoWPacket()
		{
		}

		public WoWPacket(SRP srp)
			: this(srp.SessionKey)
		{ }

		public override ICryptoTransform CreateDecryptor(byte[] rgbKey, byte[] rgbIV)
		{
			if (rgbIV.Length != 1)
				throw new ArgumentException("IV should only be one byte long");
			return new Transform(Transform.Direction.Decryption, rgbKey, rgbIV[0]);
		}

		public override ICryptoTransform CreateEncryptor(byte[] rgbKey, byte[] rgbIV)
		{
			if (rgbIV.Length != 1)
				throw new ArgumentException("IV should only be one byte long");
			return new Transform(Transform.Direction.Encryption, rgbKey, rgbIV[0]);
		}

		public override void GenerateIV()
		{
			throw new Exception("The method or operation is not implemented.");
		}

		public override void GenerateKey()
		{
			throw new Exception("The method or operation is not implemented.");
		}

		public class Transform : ICryptoTransform
		{
			internal Transform(Direction direction, byte[] key, byte iv)
			{
				this.direction = direction;
				this.key = key;
				this.iv = iv;
			}

			Transform(Direction direction, byte[] key)
				: this(direction, key, 0)
			{ }

			public enum Direction
			{
				Encryption,
				Decryption,
			}

			protected byte[] key;
			protected byte iv;
			protected int key_position = 0;
			protected Direction direction;

			public bool CanReuseTransform { get { return true; } }
			public bool CanTransformMultipleBlocks { get { return true; } }
			public int InputBlockSize { get { return 1; } }
			public int OutputBlockSize { get { return InputBlockSize; } }

			public int TransformBlock(byte[] inputBuffer, int inputOffset, int inputCount, byte[] outputBuffer, int outputOffset)
			{
				lock (this)
				{

					int bytes_written = 0;

					for (long i = inputOffset, o = outputOffset;
						i < inputCount + inputOffset;
						i++, o++)
					{
						key_position %= key.Length;

						if (direction == Direction.Encryption)
							outputBuffer[o] = (byte)((inputBuffer[i] ^ key[key_position]) + iv);
						else
							outputBuffer[o] = (byte)((inputBuffer[i] - iv) ^ key[key_position]);

						// Effectively the IV is the encrypted version of the previous byte in the stream
						if (direction == Direction.Encryption)
							iv = outputBuffer[o];
						else
							iv = inputBuffer[i];

						key_position++;
						bytes_written++;
					}

					return bytes_written;
				}
			}
			
			public byte[] TransformFinalBlock(byte[] inputBuffer, int inputOffset, int inputCount)
			{
				byte[] outputBuffer = new byte[inputCount];
				TransformBlock(inputBuffer, inputOffset, inputCount, outputBuffer, 0);
				return outputBuffer;
			}

			#region IDisposable Members

			public void Dispose()
			{
				for (int i = 0; i < key.Length; i++)
				{
					key[i] = 0;
				}
				iv = 0;
				key_position = 0;
			}

			#endregion
		}
	}
}
