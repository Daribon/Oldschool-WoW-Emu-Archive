using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;

namespace Cryptography
{
	public abstract class Hashing
	{
		public struct HashDataSource
		{
			public HashDataSource(byte[] data)
			{
				this.Data = data;
			}

			internal byte[] Data;

			public static implicit operator HashDataSource(byte[] data)
			{
				return new HashDataSource(data);
			}
			public static implicit operator HashDataSource(string data)
			{
				Encoding encoding = new ASCIIEncoding();
				return new HashDataSource(encoding.GetBytes(data));
			}
			public static implicit operator HashDataSource(BigInteger data)
			{
				return new HashDataSource(data.getBytesLE());
			}
		}

		public static byte[] Hash(HashAlgorithm algorithm, params HashDataSource[] data)
		{
			System.IO.MemoryStream buffer = new System.IO.MemoryStream();

			foreach (HashDataSource datasource in data)
			{
				byte[] bytes = datasource.Data;
				buffer.Write(bytes, 0, bytes.Length);
			}
			buffer.Position = 0;
			return algorithm.ComputeHash(buffer);
		}

		public static BigInteger HashToBigInteger(HashAlgorithm algorithm, params HashDataSource[] data)
		{
			return new BigInteger(Hash(algorithm, data));
		}
	}
}
