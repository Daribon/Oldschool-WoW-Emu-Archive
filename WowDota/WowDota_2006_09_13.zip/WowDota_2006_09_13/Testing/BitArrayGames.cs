using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Testing
{
	class BitArrayGames
	{
		public static void Run()
		{
			BitArray ba = new BitArray(7);

			ba.Set(1, true);
			ba.Set(2, true);
			ba.Set(6, true);

			int[] data = new int[2];
			ba.CopyTo(data, 0);

			Console.WriteLine("{0} {1}", data[0], data[1]);
		}
	}
}
