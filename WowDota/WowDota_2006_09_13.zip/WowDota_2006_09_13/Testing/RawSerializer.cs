using System;
using System.Collections.Generic;
using System.Runtime.Serialization;

namespace Testing
{	/*
	class RawFormatter : IFormatter
	{
		public RawSerializer()
		{

		}

		public SerializationBinder Binder
		{
			get
			{
				throw new Exception("The method or operation is not implemented.");
			}
			set
			{
				throw new Exception("The method or operation is not implemented.");
			}
		}

		public StreamingContext Context
		{
			get
			{
				throw new Exception("The method or operation is not implemented.");
			}
			set
			{
				throw new Exception("The method or operation is not implemented.");
			}
		}

		public object Deserialize(System.IO.Stream serializationStream)
		{
			throw new Exception("The method or operation is not implemented.");
		}

		public void Serialize(System.IO.Stream serializationStream, object graph)
		{
			throw new Exception("The method or operation is not implemented.");
		}

		public ISurrogateSelector SurrogateSelector
		{
			get
			{
				return surrogate;
			}
			set
			{
				surrogate = value;
			}
		}

		protected SerializationBinder binder = new SerializationBinder();
		protected ISurrogateSelector surrogate = new SurrogateSelector();
	}*/
}
