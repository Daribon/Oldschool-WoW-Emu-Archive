using System;
using System.Collections.Generic;
using System.Text;

using Core.Networking;
using System.Net;
using Core.Networking.Packet;
using Core.Data;

namespace Testing
{
	class Program
	{
		static ServerBase<WoWEndPoint> server;

		static void Main(string[] args)
		{
			MethodReflection.Games();
			Console.WriteLine("Done!");
			Console.ReadLine();
		}

		static void NetworkingTest()
		{
			Core.Scripting.ScriptAssembly.RegisterDefaults();

//			SocketPermission permission = new SocketPermission(System.Security.Permissions.PermissionState.None);
//			permission.AddPermission(NetworkAccess.Connect, TransportType.Tcp, "localhost", 7001);
//			permission.Demand();

			server = new Core.Networking.LoginServer();

			server.RecievedDataHandler += recieved_data;
			server.SentDataHandler += sent_data;
			server.ConnectHandler += new Core.Networking.Delegates.OnConnect(server_ConnectHandler);
			server.DisconnectHandler += new Core.Networking.Delegates.OnDisconnect(server_DisconnectHandler);

//			Random.stuff();
			server.Start(new IPEndPoint(IPAddress.Any, 3724));

//			IPAddress ip = IPAddress.Parse("192.168.1.101");
			IPAddress ip = IPAddress.Loopback;
			//WoWEndPoint client = new WoWEndPoint(new IPEndPoint(ip, 3724), new MessageType(Service.Login, Origin.Server));

			//client.RecievedDataHandler += client_RecievedDataHandler;
//			client.RecievedDataHandler += print_hex;
//			client.ClientData.User = new ClientUser("sineltor", "asdf");

//			DataPacket packet = DataPacket.Make(Core.Data.LoginClientMessage.AuthLogonChallenge);
//			LoginScripts.Hello.HelloPacket(client.ClientData, packet.Writer);
//			client.Send(packet);

			System.Console.ReadLine();

			server.Stop();
		}

		static void server_DisconnectHandler(RemoteEndpoint client)
		{
			System.Console.WriteLine("Client Disconnected: " + client);
			System.Console.WriteLine("Clients connected: " + server.ClientCount);
		}

		static void server_ConnectHandler(RemoteEndpoint client)
		{
			System.Console.WriteLine("New client connected: " + client);
			System.Console.WriteLine("Clients connected: " + server.ClientCount);
		}


		public static void print_hex(BasePacket packet)
		{
			byte[] data = packet.ToArray();
			print_hex(data, data.Length);
		}


		public static void print_hex(byte[] data, int length)
		{
			int line = 0;
			for (int i = 0; i < length; i++)
			{
				byte b = data[i];
				Console.Write(b.ToString("x2") + " ");
				if (++line == 16)
				{
					line = 0;
					Console.WriteLine();
				}
				//string.Format("{0} ", (int)b);
			}

			if (line > 0)
				Console.WriteLine();
		}

		static void recieved_data(RemoteEndpoint client, BasePacket packet)
		{
			System.Console.WriteLine("Read a packet of data from client {0} size {1}", client, packet.Length);

			print_hex(packet);
		}

		static void sent_data(RemoteEndpoint client, BasePacket packet)
		{
			System.Console.WriteLine("Sent a packet of data to client {0} size {1}", client, packet.Length);

			print_hex(packet);
		}

	}
}
