using System;
using System.Collections.Generic;
using System.Text;
using System.Security.Cryptography;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;
using System.Reflection;
using System.CodeDom;

namespace Testing
{
	[Serializable]
	class Random
	{
		enum Internet
		{
			a,
			b,
			c
		}

		public static void morestuff()
		{
			Assembly assembly = Assembly.Load("Login");
			
		}

		public static void stuff()
		{
			HashAlgorithm hash = new SHA1Managed();

			byte[] bytes1 = { 0x12, 0x42, 0xaf, 0x5f };
			byte[] bytes2 = { 0xa2, 0xb2, 0xcf, 0x5f, 0x99, 0x07, 0x80 };

			byte[] bytes3 = { 0x12, 0x42, 0xaf, 0x5f, 0xa2, 0xb2, 0xcf, 0x5f, 0x99, 0x07, 0x80 };

			string result1 = Convert.ToBase64String(hash.ComputeHash(bytes3));
			System.Console.WriteLine("Bytes3: {0}", result1);

			System.IO.MemoryStream stream1 = new System.IO.MemoryStream();
			stream1.Write(bytes1, 0, bytes1.Length);
			stream1.Write(bytes2, 0, bytes2.Length);
			stream1.Position = 0;

//			System.IO.MemoryStream stream2 = new System.IO.MemoryStream(bytes1);
//			stream2.Write(bytes2, 0, bytes2.Length);

			/*
			int b;
			while ((b = stream1.ReadByte()) != -1)
			{
				Console.WriteLine(b);
			}*/
			
			string result2 = Convert.ToBase64String(hash.ComputeHash(stream1));
			System.Console.WriteLine("Bytes1: {0}", result2);

		}

		public static void serializerFun()
		{
			Random crap = new Random();
			crap.Serialize();

			//MemoryStream ms;
			BinaryFormatter f = new BinaryFormatter();
			f.TypeFormat = System.Runtime.Serialization.Formatters.FormatterTypeStyle.TypesWhenNeeded;
		}

		int seven = 7;

		private void Serialize()
		{
			Console.Write("Serializing...");
			// create a file stream to write the file
			FileStream fileStream =
			   new FileStream("internet.out", FileMode.Create);
			// use the CLR binary formatter
			BinaryFormatter binaryFormatter =
			   new BinaryFormatter();
			binaryFormatter.TypeFormat = System.Runtime.Serialization.Formatters.FormatterTypeStyle.TypesWhenNeeded;
			// serialize to disk
			binaryFormatter.Serialize(fileStream, this.seven);
			Console.WriteLine("...completed");
			fileStream.Close();
		}

		public static void MemoryStreamFun()
		{
			MemoryStream stream = new MemoryStream();

			Console.WriteLine(
				"Capacity = {0}, Length = {1}, Position = {2}\n",
				stream.Capacity.ToString(),
				stream.Length.ToString(),
				stream.Position.ToString());

			stream.WriteByte(0x4f);
			stream.WriteByte(0x4f);
			stream.WriteByte(0x4f);

			Console.WriteLine(
				"written 3 bytes. Capacity = {0}, Length = {1}, Position = {2}\n",
				stream.Capacity.ToString(),
				stream.Length.ToString(),
				stream.Position.ToString());

			stream = new MemoryStream(17);

			Console.WriteLine(
				"new MemoryStream(17). Capacity = {0}, Length = {1}, Position = {2}\n",
				stream.Capacity.ToString(),
				stream.Length.ToString(),
				stream.Position.ToString());

			stream.WriteByte(0x4f);
			stream.WriteByte(0x4f);
			stream.WriteByte(0x4f);

			Console.WriteLine(
				"written 3 bytes. Capacity = {0}, Length = {1}, Position = {2}\n",
				stream.Capacity.ToString(),
				stream.Length.ToString(),
				stream.Position.ToString());

			Console.ReadLine();
		}

		public static void encoderfun()
		{
			MemoryStream stream = new MemoryStream();
			BinaryReader bin = new BinaryReader(stream);//new Networking.ReverseEndianBinaryReader(stream);
			
			stream.WriteByte(0x26);
			stream.WriteByte(0x00);
			stream.Position = 0;

			short x = bin.ReadInt16();

			Console.WriteLine("its {0}", x);

			Console.ReadLine();
		}

		enum Cool
		{
			Internet,
			Judgement,
			Song
		}

		public static void enumfun()
		{
			Cool cat = Cool.Judgement;

			//cat = "Internet";

			Console.WriteLine("cat = {0}", cat);
		}

		public static void arrayfun()
		{
			byte[] arr0 = { 0x12, 0x23, 0x34 };
			byte[] arr1 = { 0x12, 0x23, 0x34 };
			byte[] arr2 = { 0x12, 0x23, 0x31 };
			byte[] arr3 = arr2;

			if (arr0.Equals(arr1))
				Console.WriteLine("0 == 1");
			else
				Console.WriteLine("0 != 1");

			if (arr1 == arr2)
				Console.WriteLine("1 == 2");
			else
				Console.WriteLine("1 != 2");

			if (arr2 == arr3)
				Console.WriteLine("2 == 3");
			else
				Console.WriteLine("2 != 3");
		}
	}
}
