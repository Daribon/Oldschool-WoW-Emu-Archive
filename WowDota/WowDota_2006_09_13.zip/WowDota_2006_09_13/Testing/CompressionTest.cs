using System;
using System.Collections.Generic;
using System.Text;
using System.IO.Compression;
using System.IO;
using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;

namespace Testing
{
	class CompressionTest
	{
		static byte[] data = 
			{
				0x78, 0x9c, 0x75, 0xcc, 0xb1, 
				0x0e, 0xc2, 0x40, 0x0c, 0x03, 0xd0, 0xf2, 0x1f, 
				0xfc, 0x0c, 0xc7, 0x80, 0x2a, 0x71, 0x0b, 0x2d, 
				0x33, 0x8a, 0x2e, 0x29, 0xb2, 0x48, 0xd3, 0x2a, 
				0x5c, 0x41, 0xf4, 0xeb, 0x61, 0x41, 0x62, 0x08, 
				0x5e, 0x9f, 0xed, 0xa4, 0x58, 0x57, 0x72, 0xbe, 
				0xec, 0x96, 0x52, 0x31, 0xd9, 0xb9, 0x6d, 0x36, 
				0xe3, 0x73, 0x7b, 0x6c, 0x3e, 0x49, 0x5f, 0x4b, 
				0x54, 0xab, 0xca, 0x00, 0x51, 0xce, 0x30, 0x8c, 
				0x34, 0x47, 0x25, 0x18, 0xc3, 0xae, 0xe1, 0xc1, 
				0xde, 0x69, 0xa8, 0xa1, 0x1c, 0x72, 0xb7, 0xf8, 
				0x43, 0x5e, 0x21, 0xb6, 0x76, 0x9f, 0xa5, 0xc4, 
				0xc3, 0x4c, 0xc5, 0xa7, 0x50, 0x4e, 0x04, 0x0e, 
				0xa1, 0x27, 0x15, 0x8b, 0xdf, 0x7a, 0x27, 0x96, 
				0xee, 0x06, 0xd5, 0x7f, 0x0c, 0x13, 0xff, 0xb5, 
				0x37, 0x05, 0x68, 0x5d, 0xa6
			};

		static int uncompressedLength = 0x0139;

		public static void Run()
		{

			MemoryStream ms = new MemoryStream(data);

			Inflater inf = new Inflater();
			inf.SetInput(data);

			byte[] out_bytes = new byte[uncompressedLength];
			int bytes_read = inf.Inflate(out_bytes);
			
			Console.WriteLine("Read {0} bytes. remaining = {1}", bytes_read, inf.RemainingInput);

			FileStream f = new FileStream("test", FileMode.OpenOrCreate);
			f.Write(out_bytes, 0, out_bytes.Length);
			f.Close();
			/*
			MemoryStream cmp = new MemoryStream(data);
			DeflateStream def = new DeflateStream(cmp, CompressionMode.Decompress);

			def.Read(out_bytes, 0, out_bytes.Length);

			f = new FileStream("test2", FileMode.OpenOrCreate);
			byte[] win = out_bytes;//cmp.ToArray();
			f.Write(win, 0, win.Length);
			f.Close();*/

			StreamTest();
		}

		public static void StreamTest()
		{
			MemoryStream ms = new MemoryStream(data);
			InflaterInputStream iis = new InflaterInputStream(ms);
			
			byte[] out_bytes = new byte[uncompressedLength];
			Console.WriteLine("avaliable = {0}", iis.Available);
			int bytes_read = iis.Read(out_bytes, 0, out_bytes.Length + 1);
			Console.WriteLine("read {0} bytes", bytes_read);

			FileStream f = new FileStream("test3", FileMode.OpenOrCreate);
			f.Write(out_bytes, 0, bytes_read);
			f.Close();

			DeflaterOutputStream dos = new DeflaterOutputStream(new MemoryStream());
			
		}

		public static void Search()
		{
			byte[] buffer = new byte[4096];
			int bytes_read = 0;

			for (int packet = 0; packet < 1/*Data.packets.Length*/; packet++)
			{
				Console.WriteLine("Packet {0}...", packet);

				byte[] data = Data.packets[packet];

				for (int offset = 4; offset < data.Length - 1; offset++)
				{
					Inflater inf;
					FileStream file = null;
					try
					{
						file = null;
						inf = new Inflater();
						inf.SetInput(data, offset, data.Length - offset);
						bytes_read = inf.Inflate(buffer);

						if (bytes_read == 0)
							continue;
						Console.WriteLine("Found possible match in packet {0} offset {1} length {2}", packet, offset, bytes_read);

						file = new FileStream(string.Format("packet{0}off{1}.data", packet, offset), FileMode.OpenOrCreate);

						Program.print_hex(buffer, bytes_read);
						file.Write(buffer, 0, bytes_read);

						int next_packet = packet + 1;
						while (inf.IsNeedingInput && next_packet < Data.packets.Length)
						{
							Console.WriteLine("... {0}", next_packet);
							inf.SetInput(Data.packets[next_packet++]);
							bytes_read = inf.Inflate(buffer);
							if (bytes_read == 0)
								break;
							Program.print_hex(buffer, bytes_read);
							file.Write(buffer, 0, bytes_read);
						}
					}
					catch
					{
						continue;
					}
					finally
					{
						if (file != null)
							file.Close();
					}

					/*
					while (inf.IsFinished == false)
					{
						Console.WriteLine("...");
						bytes_read = inf.Inflate(buffer);
						if (bytes_read == 0)
							break;

						Program.print_hex(buffer, bytes_read);

					}*/
//					offset += inf.TotalIn;
				}
			}
		}
	}
}
