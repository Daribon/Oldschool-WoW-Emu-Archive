using System;
using System.Collections.Generic;
using System.Text;

using Cryptography;
using System.Security.Cryptography;
using System.IO;

namespace Testing
{
	class CryptoTest
	{
		public static void Run()
		{
			SymmetricAlgorithm crypto = new Cryptography.WoWPacket();
		
			byte[] data = {1,2,3,4,5,6,7,72,123,34};
			MemoryStream read_stream = new MemoryStream(data);
			read_stream.Position = 0;

			MemoryStream write_stream = new MemoryStream();

			byte[] key = {9,8,7,6,5,4,3,2,1};
			byte[] iv = {66};
			CryptoStream encStream = new CryptoStream(read_stream,
				crypto.CreateEncryptor(key, iv),
				CryptoStreamMode.Read);

                
			Console.WriteLine("Encrypting...");
 
			int x;
			while ((x = encStream.ReadByte()) != -1)
			{
				Console.Write("{0} ", x);
				write_stream.WriteByte((byte)x);
			}
			write_stream.Position = 0;

			CryptoStream decStream = new CryptoStream(write_stream,
				crypto.CreateDecryptor(key, iv),
				CryptoStreamMode.Read);

			Console.WriteLine("\n\nDecrypting...");

			while ((x = decStream.ReadByte()) != -1)
			{
				Console.Write("{0} ", x);
			}
		}
	}
}
