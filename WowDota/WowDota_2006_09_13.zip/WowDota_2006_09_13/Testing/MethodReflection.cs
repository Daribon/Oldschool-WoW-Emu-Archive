using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Testing
{
	class MethodReflection
	{
		class A
		{
			public virtual void SomeMethod()
			{
				Console.WriteLine("hmmm");
			}
		}

		class B : A
		{
			public override void SomeMethod()
			{
				Console.WriteLine("internet");
			}
		}

		class C
		{
			public void GenericMethod<T>(T x)
			{
				Console.WriteLine("generic intarweb");
			}

			public void AnotherMethod(ref int x)
			{
				Console.WriteLine(x);
			}
		}

		public static void Games()
		{
			A b = new B();

			Type[] arguments = { typeof(int) };
/*			foreach (MethodInfo method in typeof(C).GetMethods())
			{
				Console.WriteLine("{0}:", method);
				//MethodInfo method = typeof(A).GetMethod("GenericMethod", arguments, null);
				foreach (ParameterInfo p in method.GetParameters())
				{ Console.WriteLine("\t{0}", p.ParameterType); }
			}*/

			ParameterModifier mod = new ParameterModifier(1);
			mod[0] = true;
			ParameterModifier[] mods = { mod };
			MethodInfo method = typeof(C).GetMethod("AnotherMethod",
				BindingFlags.Instance | BindingFlags.Public, System.Type.DefaultBinder, arguments, mods);

			if (method == null)
				Console.WriteLine("Method not found!");
			else
			{
				object[] args = { 2 };
				method.Invoke(new C(), args);
			}
//			method = method.MakeGenericMethod(typeof(int));
//			method.Invoke(b, null);
		}
	}
}
