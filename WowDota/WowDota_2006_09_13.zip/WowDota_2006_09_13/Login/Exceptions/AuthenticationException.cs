using System;
using System.Collections.Generic;
using System.Text;
using Core.Data;
using Core.Networking.Packet;
using Core;

namespace Login.Exceptions
{
	class AuthenticationException : BaseLoginException
	{
		public AuthenticationException(LoginErrorCode errorcode)
			: base(string.Format("AuthenticationException: {0}", errorcode))
		{
			this.errorcode = errorcode;
		}

//		private byte message_source;
		private LoginErrorCode errorcode;

		public override void Dispatch(Session connection)
		{
			DataPacket packet = DataPacket.Make(LoginServerMessage.AuthLogonChallenge);
			packet.Writer.BindZeros(1);
			packet.Writer.Write((byte)errorcode);
			connection.Endpoint.Send(packet);
			connection.Endpoint.Close(errorcode.ToString());
		}
	}
}
