using System;
using System.Collections.Generic;
using System.Text;

namespace Login.Exceptions
{
	class BaseLoginException : Core.Scripting.ProcessPacket.PacketParseException
	{
		public BaseLoginException(string message)
			: base(message)
		{
		}

		public BaseLoginException(string message, Exception innerexception)
			: base(message, innerexception)
		{
		}
	}
}
