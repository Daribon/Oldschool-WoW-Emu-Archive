using System;
using System.Collections.Generic;
using System.Text;

namespace Login.Exceptions
{
	class InvalidPacketDataException : BaseLoginException
	{
		public InvalidPacketDataException(string message)
			: base(message)
		{
		}

		public InvalidPacketDataException(string message, Exception innerexception)
			: base(message, innerexception)
		{ }

	}
}
