using System;
using System.IO;
using Core.Data.Serialisation;
using Core.Scripting.ScriptObject;
using Core;
using Core.Scripting.ProcessPacket;

namespace Login
{
	[ScriptObject(typeof(Session))]
	public class SystemInformation : IBindable
	{
		public SystemInformation()
		{ }

		public Core.Data.Client.Version Version;

		#region OS
		enum OperatingSystem
		{
			OSX,
			Win
		}

		OperatingSystem os = OperatingSystem.OSX;
		public string OS
		{
			set
			{
				try
				{
					os = (OperatingSystem)Enum.Parse(typeof(OperatingSystem), value);
				}
				catch (ArgumentException e)
				{
					throw new PacketParseException("Could not parse operating system string " + value, e);
				}
			}
			get
			{
				return os.ToString();
			}
		}
		#endregion

		#region Arch
		enum ArchEnum
		{
			x86,
			PPC
		}

		ArchEnum archetecture = ArchEnum.x86;
		public string Archetecture
		{
			set
			{
				try
				{
					archetecture = (ArchEnum)Enum.Parse(typeof(ArchEnum), value);
				}
				catch (ArgumentException e)
				{
					throw new PacketParseException("Could not parse archetecture string " + value, e);
				}
			}
			get
			{
				return archetecture.ToString();
			}
		}
		#endregion

		public string Locale = "enUS";

		public uint Timezone = 0x258;
		public System.Net.IPAddress Ip = System.Net.IPAddress.Loopback;

		public static SystemInformation Defaults = new SystemInformation();

		#region IBindable Members

		public void Bind(Binder binder)
		{
			binder.Bind(ref Version);
			
			string temp_arch = Archetecture;
			binder.BindReversedCStr(ref temp_arch);
			Archetecture = temp_arch;

			string temp_os = OS;
			binder.BindReversedCStr(ref temp_os);
			OS = temp_os;

			binder.BindReversed(ref Locale, 4);
			binder.Bind(ref Timezone);
			binder.Bind(ref Ip);
		}

		#endregion
	}
}
