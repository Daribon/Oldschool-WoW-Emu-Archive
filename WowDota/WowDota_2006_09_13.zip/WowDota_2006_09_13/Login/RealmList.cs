using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;
using Core.Data;
using Core;
using Core.Scripting.ProcessPacket;

namespace LoginScripts
{
	class RealmList
	{
		[PacketHandler(LoginClientMessage.RequestRealmList)]
		public static MessageId[] RealmListRequest(Session client, Binder binder)
		{
			// Don't konw what these are for
			binder.BindZeros(4);

			MessageId[] response = { Core.Data.LoginServerMessage.RealmList };
			return response;
		}

		[PacketHandler(LoginServerMessage.RealmList)]
		public static MessageId[] RealmListData(Session client, Binder binder)
		{
			// Skip the packet length for the moment
			binder.BindIgnoredBytes(2);
			// Don't konw what these are for
			binder.BindZeros(4);

			Core.Data.Realm.List realmlist = client.RealmList;
			realmlist.Bind(client, binder);
			ushort magic = 0x0010;
			binder.Bind(ref magic);

			ushort packet_length = (ushort)(binder.Position - 3);
			binder.PushPosition();
			binder.Position = 1;
			binder.Bind(ref packet_length);
			binder.PopPosition();

			MessageId[] response = { };
			return response;
		}
	}
}
