using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using Login.Exceptions;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;

namespace Login
{
	public class Hello
	{
		[PacketHandler(LoginClientMessage.AuthLogonChallenge)]
		public static MessageId[] HelloPacket(Session client, Binder binder)
		{
			byte errorcode = (byte)0x03;//Core.Data.LoginErrorCode.RESPONSE_DISCONNECTED;
			binder.Bind(ref errorcode);

			long packet_length_position = binder.Position;
			ushort packet_length = 0;
			binder.Bind(ref packet_length);

			string magic = "WoW";
			binder.BindCStr(ref magic);
			if (binder.IsReader && magic != "WoW")
				throw new InvalidPacketDataException("Magic doesn't match");

			binder.Bind(client.GetScriptObject<Session, SystemInformation>(true));
			string username = "";
			
			if (binder.IsWriter)
			{
				username = client.User.Name;
			}
			binder.BindLengthValue(ref username);

			if (binder.IsReader)
			{
				client.User = Core.Data.Base.Singleton.GetUser(username);

				if (client.User == null)
					throw new AuthenticationException(LoginErrorCode.AccountNotFound);

				LoginErrorCode login_errorcode;
				if (client.User.CanLogIn(out login_errorcode) == false)
				{
					client.User = null;
					throw new AuthenticationException(login_errorcode);
				}

				if (packet_length + 4 != binder.Position)
					throw new InvalidPacketDataException("Claimed packet length is wrong...");

				client.User.IsCurrentlyLoggedIn = true;
			}
			else
			{
				packet_length = (ushort)(binder.Position - packet_length_position - sizeof(ushort));
				binder.PushPosition();
				binder.Position = packet_length_position;
				(binder as Writer).Write(packet_length);
				binder.PopPosition();
			}

			MessageId[] response = { Core.Data.LoginServerMessage.AuthLogonChallenge };
			return response;
		}
	}
}
