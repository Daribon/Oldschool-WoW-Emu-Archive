using System;
using System.Collections.Generic;
using System.Text;

using Login.Exceptions;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;

namespace LoginScripts
{
	class Authentication
	{
		[PacketHandler(Core.Data.LoginServerMessage.AuthLogonChallenge)]
		public static MessageId[] AuthLogonChallengePacket(Session client, Binder binder)
		{
			binder.BindZeros(1);
			byte errorcode_byte = 0;
			binder.Bind(ref errorcode_byte);
			LoginErrorCode errorcode = (LoginErrorCode)errorcode_byte;
			if (errorcode != LoginErrorCode.Ok)
				throw new AuthenticationException(errorcode);

			if (client.User == null)
				throw new InvalidPacketDataException("User is null... client probably didn't say hello");

			try
			{
				client.User.ClearAuthenticator();
				SRPBinding srp = client.User.CurrentAuthenticatorBinding;
				srp.BindServerChallenge(binder);
//				Console.WriteLine(srp.InternalsToString());
			}
			catch (InvalidOperationException e)
			{
				throw new InvalidPacketDataException("Could not bind SRP authenticator:", e);
			}

			// Curious what this is for.
			binder.BindIgnoredBytes(16);

			byte is_morestuff = 0;
			binder.Bind(ref is_morestuff);

			if (is_morestuff != 0)
				throw new NotImplementedException("Extended server authentication packet not implemented");

			MessageId[] response = { Core.Data.LoginClientMessage.AuthLogonProof };
			return response;
		}

		[PacketHandler(Core.Data.LoginClientMessage.AuthLogonProof)]
		public static MessageId[] AuthClientLogonProofPacket(Session client, Binder binder)
		{
			if (client.User == null)
				throw new InvalidPacketDataException("User hasn't logged in...");

			try
			{
				client.User.CurrentAuthenticatorBinding.BindClientProof(binder);
			}
			catch (Cryptography.InvalidProofException)
			{
				throw new AuthenticationException(LoginErrorCode.AuthenticationFailure);
			}

			binder.BindZeros(2);

//			Console.WriteLine(client.User.CurrentAuthenticator.InternalsToString());
			//Console.WriteLine("Client proof accepted!");

			MessageId[] response = { Core.Data.LoginServerMessage.AuthLogonProof };
			return response;
		}

		[PacketHandler(Core.Data.LoginServerMessage.AuthLogonProof)]
		public static MessageId[] AuthServerLogonProofPacket(Session client, Binder binder)
		{
			if (client.User == null)
				throw new InvalidPacketDataException("User hasn't logged in...");

			byte errorcode_byte = 0;
			binder.Bind(ref errorcode_byte);
			LoginErrorCode errorcode = (LoginErrorCode)errorcode_byte;
			if (errorcode != LoginErrorCode.Ok)
				throw new AuthenticationException(errorcode);

			try
			{
				client.User.CurrentAuthenticatorBinding.BindServerProof(binder);
			}
			catch (Cryptography.InvalidProofException)
			{
				throw new AuthenticationException(LoginErrorCode.AuthenticationFailure);
			}

			binder.BindZeros(4);

			//Console.WriteLine("Server proof accepted!");

			MessageId[] response = { Core.Data.LoginClientMessage.RequestRealmList };
			return response;
		}
	}
}
