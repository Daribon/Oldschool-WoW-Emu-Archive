using System;
using System.Collections.Generic;
using System.Text;
using Core.Data;

namespace ConsoleServer
{
	static class CommandConsole
	{
		internal static void AddUser()
		{
			Console.WriteLine("Adding user.");
			Console.Write("Username: ");
			string username = Console.ReadLine();

			if (Core.Data.Base.Singleton.GetUser(username) != null)
			{
				Console.WriteLine("User '{0}' already exists.", username);
				return;
			}

			Console.Write("Password: ");
			string password = Console.ReadLine();
			if (username != null && password != null)
			{
				try
				{
					Core.Data.Base.Singleton.AddUser(new ServerUser(username, password));
					Console.WriteLine("Added '{0}'", username);
				}
				catch (InvalidUsernameException)
				{
					Console.WriteLine("Invalid username");
				}
				catch (InvalidPasswordException)
				{
					Console.WriteLine("Invalid password");
				}
			}
		}

		internal static void SetPassword()
		{
			Console.Write("Username: ");
			string username = Console.ReadLine();
			User user = Core.Data.Base.Singleton.GetUser(username);
			if (user == null)
			{
				Console.WriteLine("User {0} does not exist", username);
				return;
			}

			Console.Write("New Password: ");
			string password = Console.ReadLine();

			try
			{
				user.SetPassword(password);
			}
			catch (InvalidPasswordException)
			{
				Console.WriteLine("Invalid password");
			}
		}

		internal static void ClearDatabase()
		{
			Core.Data.Base.Clear();
			Console.WriteLine("Database cleared");
		}
		internal static void ReloadDatabase()
		{
			Core.Data.Base.Reload();
			Console.WriteLine("Database reloaded");
		}

		internal static void Run()
		{
			ConsoleKeyInfo key;
			while (true)
			{
				key = Console.ReadKey(true);

				switch (key.Key)
				{
					case ConsoleKey.H:
						Console.WriteLine("H = This help message");

						Console.WriteLine("A = Add user");
						Console.WriteLine("P = Change password");

						Console.WriteLine("C = Clear database");
						Console.WriteLine("R = Reload database");

						Console.WriteLine("Q = Quit");
						break;

					case ConsoleKey.A:
						AddUser();
						break;

					case ConsoleKey.P:
						SetPassword();
						break;

					case ConsoleKey.C:
						ClearDatabase();
						break;

					case ConsoleKey.R:
						ReloadDatabase();
						break;

					case ConsoleKey.Q:
						return;

					default:
						Console.WriteLine("Unknown command {0}. Press H for help.", key.Key);
						break;
				}

				Console.WriteLine();
			}
		}
	}
}
