using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking;
using Core.Data.Client;
using Core.Networking.Packet;
using System.IO;
using Core.Data.Serialisation;
using Core;

namespace ConsoleServer
{
	class Debugging
	{
		public static void Register(LoginServer login_server, RealmServer[] realm_servers)
		{
			Core.Data.Base.Singleton.AddDebuggingUsers();

			FileLogger logfile = new FileLogger(
				new FileStream("interesting.log", FileMode.Create),
				Logger.Verbosity.Medium);
			Logger.Register(logfile);
		}
	}
}
