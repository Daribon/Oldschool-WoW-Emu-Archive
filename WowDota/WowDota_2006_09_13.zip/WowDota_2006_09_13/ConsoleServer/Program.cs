using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking;
using System.Net;
using Core;
using Core.Data;
using System.IO;
using Core.Scripting;

namespace ConsoleServer
{
	class Program
	{
		static LoginServer login_server;
		static RealmServer[] realm_servers;

		static TextLogger console_logger;

		static void SetupConsole()
		{
			Console.ForegroundColor = ConsoleColor.White;
			Console.CursorVisible = false;
			Console.Title = "Console server";
			console_logger = new ConsoleLogger(Logger.Verbosity.Medium);
			Logger.Register(console_logger);
		}

		static void StartLogging()
		{
			Properties.Settings settings = new ConsoleServer.Properties.Settings();

			if (settings.LogFile != null
				&& settings.LogFile != "")
			{
				Logger.Register(new FileLogger(settings.LogFile, Logger.Verbosity.High));
			}

			Logger.Register(new FileLogger(new FileStream("session.log", FileMode.Create),
				Logger.Verbosity.High));
		}

		static void StartLoginServer(IPAddress ip)
		{
			login_server = new LoginServer();

			login_server.Start(ip);
		}

		static void StartRealmServer(IPEndPoint ipep)
		{
			realm_servers = new RealmServer[1];
			realm_servers[0] = new RealmServer("The winternet");

			realm_servers[0].Start(ipep);
		}

		static IPAddress GetExternalIPAddress()
		{
			IPHostEntry host = Dns.GetHostEntry(Dns.GetHostName());

			foreach (IPAddress address in host.AddressList)
			{
				if (address.AddressFamily == System.Net.Sockets.AddressFamily.InterNetwork)
					return address;
			}

			return null;
		}

		static void Main(string[] args)
		{
			SetupConsole();

			Console.WriteLine("WoWterlan server!");
			Console.WriteLine();

			StartLogging();

			ScriptAssembly.RegisterDefaults();

			IPAddress binding_ip = GetExternalIPAddress();
			StartLoginServer(binding_ip);
			StartRealmServer(new IPEndPoint(binding_ip, 9000));

			foreach (RealmServer server in realm_servers)
				login_server.Register(server);

			Debugging.Register(login_server, realm_servers);

			Console.WriteLine("Startup complete. Press H for help");
			CommandConsole.Run();
		}
	}
}
