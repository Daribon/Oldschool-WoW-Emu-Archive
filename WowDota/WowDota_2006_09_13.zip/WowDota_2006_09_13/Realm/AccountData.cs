using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core.Data;
using Core.Scripting.ProcessPacket;
using Core.Data.Serialisation;
using System.Security.Cryptography;
using System.IO;
using Core;
using Core.Scripting;

namespace Realm
{
	[ScriptObject(typeof(User)), Serializable]
	class AccountData
	{
		uint Version;
		string Data;
		byte[] DataHash = new byte[128];

		[EventHandler(Event.Type.CharacterLogin)]
		void TriggerAccountDataUpdate(Event e)
		{
			PacketManager.Singleton.CreatePacket(e.Session, RealmServerMessage.AccountDataChecksum);
		}

		[PacketHandler(RealmServerMessage.AccountDataChecksum)]
		MessageId[] Checksum(Session client, Binder binder)
		{
			MessageId[] response = { RealmClientMessage.AccountDataUpdate };

			if (binder.IsWriter)
			{
				binder.Bind(DataHash);
				return response;
			}
			else
			{
				byte[] remote_hash = new byte[binder.ExpectedBytesLeft];
				binder.Bind(remote_hash);

				bool hash_is_correct = true;

				if (remote_hash.Length != DataHash.Length)
				{
					hash_is_correct = false;
				}
				else
				{
					for (int i = 0; i < remote_hash.Length; i++)
					{
						if (remote_hash[i] != DataHash[i])
						{
							hash_is_correct = false;
							break;
						}
					}
				}

				if (hash_is_correct)
					return response;
				else
					return null;
			}
		}

		[PacketHandler(RealmClientMessage.AccountDataUpdate)]
		MessageId[] Update(Session client, Binder binder)
		{
			binder.Bind(ref Version);
			Binder dataBinder = binder.BindCompressedDataStart();

			if (dataBinder != null)
			{
				int length = 0;
				if (dataBinder.IsReader)
					length = (int)dataBinder.ExpectedBytesLeft;
				else
					length = Data.Length;
				dataBinder.Bind(ref Data, length);

				// Unfortunally this isn't working even a little bit.
				// the problem is that this hash is 16 bytes long, but for some reason the
				// server deals with 128 byte MD5 hashes. I don't know that md5s get that big...
				//DataHash = Cryptography.Hashing.Hash(MD5.Create(), Data);
			}
			else if (binder.IsReader)
				Data = null;

			binder.BindCompressedDataEnd(dataBinder);

			MessageId[] response = { }; //RealmServerMessage.AccountDataUpdateResponse };
			return response;
		}

		[PacketHandler(RealmServerMessage.AccountDataUpdateResponse)]
		MessageId[] UpdateConfirm(Session client, Binder binder)
		{
			// I have no idea what this packet contains.
			throw new NotImplementedException();

		}
	}
}
