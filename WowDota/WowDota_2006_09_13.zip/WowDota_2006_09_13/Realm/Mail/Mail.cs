using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Mail
{
	[Serializable]
	class Mail
	{
	}
}
