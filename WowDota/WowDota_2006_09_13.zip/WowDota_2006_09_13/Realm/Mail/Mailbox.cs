using System;
using System.Collections.Generic;
using Core.Scripting.ScriptObject;
using Realm.Object;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;
using System.Collections;

namespace Realm.Mail
{
	[ScriptObject(typeof(Player)), Serializable]
	class Mailbox
	{
		ArrayList Mail = new ArrayList();

		[PacketHandler(RealmClientMessage.QueryNextMailTime)]
		MessageId[] Query(Session client, Binder binder)
		{
			MessageId[] response = { RealmServerMessage.QueryNextMailTime };
			return response;
		}

		// This is quite magic. I don't konw why, but this means there's no mail
		// (mangos sends 0xc7a8c000)

		const uint NoMail = 0xcfffffff;

		[PacketHandler(RealmServerMessage.QueryNextMailTime)]
		MessageId[] QueryResponse(Session client, Binder binder)
		{
			uint NextMailTime = NoMail;
			binder.Bind(ref NextMailTime);
			return null;
		}
	}
}
