using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Realm
{
	[Serializable]
	public class Pet : IBindable
	{
		public void Bind(Binder binder)
		{
			binder.BindZeros(12);
		}

		public static Pet None = new Pet();
	}
}
