using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;

namespace Realm.Chat
{
	[ScriptObject(typeof(Core.Data.Base)), Serializable]
	class Channel
	{
		[PacketHandler(RealmClientMessage.JoinChannel)]
		MessageId[] Join(Session client, Binder binder)
		{
			if (binder.IsWriter)
				throw new NotImplementedException();

			string channel_name = "";
			binder.BindCStr(ref channel_name);
			binder.BindZeros(1);

			Logger.Log(client, Logger.Priority.Medium, "Joined channel {0}", channel_name);

			return null;

		}

		[PacketHandler(RealmClientMessage.Chat)]
		MessageId[] ClientChat(Session client, Binder binder)
		{
			GUID guid = new GUID();
			binder.Bind(ref guid);
			string message = "";
			binder.BindCStr(ref message);
			Logger.Log(guid.GetObject(), Logger.Priority.Medium, "Sent message {0}", message);

			return null;
		}
	}
}
