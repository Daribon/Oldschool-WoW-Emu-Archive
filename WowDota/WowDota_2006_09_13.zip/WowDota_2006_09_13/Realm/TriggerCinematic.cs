using System;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;
using Realm.Object;
using Core.Scripting.ScriptObject;
using Core.Scripting;

namespace Realm
{
	[ScriptObject(typeof(Player)), Serializable]
	class TriggerCinematic
	{
		// Cinematics disabled for the moment. They generate huge numbers of time offset packets
		// which floods the network. I've no idea why its doing that - some reversing is in order.

		bool WatchedOpeningCinematic = true;

		enum Cinematic : uint
		{
			Human = 81,
			Orc = 21,
			Dwarf = 41,
			Nightelf = 61,
			Undead = 2,
			Tauren = 141,
			Gnome = 101,
			Troll = 121,
		}

		static Cinematic GetCinematicId(Race race)
		{
			switch (race)
			{
				case Race.Human:
					return Cinematic.Human;
				case Race.Orc:
					return Cinematic.Orc;
				case Race.Dwarf:
					return Cinematic.Dwarf;
				case Race.NightElf:
					return Cinematic.Nightelf;
				case Race.Undead:
					return Cinematic.Undead;
				case Race.Tauren:
					return Cinematic.Tauren;
				case Race.Gnome:
					return Cinematic.Gnome;
				case Race.Troll:
					return Cinematic.Troll;
				default:
					throw new ArgumentException(string.Format("{0} is not a valid race", race));
			}
		}

		// We have to use a chunky handler so we can block the packet from sending
		[PacketHandler(RealmServerMessage.TriggerCinematic)]
		bool MovieTime(
			Session session,
			MessageId id,
			Binder binder,
			out MessageId[] responses)
		{
			responses = null;

			Player character = Player.GetActiveCharacter(session);
			
			if (binder.IsWriter && WatchedOpeningCinematic == true)
			{
				new Event(session, Event.Type.CharacterEnterWorld, character, Logger.Priority.ClientState).Dispatch();
				return false;
			}

			Cinematic cinematic = GetCinematicId(character.Race);

			new Event(session, Event.Type.TriggerCinematic, cinematic).Dispatch();

			uint cinematic_value = (uint)cinematic;
			binder.Bind(ref cinematic_value);
			
			WatchedOpeningCinematic = true;

			PacketManager.Singleton.CreatePacket(session, RealmServerMessage.BindPointUpdate);
			PacketManager.Singleton.CreatePacket(session, RealmServerMessage.Update);

			return true;
		}

		[PacketHandler(RealmClientMessage.TriggerNextCinematicCamera)]
		MessageId[] NextMovie(Session session, Binder binder)
		{
			// there are no more movies. Enter the world now kthxbai
//			new Event(session, Event.Type.CharacterEnterWorld, Player.GetActiveCharacter(session))
//				.Dispatch();

			return null;
		}
	}
}
