using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Realm
{
	[Serializable]
	class Guild : IBindable
	{
		public uint Id = 0;

		public static Guild None = new Guild();

		#region IBindable Members

		public void Bind(Binder binder)
		{
			binder.BindZeros(4); // id
		}

		#endregion
	}
}
