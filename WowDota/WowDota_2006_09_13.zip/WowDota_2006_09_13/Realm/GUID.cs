using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;
using Realm.Object;

namespace Realm
{
	// Wrapper around ulong for Guid stuff
	[Serializable]
	public struct GUID : IBindable
	{
		internal ulong RawValue;

		public GUID(ulong RawValue)
		{
			this.RawValue = RawValue;
		}

		/// <summary>
		/// Initialise this guid as a new GUID
		/// </summary>
		public void Generate()
		{
			RawValue = GUIDGenerator.GetNew().RawValue;
		}

		public override bool Equals(object obj)
		{
			if (obj == null || GetType() != obj.GetType())
			{
				return false;
			}

			return RawValue == ((GUID)obj).RawValue;
		}

		public override int GetHashCode()
		{
			return (int)RawValue ^ (int)(RawValue >> 32);
		}

		public override string ToString()
		{
			return RawValue.ToString();
		}

		public void Bind(Binder binder)
		{
			binder.Bind(ref RawValue);
		}

		public void BindPacked(Binder binder)
		{
			if (binder.IsReader)
				throw new NotImplementedException();

			// The guid_bytes works something like this:
			// Think of the 8 bytes in the guid. The 8 bits here correspond to them.
			// a 1 means we'll send it (its nonzero), a 0 means we won't.

			// 0xff means joseph is lazy.
			byte guid_bytes = 0xff;
			binder.Bind(ref guid_bytes);
			Bind(binder);
		}

		public ObjectBase GetObject()
		{
			if (RawValue == 0)
				throw new InvalidOperationException("GetObject doesn't work if the GUID has not been initialised");

			return Inhabitants.Singleton.Get(this);
		}

		public bool IsSet
		{
			get
			{
				return RawValue != 0;
			}
		}
	}
}
