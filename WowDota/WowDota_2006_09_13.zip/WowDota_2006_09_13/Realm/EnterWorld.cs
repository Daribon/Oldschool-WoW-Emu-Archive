using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;
using Core.Scripting.ScriptObject;
using Realm.Object;
using Core.Scripting;

namespace Realm
{
	class EnterWorld
	{
		[PacketHandler(RealmClientMessage.EnterWorld)]
		static MessageId[] SetCharacter(Session session, Binder binder)
		{
			// First we need to work out which character it is
			if (binder.IsWriter)
				throw new NotImplementedException();

			GUID characterGuid = new GUID();
			binder.Bind(ref characterGuid);

			// Set the users' active character
			CharacterList characters = session.GetScriptObject<User, CharacterList>(true);
			Player character = characters.GetCharacter(characterGuid);
			ScopeResolver.ResolveScope<User>(session).ScriptScope.Set<Player>(character);

			character.EnterWorld(session);

			new Event(session, Event.Type.CharacterLogin, character, Logger.Priority.ClientState).Dispatch();

			MessageId[] response =
			{
//				RealmServerMessage.BindPointUpdate,
//				RealmServerMessage.Update,
				RealmServerMessage.TriggerCinematic,
			};
			// Also send MOTD, tutorialflags, spells, actions, factions,
			//      honour, bg status, timespeed, 
			return response;
		}

		
	}
}
