using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Field
{
	public partial struct FieldId
	{
		internal FieldId(uint RawId)
		{
			this.RawId = RawId;
		}

		public static implicit operator uint(FieldId val)
		{
			return val.RawId;
		}
		public static implicit operator int(FieldId val)
		{
			return (int)val.RawId;
		}

		public static implicit operator FieldId(ObjectBase val)
		{
			return new FieldId((uint)val);
		}

		[Flags]
		public enum Visibility
		{
			Noone = 0,
			Everyone = 1,
			Owner = 2,
			PetOwner = 4,
			ItemOwner = 16,
			PartyLeader = 32,
			PartyMember = 64,
			Dynamic = 256,
		}
	}
}
