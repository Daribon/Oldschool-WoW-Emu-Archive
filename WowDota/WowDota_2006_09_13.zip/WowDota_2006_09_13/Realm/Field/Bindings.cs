using System;
using System.Collections.Generic;
using System.Text;
using Realm.Object;
using Core.Data.Serialisation;
using System.Reflection;

namespace Realm.Field
{
	public partial class Bindings
	{
		class BoundField
		{
			public BoundField(FieldInfo field, FieldId.Visibility visibility)
			{
				this.ReflectedField = field;
				this.Visibility = visibility;
				BindingMethod = Core.Data.Serialisation.Binder.GetBindingMethod(field.FieldType);
				if (BindingMethod == null)
					throw new InvalidProgramException(string.Format("Can't find binding method for {0}", field));
			}
			public void Bind(Core.Data.Serialisation.Binder binder, object obj)
			{
				object field = ReflectedField.GetValue(obj);
				binder.CallBindingMethod(BindingMethod, field);
			}
			internal FieldId.Visibility Visibility;
			internal FieldInfo ReflectedField;
			internal MethodInfo BindingMethod;
		}

		/// <summary>
		/// Sparse array of field bindings for an object
		/// </summary>
		BoundField[] BoundFields;

		public Bindings(Type type, int num_fields)
		{
			BoundFields = new BoundField[num_fields];

			System.Reflection.FieldInfo[] class_fields = type.GetFields(
				BindingFlags.Instance | BindingFlags.Public | BindingFlags.NonPublic);

			foreach (FieldInfo class_field in class_fields)
			{
				SynchronizedFieldAttribute[] attributes = (SynchronizedFieldAttribute[])
					class_field.GetCustomAttributes(typeof(SynchronizedFieldAttribute), true);

				foreach (SynchronizedFieldAttribute attribute in attributes)
				{
					BoundFields[attribute.Field.RawId] = new BoundField(class_field, attribute.Visibility);
				}
			}
		}
	}
}
