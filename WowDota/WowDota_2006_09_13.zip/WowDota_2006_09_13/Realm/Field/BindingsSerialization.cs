using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Collections;
using Core.Data.Serialisation;

namespace Realm.Field
{
	public partial class Bindings
	{
		/// <summary>
		/// Read the next field from both streams and compare. Return true iff they differ.
		/// 
		/// Note that this has a side effect of advancing both streams by field_length_bytes bytes
		/// </summary>
		/// <param name="stream1"></param>
		/// <param name="stream2"></param>
		/// <returns></returns>
		private bool NextFieldDiffers(Stream stream1, Stream stream2, int field_length_bytes)
		{
			// hack achk hack
			if (stream2 == null)
			{
				stream2 = new MemoryStream(field_length_bytes);
				new Writer(stream2).BindZeros(field_length_bytes);
				stream2.Position = 0;
			}

			bool different = false;

			for (int b = 0; b < field_length_bytes; b++)
			{
				// Note that I'm reading all the bytes no matter what to keep position consistancy
				if (stream1.ReadByte() != stream2.ReadByte())
					different = true;
			}

			return different;
		}

		long SetBufferFromField(BoundField field, Binder binder, object obj)
		{
			binder.Position = 0;
			field.Bind(binder, obj);
			long field_length = binder.Position;
			binder.Position = 0;
			return field_length;
		}

		protected void BindDiffData(Core.Data.Serialisation.Binder binder,
			object obj, ref BitArray differing_fields, Stream reference)
		{
			MemoryStream buffer_stream = new MemoryStream();
			Writer buffer_binder = new Writer(buffer_stream);
			BoundField current_field = null;
			bool field_updated = false;
			long field_length = 0;

			for (int i = 0; i < BoundFields.Length; i++)
			{
				if (BoundFields[i] != null)
				{
					current_field = BoundFields[i];
					field_updated = false;
					field_length = SetBufferFromField(current_field, buffer_binder, obj);
				}

				if ((binder.IsReader && differing_fields[i])
					|| (binder.IsWriter 
							&& current_field != null
							&& NextFieldDiffers(buffer_stream, reference, sizeof(uint))))
				{
					field_updated = true;

					if (binder.IsWriter)
					{
						buffer_stream.Position -= sizeof(uint);
						differing_fields[i] = true;
					}

					// readers will read to the buffer first... there could be multiple changed
					// fields and we won't know until the end.

					// Writers will write the offending bytes from buffer_stream to the buffer.
					binder.BindStreamBytes(buffer_stream, sizeof(uint));
				}

				// We're at the end of the field
				if (current_field != null && buffer_stream.Position == field_length)
				{
					if (field_updated == true && binder.IsReader)
					{
						// _now_ we write the field back to the object.
						Reader reader = new Reader(buffer_stream);
						reader.Position = 0;
						current_field.Bind(reader, obj);
					}

					current_field = null;
				}
			}
		}

		public void BindDiff(Core.Data.Serialisation.Binder binder,
			object obj, Stream reference)
		{
			byte num_updated_field_ints = (byte)((BoundFields.Length + 31) / 32);
			binder.Bind(ref num_updated_field_ints);

			int[] updated_field_data = new int[num_updated_field_ints];

			BitArray updated_fields;
			
			// only relevant for writer
			long updated_fields_position = binder.Position;

			if (binder.IsReader)
			{
				binder.Bind(updated_field_data);
				updated_fields = new BitArray(updated_field_data);
			}
			else
			{
				binder.BindIgnoredBytes(num_updated_field_ints * sizeof(int));
				updated_fields = new BitArray(BoundFields.Length);
			}

			BindDiffData(binder, obj, ref updated_fields, reference);

			if (binder.IsWriter)
			{
				binder.PushPosition();
				binder.Position = updated_fields_position;

				updated_fields.CopyTo(updated_field_data, 0);
				binder.Bind(updated_field_data);

				binder.PopPosition();
			}
		}
	}
}
