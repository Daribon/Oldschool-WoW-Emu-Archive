using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Field
{
	/// <summary>
	/// When this attribute is applied to a field it will be considered for synchronisation.
	/// </summary>
	[AttributeUsage(AttributeTargets.Field, AllowMultiple = false)]
	class SynchronizedFieldAttribute : Attribute
	{
		public SynchronizedFieldAttribute(FieldId field)
		{
			this.Field = field;
		}

		#region FieldId constructors
		public SynchronizedFieldAttribute(FieldId.ObjectBase field)
			: this((FieldId)field)
		{ }

		public SynchronizedFieldAttribute(FieldId.Item field)
			: this((FieldId)field)
		{ }

		public SynchronizedFieldAttribute(FieldId.Container field)
			: this((FieldId)field)
		{ }

		public SynchronizedFieldAttribute(FieldId.Corpse field)
			: this((FieldId)field)
		{ }

		public SynchronizedFieldAttribute(FieldId.DynamicObject field)
			: this((FieldId)field)
		{ }

		public SynchronizedFieldAttribute(FieldId.GameObject field)
			: this((FieldId)field)
		{ }

		public SynchronizedFieldAttribute(FieldId.Unit field)
			: this((FieldId)field)
		{ }
		public SynchronizedFieldAttribute(FieldId.Player field)
			: this((FieldId)field)
		{ }
		#endregion

		public FieldId Field;
		public FieldId.Visibility Visibility;
	}
}
