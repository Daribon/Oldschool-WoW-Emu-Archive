using System;
using System.Collections.Generic;
using System.Text;
using Core.Data;
using System.Collections;
using Realm.Object;
using Core;
using Core.Data.Serialisation;
using Core.Scripting;
using Core.Scripting.ProcessPacket;
using Core.Scripting.ScriptObject;

namespace Realm
{
	[ScriptObject(typeof(Player)), Serializable]
	class FriendsList
	{
		ArrayList friends;

		[EventHandler(Event.Type.CharacterLogin)]
		static void TriggerFriendsList(Event e)
		{
			PacketManager.Singleton.CreatePacket(e.Session, RealmServerMessage.FriendList);
		}

		[PacketHandler(RealmServerMessage.FriendList)]
		MessageId[] Send(Session client, Binder binder)
		{
			if (friends == null)
				friends = new ArrayList();

			byte num = (byte)friends.Count;
			binder.Bind(ref num);

			if (binder.IsReader)
				friends = new ArrayList(num);

			if (friends.Count != 0)
			{
				// In 1.9 it was a list of {friend.guid, 0}
				throw new NotImplementedException();
			}

			return null;
		}
	}
}
