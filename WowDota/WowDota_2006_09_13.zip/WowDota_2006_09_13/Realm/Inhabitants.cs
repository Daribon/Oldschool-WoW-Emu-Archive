using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Realm.Object;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core.Data.Serialisation;
using Core;
using Core.Scripting;

namespace Realm
{
	/// <summary>
	/// Everything in the world
	/// </summary>
	[ScriptObject(typeof(Core.Data.Base)), Serializable]
	public class Inhabitants : Object.ObjectSet
	{
		public static Inhabitants Singleton
		{
			get
			{
				return Core.Data.Base.Singleton.ScriptScope.Get<Inhabitants>(true);
			}
		}
		
		[EventHandler(Event.Type.CharacterEnterWorld)]
		void TriggerUpdateCharacter(Event e)
		{
			PacketManager.Singleton.CreatePacket(e.Session, RealmServerMessage.CompressedUpdate);
		}

		[PacketHandler(RealmServerMessage.Update)]
		public new MessageId[] BindUpdate(Session session, Binder binder)
		{
			return base.BindUpdate(session, binder);
		}
		
		[PacketHandler(RealmServerMessage.CompressedUpdate)]
		public MessageId[] BindCompressedUpdate(Session session, Binder binder)
		{
			Binder compressed_binder = binder.BindCompressedDataStart();
			MessageId[] response = BindUpdate(session, compressed_binder);
			binder.BindCompressedDataEnd(compressed_binder);
			return response;
		}
	}
}
