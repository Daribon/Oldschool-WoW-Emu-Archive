using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core.Data;
using Core.Scripting.ProcessPacket;
using Core;
using Core.Data.Serialisation;
using Realm.Object;

namespace Realm
{
	[ScriptObject(typeof(Session))]
	class ActiveMover
	{
		GUID GUID;
		public Unit Mover;

		[PacketHandler(RealmClientMessage.SetActiveMover)]
		MessageId[] SetActiveMover(Session client, Binder binder)
		{
			binder.Bind(ref GUID);

			if (binder.IsReader)
				Mover = Inhabitants.Singleton.Get(GUID) as Object.Unit;

			return null;

		}
		/*
		[PacketHandler(RealmClientMessage.MoveStartForwards)]
		MessageId[] StartMoveForwards(Session client, Binder binder)
		{

			return null;
		}*/
	}
}
