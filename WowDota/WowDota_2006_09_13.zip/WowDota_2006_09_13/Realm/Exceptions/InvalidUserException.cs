using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Exceptions
{
	internal class InvalidUserException : BaseRealmException
	{
		public InvalidUserException(string username)
			: base(string.Format("Invalid user {0}", username))
		{
		}
	}
}
