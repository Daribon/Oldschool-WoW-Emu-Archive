using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Exceptions
{
	class BaseRealmException : Core.Scripting.ProcessPacket.PacketParseException
	{	
		public BaseRealmException(string message)
			: base(message)
		{
		}

		public BaseRealmException(string message, Exception innerexception)
			: base(message, innerexception)
		{
		}
	}
}
