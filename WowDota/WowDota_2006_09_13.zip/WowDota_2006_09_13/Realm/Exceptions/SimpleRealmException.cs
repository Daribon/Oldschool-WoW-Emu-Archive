using System;
using System.Collections.Generic;
using System.Text;
using Core.Data;
using Core.Networking.Packet;
using Core;

namespace Realm.Exceptions
{
	class SimpleRealmException : BaseRealmException
	{
		private SimpleRealmException(MessageId message, RealmErrorCode errorcode)
			: base(string.Format("{0} {1}", message, errorcode))
		{
			this.id = message;
			this.errorcode = errorcode;
		}

		public SimpleRealmException(RealmClientMessage message, RealmErrorCode errorcode)
			: this((MessageId)message, errorcode)
		{ }

		public SimpleRealmException(RealmServerMessage message, RealmErrorCode errorcode)
			: this((MessageId)message, errorcode)
		{ }

		MessageId id;
		RealmErrorCode errorcode;

		public override void Dispatch(Session connection)
		{
			DataPacket packet = DataPacket.Make(id);
			packet.Writer.Write((byte)errorcode);
			connection.Endpoint.Send(packet);
		}
	}
}
