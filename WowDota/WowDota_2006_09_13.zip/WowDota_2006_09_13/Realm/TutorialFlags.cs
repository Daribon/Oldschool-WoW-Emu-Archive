using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core.Scripting.ProcessPacket;
using Core.Data.Serialisation;
using Core.Data;
using Core;
using Core.Scripting;

namespace Realm
{
	[ScriptObject(typeof(User)), Serializable]
	class TutorialFlags
	{
		public TutorialFlags()
		{
			Flags = new byte[0x20];

			for (int i = 0; i < Flags.Length; i++)
			{
				// They've all been read. (please believe me...)
				Flags[i] = 0xff;
			}
		}

		byte[] Flags;

		[EventHandler(Event.Type.CharacterLogin)]
		static void TriggerTutorialflags(Event e)
		{
			PacketManager.Singleton.CreatePacket(e.Session, RealmServerMessage.TutorialFlags);
		}

		[PacketHandler(RealmServerMessage.TutorialFlags)]
		MessageId[] LearnToPlayNub(Session client, Binder binder)
		{
			binder.Bind(Flags);

			return null;
		}
	}
}
