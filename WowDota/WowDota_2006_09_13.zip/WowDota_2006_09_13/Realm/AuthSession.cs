using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

using Core;
using Core.Data;
using Core.Scripting.ProcessPacket;
using Core.Data.Serialisation;
using Core.Networking;
using Core.Scripting.ScriptObject;

using Realm.Exceptions;
using Core.Scripting;

// This should be refactored to use script objects.

namespace Realm
{
	[ScriptObject(typeof(Session))]
	class AuthSession
	{
		byte[] ClientSeed;
		byte[] ServerSeed;
		
		byte[] MakeSeed()
		{
			byte[] seed = new byte[4];
			System.Security.Cryptography.RandomNumberGenerator.Create().GetBytes(seed);
			return seed;
		}

		void InitialiseCryptoSeeds(Origin remote_origin)
		{
			if (remote_origin == Origin.Client)
			{
				ClientSeed = new byte[4];
				ServerSeed = MakeSeed();
			}
			else
			{
				ClientSeed = MakeSeed();
				ServerSeed = new byte[4];
			}
		}

		[EventHandler(Event.Type.ClientConnected)]
		static void StartRealmAuthentication(Event the_event)
		{
			Session session = the_event.Session;
			if (session.Endpoint.RemotePacketType.Service != Service.Realm)
				return;

			if (PacketManager.Singleton.CreatePacket(session, RealmServerMessage.AuthSeed) == false)
				throw new InvalidOperationException(string.Format("Could not start authentication with {0}", session));
		}
		
		[PacketHandler(RealmServerMessage.AuthSeed, EncryptPacketHeader = false)]
		MessageId[] AuthSeedPacket(Session session, Binder binder)
		{
			if (session.Endpoint is EncryptedEndPoint == false)
				throw new ArgumentException("Client isn't an encrypted endpoint as expected");

			InitialiseCryptoSeeds(session.Endpoint.RemotePacketType.Origin);

			binder.Bind(ServerSeed);

			MessageId[] response = { Core.Data.RealmClientMessage.AuthSession };
			return response;
		}

		[PacketHandler(RealmClientMessage.AuthSession, EncryptPacketHeader = false)]
		MessageId[] AuthSessionPacket(Session session, Binder binder)
		{
			if (session.Endpoint is EncryptedEndPoint == false)
				throw new ArgumentException("Client isn't an encrypted endpoint as expected");

			ushort build = Core.Data.Client.Version.ExpectedClientVersion.Build;
			binder.Bind(ref build);

			if (binder.IsReader && (build != Core.Data.Client.Version.ExpectedClientVersion.Build))
				throw new BaseRealmException("Client version mismatch");

			// These probably should be zeros...
			binder.BindIgnoredBytes(6);

			string username = "";
			if (binder.IsWriter)
				username = session.User.Name;
			binder.BindCStr(ref username);

			if (binder.IsReader)
			{
				session.User = Core.Data.Base.Singleton.GetUser(username);

				// Interestingly, this error message doesn't work unless encryption is on.
				// ... and if I don't know the user I can't work out what their session key is
				// so I can't send a valid error message back.

				// Of course, in reality, if the user has entered an incorrect username it should
				// be caught at login, but yeah... sadness.
				if (session.User == null)
					throw new SimpleRealmException(RealmServerMessage.AuthResponse,
						RealmErrorCode.UnknownAccount);
			}
			
			binder.Bind(ClientSeed);

			// Everything after this point including error messages is encrypted.
			session.UseEncryption = true;

			try
			{
				session.User.CurrentAuthenticatorBinding.BindRealmSession(binder, ServerSeed, ClientSeed);
			}
			catch (Cryptography.InvalidProofException)
			{
				throw new SimpleRealmException(RealmServerMessage.AuthResponse,
						RealmErrorCode.AuthFailed);
			}
			
			Binder addon_data_binder = binder.BindCompressedDataStart();

			// I'm not going to use the standard handler because I want the response to
			// follow the AuthResponse.
			MessageId[] addon_response;
			PacketManager.Singleton.HandlePacketBinder(
				session,
				RealmClientMessage.InternalAddonListRequest,
				addon_data_binder,
				out addon_response);

			binder.BindCompressedDataEnd(addon_data_binder);
			
			MessageId[] response = new MessageId[1 + addon_response.Length];
			response[0] = Core.Data.RealmServerMessage.AuthResponse;
			addon_response.CopyTo(response, 1);
			
			return response;
		}

		[PacketHandler(RealmServerMessage.AuthResponse, EncryptPacketHeader = true)]
		public static MessageId[] AuthResponsePacket(Session client, Binder binder)
		{
			byte errorcode = (byte)RealmErrorCode.AuthOk;
			binder.Bind(ref errorcode);
			if (errorcode != (byte)RealmErrorCode.AuthOk)
				throw new SimpleRealmException(RealmServerMessage.AuthResponse,
						(RealmErrorCode)errorcode);

			// The official server sends a more data at this point. I can't think of anything
			// sensible which that data could represent, except maybe server build information
			// using 1.12.0              I got:      48 4c 9e fa 02 00 00 00 00
			// Using 1.11.2              I got:      80 de 28 00 02 00 00 00 00 
			// and mangos developed for 1.10.2 sends b0 09 02 00 02 00 00 00 00

			byte[] unknown_data = { 0x48, 0x4c, 0x9e, 0xfa, 0x02 };
			binder.Bind(unknown_data);
			binder.BindZeros(4);

			MessageId[] response = { Core.Data.RealmClientMessage.CharacterListRequest };
			return response;
		}
	}
}
