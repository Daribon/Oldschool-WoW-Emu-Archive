using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;

namespace Realm
{
	[ScriptObject(typeof(Core.Data.Base)), Serializable]
	public class GUIDGenerator
	{
		private ulong Upto = 7; //0x0d007bc9L;

		internal GUID GetNewLocal()
		{
			return new GUID(Upto++);
		}

		public static GUID GetNew()
		{
			return Singleton.GetNewLocal();
		}

		internal static GUIDGenerator Singleton
		{
			get
			{
				return Core.Data.Base.Singleton.ScriptScope.Get<GUIDGenerator>(true);
			}
		}
	}
}
