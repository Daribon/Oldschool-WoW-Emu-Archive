using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;
using Core.Data.Serialisation;
using Core.Scripting.ScriptObject;
using Core.Data;
using Core;

namespace Realm
{
	/// <summary>
	/// A ping is sent from the client every 30 seconds
	/// </summary>
	[ScriptObject(typeof(Session)), Serializable]
	class PingPong
	{
		public uint Id = 0x1234;

		[PacketHandler(RealmClientMessage.Ping)]
		public MessageId[] Ping(Session client, Binder binder)
		{
			binder.Bind(ref Id);

			// I think this is the ping time or something... not entirely sure.
			uint unknown = 0;
			binder.Bind(ref unknown);
			//Console.WriteLine("ping unknown = {0}", unknown);

			MessageId[] response = { RealmServerMessage.Pong };
			return response;
		}

		[PacketHandler(RealmServerMessage.Pong)]
		public MessageId[] Pong(Session client, Binder binder)
		{
			binder.Bind(ref Id);

			MessageId[] response = { };
			return response;
		}
	}
}
