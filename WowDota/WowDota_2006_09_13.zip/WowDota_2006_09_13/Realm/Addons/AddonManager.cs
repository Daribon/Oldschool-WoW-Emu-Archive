using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Addons
{
	class AddonManager
	{
		internal static bool AddonAllowed(Addon addon)
		{
			if (addon.IsOfficial)
				return true;
			else
			{
				// Official addon SOMETHING.
				// work out what this is sometime, k? :)
				if (addon.Checksum == 0xD968558)
					return true;

				Console.WriteLine("Unknown addon {0}", addon);
				return false;
			}
		}
	}
}
