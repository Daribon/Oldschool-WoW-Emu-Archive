using System;
using System.Collections.Generic;
using Core.Data.Serialisation;

namespace Realm.Addons
{
	class Addon : IBindable
	{
		public void Bind(Binder binder)
		{
			binder.BindCStr(ref Name);

			byte source = (byte)SourceValue;
			binder.Bind(ref source);
			SourceValue = (Source)source;

			binder.Bind(ref Checksum);
			binder.BindZeros(4);
		}

		public void BindAllowed(Binder binder)
		{
			byte[] data = { 2, 1, 1, 0, 0, 0, 0, 0 };
			binder.Bind(data);
			/*
			byte flag1;

			// I guessed this. Please check against proper packet dumps!

			if (IsOfficial && SourceValue == Source.AddonsDirectory)
				flag1 = 2;
			else
				flag1 = 0;

			binder.Bind(ref flag1);

			if (binder.IsWriter)
			{
				Allowed = AddonManager.AddonAllowed(this);
			}

			binder.Bind(ref Allowed);

			// ??
			binder.BindZeros(6);*/
		}

//		bool Allowed = true;

		enum Source : ushort
		{
			Internal,
			AddonsDirectory
		}

		Source SourceValue;
		string Name;
		internal uint Checksum;

		public const uint ChecksumOfficial = 0x4c1c776d;

		public bool IsOfficial
		{
			get
			{
				return SourceValue == Source.Internal
					|| Checksum == ChecksumOfficial;
			}
			set
			{
				if (value == true)
					Checksum = ChecksumOfficial;
				else
					Checksum = 0;
			}
		}

		public override string ToString()
		{
			return string.Format("{0} checksum:{1}", Name, Checksum);
		}
	}
}
