using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core.Data.Serialisation;
using Core.Data;
using Core;
using Core.Scripting.ProcessPacket;
using System.IO;

namespace Realm.Addons
{
	[ScriptObject(typeof(Session))]
	class AddonList
	{
		// This guy is a compressed packet inside AuthSession.
		[PacketHandler(RealmClientMessage.InternalAddonListRequest)]
		public MessageId[] AddonRequest(Session client, Binder binder)
		{
			if (binder.IsReader)
			{
				addons = new List<Addon>();
				while (binder.ExpectedBytesLeft > 0)
				{
					Addon new_addon = new Addon();
					new_addon.Bind(binder);
					addons.Add(new_addon);
				}
			}
			else
			{
				throw new NotImplementedException();
			}

			MessageId[] response = { RealmServerMessage.AddonInfo };
			return response;
		}

		[PacketHandler(RealmServerMessage.AddonInfo)]
		public MessageId[] AddonResponse(Session client, Binder binder)
		{
			foreach (Addon addon in addons)
			{
				addon.BindAllowed(binder);
			}

			return null;
		}

		List<Addon> addons;
	}
}
