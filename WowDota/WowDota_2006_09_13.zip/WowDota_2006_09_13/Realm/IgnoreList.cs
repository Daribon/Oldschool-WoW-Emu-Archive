using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;
using System.Collections;
using Core.Scripting;

namespace Realm
{
	[ScriptObject(typeof(Realm.Object.Player)), Serializable]
	class IgnoreList
	{
		ArrayList ignored;

		[EventHandler(Event.Type.CharacterLogin)]
		static void TriggerSendIgnoreList(Event e)
		{
			PacketManager.Singleton.CreatePacket(e.Session, RealmServerMessage.IgnoreList);
		}

		[PacketHandler(RealmServerMessage.IgnoreList)]
		MessageId[] Send(Session client, Binder binder)
		{
			if (ignored == null)
				ignored = new ArrayList();

			byte num = (byte)ignored.Count;
			binder.Bind(ref num);

			if (binder.IsReader)
				ignored = new ArrayList(num);

			if (ignored.Count != 0)
			{
				throw new NotImplementedException();
			}

			return null;
		}
	}
}
