using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core.Data;
using Core.Data.Serialisation;
using Core;
using Core.Scripting.ProcessPacket;
using Core.Scripting;

// This is in absolute shambles.
// 40% of it is probably 90% right, but thats not altogether useful.

namespace Realm
{
	class Time
	{
		public Time()
		{
		}

		public Time(DateTime dt)
		{
			DateTime = dt;
		}

		public Time(long ticks)
		{
			DateTime = new DateTime(ticks);
		}

		public DateTime DateTime;

		public override string ToString()
		{
			return DateTime.ToString();
		}

		public static Time LocalTimeNow
		{
			get
			{
				return new Time(DateTime.Now);
			}
		}

		public static Time TimeOffset = new Time(new DateTime(0L));

		public static Time GameTimeNow
		{
			get
			{
				return new Time(DateTime.Now.Ticks + TimeOffset.DateTime.Ticks);
			}
			set
			{
				TimeOffset = new Time(value.DateTime.Ticks - DateTime.Now.Ticks);
			}
		}

		public static float ClockSpeed = 1f / 60f;


		[EventHandler(Event.Type.CharacterLogin)]
		static void TriggerAccountDataUpdate(Event e)
		{
			PacketManager.Singleton.CreatePacket(e.Session, RealmServerMessage.SetInitialTimeSpeed);
		}

		[PacketHandler(RealmServerMessage.SetInitialTimeSpeed)]
		static MessageId[] SetInitialTimeSpeed(Session session, Binder binder)
		{
			Time gametime = GameTimeNow;

			gametime.BindTimestamp(binder);

			if (binder.IsReader)
				GameTimeNow = gametime;

			binder.Bind(ref ClockSpeed);

			return null;
		}

		public void BindTimestamp(Binder binder)
		{
			// This is a standard timestamp
			if (binder.IsWriter)
			{
				// Courtesy of WoWDaemon.
				uint data = 0;
				
				// 4 bytes of packed time data.  the bits are:
				// high 2 bits - unknown
				data |= (uint)0;
				// next 5 bits - year
				data <<= 5;
				data |= (uint)(DateTime.Year - 2003) & 0x1f;
				// next 4 bits - month
				data <<= 4;
				data |= (uint)DateTime.Month & 0xf;
				// next 7 bits - day of month
				data <<= 7;
				data |= (uint)DateTime.Day & 0x7f;
				// next 3 bits - day of week
				data <<= 3;
				data |= (uint)DateTime.DayOfWeek & 0x7;
				// next 5 bits - hours
				data <<= 5;
				data |= (uint)(DateTime.Hour & 0x1f);
				// low 6 bits  - minutes
				data <<= 6;
				data |= (uint)(DateTime.Minute & 0x3f);

				binder.Bind(ref data);
			}
			else
				throw new NotImplementedException();
		}

		public void BindTicks(Binder binder)
		{
			uint ticks = (uint)DateTime.Ticks;
			binder.Bind(ref ticks);
		}
		
		[PacketHandler(RealmClientMessage.QueryTime)]
		static MessageId[] WhatsTheTimeMisterWolf(Session client, Binder binder)
		{
			// This packet also has some other data sometimes.. no idea what it is :(
			MessageId[] response = { RealmServerMessage.QueryTimeResponse };
			return response;
		}

		[PacketHandler(RealmServerMessage.QueryTimeResponse)]
		static MessageId[] RocketClock(Session session, Binder binder)
		{
			//			throw new NotImplementedException();
			// This may or may not be correct.
			Time.LocalTimeNow.BindTicks(binder);

			if (binder.IsReader)
				throw new NotImplementedException();

			MessageId[] response = { };
			return response;
		}

		[PacketHandler(RealmClientMessage.MoveTimeSkipped)]
		static MessageId[] Lag(Session session, Binder binder)
		{
			if (binder.IsWriter)
				throw new NotImplementedException();

			GUID guid = new GUID();
			binder.Bind(ref guid);

			uint lag = 0;
			binder.Bind(ref lag);

			Logger.Log(Logger.Priority.Medium, "Client lagged by {0}", lag);

			MessageId[] response = { };
			return response;
		}

	}
}
