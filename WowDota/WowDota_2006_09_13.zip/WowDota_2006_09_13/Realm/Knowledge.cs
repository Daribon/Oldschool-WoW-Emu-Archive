using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;
using Core;
using System.IO;

namespace Realm
{
	/// <summary>
	/// What does a player know about the world?
	/// </summary>
	[ScriptObject(typeof(Session))]
	class Knowledge
	{
		// This is a very unintuitive way to do this but it makes a lot of sense for the server.
		// I'm unconvinced its the correct approach, but if nothing else at least its efficient.

		/// <summary>
		/// This stores a buffer for each thing the client knows about.
		/// </summary>
		Dictionary<GUID, MemoryStream> buffers;

	}
}
