using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;
using Core.Scripting.ScriptObject;

namespace Realm
{
	[ScriptObject(typeof(Session))]
	class UpdateData
	{
		//uint num_blocks = 0;
		/*
		[PacketHandler(RealmServerMessage.CompressedUpdate)]
		MessageId[] CompressedUpdate(Session client, Binder binder)
		{
			// This may or may not be correct.
			Binder data = binder.BindCompressedDataStart();
			MessageId[] response = Update(client, data);
			binder.BindCompressedDataEnd(data);

			return response;
		}*/
		/*
		[PacketHandler(RealmServerMessage.Update)]
		MessageId[] Update(Session client, Binder binder)
		{
			binder.Bind(ref num_blocks);
			binder.BindZeros(1);

			return null;
		}*/
	}
}
