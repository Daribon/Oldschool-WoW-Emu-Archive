using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;
using Realm.Exceptions;
using Realm.Object;

namespace Realm
{
	partial class CharacterList
	{
		[PacketHandler(RealmClientMessage.CharacterCreate)]
		public MessageId[] Create(Session client, Binder binder)
		{
			if (binder.IsReader)
			{
				Player new_character = new Player();
				new_character.BindCreate(binder);

				Player c = GetCharacter(new_character.Name);
				if (c != null)
					throw new SimpleRealmException(RealmServerMessage.CharacterCreate,
						RealmErrorCode.CharacterCreateNameInUse);

				Characters.Add(new_character);
			}

			MessageId[] response = { RealmServerMessage.CharacterCreate };
			return response;
		}

		[PacketHandler(RealmServerMessage.CharacterCreate)]
		public MessageId[] CreateConfirm(Session client, Binder binder)
		{
			byte errorcode = (byte)RealmErrorCode.CharacterCreateOk;
			binder.Bind(ref errorcode);
			if (errorcode != (byte)RealmErrorCode.CharacterCreateOk)
				throw new SimpleRealmException(RealmServerMessage.CharacterCreate,
						(RealmErrorCode)errorcode);

			MessageId[] response = { };
			return response;
		}
	}
}
