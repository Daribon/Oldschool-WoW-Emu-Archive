using System;
using System.Collections.Generic;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core;
using Core.Data.Serialisation;
using Realm.Exceptions;
using Realm.Object;

namespace Realm
{
	partial class CharacterList
	{
		[PacketHandler(RealmClientMessage.CharacterDelete)]
		public MessageId[] Delete(Session client, Binder binder)
		{
			if (binder.IsReader)
			{
				GUID deleted_guid = new GUID();
				binder.Bind(ref deleted_guid);
				Player deleted_character = GetCharacter(deleted_guid);
				if (deleted_character == null)
				{
					throw new SimpleRealmException(RealmServerMessage.CharacterDelete,
							RealmErrorCode.CharacterDeleteFailed);
				}
				else
				{
					// I am _so_ lazy.
					Characters.Remove(deleted_character);
				}
			}

			MessageId[] response = { RealmServerMessage.CharacterDelete };
			return response;
		}

		[PacketHandler(RealmServerMessage.CharacterDelete)]
		public MessageId[] DeleteConfirm(Session client, Binder binder)
		{
			byte errorcode = (byte)RealmErrorCode.CharacterDeleteOk;
			binder.Bind(ref errorcode);
			if (errorcode != (byte)RealmErrorCode.CharacterDeleteOk)
				throw new SimpleRealmException(RealmServerMessage.CharacterDelete,
					(RealmErrorCode)errorcode);

			MessageId[] response = { };
			return response;
		}
	}
}
