using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Collections;

using Core;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core.Data.Serialisation;
using Core.Scripting.ScriptObject;

using Realm.Exceptions;
using Realm.Object;

namespace Realm
{
	[ScriptObject(typeof(User)), Serializable]
	partial class CharacterList
	{
		[PacketHandler(RealmClientMessage.CharacterListRequest)]
		MessageId[] Request(Session client, Binder binder)
		{
			MessageId[] response = { RealmServerMessage.CharacterList };
			return response;
		}

		[PacketHandler(RealmServerMessage.CharacterList)]
		MessageId[] List(Session client, Binder binder)
		{
			if (binder.IsReader)
			{
				int num_characters = 0;
				binder.Bind(ref num_characters);
			}
			else
			{
				byte num_characters = (byte)Characters.Count;
				binder.Bind(ref num_characters);
				foreach (object character_o in Characters)
				{
					Player character = (Player)character_o;
					binder.Bind(character);
				}
			}

			MessageId[] response = { };
			return response;
		}

		public ArrayList Characters = new ArrayList();

		// These both should at least optionally be done globally.
		// They can also both be sped up a lot ;)

		public Player GetCharacter(GUID id)
		{
			foreach (object character_o in Characters)
			{
				Player character = (Player)character_o;
				if (character.Guid.Equals(id))
					return character;
			}
			return null;
		}
		public Player GetCharacter(string name)
		{
			foreach (object character_o in Characters)
			{
				Player character = (Player)character_o;
				if (character.Name == name)
					return character;
			}
			return null;
		}

		[OnDeserialized]
		private void InitCharacters(StreamingContext context)
		{
			if (Characters == null)
				Characters = new ArrayList();
		}
	}
}
