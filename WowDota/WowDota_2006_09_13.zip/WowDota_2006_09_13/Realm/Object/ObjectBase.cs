using System;
using System.Collections.Generic;
using System.Text;
using Realm.Field;

namespace Realm.Object
{
	[Serializable]
	public partial class ObjectBase
	{
		protected virtual void SetDefaultFields()
		{
			Type = ObjectTypeFlag(ObjectType.ObjectBase);
			ScaleX = 1.0f;	// taurens start at 1.35
		}
	}
}
