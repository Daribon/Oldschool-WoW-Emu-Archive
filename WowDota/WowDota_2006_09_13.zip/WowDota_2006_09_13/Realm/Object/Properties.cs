using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Object
{
	public enum Race : byte
	{
		// I didn't make this order up.
		Human = 1,
		Orc,
		Dwarf,
		NightElf,
		Undead,
		Tauren,
		Gnome,
		Troll
	}

	public enum Faction : byte
	{
		Horde,
		Alliance
	}

	public enum Class : byte
	{
		Warrior = 1,
	}

	public enum Gender : byte
	{
		Male = 0,
		Female = 1,
	}

	abstract public class Properties
	{
		public static Faction GetFaction(Race race)
		{
			switch (race)
			{
				case Race.Human:
				case Race.Dwarf:
				case Race.NightElf:
				case Race.Gnome:
					return Faction.Alliance;

				case Race.Orc:
				case Race.Undead:
				case Race.Tauren:
				case Race.Troll:
					return Faction.Horde;

				default:
					throw new ArgumentException(string.Format("Invalid race {0}", race));
			}
		}
	}
}
