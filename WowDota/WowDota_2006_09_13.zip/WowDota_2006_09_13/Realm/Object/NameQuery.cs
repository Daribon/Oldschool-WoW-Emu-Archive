using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;
using Core.Data;
using Core.Scripting.ScriptObject;
using Core.Data.Serialisation;
using Core;

namespace Realm.Object
{
	[ScriptObject(typeof(Core.Networking.Packet.DataPacket))]
	class NameQuery
	{
		public NameQuery()
		{ }

		public NameQuery(GUID guid)
		{
			this.GUID = guid;
		}
		
		GUID GUID = new GUID();
		
		[PacketHandler(RealmClientMessage.NameQuery)]
		public MessageId[] Query(Session connection, Binder binder)
		{
			binder.Bind(ref GUID);

			MessageId[] response = { RealmServerMessage.NameQueryResponse };
			return response;
		}


		[PacketHandler(RealmServerMessage.NameQueryResponse)]
		public MessageId[] Response(Session connection, Binder binder)
		{
			if (GUID.IsSet == false)
				throw new InvalidOperationException("Guid hasn't been set...");

			Player character;
			if (binder.IsWriter)
			{
				ObjectBase the_object = Inhabitants.Singleton.Get(GUID);

				character = the_object as Player;
				if (character == null)
					throw new Exceptions.BaseRealmException(string.Format("Guid {0} isn't a character!", GUID));
			}
			else
				throw new NotImplementedException();

			character.BindNameQuery(binder);

			return null;
		}
	}
}
