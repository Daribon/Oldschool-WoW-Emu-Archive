using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;
using Core.Data;
using Core;
using Core.Scripting.ScriptObject;
using Core.Data.Map;
using Core.Scripting.ProcessPacket;
using Realm.Object;
using Realm.Field;
using Core.Scripting;

namespace Realm.Object
{
	public partial class Player : Unit, IBindable, IScope
	{
		public Player()
		{
			//Fields = new FieldSet(FieldId.Player._Count);
			SetDefaultFields();
		}

		public string Name = "Pwnerer";

		public Faction Faction { get { return Properties.GetFaction(Race); } }

		public WorldLocation Location = WorldLocation.Unknown;
//		public Guild Guild = Guild.None;

		public void BindLook(Binder binder)
		{
			binder.Bind(PlayerBytes);
			binder.Bind(ref PlayerBytes2[0]);
		}

		public Pet Pet = Pet.None;

//		public Item[] EquippedItems = new Item[20];

		// This is used for character creation
		public void BindCreate(Binder binder)
		{
			binder.BindCStr(ref Name);

			byte race = (byte)Race;
			binder.Bind(ref race);
			Race = (Race)race;

//			binder.Bind(ref Class);
			byte player_class = (byte)Class;
			binder.Bind(ref player_class);
			Class = (Class)player_class;

			byte gender = (byte)Gender;
			binder.Bind(ref gender);
			Gender = (Gender)gender;

			BindLook(binder);
//			binder.Bind(Look);

			byte OutfitId = 0x00;
			binder.Bind(ref OutfitId);

			if (binder.IsReader)
			{
				Inhabitants.Singleton.Add(this);
			}
		}

		protected override void SetDefaultFields()
		{
			base.SetDefaultFields();
			Type |= (uint)ObjectTypeFlag(ObjectType.Player);

//			Bytes = 0x50001;
//			Bytes2 = 0x101ee00;
//			Bytes3 = 0x7000000;
			GuildTimestamp = 0xeeeeeeee;

			ComboTarget = new GUID(0xeeeeeeeeeeeeeeeeL);

			Xp = 0;
			XpNextLevel = 7;
			
			BlockPercentage = 5f;
			DodgePercentage = 5f;
			ParryPercentage = 5f;
			CritPercentage = 10f;
			RangedCritPercentage = 0f;

			// explored zones in here

//			RestStateExperience = 0;
//			Coinage = 0;

			for (int i = 0; i < 7; i++) // 7 damage types
			{
				ModDamageDonePct[i] = 1f;
			}

//			MoreBytes = 0x70f0008; // >?
//			MoreBytes2 = 0xeeeeee15; // >?

//			WatchedFactionIndex = 0x34;

			Level = 0;
		}

		public void Bind(Binder binder)
		{
			binder.Bind(ref Guid);
			binder.BindCStr(ref Name);

			byte race = (byte)Race;
			binder.Bind(ref race);
			Race = (Race)race;

			byte player_class = (byte)Class;
			binder.Bind(ref player_class);
			Class = (Class)player_class;

			byte gender = (byte)Gender;
			binder.Bind(ref gender);
			Gender = (Gender)gender;

			BindLook(binder);
//			binder.Bind(Look);

			byte level_temp = (byte)Level;
			binder.Bind(ref level_temp);
			Level = level_temp;

			Location.BindZoneContinentPosition(binder);

			binder.Bind(ref GuildID);

			// 0x02020000 for Jai
			byte[] unknown1 = { 0x00, 0x00, 0x00, 0x00 };
			binder.Bind(unknown1);

			byte unknown2 = 0x01;
			binder.Bind(ref unknown2);

			if (Pet == null)
				Pet = Pet.None;
			binder.Bind(Pet);
			/*
			if (EquippedItems == null)
				EquippedItems = new Item[20];
			for (int i = 0; i < EquippedItems.Length; i++)
			{
				if (EquippedItems[i] == null)
				{
					binder.BindZeros(5);
				}
				else
				{
					binder.Bind(EquippedItems[i]);
				}
			}*/

			// These are the equipped items. I'll skip them until I find a nice way to do this
			for (int i = 0; i < 20; i++)
				binder.BindIgnoredBytes(5);
		}

		public void BindNameQuery(Binder binder)
		{
			binder.Bind(ref Guid);

			binder.BindCStr(ref Name);

			byte race = (byte)Race;
			binder.Bind(ref race);
			Race = (Race)race;

			byte gender = (byte)Gender;
			binder.Bind(ref gender);
			Gender = (Gender)gender;

			byte player_class = (byte)Class;
			binder.Bind(ref player_class);
			Class = (Class)player_class;
		}

		public static Player GetActiveCharacter(Session client)
		{
			return client.User.ScriptScope.Get<Player>();
		}

		internal void EnterWorld(Session client)
		{
			Logger.Log(this, Logger.Priority.Medium, "Entering world");
			if (Level == 0)
			{
				// Where am I?
				Location.Continent = Continent.Kalimdor;
				Location.Zone = new Zone(0x665);
				Location.Position = new Vector(1630.700317f, -4373.235352f, 31.122364f);

				Level = 1;
			}
		}
		
		[EventHandler(Event.Type.CharacterEnterWorld)]
		static void TriggerEnterWorld(Event e)
		{
			PacketManager.Singleton.CreatePacket(e.Session, RealmServerMessage.BindPointUpdate);
		}

		[PacketHandler(RealmServerMessage.BindPointUpdate)]
		static MessageId[] PlaceCharacter(Session client, Binder binder)
		{
			Player character = GetActiveCharacter(client);
			character.Location.BindPositionContinentZone(binder);

			return null;
		}
		
		protected override void BindMovementUpdate(Binder binder, UpdateType update_type)
		{
			byte flag1 = 0;
			uint flag2 = 0;

			switch (update_type)
			{
				case UpdateType.Create:
					flag1 = 0x70;
					flag2 = 0x0;
					break;
				case UpdateType.CreateSelf:
					flag1 = 0x71;
					flag2 = 0x2000;
					break;
				default:
					throw new NotImplementedException();
			}

			binder.Bind(ref flag1);

			binder.Bind(ref flag2);
			uint unk = 0x7690a96a;// 0x6aa99076;
			binder.Bind(ref unk);
			float zero = 0.0f;
			binder.Bind(ref Location.Position);
			binder.Bind(ref zero); // orientation
			binder.Bind(ref zero); // unknown (head orientation?)

			if (update_type == UpdateType.CreateSelf)
			{
				float one = 1.0f;

				binder.Bind(ref zero);
				binder.Bind(ref one);	// I'm curious what this is about too.
				binder.Bind(ref zero);	// its certainly not always these numbers.
				binder.Bind(ref zero);

			}

			binder.Bind(ref Speed);
		}

		public static Player GetActiveCharacter(User user)
		{
			return user.ScriptScope.Get<Player>();
		}
		
		ScriptScope scriptScope = new ScriptScope();
		public ScriptScope ScriptScope { get { return scriptScope; } }

		static Player ResolveScope(Session client)
		{
			return GetActiveCharacter(client.User);
		}

		public override string ToString()
		{
			return string.Format("Character {0} Guid:{1}", Name, Guid);
		}

		#region field accessors
		public static FieldId.Player QuestLog(int num)
		{
			return (FieldId.Player)((int)FieldId.Player.QuestLog1_1 + num);
		}

		#region Visible Items
		public enum VisibleItemSlot
		{
			// There are 19 others... can you identify them all?

			Head = 19,
		}

		public const int VisibleItemPadding = 12;
		public static FieldId.Player VisibleItemCreator(VisibleItemSlot slot)
		{
			return (FieldId.Player)((int)FieldId.Player.VisibleItem1Creator + ((int)slot * VisibleItemPadding));
		}
		public static FieldId.Player VisibleItemId(VisibleItemSlot slot)
		{
			return (FieldId.Player)((int)FieldId.Player.VisibleItem1_0 + ((int)slot * VisibleItemPadding));
		}
		public static FieldId.Player VisibleItemProperties(VisibleItemSlot slot)
		{
			return (FieldId.Player)((int)FieldId.Player.VisibleItem1Properties + ((int)slot * VisibleItemPadding));
		}
		#endregion

		public static FieldId.Player PackSlot(int num)
		{
			return (FieldId.Player)((int)FieldId.Player.PackSlot1 + num * 2);
		}

		#endregion
	}
}
