using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

using Core.Scripting.ScriptObject;
using Core.Data.Serialisation;
using Core.Scripting.ProcessPacket;
using System.IO;
using Core.Data;
using Core;

namespace Realm.Object
{
	[Serializable]
	public class ObjectSet
	{
		Hashtable objects = new Hashtable();

		public ObjectBase Get(GUID GUID)
		{
			return (ObjectBase)objects[GUID];
		}

		public void Add(ObjectBase value)
		{
			if (value.Guid.IsSet == false)
				value.Guid = GUIDGenerator.GetNew();

			objects[value.Guid] = value;
		}

		public MessageId[] BindUpdate(Session session, Binder binder)
		{
			// For now i'm going to send everything.
			
			if (binder.IsReader)
				throw new NotImplementedException("This shouldn't be hard to implement, but i haven't done it yet");

//			int num_blocks = 0;//objects.Count;
//			binder.Bind(ref num_blocks);
//			binder.BindZeros(1);

			int num_blocks = 1;//objects.Count;
			binder.Bind(ref num_blocks);
			binder.BindZeros(1);

			object oobj = Player.GetActiveCharacter(session);
//			foreach (object oobj in objects.Values)
			{
				ObjectBase obj = (ObjectBase)oobj;

				obj.BindUpdate(session, binder);
			}
	
			return null;
		}
	}
}
