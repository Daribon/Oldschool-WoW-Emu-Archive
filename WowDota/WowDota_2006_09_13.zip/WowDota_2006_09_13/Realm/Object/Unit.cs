using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;
using Realm.Field;

namespace Realm.Object
{
	public partial class Unit : ObjectBase
	{
		[Flags]
		protected enum UnitFlags
		{
			None = 0x0,
			DisableMove = 0x4,
			NotInPvp = 0x8,
			Resting = 0x20,
			Mounted = 0x2000,
			DisableRotate = 0x40000,
			InCombat = 0x80000,
			Skinnable = 0x4000000,
			Sheathe = 0x40000000
		};

		public Race Race
		{
			get { return (Race)UnitBytes0[0]; }
			set { UnitBytes0[0] = (byte)value; }
		}

		public Class Class
		{
			get { return (Class)UnitBytes0[1]; }
			set { UnitBytes0[1] = (byte)value; }
		}

		public Gender Gender
		{
			get { return (Gender)UnitBytes0[2]; }
			set { UnitBytes0[2] = (byte)value; }
		}

		protected override void SetDefaultFields()
		{
			base.SetDefaultFields();
			Type |= (uint)ObjectTypeFlag(ObjectType.Unit);
			
			Health = 1;
			MaxHealth = 1;

			// rage
			//Power2 = 0136; // oleg
//			MaxPower1 = 7;
//			MaxPower2 = 0136;
//			MaxPower3 = 7;
//			MaxPower4 = 7;

			Level = 1;

			// The client crashes if this isn't set to something
			FactionTemplate = 6;
			
			// Unit.Bytes0 incase you're wondering
/*			Race = Race.Undead;
			Class = Class.Warrior;
			Gender = Gender.Female;
*/
			Flags = (int)UnitFlags.NotInPvp;
			
			// I have no idea what this data means
			/*
			Aura = 0x999;
			Fields[FieldId.Unit.Aura+1] = 0x4a2e;
			AuraFlags = 0xd9;
			AuraLevels = 0x292b;
			AuraApplications = 0xffff;
			*/
			// I'm going to just blissfully ignore
			// the aura stuff and hope it doesn't cause
			// me grief

//			BaseAttackTime = 1500;
//			Fields[FieldId.Unit.BaseAttackTime + 1] = 1000; // ??

//			RangedAttackTime = 1500;
			BoundingRadius = 1.0f;
			CombatReach = 4.0f;

			// 30 == giant redback spider
			// 10045 == wisp
			// 10041 == forest giant
			// 10044 == lava giant
			// 10046 == silithid worm
			// 10056 == silithid egg
			// 10006 == abomination
			// 10007 == evil decaying whelp
			// 10008 == gnome queen
			// 14778 == awesome dragon
			// 17251 == ony
			// 15945 == kel thuzad
			// 10318 == goblin rocket car
			// 15990 == cupid
			DisplayId = 14778;
			NativeDisplayId = 59;

			// 11641 == brown kodo
			// 14578 == tier2 kodo
			// 15677 == zomg silithid
			// 17158 == turtle
			// 15902 == reindeer
			//MountDisplayId = 331;
			
			MinDamage = 1.0f;
			MaxDamage = 1.0f;

			MinOffhandDamage = 1.0f;
			MaxOffhandDamage = 1.0f;

			// [0] = animation state .. no idea about [3]
			UnitBytes1[3] = 0x11;

			ModCastSpeed = 1.0f;

			Stat0 = 1;
			Stat1 = 1;
			Stat2 = 1;
			Stat3 = 1;
			Stat4 = 1;

			BaseHealth = 2;

			AttackPower = 7;
			AttackPowerMods = 0;
			
			RangedAttackPower = 7;
			RangedAttackPowerMods = 0;

			MinRangedDamage = 7.0f;
			MaxRangedDamage = 7.0f;
		}

		protected Speed Speed = Speed.Default;
	}
}
