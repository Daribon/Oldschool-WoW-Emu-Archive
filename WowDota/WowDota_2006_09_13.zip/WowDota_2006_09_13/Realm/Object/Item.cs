using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Realm.Object
{
	public partial class Item : ObjectBase, IBindable
	{
		public uint Id;
		public byte Slot;

		#region IBindable Members

		// Binding on character list... not sure if this binding is useful elsewhere.
		public void Bind(Binder binder)
		{
			binder.Bind(ref Id);
			binder.Bind(ref Slot);
		}

		#endregion
	}
}
