using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Realm.Object
{
	[Serializable]
	public struct Speed : IBindable
	{
		public Speed(float Walk, float WalkBack, float Run, float Swim, float SwimBack, float Turn)
		{
			this.Walk = Walk;
			this.WalkBack = WalkBack;
			this.Run = Run;
			this.Swim = Swim;
			this.SwimBack = SwimBack;
			this.Turn = Turn;
		}

		public static Speed Default = new Speed(20f, 20f, 20f, 20f, 20f, (float)Math.PI);
		//new Speed(7.0f, 7.0f, 7.0f, 7.0f, 7.0f, (float)Math.PI);

		float Walk, WalkBack, Run, Swim, SwimBack, Turn;

		public void Bind(Binder binder)
		{
			binder.Bind(ref Walk);
			binder.Bind(ref Run);
			binder.Bind(ref SwimBack);
			binder.Bind(ref Swim);
			binder.Bind(ref WalkBack);
			binder.Bind(ref Turn);
		}
	}
}
