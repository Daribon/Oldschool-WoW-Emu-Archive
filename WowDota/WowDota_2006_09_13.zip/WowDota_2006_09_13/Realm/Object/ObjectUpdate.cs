using System;
using System.Collections.Generic;
using System.Text;
using Core;
using Core.Data.Serialisation;
using Realm.Field;

namespace Realm.Object
{
	public partial class ObjectBase
	{
		public enum UpdateType : byte
		{
			Values = 0,
			Movement = 1,
			Create = 2,
			CreateSelf = 3,
			OutOfRange = 4,
			Near = 5
		}

		public enum ObjectType : byte
		{
			ObjectBase = 0,
			Item = 1,
			Container = 2,
			Unit = 3,
			Player = 4,
			GameObject = 5,
			DynamicObject = 6,
			Corpse = 7,
			AiGroup = 8,
			AreaTrigger = 9
		}

		public uint ObjectTypeFlag(ObjectType type)
		{
			return (uint)(1 << (int)type);
		}

		public virtual ObjectType GetObjectType()
		{
			// temporary. fix me.
			return ObjectType.Player;
		}

		protected virtual void BindMovementUpdate(Binder binder, UpdateType update_type)
		{
			throw new NotImplementedException();
		}

		public void BindUpdate(Session session, Binder binder)
		{
			if (binder.IsReader)
				throw new NotImplementedException("Not hard. Do me");

			UpdateType update_type = UpdateType.Create;
			if (Player.GetActiveCharacter(session.User) == this)
			{
				update_type = UpdateType.CreateSelf;
			}

			byte update_type_temp = (byte)update_type;
			binder.Bind(ref update_type_temp);

			Guid.BindPacked(binder);

			byte type = (byte)GetObjectType();
			binder.Bind(ref type);

			BindMovementUpdate(binder, update_type);
			uint unk = 1;
			binder.Bind(ref unk);

			Bindings.BindDiff(binder, this, null);
/*
			{
				System.IO.MemoryStream ms = new System.IO.MemoryStream();
				Writer temp = new Writer(ms);
				Bindings.BindDiff(temp, this, null);
				temp.WriteToFile("my_broken_update_fields");
//				binder.WriteToFile("my_object_update");
			}
*/		}
	}
}
