using System;
using System.Collections.Generic;
using System.Text;
using Realm.Field;

namespace Realm.Object
{
	public partial class Container : Item
	{
		public FieldId.Container SlotField(int slot)
		{
			return (FieldId.Container)(slot * 2 + (int)FieldId.Container.Slot1);
		}
	}
}
