using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Realm.Object
{
	[Serializable]
	struct Look : IBindable
	{
		public byte Skin, Face;
		public byte HairStyle, HairColour, HairFacial;

		public void Bind(Binder binder)
		{
			binder.Bind(ref Skin);
			binder.Bind(ref Face);
			binder.Bind(ref HairStyle);
			binder.Bind(ref HairColour);
			binder.Bind(ref HairFacial);
		}
	}
}
