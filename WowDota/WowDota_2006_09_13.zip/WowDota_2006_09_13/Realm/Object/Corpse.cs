using System;
using System.Collections.Generic;
using System.Text;

namespace Realm.Object
{
	partial class Corpse : ObjectBase
	{
	}
}
