using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using Core.Data.Serialisation;

namespace Core.Networking.Packet
{
	/// <summary>
	/// Very simple wrapper around a memorystream for use
	/// in networked communication.
	/// 
	/// Makes no assumptions about packet size - that can be
	/// set with the constructor or by calling SetLength();
	/// 
	/// Setting WaitForWholePacket = false; will ignore this
	/// completely and call Parse() every time any data is
	/// recieved.
	/// </summary>
	public class BasePacket : MemoryStream, IDescribable
	{
		public BasePacket(int size)
			: base(size)
		{
			SetLength(size);
			read_buffer = new byte[size];
			//			Allocate(size);
		}

		public BasePacket()
			: base()
		{
			read_buffer = new byte[256];
		}


		public virtual bool Parse(RemoteEndpoint connection)
		{
			parsed = true;
			return true;	// that was easy!
		}
		protected bool parsed = false;

		/// <summary>
		/// Clear the packet buffer
		/// </summary>
		public virtual void Clear()
		{
			Position = 0;
			//SetLength(0);
			parsed = false;
		}

		protected byte[] read_buffer;

		internal byte[] GetInternalBuffer()
		{
			return read_buffer;
		}

		internal virtual int MaxReadSize
		{
			get
			{
				int buffer_size = read_buffer.Length;
				if (Length == 0)
					return buffer_size;
				else
				{
					int bytes_remaining = (int)(Length - Position);
					return System.Math.Min(buffer_size, bytes_remaining);
				}
			}
		}

		internal virtual void MarshalRead(int bytes_read)
		{
			Write(read_buffer, 0, bytes_read);
		}

		public long BytesRead
		{
			get { return Position; }
			set { Position = value; }
		}

		public virtual bool Full
		{
			get { return Position >= Length; }
		}

		/// <summary>
		/// Take a look at the data in the packet buffer without extracting it.
		/// </summary>
		/// <returns></returns>
		/*public byte[] Peek()
		{
			return base.GetBuffer();
		}*/

		internal static void Decrypt(Cryptography.BigInteger key)
		{
			throw new Exception("The method or operation is not implemented.");
		}

		Reader reader = null;
		public Reader Reader
		{
			get
			{
				if (reader == null)
					reader = new Reader(this);
				return reader;
			}
		}

		Writer writer = null;
		public Writer Writer
		{
			get
			{
				if (writer == null)
					writer = new Writer(this);
				return writer;
			}
		}

		Stack<long> position_stack = new Stack<long>();
		public void PushPosition()
		{
			position_stack.Push(Position);
		}
		public void PushPosition(long position)
		{
			position_stack.Push(Position);
			Position = position;
		}
		public void PopPosition()
		{
			Position = position_stack.Pop();
		}

		internal virtual void FinaliseWrite(RemoteEndpoint ep)
		{

		}

		#region IDescribable Members

		protected virtual void WriteBytes(TextWriter Destination, int offset, int length)
		{
			lock (this)
			{
				int line = 0;
				byte[] data = new byte[length];
				PushPosition();
				Position = offset;
				base.Read(data, offset, length);
				PopPosition();

				foreach (byte b in data)
				{
					Destination.Write(b.ToString("x2") + " ");
					if (++line == 16)
					{
						line = 0;

						Destination.WriteLine();
					}
				}

				if (line > 0)
					Destination.WriteLine();
			}
		}

		public virtual void Describe(Logger.Verbosity verbosity, TextWriter Destination)
		{
			Destination.WriteLine(this);
			WriteBytes(Destination, 0, (int)Length);
		}

		#endregion

	}
}
