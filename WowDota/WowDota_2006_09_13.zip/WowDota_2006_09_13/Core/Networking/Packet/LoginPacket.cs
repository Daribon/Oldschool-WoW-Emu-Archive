using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;
using Core.Data;

namespace Core.Networking.Packet
{
	class LoginPacket : DataPacket
	{
		internal LoginPacket(MessageId id)
			: base(id)
		{
			if (id.Service != Service.Login)
				throw new InvalidOperationException(string.Format("Cannot make a LoginPacket with Id {0}", id));

			if (id.IsIdKnown)
				Position = 1;
		}

		public override bool Parse(RemoteEndpoint remote_ep)
		{
			// Set position right after ID.
			Position = 1;
			bool parsed = base.Parse(remote_ep);

			if (parsed && Position != Length)
			{
				Logger.Log(this, Logger.Priority.Warning, "Parser only read {0}/{1} bytes", Position, Length);
			}

			return parsed;
		}

		protected override uint readId()
		{
			return Reader.ReadByte();
		}

		protected override void WriteHeader()
		{
			// Need to write header
			Position = 0;
			Writer.Write((byte)Id.RawId);
		}

		public override bool Full
		{
			get
			{
				// These packets have length specified in bytes 2 and 3.
				if (Id.Origin == Origin.Server
					&& (LoginServerMessage)Id.RawId == LoginServerMessage.RealmList)
				{
					lock (this)
					{
						if (Position < 3)
							return false;

						PushPosition();
						Position = 1;
						ushort length = 0;
						Reader.Bind(ref length);
						PopPosition();

						if (Position >= length + 3)
							return true;
						else
							return false;
					}
				}
				else
					return Position > 0;
			}
		}
	}
}
