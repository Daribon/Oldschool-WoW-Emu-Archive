using System;
using System.Collections.Generic;
using System.Text;
using Core.Data;
using Core.Scripting.ScriptObject;

namespace Core.Networking.Packet
{
	/// <summary>
	/// Simple extension of BasePacket this time assuming
	/// a header of some sort.
	/// </summary>
	public abstract class DataPacket : BasePacket, IScope
	{
		public static DataPacket Make(Service service, Origin origin)
		{
			return Make(new MessageId(service, origin));
		}

		public static DataPacket Make(MessageType type)
		{
			return Make(new MessageId(type));
		}

		public static DataPacket Make(MessageId id)
		{
			if (id.Service == Service.Login)
				return new LoginPacket(id);
			else
				return new RealmPacket(id);
		}

		public DataPacket(MessageId id)
		{
			this.id = id;
		}

		protected bool parsed_header = false;

		public virtual bool ParseHeader(int packet_base)
		{
			long oldposition = Position;

			Position = packet_base;
			id.RawId = readId();
			parsed_header = true;

			Position = oldposition;

			parsed_header = true;
			return true;
		}

		public virtual bool ParseHeader()
		{
			return ParseHeader(0);
		}

		public override bool Parse(RemoteEndpoint remote_ep)
		{
			if (ParseHeader() == false)
				return false;

			WoWEndPoint connection = (WoWEndPoint)remote_ep;

			lock (connection)
			{
				Core.Scripting.ProcessPacket.PacketManager.Singleton.HandleRecievedPacket(connection.Session, this);
			}

			if (scriptScope != null)
				scriptScope.Clear();

			return true;
		}

		protected MessageId id;
		public MessageId Id
		{
			get { return id; }
		}

		protected abstract uint readId();

		protected abstract void WriteHeader();

		internal override void FinaliseWrite(RemoteEndpoint ep)
		{
			WriteHeader();
		}

		public override void Clear()
		{
			base.Clear();
			SetLength(0);
			id.RawId = MessageId.UnknownId;
			parsed_header = false;

			if (scriptScope != null)
				scriptScope.Clear();
		}

		public override string ToString()
		{
			return Id.ToString();
		}

		#region IScope Members

		protected ScriptScope scriptScope;
		public ScriptScope ScriptScope
		{
			get
			{
				if (scriptScope == null)
					scriptScope = new ScriptScope();
				return scriptScope;
			}
		}

		static DataPacket ResolveScope(Session client)
		{
			return client.Endpoint.CurrentRecievePacket;
		}

		#endregion
	}
}
