using System;
using System.Collections.Generic;
using System.IO;
using System.Security.Cryptography;
using Core.Data;
using Core.Scripting.ProcessPacket;

namespace Core.Networking.Packet
{
	public class RealmPacket : DataPacket
	{
		/// <summary>
		/// Standard wow packet with a header and body, header of the form ID, Length, body.
		/// 
		/// Note login packets aren't handled here since they're different.
		/// </summary>
		/// <param name="packetSource"></param>
		internal RealmPacket(MessageId id)
			: base(id)
		{
			if (id.Service == Service.Login)
				throw new InvalidDataException("Cannot use WoWPacket to parse Login packets");

			// This is a bit of a hack so when we write to the packet we write in the correct
			// place.
			if (id.IsIdKnown)
			{
				Position = HeaderLength;
				parsed_header = true;
			}
		}

		enum HeaderPacketSize : ushort
		{
			Server = 4,
			Client = 6,
		}

		uint DataLength = 0;
		
		public uint TotalPacketSize
		{
			get { return (uint)(HeaderLength + DataLength); }
		}

		public int HeaderLength
		{
			get
			{
				switch (Id.Origin)
				{
					case Origin.Client:
						return (int)HeaderPacketSize.Client;
					case Origin.Server:
						return (int)HeaderPacketSize.Server;
					default:
						throw new Exception(string.Format("Don't know length of packet from {0}", Id.Origin));
				}
			}
		}

		/// <summary>
		/// Tranform some of the packet with some cryptographic function.
		/// 
		/// Assumes enough bytes are avaliable.
		/// </summary>
		/// <param name="offset">Offset into the packet</param>
		/// <param name="length">Number of bytes to transform</param>
		/// <param name="transform">Cryptographic transformation to perform</param>
		public void CryptoTransformData(int offset, int length, ICryptoTransform transform)
		{
			lock (transform)
			{
				if (transform == null)
				{
					throw new ArgumentException("transform is null");
				}

				byte[] buffer = new byte[length];

				PushPosition(offset);
				int bytes_read = Read(buffer, 0, length);
				PopPosition();

				if (bytes_read < length)
					throw new InvalidDataException("Not enough bytes avaliable for crypto transformation");

				// This could be implemented without the CryptoStream, if its particularly slow.
				PushPosition(offset);

				CryptoStream stream = new CryptoStream(this, transform, CryptoStreamMode.Write);
				stream.Write(buffer, 0, length);

				PopPosition();
			}
		}

		public override bool ParseHeader(int packet_base)
		{
			if (parsed_header)
				return true;
			if (Position < (HeaderLength + packet_base))
				return false;

			long oldPosition = Position;

			Position = packet_base;

			if (Decrypter != null)
				CryptoTransformData(packet_base, HeaderLength, Decrypter);

			DataLength = readDataLength();

			// If this has false positives, increase the number.
			// This check is invaluable for debugging.
			if (DataLength > 4000)
				Logger.Log(this, Logger.Priority.Warning, "Packet length is suspiciously big - probably issues reading the right packet data");

			id.RawId = readId();

			parsed_header = true;

			Position = oldPosition;

			return true;
		}

		protected override uint readId()
		{
			switch (Id.Origin)
			{
				case Origin.Server:
					return Reader.ReadUInt32();
				case Origin.Client:
					return Reader.ReadUInt16();
				default:
					throw new Exception("Unknown packet type");
			}
		}

		private uint readDataLength()
		{
			return (uint)(Reader.ReadUInt16BE() + sizeof(ushort) - HeaderLength);
		}

		protected override void WriteHeader()
		{
			// Need to write header
			Position = 0;

			// Strangely the length looks to be big endian...
			Writer.WriteBE((ushort)(Length - sizeof(ushort)));
			Writer.Write((ushort)Id.RawId);
		}

		public override bool Parse(RemoteEndpoint remote_ep)
		{
			if (parsed == true)
				return true;

			int packet_base = 0;

			long old_position = Position;
			try
			{
				// This is supprisingly difficult to get right.5

				while (ParseHeader(packet_base)
					&& Position >= packet_base + TotalPacketSize)
				{
					Position = packet_base + HeaderLength;
					base.Parse(remote_ep);

					if (Position != packet_base + TotalPacketSize)
					{
						if (Position > packet_base + HeaderLength)
						{
							if (packet_base != 0)
								Logger.Log(Logger.Priority.Error, "Printing out packets with a nonzero base not currently supported");
							Logger.Log(this, Logger.Priority.Warning, "Did not read correct number of bytes! ({0} remain) ",
								(packet_base + TotalPacketSize - Position));
						}
						Position = packet_base + TotalPacketSize;
					}

					packet_base = (int)Position;
					parsed_header = false;
				}

				parsed = true;
			}
			finally
			{
				if (Position < old_position)
				{
					// Damn... still bytes left.
					byte[] buffer = new byte[old_position - Position];
					Read(buffer, 0, buffer.Length);
					Position = 0;
					Write(buffer, 0, buffer.Length);
					Position = buffer.Length;
					SetLength(buffer.Length);
					parsed = false;
				}
			}

			return parsed;
		}

		internal override int MaxReadSize
		{
			get
			{
				return read_buffer.Length;
			}
		}

		public override bool Full
		{
			get
			{
				return ParseHeader() && Position >= TotalPacketSize;
			}
		}

		internal override void FinaliseWrite(RemoteEndpoint ep)
		{
			if (ep is EncryptedEndPoint)
				SetEncryptedEndPoint(ep as EncryptedEndPoint);

			base.FinaliseWrite(ep);

			if (Encrypter != null)
				CryptoTransformData(0, HeaderLength, Encrypter);
		}

		public bool UseEncryption = true;

		EncryptedEndPoint eep = null;
		public ICryptoTransform Encrypter
		{
			get
			{
				if (eep == null || UseEncryption == false)
					return null;
				else
					return eep.Encrypter;
			}
		}

		public ICryptoTransform Decrypter
		{
			get
			{
				if (eep == null || UseEncryption == false)
					return null;
				else
					return eep.Decrypter;
			}
		}

		internal void SetEncryptedEndPoint(EncryptedEndPoint eep)
		{
			this.eep = eep;
		}

		public override void Clear()
		{
			base.Clear();
			UseEncryption = true;
			parsed = false;
		}

		public override string ToString()
		{
			if (Full)
				return string.Format("{0}", Id);
			else if (ParseHeader())
				return string.Format("{0}[{1}/{2}]", Id, Position, TotalPacketSize);
			else if (id.IsIdKnown)
				return string.Format("{0}", Id);
			else
				return string.Format("Unknown packet");	
		}

		public override void Describe(Logger.Verbosity verbosity, TextWriter Destination)
		{
			Destination.WriteLine(this);
			WriteBytes(Destination, 0, (int)TotalPacketSize);
		}
	}
}
