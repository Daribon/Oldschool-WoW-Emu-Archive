using System;
using System.Net;
using System.Net.Sockets;
using System.Collections;

namespace Core.Networking
{
	/// <summary>
	/// This is effectively a wrapper around m_socket to do async reads and writes, and provide subscribable events
	/// to notify other parts of the program when this happens.
	/// 
	/// We also have a packet buffer which buffers incoming data. This requires a that packets have a known size.
	/// </summary>
	public class RemoteEndpoint
	{
		protected Socket m_socket;
		//		protected Queue m_sendQueue = Queue.Synchronized(new Queue());
		private Packet.BasePacket m_recievePacket;

		public event Delegates.OnDataHandler RecievedDataHandler;
		public event Delegates.OnDataHandler SentDataHandler;
		public event Delegates.OnDisconnect DisconnectHandler;

		/// <summary>
		/// Must call Initialise before you can do anything
		/// </summary>
		public RemoteEndpoint()
		{
		}

		public RemoteEndpoint(Socket sock, object data)
		{
			Initialise(sock, data);
		}

		public RemoteEndpoint(IPEndPoint ipep, object data)
		{
			// Could probably use SocketType.Rdp instead... ?
			m_socket = new Socket(ipep.AddressFamily, SocketType.Stream, ProtocolType.Tcp);
			m_socket.Connect(ipep);

			Initialise(m_socket, data);
		}

		public virtual void Initialise(Socket sock, object data)
		{
			m_socket = sock;

			// Problematic?
			if (m_socket != null && m_socket.Connected)
			{
				setupSocket();
			}
			else
				throw new Exception("Could not connect!");
		}

		private void setupSocket()
		{
			// ???
			//m_socket.Blocking = false;

			if (m_recievePacket == null)
				m_recievePacket = new Packet.BasePacket(5);

			registerRecieveCallback(GetNextPacketInfo(null, null));
		}

		public bool WaitForWholePacket = true;

		#region General networking state
		public virtual IPEndPoint RemoteEndPoint
		{
			get
			{
				if (m_socket != null && m_socket.Connected)
					return (IPEndPoint)m_socket.RemoteEndPoint;
				else
					return null;
			}
		}

		public virtual bool TimedOut
		{
			get
			{
				return false;
			}
		}

		public virtual void Close(string reason)
		{
			lock (m_socket)
			{
				// Are we already closed?
				if (m_socket.Connected == false)
					return;

				if (DisconnectHandler != null)
				{
					DisconnectHandler(this);
				}

				//Console.WriteLine(this + " closed: " + reason);
				try
				{
					m_socket.Shutdown(SocketShutdown.Both);
					//m_socket.BeginDisconnect(true, new AsyncCallback(disconnectCallback), null);
					m_socket.Close();
				}
				catch (Exception) { }
			}
		}
		#endregion

		#region Helper
		public virtual void OnException(Exception e)
		{
			if (e is SocketException)
				Close(e.Message + " (" + ((SocketException)e).ErrorCode + ")");
			else
				Close(e.Message);
		}

		public override string ToString()
		{
			IPEndPoint remoteEndPoint = RemoteEndPoint;
			if (remoteEndPoint != null)
				return RemoteEndPoint.ToString();
			else
				return "disconnected";
		}
		#endregion

		#region Recieve related

		protected virtual Packet.BasePacket GetPacketBuffer(Object packetinfo)
		{
			return m_recievePacket;
		}

		/// <summary>
		/// Register a data recieving callback function to read data from the server
		/// </summary>
		protected void registerRecieveCallback(Object packetInfo)
		{
			if (m_socket.Connected == false)
				return;

			Packet.BasePacket buf = GetPacketBuffer(packetInfo);

			try
			{
				//					Console.WriteLine("Waiting for {0} bytes", buf.MaxReadSize);
				m_socket.BeginReceive(
					buf.GetInternalBuffer(), 0, buf.MaxReadSize,
					SocketFlags.None, new AsyncCallback(recieveCallback), packetInfo);
			}
			catch (Exception e)
			{
				OnException(e);
			}
		}

		/// <summary>
		/// callback for recieving connection data events.
		/// </summary>
		private void recieveCallback(IAsyncResult result)
		{
			try
			{
				Object packetInfo = result.AsyncState;

				int bytes_read;

				try
				{
					bytes_read = m_socket.EndReceive(result);
				}
				catch (ObjectDisposedException) // Socket has been closed.
				{
					Close("Could not recieve data");
					return;
				}

				if (bytes_read == 0)
				{
					Close("Remote host closed connection");
					return;
				}

				Packet.BasePacket buffer = GetPacketBuffer(packetInfo);
				buffer.MarshalRead(bytes_read);
				//				buffer.BytesRead += bytes_read;

				//				System.Console.WriteLine("in {0} recieveCallback() - read in {1} bytes. -> {2}",
				//					this.ToString(), bytes_read, buf.BytesRead);
				if (buffer.Full || WaitForWholePacket == false)
				{
					RecievedPacket(buffer, packetInfo);
					bool parse_complete = buffer.Parse(this);
					if (parse_complete)
						buffer.Clear();

					Object newPacketInfo = GetNextPacketInfo(buffer, packetInfo);

					registerRecieveCallback(newPacketInfo);
				}
				else
				{
					Logger.Log(Logger.Priority.Low, "Buffering {0} bytes of data to {1}", bytes_read, buffer);

					registerRecieveCallback(packetInfo);
				}
			}
			catch (SocketException e)
			{
				OnException(e);
			}
		}

		/// <summary>
		/// We have recieved a complete packet. This function works out what to do with it.
		/// </summary>
		/// <param name="data">Packet data</param>
		/// <param name="state">Some state information about this packet</param>
		/// <returns>State information for the next packet to be recieved</returns>
		protected virtual void RecievedPacket(Packet.BasePacket packet, Object packetinfo)
		{
			if (RecievedDataHandler != null)
			{
				RecievedDataHandler(this, packet);
			}
		}

		protected virtual object GetNextPacketInfo(Packet.BasePacket packet, object oldPacketInfo)
		{
			return null;
		}

		#endregion

		#region Send related

		public void Send(Packet.BasePacket packet)
		{
			packet.FinaliseWrite(this);
			byte[] data = packet.ToArray();
			//Console.WriteLine("Writing {0} bytes to {1}", data.Length, this);

			try
			{
				// Is this necessary?
				lock (m_socket)
				{
					// Useful debugging.
					//						Console.WriteLine("Press a key to send {0}...", packet);
					//						Console.ReadLine();

					m_socket.BeginSend(
						data, 0, data.Length,
						SocketFlags.None, new AsyncCallback(sendCallback), (Object)packet);
				}
			}
			catch (Exception e)
			{
				OnException(e);
			}
		}

		public void sendCallback(IAsyncResult result)
		{
			try
			{
				m_socket.EndSend(result);

				if (SentDataHandler != null)
					SentDataHandler(this, (Packet.BasePacket)result.AsyncState);
			}
			catch (ObjectDisposedException)
			{
				Close("Could not send data to socket");
			}
		}

		#endregion
	}
}