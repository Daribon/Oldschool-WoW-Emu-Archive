using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking.Packet;
using System.IO;
using Core.Data.Client;
using Core.Scripting;

namespace Core.Networking
{
	class DataTransferredEvent : Event
	{
		BasePacket Packet;

		public DataTransferredEvent(Event.Type type, RemoteEndpoint endpoint, BasePacket data, Logger.Priority priority)
			: base(type, endpoint, priority)
		{
			this.Packet = data;
		}
		public DataTransferredEvent(Event.Type type, Session session, BasePacket data, Logger.Priority priority)
			: base(session, type, priority)
		{
			this.Packet = data;
		}

		public DataTransferredEvent(Event.Type type, RemoteEndpoint endpoint, BasePacket data)
			: base(type, endpoint)
		{
			this.Packet = data;
		}
		public DataTransferredEvent(Event.Type type, Session session, BasePacket data)
			: base(session, type)
		{
			this.Packet = data;
		}

		public override void Describe(Logger.Verbosity verbosity, TextWriter writer)
		{
			if (Packet != null)
			{
				writer.Write("{0}", EventType);
				
				if (Session != null)
					writer.Write(" using {0}", Session);

				writer.WriteLine();

				Packet.Describe(verbosity, writer);
			}
		}
	}
}
