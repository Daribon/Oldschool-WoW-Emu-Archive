using System;
using System.Collections.Generic;
using System.Text;
using System.Net.Sockets;
using System.Net;
using Core.Data;
using Core.Networking.Packet;

namespace Core.Networking
{
	public class WoWEndPoint : RemoteEndpoint
	{
		public WoWEndPoint()
		{ }

		public WoWEndPoint(Socket sock, MessageType remotePacketType)
			: base(sock, remotePacketType)
		{ }

		public WoWEndPoint(IPEndPoint ipep, MessageType remotePacketType)
			: base(ipep, remotePacketType)
		{ }

		public override void Initialise(Socket sock, object data)
		{
			lock (this)
			{
				WaitForWholePacket = true;

				MessageType remotePacketType = (MessageType)data;

				packet = DataPacket.Make(remotePacketType);
				base.Initialise(sock, remotePacketType);
				this.remotePacketType = remotePacketType;

				session = new Session(this);
			}
		}

		Packet.DataPacket packet;

		MessageType remotePacketType;
		public MessageType RemotePacketType
		{
			get { return remotePacketType; }
		}

		Session session;
		public Session Session
		{
			get { return session; }
		}
		
		protected override Packet.BasePacket GetPacketBuffer(object packetinfo)
		{
			return packet;
		}

		internal Packet.DataPacket CurrentRecievePacket { get { return packet; } }
	}
}