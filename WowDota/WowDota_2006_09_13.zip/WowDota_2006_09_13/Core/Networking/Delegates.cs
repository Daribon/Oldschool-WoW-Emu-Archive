using System;
using System.Net;
using System.Net.Sockets;
using Core.Networking;

namespace Core.Networking.Delegates
{
	public delegate void VoidDelegate();
	public delegate void OnDataHandler(RemoteEndpoint client, Core.Networking.Packet.BasePacket packet);
	public delegate void OnConnect(RemoteEndpoint client);
	public delegate void OnDisconnect(RemoteEndpoint client);
}
