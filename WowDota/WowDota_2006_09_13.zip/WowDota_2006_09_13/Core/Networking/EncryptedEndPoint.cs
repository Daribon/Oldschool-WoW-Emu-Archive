using System;
using System.Collections.Generic;
using System.Text;
using Core.Data;
using System.Net.Sockets;
using System.Net;
using System.IO;
using System.Security.Cryptography;
using Core.Networking.Packet;

namespace Core.Networking
{
	public class EncryptedEndPoint : WoWEndPoint
	{
		public EncryptedEndPoint()
			: base()
		{ }
		
		public EncryptedEndPoint(Socket sock, MessageType remotePacketType)
			: base(sock, remotePacketType)
		{ }

		public EncryptedEndPoint(IPEndPoint ipep, MessageType remotePacketType)
			: base(ipep, remotePacketType)
		{ }

		public override void Initialise(System.Net.Sockets.Socket sock, object data)
		{
 			base.Initialise(sock, data);

			MessageType remotePacketType = (MessageType)data;
		}

		protected override BasePacket GetPacketBuffer(object packetinfo)
		{
			RealmPacket packet = base.GetPacketBuffer(packetinfo) as RealmPacket;
			if (packet == null)
				throw new InvalidDataException("My packet buffer isn't a world packet! This is bad.");

			packet.SetEncryptedEndPoint(this);

			return packet;
		}

		public SymmetricAlgorithm Cypher
		{
			set
			{
				if (value == null)
				{
					encrypter = null;
					decrypter = null;
				}
				else
				{
					encrypter = value.CreateEncryptor();
					decrypter = value.CreateDecryptor();
				}
			}
		}

		ICryptoTransform encrypter, decrypter;
		public ICryptoTransform Encrypter { get { return encrypter; } }
		public ICryptoTransform Decrypter { get { return decrypter; } }
	}
}
