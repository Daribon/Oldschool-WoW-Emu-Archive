using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking.Packet;

namespace Core.Networking
{
	public class RealmServer : ServerBase<EncryptedEndPoint>
	{
		public RealmServer()
			: base(new Core.Data.MessageType(Core.Data.Service.Realm, Core.Data.Origin.Client))
		{
			OnServerStart += ServerStart;
			OnServerStop += ServerStop;

		}

		public RealmServer(string name)
			: this()
		{
			data.Name = name;
		}

		Core.Data.Realm.RealmInfo data = new Core.Data.Realm.RealmInfo();
		internal Core.Data.Realm.RealmInfo Data
		{
			get
			{
				return data;
			}
		}

		public string Name
		{
			get { return data.Name; }
			set { data.Name = value; }
		}


		void ServerStart()
		{
			data.Status = Core.Data.Realm.Status.Good;

			// This works, but I don't trust it not to change at some point.
			// data.Address = LocalEndPoint.ToString();
			data.Address = string.Format("{0}:{1}",
				LocalEndPoint.Address.ToString(),
				LocalEndPoint.Port.ToString());
		}

		void ServerStop()
		{
			data.Status = Core.Data.Realm.Status.Offline;
		}

		public override string ToString()
		{
			return string.Format("Realmserver({1}) '{0}'", data.Name, LocalEndPoint);
		}
	}
}
