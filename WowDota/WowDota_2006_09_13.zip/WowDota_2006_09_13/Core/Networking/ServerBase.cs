using System;
using System.Net;
using System.Net.Sockets;
using System.Threading;
using System.Globalization;
using System.Collections.Generic;
using Core.Networking.Delegates;
using Core.Scripting;

namespace Core
{
	namespace Networking
	{
		/// <summary>
		/// Summary description for ServerBase.
		/// </summary>
		public class ServerBase<RemoteEndpointType> where RemoteEndpointType : RemoteEndpoint, new()
		{
			protected Socket m_listen = null;

			// Change this to a List<RemoteEndpoint> m_clients or something.
			protected Dictionary<string, RemoteEndpoint> m_clients = new Dictionary<string, RemoteEndpoint>();

			public event VoidDelegate OnServerStart;
			public event VoidDelegate OnServerStop;

			public event Delegates.OnDataHandler RecievedDataHandler;
			public event Delegates.OnDataHandler SentDataHandler;
			public event Delegates.OnConnect ConnectHandler;
			public event Delegates.OnDisconnect DisconnectHandler;

			// If I bump this to a number > 1 I start seeing 100% CPU usage in win2k.
			// 10 would be preferable - play with this. There's a bug somewhere, apparently in .NET
			protected const int AcceptThreadPoolSize = 10;

			protected object endpoint_init_data;

			public ServerBase(object endpoint_init_data)
			{
				DisconnectHandler += RemoveClient;
				ConnectHandler += AddClient;

				this.endpoint_init_data = endpoint_init_data;
				RegisterEvents();
			}

			public IPEndPoint LocalEndPoint
			{
				get
				{
					if (m_listen != null)
						return (IPEndPoint)m_listen.LocalEndPoint;
					else
						return new IPEndPoint(IPAddress.Any, 0);
				}
			}

			public override string ToString()
			{
				return string.Format("Server<{0}> on {1}", typeof(RemoteEndpointType), LocalEndPoint);
			}

			public virtual bool Start(IPEndPoint iep)
			{
				//			GetPermissions();
				m_listen = new Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
				try
				{
					m_listen.Bind(iep);
					m_listen.Listen((int)SocketOptionName.MaxConnections);
				}
				catch (SocketException)
				{
					return false;
				}

				if (OnServerStart != null)
					OnServerStart();

				for (int i = 0; i < AcceptThreadPoolSize; i++)
				{
					m_listen.BeginAccept(new AsyncCallback(acceptCallback), null);
				}

				return true;
			}

			public virtual bool Start()
			{
				return Start(LocalEndPoint);
			}

			protected void acceptCallback(IAsyncResult result)
			{
				Socket client = m_listen.EndAccept(result);
				IPEndPoint ip = (IPEndPoint)client.RemoteEndPoint;

				if (isBanned(ip.Address))
				{
					client.Close();
				}
				else
				{
					OnAcceptSocket(client);
				}

				m_listen.BeginAccept(new AsyncCallback(acceptCallback), result.AsyncState);
			}

			public virtual void Stop()
			{
				// First we'll stop accepting new connections
				if (m_listen != null && m_listen.Connected)
					m_listen.Close();

				// Now lets kill all the existing ones...
				foreach (RemoteEndpoint client in Clients)
				{
					client.Close("Server shutdown");
				}

				if (OnServerStop != null)
					OnServerStop();
			}

			public virtual void Broadcast(Packet.BasePacket data)
			{
				foreach (RemoteEndpoint client in Clients)
				{
					client.Send(data);
				}
			}

			#region Client management

			public int ClientCount
			{
				get
				{
					return m_clients.Count;
				}
			}

			public List<RemoteEndpoint> Clients
			{
				get
				{
					return new List<RemoteEndpoint>(m_clients.Values);
				}
			}

			public virtual bool isBanned(IPAddress address)
			{
				return false;
			}

			protected virtual void OnAcceptSocket(Socket sock)
			{
				RemoteEndpoint client = new RemoteEndpointType();
				client.Initialise(sock, endpoint_init_data);
				OnClientConnect(client);
			}

			protected virtual void AddClient(RemoteEndpoint client)
			{
				client.RecievedDataHandler += OnClientRecievedData;
				client.DisconnectHandler += OnClientDisconnect;
				client.SentDataHandler += OnClientSentData;
				m_clients.Add(client.RemoteEndPoint.ToString(), client);
			}

			protected virtual void RemoveClient(RemoteEndpoint client)
			{
				client.RecievedDataHandler -= OnClientRecievedData;
				client.DisconnectHandler -= OnClientDisconnect;
				client.SentDataHandler -= OnClientSentData;
				m_clients.Remove(client.RemoteEndPoint.ToString());
			}

			#region Event handlers
			protected virtual void OnClientRecievedData(RemoteEndpoint aClient, Packet.BasePacket data)
			{
				if (RecievedDataHandler != null)
				{
					RecievedDataHandler(aClient, data);
				}
			}

			protected virtual void OnClientSentData(RemoteEndpoint aClient, Packet.BasePacket data)
			{
				if (SentDataHandler != null)
				{
					SentDataHandler(aClient, data);
				}
			}

			protected virtual void OnClientConnect(RemoteEndpoint aClient)
			{
				if (ConnectHandler != null)
				{
					ConnectHandler(aClient);
				}
			}

			protected virtual void OnClientDisconnect(RemoteEndpoint aClient)
			{
				if (DisconnectHandler != null)
				{
					DisconnectHandler(aClient);
				}
			}

			private void RegisterEvents()
			{
				OnServerStart += SendServerStartEvent;
				OnServerStop += SendServerStopEvent;
				SentDataHandler += SendSentDataEvent;
				RecievedDataHandler += SendRecievedDataEvent;
			}

			void SendSentDataEvent(RemoteEndpoint client, Core.Networking.Packet.BasePacket packet)
			{
				new DataTransferredEvent(Event.Type.PacketSent, client, packet, Logger.Priority.Low).Dispatch();
			}
			void SendRecievedDataEvent(RemoteEndpoint client, Core.Networking.Packet.BasePacket packet)
			{
				new DataTransferredEvent(Event.Type.PacketSent, client, packet, Logger.Priority.Low).Dispatch();
			}

			void SendServerStartEvent()
			{
				new Event(Event.Type.ServerStarted, this, Logger.Priority.GlobalState).Dispatch();
			}
			void SendServerStopEvent()
			{
				new Event(Event.Type.ServerStopped, this, Logger.Priority.GlobalState).Dispatch();
			}
			#endregion

			#endregion
		}
	}
}