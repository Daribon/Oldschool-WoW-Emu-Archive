using System;
using System.Collections.Generic;
using System.Text;
using System.Net;

namespace Core.Networking
{
	public class LoginServer : ServerBase<WoWEndPoint>
	{
		public LoginServer()
			: base(new Core.Data.MessageType(Core.Data.Service.Login, Core.Data.Origin.Client))
		{
		}

		public virtual bool Start(IPAddress ip)
		{
			return base.Start(new IPEndPoint(ip, 3724));
		}

		public virtual void Register(RealmServer server)
		{
			// For the moment lets just add it to the database.
			Core.Data.Base.Singleton.RealmList.Add(server);
		}

		public override string ToString()
		{
			return string.Format("Loginserver({0})", LocalEndPoint);
		}
	}

}