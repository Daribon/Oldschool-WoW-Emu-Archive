using System;
using System.Collections.Generic;
using Core.Scripting.ScriptObject;
using Core.Data;
using Core.Scripting;

namespace Core
{
	/// <summary>
	/// All the data to be associated with a client connection.
	/// </summary>
	public class Session : IScope
	{
		public Session(Core.Networking.WoWEndPoint endpoint)
		{
			this.endpoint = endpoint;
			endpoint.DisconnectHandler += DisconnectHandler;

			new Event(this, Event.Type.ClientConnected, endpoint, Logger.Priority.ClientState).Dispatch();
		}

		public User User;
		
		Core.Networking.WoWEndPoint endpoint;
		public Core.Networking.WoWEndPoint Endpoint
		{
			get { return endpoint; }
		}

		public override string ToString()
		{
			if (User != null)
				return string.Format("Session '{0}'", User);
			else
				return string.Format("Session [{0}]", endpoint);
		}

		void DisconnectHandler(Core.Networking.RemoteEndpoint endpoint)
		{
			new Event(this, Event.Type.ClientDisconnected, endpoint, Logger.Priority.ClientState).Dispatch();

			if (endpoint != this.Endpoint)
				throw new ArgumentException(
					string.Format("{0} Recieving disconnect message from {1}", this, endpoint));
			if (User != null)
				User.DestroySession();
		}

		internal void Close(string message)
		{
			endpoint.Close(message);
		}

		[NonSerialized]
		private Core.Data.Realm.List realmlist;
		public Core.Data.Realm.List RealmList
		{
			get
			{
				if (User == null)
					return null;
				else if (User is ServerUser)
					return Data.Base.Singleton.RealmList;
				else
				{
					if (realmlist == null)
						realmlist = new Core.Data.Realm.List();
					return realmlist;
				}
			}
		}

		public bool UseEncryption
		{
			set
			{
				Core.Networking.EncryptedEndPoint eep
						= Endpoint as Core.Networking.EncryptedEndPoint;

				if (value == true)
				{
					if (eep == null)
						throw new InvalidOperationException("Cannot use encryption on non-encrypted endpoint");

					eep.Cypher = User.CurrentAuthenticatorBinding.GetCypher();
				}
				else
				{
					if (eep != null)
						eep.Cypher = null;
				}
			}
		}

		public override int GetHashCode()
		{
			return Endpoint.RemoteEndPoint.GetHashCode();
		}

		#region script object stuff
		[NonSerialized]
		ScriptScope scriptScope = new ScriptScope();

		public ScriptScope ScriptScope { get { return scriptScope; } }

		// This is mostly a shortcut for a horrible mass of code.
		public ObjectType GetScriptObject<ScopeType, ObjectType>(bool create) where ScopeType : IScope
		{
			return ScopeResolver.ResolveObject<ScopeType, ObjectType>(this, create);
		}
		
		static Session ResolveScope(Session client)
		{
			return client;
		}
		#endregion
	}
}
