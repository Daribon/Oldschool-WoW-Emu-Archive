using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Core.Data.Map
{
	public enum Continent : uint
	{
		Azeroth,
		Kalimdor
	}
}
