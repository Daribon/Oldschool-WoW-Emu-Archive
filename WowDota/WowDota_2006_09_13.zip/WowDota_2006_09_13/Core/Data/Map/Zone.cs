using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Core.Data.Map
{
	[Serializable]
	public struct Zone : IBindable
	{
		public Zone (uint Id)
		{
			this.Id = Id;
		}

		public uint Id;

		public void Bind(Binder binder)
		{
			binder.Bind(ref Id);
		}

		// override object.Equals
		public override bool Equals(object obj)
		{
			if (obj == null || GetType() != obj.GetType())
			{
				return false;
			}

			return ((Zone)obj).Id == Id;
		}

		// override object.GetHashCode
		public override int GetHashCode()
		{
			return Id.GetHashCode();
		}

		public static Zone Unknown = new Zone(0);
	}
}
