using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Core.Data.Map
{
	[Serializable]
	public struct WorldLocation
	{
		public WorldLocation(Continent continent, Zone zone, Vector position)
		{
			this.Continent = continent;
			this.Zone = zone;
			this.Position = position;
		}

		public Continent Continent;
		public Zone Zone;
		public Vector Position;

		#region Binders

		// Its this order in character lists...
		public void BindZoneContinentPosition(Binder binder)
		{
			binder.Bind(ref Zone);
			uint c = (uint)Continent;
			binder.Bind(ref c);
			Continent = (Continent)c;
			binder.Bind(ref Position);
		}

		// ... and this order for BINDPOINTUPDATE
		public void BindPositionContinentZone(Binder binder)
		{
			binder.Bind(ref Zone);
			uint c = (uint)Continent;
			binder.Bind(ref c);
			Continent = (Continent)c;
			binder.Bind(ref Position);
		}

		#endregion

		public static WorldLocation Unknown
			= new WorldLocation(Continent.Kalimdor, Zone.Unknown, new Vector());
	}
}
