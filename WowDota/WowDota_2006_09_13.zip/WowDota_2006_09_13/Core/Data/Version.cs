using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;

namespace Core.Data.Client
{
	public struct Version : IBindable
	{
		public Version(ushort build)
			: this(byte.MaxValue, byte.MaxValue, byte.MaxValue, build)
		{ }

		public Version(byte MajorVersion, byte MinorVersion, byte Revision)
			: this(MajorVersion, MinorVersion, Revision, ushort.MaxValue)
		{ }

		public Version(byte MajorVersion, byte MinorVersion, byte Revision, ushort Build)
		{
			this.MajorVersion = MajorVersion;
			this.MinorVersion = MinorVersion;
			this.Revision = Revision;
			this.Build = Build;
		}

		static public Version ExpectedClientVersion = new Version(1, 12, 0, 5595);

		public byte MajorVersion;
		public byte MinorVersion;
		public byte Revision;
		public ushort Build;

		public void Bind(Binder binder)
		{
			binder.Bind(ref MajorVersion);
			binder.Bind(ref MinorVersion);
			binder.Bind(ref Revision);
			binder.Bind(ref Build);
		}

		public void BindBuild(Binder binder)
		{
			binder.Bind(ref Build);
		}

		/// <summary>
		/// Test if two versions are equivalent.
		/// 
		/// I'm accepting either the major, minor and revision numbers to be the same
		/// or the build numbers to be the same.
		/// </summary>
		/// <param name="obj">object to compare to</param>
		/// <returns></returns>
		public override bool Equals(object obj)
		{
			if (obj == null || GetType() != obj.GetType())
			{
				return false;
			}

			Version version = (Version)obj;

			// Note that they're the same if just their build matches!
			return (MajorVersion == version.MajorVersion
				&& MinorVersion == version.MinorVersion
				&& Revision == version.Revision)
						|| Build == version.Build;
		}

		public override int GetHashCode()
		{
			return MajorVersion << 30 | MinorVersion << 25 | Revision << 20 | Build ;
		}

		public override string ToString()
		{
			if (MajorVersion == byte.MaxValue)
				return string.Format("Build {0}", Build);
			else if (Build == ushort.MaxValue)
				return string.Format("{0}.{1}.{2}", MajorVersion, MinorVersion, Revision);
			else
				return string.Format("{0}.{1}.{2}.{3}", MajorVersion, MinorVersion, Revision, Build);
		}
	}
}
