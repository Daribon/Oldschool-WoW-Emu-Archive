using System;
using System.Collections.Generic;
using System.Text;

using System.IO;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using Core.Scripting.ProcessPacket;

namespace Core.Data
{
	class Test
	{
		public static void test_auth()
		{
			User auth = new ServerUser("fred", "smoth");
			//auth.Name = "user";
			//auth.Verifier = new Cryptography.BigInteger(7);
			//auth.Salt = new Cryptography.BigInteger("3472364946298734569287345692873456982734562987346", 10);

			Stream writer = File.Open("cool.xml", FileMode.Create);
			IFormatter formatter = new SoapFormatter();

			System.Console.WriteLine("Serializing {0}", auth);
			formatter.Serialize(writer, auth);
			writer.Close();


			Stream reader = new FileStream("cool.xml", FileMode.Open);
			User t2 = (User)formatter.Deserialize(reader);
			reader.Close();

			System.Console.WriteLine("Deserialized {0}", t2);

			System.Console.ReadLine();


		}
	}
}
