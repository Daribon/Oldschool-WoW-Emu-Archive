using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Data
{
	[Serializable]
	public struct Vector : Core.Data.Serialisation.IBindable
	{
		public Vector(float x, float y, float z)
		{
			this.X = x;
			this.Y = y;
			this.Z = z;
		}

		public float X, Y, Z;

		public void Bind(Core.Data.Serialisation.Binder binder)
		{
			binder.Bind(ref X);
			binder.Bind(ref Y);
			binder.Bind(ref Z);
		}
	}
}
