using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Data
{
	public enum Service
	{
		Login,
		Realm,

		Num
	}

	[Flags]
	public enum Origin
	{
		Server = 1,
		Client = 2,

		ServerClient = Server | Client
	}

	public struct MessageType
	{
		public Service Service;
		public Origin Origin;

		public MessageType(Service service, Origin origin)
		{
			Service = service;
			Origin = origin;
		}

		public override string ToString()
		{
			return string.Format("{0} {1}", Service, Origin);
		}
	}

	public struct MessageId
	{
		public MessageType Type;
		public uint RawId;

		public MessageId(Service service, Origin origin)
		{
			Type.Service = service;
			Type.Origin = origin;
			RawId = UnknownId;
		}

		public MessageId(Service service, Origin origin, uint id)
			: this(service, origin)
		{
			RawId = id;
		}

		public MessageId(MessageType type)
		{
			Type = type;
			RawId = UnknownId;
		}

		public MessageId(MessageType type, uint id)
		{
			Type = type;
			RawId = id;
		}

		public Service Service
		{
			get { return Type.Service; }
			set { Type.Service = value; }
		}
		public Origin Origin
		{
			get { return Type.Origin; }
			set { Type.Origin = value; }
		}

		public static implicit operator MessageId(LoginClientMessage val)
		{
			return new MessageId(Service.Login, Origin.Client, (uint)val);
		}

		public static implicit operator MessageId(LoginServerMessage val)
		{
			return new MessageId(Service.Login, Origin.Server, (uint)val);
		}

		public static implicit operator MessageId(RealmClientMessage val)
		{
			return new MessageId(Service.Realm, Origin.Client, (uint)val);
		}

		public static implicit operator MessageId(RealmServerMessage val)
		{
			return new MessageId(Service.Realm, Origin.Server, (uint)val);
		}

		public static explicit operator LoginClientMessage(MessageId val)
		{
			if (val.Origin != Origin.Client || val.Service != Service.Login)
				throw new InvalidCastException(string.Format("Cannot convert {0} to LoginClientMessage", val));

			return (LoginClientMessage)val;
		}

		public static explicit operator LoginServerMessage(MessageId val)
		{
			if (val.Origin != Origin.Server || val.Service != Service.Login)
				throw new InvalidCastException(string.Format("Cannot convert {0} to LoginServerMessage", val));

			return (LoginServerMessage)val;
		}

		public static explicit operator RealmClientMessage(MessageId val)
		{
			if (val.Origin != Origin.Client || val.Service != Service.Realm)
				throw new InvalidCastException(string.Format("Cannot convert {0} to LoginClientMessage", val));

			return (RealmClientMessage)val;
		}

		public static explicit operator RealmServerMessage(MessageId val)
		{
			if (val.Origin != Origin.Server || val.Service != Service.Realm)
				throw new InvalidCastException(string.Format("Cannot convert {0} to LoginServerMessage", val));

			return (RealmServerMessage)val;
		}

		public override string ToString()
		{
			if (IsIdKnown == false)
				return string.Format("{0} : Unknown", Type);
			
			string id_str = RawId.ToString();
			if (Type.Service == Service.Login)
			{
				if (Origin == Origin.Client)
					id_str = ((LoginClientMessage)RawId).ToString();
				else
					id_str = ((LoginServerMessage)RawId).ToString();
			}
			else if (Type.Service == Service.Realm)
			{
				if (Origin == Origin.Client)
					id_str = ((RealmClientMessage)RawId).ToString();
				else
					id_str = ((RealmServerMessage)RawId).ToString();
			}
			
			return string.Format("{0} : {1}", Type, id_str); 
		}

		public bool IsIdKnown
		{
			get { return RawId != UnknownId; }
		}
		public const uint UnknownId = uint.MaxValue;
	}
}
