using System;
using System.Collections.Generic;
using System.Text;
using Cryptography;
using System.Security.Cryptography;

namespace Core.Data
{
	public class SRPBinding
	{
		SRP srp;

		public SRPBinding(SRP srp)
		{
			this.srp = srp;
		}

		#region Login bindings
		public void BindServerChallenge(Core.Data.Serialisation.Binder binder)
		{
			Cryptography.BigInteger temp = null;

			if (binder.IsReader)
			{
				binder.Bind(ref temp, 32);
				srp.PublicEphemeralValueB = temp;

				temp = srp.Generator;
				binder.BindLengthValue(ref temp);
				if (temp != srp.Generator)
					throw new InvalidOperationException("generator isn't what I was expecting.");

				binder.BindLengthValue(ref temp);
				if (temp != srp.Modulus)
					throw new InvalidOperationException("modulus isn't what I was expecting.");

				binder.Bind(ref temp, 32);
				srp.Salt = temp;
			}
			else
			{
				temp = srp.PublicEphemeralValueB;
				binder.Bind(ref temp, 32);

				temp = srp.Generator;
				binder.BindLengthValue(ref temp);

				// We will pad this out to 0x20 bytes.
				byte mod_length = 32;
				binder.Bind(ref mod_length);
				temp = srp.Modulus;
				binder.Bind(ref temp, 32);

				temp = srp.Salt;
				binder.Bind(ref temp, 32);
			}
		}

		public void BindClientProof(Core.Data.Serialisation.Binder binder)
		{
			if (srp.IsServer)
			{
				BigInteger A = null;
				binder.Bind(ref A, 32);
				srp.PublicEphemeralValueA = A;// new BigInteger("68BC58DBB848BF7266949161D97FF7E2E41DE8654A09934D1D9166AF772B6B0F", 16);//A;

				BigInteger proof = null;
				binder.Bind(ref proof, 20);

				if (srp.IsClientProofValid(proof) == false)
				{
					/*					Console.WriteLine("  given: {0}\ncorrect: {1}",
											proof, ClientSessionKeyProof);
					
										Console.WriteLine(InternalsToString());
					*/
					throw new InvalidProofException(srp);
				}
			}
			else
			{
				BigInteger A = srp.PublicEphemeralValueA;
				binder.Bind(ref A, 32);

				BigInteger proof = srp.ClientSessionKeyProof;
				binder.Bind(ref proof, 20);
			}

			// Writing code to do a CRC check of the session key proof is left
			// as an exercise for the reader.
			binder.BindIgnoredBytes(20);
		}

		public void BindServerProof(Core.Data.Serialisation.Binder binder)
		{
			if (binder.IsReader)
			{
				BigInteger proof = null;
				binder.Bind(ref proof, 20);

				if (srp.IsServerProofValid(proof) == false)
					throw new InvalidProofException(srp);
			}
			else
			{
				BigInteger proof = srp.ServerSessionKeyProof;
				binder.Bind(ref proof, 20);
			}
		}
		#endregion

		#region Realm bindings
		public void BindRealmSession(Core.Data.Serialisation.Binder binder,
			byte[] server_seed, byte[] client_seed)
		{
			byte[] zeros = new byte[4];
			BigInteger verifier = 
				srp.Hash(
					srp.Username,
					zeros,
					client_seed,
					server_seed,
					srp.SessionKey);

			if (binder.IsReader)
			{
				BigInteger remote_verifier = new BigInteger();
				binder.Bind(ref remote_verifier, 20);
				if (remote_verifier != verifier)
					throw new Cryptography.InvalidProofException(srp);
			}
			else
			{
				binder.Bind(ref verifier, 20);
			}
		}

		public SymmetricAlgorithm GetCypher()
		{
			return new Cryptography.WoWPacket(srp);
		}

		#endregion
	}
}
