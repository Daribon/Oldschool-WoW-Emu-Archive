using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Data
{
	public class InvalidUsernameException : Exception
	{
		public InvalidUsernameException(string username)
			: base("Invalid Username")
		{ }
	}
}
