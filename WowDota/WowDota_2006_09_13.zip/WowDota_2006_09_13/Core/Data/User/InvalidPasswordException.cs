using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Data
{
	public class InvalidPasswordException : Exception
	{
		public InvalidPasswordException(string password)
			: base("Invalid password")
		{ }
	}
}
