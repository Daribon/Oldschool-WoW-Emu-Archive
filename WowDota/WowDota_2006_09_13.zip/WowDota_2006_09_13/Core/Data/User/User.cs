using System;
using System.Collections.Generic;
using System.Text;

using Cryptography;
using Core.Scripting.ScriptObject;

namespace Core.Data
{
    [Serializable]
    abstract public class User : IScope
	{
		protected User(string name)
		{
			if (name == null || name == "")
				throw new InvalidUsernameException(name);

			this.name = name.ToUpper();
		}

        protected string name;
		public string Name
		{
			get { return name; }
		}
		protected abstract SRP getAuthenticator();

		[NonSerialized]
		private SRP currentAuthenticator;
		public SRP CurrentAuthenticator
		{
			get
			{
				if (currentAuthenticator == null)
					currentAuthenticator = getAuthenticator();
				return currentAuthenticator;
			}
		}

		public void ClearAuthenticator()
		{
			currentAuthenticator = null;
		}

		public SRPBinding CurrentAuthenticatorBinding
		{
			get
			{
				return new SRPBinding(CurrentAuthenticator);
			}
		}

        public override string ToString()
        {
			return string.Format("User['{0}']", name);
        }

		public abstract void SetPassword(string lcase_password);

		[NonSerialized]
		public bool IsCurrentlyLoggedIn = false;

		public bool IsBanned = false;
		public bool IsDisabledByParentalControls = false;
		public bool IsTrialExpired = false;

		public bool CanLogIn(out LoginErrorCode error)
		{
			error = LoginErrorCode.Ok;

			if (IsCurrentlyLoggedIn)
				error = LoginErrorCode.AccountAlreadyLoggedIn;
			if (IsTrialExpired)
				error = LoginErrorCode.AccountTrialExpired;
			if (IsBanned)
				error = LoginErrorCode.Banned;
			if (IsDisabledByParentalControls)
				error = LoginErrorCode.ParentalControls;

			return error == LoginErrorCode.Ok;
		}

		internal void DestroySession()
		{
			IsCurrentlyLoggedIn = false;
			// currentAuthenticator = null;
		}

		ScriptScope scriptScope = new ScriptScope();
		public ScriptScope ScriptScope { get { return scriptScope; } }

		static User ResolveScope(Session client)
		{
			return client.User;
		}
		/*
		public Player ActiveCharacter
		{
			set
			{
				ScriptScope.Set<Player>(value);
			}
			get
			{
				return ScriptScope.Get<Player>();
			}
		}*/
	}
}
