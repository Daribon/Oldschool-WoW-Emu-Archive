using System;
using System.Collections.Generic;
using System.Text;
using Cryptography;

namespace Core.Data
{
	[Serializable]
	public class ServerUser : User
	{
		public ServerUser(string name, BigInteger verifier, BigInteger salt)
			: base(name)
		{
			this.verifier = verifier;
			this.salt = salt;
		}

		/// <summary>
		/// Work out our own verifier and salt.
		/// </summary>
		/// <param name="name"></param>
		public ServerUser(string lcase_name, string lcase_password)
			: base(lcase_name)
		{
			SetPassword(lcase_password);
		}

		public override void SetPassword(string lcase_password)
		{
			if (lcase_password == null || lcase_password == "")
				throw new InvalidPasswordException(lcase_password);

			string password = lcase_password.ToUpper();
			SRP authenticator = new SRP(this.name, password, true, SRP.Parameters.Defaults);
			verifier = authenticator.Verifier;
			salt = authenticator.Salt;
		}

		protected override SRP getAuthenticator()
		{
//			return new SRP(name, password, true, SRP.Parameters.Defaults); 
			return new SRP(name, Verifier, Salt, SRP.Parameters.Defaults);
		}

		Cryptography.BigInteger verifier;
		Cryptography.BigInteger salt;

		public Cryptography.BigInteger Verifier
		{ get { return verifier; } }
		public Cryptography.BigInteger Salt
		{ get { return salt; } }
	}
}
