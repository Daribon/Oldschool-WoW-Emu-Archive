using System;
using System.Collections.Generic;
using System.Text;
using Cryptography;

namespace Core.Data
{
	public class ClientUser : User
	{
		public ClientUser (string lcase_name, string lcase_password)
			: base(lcase_name)
		{
			SetPassword(lcase_password);
		}

		protected override Cryptography.SRP getAuthenticator()
		{
			return new SRP(name, password, false, SRP.Parameters.Defaults);
		}

		public override void SetPassword(string lcase_password)
		{
			password = lcase_password.ToUpper();
		}

		private string password;
	}
}
