using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;

namespace Core.Data
{
	public enum LoginClientMessage : byte
	{
		AuthLogonChallenge = 0x00,
		AuthLogonProof = 0x01,

		AuthReconnectChallenge = 0x02,
		AuthReconnectProof = 0x03,

		RequestRealmList = 0x10,
		XferInitiate = 0x30,
		XferData = 0x31,
	}

	public enum LoginServerMessage : byte
	{
		AuthLogonChallenge = 0x00,
		AuthLogonProof = 0x01,

		RealmList = 0x10,

		// These are possibly wrong/irrelevant.
		AuthVerify = 0x02,

		Ping = 0x10,
		Pong = 0x11,

		Hello = 0x20,

		ProveSession = 0x21,
		Kick = 0x24,
	}

	public enum RealmServerMessage : ushort
	{
		CharacterCreate = 58,
		CharacterList = 59,
		CharacterDelete = 60,

		SetInitialTimeSpeed = 66,

		NameQueryResponse = 81,

		FriendList = 103,
		IgnoreList = 107,

		Chat = 150,

		TriggerCinematic = 250,

		TutorialFlags = 253,

		// This is a terrible name
		BindPointUpdate = 341,

		QueryTimeResponse = 463,
		Pong = 477,

		AuthSeed = 492,
		AuthResponse = 494,
		
		Update = 169,
		CompressedUpdate = 502,

		AccountDataChecksum = 521,
		AccountDataUpdateResponse = 524,

		GMSetTicket = 530,

		QueryNextMailTime = 644,

		AddonInfo = 751,
	}

	public enum RealmClientMessage : uint
	{
		CharacterCreate = 54,
		CharacterListRequest = 55,
		CharacterDelete = 56,

		EnterWorld = 61,

		NameQuery = 80,

		Chat = 149,
		JoinChannel = 151,

		MoveStartForwards = 181,
		MoveStartBackwards = 182,
		MoveStop = 183,
		MoveStartStrafeLeft = 184,
		MoveStartStrafeRight = 185,
		MoveStartStrafeStop = 186,
		MoveJump = 187,
		MoveStartTurnLeft = 188,
		MoveStartTurnRight = 189,
		MoveStopTurn = 190,
		MoveStartPitchUp = 191,
		MoveStartPitchDown = 192,
		MoveStopPitch = 193,
		MoveSetRunMode = 194,
		MoveSetWalkMode = 195,
		MoveFallLand = 201,
		MoveSetFacing = 218,
		MoveSetPitch = 219,

		MoveHeartbeat = 238,

		TriggerNextCinematicCamera = 251,

		QueryTime = 462,

		Ping = 476,

		AuthSession = 493,

		AccountDataRequest = 522,
		AccountDataUpdate = 523,

		QueryNextMailTime = 644,

		GMGetTicket = 529,

		SetActiveMover = 618,

		MeetingStoneInfo = 662,

		RequestRaidInfo = 717,
		MoveTimeSkipped = 718,

		QueryBattlegroundStatus = 723,

		InternalAddonListRequest = 0xff000000,
	}

	/// <summary>
	/// Courtesy of mangos... :D
	/// </summary>
	public enum LoginErrorCode : byte
	{
		Ok = 0x00,
		Banned = 0x03,
		AuthenticationFailure = 0x04,
		AccountNotFound = 0x05,
		AccountAlreadyLoggedIn = 0x06,
		AccountTrialExpired = 0x07,
		ServerDown = 0x08,
		VersionMismatch = 0x09,
		Patch = 0x0a,
		AccountSuspended = 0x0c,
		ParentalControls = 0x0f,
	}

	public enum RealmErrorCode : byte
	{
		AuthOk = 0x0c,
		AuthFailed = 0x0d,
		UnknownAccount = 0x15,
		ServerFull = 0x08,

		CharacterCreateOk = 0x2e,
		CharacterCreateNameInUse = 0x31,

		CharacterDeleteOk = 0x39,
		CharacterDeleteFailed = 0x3A,
	}

		/*
		RESPONSE_SUCCESS = 0x00,
		RESPONSE_FAILURE = 0x01,
		RESPONSE_CANCELLED = 0x02,
		RESPONSE_DISCONNECTED = 0x03,
		RESPONSE_FAILED_TO_CONNECT = 0x04,
		RESPONSE_CONNECTED = 0x05,
		RESPONSE_VERSION_MISMATCH = 0x06,

		CSTATUS_CONNECTING = 0x07,
		CSTATUS_FULL = 0x08,
		CSTATUS_NEGOTIATION_COMPLETE = 0x09,
		CSTATUS_NEGOTIATION_FAILED = 0x0A,
		CSTATUS_AUTHENTICATING = 0x0B,

		AUTH_OK = 0x0C,
		AUTH_FAILED = 0x0D,
		AUTH_BAD_SERVER_PROOF = 0x0F,
		AUTH_UNAVAILABLE = 0x10,
		AUTH_SYSTEM_ERROR = 0x11,
		AUTH_BILLING_ERROR = 0x12,
		AUTH_BILLING_EXPIRED = 0x13,
		AUTH_VERSION_MISMATCH = 0x14,
		AUTH_UNKNOWN_ACCOUNT = 0x15,
		AUTH_INCORRECT_PASSWORD = 0x16,
		AUTH_SESSION_EXPIRED = 0x17,
		AUTH_SERVER_SHUTTING_DOWN = 0x18,
		AUTH_ALREADY_LOGGING_IN = 0x19,
		AUTH_LOGIN_SERVER_NOT_FOUND = 0x1A,
		AUTH_WAIT_QUEUE = 0x1B,
		AUTH_BANNED = 0x1C,
		AUTH_ALREADY_ONLINE = 0x1D,
		AUTH_NO_TIME = 0x1E,
		AUTH_DB_BUSY = 0x1F,
		AUTH_SUSPENDED = 0x20,
		AUTH_PARENTAL_CONTROL = 0x21,

		REALM_LIST_RECIEVING = 0x22,
		REALM_LIST_SUCCESS = 0x23,
		REALM_LIST_FAILED = 0x24,
		REALM_LIST_INVALID = 0x25,
		REALM_LIST_REALM_NOT_FOUND = 0x26,

		ACCOUNT_CREATE_IN_PROGRESS = 0x27,
		ACCOUNT_CREATE_SUCCESS = 0x28,
		ACCOUNT_CREATE_FAILED = 0x29,

		CHAR_LIST_RETRIEVING = 0x2A,
		CHAR_LIST_RETRIEVED = 0x2B,
		CHAR_LIST_FAILED = 0x2C,

		CHAR_CREATE_IN_PROGRESS = 0x2D,
		CHAR_CREATE_SUCCESS = 0x2E,
		CHAR_CREATE_ERROR = 0x2F,
		CHAR_CREATE_FAILED = 0x30,
		CHAR_CREATE_IN_USE = 0x31,
		CHAR_CREATE_DISABLED = 0x32,
		CHAR_CREATE_PVP_TEAMS_VIOLATION = 0x33,
		CHAR_CREATE_SERVER_LIMIT = 0x34,
		CHAR_CREATE_ACCOUNT_LIMIT = 0x35,
		CHAR_CREATE_NEW_LIMIT = 0x36,
		CHAR_CREATE_REALM_LIMIT = 0x37,
		CHAR_DELETE_IN_PROGRESS = 0x38,
		CHAR_DELETE_SUCCESS = 0x39,
		CHAR_DELETE_FAILED = 0x3A,

		CHAR_LOGIN_IN_PROGRESS = 0x3B,
		CHAR_LOGIN_SUCCESS = 0x3C,
		CHAR_LOGIN_NO_WORLD = 0x3D,
		CHAR_LOGIN_DUPLICATE_CHARACTER = 0x3E,
		CHAR_LOGIN_NO_INSTANCES = 0x3F,
		CHAR_LOGIN_FAILED = 0x40,
		CHAR_LOGIN_DISABLED = 0x41,
		CHAR_LOGIN_NO_CHARACTER = 0x42,

		CHAR_NAME_NO_NAME = 0x43,
		CHAR_NAME_TOO_SHORT = 0x44,
		CHAR_NAME_TOO_LONG = 0x45,
		CHAR_NAME_INVALID_CHARACTER = 0x46,
		CHAR_NAME_MIXED_LANGUAGES = 0x47,
		CHAR_NAME_PROFANE = 0x48,
		CHAR_NAME_RESERVED = 0x49,
		CHAR_NAME_INVALID_APOSTROPHE = 0x4A,
		CHAR_NAME_MULTIPLE_APOSTROPHES = 0x4B,
		CHAR_NAME_THREE_CONSECUTIVE = 0x4C,
		CHAR_NAME_INVALID_SPACE = 0x4D,
		CHAR_NAME_CONSECUTIVE_SPACES = 0x4E,
		CHAR_NAME_FAILURE = 0x4F,
		CHAR_NAME_SUCCESS = 0x50,*/


}
