using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking;
using System.IO;

namespace Core.Data.Serialisation
{
	public interface IBindable
	{
		void Bind(Binder binder);
	}

	public abstract partial class Binder
	{
		protected abstract Stream BaseStream { get; }

		public abstract void Bind(ref bool value);

		public abstract void Bind(ref byte value);
		public abstract void Bind(ref sbyte value);
		
		public abstract void Bind(ref short value);
		public abstract void Bind(ref ushort value);

		public abstract void Bind(ref int value);
		public abstract void Bind(ref uint value);

		public abstract void Bind(ref long value);
		public abstract void Bind(ref ulong value);

		public abstract void Bind(ref float value);
		public abstract void Bind(ref double value);

		public abstract void BindEnum<EnumType>(ref EnumType value) where EnumType : IConvertible;

		public abstract void Bind(ref string value, int length);
		public abstract void BindLengthValue(ref string value);
		public abstract void BindCStr(ref string value);
		public abstract void BindReversed(ref string value, int length);
		public abstract void BindReversedCStr(ref string value);

		public abstract void Bind(ref char value);

		public abstract void Bind(ref System.Net.IPAddress ip);
		public abstract void Bind(ref Cryptography.BigInteger value, int length);
		public abstract void BindLengthValue(ref Cryptography.BigInteger value);

		public abstract Binder BindCompressedDataStart();
		public abstract void BindCompressedDataEnd(Binder compressed_data_binder);

		public virtual void Bind<T>(T value) where T : class, IBindable
		{
			value.Bind(this);
		}
		
		public virtual void Bind<T>(ref T value) where T : IBindable
		{
			value.Bind(this);
		}

		public virtual void Bind<T>(T[] array) where T : class, IBindable
		{
			for (int i = 0; i < array.Length; i++)
				Bind(array[i]);
		}
		public virtual void Bind<T>(ref T[] array) where T : struct, IBindable
		{
			for (int i = 0; i < array.Length; i++)
				Bind(ref array[i]);
		}
		public virtual void Bind(int[] array)
		{
			for (int i = 0; i < array.Length; i++)
				Bind(ref array[i]);
		}
		public virtual void Bind(uint[] array)
		{
			for (int i = 0; i < array.Length; i++)
				Bind(ref array[i]);
		}
		public virtual void Bind(byte[] array)
		{
			for (int i = 0; i < array.Length; i++)
				Bind(ref array[i]);
		}
		public virtual void Bind(char[] array)
		{
			for (int i = 0; i < array.Length; i++)
				Bind(ref array[i]);
		}
		public virtual void Bind(float[] array)
		{
			for (int i = 0; i < array.Length; i++)
				Bind(ref array[i]);
		}
		public virtual void Bind(double[] array)
		{
			for (int i = 0; i < array.Length; i++)
				Bind(ref array[i]);
		}

		/// <summary>
		/// Ignore next length bytes
		/// </summary>
		/// <param name="length">number of bytes to ignore</param>
		public virtual void BindIgnoredBytes(int length)
		{
			BindIgnoredBytes((long)length);
		}

		/// <summary>
		/// Ignore next length bytes
		/// </summary>
		/// <param name="length">number of bytes to ignore</param>
		public virtual void BindIgnoredBytes(long length)
		{
			Position += length;
		}

		/// <summary>
		/// Read/write this many zeros. If the data does not contain zeros on reading,
		/// throw an assertion.
		/// </summary>
		/// <param name="length"></param>
		public abstract void BindZeros(int length);

		public abstract void BindStreamBytes(Stream stream, int length);

		public abstract long Position
		{ get; set; }

		public abstract long ExpectedLength
		{ get; }

		public virtual long ExpectedBytesLeft
		{ get {	return ExpectedLength - Position; } }

		Stack<long> position_stack = new Stack<long>();
		public void PushPosition()
		{
			position_stack.Push(Position);
		}
		public void PopPosition()
		{
			Position = position_stack.Pop();
		}

		abstract public bool IsWriter { get; }
		public bool IsReader { get { return !IsWriter; } }

		protected void reverse<T>(T[] buffer, int length)
		{
			for (int i = 0; i < length / 2; i++)
			{
				T temp = buffer[i];
				buffer[i] = buffer[length - i - 1];
				buffer[length - i - 1] = temp;
			}
		}
		protected void reverse<T>(T[] buffer)
		{
			reverse<T>(buffer, buffer.Length);
		}

		public virtual void WriteToFile(string filename)
		{
			long length = ExpectedLength; // dependant on position!
			PushPosition();
			Position = 0;
			System.IO.FileStream file = new FileStream(filename, FileMode.OpenOrCreate);
			byte[] buf = new byte[length];

			if (BaseStream.CanRead == false)
				throw new InvalidOperationException("Can't read this stream");

			BaseStream.Read(buf, 0, (int)length);
			file.Write(buf, 0, buf.Length);
			file.Close();
			PopPosition();
		}
	}
}
