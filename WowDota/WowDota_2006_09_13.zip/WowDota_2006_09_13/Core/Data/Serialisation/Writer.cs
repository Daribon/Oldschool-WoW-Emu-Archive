using System;
using System.Collections.Generic;
using System.IO;
using Compression;

namespace Core.Data.Serialisation
{
	public class Writer : Binder
	{
		internal BinaryWriter Stream;
		protected override Stream BaseStream { get { return Stream.BaseStream; } }

		public Writer(Stream output)
		{
			Stream = new BinaryWriter(output);
		}

		public Writer(Stream output, System.Text.Encoding encoding)
		{
			Stream = new BinaryWriter(output, encoding);
		}

		public override void Bind(ref double value)
		{
			Stream.Write(value);
		}

		public override void Bind(ref float value)
		{
			Stream.Write(value);
		}

		public virtual void Write(byte value)
		{
			Stream.Write(value);
		}
		public override void Bind(ref byte value)
		{
			Write(value);
		}

		public void Write(bool value)
		{
			if (value)
				Write((byte)1);
			else
				Write((byte)0);
		}

		public override void Bind(ref bool value)
		{
			Write(value);
		}

		public override void Bind(ref sbyte value)
		{
			Stream.Write(value);
		}

		public override void Bind(ref char value)
		{
			Stream.Write(value);
		}

		public virtual void Write(ushort value)
		{
			Stream.Write(value);
//			Write((byte)(value & byte.MaxValue));
//			Write((byte)((value >> 8) & byte.MaxValue));
		}

		#region big endian stuff
		public virtual void WriteBE(ushort value)
		{
			Stream.Write(System.Net.IPAddress.HostToNetworkOrder((short)value));
		}
		public virtual void WriteBE(short value)
		{
			Stream.Write(System.Net.IPAddress.HostToNetworkOrder(value));
		}
		public virtual void WriteBE(uint value)
		{
			Stream.Write(System.Net.IPAddress.HostToNetworkOrder((int)value));
		}
		public virtual void WriteBE(int value)
		{
			Stream.Write(System.Net.IPAddress.HostToNetworkOrder(value));
		}
		public virtual void WriteBE(ulong value)
		{
			Stream.Write(System.Net.IPAddress.HostToNetworkOrder((long)value));
		}
		public virtual void WriteBE(long value)
		{
			Stream.Write(System.Net.IPAddress.HostToNetworkOrder(value));
		}
		#endregion

		public override void Bind(ref ushort value)
		{
			Write(value);
		}

		public override void Bind(ref short value)
		{
			Stream.Write((ushort)value);
		}

		public virtual void Write(uint value)
		{
			Stream.Write(value);
//			Write((ushort)(value & ushort.MaxValue));
//			Write((ushort)((value >> 16) & ushort.MaxValue));
		}
		public override void Bind(ref uint value)
		{
			Stream.Write(value);
		}

		public override void Bind(ref int value)
		{
			Stream.Write(value);
		}

		public void Write(ulong value)
		{
			Stream.Write(value);
		}
		public override void Bind(ref ulong value)
		{
			Write(value);
		}

		public override void Bind(ref long value)
		{
			Write((ulong)value);
		}
		
		public override void BindEnum<EnumType>(ref EnumType value)
		{
			Type enum_type = typeof(EnumType);
			if (enum_type.IsEnum == false)
				throw new ArgumentException(string.Format("{0} is not an enum", value));

			Type underlying_type = Enum.GetUnderlyingType(enum_type);

			switch (Type.GetTypeCode(underlying_type))
			{
				case TypeCode.Byte:
				case TypeCode.SByte:
					Write(Convert.ToByte(value));
					break;
				case TypeCode.Int16:
				case TypeCode.UInt16:
					Write((ushort)Convert.ToUInt16(value));
					break;
				case TypeCode.Int32:
				case TypeCode.UInt32:
					Write(Convert.ToUInt32(value));
					break;
				case TypeCode.Int64:
				case TypeCode.UInt64:
					Write(Convert.ToUInt64(value));
					break;
				default:
					throw new InvalidCastException("Cannot find an appropriate base for enum");
			}
		}

		public virtual void Write(string value)
		{
			Stream.Write(value.ToCharArray());
		}

		public override void Bind(ref string value, int length)
		{
			for (int i = 0; i < length; i++)
			{
				if (i < value.Length)
					Stream.Write(value[i]);
				else
					Stream.Write('\0');
			}
		}
		public override void BindLengthValue(ref string value)
		{
			Stream.Write((byte)value.Length);
			Write(value);
		}

		public virtual void WriteCStr(string value)
		{
			if (value != null)
				Write(value);
			Stream.Write('\0');
		}
		public override void BindCStr(ref string value)
		{
			WriteCStr(value);
		}

		public override void BindReversed(ref string value, int length)
		{
			char[] arr = value.ToCharArray();
			if (length != arr.Length)
				throw new InvalidOperationException("Wrong length.");
			reverse(arr);
			Stream.Write(arr);
		}

		public override void BindReversedCStr(ref string value)
		{
			char[] arr = value.ToCharArray();
			reverse(arr);
			Stream.Write(arr);
			Stream.Write('\0');
		}

		public override void Bind(ref System.Net.IPAddress value)
		{
			byte[] data = value.GetAddressBytes();
			Stream.Write(data);
		}

		public override void Bind(ref Cryptography.BigInteger value, int length)
		{
			byte[] data = value.getBytesLE(length);
//			reverse(data);

			Stream.Write(data);
		}

		public override void BindLengthValue(ref Cryptography.BigInteger value)
		{
			byte[] data = value.getBytesLE();
//			reverse(data);
			Stream.Write((byte)data.Length);
			Stream.Write(data);
		}

		public override void BindZeros(int length)
		{
			for (int i = 0; i < length; i++)
				Write((byte)0);
		}

		public override void BindStreamBytes(Stream stream, int length)
		{
			if (stream.CanRead == false)
				throw new ArgumentException("I can't read data from the stream");

			for (int i = 0; i < length; i++)
			{
				int the_byte = stream.ReadByte();
				if (the_byte == -1)
					throw new System.IO.EndOfStreamException();
				Write((byte)the_byte);
			}
		}

		public override long Position
		{
			get
			{
				return Stream.BaseStream.Position;
			}
			set
			{
				Stream.BaseStream.Position = value;
			}
		}

		public override bool IsWriter
		{
			get { return true; }
		}

		public override Binder BindCompressedDataStart()
		{
			// I'll store the start position here. We'll need to come back
			// here to write the uncompressed data length.
			PushPosition();

			// Leave space for it
			BindIgnoredBytes(4);

			BufferedCompressorStream compressor = new BufferedCompressorStream(Stream.BaseStream);
			return new Writer(compressor);
		}

		public override void BindCompressedDataEnd(Binder compressed_data_binder)
		{
			// Make sure there's no sloppy seconds waiting around
			BufferedCompressorStream compressor
				= ((Writer)compressed_data_binder).Stream.BaseStream as BufferedCompressorStream;
			if (compressor == null)
				throw new InvalidDataException("This isn't a compressed writer binder");
			compressor.FlushOut();

			long old_position = Position;
			PopPosition();
			Write((uint)compressed_data_binder.Position);
			Position = old_position;
		}

		public override long ExpectedLength
		{
			get { return Position; }
		}

		public override void BindIgnoredBytes(long length)
		{
			BindZeros((int)length);
		}
	}
}