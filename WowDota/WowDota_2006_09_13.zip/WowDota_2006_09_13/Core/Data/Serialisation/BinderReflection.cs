using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Core.Data.Serialisation
{
	public abstract partial class Binder
	{
		protected static Dictionary<Type, MethodInfo> BindingMethodCache
			= new Dictionary<Type, MethodInfo>();

		/// <summary>
		/// Get a binder method by reflection for some given type.
		/// The method will have the signature 'void Bind(ref type)'
		/// </summary>
		/// <param name="type">type of object we want to bind</param>
		/// <returns>the method if found, null otherwise</returns>
		public static MethodInfo GetBindingMethod(Type type)
		{
			MethodInfo method = null;

			if (BindingMethodCache.TryGetValue(type, out method) == true)
				return method;

			foreach (MethodInfo tested_method in typeof(Binder).GetMethods())
			{
				if (tested_method.Name != "Bind")
					continue;

				MethodInfo current_method = tested_method;
				if (current_method.IsGenericMethodDefinition)
				{
					if (ReflectionHelper.SatisfiesGenericConstraints(current_method, type))
						current_method = current_method.MakeGenericMethod(type);
					else if (type.IsArray && ReflectionHelper.SatisfiesGenericConstraints(current_method, type.GetElementType()))
						current_method = current_method.MakeGenericMethod(type.GetElementType());
					else
						continue;
				}

				ParameterInfo[] parameters = current_method.GetParameters();
				if (parameters.Length == 1 &&
							(parameters[0].ParameterType == type
							|| parameters[0].ParameterType.GetElementType() == type))
				{
					method = current_method;
					break;
				}
			}

			if (method == null)
			{
				// Sadness. I'm going to try and find a Bind method on the object itself.

				Type[] types = { typeof(Binder) };
				method = type.GetMethod("Bind", types, null);
			}

			if (method != null)
				BindingMethodCache[type] = method;

			return method;
		}

		public virtual void CallBindingMethod(MethodInfo method, object obj)
		{
			if (method.DeclaringType == typeof(Binder))
			{
				object[] parameters = { obj };
				method.Invoke(this, parameters);
			}
			else
			{
				object[] parameters = { this };
				method.Invoke(obj, parameters);
			}
		}
	}
}

