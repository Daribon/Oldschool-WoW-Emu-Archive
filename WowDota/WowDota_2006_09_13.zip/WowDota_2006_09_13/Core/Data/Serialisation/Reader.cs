using System;
using System.Collections.Generic;
using System.IO;
using Compression;

namespace Core.Data.Serialisation
{
	public class Reader : Binder
	{
		internal BinaryReader Stream;
		protected override Stream BaseStream { get { return Stream.BaseStream; } }

		public Reader(Stream input)
		{
			Stream = new BinaryReader(input);
		}

		public Reader(Stream input, System.Text.Encoding encoding)
		{
			Stream = new BinaryReader(input, encoding);
		}

		public override void Bind(ref double value)
		{
			/*
			byte[] data = stream.ReadBytes(8);
			reverse(data);
			MemoryStream temp_stream = new MemoryStream(data);
			BinaryReader temp_reader = new BinaryReader(temp_stream);
			value = temp_reader.ReadDouble();*/

			value = Stream.ReadDouble();
		}

		public override void Bind(ref float value)
		{
			/*
			byte[] data = stream.ReadBytes(4);
			reverse(data);
			MemoryStream temp_stream = new MemoryStream(data);
			BinaryReader temp_reader = new BinaryReader(temp_stream);
			value = temp_reader.ReadSingle(); */

			value = Stream.ReadSingle();
		}

		public override void Bind(ref bool value)
		{
			value = Stream.ReadByte() != 0;
		}

		public virtual ushort ReadUInt16()
		{
			return Stream.ReadUInt16();

			//byte[] data = ReadBytes(2);
			//if (data.Length < 2)
			//	throw new EndOfStreamException();
			//return (ushort)((ushort)(data[1] << 8) | data[0]);
		}
		public virtual ushort ReadUInt16BE()
		{
			ushort value = ReadUInt16();
			return (ushort)System.Net.IPAddress.NetworkToHostOrder((short)value);
		}
		public override void Bind(ref ushort value)
		{
			value = ReadUInt16();
		}

		public virtual short ReadInt16()
		{
			return (short)ReadUInt16();
		}
		public override void Bind(ref short value)
		{
			value = ReadInt16();
		}

		public virtual uint ReadUInt32()
		{/*
			byte[] data = ReadBytes(4);
			if (data.Length < 4)
				throw new EndOfStreamException();

			return (uint)((uint)(data[3] << 24) | (uint)(data[2] << 16) | (uint)(data[1] << 8) | data[0]);*/

			return Stream.ReadUInt32();
		}
		public override void Bind(ref uint value)
		{
			value = ReadUInt32();
		}

		public virtual int ReadInt32()
		{
			return (int)ReadUInt32();
		}
		public override void Bind(ref int value)
		{
			value = ReadInt32();
		}

		public virtual ulong ReadUInt64()
		{
			return Stream.ReadUInt64();
		}
		public override void Bind(ref ulong value)
		{
			value = ReadUInt64();
		}

		public virtual long ReadInt64()
		{
			return (long)ReadUInt64();
		}
		public override void Bind(ref long value)
		{
			value = ReadInt64();
		}

		public override void BindEnum<EnumType>(ref EnumType value)
		{
			Type enum_type = typeof(EnumType);
			if (enum_type.IsEnum == false)
				throw new ArgumentException(string.Format("{0} is not an enum", value));

			Type underlying_type = Enum.GetUnderlyingType(enum_type);

			switch (Type.GetTypeCode(underlying_type))
			{
				case TypeCode.Byte:
				case TypeCode.SByte:
					value = (EnumType)Enum.ToObject(enum_type, ReadByte());
					break;
				case TypeCode.Int16:
				case TypeCode.UInt16:
					value = (EnumType)Enum.ToObject(enum_type, ReadInt16());
					break;
				case TypeCode.Int32:
				case TypeCode.UInt32:
					value = (EnumType)Enum.ToObject(enum_type, ReadInt32());
					break;
				case TypeCode.Int64:
				case TypeCode.UInt64:
					value = (EnumType)Enum.ToObject(enum_type, ReadInt64());
					break;
				default:
					throw new InvalidCastException("Cannot find an appropriate base for enum");
			}
		}

		public virtual string ReadString(int count)
		{
			char[] characters = ReadChars(count);
			return new string(characters);
		}
		public override void Bind(ref string value, int length)
		{
			value = ReadString(length);
		}
		public override void BindLengthValue(ref string value)
		{
			byte length = ReadByte();
			value = ReadString(length);
		}
		public override void BindCStr(ref string value)
		{
			value = new string(ReadCStrToArray());
		}

		public override void BindReversed(ref string value, int length)
		{
			char[] characters = ReadChars(length);
			reverse(characters);
			value = new string(characters);
		}
		public override void BindReversedCStr(ref string value)
		{
			char[] array = ReadCStrToArray();
			reverse(array);
			value = new string(array);
		}

		private char[] ReadCStrToArray()
		{
			List<char> characters = new List<char>(32);
			char c;
			while ((c = Stream.ReadChar()) != '\0')
			{
				characters.Add(c);
			}

			char[] array = characters.ToArray();
			return array;
		}

		public virtual System.Net.IPAddress ReadIPAddress()
		{
			byte[] data = ReadBytes(4);
			return new System.Net.IPAddress(data);
		}
		public override void Bind(ref System.Net.IPAddress ip)
		{
			ip = ReadIPAddress();
		}

		public virtual byte ReadByte()
		{
			return Stream.ReadByte();
		}
		public override void Bind(ref byte value)
		{
			value = Stream.ReadByte();
		}
		public virtual byte[] ReadBytes(int num)
		{
			return Stream.ReadBytes(num);
		}
		public virtual char[] ReadChars(int num)
		{
			return Stream.ReadChars(num);
		}

		public override void Bind(ref sbyte value)
		{
			value = Stream.ReadSByte();
		}

		public override void Bind(ref char value)
		{
			value = Stream.ReadChar();
		}

		public override void Bind(ref Cryptography.BigInteger value, int length)
		{
			byte[] arr = Stream.ReadBytes(length);
//			reverse(arr);
			value = new Cryptography.BigInteger(arr);
		}

		public override void BindLengthValue(ref Cryptography.BigInteger value)
		{
			Bind(ref value, ReadByte());
		}

		public override void BindStreamBytes(Stream stream, int length)
		{
			if (stream.CanWrite == false)
				throw new ArgumentException("I can't write my data to the stream");

			for (int i = 0; i < length; i++)
			{
				int the_byte = BaseStream.ReadByte();
				if (the_byte == -1)
					throw new System.IO.EndOfStreamException();
				stream.WriteByte((byte)the_byte);
			}
		}

		public override Binder BindCompressedDataStart()
		{
			uint uncompressed_length = ReadUInt32();

			// Its completely empty. Maybe I could be returning null here.
			if (uncompressed_length == 0)
				return null;

			BufferedDecompressorStream decompressor
				= new BufferedDecompressorStream(Stream.BaseStream, (int)uncompressed_length);
//			DecompressorStream decompressor = new DecompressorStream(Stream.BaseStream);
			return new Reader(decompressor);
		}

		public override void BindCompressedDataEnd(Binder compressed_data_binder)
		{
			// This will happen if the uncompressed length is zero.
			if (compressed_data_binder == null)
				return;

			BufferedDecompressorStream decompressor
				= ((Reader)compressed_data_binder).Stream.BaseStream as BufferedDecompressorStream;
			if (compressed_data_binder.ExpectedLength != decompressor.Position)
			{
				Logger.Log(this, Logger.Priority.Warning, "Compressed data binder did not read expected number of bytes");
				compressed_data_binder.BindIgnoredBytes(compressed_data_binder.ExpectedLength - decompressor.Position);
			}
			// I have no idea what these bytes represent. Sadness.
			BindIgnoredBytes(4);
		}

		public override void BindZeros(int length)
		{
			for (int i = 0; i < length; i++)
			{
				if (ReadByte() != 0)
					throw new InvalidDataException("Data isn't zero!");
			}
		}

		public override void Bind<T>(T value)
		{
			if (typeof(T).IsValueType == true)
				throw new InvalidOperationException("Your value type won't be read by the binder");
			value.Bind(this);
		}

		public override long Position
		{
			get
			{
				return Stream.BaseStream.Position;
			}
			set
			{
				Stream.BaseStream.Position = value;
			}
		}

		public override long ExpectedLength
		{
			get { return Stream.BaseStream.Length; }
		}

		public override bool IsWriter
		{
			get { return false; }
		}
	}
}