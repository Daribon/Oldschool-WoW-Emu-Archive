using System;
using System.Collections.Generic;
using System.Text;
using System.Runtime.Serialization;
using System.Runtime.Serialization.Formatters.Soap;
using System.Runtime.Serialization.Formatters.Binary;
using System.IO;
using System.Collections;
using Core.Scripting.ScriptObject;
using Core.Scripting;

namespace Core.Data
{
	[Serializable]
	public class Base : IScope
	{
		public Base()
		{

		}

		private static Base load()
		{
			// there should only be one...
			// we should load the location from our config file
			BaseAccess settings = new BaseAccess();
			
			if (settings.IsBinaryFormatted)
				Base.Formatter = new BinaryFormatter();
			else
				Base.Formatter = new SoapFormatter();

			string filename = settings.IsBinaryFormatted ? settings.BinaryDataFile : settings.SoapDataFile;
			Stream writer;

			try
			{
				writer = File.Open(filename, FileMode.Open);
			}
			catch (FileNotFoundException)
			{
				Base b = new Base();
				b.SerializeOnFinish = true;
				return b;
			}

			Base the_base;
			try
			{
				the_base = (Base)Formatter.Deserialize(writer);
				new Event(Event.Type.DatabaseLoaded, Logger.Priority.GlobalState).Dispatch();
			}
			catch (Exception e)
			{
				Logger.Log(Logger.Priority.Error, "SerializationException while Deserializing database: {0}", e);
				new Event(Event.Type.DatabaseCleared, Logger.Priority.GlobalState).Dispatch();
				the_base = new Base();
			}
			finally
			{
				writer.Close();
			}

			the_base.SerializeOnFinish = true;
			return the_base;
		}

		protected static Base singleton;
		public static Base Singleton
		{
			get
			{
				if (singleton == null)
					singleton = load();

				return singleton;
			}
		}

		/// <summary>
		/// Completely clear the contents of the database
		/// </summary>
		public static void Clear()
		{
			singleton = new Base();
			new Event(Event.Type.DatabaseCleared, Logger.Priority.GlobalState).Dispatch();
		}

		/// <summary>
		/// Reload the database from file
		/// </summary>
		public static void Reload()
		{
			singleton = load();
		}

		~Base()
		{
			if (SerializeOnFinish)
			{
				BaseAccess settings = new BaseAccess();

				string filename = settings.SoapDataFile;

				Stream writer = File.Open(filename, FileMode.Create);
				Formatter.Serialize(writer, this);
				writer.Close();
			}
		}

		internal static IFormatter Formatter;

		[NonSerialized]
		bool SerializeOnFinish = false;

		#region Users
		// generics == SOAP sadness. Aah well..
		private Hashtable Users = Hashtable.Synchronized(new Hashtable());

		public User GetUser(string username)
		{
			username = username.ToUpper();
			if (Users.ContainsKey(username) == false)
				return null;
			else
				return (User)Users[username];
		}
		public void AddUser(User user)
		{
			Users[user.Name] = user;
			new Event(Event.Type.UserAdded, user, Logger.Priority.ClientState).Dispatch();
		}

		public void AddDebuggingUsers()
		{
			if (GetUser("a") == null)
				AddUser(new ServerUser("a", "a"));
		}
		#endregion

		#region realm list
		[NonSerialized]
		public Realm.List RealmList = new Core.Data.Realm.List();

		[OnDeserialized]
		internal void InitRealmList(StreamingContext context)
		{
			RealmList = new Core.Data.Realm.List();
		}
		#endregion

		#region script scope
		ScriptScope scriptScope = new ScriptScope();
		public ScriptScope ScriptScope { get { return scriptScope; } }

		static Base ResolveScope(Session client)
		{
			return Singleton;
		}
		#endregion
	}
}
