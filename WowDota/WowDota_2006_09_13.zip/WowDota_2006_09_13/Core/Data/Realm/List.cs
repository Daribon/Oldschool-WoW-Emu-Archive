using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;
using Core.Data.Client;
using System.Collections;

namespace Core.Data.Realm
{
	public class List
	{
		ArrayList servers = new ArrayList();

		public List()
		{

		}

		internal void Add(Core.Networking.RealmServer server)
		{
			servers.Add(server.Data);
		}

		internal void Add(RealmInfo server)
		{
			servers.Add(server);
		}

		public void Bind(Session connection, Binder binder)
		{
			byte num = 0;
			if (binder.IsReader)
			{
				binder.Bind(ref num);
				servers = new ArrayList(num);

				for (int i = 0; i < num; i++)
				{
					RealmInfo server = new RealmInfo();
					server.Bind(connection, binder);
					servers.Add(server);
				}
			}
			else
			{
				num = (byte)servers.Count;
				binder.Bind(ref num);

				for (int i = 0; i < num; i++)
				{
					((RealmInfo)servers[i]).Bind(connection, binder);
				}
			}
		}
	}
}
