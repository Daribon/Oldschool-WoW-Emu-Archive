using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Serialisation;
using Core.Data.Client;

namespace Core.Data.Realm
{
	public enum Timezone : byte
	{
		USA = 0x01,
		Oceanic = 0x05
	}

	public enum Status : byte
	{
		Good = 0x00,
		Full = 0x01,
		Offline = 0x02
	}

	public enum Type : uint
	{
		Normal = 0x00,
		PVP = 0x01,
		RP = 0x06,
		RPPVP = 0x08,
	}

	internal class RealmInfo
	{
		private static byte NumServers = 1;

		public RealmInfo()
		{
			ID = NumServers;
			NumServers++;
		}

		public RealmInfo(string name, string address)
			: this()
		{
			this.Name = name;
			this.Address = address;
		}

		uint type = (uint)Type.PVP;
		public Type Type
		{
			get { return (Type)type; }
			set { type = (uint)value; }
		}

		byte status = (byte)Status.Good;
		public Status Status
		{
			get { return (Status)status; }
			set { status = (byte)value; }
		}

		public string Name = "Unnamed Server";
		public string Address;
		
		const float NewServerSentinalCapacity = 200.0f;
		public float UsedCapacity = 0.0f;
		public bool IsNew = false;

		byte timezone = (byte)Timezone.Oceanic;
		public Timezone Timezone
		{
			get { return (Timezone)timezone; }
			set { timezone = (byte)value; }
		}

		public byte ID;

		#region IBindable Members

		public void Bind(Session connection, Binder binder)
		{
			binder.Bind(ref type);
			binder.Bind(ref status);

			binder.BindCStr(ref Name);
			binder.BindCStr(ref Address); // eg. 127.0.0.1:3724

			if (binder.IsReader)
			{
				binder.Bind(ref UsedCapacity);
				if (UsedCapacity == NewServerSentinalCapacity)
				{
					IsNew = true;
				}
			}
			else
			{
				if (IsNew)
				{
					float cap = NewServerSentinalCapacity;
					binder.Bind(ref cap);
				}
				else
					binder.Bind(ref UsedCapacity);
			}
			
			byte num_characters = 7;
			binder.Bind(ref num_characters);

			byte timezone_byte = (byte)Timezone;
			binder.Bind(ref timezone_byte);
			Timezone = (Timezone)timezone_byte;

			binder.Bind(ref ID);
		}

		#endregion
	}
}
