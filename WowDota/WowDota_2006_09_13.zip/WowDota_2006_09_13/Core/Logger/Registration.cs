using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking;
using Core.Networking.Packet;
using Core.Data.Client;
using Core.Scripting.ProcessPacket;

namespace Core
{
	partial class Logger
	{
		#region registration
		public static void RegisterPacketManager()
		{
/*			PacketManager.OnRecievedPacket += RecievedPacket;
			PacketManager.OnUnhandledPacket += UnhandledPacket;
			PacketManager.OnSendPacket += SendPacket;

			PacketManager.OnRegisteredScriptHandler += RegisteredHandler;
			PacketManager.OnRegisteredStaticHandler += RegisteredHandler;
*/		}

		public static void Register(LoginServer login_server)
		{
/*			login_server.ConnectHandler += LoginConnectHandler;
			login_server.DisconnectHandler += LoginDisconnectHandler;
*/		}

		public static void Register(RealmServer server)
		{
/*			server.ConnectHandler += RealmConnectHandler;
			server.DisconnectHandler += RealmDisconnectHandler;

			server.SentDataHandler += RealmSentDataHandler;
			server.RecievedDataHandler += RealmRecievedDataHandler;
*/		}

		public static void RegisterEverything(LoginServer login_server, RealmServer[] realm_servers)
		{
			if (login_server != null)
				Register(login_server);

			foreach (RealmServer realm_server in realm_servers)
			{
				if (realm_servers != null)
					Register(realm_server);
			}

			RegisterPacketManager();
		}
		#endregion
		/*
		#region realm handlers

		void RealmSentDataHandler(RemoteEndpoint client, Core.Networking.Packet.BasePacket packet)
		{
			Log(Verbosity.High, "RealmServer sent data {0}", packet);
			LogWrite(Verbosity.ExtremelyHigh, packet);
		}

		void RealmRecievedDataHandler(RemoteEndpoint client, BasePacket packet)
		{
			LogMessage(Verbosity.High, "RealmServer recieved data {0}", packet);
			LogWrite(Verbosity.ExtremelyHigh, packet);
		}

		void RealmConnectHandler(RemoteEndpoint client)
		{
			LogMessage(Verbosity.Medium, "New realm server client: " + client);
		}

		void RealmDisconnectHandler(RemoteEndpoint client)
		{
			LogMessage(Verbosity.Medium, "Disconnected realm server client: " + client);
		}

		#endregion

		#region login handlers

		// yeah... i could pull out a lot of common code here.
		void LoginConnectHandler(RemoteEndpoint client)
		{
			LogMessage(Verbosity.Medium, "Login server client connected: " + client);
		}

		void LoginDisconnectHandler(RemoteEndpoint client)
		{
			LogMessage(Verbosity.Medium, "Login server client disconnected: " + client);
		}

		#endregion

		#region packet manager
		void RegisteredHandler(System.Reflection.MethodInfo method, Core.Data.MessageId message)
		{
			LogMessage(Verbosity.High, "Registering {0} for {1}", method.Name, message);
		}

		void RecievedPacket(Session client, DataPacket packet)
		{
			LogMessage(Verbosity.Medium, "Handling recieved packet: {0} from {1}", packet, client);
			LogWrite(Verbosity.High, packet);
		}

		void SendPacket(Session client, DataPacket packet)
		{
			LogMessage(Verbosity.Medium, "Crafted packet to send: {0} to {1}", packet, client);
			LogWrite(Verbosity.High, packet);
		}

		void UnhandledPacket(Session client, DataPacket packet)
		{
			LogMessage(Verbosity.Warning, "Recieved unhandled packet: {0} from {1}", packet, client);
			LogWrite(Verbosity.Warning, packet);
		}
		#endregion
		*/
	}
}
