using System;
using System.Collections.Generic;
using System.Text;

namespace Core
{
	public class ConsoleLogger : TextLogger
	{
		public ConsoleLogger(Verbosity verbosity)
			: base(Console.Out, verbosity)
		{ }

		public static ConsoleColor GetFGColour(Priority priority)
		{
			switch (priority)
			{
				case Priority.ExtremelyHigh:
				case Priority.Error:
					return ConsoleColor.Red;

				case Priority.High:
				case Priority.Warning:
					return ConsoleColor.Yellow;

				case Priority.Medium:
					return ConsoleColor.White;

				case Priority.Low:
				case Priority.ExtremelyLow:
					return ConsoleColor.Gray;

				case Priority.ClientState:
					return ConsoleColor.Cyan;
				case Priority.GlobalState:
					return ConsoleColor.Green;

				default:
					throw new NotImplementedException();
			}
		}

		public override void LogMessage(Priority message_priority, string message)
		{
			if (ShouldILog(message_priority))
			{
				lock (Console.Out)
				{
					ConsoleColor old_fg_colour = Console.ForegroundColor;

					Console.ForegroundColor = GetFGColour(message_priority);
					// we need to make the colour stick somehow

					Console.WriteLine(message);

					Console.ForegroundColor = old_fg_colour;
				}
			}
		}
	}
}
