using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking.Packet;
using System.IO;
using Core.Scripting;

namespace Core
{
	public abstract partial class Logger
	{
		public Logger(Verbosity verbosity)
		{
			this.VerbosityValue = verbosity;
		}

		public static void Register(Logger logger)
		{
			OnLogMessage += logger.LogMessage;
		}

		public enum Verbosity
		{
			VeryHigh,
			High,
			Medium,
			Low,
			VeryLow,
			ErrorsOnly = VeryLow,
		}

		/// <summary>
		/// Priority has an inverted relationship with verbosity.
		/// </summary>
		public enum Priority
		{
			ExtremelyHigh = Verbosity.VeryLow,
			High = Verbosity.Low,
			Medium = Verbosity.Medium,
			Low = Verbosity.High,
			ExtremelyLow = Verbosity.VeryHigh,

			Special = 100,
			Error = Special,
			Warning,
			GlobalState,
			ClientState
		}

		protected Verbosity GetRequiredVerbosity(Priority priority)
		{
			if ((int)priority >= (int)Priority.Special)
			{
				switch (priority)
				{
					case Priority.Error:
						return Verbosity.ErrorsOnly;
					case Priority.Warning:
					case Priority.GlobalState:
						return Verbosity.Low;
					case Priority.ClientState:
						return Verbosity.Medium;
					default:
						throw new NotImplementedException();
				}
			}
			else
				return (Verbosity)priority;
		}

		protected Verbosity VerbosityValue;

		protected bool HasAtLeast(Verbosity required_verbosity)
		{
			return (int)VerbosityValue <= (int)required_verbosity;
		}
		protected bool ShouldILog(Priority message_priority)
		{
			return HasAtLeast(GetRequiredVerbosity(message_priority));
		}

		public abstract void LogMessage(object source, Priority message_priority, string message);

		public delegate void LogMessageDelegate(object source, Priority message_priority, string message);
		public static event LogMessageDelegate OnLogMessage;

		/// <summary>
		/// Log a message to all loggers.
		/// </summary>
		/// <param name="source">the object from whence the message comes</param>
		/// <param name="required_verbosity">verbosity of the message</param>
		/// <param name="message">the message, without a trailing newline</param>
		public static void Log(object source, Priority message_priority, string message)
		{
			if (OnLogMessage != null)
				OnLogMessage(source, message_priority, message);
		}

		public static void Log(Priority message_priority, string message)
		{
			if (OnLogMessage != null)
				OnLogMessage(null, message_priority, message);
		}

		public static void Log(object source, Priority message_priority, string format, params object[] args)
		{
			Log(source, message_priority, string.Format(format, args));
		}

		public static void Log(Priority message_priority, string format, params object[] args)
		{
			if (OnLogMessage != null)
				OnLogMessage(null, message_priority, string.Format(format, args));
		}

		public static void Log(IDescribable source, Priority message_priority)
		{
			Log(source, message_priority, null);
		}

		[EventHandler(Event.Type.Any)]
		static void LogEvent(Event the_event)
		{
			Log(the_event, the_event.EventLoggingPriority);
		}
	}
}
