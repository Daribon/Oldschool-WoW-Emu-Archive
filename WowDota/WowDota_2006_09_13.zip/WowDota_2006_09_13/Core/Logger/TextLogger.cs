using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking;
using System.IO;
using Core.Scripting.ProcessPacket;
using Core.Data.Client;
using Core.Networking.Packet;

namespace Core
{
	public class TextLogger : Logger
	{
		/// <summary>
		/// Load the logger but don't register any of its handlers.
		/// 
		/// The user must do this themself by calling the Register() functions
		/// </summary>
		/// <param name="destination"></param>
		/// <param name="verbosity"></param>
		public TextLogger(TextWriter destination, Verbosity verbosity)
			: base(verbosity)
		{
			this.Destination = TextWriter.Synchronized(destination);
		}

		private TextWriter Destination;

		public virtual void LogMessage(Priority message_priority, string message)
		{
			if (ShouldILog(message_priority))
			{
				Destination.WriteLine(message);
				Destination.Flush();
			}
		}

		public void LogMessage(Priority message_priority, string format, params object[] parameters)
		{
			LogMessage(message_priority, string.Format(format, parameters));
		}

		public override void LogMessage(object source, Priority message_priority, string message)
		{
			if (source != null)
			{
				IDescribable describable_source = source as IDescribable;
				if (describable_source != null)
				{
					StringWriter writer = new StringWriter();
					writer.Write(message);
					describable_source.Describe((Verbosity)message_priority, writer);
					LogMessage(message_priority, writer.ToString());
					//Log((object)source, message_priority, writer.ToString());
				}
				else if (message != null && message != "")
					LogMessage(message_priority, "{0}: {1}", source, message);
				else
					LogMessage(message_priority, "{0}", source);
			}
			else
				LogMessage(message_priority, message);
		}
	}
}
