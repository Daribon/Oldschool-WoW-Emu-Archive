using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Core
{
	public interface IDescribable
	{
		void Describe(Logger.Verbosity verbosity, TextWriter description);
	}
}
