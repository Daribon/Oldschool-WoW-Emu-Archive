using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Core
{
	public class FileLogger : TextLogger
	{
		public FileLogger(FileStream file, Verbosity verbosity)
			: base(new StreamWriter(file), verbosity)
		{ }

		public FileLogger(string filename, Verbosity verbosity)
			: this(new FileStream(filename, FileMode.Append), verbosity)
		{ }
	}
}
