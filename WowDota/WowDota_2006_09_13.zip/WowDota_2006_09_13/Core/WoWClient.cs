using System;
using System.Collections.Generic;
using System.Net.Sockets;

namespace Networking
{
	class WoWClient : RemoteEndpoint
	{
		public WoWClient(Socket sock) : base(sock)
		{
			
		}
		//		protected PacketBuffer m_packet_header;
		//		protected PacketBuffer m_packet_data;

		public byte[] Hash;
		public byte[] key = { 0, 0, 0, 0 };
		public bool Authenticated = false;

		#region Packet size calculations
		/// <summary>
		/// Get the size of just the header. Overridding me is a good idea.
		/// </summary>
		public virtual int PacketHeaderSize
		{
			get
			{
				return 4;
			}
		}

		/// <summary>
		/// Size of the packet data. May require header to be read in already.
		/// </summary>
/*		public virtual int PacketDataSize
		{
			get
			{
				int size = BitConverter.ToInt32(m_packet_header.Peek(), 0);
				if (size > 0xFFFF || size == 0)
					throw new Exception("Corrupt packet(size=" + string.Format("0x{0:X}", size) + ").");
				return size;
			}
		}
*/		
#endregion

		#region Encryption
		public void Encode(byte[] data)
		{
			for (int t = 0; t < 4; t++)
			{
				byte a = key[3];
				a = (byte)(Hash[a] ^ data[t]);
				byte d = key[2];
				a += d;
				data[t] = a;
				key[2] = a;
				a = key[3];
				a++;
				key[3] = (byte)(a % 0x28);
			}
		}

		public void Decode(byte[] data, int size)
		{
			for (int t = 0; t < size; t++)
			{
				byte a = key[0];
				key[0] = data[t];

				byte b = data[t];
				b = (byte)(b - a);

				byte d = key[1];
				a = Hash[d];
				a = (byte)(a ^ b);
				data[t] = a;

				a = key[1];
				a++;
				key[1] = (byte)(a % 0x28);
			}
		}

		public void Decode(byte[] data)
		{
			Decode(data, data.Length);
		}
#endregion
		

		/*
		 * 
		 * 		if (buf.Full)
				{
					if (readingHeader)
					{
						if (Authenticated)
						{
							Decode(m_packet_header.Peek());
						}
						//						System.Console.WriteLine("in {0} Finished reading header. Data {1}, {2}", this,
						//							m_packet_header, BitConverter.ToInt32(m_packet_header.Peek(), 0));

						m_packet_data = new PacketBuffer(PacketDataSize);
						OnReadHeader(buf.Peek());
					}
					else
					{
						//						System.Console.WriteLine("in {0} Finished reading data, size {1}", this, buf.BytesRead);
						byte[] packet_header = m_packet_header.Extract();
						byte[] packet_data = m_packet_data.Extract();

						byte[] buffer = new byte[packet_header.Length + packet_data.Length];
						packet_header.CopyTo(buffer, 0);
						packet_data.CopyTo(buffer, packet_header.Length);

						OnReadData(buffer);
					}

					registerRecieveCallback(!readingHeader);
				}
				else
				{
					registerRecieveCallback(readingHeader);
				} */


		protected override PacketBuffer GetPacketBuffer(Object packetinfo)
		{
			return null;//m_recievePacket;
		}

		protected override Object RecievedPacket(byte[] data, Object packetinfo)
		{
		/*	if (RemoteDataHandler != null)
			{
				RemoteDataHandler(this, data);
			}
		*/	return null;
		}

		#region Interface
		protected virtual void OnReadHeader(byte[] data)
		{

		}

		protected virtual void OnReadData(byte[] data)
		{
//			if (RemoteDataHandler != null)
//			{
//				RemoteDataHandler(this, data);
//			}
		}
		#endregion


	}
}
