using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Core
{
	static class ReflectionHelper
	{
		/// <summary>
		/// This should be supplied as part of the system library.
		/// 
		/// Works out whether or not the types given satisfy the generic method constraints
		/// </summary>
		/// <param name="type"></param>
		/// <param name="generic_method_definition"></param>
		/// <returns></returns>
		public static bool SatisfiesGenericConstraints(MethodInfo generic_method_definition, params Type[] types)
		{
			Type[] generic_types = generic_method_definition.GetGenericArguments();

			if (generic_types.Length != types.Length)
				return false;

			for (int i = 0; i < types.Length; i++)
			{
				Type type = types[i];
				Type generic_type = generic_types[i];

				if ((generic_type.GenericParameterAttributes & GenericParameterAttributes.DefaultConstructorConstraint)
								!= GenericParameterAttributes.None
						&& type.IsValueType == false && type.GetConstructor(Type.EmptyTypes) == null)
					return false;

				if ((generic_type.GenericParameterAttributes & GenericParameterAttributes.NotNullableValueTypeConstraint)
								!= GenericParameterAttributes.None
						&& type.IsValueType == false)
					return false;

				if ((generic_type.GenericParameterAttributes & GenericParameterAttributes.ReferenceTypeConstraint)
								!= GenericParameterAttributes.None
						&& type.IsValueType == true)
					return false;

				foreach (Type required_parent in generic_type.GetGenericParameterConstraints())
				{
					if (required_parent != type.BaseType
						&& type.GetInterface(required_parent.Name) == null)
						return false;
				}
			}

			return true;
		}

		/// <summary>
		/// Can we create a delegate of some type out of this method?
		/// Checks parameter list and return value and such.
		/// 
		/// This does not handle generic method definitions.
		/// </summary>
		/// <typeparam name="DelegateType">delegate to create</typeparam>
		/// <param name="method"></param>
		/// <returns></returns>
		public static bool CanCreateDelegate<DelegateType>(MethodInfo method)
		{
			Type delegate_type = typeof(DelegateType);
			MethodInfo invoke = delegate_type.GetMethod("Invoke");

			if (invoke.ReturnType != method.ReturnType)
				return false;

			ParameterInfo[] method_params = method.GetParameters();
			ParameterInfo[] delegate_params = method.GetParameters();

			if (method_params.Length != delegate_params.Length)
				return false;

			for (int i = 0; i < method_params.Length; i++)
			{
				if (method_params[i].GetType() != delegate_params[i].GetType())
					return false;
			}

			return true;
		}
	}
}
