using System;
using System.Collections.Generic;
using System.Text;
using System.Collections;

namespace Core.Scripting.ScriptObject
{
	[Serializable]
	public class ScriptScope
	{
		Hashtable bindings = new Hashtable();
			// Dictionary<Type, object> bindings = new Dictionary<Type,object>();

		bool TryGetValue(Type type, out object value)
		{
			if (bindings.ContainsKey(type) == false)
			{
				value = null;
				return false;
			}
			else
			{
				value = bindings[type];
				return true;
			}
		}

		public object Get(Type type, bool create)
		{
			lock (bindings)
			{
				object obj;
				if (TryGetValue(type, out obj) == true)
					return obj;
				else
				{
					if (create)
					{
						obj = Activator.CreateInstance(type);
						bindings[type] = obj;
						return obj;
					}
					else
						return null;
				}
			}
		}

		public object Get(Type t)
		{
			return Get(t, false);
		}

		public ScriptObject Get<ScriptObject>(bool create)
		{
			return (ScriptObject)Get(typeof(ScriptObject), create);
		}

		public ScriptObject Get<ScriptObject>()
		{
			return Get<ScriptObject>(false);
		}

		public void Set(Type type, object obj)
		{
			lock (bindings)
			{
				bindings[type] = obj;
			}
		}

		public void Set<ScriptObject>(ScriptObject obj)
		{
			Set(typeof(ScriptObject), obj);
		}

		public void Clear()
		{
			bindings.Clear();
		}
	}
}
