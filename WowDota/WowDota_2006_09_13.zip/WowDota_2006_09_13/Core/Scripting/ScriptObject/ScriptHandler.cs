using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Core.Scripting.ScriptObject
{
	public class ScriptHandler<Identifier, HandlerDelegate>
	{
		Type ScriptScopeType;
		Type ScriptObjectType;

		public delegate HandlerDelegate MakeHandlerDelegateFromDelegate(MethodInfo method, object scriptobject);
		public MakeHandlerDelegateFromDelegate MakeHandlerDelegateFrom;

		public HandlerDelegate Handler;

		#region constructor stuff
		protected internal ScriptHandler(ScriptObjectAttribute scriptobject_attribute,
			Type scriptobject_type, HandlerDelegate handler)
		{
			if (scriptobject_attribute != null)
				ScriptScopeType = scriptobject_attribute.Scope;
			ScriptObjectType = scriptobject_type;
			MakeHandlerDelegateFrom = this.DefaultMakeHandlerDelegateFrom;
			Handler = handler;
		}
		
		protected internal ScriptHandler(Type scriptobject_type, HandlerDelegate handler)
			: this(TryGetScriptAttribute(scriptobject_type), scriptobject_type, handler)
		{
		}

		/// <summary>
		/// Try to get the script attribute applied to the type. This is needed to create
		/// a script handler.
		/// </summary>
		/// <param name="type"></param>
		/// <returns></returns>
		public static ScriptObjectAttribute TryGetScriptAttribute(Type type)
		{
			ScriptObjectAttribute[] script_object_attributes = (ScriptObjectAttribute[])
				type.GetCustomAttributes(typeof(ScriptObjectAttribute), false);

			if (script_object_attributes.Length > 1)
				throw new NotSupportedException("Multiple ScriptObjectAttributes on any single class is not supported");

			if (script_object_attributes.Length > 0)
				return script_object_attributes[0];
			else
				return null;
		}

		#endregion

		public bool IsGood
		{
			get
			{
				return Handler != null && ScriptScopeType != null;
			}
		}

		internal struct HandlerElement
		{
			internal HandlerElement(Identifier messageid, MethodInfo method)
			{
				this.Message = messageid;
				this.Method = method;
			}
			internal Identifier Message;
			internal MethodInfo Method;
		}
		/// <summary>
		/// This is a list of all the handlers our sponsor script type has
		/// </summary>
		List<HandlerElement> handler_methods;

		public void AddHandlerMethod(Identifier message, MethodInfo method)
		{
			if (method.IsStatic)
				throw new ArgumentException(string.Format("Cannot add static method {0} as a script handler method", method));
			if (handler_methods == null)
				handler_methods = new List<HandlerElement>();
			handler_methods.Add(new HandlerElement(message, method));
		}

		public struct MessageBinding
		{
			public MessageBinding(Session session, Identifier id)
			{
				this.Session = session;
				this.Identifier = id;
			}

			public Session Session;
			public Identifier Identifier;

			public override int GetHashCode()
			{
				return Identifier.GetHashCode() ^ Session.GetHashCode();
			}
		}

		/// <summary>
		/// The handler cache caches all script methods into the connection.
		/// 
		/// Basically, the idea is that the first time a script object is used all its methods
		/// are cached against the connection. That way we don't have to go searching for the object
		/// every time.
		/// 
		/// Yes, this is a premature optimisation. Yes, I'm a bad person. 
		/// 
		/// Yes, I've come to regret it on the third time I've refactored the code.
		/// </summary>
		Dictionary<MessageBinding, HandlerDelegate> handler_cache;

		virtual protected internal HandlerDelegate DefaultMakeHandlerDelegateFrom(MethodInfo method, object scriptobject)
		{
			return (HandlerDelegate)(object)Delegate.CreateDelegate(typeof(HandlerDelegate), scriptobject, method);
		}

		void PopulateSessionHandlerCache(Session session)
		{
			if (handler_methods == null)
				return; 
			
			if (handler_cache == null)
				handler_cache = new Dictionary<MessageBinding, HandlerDelegate>();

			object scriptobject = ScopeResolver.ResolveScope(session, ScriptScopeType)
					.ScriptScope.Get(ScriptObjectType, true);

			int num_registered_handlers = 0;

			foreach (HandlerElement element in handler_methods)
			{
				MessageBinding binding = new MessageBinding(session, element.Message);
				
				HandlerDelegate fn = MakeHandlerDelegateFrom(element.Method, scriptobject);

				handler_cache[binding] = fn;
				num_registered_handlers++;
			}

			if (num_registered_handlers > 0)
				EventManager.Singleton.RegisterHandler(Event.Type.ClientDisconnected, ClearClientPacketHandlerCache);
		}

		/// <summary>
		/// The connection is closing. We need to clear it from our connection cache
		/// else it can't properly dispose.
		/// 
		/// Interestingly, this will be called twice - once for a lo
		/// </summary>
		/// <param name="connection"></param>
		void ClearClientPacketHandlerCache(Event disconnection_event)
		{
			Session session = disconnection_event.Session;

			MessageBinding binding;
			binding.Session = session;

			foreach (HandlerElement element in handler_methods)
			{
				binding.Identifier = element.Message;

				handler_cache.Remove(binding);
			}
		}

		public HandlerDelegate GetDelegate(MessageBinding binding, Session session)
		{
			HandlerDelegate fn;
			if (handler_cache != null && handler_cache.TryGetValue(binding, out fn) == true)
			{
				return fn;
			}
			else
			{
				PopulateSessionHandlerCache(session);

				if (handler_cache.ContainsKey(binding) == false)
				{
					throw new ArgumentException(string.Format("I don't have a handler for {0}", binding.Identifier));
				}

				// I love recursion
				return GetDelegate(binding, session);
			}
		}
	}
}
