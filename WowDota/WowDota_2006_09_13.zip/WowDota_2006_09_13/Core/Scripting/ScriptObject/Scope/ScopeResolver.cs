using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Core.Scripting.ScriptObject
{
	public class ScopeResolver
	{
		public static IScope ResolveScope(Session client, Type scope)
		{
			MethodInfo method = scope.GetMethod("ResolveScope", BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic);

			if (method == null)
				throw new InvalidProgramException(string.Format("Scope {0} does not implement ResolveScope for scope resolution"));

			object[] args = { client };
			object scope_obj = method.Invoke(null, args);
			return (IScope)scope_obj;
		}

		public static IScope ResolveScope<Scope>(Session client) where Scope : IScope
		{
			return ResolveScope(client, typeof(Scope));
		}

		public static Type ResolveObject<Scope, Type>(Session client, bool create) where Scope : IScope
		{
			return ResolveScope<Scope>(client).ScriptScope.Get<Type>(create);
		}
	}
}
