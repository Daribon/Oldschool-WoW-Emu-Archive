using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Core.Scripting.ScriptObject
{
	/// <summary>
	/// Defines this object as a scope for script objects to reside in.
	/// 
	/// Scopes must also define a static function Scope ResolveScope(Session client)
	/// where Scope is the object type.
	/// </summary>
	public interface IScope
	{
		ScriptScope ScriptScope { get; }
	}
}
