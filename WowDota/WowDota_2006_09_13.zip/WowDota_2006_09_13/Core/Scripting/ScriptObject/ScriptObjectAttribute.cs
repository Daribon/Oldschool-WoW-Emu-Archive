using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;

namespace Core.Scripting.ScriptObject
{
	/*
	public enum Scope
	{
//		Realm,
		Database,	// As global as they come
		Session,	// Transient for this connection to the client
		User,		// User data - alive until the account is deleted
		Character,
//		Item,
//		Guild,
	}*/

	// I would make this generic, but I'm not allowed. (at least in .NET 2.0)
	// Bastards.

	[AttributeUsage(AttributeTargets.Class, AllowMultiple = false)]
	public class ScriptObjectAttribute : Attribute
	{
		public ScriptObjectAttribute(Type Scope)
		{
			if (Scope.GetInterface("IScope") == null)
				throw new InvalidOperationException("To use this attribute you must implement IScope");

			// This check should happen in the scope itself but I can't.. here will have to do.
			if (Scope.GetMethod("ResolveScope",
				BindingFlags.Static | BindingFlags.Public | BindingFlags.NonPublic) == null)
				throw new ArgumentException(string.Format("Scope {0} does not implement ResolveScope", Scope));

			this.Scope = Scope;
		}

		internal Type Scope;
	}
}
