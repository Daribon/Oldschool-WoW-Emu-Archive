using System;
using System.Collections.Generic;
using System.Reflection;
using Core.Data;

namespace Core.Scripting.Handler
{
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
	public class HandlerAttribute : System.Attribute
	{
		protected HandlerAttribute(object identifier)
		{
			this.Identifier = identifier;
		}

		object identifier;

		public object Identifier
		{
			get { return identifier; }
			set { identifier = value; }
		}
		public Id GetIdentifier<Id>()
		{
			return (Id)Identifier;
		}
	}
}
