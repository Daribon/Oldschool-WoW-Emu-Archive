using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Scripting.Handler
{
	class MultipleHandlersException : Exception
	{
		public MultipleHandlersException(object id)
			: base(string.Format("Multiple handlers registered for message {0}", id))
		{ }
	}
}
