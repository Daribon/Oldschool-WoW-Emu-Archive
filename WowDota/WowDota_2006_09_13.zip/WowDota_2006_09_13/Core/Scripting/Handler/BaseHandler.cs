using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Core.Scripting.ScriptObject;
using Core.Networking.Packet;

namespace Core.Scripting.Handler
{
	/// <summary>
	/// Handle some type of event.
	/// </summary>
	public abstract class BaseHandler<Identifier, HandlerDelegate, HandlerAttribute>
		where HandlerAttribute : Core.Scripting.Handler.HandlerAttribute
	{
		protected Dictionary<Identifier, HandlerDelegate> Handlers
			= new Dictionary<Identifier, HandlerDelegate>();

		#region Register handlers

		protected virtual bool AllowMultiple
		{
			get
			{
				return false;
			}
		}

		/// <summary>
		/// Register function fn to be called for message type type.
		/// 
		/// if the messageid's id isn't known this will make an unhandled packet handler.
		/// </summary>
		/// <param name="type"></param>
		/// <param name="fn"></param>
		public virtual void RegisterHandler(Identifier type, HandlerDelegate fn)
		{
			if (Handlers.ContainsKey(type) == false)
				Handlers[type] = fn;
			else if (AllowMultiple)
			{
				Delegate current = (Delegate)(object)Handlers[type];
				Delegate new_delegate = (Delegate)(object)fn;
				Handlers[type] = (HandlerDelegate)(object)Delegate.Combine(current, new_delegate);
			}
			else
				throw new MultipleHandlersException(type);
		}

		public virtual HandlerDelegate MakeHandlerDelegateFrom(MethodInfo method, object obj)
		{
			// If its a static method we don't want to bind it to the object
			if (method.IsStatic)
				obj = null;

			// typecasting hack :D (why can't I require a generic type param extends delegate?)
			return (HandlerDelegate)(object)
				Delegate.CreateDelegate(typeof(HandlerDelegate), obj, method);
		}

		protected abstract ScriptHandler<Identifier, HandlerDelegate> MakeScriptHandler(Type type);

		public void Register(Type type)
		{
			MethodInfo[] methods = type.GetMethods(
				BindingFlags.Instance | BindingFlags.Static
				| BindingFlags.Public | BindingFlags.NonPublic);

			ScriptHandler<Identifier, HandlerDelegate> script_handler = MakeScriptHandler(type);
			if (script_handler != null && script_handler.IsGood == false)
				script_handler = null;

			foreach (MethodInfo method in methods)
			{
				HandlerAttribute[] attributes = (HandlerAttribute[])
						method.GetCustomAttributes(typeof(HandlerAttribute), false);

				if (attributes.Length == 0)
					continue;

				if (method.IsStatic == false && script_handler == null)
					throw new InvalidOperationException("Cannot create handler from instance method unless its a ScriptObject");

				HandlerDelegate _delegate;

				if (method.IsStatic == false)
					_delegate = script_handler.Handler;
				else
					_delegate = MakeHandlerDelegateFrom(method, null);

				foreach (HandlerAttribute attribute in attributes)
				{
					if (script_handler != null && method.IsStatic == false)
						script_handler.AddHandlerMethod(attribute.GetIdentifier<Identifier>(), method);

					RegisterHandler(attribute.GetIdentifier<Identifier>(), _delegate);

					Logger.Log(Logger.Priority.Low, "Registered handler for {0} for {1}", method.Name, attribute.Identifier);
				}
			}
		}

		#endregion
	}
}
