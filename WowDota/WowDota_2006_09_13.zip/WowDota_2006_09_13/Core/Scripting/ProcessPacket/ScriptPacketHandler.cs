using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ProcessPacket;
using Core.Scripting.ScriptObject;
using System.Reflection;
using Core.Data;

namespace Core.Scripting.ProcessPacket
{
	class ScriptPacketHandler : ScriptHandler<MessageId, PacketManager.PacketHandlerDelegate>
	{
		protected internal ScriptPacketHandler(ScriptObjectAttribute scriptobject_attribute, Type scriptobject_type)
			: base(scriptobject_attribute, scriptobject_type, null)
		{
		}

		protected internal ScriptPacketHandler(Type obj_type)
			: base(obj_type, null)
		{
			base.Handler = this.PacketHandler;
		}

		/// <summary>
		/// Handle a packet. This is called when any scriptobject's packet handler function is called.
		/// </summary>
		public bool PacketHandler(
			Session session,
			MessageId id,
			Core.Data.Serialisation.Binder binder,
			out MessageId[] responses)
		{
			MessageBinding binding = new MessageBinding(session, id);
			PacketManager.PacketHandlerDelegate fn = GetDelegate(binding, session);
			return fn(session, id, binder, out responses);
		}
	}
}
