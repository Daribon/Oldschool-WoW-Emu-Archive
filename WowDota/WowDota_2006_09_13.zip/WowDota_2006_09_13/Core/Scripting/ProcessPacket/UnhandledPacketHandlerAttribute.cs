using System;
using System.Collections.Generic;
using System.Text;
using Core.Data;

namespace Core.Scripting.ProcessPacket
{
	class UnhandledPacketHandlerAttribute : PacketHandlerAttribute
	{
		/// <summary>
		/// Register this function as an unhandled packet handler for the given service and origin.
		/// For now if you want a handler for both Login and Realm servers, you'll have to add two
		/// attributes.
		/// </summary>
		/// <param name="service"></param>
		/// <param name="origin"></param>
		public UnhandledPacketHandlerAttribute(Service service, Origin origin)
			: base(new MessageId(service, origin))
		{ }

		public UnhandledPacketHandlerAttribute(Service service)
			: base(new MessageId(service, Origin.ServerClient))
		{ }
	}
}
