using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Core.Networking.Packet;
using Core.Scripting.ScriptObject;
using Core.Scripting.Handler;
using Core.Data;

namespace Core.Scripting.ProcessPacket
{
	/// <summary>
	/// For documentation see Documentation.txt in the same directory as this file
	/// </summary>
	public partial class PacketManager : BaseHandler<
		MessageId,
		Core.Scripting.ProcessPacket.PacketManager.PacketHandlerDelegate,
		PacketHandlerAttribute>
	{
		private static PacketManager singleton;
		public static PacketManager Singleton
		{
			get
			{
				if (singleton == null)
					singleton = new PacketManager();
				return singleton;
			}
		}

		// Simple packet handler
		public delegate MessageId[] SimplePacketHandlerDelegate(
			Session session,
			Core.Data.Serialisation.Binder binder);

		// Powerful packet handler
		public delegate bool PacketHandlerDelegate(
			Session session,
			MessageId id,
			Core.Data.Serialisation.Binder binder,
			out MessageId[] responses);

		#region Register handlers

		/// <summary>
		/// Register function fn to be called for message type type.
		/// 
		/// if the messageid's id isn't known this will make an unhandled packet handler.
		/// </summary>
		/// <param name="type"></param>
		/// <param name="fn"></param>
		public override void RegisterHandler(MessageId type, PacketHandlerDelegate fn)
		{
			if (type.Origin == Origin.ServerClient)
			{
				type.Origin = Origin.Server;
				RegisterHandler(type, fn);

				type.Origin = Origin.Client;
				RegisterHandler(type, fn);

				return;
			}

			base.RegisterHandler(type, fn);

			// We won't allow more than one handler for any message type.
			// I could extend this later to support replacing handlers for scripting support
			// or something.. not sure if its worthwhile.
		}

		public override PacketHandlerDelegate MakeHandlerDelegateFrom(
			MethodInfo method,
			object obj)
		{
			// If its a static method we don't want to bind it to the object
			if (method.IsStatic)
				obj = null;

			if (ReflectionHelper.CanCreateDelegate<PacketHandlerDelegate>(method))
			{
				return (PacketHandlerDelegate)
					Delegate.CreateDelegate(typeof(PacketHandlerDelegate), obj, method);
			}
			else if (ReflectionHelper.CanCreateDelegate<SimplePacketHandlerDelegate>(method))
			{
				SimplePacketHandlerDelegate simple_delegate = (SimplePacketHandlerDelegate)
					Delegate.CreateDelegate(typeof(SimplePacketHandlerDelegate), obj, method);

				return new PacketHandlerFunctor(simple_delegate).PacketHandlerDelegate;
			}
			else
			{
				throw new InvalidCastException(string.Format("Cannot make a handler delegate from {0}", method));
			}
		}

		protected override ScriptHandler<MessageId, PacketManager.PacketHandlerDelegate> MakeScriptHandler(Type type)
		{
			ScriptPacketHandler ph = new ScriptPacketHandler(type);
			ph.MakeHandlerDelegateFrom = MakeHandlerDelegateFrom;
			return ph;
		}

		#endregion

		#region Handle Packets

		public bool HandleUnhandledPacket(Session session,
			MessageId id,
			Core.Data.Serialisation.Binder binder,
			out MessageId[] responses)
		{
			responses = null;
			return false;
		}

		public bool HandlePacketBinder(Session session,
			MessageId id,
			Core.Data.Serialisation.Binder binder,
			out MessageId[] responses)
		{
			try
			{
				PacketHandlerDelegate handler;
				Handlers.TryGetValue(id, out handler);

				if (handler == null)
				{
					// lets see if we can find an unhandled packet handler
					MessageId unhandled_id = new MessageId(id.Type);
					Handlers.TryGetValue(unhandled_id, out handler);
				}

				if (handler == null)
				{	// castle sadness
					return HandleUnhandledPacket(session, id, binder, out responses);
				}
				else
				{
					return handler(session, id, binder, out responses);
				}
			}
			catch (PacketParseException e)
			{
				new Event(session, Event.Type.PacketParseException, e, Logger.Priority.Error).Dispatch();
				e.Dispatch(session);
				responses = null;
				return false;
			}
		}

		public bool HandleRecievedPacket(Session session, DataPacket packet)
		{
			new Networking.DataTransferredEvent(Event.Type.PacketHandling, session, packet, Logger.Priority.Low).Dispatch();

//			Logger.Log(packet, Logger.Priority.Medium, "Handling");
			MessageId[] response;
			bool handled = HandlePacketBinder(session, packet.Id, packet.Reader, out response);

			if (handled && response != null)
			{
				foreach (MessageId id in response)
				{
					CreatePacket(session, id);
				}
			}

			if (handled)
			{
				new Networking.DataTransferredEvent(Event.Type.PacketHandled, session, packet, Logger.Priority.Low).Dispatch();
			}
			else
			{
				new Networking.DataTransferredEvent(Event.Type.PacketUnhandled, session, packet, Logger.Priority.Warning).Dispatch();
			}

			return handled;
		}

		public bool CreatePacket(Session session, MessageId message_id)
		{
			DataPacket packet = DataPacket.Make(message_id);
			MessageId[] response; // ignored
			bool handled = HandlePacketBinder(session, message_id, packet.Writer, out response);
			if (handled == true)
				session.Endpoint.Send(packet);
			Logger.Log(packet, Logger.Priority.Low, "Sent with default handler");
			return true;
		}

		#endregion

	}
}
