using System;
using System.Collections.Generic;
using System.Reflection;
using Core.Data;
using Core.Scripting.Handler;

namespace Core.Scripting.ProcessPacket
{
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
	public class PacketHandlerAttribute : HandlerAttribute
	{
		public PacketHandlerAttribute(MessageId handledMessage)
			: base(handledMessage)
		{
			if (handledMessage.IsIdKnown == false
				&& GetType() == typeof(PacketHandlerAttribute))
				throw new ArgumentException("Cannot register a packet handler with an unknown Id. If you want an UnhandledPacketHandler, try UnhandledPacketHandlerAttribute");
		}

		public PacketHandlerAttribute(LoginClientMessage id)
			: this((MessageId)id)
		{ }

		public PacketHandlerAttribute(LoginServerMessage id)
			: this((MessageId)id)
		{ }

		public PacketHandlerAttribute(RealmClientMessage id)
			: this((MessageId)id)
		{ }

		public PacketHandlerAttribute(RealmServerMessage id)
			: this((MessageId)id)
		{ }

		public MessageId HandledMessage
		{
			get
			{
				return base.GetIdentifier<MessageId>();
			}
		}

		bool encryptPacketHeader = true;
		public bool EncryptPacketHeader
		{
			get
			{
				if (HandledMessage.Service == Service.Login)
					return false;
				else
					return encryptPacketHeader;
			}
			set
			{
				if (HandledMessage.Service == Service.Login && value == true)
					throw new InvalidOperationException("Cannot encrypt login server packets");
				else
					encryptPacketHeader = value;
			}
		}
	}
}
