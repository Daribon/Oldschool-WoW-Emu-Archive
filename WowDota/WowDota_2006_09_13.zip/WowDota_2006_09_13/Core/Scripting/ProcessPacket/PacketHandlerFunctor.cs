using System;
using Core.Data;

namespace Core.Scripting.ProcessPacket
{
	/// <summary>
	/// Functor for non-default packet handler functions. This allows us to have packet handler
	/// functions with different signatures.
	/// </summary>
	class PacketHandlerFunctor
	{
		PacketManager.SimplePacketHandlerDelegate simple_handler;

		public PacketHandlerFunctor(PacketManager.SimplePacketHandlerDelegate simple_handler)
		{
			this.simple_handler = simple_handler;
		}

		internal bool PacketHandlerDelegate(
			Session client,
			MessageId id,
			Core.Data.Serialisation.Binder binder,
			out MessageId[] responses)
		{
			responses = simple_handler(client, binder);
			return true;
		}
	}
}
