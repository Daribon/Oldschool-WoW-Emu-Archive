using System;
using System.Collections.Generic;
using System.Text;
using Core.Networking;

namespace Core.Scripting.ProcessPacket
{
	public class PacketParseException : Exception
	{
		public PacketParseException(string message)
			: base(message)
		{
		}

		public PacketParseException(string message, Exception innerexception)
			: base(message, innerexception)
		{
		}

		public virtual void Dispatch(Session connection)
		{
			Logger.Log(this, Logger.Priority.Error, "Error parsing packet. Closing connection {0}", connection);
			connection.Close(Message);
		}
	}
}
