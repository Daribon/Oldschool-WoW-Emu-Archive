using Core.Data.Client;

namespace Core.Scripting
{
	/// <summary>
	/// This is a horrible name. Any assembly that wishes to be searched for scripts and packet
	/// handlers and stuff has to have this attribute applied, with the appropriate version.
	/// </summary>
	[System.AttributeUsage(System.AttributeTargets.Assembly, AllowMultiple=false)]
	public class RegisterScriptsAttribute : System.Attribute
	{
		public RegisterScriptsAttribute(ushort build)
			: this (new Version(build))
		{ }

		public RegisterScriptsAttribute(byte MajorVersion, byte MinorVersion, byte Revision)
			: this (new Version(MajorVersion, MinorVersion, Revision))
		{ }

		public RegisterScriptsAttribute(byte MajorVersion, byte MinorVersion, byte Revision, ushort Build)
			: this(new Version(MajorVersion, MinorVersion, Revision, Build))
		{ }

		internal RegisterScriptsAttribute()
			: this(Version.ExpectedClientVersion)
		{ }

		public RegisterScriptsAttribute(Version version)
		{
			this.Version = version;
		}

		public Version Version;
	}
}
