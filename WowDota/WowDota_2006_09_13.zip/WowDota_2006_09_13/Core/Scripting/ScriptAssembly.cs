using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Core.Scripting.ProcessPacket;

namespace Core.Scripting
{
	public class ScriptAssembly
	{
		public static void Register(Assembly assembly)
		{
			RegisterScriptsAttribute[] attributes = (RegisterScriptsAttribute[])
				assembly.GetCustomAttributes(typeof(RegisterScriptsAttribute), false);

			if (attributes.Length == 0)
				throw new InvalidOperationException(
						string.Format("{0} isn't a registered script handler. Add [ScriptAssemblyAttribute] to your assembly.", assembly));

			if (Data.Client.Version.ExpectedClientVersion.Equals(attributes[0].Version) == false)
				throw new InvalidOperationException(
						string.Format("Version mismatch when loading assembly {0}: Core built against {1} and assembly uses {2}",
						assembly, Data.Client.Version.ExpectedClientVersion, attributes[0].Version));

			foreach (Type type in assembly.GetTypes())
			{
				PacketManager.Singleton.Register(type);
				EventManager.Singleton.Register(type);
			}
		}

		public static void Register(string assemblyname)
		{
			Register(Assembly.Load(assemblyname));
		}

		public static void RegisterCore()
		{
			Register(Assembly.GetExecutingAssembly());
		}

		public static void RegisterMe()
		{
			Register(Assembly.GetCallingAssembly());
		}

		public static void RegisterDefaults()
		{
			RegisterCore();
			Register("Login");
			Register("Realm");
		}
	}
}
