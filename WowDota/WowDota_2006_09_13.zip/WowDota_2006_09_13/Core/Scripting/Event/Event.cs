using System;
using System.Collections.Generic;
using System.Text;
using Core.Data.Client;

namespace Core.Scripting
{
	public partial class Event : IDescribable
	{
		public delegate void EventHandlerDelegate(Event the_event);

		public const Logger.Priority DefaultPriority = Logger.Priority.Low;

		public Event(Session session, Event.Type type, object origin, Logger.Priority priority)
		{
			this.EventType = type;
			this.Session = session;
			this.Origin = origin;
			this.Priority = priority;
		}

		public Event(Session session, Event.Type type, object origin)
			: this(session, type, origin, DefaultPriority)
		{ }

		public Event(Session session, Event.Type type, Logger.Priority priority)
			: this(session, type, null, priority)
		{ }

		public Event(Session session, Event.Type type)
			: this(session, type, null)
		{ }

		public Event(Event.Type type, object origin, Logger.Priority priority)
			: this(null, type, origin, priority)
		{ }

		public Event(Event.Type type, object origin)
			: this(null, type, origin)
		{ }

		public Event(Event.Type type, Logger.Priority priority)
			: this(null, type, null)
		{ }
		
		public Event(Event.Type type)
			: this(null, type, null)
		{ }

		public virtual Logger.Priority EventLoggingPriority
		{
			get
			{
				return Priority;
			}
		}

		public Type EventType;
		public Session Session;
		public object Origin;
		public Logger.Priority Priority = DefaultPriority;

		public virtual void Dispatch()
		{
			EventManager.Dispatch(this);
		}

		public override string ToString()
		{
			return string.Format("{0}", EventType);
		}

		// for logging
		virtual public void Describe(Logger.Verbosity verbosity, System.IO.TextWriter description)
		{
			if (Session != null)
			{
				if (Origin != null)
					description.Write("{0}: {1}.{2}", this, Session, Origin);
				else
					description.Write("{0}: {1}", this, Session);
			}
			else if (Origin != null)
				description.Write("{0}: {1}", this, Origin);
		}
	}
}
