using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Scripting
{
	public partial class Event
	{
		public enum Type
		{
			DatabaseLoaded,
			DatabaseCleared,

			UserAdded,
			UserDeleted,

			ServerStarted,
			ServerStopped,

			ClientConnected,
			ClientDisconnected,

			PacketRecieved,
			PacketSent,

			PacketHandling,
			PacketHandled,
			PacketUnhandled,

			PlayerAuthenticated,

			CharacterLogin,
			CharacterEnterWorld,

			PacketParseException,

			TriggerCinematic,

			Any
		}

	}
}
