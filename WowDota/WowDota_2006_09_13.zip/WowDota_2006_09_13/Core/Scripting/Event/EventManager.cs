using System;
using System.Collections.Generic;
using System.Text;
using System.Reflection;
using Core.Scripting.ScriptObject;

namespace Core.Scripting
{
	public class EventManager : Handler.BaseHandler<Event.Type, Event.EventHandlerDelegate, EventHandlerAttribute>
	{
		private EventManager()
		{
			OnDispatchEvent += _DispatchHandler;
		}

		public event Event.EventHandlerDelegate OnDispatchEvent;

		public delegate void RegisteredEventHandlerDelegate(Event.Type eventType, Event.EventHandlerDelegate fn);
		public event RegisteredEventHandlerDelegate OnRegisteredEventHandler;

		public override void RegisterHandler(Event.Type type, Event.EventHandlerDelegate fn)
		{
			if (OnRegisteredEventHandler != null)
				OnRegisteredEventHandler(type, fn);
			base.RegisterHandler(type, fn);
		}

		protected override bool AllowMultiple
		{
			get
			{
				return true;
			}
		}

		private void _DispatchHandler(Event the_event)
		{
			Event.EventHandlerDelegate handler;
			if (Handlers.TryGetValue(the_event.EventType, out handler))
				handler(the_event);
			if (Handlers.TryGetValue(Event.Type.Any, out handler))
				handler(the_event);
		}

		public static void Dispatch(Event the_event)
		{
			if (Singleton.OnDispatchEvent != null)
				Singleton.OnDispatchEvent(the_event);
		}

		static private EventManager singleton;
		static public EventManager Singleton
		{
			get
			{
				if (singleton == null)
					singleton = new EventManager();

				return singleton;
			}
		}

		protected override ScriptHandler<Event.Type, Event.EventHandlerDelegate> MakeScriptHandler(Type type)
		{
			return new ScriptEventHandler(type);
		}
	}
}
