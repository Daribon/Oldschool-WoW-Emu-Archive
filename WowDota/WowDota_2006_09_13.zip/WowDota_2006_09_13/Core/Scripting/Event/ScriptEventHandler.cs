using System;
using System.Collections.Generic;
using System.Text;
using Core.Scripting.ScriptObject;

namespace Core.Scripting
{
	internal class ScriptEventHandler : ScriptHandler<Event.Type, Event.EventHandlerDelegate>
	{
		protected internal ScriptEventHandler(ScriptObjectAttribute scriptobject_attribute,
			Type scriptobject_type)
			: base(scriptobject_attribute, scriptobject_type, null)
		{
			base.Handler = this.EventHandler;
		}

		protected internal ScriptEventHandler(Type obj_type)
			: base(obj_type, null)
		{
			base.Handler = this.EventHandler;
		}

		public void EventHandler(Event the_event)
		{
			MessageBinding binding = new MessageBinding(the_event.Session, the_event.EventType);
			Event.EventHandlerDelegate fn = GetDelegate(binding, the_event.Session);
			fn(the_event);
		}

	}
}
