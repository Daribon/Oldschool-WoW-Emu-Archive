using System;
using System.Collections.Generic;
using System.Text;

namespace Core.Scripting
{
	/// <summary>
	/// Attribute for functions of the form 'static void EventHandlerDelegate(Event)' to
	/// be able to actually handle events.
	/// </summary>
	[AttributeUsage(AttributeTargets.Method, AllowMultiple=true, Inherited=false)]
	public class EventHandlerAttribute : Handler.HandlerAttribute
	{
		public EventHandlerAttribute(Event.Type type)
			: base(type)
		{
		}
	}
}
