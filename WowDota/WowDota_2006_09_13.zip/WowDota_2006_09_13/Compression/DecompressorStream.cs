using System;
using System.Collections.Generic;
using System.Text;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;
using System.IO;

namespace Compression
{
	public class DecompressorStream : InflaterInputStream
	{
		public DecompressorStream(Stream base_stream)
			: base(base_stream)
		{
			originalPosition = base.Position;
		}

		long originalPosition;

		public virtual void Finish()
		{
			base.Position = Position;
		}

		public override long Position
		{
			get
			{
				return originalPosition + CompressedBytes;
			}
			set
			{
				throw new NotSupportedException("Its hard to seek in a compressed stream");
			}
		}

		public virtual long CompressedBytes
		{ get { return base.inf.TotalIn; } }

		public virtual long UncompressedBytes
		{ get { return base.inf.TotalOut; } }
	}
}
