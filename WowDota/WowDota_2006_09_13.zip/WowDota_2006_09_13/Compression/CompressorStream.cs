using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using ICSharpCode.SharpZipLib.Zip.Compression;
using ICSharpCode.SharpZipLib.Zip.Compression.Streams;

namespace Compression
{
	public class CompressorStream : DeflaterOutputStream
	{
		public CompressorStream(Stream base_stream)
			: base(base_stream)
		{
			originalPosition = base.Position;
		}

		long originalPosition;

		public override void Finish()
		{
			base.Finish();
			base.Position = Position;
		}

		public override long Position
		{
			get
			{
				return originalPosition + CompressedBytes;
			}
			set
			{
				throw new NotSupportedException("Its hard to seek in a compressed stream");
			}
		}

		public virtual long CompressedBytes
		{ get { return base.def.TotalOut; } }

		public virtual long UncompressedBytes
		{ get { return base.def.TotalIn; } }
	}
}
