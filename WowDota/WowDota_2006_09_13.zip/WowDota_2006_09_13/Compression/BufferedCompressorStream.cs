using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Compression
{
	public class BufferedCompressorStream : MemoryStream
	{
		Stream BaseStream;

		public BufferedCompressorStream(Stream baseStream)
		{
			this.BaseStream = baseStream;
		}

		public void FlushOut()
		{
			base.Flush();
			CompressorStream compressor = new CompressorStream(BaseStream);
			WriteTo(compressor);
			compressor.Finish();
		}
	}
}
