using System;
using System.Collections.Generic;
using System.Text;
using System.IO;

namespace Compression
{
	public class BufferedDecompressorStream : MemoryStream
	{
		public BufferedDecompressorStream(Stream BaseStream, int uncompressed_bytes)
			: base(uncompressed_bytes)
		{
			DecompressorStream decompressor = new DecompressorStream(BaseStream);

			SetLength(uncompressed_bytes);

			decompressor.Read(base.GetBuffer(), 0, uncompressed_bytes);
			decompressor.Finish();

			Position = 0;
		}
	}
}
