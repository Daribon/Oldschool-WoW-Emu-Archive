using System;
using System.Collections.Generic;
using System.Windows.Forms;

namespace GuiServer
{
	static class Program
	{
		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main()
		{
			Application.EnableVisualStyles();
			Application.SetCompatibleTextRenderingDefault(false);

			MessageBox.Show("The GUI server hasn't been written yet. For now use ConsoleServer\nIt shouldn't be too hard to get something going if you want a crack at it",
				"No internets found", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
			Application.Run(new MainForm());
		}
	}
}