 !!! !!! !!! First of all, this release known bugs !!! !!! !!!
   - autoaccount is damaged due to some critical changes and it will be fixed soon.



     ------------------------------------------
     | YAWE (Yet Another WOW Emulator) README |
     ------------------------------------------
     
     
  This is the official release of YAWE server. 
  Please be sure to read this file and read it well as you may find the 
 answer to your problems here :)
 
 1. Instalation               
 --------------
 
  Well, its pretty simple as you have nothing to do but only eventually to edit
 your "/Configuration/system.conf" file in order to fit your actual needs. YAWE
 server will work smoothily even without modifying that file as it is configured
 for localhost usage (127.0.0.1 IP address).
  Configuration file is self explanatory for all things. So please read and read 
 twice before modifying something there :)
 
 2. Requirements
 ---------------
 
  Obviously youll need Windows XP with service pack 2 installed. The server is 
 expected to work perfect on a machine that can run Windows XP with Service Pack 2,
 so even on an AMD at 450 MHz with this operating system mentioned above YAWE should
 work smoothly.
  This can run also under Windows Vista. But when Delphi 2007 will be released, well
 make special releases for Widnows Vista users, compiled with Delphi 2007.
  So besides operating system requirements, youll need a mouse and a keyboard in order
 to interract with this server.
 
 Quite easy till now, isnt it?
 
 3. How do I test it?
 --------------------
  
  - W*W version required: 1.12.0 to 1.12.2 (builds 5595, 5875, 6005)
  - Configure your W*W Clients realmlist file to connect to 127.0.0.1 (or if you configured
      already the server to bind to some other IP, use the IP you setted-up in the configuration
      file instead of 127.0.0.1)
  - There is a default account created (TestUser / TestPassword). 
      Note: The server is default configured to autocreate accounts. The only thing needed to 
              an account autocreated is to type in W*W client a password which is the same as
              the username you want. (example: using aUsername / aUsername will automatically 
              create the account aUsername with aUsername password assigned to it. Anyway, in game
              every autocreated is asked to change its password using the command: 
              "set pass <the new password goes here>" without `"` or `<` of course)
  - Start YAWE server. Ignore map loading error as theres no tool to extract maps available yet.
  - Start W*W client and connect to YAWE server.                                                                                 
    
 !!! Important notes: Theres no database for YAWE server nad there will never be an official database
       from us so its up to you, dear user, to build or search for one :)
       
 4. BUG Reports
 --------------
  - Feel free to use our forum (located here: http://yawe.mcheats.net/forum/index.php) to report any bugs
      you discover but first of all, search and read the forum to be sure they are not reported already!
  - Also you will find a directory named sugestive "Errors". So when the server crashes, give us the files
      that are located in that directory (if there are any) so well track and understand the error easier!
  
 5. Server commands
 ------------------
  A. Console commands:
    - exit: safely terminates YAWE server
    - tray: sends YAWE server to tray.
  B. In-game chat commands:
   "help"       - Shows more detailed description of commands specified.
   "list"       - Lists all avaiable commands for your account level.
   "syntax"     - Displays the syntax for the specified commands.
   "online"     - Shows you the total number of players online.
   "add item"   - Adds an item or more into your bag.
   "set speed"  - Sets your speed to a new constant. Use ".setspeed default" to set its default value
   "honor"      - Simulates that you killed some oponent with random option like level difference, his rank, etc
   "equipme"    - Equips you with some hardcoded items, usually for test purposes.
   "suicide"    - Drops your health to 1, almost killing you.
   "heal"       - Heals yourself for X damage.
   "save"       - Saves the whole DB to disk. Optional parameter specifies if the server save timer should be refreshed (by default yes).
   "warp"       - Teleports you to a desired location (Map, X, Y, Z).
   "gps"        - Shows you the current location (Map and X, Y, Z coordinates).
   "levelup"    - Adds you one or more levels.
   "morph"      - Turns you into model specified.
   "demorph"    - Turns you into your original model.
   "showmount"  - Graphicly mounts you on mount model you specify.
   "hidemount"  - Graphicly dismounts you from a mount.
   "warpto"     - Teleports you to a player. (name is case IN-sensitive)
   "add node"   - Creates a node at your location and returns you its ID. You may use this ID to change the properties of this new node.
   "rem node"   - Deletes a node specified by index. The node is automaticly unregistered/unlinked and spawns are removed.
   "add spawn"  - Adds a new spawn entry to the specified node. Returns the ID of this entry in spawns entry table. You may use this ID to change or remove this entry.
   "rem spawn"  - Removes a spawn entry identified by spawn entry table id.
   "set pass"   - Sets or Resets yout account password.
   "get z"      - Queries the height of a specified point or of your position. WARNING: Developer only!
   "kill"       - Kills the selected creature.
   "movetarget" - Debug only! Moves selected creature few stept in one only direction!
                  
      
      
      
------------------
With kind regards,
YAWE Team!
    
    
    
    
    
    
    
    