-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `items`
--

DROP TABLE IF EXISTS `items`;
CREATE TABLE `items` (
  `guid` int(10) unsigned NOT NULL default '0',
  `data` mediumtext NOT NULL,
  PRIMARY KEY  (`guid`)
) TYPE=MyISAM;

