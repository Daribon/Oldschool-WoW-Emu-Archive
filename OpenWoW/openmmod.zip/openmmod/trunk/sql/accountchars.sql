-- MySQL dump 8.23
--
-- Host: localhost    Database: wow_rs
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `accountchars`
--

DROP TABLE IF EXISTS `accountchars`;
CREATE TABLE `accountchars` (
  `login` varchar(32) NOT NULL default '',
  `realm` varchar(32) NOT NULL default '',
  `numchars` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`login`,`realm`)
) TYPE=MyISAM;

