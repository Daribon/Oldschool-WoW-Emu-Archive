-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `access_levels`
--

DROP TABLE IF EXISTS `access_levels`;
CREATE TABLE `access_levels` (
  `level` tinyint(3) unsigned NOT NULL default '0',
  `name` varchar(32) NOT NULL default '',
  `flags` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`level`)
) TYPE=MyISAM;

--
-- Dumping data for table `access_levels`
--


INSERT INTO `access_levels` VALUES (3,'GameMaster',0);
INSERT INTO `access_levels` VALUES (2,'Seer',0);
INSERT INTO `access_levels` VALUES (1,'Councelor',0);
INSERT INTO `access_levels` VALUES (0,'Player',0);
INSERT INTO `access_levels` VALUES (4,'Developer',4294967295);

