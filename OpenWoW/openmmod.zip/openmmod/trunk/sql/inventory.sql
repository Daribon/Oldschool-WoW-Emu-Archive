-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `inventory`
--

DROP TABLE IF EXISTS `inventory`;
CREATE TABLE `inventory` (
  `charGuid` int(10) NOT NULL default '0',
  `slot` tinyint(3) NOT NULL default '0',
  `itemGuid` int(10) NOT NULL default '0',
  PRIMARY KEY  (`charGuid`,`slot`)
) TYPE=MyISAM;

