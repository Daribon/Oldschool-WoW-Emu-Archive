-- MySQL dump 8.23
--
-- Host: localhost    Database: wow
---------------------------------------------------------
-- Server version	3.23.58

--
-- Table structure for table `quest_status`
--

DROP TABLE IF EXISTS `quest_status`;
CREATE TABLE `quest_status` (
  `charGuid` int(10) unsigned NOT NULL default '0',
  `questId` int(10) unsigned NOT NULL default '0',
  `status` int(10) unsigned NOT NULL default '0',
  `MobCount1` int(10) unsigned NOT NULL default '0',
  `MobCount2` int(10) unsigned NOT NULL default '0',
  `MobCount3` int(10) unsigned NOT NULL default '0',
  `MobCount4` int(10) unsigned NOT NULL default '0',
  `ItemCount1` int(10) unsigned NOT NULL default '0',
  `ItemCount2` int(10) unsigned NOT NULL default '0',
  `ItemCount3` int(10) unsigned NOT NULL default '0',
  `ItemCount4` int(10) unsigned NOT NULL default '0',
  PRIMARY KEY  (`charGuid`)
) TYPE=MyISAM;

