/*
    Realm list server class.
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "RealmListSrv.h"
#include "RealmClient.h"
#include "Database.h"

IMPLEMENT_VECTOR_SORTED_STRKEY (, RealmVector, Realm *, Name);

RealmListSrv::RealmListSrv (uint iPort, Log *iLogger) : Server (iPort, 1000, iLogger)
{
}

RealmListSrv::~RealmListSrv ()
{
}

bool RealmListSrv::Start ()
{
	if (!db)
		return false;

	return Server::Start ();
}

void RealmListSrv::SocketEvent (uint mask)
{
	if (mask & PF_READ)
	{
		Socket *sock = socket->Accept ();
		if (!sock)
			return;
		// Free local references to refcounted objects
		RealmClient *c = new RealmClient (sock, this);
		AddClient (c);
		c->DecRef ();
		sock->DecRef ();
	}
}

void RealmListSrv::SetDatabase (Database *iDb)
{
	if (db != iDb)
	{
		if (db)
			db->DecRef ();
		if ((db = iDb))
		{
			db->IncRef ();
			db->SetLogger (Logger);
		}
	}
}

RealmVector *RealmListSrv::GetRealms ()
{
	DatabaseExecutor *dbex = db->GetExecutor ();
	if (!dbex)
		return NULL;

	RealmVector *rv = NULL;
	if (dbex->Execute ("SELECT name,address,population,type,color,language,online "
					   "FROM realms") == dbeOk)
	{
		rv = new RealmVector (8, 8);
		while (dbex->NextRow ())
		{
			Realm *r = new Realm (dbex->Get (0), dbex->Get (1),
								  atof (dbex->Get (2)), atoi (dbex->Get (3)),
								  atoi (dbex->Get (4)), atoi (dbex->Get (5)));
			// Mark server with the 'offline' color if it is offline
			if (!atoi (dbex->Get (6)))
				r->Color = 2;
			rv->Push (r);
		}
	}

	db->PutExecutor (dbex);

	return rv;
}
