/*
    Account Manager
    Copyright (C) 2005-2007 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "Database.h"
#include "Log.h"
#include "version.h"
#include "AccountMgr.h"
#include "RealmListSrv.h"

AccountInfo *AccountMgr::GetAccountInfo(char *Name)
{
	AccountInfo *info = NULL;
	DatabaseExecutor *dbex = rs->db->GetExecutor ();
	
	if (dbex->ExecuteF ("SELECT id,login,password,level,authip,sessionkey,email,banned FROM accounts WHERE login='%s'", Name) == dbeOk && dbex->NextRow ())
	{
		info = new AccountInfo();
		info->ID = dbex->GetU32 (0);
		info->Name = strnew (dbex->Get(1));
		info->Password = strnew (dbex->Get(2));
		info->Level = (uint8)dbex->Get(3);
		info->AuthIP = strnew (dbex->Get(4));
		const char *seskey = dbex->Get(5);
		if (seskey)
			Hex2Bin (seskey, info->SessionKey, sizeof (info->SessionKey));
		info->Email = strnew (dbex->Get(6));
		info->banned = dbex->GetU32(7) ? true : false;
	}

	if (dbex)
		rs->db->PutExecutor (dbex);

	return info;

}

AccountInfo *AccountMgr::GetAccountInfo(uint32 id)
{
	AccountInfo *info = NULL;
	DatabaseExecutor *dbex = rs->db->GetExecutor ();
	
	if (dbex->ExecuteF ("SELECT id,login,password,level,authip,sessionkey,email,banned FROM accounts WHERE id='%d'", id) == dbeOk && dbex->NextRow ())
	{
		info = new AccountInfo();
		info->ID = dbex->GetU32 (0);
		info->Name = strnew (dbex->Get(1));
		info->Password = strnew (dbex->Get(2));
		info->Level = (uint8)dbex->Get(3);
		info->AuthIP = strnew (dbex->Get(4));
		const char *seskey = dbex->Get(5);
		if (seskey)
			Hex2Bin (seskey, info->SessionKey, sizeof (info->SessionKey));
		info->Email = strnew (dbex->Get(6));
		info->banned = dbex->GetU32(7) ? true : false;
	}

	if (dbex)
		rs->db->PutExecutor (dbex);

	return info;

}

char *AccountMgr::GetAccountPassword(char *Name)
{
	const char *Password = NULL;
	DatabaseExecutor *dbex = rs->db->GetExecutor ();
	
	if (dbex->ExecuteF ("SELECT password FROM accounts WHERE id='%s'", Name) == dbeOk && dbex->NextRow ())
	{
		Password = dbex->Get(0);
	}

	if (dbex)
		rs->db->PutExecutor (dbex);

	return Password;
}