/*
    Account Manager
    Copyright (C) 2005-2007 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#include "Database.h"
#include "Log.h"
#include "version.h"
#include "RealmListSrv.h"

extern RealmListSrv *rs;

struct AccountInfo
{
	uint32 ID;
	char *Name;
	char *Password;
	uint8 Level;
	char *AuthIP;
	char SessionKey[40];
	char *Email;
	bool banned;

	AccountInfo()
	{
		Name = NULL;
		Password = NULL;
		AuthIP = NULL;
		Email = NULL;
	}

	~AccountInfo()
	{
		delete [] Name;
		delete [] Password;
		delete [] AuthIP;
		delete [] Email;
	}
};

class AccountMgr
{
	AccountMgr() { /* Don't think we need anything here */ }
	~AccountMgr() { /* Or here */ }

	AccountInfo *GetAccountInfo(char *Name);
	AccountInfo *GetAccountInfo(uint32 ID);
	char *GetAccountPassword(char *Name);

	bool SaveAccountInfo(AccountInfo *Info);

};
