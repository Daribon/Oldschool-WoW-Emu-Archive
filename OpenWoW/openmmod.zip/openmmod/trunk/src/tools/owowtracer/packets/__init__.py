from pkgutil import extend_path
__path__ = extend_path("../../gencode/", "yaml")
print __path__
