# Taken from hexedit
#(C) 2004 Chris Liechti <cliechti@gmx.net>

from wxPython.stc import *
import wx

BIN = 1
HEX = 2
LEFTTORIGHT = 1
RIGHTTOLEFT = 1

class Observer:
    def __init__(self):
        pass
    def update(self, theChangedSubject):
        pass

def limit(min, max, value):
    """limit value to the given range"""
    if value < min:
        return min
    if value > max:
        return max
    return value
        
class Subject:
    def __init__(self):
        self.observerList = []
    def attach(self, observer):
        self.observerList.append(observer)
    def detach(self, observer):
        try:
            self.observerList.remove(observer)
        except ValueError: #ignore if x not in list
            pass
    def notify(self, *args):
        for observer in self.observerList:
            try:
                observer.update(self, *args)
            except Exception, msg:
                sys.stderr.write("Subject.notify() exception in update() for %r:\n" % observer)
                traceback.print_exc()


class Bookmarks:
    """Keep a list of bookmarks (offsets).
    They are sorted by offset.
    """
    def __init__(self):
        self.offsets = []
        self.current = 0
    
    def toggle(self, offset):
        """toggle a bookmark at the specified offset"""
        if offset in self.offsets:
            self.current = self.offsets.index(offset)
            self.offsets.remove(offset)
        else:
            self.offsets.append(offset)
            self.offsets.sort()
            self.current = self.offsets.index(offset) + 1

    def getNext(self):
        """get next bookmark from the list. an internal pointer
        keeps track of the position
        """
        if not self.offsets:
            raise IndexError("no bookmarks set") #empty list
        if self.current >= len(self.offsets):
            self.current = 0
        offset = self.offsets[self.current]
        self.current += 1
        return offset

    def getAll(self):
        """get a list of all bookmarks"""
        return self.offsets[:]

class Packet:
    """pseudo file for tests, it may be of any size as it uses
       arbitrary precision numbers for the internals and it generates
       the read data on demand.
       write is not supported.
    """
    
    def __init__(self, str):
        self.str = str
        self.offset = 0L
        self.fileobj = None
        self.bin = None
        self.filename = None
        self.readonly = True

    def read(self, offset, size):
        return self.str[offset:offset+size]
        #~ print self.offset, size
        """
        if self.offset + size >= self.size:
            size = self.size - self.offset
        for n in xrange(size):
            x = (self.offset + n) % 16
            result.append(("%016x" % ((self.offset + n)/16))[x])
        self.offset += size
        print result
        """
        return ''.join(result)
        
    def write(self, offset, data):
        pass
        #raise IOError("it's read only")
        
    def seek(self, position, origin=0):
        if origin == 0:
            self.offset = position
        elif origin == 1:
            self.offset += position
        elif origin == 2:
            self.offset = self.size - position
        
        if self.offset >= self.size:
            self.offset = self.size
        
    def tell(self):
        return self.offset
        
    def size(self):
        return len(self.str)

    def close(self):
        pass
        
#constants for the hex view
EDIT_BYTES        = 1
EDIT_NIBBLE_LOW   = 2
EDIT_NIBBLE_HIGH  = 4
EDIT_NIBBLES      = 6   #mask

#key to hex nibble translation table
hex2bin = {
    ord('0'): 0,
    ord('1'): 1,
    ord('2'): 2,
    ord('3'): 3,
    ord('4'): 4,
    ord('5'): 5,
    ord('6'): 6,
    ord('7'): 7,
    ord('8'): 8,
    ord('9'): 9,
    ord('a'): 10, ord('A'): 10,
    ord('b'): 11, ord('B'): 11,
    ord('c'): 12, ord('C'): 12,
    ord('d'): 13, ord('D'): 13,
    ord('e'): 14, ord('E'): 14,
    ord('f'): 15, ord('F'): 15,
}

class Formater:
    """hex dump formater"""
    def __init__(self, width=16, address_width=8):
        self.width = width
        self.address_width = address_width
    
    def bestFit(self, characterwidth):
        a, b = divmod((characterwidth - self.address_width - 5) / 4, 4)
        return max(4, a* 4)
    
    def getPositions(self):
        address_end     = self.address_width
        hex_start       = address_end + 2
        hex_end         = hex_start + 3*self.width - 1
        ascii_start     = hex_end + 2
        ascii_end       = ascii_start + self.width
        return (address_end, hex_start, hex_end, ascii_start, ascii_end)

    def formatDump(self, data):
        return ' '.join(['%02x' % ord(c) for c in data])

    def formatASCII(self, data):
        return ''.join([(c >= ' ' and c or '.' ) for c in data])

    def format(self, offset, data):
        if len(data) > self.width:
            raise ValueError("too much data for the width")
        return ('%%0%sx  %%-%ss %%s' % (self.address_width, 3*self.width)) % (offset, self.formatDump(data), self.formatASCII(data))

    def formatBlock(self, offset, data):
        lines = []
        for block in blockSplitter(data, self.width):
            lines.append(self.format(offset, block))
            offset += len(block)
        return lines


class PacketViewer(wx.ScrolledWindow):
    """Hex Viewer widget.
       supports arbitrary size files, copy&paste, selection, undo/redo, ...
    """
    
    def __init__(self, parent, id):
        wx.ScrolledWindow.__init__(self, parent, id,size=(-1,100))
        self.EnableScrolling(False, False)
        
        self.InitFont()
        self.MapEvents()
        packet = Packet("Something should be removed from this str somtime")
        self.formater = Formater()
        self.lines              = 0
        #~ self.model.attach(self)
        
        self.color_text         = wx.NamedColour('black')
        self.color_background   = wx.NamedColour('white')
        self.color_mark         = wx.NamedColour('light grey')
        self.color_cursor       = wx.NamedColour('yellow')
        self.color_lines        = wx.NamedColour('blue')
        self.color_lines_weak   = wx.NamedColour('light blue')
        self.color_bookmark     = wx.NamedColour('red')
        
        self.packet         = packet
        
        self.bmp = wx.EmptyBitmap(1,1)
        
        self.sx                 = 0L
        self.sy                 = 0L
        self.sh                 = 0L
        
        self.offset             = 0L
        self.editmode           = EDIT_NIBBLE_HIGH
        self.reload             = True
        
        self.selection_start    = None
        self.selection_end      = None
        self.leftdragging       = False
        self.redo_list          = []
        self._mouse_lastoffset  = None
        
        self.address_end, self.hex_start, self.hex_end, self.ascii_start, self.ascii_end = self.formater.getPositions()
        self.bookmarks = Bookmarks()
        self.OnSize(None)       #init double buffering
        self.setPacket(packet)
        self.reset()


    def MapEvents(self):
        wx.EVT_SCROLLWIN(self,  self.OnScroll)
        wx.EVT_PAINT(self,      self.OnPaint)
        wx.EVT_SIZE(self,       self.OnSize)
        wx.EVT_ERASE_BACKGROUND(self, self.OnEraseBackground)
        wx.EVT_LEFT_DOWN(self,  self.OnMouseButtonEvent)
        wx.EVT_LEFT_UP(self,    self.OnMouseButtonEvent)
        wx.EVT_MOTION(self,     self.OnMouseButtonEvent)
        wx.EVT_CHAR(self,       self.OnChar)


    def UpdateView(self, dc = None):
        if dc is None:
            cdc = wx.ClientDC(self)
            dc = wx.BufferedDC(cdc, self.bmp)
            #~ dc = wx.MemoryDC()
            #~ dc.SelectObject(self.bmp)
        if dc.Ok():
            if self.packet is not None:
                self.draw(dc)
                #~ self.Refresh()
    def OnPaint(self, event):
        #would be nice, but does bad scrolling :-(
        #~ dc = wx.BufferedPaintDC(self, self.bmp)
        #update display w/o scrolling of the virtual area
        dc = wx.PaintDC(self)
        dc.DrawBitmap(self.bmp, 0, 0, False)

    def OnEraseBackground(self, evt):
        pass

    def OnSize(self, event):
        """called on window resize, also used to init double buffering"""
        try:
            self.bw, self.bh = self.GetClientSizeTuple()
        except: pass
        self.bw = max(1,self.bw)
        self.bh = max(1,self.bh)
        #self.bw= 100
        #self.bh = 100
        self.bmp = wx.EmptyBitmap(self.bw,self.bh)
        #self.bmp.SetSize(wx.Size(self.bw, self.bh))
        if self.packet is not None:
            self.update()       #calls AdjustScrollbars, UpdateView, etc
        else:
            self.AdjustScrollbars()

    def InitFont(self, font=None):
        dc = wx.ClientDC(self)
        if font is None:
            self.font = self.NiceFontForPlatform()
        else:
            self.font = font
        dc.SetFont(self.font)
        self.fw = dc.GetCharWidth()
        self.fh = dc.GetCharHeight()

    def NiceFontForPlatform(self):
        if wx.Platform == "__WXMSW__":
            return wx.Font(10, wx.MODERN, wx.NORMAL, wx.NORMAL)
        else:
            return wx.Font(11, wx.MODERN, wx.NORMAL, wx.NORMAL, False)

    def SetCharDimensions(self):
        self.sh = self.bh / self.fh
        self.sw = (self.bw / self.fw) - 1

    def OnScroll(self, event):
        eventType = event.GetEventType()
        if   eventType == wx.wxEVT_SCROLLWIN_LINEUP:
            self.sy -= 1
        elif eventType == wx.wxEVT_SCROLLWIN_LINEDOWN:
            self.sy += 1
        elif eventType == wx.wxEVT_SCROLLWIN_PAGEUP:
            self.sy -= self.sh
        elif eventType == wx.wxEVT_SCROLLWIN_PAGEDOWN:
            self.sy += self.sh
        #~ elif eventType == wx.wxEVT_SCROLLWIN_TOP:
            #~ self.sy = 0
        #~ elif eventType == wx.wxEVT_SCROLLWIN_BOTTOM:
            #~ self.sy = self.lines - self.sh
        else:
            self.sy = event.GetPosition()
            
        self.sy = max(0, min(self.sy, self.lines - self.sh))
        #~ self.offset = self.sy*16 + (self.offset % 16)
        self.reload = True
        self.AdjustScrollbars()
        self.UpdateView()
        
    def AdjustScrollbars(self):
        self.SetCharDimensions()
        self.sy = max(0, min(self.sy, self.lines - self.sh))
        if self.lines < 2**25:      #hide scollbars after a certain size
            self.SetScrollbars(self.fw, self.fh,
                               self.sw, self.lines+1,       #XXX +1 HACK
                               #~ self.sw, self.lines,
                               self.sx, self.sy)
        else:
            self.SetScrollbars(self.fw, self.fh,
                               self.sw, 0,
                               self.sx, 0)

    def getLine(self, line):
        """cache formated lines for faster screen updates"""
        if self.linecache.has_key(line):
            return self.linecache[line]
        else:
            offset = line*self.formater.width
            self.linecache[line] = self.formater.format(offset, self.packet.read(offset, self.formater.width))
        return self.linecache[line]

    def draw(self, dc):
        if self.reload == True:
            self.linecache = {}
            self.reload = False
        dc.BeginDrawing()
        dc.SetFont(self.font)
        dc.SetBackgroundMode(wx.SOLID)
        dc.SetBackground(wx.Brush(self.color_background))
        dc.SetTextForeground(self.color_text)
        dc.Clear()
        #numbers
        linewidth       = self.formater.width
        visible_start   = self.sy*linewidth
        visible_end     = (self.sy + self.sh)*linewidth
        
        
        #selection
        if self.selection_start is not None and self.selection_end is not None:
            if self.selection_start > self.selection_end: #swap if start > end
                selection_start, selection_end = self.selection_end, self.selection_start
            else:
                selection_start, selection_end = self.selection_start, self.selection_end
            
            dc.SetPen(wx.Pen(self.color_mark, 1))
            dc.SetBrush(wx.Brush(self.color_mark))
            
            #start to end of mark/end of line
            if visible_start <= selection_start < visible_end:
                xb, xa, y = self._offset2XXY(selection_start)
                width = min(selection_end - selection_start, (linewidth-1) - selection_start % linewidth)
                dc.DrawRectangle(xb, y, self.fw*(2 + 3*width), self.fh)
                dc.DrawRectangle(xa, y, self.fw*(1 + width), self.fh)
            
            #end to start of mark or start of line
            if visible_start <= selection_end < visible_end:
                xb, xa, y = self._offset2XXY(selection_end)
                width = min(selection_end - selection_start, selection_end % linewidth)
                dc.DrawRectangle(xb-self.fw*3*width, max(0, y), self.fw*(2 + 3*width), self.fh)
                dc.DrawRectangle(xa-self.fw*width, max(0, y), self.fw*(width + 1), self.fh)
            
            #whole lines in between
            sel_startline = max(0, selection_start / linewidth - self.sy + 1)
            sel_endline   = max(0, min(self.sh, selection_end / linewidth - self.sy))
            visible_lines = sel_endline - sel_startline
            if visible_lines:
                xb = self.fw*self.hex_start
                xa = self.fw*self.ascii_start
                wb = self.fw*(3*linewidth - 1)
                wa = self.fw*linewidth
                y  = sel_startline * self.fh
                for i in range(visible_lines):
                    dc.DrawRectangle(xb, y, wb, self.fh)
                    dc.DrawRectangle(xa, y, wa, self.fh)
                    y += self.fh
        
        #cursor
        if visible_start <= self.offset < visible_end:
            dc.SetPen(wx.Pen(self.color_cursor, 2))
            if self.selection_start is not None and self.selection_end is not None \
              and self.selection_start != self.selection_end:
                dc.SetBrush(wx.TRANSPARENT_BRUSH)
            else:
                dc.SetBrush(wx.Brush(self.color_cursor))
            
            xb, xa, y = self._offset2XXY(self.offset)
            if self.editmode == EDIT_BYTES:
                dc.DrawRectangle(xa, y, self.fw, self.fh)
            elif self.editmode == EDIT_NIBBLE_LOW:
                dc.DrawRectangle(xb+self.fw, y, self.fw, self.fh)
            elif self.editmode == EDIT_NIBBLE_HIGH:
                dc.DrawRectangle(xb, y, self.fw, self.fh)
        
        #draw bookmarks
        for bookmark in self.bookmarks.getAll():
            if visible_start <= bookmark < visible_end:
                dc.SetPen(wx.Pen(self.color_bookmark, 2))
                dc.SetBrush(wx.TRANSPARENT_BRUSH)
                xb, xa, y = self._offset2XXY(bookmark)
                dc.DrawRectangle(xb, y, 2*self.fw, self.fh)
                dc.DrawRectangle(xa, y, self.fw, self.fh)
            
        #lines
        dc.SetBackgroundMode(wx.TRANSPARENT)
        y = 0
        for line in range(self.sy, min(self.sy + self.sh, self.lines)):
            dc.DrawText(self.getLine(line), 0, y)
            y += self.fh
        
        #vertical lines
        dc.SetPen(wx.Pen(self.color_lines, 2))
        x = self.fw*(self.address_end + (self.hex_start - self.address_end)/2)
        dc.DrawLine(x, 0, x, self.bh)
        x = self.fw*(self.hex_end + (self.ascii_start - self.hex_end)/2)
        dc.DrawLine(x, 0, x, self.bh)
        dc.SetPen(wx.Pen(self.color_lines_weak, 1))
        f2 = self.fw / 2
        for pos in range(self.hex_start+12, self.hex_end, 12):
            x = self.fw*pos - f2
            dc.DrawLine(x, 0, x, self.bh)
        
        dc.EndDrawing()

    def _offset2XXY(self, offset):
        """offset to character coordinates, hex and ascii dump x offsets"""
        d, m = divmod(offset, self.formater.width)
        return (self.fw * (m * 3 + self.hex_start),
                self.fw * (m + self.ascii_start), #-1
                self.fh * (d - self.sy))

    def OnMouseButtonEvent(self, event):
        """mouse events, handle selection, clicks"""
        fullline = False
        update = False
        x, y = event.GetX(), event.GetY()
        line = (y / self.fh + self.sy)
        offset = offset_line = line * self.formater.width #calculate offset of fist char in line, x handled below
        xchar = x / self.fw
        if xchar < self.hex_start:              #address area
            fullline = True
            editmode = EDIT_NIBBLE_HIGH
        elif xchar < self.hex_end:              #hex area
            offset += (xchar - self.hex_start) / 3
            if ((xchar - self.hex_start) % 3 < 1) or fullline:
                editmode = EDIT_NIBBLE_HIGH
            else:
                editmode = EDIT_NIBBLE_LOW
        elif xchar < self.ascii_start:          #between hex and ascii area
            fullline = True
            editmode = EDIT_BYTES
        elif xchar < self.ascii_end:            #ascii area
            offset += xchar - self.ascii_start
            editmode = EDIT_BYTES
        else:                                   #right of ascii area
            fullline = True
            editmode = EDIT_BYTES
        
        size = max(0, self.packet.size() - 1)
        offset = limit(0, size, offset)
        
        if event.LeftDown():
            self.CaptureMouse()
            self.leftdragging = True
            if fullline:
                offset = limit(0, size, offset_line + self.formater.width - 1)
                self.selection_start = offset_line
            else:
                self.selection_start = offset
            self.selection_end = self.offset = offset
            update = True
        elif event.Dragging() and self.leftdragging:
            if fullline:
                offset = limit(0, size, offset_line + self.formater.width - 1)
            if self._mouse_lastoffset != offset:
                self.selection_end = self.offset = offset
                update = True
        elif event.LeftUp():
            if self.leftdragging:
                self.ReleaseMouse()
                self.leftdragging = False
            if fullline:
                offset = limit(0, size, offset_line + self.formater.width - 1)
            if self.leftdragging:
                if self.selection_end != offset:
                    self.selection_end = offset
                    update = True
        
        if update:
            self.editmode = editmode
            self.ensureVisible()
        
        self._mouse_lastoffset = offset
    
    def OnChar(self, event):
        """key events, input and movements"""
        move = False
        update = False
        update_selection_end = False
        keycode = event.GetKeyCode()
        #controls
        if keycode == 0x08:                     #backspace
            self.offset -= 1
            update = True
        elif keycode == 0x1b:                   #ESC ->toggle hex/ascii edit
            if self.editmode == EDIT_BYTES:
                self.editmode = EDIT_NIBBLE_HIGH
            else:
                self.editmode = EDIT_BYTES
            self.ensureVisible()
        elif keycode == 127:                    #DELETE
            pass
            #~ self.model.bin.write(self.offset, '\0')
        elif 32 <= keycode < 256:               #ascii text
            #~ print "Key %d: %c" % (keycode, keycode)
            #hex edit mode
            if self.editmode & EDIT_NIBBLES:
                if keycode == 0x20: #space -> swap nibbles
                    if self.editmode == EDIT_NIBBLE_HIGH:
                        self.editmode = EDIT_NIBBLE_LOW
                    else:
                        self.editmode = EDIT_NIBBLE_HIGH
                    update = True
                else:
                    if self.packet.isReadonly():
                        wx.Bell()       #TODO dialog box?
                    else:
                        try:
                            value = hex2bin[keycode]
                        except KeyError:
                            #~ print "not a hex character"     #XXX DEBUG
                            event.Skip()
                        else:
                            if self.editmode == EDIT_NIBBLE_HIGH:
                                value = (value << 4) | (ord(self.packet.read(self.offset, 1)) & 0x0f)
                                self.editmode = EDIT_NIBBLE_LOW
                                self.packet.write(self.offset, chr(value))
                            else:
                                value = value | (ord(self.packet.read(self.offset, 1)) & 0xf0)
                                self.editmode = EDIT_NIBBLE_HIGH
                                self.packet.write(self.offset, chr(value))
                                self.offset += 1
                            del self.redo_list[:]
                            update = True
            #ascii edit mode
            elif self.editmode == EDIT_BYTES:
                if self.model.isReadonly():
                    wx.Bell()       #TODO dialog box?
                else:
                    self.packet.write(self.offset, chr(keycode))
                    del self.redo_list[:]
                    self.offset += 1
                    update = True
        else:   #special keys
            if keycode == wx.WXK_RIGHT:
                self.offset += 1
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_LEFT:
                self.offset -= 1
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_DOWN:
                self.offset += self.formater.width
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_UP:
                self.offset -= self.formater.width
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_NEXT:
                self.offset += self.sh*self.formater.width
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_PRIOR:
                self.offset -= self.sh*self.formater.width
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_HOME:
                if event.ControlDown():
                    self.offset = 0L
                else:
                    self.offset -= self.offset % self.formater.width
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_END:
                if event.ControlDown():
                    self.offset = long(self.packet.size())
                else:
                    self.offset += (self.formater.width - 1) - (self.offset % self.formater.width)
                move = True
                if event.ShiftDown():
                    update_selection_end = True
            elif keycode == wx.WXK_F2:          #bookmarks jump/toggle
                if event.ControlDown():
                    self.bookmarks.toggle(self.offset)
                else:
                    try:
                        self.ensureVisible(self.bookmarks.getNext())
                    except IndexError:
                        pass    #do nothing if no bookmarks are set
                update = True
            else:
                print "Key %d s:%s c:%s a:%s m:%s" % (
                    keycode, event.ShiftDown(), event.ControlDown(),
                    event.AltDown(), event.MetaDown()
                )
                event.Skip()
        
        if move or update:      #update screen if needed
            if self.offset < 0:
                self.offset = 0L
            elif self.offset >= self.packet.size():
                self.offset = max(0, self.packet.size() - 1L)
            
            if move:            #nibble edit: select high nibble after moves
                if self.editmode & EDIT_NIBBLES:
                    self.editmode = EDIT_NIBBLE_HIGH
            
            #update selection with keyboard (shift+movement)?
            if update_selection_end:
                #update selection
                self.selection_end = self.offset
            else:
                #reset selection otherwise
                self.selection_start = self.selection_end = self.offset
            self.ensureVisible()

    def reset(self):
        """reset view, empty"""
        self.sy = self.sx = 0L
        self.offset = 0L
        self.lines = 0L
        self.selection_start = self.selection_end = 0L
        self.reload = True
    
    def ensureVisible(self, offset=None):
        """ensure that the cursor is visible, if offset is given, set cursor on that location"""
        if offset is not None:
            self.offset = offset
            #~ print "ensureVisible(0x%08x)" % (offset)
        #check if cursor is in currently visible area
        visible_start = self.sy * self.formater.width
        visible_end   = min(self.sy + self.sh, self.lines) * self.formater.width
        if visible_start <= self.offset < visible_end:
            pass
        else:
            #scroll to new position, try to place it at 1/3rd of the view
            self.sy = max(0, min(self.offset/self.formater.width - self.sh/3, self.lines))
            self.reload = True
        self.AdjustScrollbars()
        self.UpdateView()
        #self.notify()

    def setSelection(self, start=None, end=None, offset=None):
        """set selection to include the given start and end offset
        if offset is given , move cursor there.
        if end is not given, select a single character, given by start
        if either start not end is given, remove selection
        """
        if start is None:
            start = self.offset
        if end is None:
            end = start
        self.selection_start = start
        self.selection_end = end
        if offset is not None:
            self.ensureVisible(offset)
        else:
            self.update()

    def getSelection(self):
        """get selection as tuple (start,end), ensures that
        start <= end, None if nothing selected."""
        if self.selection_start > self.selection_end:
            return (self.selection_end, self.selection_start)
        else:
            return (self.selection_start, self.selection_end)

    def undo(self):
        """go one step back in the write history"""
        """
        if self.packet.history:
            history_entry = self.packet.history.pop()
            self.model.bin.notify()                     #hack!!
            self.redo_list.append(history_entry)
            self.model.notify()                         #hack!!
            self.update()
            self.ensureVisible(history_entry[1]-1)      #hack!
            self.setSelection()                         #hack!
        """
    def redo(self):
        """redo the last undone step"""
        """
        if self.redo_list:
            history_entry = self.redo_list.pop()
            self.model.bin.history.append(history_entry)
            self.model.bin.notify()                     #hack!!
            self.model.notify()                         #hack!!
            self.update()
            self.ensureVisible(history_entry[1]-1)      #hack!
            self.setSelection()                         #hack!
        """

    def update(self, subject=None):
        """update view"""
        size = self.packet.size()
        if size:
            a, b = divmod(len("%x" % (size - 1)), 4)
            self.formater.address_width = (a + (b != 0))*4
            width = self.formater.bestFit(self.GetSizeTuple()[0]/self.fw)
            self.formater.width = width
            self.address_end, self.hex_start, self.hex_end, self.ascii_start, self.ascii_end = self.formater.getPositions()
            self.lines = self.packet.size() / self.formater.width
            if self.packet.size() % self.formater.width:
                self.lines += 1
            self.sy = max(0L, min(self.lines-self.sh, self.sy))
            #FIXME
            #self.sy = 10
            #~ self.offset = self.sy*16
        else:
            self.lines = self.sy = 0
            self.formater.address_width = 8
        self.reload = True
        #~ self.AdjustScrollbars()
        #~ self.UpdateView()
        self.ensureVisible()

    def setPacket(self, packet):
        """change model"""
        self.packet = packet
        #self.model.attach(self)
        self.reset()
        self.update()

