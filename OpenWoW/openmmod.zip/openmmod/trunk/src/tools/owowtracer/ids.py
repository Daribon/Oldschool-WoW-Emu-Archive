from wxPython.wx import wxNewId, wxID_EXIT, EVT_MENU, EVT_BUTTON, EVT_CLOSE
#from wx import *

id_menu_about = wxNewId()
id_menu_connect = wxNewId()
id_menu_disconnect = wxNewId()

