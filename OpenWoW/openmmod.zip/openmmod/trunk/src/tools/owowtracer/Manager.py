from net.__init__ import *

class Connection:
	def __init__(self, connection):
		self.connection = connection
		self.packets = {}
		self.users = {}
		self.filter = None
		# register callback
		self.connection = connection
		connection.register(TRAFFIC, self.rcvPacket)
		connection.register(UPDATE_CLIENT, self.rcvUpdate)
	
	def connect(self):
		self.connection.connect()
		
	def disconnect(self):
		self.connection.disconnect()

	def rcvPacket(self, packet):
		if packet:
			if not self.packets.has_key(packet.account):
				self.packets[packet.account] = []
			self.packets[packet.account].append(packet)
			print "Got packet"

	def rcvUpdate(self, packet):
		if packet:
			self.users[packet.account] = packet
			
	def setFilter(self, filter):
		if not iscallable(filter):
			raise ValueError, "Filter must be callable"
		self.filter = filter
	
	def getPackets(self, filtered = True):
		if iscallable(self.filter):
			out = []
			for i in self.packets:
				if self.filter(i):
					out.append(i)
		else:
			return self.packets
		

class Manager:
	
	def __init__(self):
		self.connections = []

	def addConnection(self, cls, host, user, password):
		lcon = cls(host, user, password)		
		con = Connection(lcon)
		return con
		
	def delConnection(self, connection):
		connection.disconnect()
		self.connections.remove(connection)
	
	def listConnections(self):
		return self.connections
		
	
