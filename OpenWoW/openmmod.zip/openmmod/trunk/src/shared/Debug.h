/*
    Debugging helper functions
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __DEBUG_H
#define __DEBUG_H

#include "Console.h"



/**
 * All kind of asserts, as well as debug outputs must be activated ONLY IN DEBUG BUILDS.
 * The reason for having the following macros is to disable all kinds of debugging
 * for release builds.
 */

#define DEBUG

#ifdef DEBUG
#  include <assert.h>
#  include "Console.h"
#  define DEBUG_DUMP (f,d,s,r) DebugDump (f, d, s, r)
#  if COMPILER == COMPILER_GNU
#    define DEBUG_BREAK asm ("int $3")
#  elif (COMPILER == COMPILER_MICROSOFT) || (COMPILER == COMPILER_BORLAND)
#    define DEBUG_BREAK //_asm { int 3 }
#  else
#    define DEBUG_BREAK
#  endif
#  define DEBUG_BREAK_IF(cond) { if (cond) DEBUG_BREAK; }
#  define ASSERT(cond) assert(cond)
#  if __GNUC__ >= 3
#    define DEBUG_PRINTF CONSOLE.Out ("\ax4%s\axc:\ax4%s\axc:\ax4%d\axc: \ax3", __FILE__, __FUNCTION__, __LINE__), CONSOLE.Out
#  else
#    define DEBUG_PRINTF CONSOLE.Out ("\ax4%s\axc:\ax4%d\axc: \ax3", __FILE__, __LINE__), CONSOLE.Out
#  endif
#else
#  define DEBUG_DUMP (f,d,s,r)
#  define DEBUG_BREAK
#  define DEBUG_BREAK_IF(cond)
#  define ASSERT(cond)
static inline void DEBUG_PRINTF (...) {}
#endif

// Neat for debugging
void DebugDump(FILE *Out, const void *Data, unsigned Size, const void *Base = (const void *)-1);

void printBytes(void *bytes, int l, char *name);

#endif
