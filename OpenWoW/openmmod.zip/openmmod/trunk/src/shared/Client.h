/*
    Network Client abstraction
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __CLIENT_H__
#define __CLIENT_H__

#include "Base.h"
#include "Sockets.h"

class Server;

/**
 * This is an abstraction class for any client connection of a network Server.
 * It holds the client connection socket, and receives notifications about
 * incoming events.
 */
class Client : public Base
{
protected:
	friend class Server;

	/// The client socket
	Socket *socket;

	/// Private destructor -- use DecRef () instead
	virtual ~Client ();

public:
	/// Create the client object listening to this socket
	Client (Socket *sock); //tolua_hide abstract class can't be allociated

	/**
	 * Called when any event (one of those requested by socket->InterestedEvents())
	 * happens with the socket.
	 * @arg mask
	 *   Event mask (a combination of PF_XXX flags)
	 */
	virtual void SocketEvent (uint mask) = 0;
};

#endif // __CLIENT_H__
