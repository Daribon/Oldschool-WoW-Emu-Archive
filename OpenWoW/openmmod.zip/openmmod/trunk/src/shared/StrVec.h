/*
    String vector class
    Copyright (C) 1998,1999 by Andrew Zabolotny <bit@eltech.ru>

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __STRVEC_H__
#define __STRVEC_H__

#include "Vector.h"

/**
 * StrVector is a version of Vector which assumes its components
 * were allocated with 'new char *[]'. FreeItem () deletes vector elements
 * using 'delete [] (char *)' operator.
 */
class StrVector : public Vector
{
public:
    /// Constructor just passes control to Vector's
    StrVector (int ilimit = 64, int ithreshold = 64) :
        Vector (ilimit, ithreshold) {}

    /// Delete all inserted strings before deleting the object itself
    virtual ~StrVector ();

    /// FreeItem deletes Item as if it was allocated by 'new char *[]'
    virtual void FreeItem (Some Item) const;

    /// Compare two array elements in given Mode
    virtual int Compare (Some Item1, Some Item2, int Mode) const;

    /// Compare two strings for equality (case-sensitive)
    virtual int CompareKey (Some Item, ConstSome Key, int Mode) const;

    /// Override Get() to avoid explicit typecasting
    inline char *Get (int iIndex) const
    { return (char *)Vector::Get (iIndex); }
};

#endif // __STRVEC_H__
