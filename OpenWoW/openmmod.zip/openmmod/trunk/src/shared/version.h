/*
    Version info and basic definitions
    Copyright (C) 2005 Team OpenWoW

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Library General Public
    License as published by the Free Software Foundation; either
    version 2 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Library General Public License for more details.

    You should have received a copy of the GNU Library General Public
    License along with this library; if not, write to the Free
    Software Foundation, Inc., 675 Mass Ave, Cambridge, MA 02139, USA.
*/

#ifndef __VERSION_H__
#define __VERSION_H__

// Server Settings [ Connection ]
#define COPYRIGHT			"2004-2007 Team OpenWoW"
#define VERSION				"2.0.8-amd64"

#define DEFDBTYPE			"MySQL"
#define DEFDBADDR			"localhost,wow,wow,wow"

// Start human zone (0 = off / 1 = on)
#define DEFSTARTHUMANZONE	0
// Play Cinematics  (false = off / true = on)
#define DEFSHOWINTRO		1
// Max number of clients
#define DEFCLIENTLIMIT		50

// Max characters per login
#define MAX_CHARS_PER_LOGIN	10

// VERSION comes from dep/inc/config.h for Win32 and from config.h for Linux

#if PLATFORM == PLATFORM_WIN32
# define FULLVERSION		VERSION "-win"
#else
# define FULLVERSION		VERSION "-nix"
#endif

// Compatible client build range

#define MIN_CLIENT_BUILD	6403
#define MAX_CLIENT_BUILD	9999

// The path to config files
#ifndef SYSCONFDIR
#  define SYSCONFDIR		""
#endif

#define RL_CONFIG_FILE		SYSCONFDIR"realmlist.conf"
#define WS_CONFIG_FILE		SYSCONFDIR"worldserv.conf"

#endif // __VERSION_H__
