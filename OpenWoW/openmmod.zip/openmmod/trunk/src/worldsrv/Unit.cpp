/*
    Unit class implementation
    Copyright (C) 2004 Team Python
    Copyright (C) 2005 Team OpenWoW

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "Unit.h"
#include "Affect.h"
#include "Opcodes.h"
#include "Debug.h"

#include <math.h>

#define M_PI       3.14159265358979323846

#define RAD2DEG(x)	(x * (180.0 / M_PI))

IMPLEMENT_VECTOR (Affect::, ModifierVector, Modifier *)
IMPLEMENT_VECTOR (Unit::, AffectVector, Affect *)

Unit::Unit () : Object (), AttackTimer (0), Attackers (0, 16),
	Affects (0, 16)
{
	TempAffect = NULL;
	Aura = NULL;
	AuraCheck = 2000;
	CurrentSpell = NULL;
	Silenced = false;
	MeleeSpell = false;
	AddDmgOnce = 0;
	TotemSlot1 = TotemSlot2 = TotemSlot3 = TotemSlot4 = 0;
	TriggerSpell = 0;
	TriggerDamage = 0;
	DeathState = ALIVE;

	Field.SetLength (UNIT_END);
	Field.Clear (OBJECT_END, UNIT_END - OBJECT_END);
	Field.SetBits (OBJECT_FIELD_TYPE, TYPE_UNIT, TYPE_UNIT);
}

Unit::~Unit()
{
}

void Unit::Update (uint32 iDeltaMs)
{
	Object::Update (iDeltaMs);

	UpdateSpells (iDeltaMs);

	if (AttackTimer.Enabled ())
	{
		if (AttackTimer.Tick (iDeltaMs))
			AttackTimer.Disable ();
	}
}

bool Unit::CanReachWithAttack (Unit *iVictim) const
{
	float reach = Field.GetF32 (UNIT_FIELD_COMBATREACH);
	float radius = Field.GetF32 (UNIT_FIELD_BOUNDINGRADIUS);

	if (GetDistanceSq (iVictim) > Square <float> (reach + radius))
		return false;

	return true;
}

void Unit::GiveXP (uint32 iXP, Unit *iVictim, bool iGroup)
{
	// for now, do nothing -- Player will have its own overrided method
}

void Unit::ReceiveDamage (Unit *iAttacker, uint32 iDamage)
{
	uint32 Health = Field.GetU32 (UNIT_FIELD_HEALTH);

	if (Health > iDamage)
	{
		Field.SetU32 (UNIT_FIELD_HEALTH, Health - iDamage);

#if 0
		// This logic will go to corresponding class: Creature or Player
		// Every unit type has its own rules how to decide how to answer
		// when somebody hurts him.

		// this need alot of work.
		if ((World->GameFeatures & GF_PLAYER_AUTOATTACK)
		 || !(GetType () & TYPE_PLAYER))
		{
			((Creature*)iVictim)->AI_ChangeState(ATTACKING); // when attacked mobs stop moving around
			((Creature*)iVictim)->AI_AttackReaction(this, damage);
			/*
			 //uint32 max_health = Field.GetU32(UNIT_FIELD_MAXHEALTH);
			 //uint32 health_porcent = (max_health*10)/100; // this if for know 10% of total healt,need changes about mobs lvls
			 iVictim->AI_ChangeState(3); //if mob are attack then they stop moving around
			 iVictim->AI_AttackReaction(pAttacker, damage);

			 //well mobs scape if have a movement assignet atm
			 //if(health<=health_porcent)
			 {}
			 */
		}
#endif
	}
    else // Oh well, we're killed
	{
		// Put something in our pockets if they're empty
		GenerateLoot ();
		if (!(GetType () & TYPE_PLAYER))
			Field.SetBits (UNIT_DYNAMIC_FLAGS, UDF_LOOTABLE, UDF_LOOTABLE);

		// Set our health to 0
		Field.SetU32 (UNIT_FIELD_HEALTH, 0);
		// Drop combat mode and set the 'dead' flag
		Field.SetBits (UNIT_FIELD_FLAGS, UFF_IN_COMBAT | UFF_DEAD, UFF_DEAD);

		// Remove the effect of all items & spells from the victim
//@@@		RemoveAllAffects ();

		SetDeathState (JUST_DIED);
	}
}

void Unit::SpellNonMeleeDamageLog (Unit *iVictim, uint32 iSpellId, uint32 iDamage)
{
	//@@@todo is this really required?
	//if (!IsAlive () || !iVictim->isAlive ())
	//	return;

	DEBUG_PRINTF ("%X:%u attacked %X:%u for %u damage with spell %u",
			 GetHighGUID (), GetLowGUID (), iVictim->GetHighGUID (),
			 iVictim->GetLowGUID (), iDamage, iSpellId);

	SMSG_SPELLNONMELEEDAMAGELOG_t *outpkt = SMSG_SPELLNONMELEEDAMAGELOG_t::Create ();
	outpkt->Victim = iVictim->GetGUID ();
	outpkt->Attacker = GetGUID ();
	outpkt->SpellId = iSpellId;
	outpkt->Damage = iDamage;
	outpkt->Assemble ();

	SendToSet (outpkt, true);
	DealDamage (iVictim, iDamage);
}

void Unit::PeriodicAuraLog (Unit *iVictim, uint32 iSpellId, uint32 iDamage, uint32 iDamageType)
{
	//@@@todo is this really required?
	//if (!IsAlive () || !iVictim->isAlive ())
	//	return;

	DEBUG_PRINTF ("PeriodicAuraLog: %X:%u attacked %X:%u for %u damage with spell %u",
			 GetHighGUID (), GetLowGUID (), iVictim->GetHighGUID (),
			 iVictim->GetLowGUID (), iDamage, iSpellId);

	SMSG_PERIODICAURALOG_t *outpkt = SMSG_PERIODICAURALOG_t::Create ();
	outpkt->Victim = iVictim->GetGUID ();
	outpkt->Attacker = GetGUID ();
	outpkt->SpellId = iSpellId;
	outpkt->TargetCount = 1;
	//outpkt->DamageType = iDamageType;
	outpkt->Damage = iDamage;
	outpkt->Assemble ();

	SendToSet (outpkt, true);
	DealDamage (iVictim, iDamage);
}

void Unit::AttackerStateUpdate (Unit *iVictim, uint32 iDamage, bool DoT)
{
	uint32 hit_status = 0xe2;
	uint32 damageType = 0;

	DEBUG_PRINTF ("%X:%u attacked %X:%u for %u damage",
				  GetHighGUID (), GetLowGUID (),
				  iVictim->GetLowGUID (), iVictim->GetHighGUID(), iDamage);

	if (!iDamage)
		//@@@@@@@@todo: highly temporary
		iDamage = 10;//CalculateDamage (this);
	else
		damageType = 1;

	if (DoT)
		hit_status = 0;

	// if we are currently casting a melee spell then finish it now
#if 0
	if (MeleeSpell)
	{
		if (CurrentSpell->getState () == SPELL_STATE_IDLE)
		{
			spell = m_currentSpell->m_spellInfo->Id;
			m_currentSpell->SendCastResult(0);
			m_currentSpell->SendSpellGo();
			for(uint32 i=0;i<2;i++)
				m_currentSpell->HandleEffects(m_currentSpell->m_targets.m_unitTarget,i);
			m_currentSpell->finish();
		}
	}
#endif

	SMSG_ATTACKERSTATEUPDATE_t *outpkt = SMSG_ATTACKERSTATEUPDATE_t::Create ();
	outpkt->AttackFlags = hit_status;
	outpkt->Attacker = GetGUID ();
	outpkt->Victim = iVictim->GetGUID ();
	outpkt->TotalDamage = iDamage;
	outpkt->Count = 1;
	DamageInfo *di = new DamageInfo ();
	di->Type = damageType;
	di->Float = 0;
	di->Damage = iDamage;
	di->Absorbed = 0;
	di->VictimState = 1;
	di->RoundDuration = 0;
	di->AdditionalSpellDamage = 0;
	di->AdditionalSpellId = 0;
	di->AdditionalSpellAbsorbed = 0;
	outpkt->DamageList.Push (di);

	SendToSet (outpkt, true);
	DealDamage (iVictim, iDamage);
}

void Unit::AttackStart (Unit *iVictim)
{
	// Prevent user from ignoring attack speed and stopping
	// and start combat really really fast
	if (IsAttackReady () && CanReachWithAttack (iVictim))
	{
		AttackerStateUpdate (iVictim, 0, false);
		SetAttackTimer ();
	}

	DEBUG_PRINTF ("%X:%u attacked %X:%u",
				  GetHighGUID (), GetLowGUID (),
				  iVictim->GetHighGUID (), iVictim->GetLowGUID ());

	// Send out ATTACKSTART
	SMSG_ATTACKSTART_t *outpkt = SMSG_ATTACKSTART_t::Create ();
	outpkt->Attacker = GetGUID ();
	outpkt->Victim = iVictim->GetGUID ();

	SendToSet (outpkt, true);

	// FLAGS changed so other players see attack animation
	//    addUnitFlag (0x00080000);
	//    setUpdateMaskBit (UNIT_FIELD_FLAGS);
}

void Unit::AttackStop (uint64 iVictimGuid)
{
	DEBUG_PRINTF ("%X:%u stopped attacking %X:%u",
				  GetHighGUID (), GetLowGUID (),
				  uint32 (iVictimGuid >> 32), uint32 (iVictimGuid));

	Field.SetBits (UNIT_FIELD_FLAGS, UFF_IN_COMBAT, 0);

	SMSG_ATTACKSTOP_t *outpkt = SMSG_ATTACKSTOP_t::Create ();
	outpkt->Attacker = GetGUID ();
	outpkt->Victim = iVictimGuid;

	SendToSet (outpkt, true);
}

bool Unit::AddAffect (Affect *iAff, bool iUniq)
{
	return false;
}

void Unit::RemoveAffect (Affect *aff)
{
    int aid = Affects.Find(aff);
	if(aid == -1)
            return;

	if(aff->CoAffect != 0)
	    RemoveAffect(aff->CoAffect);

        // Remove all modifiers of this affect
	for (int i = 0; i < aff->Modifiers.Length(); i++) {
		ApplyModifier(aff->Modifiers.Get(i), false, aff);
	}

	//_RemoveAura(aff);

	Affects.Delete(aid);
}

void Unit::RemoveAffectById(uint32 spellId)
{
}

bool Unit::RemoveAffect(uint32 spellId)
{
	return false;
}

void Unit::RemoveAllAffects()
{
}

void Unit::ApplyModifier (Modifier *iMod, bool iApply, Affect *iParent)
{
}


void Unit::UpdateSpells (uint32 iDeltaMs)
{

}


void Unit::InterruptSpell()
{
}

float Unit::getdistance( float xe, float ye, float xz, float yz )
{
	return sqrt( ( xe - xz ) * ( xe - xz ) + ( ye - yz ) * ( ye - yz ) );
}

float Unit::getangle( float xe, float ye, float xz, float yz )
{
	float w;
	w = RAD2DEG (atan ((yz - ye) / (xz - xe)));
	if (xz>=xe) {
		w = 90+w;
	} else {
		w = 270+w;
	}
	return w;
}

float Unit::geteasyangle( float angle )
{
	if(angle < 0)
		return fmod(fabs(angle), (float)360.0);
    return fmod(angle, (float)360.0);
}

bool Unit::inarc( float radius,  float xM, float yM, float offnung, float orientation, float xP, float yP )
{
	float distance = getdistance( xM, yM, xP, yP );
	float angle = getangle( xM, yM, xP, yP );
	float lborder = geteasyangle( ( orientation - (offnung/2) ) );
	float rborder = geteasyangle( ( orientation + (offnung/2) ) );
	if(radius>=distance &&( ( angle >= lborder ) &&
						   ( angle <= rborder ) ||
						   ( lborder > rborder && ( angle < rborder || angle > lborder ) ) ) ) {
		return true;
	} else {
		return false;
	}
}
