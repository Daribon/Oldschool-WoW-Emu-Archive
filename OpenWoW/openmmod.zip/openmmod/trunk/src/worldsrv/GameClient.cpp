/*
    Handle the World Server clients
    Copyright (C) 2004 Team Python
    Copyright (C) 2005 Team OpenWoW

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "GameClient.h"
#include "WorldServer.h"
#include "ProtoPacket.h"
#include "Log.h"
#include "Database.h"
#include "Player.h"

#include <openssl/sha.h>

GameClient::GameClient (Socket *sock) : Client (sock)
{
	Capabilities = 0;
	Login = NULL;
	GenSeed ();

	memset (&AccountData, 0, sizeof (AccountData));

	// Initiate authentification sequence
	SMSG_AUTH_CHALLENGE_t *outpkt = SMSG_AUTH_CHALLENGE_t::Create ();
	outpkt->Seed = Seed;
	outpkt->Assemble ();
	Send (outpkt);
}

GameClient::~GameClient ()
{
	LOG.Out (LOG_IMPORTANT, "User %s logged out\n", Login);
	if (Character)
	{
		Character->SaveToDB ();
		Character->DecRef ();
	}
	SaveAccountData ();
	delete [] Login;
}

void GameClient::SocketEvent (uint mask)
{
	/*
	 * Process one packet at a time, giving a chance to be serviced
	 * to other players that may be handled by this thread (also protect
	 * ourselves from someone that may flood the server with random data
	 * which would otherwise cause a DoS.
	 */
	if (!(mask & PF_READ))
		return;

	/// Eat as many packets as we can
	for (;;)
	{
		socket->Rewind ();

		uint8 header [2+4];
		if (!socket->Get (header, sizeof (header)))
			break;

		if (Authenticated ())
		{
			SaveRecvEncryptor ();
			DecryptRecv (header);
		}
		uint pktlen = GET_BE16 (header) + 2;
		if (socket->Avail () + sizeof (header) < pktlen)
		{
			DEBUG_PRINTF ("Got incomplete packet [%02x %02x %02x %02x %02x %02x], waiting for packet tail\n",
						  header [0],header [1],header [2],header [3],header [4],header [5]);
			RestoreRecvEncryptor ();
			break;
		}

		NetworkPacket *packet = NULL;
		uint32 opcode = GET_LE32 (header + 2);

		DEBUG_PRINTF ("Packet %s len %d\n", GetPacketName (opcode), pktlen);

		if (Authenticated ())
		{
			switch (opcode)
			{
#include "Parser.inc"
				default:
					LOG.Out (LOG_DEBUG, "Unhandled opcode %s\n", GetPacketName (opcode));
					socket->Skip (pktlen - sizeof (header));
					break;
			}
		}
		else
		{
			switch (opcode)
			{
				case CMSG_PING:
				{
					packet = CMSG_PING_t::Create (socket);
					if (packet)
						HandlePing (*(CMSG_PING_t *)packet);
					break;
				}
				case CMSG_AUTH_SESSION:
				{
					packet = CMSG_AUTH_SESSION_t::Create (socket, pktlen);
					if (packet)
						HandleAuthSession (*(CMSG_AUTH_SESSION_t *)packet);
					break;
				}
				default:
					LOG.Out (LOG_DEBUG, "PRE-AUTH: Unhandled opcode: %s\n",
							 GetPacketName (opcode));
					socket->Skip (pktlen - sizeof (header));
					break;
			}
		}

		if (packet && socket->Chewed () != pktlen)
			LOG.Out (LOG_IMPORTANT, "BAD PACKET OR PARSER: Chewed %d bytes, packet is %d bytes - OpCode: %s\n",
								 socket->Chewed (), pktlen, GetPacketName (opcode));

		socket->Swallow ();
		if (packet)
			packet->DecRef ();
	}
}

void GameClient::GenSeed ()
{
	do {
		Seed = rand ();
	} while (!Seed);
}

void GameClient::Send (NetworkPacket *packet)
{
	if (!packet->data)
		packet->Assemble ();

	if (Authenticated ())
		EncryptSend (packet->data);

	socket->SendData (packet);
	packet->DecRef ();
}

void GameClient::SaveAccountData ()
{
	if (!Login)
		return;

	char *ad [ARRAY_LEN (AccountData)];
	for (uint i = 0; i < ARRAY_LEN (AccountData); i++)
	{
		ad [i] = !AccountData [i] ? NULL :
			EncodeSQL (AccountData [i], sizeof (uint32) * 2 + 16 + GET_LE32 (AccountData [i] + 4));
		delete [] AccountData [i];
		AccountData [i] = 0;
	}

	DatabaseExecutor *dbex = World->rdb->GetExecutor ();
	if (dbex)
	{
		dbex->ExecuteF ("UPDATE accounts SET data0='%s',data1='%s',data2='%s' WHERE login='%s'",
						NN_STR (ad [0]), NN_STR (ad [1]), NN_STR (ad [2]), Login);
		World->rdb->PutExecutor (dbex);
	}

	for (uint i = 0; i < ARRAY_LEN (AccountData); i++)
		delete [] ad [i];
}

//-----------------------------// Encryption //------------------------------//

#define CRYPTED_SEND_LEN 4
#define CRYPTED_RECV_LEN 6

void GameClient::InitEncryptor ()
{
	Seed = 0;
	cs_prev = cr_prev = 0;
	cs_idx = cr_idx = 0;
}

void GameClient::DecryptRecv (uint8 *data)
{
	for (size_t i = 0; i < CRYPTED_RECV_LEN; i++)
	{
		uint8 b = data [i];
		data [i] = (b - cr_prev) ^ SessionKey [cr_idx];
		cr_prev = b;
		if (++cr_idx >= sizeof (SessionKey))
			cr_idx = 0;
	}
}

void GameClient::EncryptSend (uint8 *data)
{
	for (size_t i = 0; i < CRYPTED_SEND_LEN; i++)
	{
		data [i] = cs_prev = (data [i] ^ SessionKey [cs_idx]) + cs_prev;
		if (++cs_idx >= sizeof (SessionKey))
			cs_idx = 0;
	}
}

//------------------------------// Handlers //-------------------------------//

