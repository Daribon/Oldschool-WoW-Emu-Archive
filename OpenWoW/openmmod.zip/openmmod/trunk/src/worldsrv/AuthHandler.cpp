/*
    Handle Player Authentication/Logon procedure
    Copyright (C) 2005-2007 Team OpenWoW

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#include "GameClient.h"
#include "WorldServer.h"
#include "ProtoPacket.h"
#include "Log.h"
#include "Database.h"
#include "Player.h"

#include <openssl/sha.h>



void GameClient::FailAuth (uint32 iCode)
{
	SMSG_AUTH_RESPONSE_t *outpkt = SMSG_AUTH_RESPONSE_t::Create ();
	outpkt->ErrorCode = iCode;
	outpkt->Assemble ();
	Send (outpkt);
	LOG.Out (LOG_DEBUG, "Rejecting user '%s' with code %d\n", Login, iCode);
	// Switch back to unencrypted mode
	GenSeed ();

	if (Login)
	{
		delete [] Login;
		Login = NULL;
	}
	if (Character)
	{
		Character->DecRef ();
		Character = NULL;
	}
}

void GameClient::HandleAuthSession (CMSG_AUTH_SESSION_t &inpkt)
{
	// Save old account data, if any
	SaveAccountData ();

	Login = inpkt.Login;
	inpkt.Login = NULL; // steal this field from packet ;)

	LOG.Out (LOG_DEBUG, "'%s' attempting to login\n", Login);

	DatabaseExecutor *dbex = World->rdb->GetExecutor ();
	if (!dbex ||
	    dbex->ExecuteF ("SELECT level,sessionkey FROM accounts WHERE login='%s'", Login) != dbeOk ||
		!dbex->NextRow ())
	{
		FailAuth (WSE_UNKNOWN_ACCOUNT);
error:	if (dbex)
			World->rdb->PutExecutor (dbex);
		return;
	}

	uint level = dbex->GetU32 (0);
	const char *seskey = dbex->Get (1);
	if (!seskey
	 || !Hex2Bin (seskey, SessionKey, sizeof (SessionKey)))
	{
		FailAuth (WSE_LOGIN_UNAVAILABLE);
		goto error;
	}

	World->rdb->PutExecutor (dbex);

	// Set the 'authentificated' flag
	uint32 auth_seed = Seed;
	InitEncryptor ();

	// Check if server is full
	if (World->ClientLimit && World->GetClientsConnected () >= World->ClientLimit)
	{
		FailAuth (WSE_POSITION_IN_QUEUE_0);
		return;
	}

	// check if player is already connected
	if (World->SortedClients.FindSortedKey (Login) >= 0)
	{
		FailAuth (WSE_THIS_CHARACTER_IS_STILL_LOGGED_ON);
		return;
	}

	// Check client' hash
	size_t sl = strlen (Login);
	size_t buffsize = sl + 3 * sizeof (uint32) + sizeof (SessionKey);
	uint8 *buff = new uint8 [buffsize];
	uint8 *cur = buff;

	memcpy (cur, Login, sl);    cur += sl;
	PUT_LE32 (cur, 0);          cur += sizeof (uint32);
	PUT_LE32 (cur, inpkt.Seed); cur += sizeof (uint32);
	PUT_LE32 (cur, auth_seed);  cur += sizeof (uint32);
	memcpy (cur, SessionKey, sizeof (SessionKey)); cur += sizeof (SessionKey);

	uint8 digest [20];
	SHA1 (buff, (unsigned long)buffsize, digest);

	if (memcmp (digest, inpkt.Digest, sizeof (digest)))
	{
		FailAuth (WSE_AUTHENTICATION_FAILED);
		return;
	}

	World->SortedClients.InsertSorted (this);

	SMSG_AUTH_RESPONSE_t *outpkt = SMSG_AUTH_RESPONSE_t::Create ();
	outpkt->ErrorCode = WSE_AUTHENTICATION_SUCCESSFUL;
	outpkt->Counter = World->AuthCount++;
	outpkt->Assemble ();
	Send (outpkt);

	char *PrivName = NULL;

	dbex = World->db->GetExecutor ();
	if (dbex)
	{
		// Get user privileges
		if (dbex->ExecuteF ("SELECT name,flags FROM access_levels WHERE level=%d", level) == dbeOk &&
		    dbex->NextRow ())
		{
			PrivName = strnew (dbex->Get (0));
			Capabilities = dbex->GetU32 (1);
		}

		World->db->PutExecutor (dbex);
	}

	dbex = World->rdb->GetExecutor ();
	if (dbex)
	{
		// Get account data
		if (dbex->ExecuteF ("SELECT data0,data1,data2 FROM accounts WHERE login='%s'", Login) == dbeOk &&
		    dbex->NextRow ())
			for (uint i = 0; i < 3; i++)
			{
				size_t sz = DecodeSQL (dbex->Get (i), NULL, 0);
				if (sz)
				{
					AccountData [i] = new uint8 [sz];
					DecodeSQL (dbex->Get (i), AccountData [i], sz);
				}
			}

		World->rdb->PutExecutor (dbex);
	}
	// Update realm load etc
	World->UpdateRealm (true);

	LOG.Out (LOG_DEBUG, "%s '%s' logged in\n",
			 PrivName ? PrivName : "Stranger", Login);
	delete [] PrivName;
}

void GameClient::HandlePing (CMSG_PING_t &inpkt)
{
	SMSG_PONG_t *outpkt = SMSG_PONG_t::Create ();
	outpkt->Acknowledge = inpkt.Ordinal;
	outpkt->Assemble ();
	Send (outpkt);
}

void GameClient::HandleUpdateAccountData(CMSG_UPDATE_ACCOUNT_DATA_t &inpkt)
{
	// ToDo
}

void GameClient::HandleRequestAccountData(CMSG_REQUEST_ACCOUNT_DATA_t &inpkt)
{
	// ToDo
}

void GameClient::HandlePlayerLogin(CMSG_PLAYER_LOGIN_t &inpkt)
{
	// ToDo (Priority)
}

void GameClient::HandleCharCreate(CMSG_CHAR_CREATE_t &inpkt)
{
	Player *newPlayer = new Player();
	uint32 ret = newPlayer->Create(inpkt, this);

	if (ret = WSE_CHARACTER_CREATED)
		newPlayer->SaveToDB();

	LOG.Out (LOG_DEBUG, "Player::Create() returned %d for %s\n",
			 ret, Login);
	SMSG_CHAR_CREATE_t *outpkt = SMSG_CHAR_CREATE_t::Create();
	outpkt->ErrorCode = ret;
	outpkt->Assemble();
	Send (outpkt);
	newPlayer->DecRef();
	newPlayer = NULL;
}

void GameClient::HandleCharDelete(CMSG_CHAR_DELETE_t &inpkt)
{
	// ToDo (Low-Priority)
}

void GameClient::HandleCharEnum()
{
	uint8 CharCount = 0;
	uint32 guids[12];


	SMSG_CHAR_ENUM_t *outpkt = SMSG_CHAR_ENUM_t::Create();

	DatabaseExecutor *dbex = World->db->GetExecutor ();
	if (dbex)
	{
		if (dbex->ExecuteF ("SELECT guid FROM characters WHERE login='%s'", Login) == dbeOk)
		{
			while (dbex->NextRow ())
			{
				guids[CharCount++] = dbex->GetU32(0);
			}
		}

		World->db->PutExecutor (dbex);
	}

	uint8 TempCount = CharCount;
	for (uint8 i = 0; i < TempCount; i++)
	{
		CharacterData *data = new CharacterData;

		dbex = World->db->GetExecutor ();
		if (dbex)
		{
			if ( data->Load(dbex, guids[i]) )
				outpkt->List.InsertSorted(data);
			else
				CharCount--;

			World->db->PutExecutor (dbex);
		}
		else
			CharCount--;
	}


	outpkt->Count = CharCount;
	outpkt->Assemble();
	Send (outpkt);

}

