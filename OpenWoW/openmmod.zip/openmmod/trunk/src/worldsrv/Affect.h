/*
    Affect class
    Copyright (C) 2005 WoWD Team
    Copyright (C) 2005 Team OpenWoW

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public License
    along with this program; if not, write to the Free Software
    Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA  02111-1307  USA
*/

#ifndef __AFFECT_H__
#define __AFFECT_H__

#include "Vector.h"
#include "Timer.h"

// Number of fields starting with UNIT_FIELD_AURA reserved for positive auras
#define MAX_POSITIVE_AURAS	32
// Number of fields starting with UNIT_FIELD_AURA reserved for all auras
#define MAX_AURAS			56

//! 4-bit flag
enum AURA_FLAGS
{
	AFLAG_EMPTY = 0x0,
	AFLAG_SET = 0x9
};

enum MOD_TYPES
{
	SPELL_AURA_NONE = 0,                                // None
	SPELL_AURA_BIND_SIGHT = 1,                          // Bind Sight
	SPELL_AURA_MOD_POSSESS = 2,                         // Mod Possess
	SPELL_AURA_PERIODIC_DAMAGE = 3,                     // Periodic Damage
	SPELL_AURA_MOD_CONFUSE = 5,                         // Mod Confuse
	SPELL_AURA_MOD_CHARM = 6,                           // Mod Charm
	SPELL_AURA_MOD_FEAR = 7,                            // Mod Fear
	SPELL_AURA_PERIODIC_HEAL = 8,                       // Periodic Heal
	SPELL_AURA_MOD_ATTACKSPEED = 9,                     // Mod Attack Speed
	SPELL_AURA_MOD_THREAT = 10,                         // Mod Threat
	SPELL_AURA_MOD_TAUNT = 11,                          // Taunt
	SPELL_AURA_MOD_STUN = 12,                           // Stun
	SPELL_AURA_MOD_DAMAGE_DONE = 13,                    // Mod Damage Done
	SPELL_AURA_MOD_DAMAGE_TAKEN = 14,                   // Mod Damage Taken
	SPELL_AURA_DAMAGE_SHIELD = 15,                      // Damage Shield
	SPELL_AURA_MOD_STEALTH = 16,                        // Mod Stealth
	SPELL_AURA_MOD_DETECT = 17,                         // Mod Detect
	SPELL_AURA_MOD_INVISIBILITY = 18,                   // Mod Invisibility
	SPELL_AURA_MOD_INVISIBILITY_DETECTION = 19,         // Mod Invisibility Detection
	SPELL_AURA_MOD_RESISTANCE = 22,                     // Mod Resistance
	SPELL_AURA_PERIODIC_TRIGGER_SPELL = 23,             // Periodic Trigger
	SPELL_AURA_PERIODIC_ENERGIZE = 24,                  // Periodic Energize
	SPELL_AURA_MOD_PACIFY = 25,                         // Pacify
	SPELL_AURA_MOD_ROOT = 26,                           // Root
	SPELL_AURA_MOD_SILENCE = 27,                        // Silence
	SPELL_AURA_REFLECT_SPELLS = 28,                     // Reflect Spells %
	SPELL_AURA_MOD_STAT = 29,                           // Mod Stat
	SPELL_AURA_MOD_SKILL = 30,                          // Mod Skill
	SPELL_AURA_MOD_INCREASE_SPEED = 31,                 // Mod Speed
	SPELL_AURA_MOD_INCREASE_MOUNTED_SPEED = 32,         // Mod Speed Mounted
	SPELL_AURA_MOD_DECREASE_SPEED = 33,                 // Mod Speed Slow
	SPELL_AURA_MOD_INCREASE_HEALTH = 34,                // Mod Increase Health
	SPELL_AURA_MOD_INCREASE_ENERGY = 35,                // Mod Increase Energy
	SPELL_AURA_MOD_SHAPESHIFT = 36,                     // Shapeshift
	SPELL_AURA_EFFECT_IMMUNITY = 37,                    // Immune Effect
	SPELL_AURA_STATE_IMMUNITY = 38,                     // Immune State
	SPELL_AURA_SCHOOL_IMMUNITY = 39,                    // Immune School
	SPELL_AURA_DAMAGE_IMMUNITY = 40,                    // Immune Damage
	SPELL_AURA_DISPEL_IMMUNITY = 41,                    // Immune Dispel Type
	SPELL_AURA_PROC_TRIGGER_SPELL = 42,                 // Proc Trigger Spell
	SPELL_AURA_PROC_TRIGGER_DAMAGE = 43,                // Proc Trigger Damage
	SPELL_AURA_TRACK_CREATURES = 44,                    // Track Creatures
	SPELL_AURA_TRACK_RESOURCES = 45,                    // Track Resources
	SPELL_AURA_MOD_PARRY_SKILL = 46,                    // Mod Parry Skill
	SPELL_AURA_MOD_PARRY_PERCENT = 47,                  // Mod Parry Percent
	SPELL_AURA_MOD_DODGE_SKILL = 48,                    // Mod Dodge Skill
	SPELL_AURA_MOD_DODGE_PERCENT = 49,                  // Mod Dodge Percent
	SPELL_AURA_MOD_BLOCK_SKILL = 50,                    // Mod Block Skill
	SPELL_AURA_MOD_BLOCK_PERCENT = 51,                  // Mod Block Percent
	SPELL_AURA_MOD_CRIT_PERCENT = 52,                   // Mod Crit Percent
	SPELL_AURA_PERIODIC_LEECH = 53,                     // Periodic Leech
	SPELL_AURA_MOD_HIT_CHANCE = 54,                     // Mod Hit Chance
	SPELL_AURA_MOD_SPELL_HIT_CHANCE = 55,               // Mod Spell Hit Chance
	SPELL_AURA_TRANSFORM = 56,                          // Transform
	SPELL_AURA_MOD_SPELL_CRIT_CHANCE = 57,              // Mod Spell Crit Chance
	SPELL_AURA_MOD_INCREASE_SWIM_SPEED = 58,            // Mod Speed Swim
	SPELL_AURA_MOD_DAMAGE_DONE_CREATURE = 59,           // Mod Creature Dmg Done
	SPELL_AURA_MOD_PACIFY_SILENCE = 60,                 // Pacify & Silence
	SPELL_AURA_MOD_SCALE = 61,                          // Mod Scale
	SPELL_AURA_PERIODIC_HEALTH_FUNNEL = 62,             // Periodic Health Funnel
	SPELL_AURA_PERIODIC_MANA_FUNNEL = 63,               // Periodic Mana Funnel
	SPELL_AURA_PERIODIC_MANA_LEECH = 64,                // Periodic Mana Leech
	SPELL_AURA_MOD_CASTING_SPEED = 65,                  // Haste - Spells
	SPELL_AURA_FEIGN_DEATH = 66,                        // Feign Death
	SPELL_AURA_MOD_DISARM = 67,                         // Disarm
	SPELL_AURA_MOD_STALKED = 68,                        // Mod Stalked
	SPELL_AURA_SCHOOL_ABSORB = 69,                      // School Absorb
	SPELL_AURA_EXTRA_ATTACKS = 70,                      // Extra Attacks
	SPELL_AURA_MOD_SPELL_CRIT_CHANCE_SCHOOL = 71,       // Mod School Spell Crit Chance
	SPELL_AURA_MOD_POWER_COST = 72,                     // Mod Power Cost
	SPELL_AURA_MOD_POWER_COST_SCHOOL = 73,              // Mod School Power Cost
	SPELL_AURA_REFLECT_SPELLS_SCHOOL = 74,              // Reflect School Spells %
	SPELL_AURA_MOD_LANGUAGE = 75,                       // Mod Language
	SPELL_AURA_FAR_SIGHT = 76,                          // Far Sight
	SPELL_AURA_MECHANIC_IMMUNITY = 77,                  // Immune Mechanic
	SPELL_AURA_MOUNTED = 78,                            // Mounted
	SPELL_AURA_MOD_DAMAGE_PERCENT_DONE = 79,            // Mod Dmg %
	SPELL_AURA_MOD_PERCENT_STAT = 80,                   // Mod Stat %
	SPELL_AURA_SPLIT_DAMAGE = 81,                       // Split Damage
	SPELL_AURA_WATER_BREATHING = 82,                    // Water Breathing
	SPELL_AURA_MOD_BASE_RESISTANCE = 83,                // Mod Base Resistance
	SPELL_AURA_MOD_REGEN = 84,                          // Mod Health Regen
	SPELL_AURA_MOD_POWER_REGEN = 85,                    // Mod Power Regen
	SPELL_AURA_CHANNEL_DEATH_ITEM = 86,                 // Create Death Item
	SPELL_AURA_MOD_DAMAGE_PERCENT_TAKEN = 87,           // Mod Dmg % Taken
	SPELL_AURA_MOD_PERCENT_REGEN = 88,                  // Mod Health Regen Percent
	SPELL_AURA_PERIODIC_DAMAGE_PERCENT = 89,            // Periodic Damage Percent
	SPELL_AURA_MOD_RESIST_CHANCE = 90,                  // Mod Resist Chance
	SPELL_AURA_MOD_DETECT_RANGE = 91,                   // Mod Detect Range
	SPELL_AURA_PREVENTS_FLEEING = 92,                   // Prevent Fleeing
	SPELL_AURA_MOD_UNATTACKABLE = 93,                   // Mod Uninteractible
	SPELL_AURA_INTERRUPT_REGEN = 94,                    // Interrupt Regen
	SPELL_AURA_GHOST = 95,                              // Ghost
	SPELL_AURA_SPELL_MAGNET = 96,                       // Spell Magnet
	SPELL_AURA_MANA_SHIELD = 97,                        // Mana Shield
	SPELL_AURA_MOD_SKILL_TALENT = 98,                   // Mod Skill Talent
	SPELL_AURA_MOD_ATTACK_POWER = 99,                   // Mod Attack Power
	SPELL_AURA_AURAS_VISIBLE = 100,                     // Auras Visible
	SPELL_AURA_MOD_RESISTANCE_PCT = 101,                // Mod Resistance %
	SPELL_AURA_MOD_CREATURE_ATTACK_POWER = 102,         // Mod Creature Attack Power
	SPELL_AURA_MOD_TOTAL_THREAT = 103,                  // Mod Total Threat (Fade)
	SPELL_AURA_WATER_WALK = 104,                        // Water Walk
	SPELL_AURA_FEATHER_FALL = 105,                      // Feather Fall
	SPELL_AURA_HOVER = 106,                             // Hover
	SPELL_AURA_ADD_FLAT_MODIFIER = 107,                 // Add Flat Modifier
	SPELL_AURA_ADD_PCT_MODIFIER = 108,                  // Add % Modifier
	SPELL_AURA_ADD_TARGET_TRIGGER = 109,                // Add Class Target Trigger
	SPELL_AURA_MOD_POWER_REGEN_PERCENT = 110,           // Mod Power Regen %
	SPELL_AURA_ADD_CASTER_HIT_TRIGGER = 111,            // Add Class Caster Hit Trigger
	SPELL_AURA_OVERRIDE_CLASS_SCRIPTS = 112,            // Override Class Scripts
	SPELL_AURA_MOD_RANGED_DAMAGE_TAKEN = 113,           // Mod Ranged Dmg Taken
	SPELL_AURA_MOD_RANGED_DAMAGE_TAKEN_PCT = 114,       // Mod Ranged % Dmg Taken
	SPELL_AURA_MOD_HEALING = 115,                       // Mod Healing
	SPELL_AURA_IGNORE_REGEN_INTERRUPT = 116,            // Regen During Combat
	SPELL_AURA_MOD_MECHANIC_RESISTANCE = 117,           // Mod Mechanic Resistance
	SPELL_AURA_MOD_HEALING_PCT = 118,                   // Mod Healing %
	SPELL_AURA_SHARE_PET_TRACKING = 119,                // Share Pet Tracking
	SPELL_AURA_UNTRACKABLE = 120,                       // Untrackable
	SPELL_AURA_EMPATHY = 121,                           // Empathy (Lore, whatever)
	SPELL_AURA_MOD_OFFHAND_DAMAGE_PCT = 122,            // Mod Offhand Dmg %
	SPELL_AURA_MOD_POWER_COST_PCT = 123,                // Mod Power Cost %
	SPELL_AURA_MOD_RANGED_ATTACK_POWER = 124,           // Mod Ranged Attack Power
	SPELL_AURA_MOD_MELEE_DAMAGE_TAKEN = 125,            // Mod Melee Dmg Taken
	SPELL_AURA_MOD_MELEE_DAMAGE_TAKEN_PCT = 126,        // Mod Melee % Dmg Taken
	SPELL_AURA_RANGED_ATTACK_POWER_ATTACKER_BONUS = 127,// Rngd Atk Pwr Attckr Bonus
	SPELL_AURA_MOD_POSSESS_PET = 128,                   // Mod Possess Pet
	SPELL_AURA_MOD_INCREASE_SPEED_ALWAYS = 129,         // Mod Speed Always
	SPELL_AURA_MOD_MOUNTED_SPEED_ALWAYS = 130,          // Mod Mounted Speed Always
	SPELL_AURA_MOD_CREATURE_RANGED_ATTACK_POWER = 131,  // Mod Creature Ranged Attack Power
	SPELL_AURA_MOD_INCREASE_ENERGY_PERCENT = 132,       // Mod Increase Energy %
	SPELL_AURA_MOD_INCREASE_HEALTH_PERCENT = 133,       // Mod Max Health %
	SPELL_AURA_MOD_MANA_REGEN_INTERRUPT = 134,          // Mod Interrupted Mana Regen
	SPELL_AURA_MOD_HEALING_DONE = 135,                  // Mod Healing Done
	SPELL_AURA_MOD_HEALING_DONE_PERCENT = 136,          // Mod Healing Done %
	SPELL_AURA_MOD_TOTAL_STAT_PERCENTAGE = 137,         // Mod Total Stat %
	SPELL_AURA_MOD_HASTE = 138,                         // Haste - Melee
	SPELL_AURA_FORCE_REACTION = 139,                    // Force Reaction
	SPELL_AURA_MOD_RANGED_HASTE = 140,                  // Haste - Ranged
	SPELL_AURA_MOD_RANGED_AMMO_HASTE = 141,             // Haste - Ranged (Ammo Only)
	SPELL_AURA_MOD_BASE_RESISTANCE_PCT = 142,           // Mod Base Resistance %
	SPELL_AURA_MOD_RESISTANCE_EXCLUSIVE = 143,          // Mod Resistance Exclusive
	SPELL_AURA_SAFE_FALL = 144,                         // Safe Fall
	SPELL_AURA_CHARISMA = 145,                          // Charisma
	SPELL_AURA_PERSUADED = 146,                         // Persuaded
	SPELL_AURA_ADD_CREATURE_IMMUNITY = 147,             // Add Creature Immunity
	SPELL_AURA_RETAIN_COMBO_POINTS = 148,               // Retain Combo Points
};

class SpellEntry;

struct Modifier
{
	/// What does it modify? (str,int,hp)
	uint8 Type;
	/// By how much does it mod?
	int32 Amount;
	/// Misc Value
	uint32 MiscValue;
	/// second Misc Value
	uint32 MiscValue2;

	Modifier (uint8 t, int32 a, uint32 mv1, uint32 mv2) :
		Type (t), Amount (a), MiscValue (mv1), MiscValue2 (mv2)
	{
	}
};

/**
 * Casting spell should look time:
 *
 * \Verbatim
 * Affect *af = new Affect (AFF_GIANTSTR, spellId, 30, caster->GetGUID ())
 * af->AddMod(MOD_STRENGTH, 5);
 * victim->AddAffect(af);
 * \EndVerbatim
 *
 * TODO: should store something like spell strength or caster level.
 *       should we use affect id or spellId is enough? probably not
 *       because different spell ranks have differt ids (afaik)
 */
class Affect
{
private:
	SpellEntry *SpellProto;

public:
	/// Affect duration in msecs
	int32 Duration; 
	/// The GUID of the creep that casted this
	uint64 CasterGUID;

	/// Affect modifiers list
	DECLARE_VECTOR (ModifierVector, Modifier *,) Modifiers; //tolua_hide fixme subclasses make problems

	/// Unit slot for this aura
	uint8 AuraSlot;

	/// For auras causing periodic damage
	uint32 DamagePerTick;
	Timer DamageTimer;

	/// For auras that periodically trigger spells
	uint32 SpellPerTick;
	Timer SpellTimer;

	/// true if this modifier is positive
	bool Positive;
	/// An additional affect bound to this one (compound affects)
	Affect *CoAffect;

	Affect (SpellEntry *iProto, int32 iDuration, uint64 iGuid) :
		SpellProto (iProto), Duration (iDuration), CasterGUID (iGuid),
		Modifiers (8, 8), AuraSlot (0), DamagePerTick (0), DamageTimer (0),
		SpellPerTick (0), SpellTimer (0), Positive (false), CoAffect (0)
	{}

	void AddMod (uint8 t, int32 a, uint32 mv1, uint32 mv2)
	{ Modifiers.Push (new Modifier (t, a, mv1, mv2)); }

	void SetDamagePerTick (uint32 iDamage, uint32 iDeltaMs)
	{
		DamagePerTick = iDamage;
		DamageTimer.SetInterval (iDeltaMs);
	}

	void SetPeriodicTriggerSpell (uint32 iSpellId, uint32 iDeltaMs)
	{
		SpellPerTick = iSpellId;
		SpellTimer.SetInterval (iDeltaMs);
	};

#if 0
	uint32 GetSpellId () const
	{
		if (SpellProto)
			return SpellProto->field153;
		else
			return NULL;
	}

	uint32 GetId () const
	{
		if (SpellProto)
			return SpellProto->Id;
		else
			return NULL;
	}
#endif

	/**
	 * Update affects as time passes.
	 * @arg iDeltaMs
	 *   The time that has passed since last call to Update()
	 * @return
	 *   bit 0 set if periodic damage should be applied
	 *   bit 1 set if periodic spell should be triggered
	 */
	uint8 Update (uint32 iDeltaMs)
	{
		uint8 rc = 0;

		if (Duration > 0)
		{
			Duration -= iDeltaMs;
			if (Duration < 0)
				Duration = 0;
		}

		if (DamagePerTick)
			if (DamageTimer.Tick (iDeltaMs))
				rc |= 1;

		if (SpellPerTick)
            if (SpellTimer.Tick (iDeltaMs))
				rc |= 2;

		return rc;
	}
};

#endif // __AFFECT_H__
