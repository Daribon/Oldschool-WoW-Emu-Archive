using System;

namespace Server
{
	/// <summary>
	/// Summary description for Creature.
	/// </summary>
	public class Creature : Mobile
	{
		public Creature()
		{
		}
	}
}
