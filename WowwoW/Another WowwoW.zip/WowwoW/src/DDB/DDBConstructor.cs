using System;

namespace DDB
{
	/// <summary>
	/// Summary description for DDBConstructor.
	/// </summary>
	public class DDBConstructor : Attribute
	{
		public DDBConstructor()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
