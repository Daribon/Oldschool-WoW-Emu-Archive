using System;

namespace Server
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class SpecStates
	{
		public static int Combustion = 0x15af54;
		public SpecStates()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
