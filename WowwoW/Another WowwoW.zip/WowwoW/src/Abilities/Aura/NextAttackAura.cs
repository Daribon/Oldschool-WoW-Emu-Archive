using System;
using Server.Items;

namespace Server
{/*
	/// <summary>
	/// Summary description for ItemAura.
	/// </summary>
	public class NextAttackEffect 
	{
		int number;
		SpellTemplate spell;
		public object OnEffect;
		public NextAttackEffect( SpellTemplate st, int Number  )
		{
			this.number = Number;
			this.spell = st;
		}
		public delegate void NextAttackEffectDelegate( Mobile attack, Mobile target, SpellTemplate st );
		public void TakeEffect(Mobile attacker, Mobile target)
		{
			( OnEffect as NextAttackEffectDelegate )( attacker,target,spell );
		}
	}*/
}
