using System;
using Server.Creatures;

namespace Server
{
	/// <summary>
	/// Summary description for Class1.
	/// </summary>
	public class TaxiVendor : BaseCreature
	{
		public int MountId; 
		public TaxiVendor() : base()
		{
			
		}
	}
}
