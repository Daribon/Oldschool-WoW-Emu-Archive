using System;

namespace WowwoW.Quest
{
	/// <summary>
	/// Summary description for NpcSpeakQuest.
	/// </summary>
	public class NpcSpeakQuest
	{
		public NpcSpeakQuest()
		{
			//
			// TODO: Add constructor logic here
			//
		}
	}
}
