namespace Server
{
    using System;

    public enum SkillsIds
    {
        // Fields
        Mining = 0xba
    }
}

