namespace Server
{
    using System;

    public class StavesSkill : Skill
    {
        // Methods
        public StavesSkill()
        {
        }

        public StavesSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x88;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x88;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xe3;
            }
        }

    }
}

