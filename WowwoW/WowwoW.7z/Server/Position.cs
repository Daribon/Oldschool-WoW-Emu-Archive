namespace Server
{
    using System;

    public class Position
    {
        // Methods
        public Position(float xx, float yy, float zz, int map)
        {
            this.x = xx;
            this.y = yy;
            this.z = zz;
            this.mapId = map;
        }

        public int QuickDistance(Mobile with)
        {
            int num1 = (int) this.x;
            int num2 = (int) this.y;
            int num3 = (int) with.X;
            int num4 = (int) with.Y;
            num1 -= num3;
            num2 -= num4;
            num1 *= num1;
            num2 *= num2;
            return (num1 + num2);
        }


        // Properties
        public int MapId
        {
            get
            {
                return this.mapId;
            }
        }

        public float X
        {
            get
            {
                return this.x;
            }
        }

        public float Y
        {
            get
            {
                return this.y;
            }
        }

        public float Z
        {
            get
            {
                return this.z;
            }
        }


        // Fields
        private int mapId;
        private float x;
        private float y;
        private float z;
    }
}

