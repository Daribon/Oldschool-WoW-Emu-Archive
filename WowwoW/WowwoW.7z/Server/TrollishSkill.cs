namespace Server
{
    using System;

    public class TrollishSkill : Skill
    {
        // Methods
        public TrollishSkill()
        {
        }

        public TrollishSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x13b;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x13b;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x1cad;
            }
        }

    }
}

