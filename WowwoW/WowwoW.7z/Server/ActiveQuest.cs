namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;
    using System.Reflection;

    public class ActiveQuest
    {
        // Methods
        public ActiveQuest(GenericReader gr)
        {
            this.delivery = new Hashtable();
            this.npcobj = new Hashtable();
            this.areas = new ArrayList();
            this.Deserialisation(gr);
        }

        public ActiveQuest(BaseQuest bq)
        {
            this.delivery = new Hashtable();
            this.npcobj = new Hashtable();
            this.areas = new ArrayList();
            ConstructorInfo[] infoArray1 = bq.GetType().GetConstructors();
            this.activeQuest = (BaseQuest) infoArray1[0].Invoke(null);
        }

        public bool AllAreaDiscovered()
        {
            bool flag1 = true;
            if (this.HaveDiscoveryObj)
            {
                int[] numArray1 = this.activeQuest.DiscoverigArea.Items;
                for (int num2 = 0; num2 < numArray1.Length; num2++)
                {
                    int num1 = numArray1[num2];
                    if (!this.areas.Contains(num1))
                    {
                        flag1 = false;
                    }
                }
            }
            return flag1;
        }

        public bool CheckAreaId(int aId)
        {
            bool flag1 = false;
            if (this.HaveDiscoveryObj && this.activeQuest.DiscoverigArea.Contains(aId))
            {
                flag1 = this.areas.Contains(aId);
            }
            return flag1;
        }

        public bool CompletedFor(Character c)
        {
            if (!this.Done)
            {
                if (!this.HaveNPCTargetId || (this.activeQuest.NPCTargetId != c.Id))
                {
                    return false;
                }
                if (this.HaveDiscoveryObj && !this.AllAreaDiscovered())
                {
                    return false;
                }
                if (this.HaveNPCObj && !this.DoneAllNpcObj())
                {
                    return false;
                }
                if (this.HaveDeliveryObj && !this.DoneAllDeliveryObj())
                {
                    return false;
                }
            }
            return true;
        }

        public int DeliveryAmount(Item it)
        {
            return this.DeliveryAmount(it.Id);
        }

        public int DeliveryAmount(int id)
        {
            int num1 = -1;
            if (this.HaveDeliveryObj)
            {
                DeliveryObjective objective1 = this.activeQuest.DeliveryObjectives.GetById(id);
                if (objective1 != null)
                {
                    num1 = objective1.Amount;
                }
            }
            return num1;
        }

        public int DeliveryCurrentAmount()
        {
            int num1 = 0;
            if (this.HaveDeliveryObj)
            {
                foreach (int num2 in this.delivery.Keys)
                {
                    num1 += ((int) this.delivery[num2]);
                }
            }
            return num1;
        }

        public int DeliveryCurrentAmount(Item it)
        {
            return this.DeliveryCurrentAmount(it.Id);
        }

        public int DeliveryCurrentAmount(int id)
        {
            int num1 = 0;
            if (this.HaveDeliveryObj)
            {
                DeliveryObjective objective1 = this.activeQuest.DeliveryObjectives.GetById(id);
                if ((objective1 != null) && this.delivery.ContainsKey(id))
                {
                    num1 = (int) this.delivery[id];
                }
            }
            return num1;
        }

        public void Deserialisation(GenericReader gr)
        {
            int num1 = gr.ReadInt();
            int num12 = num1;
            if (num12 == 0)
            {
                int num2 = gr.ReadInt();
                if (num2 > 0)
                {
                    for (int num3 = 0; num3 < num2; num3++)
                    {
                        int num4 = gr.ReadInt();
                        int num5 = gr.ReadInt();
                        this.delivery.Add(num4, num5);
                    }
                }
                int num6 = gr.ReadInt();
                if (num6 > 0)
                {
                    for (int num7 = 0; num7 < num6; num7++)
                    {
                        int num8 = gr.ReadInt();
                        int num9 = gr.ReadInt();
                        this.npcobj.Add(num8, num9);
                    }
                }
                int num10 = gr.ReadInt();
                if (num10 > 0)
                {
                    for (int num11 = 0; num11 < num10; num11++)
                    {
                        this.areas.Add(gr.ReadInt());
                    }
                }
                this.activeQuest = World.CreateQuestById(gr.ReadInt());
                this.completed = gr.ReadBool();
            }
        }

        public bool DiscoverAreaId(int aId)
        {
            bool flag1 = false;
            if (!this.HaveDiscoveryObj || !this.activeQuest.DiscoverigArea.Contains(aId))
            {
                return flag1;
            }
            if (!this.areas.Contains(aId))
            {
                this.areas.Add(aId);
            }
            return true;
        }

        public bool DoneAllDeliveryObj()
        {
            bool flag1 = true;
            if (!this.HaveDeliveryObj)
            {
                return flag1;
            }
            DeliveryObjective[] objectiveArray1 = this.activeQuest.DeliveryObjectives.Items;
            for (int num1 = 0; num1 < objectiveArray1.Length; num1++)
            {
                DeliveryObjective objective1 = objectiveArray1[num1];
                if (this.delivery.ContainsKey(objective1.Id))
                {
                    if (((int) this.delivery[objective1.Id]) >= objective1.Amount)
                    {
                        goto Label_0067;
                    }
                    flag1 = false;
                    break;
                }
                flag1 = false;
                break;
            Label_0067:;
            }
            return flag1;
        }

        public bool DoneAllNpcObj()
        {
            bool flag1 = true;
            if (!this.HaveNPCObj)
            {
                return flag1;
            }
            NPCObjective[] objectiveArray1 = this.activeQuest.NPCObjectives.Items;
            for (int num1 = 0; num1 < objectiveArray1.Length; num1++)
            {
                NPCObjective objective1 = objectiveArray1[num1];
                if (this.npcobj.ContainsKey(objective1.Id2))
                {
                    if (((int) this.npcobj[objective1.Id2]) >= objective1.Amount)
                    {
                        goto Label_0067;
                    }
                    flag1 = false;
                    break;
                }
                flag1 = false;
                break;
            Label_0067:;
            }
            return flag1;
        }

        public int IncreaseDelivery(Item it)
        {
            return this.IncreaseDelivery(it.Id);
        }

        public int IncreaseDelivery(int id)
        {
            int num1 = 0;
            if (!this.HaveDeliveryObj)
            {
                return num1;
            }
            DeliveryObjective objective1 = this.activeQuest.DeliveryObjectives.GetById(id);
            if (objective1 == null)
            {
                return num1;
            }
            if (this.delivery.ContainsKey(id))
            {
                int num2 = (int) this.delivery[id];
                if (num2 < objective1.Amount)
                {
                    num2++;
                    this.delivery[id] = num2;
                    num1 = num2;
                }
                return num1;
            }
            this.delivery.Add(id, 1);
            return 1;
        }

        public int IncreaseNpcObj(Mobile mob)
        {
            return this.IncreaseNpcObj(mob.Id);
        }

        public int IncreaseNpcObj(int id)
        {
            int num1 = 0;
            if (!this.HaveNPCObj)
            {
                return num1;
            }
            NPCObjective objective1 = this.activeQuest.NPCObjectives.GetById(id);
            if (objective1 == null)
            {
                return num1;
            }
            if (this.npcobj.ContainsKey(id))
            {
                int num2 = (int) this.npcobj[id];
                if (num2 < objective1.Amount)
                {
                    num2++;
                    this.npcobj[id] = num2;
                }
                return num2;
            }
            this.npcobj.Add(id, 1);
            return 1;
        }

        public bool NeedItem(Item it)
        {
            return this.NeedItem(it.Id);
        }

        public bool NeedItem(int id)
        {
            bool flag1 = false;
            if (!this.HaveDeliveryObj)
            {
                return flag1;
            }
            DeliveryObjective objective1 = this.activeQuest.DeliveryObjectives.GetById(id);
            if (objective1 == null)
            {
                return flag1;
            }
            if (this.delivery.ContainsKey(id))
            {
                return (((int) this.delivery[id]) < objective1.Amount);
            }
            return true;
        }

        public int NpcObjAmount(Mobile mob)
        {
            return this.NpcObjAmount(mob.Id);
        }

        public int NpcObjAmount(int id)
        {
            int num1 = -1;
            if (this.HaveNPCObj)
            {
                NPCObjective objective1 = this.activeQuest.NPCObjectives.GetById(id);
                if (objective1 != null)
                {
                    num1 = objective1.Amount;
                }
            }
            return num1;
        }

        public int NpcObjCurrentAmount(Mobile mob)
        {
            return this.NpcObjCurrentAmount(mob.Id);
        }

        public int NpcObjCurrentAmount(int id)
        {
            int num1 = 0;
            if (this.HaveNPCObj)
            {
                NPCObjective objective1 = this.activeQuest.NPCObjectives.GetById(id);
                if ((objective1 != null) && this.npcobj.ContainsKey(id))
                {
                    num1 = (int) this.npcobj[id];
                }
            }
            return num1;
        }

        public void Serialisation(GenericWriter gw)
        {
            int num1 = 0;
            gw.Write(num1);
            gw.Write(this.delivery.Keys.Count);
            foreach (int num2 in this.delivery.Keys)
            {
                gw.Write(num2);
                gw.Write((int) this.delivery[num2]);
            }
            gw.Write(this.npcobj.Keys.Count);
            foreach (int num3 in this.npcobj.Keys)
            {
                gw.Write(num3);
                gw.Write((int) this.npcobj[num3]);
            }
            gw.Write(this.areas.Count);
            foreach (int num4 in this.areas)
            {
                gw.Write(num4);
            }
            gw.Write(this.Id);
            gw.Write(this.completed);
        }


        // Properties
        public BaseQuest baseQuest
        {
            get
            {
                return this.activeQuest;
            }
        }

        public bool Completed
        {
            get
            {
                if (!this.Done)
                {
                    if (this.HaveNPCTargetId)
                    {
                        return false;
                    }
                    if (this.HaveDiscoveryObj && !this.AllAreaDiscovered())
                    {
                        return false;
                    }
                    if (this.HaveNPCObj && !this.DoneAllNpcObj())
                    {
                        return false;
                    }
                    if (this.HaveDeliveryObj && !this.DoneAllDeliveryObj())
                    {
                        return false;
                    }
                }
                return true;
            }
        }

        public bool DeliveryNotForOwner
        {
            get
            {
                return this.activeQuest.DeliveryNotForOwner;
            }
        }

        public bool Done
        {
            get
            {
                return this.completed;
            }
            set
            {
                this.completed = value;
            }
        }

        public bool HaveDeliveryObj
        {
            get
            {
                return this.activeQuest.HaveDeliveryObj;
            }
        }

        public bool HaveDiscoveryObj
        {
            get
            {
                return this.activeQuest.HaveDiscoveryObj;
            }
        }

        public bool HaveNPCObj
        {
            get
            {
                return this.activeQuest.HaveNPCObj;
            }
        }

        public bool HaveNPCTargetId
        {
            get
            {
                return this.activeQuest.HaveNPCTargetId;
            }
        }

        public int Id
        {
            get
            {
                return this.activeQuest.Id;
            }
        }

        public bool QuestIsBugged
        {
            get
            {
                return this.activeQuest.QuestIsBugged;
            }
        }

        public Type QuestType
        {
            get
            {
                return this.activeQuest.GetType();
            }
        }

        public bool Repeatable
        {
            get
            {
                return this.activeQuest.Repeatable;
            }
        }


        // Fields
        private BaseQuest activeQuest;
        private ArrayList areas;
        private bool completed;
        private Hashtable delivery;
        private Hashtable npcobj;
    }
}

