namespace Server
{
    using System;
    using System.Collections;
    using System.Runtime.CompilerServices;

    public delegate void OnSelfSpellEffectMultiple(BaseAbility ba, Mobile c, ArrayList targets);

}

