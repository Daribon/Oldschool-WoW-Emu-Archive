namespace Server
{
    using System;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;
    using System.Reflection;
    using System.Text;

    public class ClientHandler
    {
        // Methods
        public ClientHandler(TcpClientBis _ClientSocket, int num, string handle)
        {
            this.ContinueProcess = false;
            this.length = 0;
            this.sb = new StringBuilder();
            this.handler = handle;
            this.m_Num = num;
            this.ClientSocket = _ClientSocket;
            this.networkStream = this.ClientSocket.GetStream();
            this.bytes = new byte[this.ClientSocket.ReceiveBufferSize];
            this.ContinueProcess = true;
            this.m_State = 0;
            if (handle == "PlayerHandler")
            {
                this.Send(new byte[8] { 0, 6, 0xec, 1, 0x71, 0x2c, 0x7e, 0x88 } );
            }
        }

        public void Close()
        {
            Console.WriteLine("Closing connection");
            this.networkStream.Close();
            this.ClientSocket.Close();
        }

        public static ConstructorInfo FindConstructor(string cls)
        {
            char[] chArray2 = new char[1] { '.' } ;
            char[] chArray1 = chArray2;
            string[] textArray1 = cls.Split(chArray1);
            Module[] moduleArray1 = Assembly.GetAssembly(typeof(ClientHandler)).GetModules(false);
            Module module1 = moduleArray1[0];
            Type[] typeArray1 = module1.FindTypes(Module.FilterTypeName, textArray1[textArray1.Length - 1]);
            ConstructorInfo[] infoArray1 = typeArray1[0].GetConstructors();
            ConstructorInfo[] infoArray3 = infoArray1;
            for (int num1 = 0; num1 < infoArray3.Length; num1++)
            {
                ConstructorInfo info1 = infoArray3[num1];
                ParameterInfo[] infoArray2 = info1.GetParameters();
                if (infoArray2.Length == 0)
                {
                    return info1;
                }
            }
            return null;
        }

        public void Process()
        {
            try
            {
                if (this.networkStream.DataAvailable)
                {
                    int num1 = this.networkStream.Read(this.bytes, 0, this.bytes.Length);
                    if (num1 <= 0)
                    {
                        return;
                    }
                    this.length += num1;
                    this.ProcessDataReceived();
                }
            }
            catch (IOException)
            {
                this.ProcessDataReceived();
                this.networkStream.Flush();
            }
            catch (SocketException)
            {
                this.networkStream.Close();
                this.ClientSocket.Close();
                this.ContinueProcess = false;
                Console.WriteLine("Conection is broken!");
            }
        }

        private void ProcessDataReceived()
        {
            if (this.theClient == null)
            {
                ConstructorInfo info1 = ClientHandler.FindConstructor(this.handler);
                this.theClient = (TcpIPSocketClient) info1.Invoke(null);
                this.theClient.theClientHandler = this;
            }
            byte[] buffer1 = this.theClient.ProcessDataReceived(this.bytes, this, this.length);
            if (buffer1 != null)
            {
                this.Send(buffer1);
            }
            this.length = 0;
        }

        public void Send(string str)
        {
            try
            {
                if (str.Length <= 0)
                {
                    return;
                }
                StringBuilder builder1 = new StringBuilder();
                builder1.Append(str);
                byte[] buffer1 = Encoding.ASCII.GetBytes(builder1.ToString());
                this.networkStream.Write(buffer1, 0, buffer1.Length);
            }
            catch (Exception)
            {
            }
        }

        public void Send(byte[] str)
        {
            try
            {
                this.networkStream.Write(str, 0, str.Length);
            }
            catch (Exception)
            {
            }
        }

        public void Send(byte[] str, int length)
        {
            try
            {
                this.networkStream.Write(str, 0, length);
            }
            catch (Exception)
            {
            }
        }


        // Properties
        public bool Alive
        {
            get
            {
                return this.ContinueProcess;
            }
        }

        public IPAddress IP
        {
            get
            {
                return this.ClientSocket.IP;
            }
        }

        public NetworkStream NetStream
        {
            get
            {
                return this.networkStream;
            }
        }

        public int Port
        {
            get
            {
                return this.ClientSocket.Port;
            }
        }

        public IPAddress SourceIP
        {
            get
            {
                return this.ClientSocket.SourceIP;
            }
        }


        // Fields
        private byte[] bytes;
        private TcpClientBis ClientSocket;
        private bool ContinueProcess;
        private string handler;
        private int length;
        public int m_Num;
        public int m_State;
        private NetworkStream networkStream;
        private StringBuilder sb;
        private TcpIPSocketClient theClient;
    }
}

