namespace Server
{
    using System;

    public class TextColor
    {
        // Methods
        public TextColor()
        {
        }

        public static string Set(TextColors c, string text)
        {
            return string.Format("|c{0:x8}{1}|r", TextColor.ToARGB(c), text);
        }

        public static string Set(byte alpha, byte red, byte green, byte blue, string text)
        {
            //ulong num1 = ((((alpha << 0x18) | (red << 0x10)) | (green << 8)) | blue) & 0xffffffff;
			 ulong num1 = (((((ulong)alpha << 0x18) | ((ulong)red << 0x10)) | ((ulong)green << 8)) | (ulong)blue) & 0xffffffff;//fix
            return string.Format("|c{0:x8}{1}|r", num1, text);
        }

        public static ulong ToARGB(TextColors c)
        {
            return (ulong) (c & ((TextColors) 0xffffffff));
        }

    }
}

