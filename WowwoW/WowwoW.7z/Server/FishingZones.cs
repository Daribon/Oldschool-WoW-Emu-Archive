namespace Server
{
    using System;
    using System.Collections;

    public class FishingZones
    {
        // Methods
        public FishingZones()
        {
            this.zones = new ArrayList();
        }

        public void Add(float x, float y, float z, float radius, GameObjectDescription d)
        {
            this.zones.Add(new FishZone(x, y, z, radius, d));
        }

        public GameObjectDescription InsideFishingZone(float x, float y, float z)
        {
            foreach (FishZone zone1 in this.zones)
            {
                if (zone1.Inside(x, y, z))
                {
                    return zone1.desc;
                }
            }
            return null;
        }


        // Fields
        private ArrayList zones;

        // Nested Types
        private class FishZone
        {
            // Methods
            public FishZone(float _x, float _y, float _z, float _radius, GameObjectDescription _desc)
            {
                this.x = _x;
                this.y = _y;
                this.z = _z;
                this.radius = _radius * _radius;
                this.desc = _desc;
            }

            public bool Inside(float _x, float _y, float _z)
            {
                float single1 = this.x - _x;
                float single2 = this.y - _y;
                single1 *= single1;
                single2 *= single2;
                if ((single1 + single2) < this.radius)
                {
                    return true;
                }
                return false;
            }


            // Fields
            public GameObjectDescription desc;
            private float radius;
            private float x;
            private float y;
            private float z;
        }
    }
}

