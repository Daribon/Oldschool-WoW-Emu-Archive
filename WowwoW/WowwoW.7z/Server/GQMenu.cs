namespace Server
{
    using System;
    using System.Collections;

    public class GQMenu
    {
        // Methods
        public GQMenu()
        {
            this.list = new ArrayList();
        }

        public GQMenu(GQMenuItem item)
        {
            this.list = new ArrayList();
            this.Add(item);
        }

        public GQMenu(uint menuId, DialogStatus icon, string text)
        {
            this.list = new ArrayList();
            this.Add(menuId, icon, text);
        }

        public void Add(GQMenuItem item)
        {
            this.list.Add(item);
        }

        public void Add(uint menuId, DialogStatus icon, string text)
        {
            this.list.Add(new GQMenuItem(menuId, icon, text));
        }


        // Properties
        public int Count
        {
            get
            {
                return this.list.Count;
            }
        }

        public GQMenuItem[] Items
        {
            get
            {
                return (GQMenuItem[]) this.list.ToArray(typeof(GQMenuItem));
            }
        }


        // Fields
        private ArrayList list;
    }
}

