namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;
    using System.Net;
    using System.Net.Sockets;

    public class PlayerHandler : SockClient
    {
        // Methods
        public PlayerHandler(Socket from, RemoveClientDelegate rftsl) : base(from, rftsl)
        {
            byte[] buffer2 = new byte[4];
            this.key = buffer2;
            this.firstPacket = true;
            this.needEncode = false;
            buffer2 = new byte[7];
            buffer2[1] = 5;
            this.nullAction = buffer2;
            this.test = new Queue();
            this.debloque = false;
            this.lastUpdate = DateTime.Now;
            this.needLog = false;
            this.lastCoordTrajet = null;
            byte[] buffer1 = new byte[8];
            int num1 = 0;
            Converter.ToBytes((ushort) 0x600, buffer1, ref num1);
            Converter.ToBytes((ushort) 0x1ec, buffer1, ref num1);
            Converter.ToBytes(0x1000, buffer1, ref num1);
            this.Send(buffer1, true);
        }

        public void Decode(byte[] data, int length)
        {
            byte[] buffer1 = this.SS_Hash;
            for (int num1 = 0; num1 < 6; num1++)
            {
                byte num2 = this.key[0];
                this.key[0] = data[num1];
                byte num3 = data[num1];
                num3 = (byte) (num3 - num2);
                byte num4 = this.key[1];
                num2 = buffer1[num4];
                num2 = (byte) (num2 ^ num3);
                data[num1] = num2;
                num2 = this.key[1];
                num2 = (byte) (num2 + 1);
                this.key[1] = (byte) (num2 % 40);
            }
        }

        public void Decode(byte[] data, int offset, int length)
        {
            byte[] buffer1 = this.SS_Hash;
            for (int num1 = 0; num1 < 6; num1++)
            {
                byte num2 = this.key[0];
                this.key[0] = data[offset + num1];
                byte num3 = data[offset + num1];
                num3 = (byte) (num3 - num2);
                byte num4 = this.key[1];
                num2 = buffer1[num4];
                num2 = (byte) (num2 ^ num3);
                data[num1 + offset] = num2;
                num2 = this.key[1];
                num2 = (byte) (num2 + 1);
                this.key[1] = (byte) (num2 % 40);
            }
        }

        public void DecodeSansAff(byte[] data, int length)
        {
            byte[] buffer1 = this.SS_Hash;
            for (int num1 = 0; num1 < 6; num1++)
            {
                byte num2 = this.key[0];
                this.key[0] = data[num1];
                byte num3 = data[num1];
                num3 = (byte) (num3 - num2);
                byte num4 = this.key[1];
                num2 = buffer1[num4];
                num2 = (byte) (num2 ^ num3);
                data[num1] = num2;
                num2 = this.key[1];
                num2 = (byte) (num2 + 1);
                this.key[1] = (byte) (num2 % 40);
            }
        }

        public byte[] DequeueData(byte[] data, int length)
        {
            byte[] buffer6;
            int num1 = 0;
            int num2 = 0;
            int num3 = 0;
            try
            {
                if (this.playerAccount == null)
                {
                    this.firstPacket = true;
                    if (((IPEndPoint) this.clientSocket.RemoteEndPoint) == null)
                    {
                        return null;
                    }
                    this.playerAccount = World.allAccounts.FindAccountByIp(base.IP, ((IPEndPoint) this.clientSocket.RemoteEndPoint).Port);
                }
                else
                {
                    this.playerAccount.lastHeartBeat = DateTime.Now;
                }
                while (num2 != -1)
                {
                    int num10;
                    byte[] buffer3;
                    byte[] buffer4;
                    int num11;
                    byte[] buffer5;
                    string text1;
                    int num13;
                    string text2;
                    string text3;
                    int num15;
                    string text4;
                    int num16;
                    string text5;
                    byte[] buffer7;
                    if (!this.firstPacket)
                    {
                        byte num4 = data[num2];
                        byte num5 = data[num2 + 1];
                        byte num6 = data[num2 + 2];
                        byte num7 = data[num2 + 3];
                        this.Decode(data, num2, length - num2);
                        num3 = data[num2 + 2] + (data[num2 + 3] << 8);
                        num1 = data[num2 + 1] + (data[num2] << 8);
                        if ((num2 + num1) <= data.Length)
                        {
                            goto Label_0135;
                        }
                        byte[] buffer1 = new byte[data.Length - num2];
                        Buffer.BlockCopy(data, num2, buffer1, 0, buffer1.Length);
                        if (buffer1.Length > 0)
                        {
                            buffer1[0] = num4;
                        }
                        if (buffer1.Length > 1)
                        {
                            buffer1[1] = num5;
                        }
                        if (buffer1.Length > 2)
                        {
                            buffer1[2] = num6;
                        }
                        if (buffer1.Length > 3)
                        {
                            buffer1[3] = num7;
                        }
                        return buffer1;
                    }
                    num3 = data[num2 + 2] + (data[num2 + 3] << 8);
                    num1 = data[num2 + 1] + (data[num2] << 8);
                Label_0135:
                    this.firstPacket = false;
                    if ((this.playerAccount != null) && (this.playerAccount.loggoutTimer != null))
                    {
                        if (num3 == 0x4e)
                        {
                            this.playerAccount.CancelLogout();
                            return null;
                        }
                        this.SendNullAction(num3);
                        return null;
                    }
                    int num23 = num3;
                    if (num23 <= 0x3d)
                    {
                        switch (num23)
                        {
                            case 0x36:
                            case 0x37:
                            case 0x38:
                            case 0x3d:
                            {
                                goto Label_01D0;
                            }
                        }
                    }
                    else if (((num23 == 0xee) || (num23 == 0x1dc)) || (num23 == 0x1ed))
                    {
                        goto Label_01D0;
                    }
                    if (this.loggedChar == null)
                    {
                        base.Dispose();
                        return null;
                    }
                Label_01D0:
                    num23 = num3;
                    if (num23 <= 0x16d)
                    {
                        if (num23 <= 0x98)
                        {
                            if (num23 <= 0x56)
                            {
                                if (num23 <= 0x3d)
                                {
                                    switch (num23)
                                    {
                                        case 0x36:
                                        {
                                            this.playerAccount.AddCharacter(data);
                                            goto Label_16C1;
                                        }
                                        case 0x37:
                                        {
                                            this.needLog = false;
                                            num10 = 4;
                                            buffer3 = this.playerAccount.PrepareDataList(ref num10);
                                            num10 -= 2;
                                            buffer3[0] = (byte) ((num10 >> 8) & 0xff);
                                            buffer3[1] = (byte) (num10 & 0xff);
                                            buffer3[2] = 0x3b;
                                            buffer3[3] = 0;
                                            buffer4 = new byte[num10 + 2];
                                            num11 = 0;
                                            goto Label_0B6F;
                                        }
                                        case 0x38:
                                        {
                                            this.playerAccount.Handler = this;
                                            this.playerAccount.DeleteChar(BitConverter.ToUInt64(data, num2 + 6));
                                            goto Label_16C1;
                                        }
                                        case 0x3d:
                                        {
                                            goto Label_0B84;
                                        }
                                    }
                                    goto Label_164F;
                                }
                                if (num23 == 0x4b)
                                {
                                    goto Label_1130;
                                }
                                if (num23 == 80)
                                {
                                    goto Label_0D1A;
                                }
                                if (num23 == 0x56)
                                {
                                    goto Label_0DE9;
                                }
                                goto Label_164F;
                            }
                            if (num23 <= 0x69)
                            {
                                switch (num23)
                                {
                                    case 0x5c:
                                    {
                                        this.loggedChar.QuestQuery(BitConverter.ToInt32(data, num2 + 6));
                                        goto Label_16C1;
                                    }
                                    case 0x5d:
                                    case 0x5f:
                                    case 0x61:
                                    {
                                        goto Label_164F;
                                    }
                                    case 0x5e:
                                    {
                                        this.loggedChar.GameObjectQuery(BitConverter.ToInt32(data, num2 + 6), BitConverter.ToUInt64(data, num2 + 10));
                                        goto Label_16C1;
                                    }
                                    case 0x60:
                                    {
                                        this.loggedChar.CreatureQuery((ulong) BitConverter.ToInt64(data, num2 + 10), BitConverter.ToInt32(data, num2 + 6));
                                        goto Label_16C1;
                                    }
                                    case 0x62:
                                    {
                                        this.loggedChar.WhoIsRequest();
                                        goto Label_16C1;
                                    }
                                    case 0x66:
                                    {
                                        goto Label_15DC;
                                    }
                                    case 0x69:
                                    {
                                        goto Label_15FC;
                                    }
                                }
                                goto Label_164F;
                            }
                            if (num23 == 110)
                            {
                                goto Label_13B2;
                            }
                            switch (num23)
                            {
                                case 0x72:
                                {
                                    this.loggedChar.GroupAccept();
                                    goto Label_16C1;
                                }
                                case 0x73:
                                {
                                    this.loggedChar.GroupDecline();
                                    goto Label_16C1;
                                }
                                case 0x74:
                                case 0x76:
                                case 0x77:
                                case 0x79:
                                case 150:
                                {
                                    goto Label_164F;
                                }
                                case 0x75:
                                {
                                    text3 = "";
                                    num15 = 0;
                                    goto Label_146B;
                                }
                                case 120:
                                {
                                    text4 = "";
                                    num16 = 0;
                                    goto Label_14B4;
                                }
                                case 0x7a:
                                {
                                    this.loggedChar.SetLootMethod(BitConverter.ToInt32(data, num2 + 6));
                                    goto Label_16C1;
                                }
                                case 0x7b:
                                {
                                    this.loggedChar.QuitGroup();
                                    goto Label_16C1;
                                }
                                case 0x95:
                                {
                                    text1 = "";
                                    num13 = 0;
                                    goto Label_0D61;
                                }
                                case 0x97:
                                {
                                    this.loggedChar.JoinChannel(data, num2 + 6);
                                    this.debloque = true;
                                    goto Label_16C1;
                                }
                                case 0x98:
                                {
                                    this.SendNullAction(0x99);
                                    goto Label_16C1;
                                }
                            }
                            goto Label_164F;
                        }
                        if (num23 <= 0x11f)
                        {
                            if (num23 <= 220)
                            {
                                switch (num23)
                                {
                                    case 0xab:
                                    {
                                        this.loggedChar.UseItem(data[num2 + 6], BitConverter.ToInt32(data, num2 + 7));
                                        goto Label_16C1;
                                    }
                                    case 0xac:
                                    case 0xad:
                                    case 0xae:
                                    case 0xaf:
                                    case 0xb0:
                                    case 0xb2:
                                    case 0xb3:
                                    case 0xc4:
                                    case 0xc5:
                                    case 0xc6:
                                    case 0xc7:
                                    case 200:
                                    case 0xca:
                                    case 0xd9:
                                    case 0xdb:
                                    {
                                        goto Label_164F;
                                    }
                                    case 0xb1:
                                    {
                                        this.loggedChar.GameObjectUse(BitConverter.ToUInt64(data, num2 + 6));
                                        goto Label_16C1;
                                    }
                                    case 180:
                                    {
                                        if (Character.onAreaTrigger != null)
                                        {
                                            this.loggedChar.AreaTrigger(BitConverter.ToInt32(data, num2 + 6));
                                        }
                                        goto Label_16C1;
                                    }
                                    case 0xb5:
                                    case 0xb6:
                                    case 0xb7:
                                    case 0xb8:
                                    case 0xb9:
                                    case 0xba:
                                    case 0xbb:
                                    case 0xbc:
                                    case 0xbd:
                                    case 190:
                                    case 0xbf:
                                    case 0xc0:
                                    case 0xc1:
                                    case 0xc2:
                                    case 0xc3:
                                    case 0xc9:
                                    case 0xcb:
                                    case 0xcc:
                                    case 0xd7:
                                    case 0xd8:
                                    {
                                        goto Label_0743;
                                    }
                                    case 0xda:
                                    {
                                        goto Label_16C1;
                                    }
                                    case 220:
                                    {
                                        this.loggedChar.TeleportAck();
                                        goto Label_16C1;
                                    }
                                }
                                goto Label_164F;
                            }
                            if (num23 == 0xe3)
                            {
                                goto Label_14E0;
                            }
                            if (num23 == 0xee)
                            {
                                goto Label_0743;
                            }
                            switch (num23)
                            {
                                case 0xfb:
                                case 0xfc:
                                case 0xfe:
                                case 0xff:
                                {
                                    goto Label_16C1;
                                }
                                case 0xfd:
                                case 0x100:
                                case 0x102:
                                case 0x103:
                                case 0x105:
                                case 0x106:
                                case 0x107:
                                case 0x109:
                                case 270:
                                case 0x10f:
                                case 0x110:
                                case 0x112:
                                case 0x113:
                                case 0x114:
                                case 0x115:
                                case 280:
                                case 0x119:
                                {
                                    goto Label_164F;
                                }
                                case 0x101:
                                {
                                    this.loggedChar.ChangeStandState(BitConverter.ToInt32(data, num2 + 6));
                                    goto Label_16C1;
                                }
                                case 260:
                                {
                                    this.loggedChar.OnTextEmote(BitConverter.ToInt32(data, num2 + 6), BitConverter.ToUInt64(data, num2 + 14));
                                    goto Label_16C1;
                                }
                                case 0x108:
                                {
                                    this.loggedChar.AutostoreLootItem(data[num2 + 6]);
                                    goto Label_16C1;
                                }
                                case 0x10a:
                                {
                                    this.loggedChar.AutoEquip(Item.SlotNum(data[num2 + 6], data[num2 + 7]));
                                    goto Label_16C1;
                                }
                                case 0x10b:
                                {
                                    this.loggedChar.Autostore(Item.SlotNum(data[num2 + 6], data[num2 + 7]), data[num2 + 8]);
                                    goto Label_16C1;
                                }
                                case 0x10c:
                                {
                                    this.loggedChar.SwapItem(data[num2 + 6], data[num2 + 7], data[num2 + 8], data[num2 + 9]);
                                    goto Label_16C1;
                                }
                                case 0x10d:
                                {
                                    this.loggedChar.SwapInv((Slots) data[num2 + 6], (Slots) data[num2 + 7]);
                                    goto Label_16C1;
                                }
                                case 0x111:
                                {
                                    this.loggedChar.DestroyItem(Item.SlotNum(data[num2 + 6], data[num2 + 7]), true);
                                    goto Label_16C1;
                                }
                                case 0x116:
                                {
                                    this.loggedChar.InitiateTrade(BitConverter.ToUInt64(data, num2 + 6));
                                    goto Label_16C1;
                                }
                                case 0x117:
                                {
                                    this.loggedChar.BeginTrade();
                                    goto Label_16C1;
                                }
                                case 0x11a:
                                {
                                    this.loggedChar.AcceptTrade();
                                    goto Label_16C1;
                                }
                                case 0x11b:
                                {
                                    if (this.loggedChar != null)
                                    {
                                        goto Label_12A3;
                                    }
                                    base.Dispose();
                                    goto Label_16C1;
                                }
                                case 0x11c:
                                {
                                    this.loggedChar.CancelTrade();
                                    goto Label_16C1;
                                }
                                case 0x11d:
                                {
                                    this.loggedChar.TradeItem(data[num2 + 6], Item.SlotNum(data[num2 + 7], data[num2 + 8]));
                                    goto Label_16C1;
                                }
                                case 0x11e:
                                {
                                    this.loggedChar.ClearTradeItem(data[num2 + 6]);
                                    goto Label_16C1;
                                }
                                case 0x11f:
                                {
                                    this.loggedChar.TradeGold(BitConverter.ToInt32(data, num2 + 6));
                                    goto Label_16C1;
                                }
                            }
                            goto Label_164F;
                        }
                        if (num23 <= 310)
                        {
                            if (num23 == 0x128)
                            {
                                goto Label_1164;
                            }
                            switch (num23)
                            {
                                case 0x12e:
                                {
                                    if (!this.loggedChar.taxiOn)
                                    {
                                        goto Label_0A07;
                                    }
                                    this.loggedChar.SpellFaillure(SpellFailedReason.YourAreInFligth);
                                    goto Label_16C1;
                                }
                                case 0x12f:
                                {
                                    this.loggedChar.CancelCast();
                                    goto Label_16C1;
                                }
                                case 310:
                                {
                                    goto Label_12D3;
                                }
                            }
                            goto Label_164F;
                        }
                        switch (num23)
                        {
                            case 0x13b:
                            {
                                this.loggedChar.ChannelEnd();
                                goto Label_16C1;
                            }
                            case 0x13c:
                            case 0x13f:
                            case 320:
                            case 0x15b:
                            case 0x15c:
                            {
                                goto Label_164F;
                            }
                            case 0x13d:
                            {
                                this.loggedChar.SetSelection(BitConverter.ToUInt64(data, num2 + 6));
                                goto Label_16C1;
                            }
                            case 0x13e:
                            {
                                this.loggedChar.Target = (ulong) BitConverter.ToInt64(data, num2 + 6);
                                goto Label_16C1;
                            }
                            case 0x141:
                            {
                                this.loggedChar.AttackSwing(BitConverter.ToUInt64(data, num2 + 6));
                                goto Label_16C1;
                            }
                            case 0x142:
                            {
                                if ((this.playerAccount == null) || (this.loggedChar == null))
                                {
                                    return null;
                                }
                                goto Label_1003;
                            }
                            case 0x15a:
                            {
                                this.loggedChar.OnRepop();
                                goto Label_16C1;
                            }
                            case 0x15d:
                            {
                                this.loggedChar.LootCreature(BitConverter.ToUInt64(data, num2 + 6));
                                goto Label_16C1;
                            }
                            case 350:
                            {
                                this.loggedChar.OnLootMoney();
                                goto Label_16C1;
                            }
                            case 0x15f:
                            {
                                this.loggedChar.ReleaseLoot();
                                goto Label_16C1;
                            }
                            case 0x16c:
                            {
                                this.loggedChar.SendDuelArbitrer(BitConverter.ToUInt64(data, num2 + 6));
                                goto Label_16C1;
                            }
                            case 0x16d:
                            {
                                this.loggedChar.CancelDuel(BitConverter.ToUInt64(data, num2 + 6));
                                goto Label_16C1;
                            }
                        }
                        goto Label_164F;
                    }
                    if (num23 <= 0x1dc)
                    {
                        if (num23 <= 0x194)
                        {
                            if (num23 <= 0x17f)
                            {
                                switch (num23)
                                {
                                    case 0x174:
                                    {
                                        if (num1 != 20)
                                        {
                                            goto Label_1348;
                                        }
                                        this.loggedChar.SetPetAction(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14), BitConverter.ToUInt32(data, num2 + 0x12));
                                        goto Label_16C1;
                                    }
                                    case 0x175:
                                    {
                                        this.loggedChar.PetAction(BitConverter.ToUInt16(data, num2 + 14), data[num2 + 0x11], BitConverter.ToUInt64(data, num2 + 0x12));
                                        goto Label_16C1;
                                    }
                                    case 0x176:
                                    {
                                        this.loggedChar.DismissPet(BitConverter.ToUInt64(data, num2 + 6));
                                        goto Label_16C1;
                                    }
                                    case 0x177:
                                    case 0x178:
                                    case 0x179:
                                    case 0x17a:
                                    {
                                        goto Label_164F;
                                    }
                                    case 0x17b:
                                    {
                                        ulong num17 = BitConverter.ToUInt64(data, num2 + 6);
                                        this.loggedChar.GossipHello(num17);
                                        goto Label_16C1;
                                    }
                                    case 380:
                                    {
                                        this.loggedChar.GossipSelectOption(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14));
                                        goto Label_16C1;
                                    }
                                    case 0x17f:
                                    {
                                        goto Label_0EEB;
                                    }
                                }
                                goto Label_164F;
                            }
                            switch (num23)
                            {
                                case 0x182:
                                {
                                    this.loggedChar.QuestStatus(BitConverter.ToUInt64(data, num2 + 6));
                                    goto Label_16C1;
                                }
                                case 0x183:
                                case 0x185:
                                case 0x187:
                                case 0x188:
                                {
                                    goto Label_164F;
                                }
                                case 0x184:
                                {
                                    this.loggedChar.QuestGiverHello(BitConverter.ToUInt64(data, num2 + 6));
                                    goto Label_16C1;
                                }
                                case 390:
                                {
                                    this.loggedChar.QuestQueryForCreature(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14));
                                    goto Label_16C1;
                                }
                                case 0x189:
                                {
                                    this.loggedChar.AcceptQuest(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14));
                                    goto Label_16C1;
                                }
                                case 0x18a:
                                {
                                    this.loggedChar.QuestGiverCompleteQuest(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14));
                                    goto Label_16C1;
                                }
                                case 0x18e:
                                {
                                    this.loggedChar.ChooseReward(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14), BitConverter.ToInt32(data, num2 + 0x12));
                                    goto Label_16C1;
                                }
                                case 0x194:
                                {
                                    this.loggedChar.RemoveQuest(data[num2 + 6]);
                                    goto Label_16C1;
                                }
                            }
                            goto Label_164F;
                        }
                        if (num23 <= 0x1b5)
                        {
                            switch (num23)
                            {
                                case 0x19e:
                                {
                                    this.loggedChar.ShowMobileInventory((ulong) BitConverter.ToInt64(data, num2 + 6));
                                    this.SendNullAction(num3);
                                    goto Label_16C1;
                                }
                                case 0x19f:
                                case 0x1a1:
                                case 0x1ab:
                                case 430:
                                case 0x1af:
                                case 0x1b1:
                                {
                                    goto Label_164F;
                                }
                                case 0x1a0:
                                {
                                    this.loggedChar.Sell(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToUInt64(data, num2 + 14));
                                    goto Label_16C1;
                                }
                                case 0x1a2:
                                {
                                    this.loggedChar.Buy(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14), Slots.None, data[num2 + 0x13]);
                                    goto Label_16C1;
                                }
                                case 0x1a3:
                                {
                                    ulong num18 = BitConverter.ToUInt64(data, num2 + 6);
                                    int num19 = BitConverter.ToInt32(data, num2 + 14);
                                    byte num20 = data[num2 + 0x1a];
                                    byte num21 = data[num2 + 0x1b];
                                    this.loggedChar.Buy(num18, num19, (Slots) num20, num21);
                                    goto Label_16C1;
                                }
                                case 0x1aa:
                                {
                                    Taxi.OnCMSG_TAXINODE_STATUS_QUERY(this.loggedChar);
                                    goto Label_16C1;
                                }
                                case 0x1ac:
                                {
                                    Taxi.OnCMSG_TAXIQUERYAVAILABLENODES(this.loggedChar);
                                    goto Label_16C1;
                                }
                                case 0x1ad:
                                {
                                    Taxi.OnCMSG_ACTIVATETAXI(this.loggedChar, BitConverter.ToUInt32(data, num2 + 14), BitConverter.ToUInt32(data, num2 + 0x12));
                                    goto Label_16C1;
                                }
                                case 0x1b0:
                                {
                                    this.loggedChar.TrainerList(BitConverter.ToUInt64(data, num2 + 6));
                                    goto Label_16C1;
                                }
                                case 0x1b2:
                                {
                                    this.loggedChar.TrainerBuy(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToInt32(data, num2 + 14));
                                    goto Label_16C1;
                                }
                                case 0x1b5:
                                {
                                    goto Label_16C1;
                                }
                            }
                            goto Label_164F;
                        }
                        if (num23 == 0x1ce)
                        {
                            goto Label_0CDF;
                        }
                        if (num23 == 0x1d2)
                        {
                            goto Label_1240;
                        }
                        if (num23 == 0x1dc)
                        {
                            goto Label_0AA1;
                        }
                        goto Label_164F;
                    }
                    if (num23 <= 0x211)
                    {
                        if (num23 <= 0x1ff)
                        {
                            if (num23 == 480)
                            {
                                goto Label_0E7D;
                            }
                            if (num23 == 500)
                            {
                                goto Label_0DD0;
                            }
                            if (num23 == 0x1ff)
                            {
                                goto Label_0D0E;
                            }
                            goto Label_164F;
                        }
                        if (num23 == 0x202)
                        {
                            goto Label_11EF;
                        }
                        switch (num23)
                        {
                            case 0x20a:
                            case 0x20b:
                            {
                                goto Label_16C1;
                            }
                            case 0x211:
                            {
                                this.playerAccount.Handler.Send(530, new byte[8] { 0, 6, 0x12, 2, 1, 0, 0, 0 } );
                                goto Label_16C1;
                            }
                        }
                        goto Label_164F;
                    }
                    if (num23 <= 0x253)
                    {
                        if (num23 == 0x216)
                        {
                            goto Label_1250;
                        }
                        if (num23 == 540)
                        {
                            goto Label_1642;
                        }
                        switch (num23)
                        {
                            case 0x251:
                            {
                                this.loggedChar.LearnTalent(BitConverter.ToInt32(data, num2 + 6), BitConverter.ToInt32(data, num2 + 10));
                                goto Label_16C1;
                            }
                            case 0x252:
                            {
                                goto Label_164F;
                            }
                            case 0x253:
                            {
                                goto Label_16C1;
                            }
                        }
                        goto Label_164F;
                    }
                    switch (num23)
                    {
                        case 0x268:
                        {
                            this.loggedChar.SetAmmo(BitConverter.ToInt32(data, num2 + 6));
                            goto Label_16C1;
                        }
                        case 0x269:
                        {
                            goto Label_164F;
                        }
                        case 0x26a:
                        {
                            goto Label_16C1;
                        }
                        case 0x284:
                        {
                            buffer7 = new byte[8];
                            this.playerAccount.Handler.Send(OpCodes.MSG_QUERY_NEXT_MAIL_TIME, buffer7);
                            goto Label_16C1;
                        }
                        case 0x296:
                        {
                            this.loggedChar.MeetingStoneInfo();
                            goto Label_16C1;
                        }
                        default:
                        {
                            goto Label_164F;
                        }
                    }
                Label_0743:
                    if (num3 == 0xbc)
                    {
                        this.loggedChar.deadEndTeleportLoop = false;
                    }
                    TimeSpan span1 = DateTime.Now.Subtract(this.lastUpdate);
                    if (span1.TotalSeconds > 2)
                    {
                        this.playerAccount.RefreshMobileList();
                    }
                    this.playerAccount.realylogged = true;
                    this.playerAccount.MvtToAllPlayerNear(num3, data, num2, num1 + 2);
                    float single1 = BitConverter.ToSingle(data, num2 + 14);
                    float single2 = BitConverter.ToSingle(data, num2 + 0x12);
                    float single3 = BitConverter.ToSingle(data, num2 + 0x16);
                    float single4 = BitConverter.ToSingle(data, num2 + 0x1a);
                    this.loggedChar.MoveHandler(single1, single2, single3, single4);
                    if ((num3 != 0xc9) && (this.loggedChar.path != null))
                    {
                        if (this.loggedChar.path.Count > 0)
                        {
                            int num8 = this.loggedChar.path.Count - 1;
                            float single5 = this.loggedChar.path[num8].x - single1;
                            float single6 = this.loggedChar.path[num8].y - single2;
                            float single7 = this.loggedChar.path[num8].z - single3;
                            if (((single5 + single6) + single7) != 0f)
                            {
                                string[] textArray1 = new string[6] { "Pos x=", single1.ToString(), "; y=", single2.ToString(), "; z=", single3.ToString() } ;
                                this.loggedChar.SendMessage(string.Concat(textArray1));
                                Coord coord1 = this.lastCoordTrajet;
                                this.lastCoordTrajet = new Coord(single1, single2, single3, this.lastCoordTrajet, null);
                                coord1.next = this.lastCoordTrajet;
                                this.loggedChar.path.Add(this.lastCoordTrajet, coord1);
                            }
                            goto Label_16C1;
                        }
                        this.lastCoordTrajet = new Coord(single1, single2, single3, null, null);
                        this.loggedChar.path.Add(this.lastCoordTrajet);
                        goto Label_16C1;
                    }
                    if (((num3 == 0xb9) || (num3 == 0xb8)) && this.loggedChar.IsCasting)
                    {
                        this.loggedChar.CancelCast();
                    }
                    goto Label_16C1;
                Label_0A07:
                    if (BitConverter.ToInt32(data, num2 + 6) == 0x1c62)
                    {
                        this.loggedChar.PrepareInv(data, num2);
                    }
                    ushort num9 = BitConverter.ToUInt16(data, num2 + 10);
                    this.loggedChar.OnCastSpellCMSG(data, num2, num9);
                    goto Label_16C1;
                Label_0AA1:
                    buffer7 = new byte[8] { 0, 6, 0xdd, 1, 0, 0, 0, 0 } ;
                    buffer7[4] = data[6];
                    buffer7[5] = data[7];
                    buffer7[6] = data[8];
                    buffer7[7] = data[9];
                    byte[] buffer2 = buffer7;
                    this.Send(buffer2);
                    if (this.playerAccount != null)
                    {
                        this.playerAccount.HeartBeat();
                    }
                    goto Label_16C1;
                Label_0B5F:
                    buffer4[num11] = buffer3[num11];
                    num11++;
                Label_0B6F:
                    if (num11 < (num10 + 2))
                    {
                        goto Label_0B5F;
                    }
                    this.Send(buffer4);
                    goto Label_16C1;
                Label_0B84:
                    this.dt.Stop();
                    ulong num12 = (ulong) BitConverter.ToInt64(data, num2 + 6);
                    this.playerAccount.Handler = this;
                    this.loggedChar = this.playerAccount.Login(num12);
                    if (this.loggedChar != null)
                    {
                        buffer7 = new byte[8];
                        buffer7[1] = 6;
                        buffer7[2] = 0x67;
                        this.Send(buffer7);
                        goto Label_16C1;
                    }
                    buffer7 = new byte[5];
                    buffer7[1] = 3;
                    buffer7[2] = 0x41;
                    this.playerAccount.Handler.Send(buffer7);
                    goto Label_16C1;
                Label_0CDF:
                    buffer5 = new byte[8] { 0, 0, 0, 0, 0x90, 0xe0, 0x22, 0x42 } ;
                    this.playerAccount.Handler.Send(0x1cf, buffer5);
                    goto Label_16C1;
                Label_0D0E:
                    this.SendNullAction(num3);
                    goto Label_16C1;
                Label_0D1A:
                    this.loggedChar.SendName(BitConverter.ToUInt64(data, num2 + 6));
                    goto Label_16C1;
                Label_0D3F:
                    text1 = text1 + "" + ((char) data[(num2 + num13) + 14]);
                    num13++;
                Label_0D61:
                    if (data[(num2 + num13) + 14] != 0)
                    {
                        goto Label_0D3F;
                    }
                    this.loggedChar.MessageHandler(text1, (Character.ChatMsgType) BitConverter.ToInt32(data, num2 + 6), BitConverter.ToInt32(data, num2 + 10));
                    goto Label_16C1;
                Label_0DD0:
                    this.loggedChar.ZoneUpdateRequested(BitConverter.ToInt32(data, num2 + 6));
                    goto Label_16C1;
                Label_0DE9:
                    this.loggedChar.SendItem(BitConverter.ToInt32(data, num2 + 6), BitConverter.ToUInt64(data, num2 + 10));
                    goto Label_16C1;
                Label_0E7D:
                    this.loggedChar.Sheathed = BitConverter.ToInt32(data, num2 + 6);
                    goto Label_16C1;
                Label_0EEB:
                    this.loggedChar.NpcTextQuery(BitConverter.ToInt32(data, num2 + 6), BitConverter.ToUInt64(data, num2 + 10));
                    goto Label_16C1;
                Label_1003:
                    this.loggedChar.StopAttacking();
                    goto Label_16C1;
                Label_1130:
                    this.playerAccount.Handler.Send(OpCodes.SMSG_LOGOUT_RESPONSE, new byte[9] { 0, 6, 0x12, 2, 0, 0, 0, 0, 0 } );
                    this.playerAccount.LoggoutStartTimer();
                    goto Label_16C1;
                Label_1164:
                    this.loggedChar.AddToActionBar(data[num2 + 6], BitConverter.ToUInt16(data, num2 + 7), data[num2 + 9], data[num2 + 10]);
                    goto Label_16C1;
                Label_11EF:
                    this.loggedChar.SendMessage("Not available yet !");
                    goto Label_16C1;
                Label_1240:
                    this.loggedChar.ReclaimCorps();
                    goto Label_16C1;
                Label_1250:
                    this.loggedChar.CorpseQuery();
                    goto Label_16C1;
                Label_12A3:
                    this.loggedChar.UnacceptTrade();
                    goto Label_16C1;
                Label_12D3:
                    this.loggedChar.CancelAura(BitConverter.ToInt32(data, num2 + 6));
                    goto Label_16C1;
                Label_1348:
                    this.loggedChar.SetPetAction(BitConverter.ToUInt64(data, num2 + 6), BitConverter.ToUInt32(data, num2 + 14), BitConverter.ToUInt32(data, num2 + 0x12), BitConverter.ToUInt32(data, num2 + 0x16), BitConverter.ToUInt32(data, num2 + 0x1a));
                    goto Label_16C1;
                Label_13B2:
                    text2 = "";
                    for (int num14 = 0; data[(num2 + num14) + 6] != 0; num14++)
                    {
                        text2 = text2 + "" + ((char) data[(num2 + num14) + 6]);
                    }
                    this.loggedChar.GroupInvite(text2);
                    goto Label_16C1;
                Label_144A:
                    text3 = text3 + "" + ((char) data[(num2 + num15) + 6]);
                    num15++;
                Label_146B:
                    if (data[(num2 + num15) + 6] != 0)
                    {
                        goto Label_144A;
                    }
                    this.loggedChar.GroupUninvite(text3);
                    goto Label_16C1;
                Label_1493:
                    text4 = text4 + "" + ((char) data[(num2 + num16) + 6]);
                    num16++;
                Label_14B4:
                    if (data[(num2 + num16) + 6] != 0)
                    {
                        goto Label_1493;
                    }
                    this.loggedChar.GroupSetLeader(text4);
                    goto Label_16C1;
                Label_14E0:
                    this.loggedChar.ForceSpeedAck();
                    goto Label_16C1;
                Label_15DC:
                    this.loggedChar.SendFriendList();
                    goto Label_16C1;
                Label_15FC:
                    text5 = "";
                    for (int num22 = 0; data[(num2 + num22) + 6] != 0; num22++)
                    {
                        text5 = text5 + "" + ((char) data[(num2 + num22) + 6]);
                    }
                    this.loggedChar.AddFriend(text5);
                    goto Label_16C1;
                Label_1642:
                    this.loggedChar.ReclaimCorps();
                    goto Label_16C1;
                Label_164F:
                    if (num3 != 0x2ce)
                    {
                        Console.WriteLine("{2} : Receive unknown command {0} ({1})", (OpCodes) num3, num3.ToString("X4"), this.loggedChar.Name);
                    }
                    if (num3 > 0x330)
                    {
                        Console.WriteLine("");
                        Console.WriteLine("{0} kicked", this.playerAccount.Username);
                        this.playerAccount.Loggout(this.loggedChar.Guid);
                        base.Dispose();
                    }
                Label_16C1:
                    if ((num1 + 2) < (length - num2))
                    {
                        num2 += (num1 + 2);
                        continue;
                    }
                    num2 = -1;
                }
                buffer6 = null;
            }
            catch (Exception exception1)
            {
                object[] objArray1;
                string text6 = "";
                if (this.playerAccount != null)
                {
                    text6 = text6 + "Account " + this.playerAccount.Username;
                }
                if (this.loggedChar != null)
                {
                    text6 = text6 + " character " + this.loggedChar.Name;
                }
                text6 = text6 + " cause a crash";
                Console.WriteLine(text6);
                Console.WriteLine(exception1.Message);
                Console.WriteLine(exception1.Source);
                Console.WriteLine(exception1.StackTrace);
                if (this.loggedChar == null)
                {
                    objArray1 = new object[4] { DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, base.IP.ToString() } ;
                    Console.Write("{0}:{1}:{2} NULL {3} <-- ", objArray1);
                }
                else
                {
                    objArray1 = new object[5] { DateTime.Now.Hour, DateTime.Now.Minute, DateTime.Now.Second, base.IP.ToString(), this.loggedChar.Guid } ;
                    Console.Write("{0}:{1}:{2} {3} {4} <-- ", objArray1);
                }
                Console.WriteLine("Code {2} Len {0} After {1}", num1, num2, num3);
                HexViewer.View(data, num2, num1 + 2);
                this.playerAccount.Loggout(0);
                base.Dispose();
                if (MainConsole.sw1 != null)
                {
                    MainConsole.sw1.Flush();
                }
                buffer6 = null;
            }
            return buffer6;
        }

        public void Encode(byte[] data)
        {
            if (this.SS_Hash == null)
            {
                Console.WriteLine("Missing SS_Hash for that character !!!!!");
            }
            else
            {
                byte[] buffer1 = this.SS_Hash;
                for (int num1 = 0; num1 < 4; num1++)
                {
                    byte num2 = this.key[3];
                    num2 = (byte) (buffer1[num2] ^ data[num1]);
                    byte num3 = this.key[2];
                    num2 = (byte) (num2 + num3);
                    data[num1] = num2;
                    this.key[2] = num2;
                    num2 = this.key[3];
                    num2 = (byte) (num2 + 1);
                    this.key[3] = (byte) (num2 % 40);
                }
            }
        }

        public void Logout()
        {
            if (this.loggedChar != null)
            {
                this.playerAccount.Loggout(this.loggedChar.Guid);
            }
        }

        public override byte[] ProcessDataReceived(byte[] data, int length)
        {
            if (this.playerAccount == null)
            {
                Console.WriteLine("playerAccount == null, IP={0}", base.IP.ToString());
                if (((data[0] == 0) && (data[2] == 0xed)) && (data[3] == 1))
                {
                    string text1 = "";
                    for (int num1 = 14; num1 < length; num1++)
                    {
                        if (data[num1] == 0)
                        {
                            break;
                        }
                        text1 = text1 + "" + ((char) data[num1]);
                    }
                    this.playerAccount = World.allAccounts.FindByUserName(text1);
                    Console.WriteLine("Player {0} with IP {1}", text1, base.IP);
                    if (this.playerAccount == null)
                    {
                        Console.WriteLine("Strange bug, {0} was not found in the account list !", text1);
                        return null;
                    }
                    this.playerAccount.Handler = this;
                    this.playerAccount.PreLogin();
                    if (this.playerAccount.packetHandler == null)
                    {
                        Console.WriteLine("packetHandler cannot be null");
                    }
                    if (this.playerAccount.Packets.Count > 0)
                    {
                        Queue queue1 = new Queue();
                        queue1.Enqueue(new Packet(data, length));
                        while (this.playerAccount.Packets.Count > 0)
                        {
                            queue1.Enqueue(this.playerAccount.Packets.Dequeue());
                        }
                        this.playerAccount.Packets = queue1;
                    }
                    if (this.playerAccount.Packets.Count > 100)
                    {
                        Console.WriteLine("Player {0} send too many packets !!! Kicked !!!");
                        this.playerAccount.Packets.Clear();
                        this.Logout();
                        return null;
                    }
                    byte[] buffer1 = new byte[4];
                    this.key = buffer1;
                    this.needEncode = true;
                    this.needLog = true;
                    this.dt = new DelaySend(this);
                    this.firstPacket = false;
                    return null;
                }
                this.playerAccount = World.allAccounts.FindNotLoggedAccountByIp(base.IP);
                if (this.playerAccount == null)
                {
                    Console.WriteLine("IP doesn't match the prior IP client send !!!\nMake sure your IP match the IP in the realmlist.rtf");
                    base.Dispose();
                    return null;
                }
                if (!this.needEncode && (this.playerAccount.packetHandler != null))
                {
                    this.playerAccount.packetHandler.Stop();
                    this.playerAccount.packetHandler = null;
                }
                if ((this.playerAccount != null) && (this.playerAccount.packetHandler == null))
                {
                    this.playerAccount.Handler = this;
                    this.playerAccount.PreLogin();
                }
            }
            if (this.playerAccount == null)
            {
                Console.WriteLine("Loosing packet for {0}", base.IP.ToString());
            }
            else
            {
                lock (this.playerAccount.Packets)
                {
                    this.playerAccount.Packets.Enqueue(new Packet(data, length));
                }
            }
            return null;
        }

        public void Send(byte[] buffer)
        {
            if (buffer != null)
            {
                if (this.needEncode)
                {
                    this.Encode(buffer);
                }
                this.Send(buffer, 0, buffer.Length);
            }
        }

        public void Send(OpCodes opcode, byte[] buffer)
        {
            if (buffer != null)
            {
                buffer[1] = (byte) ((buffer.Length - 2) & 0xff);
                buffer[0] = (byte) (((buffer.Length - 2) >> 8) & 0xff);
                buffer[2] = (byte) (opcode & OpCodes.CMSG_TUTORIAL_CLEAR);
                buffer[3] = (byte) ((((int) opcode) >> 8) & 0xff);
                if (this.needEncode)
                {
                    this.Encode(buffer);
                }
                this.Send(buffer, 0, buffer.Length);
            }
        }

        public void Send(int opcode, byte[] buffer)
        {
            if (buffer != null)
            {
                buffer[1] = (byte) ((buffer.Length - 2) & 0xff);
                buffer[0] = (byte) (((buffer.Length - 2) >> 8) & 0xff);
                buffer[2] = (byte) (opcode & 0xff);
                buffer[3] = (byte) ((opcode >> 8) & 0xff);
                if (this.needEncode)
                {
                    this.Encode(buffer);
                }
                this.Send(buffer, 0, buffer.Length);
            }
        }

        public void Send(byte[] buffer, bool noEncode)
        {
            if (buffer != null)
            {
                if (!noEncode)
                {
                    this.Encode(buffer);
                }
                this.Send(buffer, 0, buffer.Length);
            }
        }

        public void Send(OpCodes opcode, byte[] buffer, int len)
        {
            this.Send((int) opcode, buffer, len);
        }

        public void Send(int opcode, byte[] buffer, int len)
        {
            if (buffer != null)
            {
                len -= 2;
                buffer[1] = (byte) (len & 0xff);
                buffer[0] = (byte) ((len >> 8) & 0xff);
                buffer[2] = (byte) (opcode & 0xff);
                buffer[3] = (byte) ((opcode >> 8) & 0xff);
                if (this.needEncode)
                {
                    this.Encode(buffer);
                }
                this.Send(buffer, 0, len + 2);
            }
        }

        public void SendNullAction(int opcode)
        {
            int num1 = 5;
            Converter.ToBytes((short) opcode, this.nullAction, ref num1);
            this.Send(OpCodes.MSG_NULL_ACTION, this.nullAction);
        }


        // Properties
        public byte[] SS_Hash
        {
            get
            {
                byte[] buffer1;
                try
                {
                    buffer1 = this.playerAccount.SS_Hash;
                }
                catch (Exception exception1)
                {
                    Console.WriteLine("Error {0}\n{1}", exception1.Message, exception1.StackTrace);
                    buffer1 = null;
                }
                return buffer1;
            }
        }


        // Fields
        public bool debloque;
        private DelaySend dt;
        private bool firstPacket;
        private byte[] key;
        private Coord lastCoordTrajet;
        private DateTime lastUpdate;
        private Character loggedChar;
        public const int MSG_MOVE_COLLIDE_REDIRECT = 0xc9;
        public const int MSG_MOVE_COLLIDE_STUCK = 0xca;
        public const int MSG_MOVE_JUMP = 0xbb;
        public const int MSG_MOVE_SET_ALL_SPEED_CHEAT = 0xd3;
        public const int MSG_MOVE_SET_FACING = 0xd7;
        public const int MSG_MOVE_SET_PITCH = 0xd8;
        public const int MSG_MOVE_SET_RUN_MODE = 0xc2;
        public const int MSG_MOVE_SET_RUN_SPEED = 0xce;
        public const int MSG_MOVE_SET_RUN_SPEED_CHEAT = 0xcd;
        public const int MSG_MOVE_SET_SWIM_SPEED = 210;
        public const int MSG_MOVE_SET_SWIM_SPEED_CHEAT = 0xd1;
        public const int MSG_MOVE_SET_TURN_RATE = 0xd5;
        public const int MSG_MOVE_SET_TURN_RATE_CHEAT = 0xd4;
        public const int MSG_MOVE_SET_WALK_MODE = 0xc3;
        public const int MSG_MOVE_SET_WALK_SPEED = 0xd0;
        public const int MSG_MOVE_SET_WALK_SPEED_CHEAT = 0xcf;
        public const int MSG_MOVE_START_BACKWARD = 0xb6;
        public const int MSG_MOVE_START_FORWARD = 0xb5;
        public const int MSG_MOVE_START_PITCH_DOWN = 0xc0;
        public const int MSG_MOVE_START_PITCH_UP = 0xbf;
        public const int MSG_MOVE_START_STRAFE_LEFT = 0xb8;
        public const int MSG_MOVE_START_STRAFE_RIGHT = 0xb9;
        public const int MSG_MOVE_START_SWIM = 0xcb;
        public const int MSG_MOVE_START_TURN_LEFT = 0xbc;
        public const int MSG_MOVE_START_TURN_RIGHT = 0xbd;
        public const int MSG_MOVE_STOP = 0xb7;
        public const int MSG_MOVE_STOP_PITCH = 0xc1;
        public const int MSG_MOVE_STOP_STRAFE = 0xba;
        public const int MSG_MOVE_STOP_SWIM = 0xcc;
        public const int MSG_MOVE_STOP_TURN = 190;
        public const int MSG_MOVE_TELEPORT = 0xc5;
        public const int MSG_MOVE_TELEPORT_ACK = 0xc7;
        public const int MSG_MOVE_TELEPORT_CHEAT = 0xc6;
        public const int MSG_MOVE_TOGGLE_COLLISION_CHEAT = 0xd6;
        public const int MSG_MOVE_TOGGLE_FALL_LOGGING = 200;
        public const int MSG_MOVE_TOGGLE_LOGGING = 0xc4;
        private bool needEncode;
        private bool needLog;
        private byte[] nullAction;
        private Account playerAccount;
        public Queue test;
        private UpdateTimer updateTimer;

        // Nested Types
        private class DelaySend : WowTimer
        {
            // Methods
            public DelaySend(PlayerHandler ph) : base(WowTimer.Priorities.Milisec10, 300)
            {
                this.ti = 0;
                this.playerHangler = ph;
                base.Start();
            }

            public override void OnTick()
            {
                this.ti++;
                if (this.ti > 30)
                {
                    base.Stop();
                }
                if ((this.ti == 2) || this.playerHangler.needLog)
                {
                    byte[] buffer1 = new byte[5] { 0, 3, 0xee, 1, 12 } ;
                    this.playerHangler.Send(buffer1, false);
                    base.OnTick();
                }
                else
                {
                    base.OnTick();
                }
            }


            // Fields
            private PlayerHandler playerHangler;
            private int ti;
        }

        private class UpdateTimer : WowTimer
        {
            // Methods
            public UpdateTimer(PlayerHandler ph, Character lc) : base(WowTimer.Priorities.Milisec10, 50)
            {
                this.increment = 0;
                this.playerHangler = ph;
                this.loggedChar = lc;
                base.Start();
            }

            public override void OnTick()
            {
                ulong num2;
                byte[] buffer1 = new byte[150] { 
                    0x95, 0xa9, 0, 1, 0, 0, 0, 0, 0, 0x25, 0x30, 0x15, 0, 0, 0, 0, 
                    0, 0x1c, 0, 0, 0x80, 15, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                    0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x3e, 0, 
                    0, 0, 0, 0, 0, 0
                 } ;
                int num1 = 9;
                Converter.ToBytes(this.loggedChar.Guid, buffer1, ref num1);
                num1 = 0x8e;
                this.increment = (num2 = this.increment) + 1;
                Converter.ToBytes(num2, buffer1, ref num1);
                base.OnTick();
            }


            // Fields
            public ulong increment;
            private Character loggedChar;
            private PlayerHandler playerHangler;
        }
    }
}

