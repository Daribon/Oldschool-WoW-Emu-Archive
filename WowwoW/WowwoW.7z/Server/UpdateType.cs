namespace Server
{
    using System;

    public enum UpdateType
    {
        // Fields
        UpdateFull = 2,
        UpdateInRange = 4,
        UpdateMovement = 1,
        UpdateOutOfRange = 3,
        UpdatePartial = 0
    }
}

