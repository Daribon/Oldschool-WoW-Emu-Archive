namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Reflection;

    [Serializable]
    public class Trajets : CollectionBase
    {
        // Methods
        public Trajets()
        {
            this.dirty = false;
        }

        public Trajets(GenericReader gr)
        {
            this.dirty = false;
            base.List.Clear();
            if (!gr.notFound)
            {
                this.Deserialize(gr);
            }
        }

        public Trajets(Trajet[] val)
        {
            this.dirty = false;
            this.AddRange(val);
        }

        public Trajets(Trajets val)
        {
            this.dirty = false;
            this.AddRange(val);
        }

        public int Add(Trajet val)
        {
            return base.List.Add(val);
        }

        public void AddRange(Trajets val)
        {
            for (int num1 = 0; num1 < val.Count; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void AddRange(Trajet[] val)
        {
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public bool Contains(Trajet val)
        {
            return base.List.Contains(val);
        }

        public void CopyTo(Trajet[] array, int index)
        {
            base.List.CopyTo(array, index);
        }

        public virtual void Deserialize(GenericReader gr)
        {
            gr.ReadInt();
            int num1 = gr.ReadInt();
            for (int num2 = 0; num2 < num1; num2++)
            {
                this.Add(new Trajet(gr));
            }
            gr.Close();
            int num3 = 0;
            while (num3 < Trajet.allLinks.Count)
            {
                Coord coord1 = (Coord) Trajet.allLinks[num3++];
                int num4 = (int) Trajet.allLinks[num3++];
                int num5 = (int) Trajet.allLinks[num3++];
                int num6 = (int) Trajet.allLinks[num3++];
                int num7 = (int) Trajet.allLinks[num3++];
                coord1.previous = this[num4][num5];
                coord1.next = this[num6][num7];
                if (coord1 is Intersection)
                {
                    Intersection intersection1 = (Intersection) coord1;
                    num4 = (int) Trajet.allLinks[num3++];
                    num5 = (int) Trajet.allLinks[num3++];
                    num6 = (int) Trajet.allLinks[num3++];
                    num7 = (int) Trajet.allLinks[num3++];
                    intersection1.left = this[num4][num5];
                    intersection1.right = this[num6][num7];
                }
            }
            Trajet.allLinks.Clear();
            GC.Collect();
        }

        public Trajet Find(ulong guid)
        {
            foreach (Trajet trajet1 in this)
            {
                if (trajet1.Guid == guid)
                {
                    return trajet1;
                }
            }
            return null;
        }

        public new TrajetEnumerator GetEnumerator()
        {
            return new TrajetEnumerator(this);
        }

        public int IndexOf(Trajet val)
        {
            return base.List.IndexOf(val);
        }

        public void Insert(int index, Trajet val)
        {
            base.List.Insert(index, val);
        }

        public void Remove(Trajet val)
        {
            base.List.Remove(val);
        }

        public virtual void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            gw.Write(base.List.Count);
            TrajetEnumerator enumerator1 = this.GetEnumerator();
            try
            {
                while (enumerator1.MoveNext())
                {
                    enumerator1.Current.Serialize(gw);
                }
            }
            finally
            {
                IDisposable disposable1 = enumerator1 as IDisposable;
                if (disposable1 != null)
                {
                    disposable1.Dispose();
                }
            }
            gw.Close();
            this.Dirty = false;
        }


        // Properties
        public bool Dirty
        {
            get
            {
                return this.dirty;
            }
            set
            {
                this.dirty = value;
            }
        }

        public Trajet this[int index]
        {
            get
            {
                return (Trajet) base.List[index];
            }
            set
            {
                base.List[index] = value;
            }
        }


        // Fields
        private bool dirty;

        // Nested Types
        public class TrajetEnumerator : IEnumerator
        {
            // Methods
            public TrajetEnumerator(Trajets mappings)
            {
                this.temp = mappings;
                this.baseEnumerator = this.temp.GetEnumerator();
            }

            public bool MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            public void Reset()
            {
                this.baseEnumerator.Reset();
            }


            // Properties
            public Trajet Current
            {
                get
                {
                    return (Trajet) this.baseEnumerator.Current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.baseEnumerator.Current;
                }
            }


            // Fields
            private IEnumerator baseEnumerator;
            private IEnumerable temp;
        }
    }
}

