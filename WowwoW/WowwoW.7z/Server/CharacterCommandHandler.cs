namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool CharacterCommandHandler(Character c, string cmd);

}

