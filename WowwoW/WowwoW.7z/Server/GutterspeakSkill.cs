namespace Server
{
    using System;

    public class GutterspeakSkill : Skill
    {
        // Methods
        public GutterspeakSkill()
        {
        }

        public GutterspeakSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x2a1;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x2a1;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x4549;
            }
        }

    }
}

