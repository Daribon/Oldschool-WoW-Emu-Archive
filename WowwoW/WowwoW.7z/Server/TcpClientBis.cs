namespace Server
{
    using System;
    using System.Net;
    using System.Net.Sockets;

    public class TcpClientBis : TcpClient
    {
        // Methods
        public TcpClientBis(Socket socket)
        {
            base.Client = socket;
            base.NoDelay = true;
            base.ReceiveTimeout = 0x1388;
            base.SendTimeout = 0x1388;
            base.ReceiveBufferSize = 0x8000;
            base.SendBufferSize = 0x8000;
        }


        // Properties
        public IPAddress IP
        {
            get
            {
                return ((IPEndPoint) base.Client.RemoteEndPoint).Address;
            }
        }

        public int Port
        {
            get
            {
                return ((IPEndPoint) base.Client.RemoteEndPoint).Port;
            }
        }

        public IPAddress SourceIP
        {
            get
            {
                return ((IPEndPoint) base.Client.LocalEndPoint).Address;
            }
        }

    }
}

