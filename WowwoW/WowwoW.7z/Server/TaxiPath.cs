namespace Server
{
    using System;

    public class TaxiPath
    {
        // Methods
        public TaxiPath(int _id, int _from, int _to, int _price)
        {
            this.id = _id;
            this.from = _from;
            this.to = _to;
            this.price = _price;
        }


        // Properties
        public int From
        {
            get
            {
                return this.from;
            }
        }

        public int Id
        {
            get
            {
                return this.id;
            }
        }

        public int Price
        {
            get
            {
                return this.price;
            }
        }

        public int To
        {
            get
            {
                return this.to;
            }
        }


        // Fields
        private int from;
        private int id;
        private int price;
        private int to;
    }
}

