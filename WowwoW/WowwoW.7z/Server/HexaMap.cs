namespace Server
{
    using System;

    public class HexaMap
    {
        // Methods
        static HexaMap()
        {
            HexaMap.oppose = new int[6] { 5, 4, 3, 2, 1, 0 } ;
        }

        public HexaMap()
        {
        }

        public HexaMap(int x, int y)
        {
            this.maxX = x;
            this.maxY = y;
            this.cluster = new float[this.maxY * this.maxX];
        }

        public float GetMap(HexaPoint hp)
        {
            if (hp == null)
            {
                return float.MinValue;
            }
            return this.cluster[hp.x + (hp.y * this.maxX)];
        }

        public float GetMap(int x, int y)
        {
            return this.cluster[x + (y * this.maxX)];
        }

        public float GetMapSafe(int x, int y)
        {
            if (y >= this.maxY)
            {
                y -= this.maxY;
            }
            else if (y < 0)
            {
                y += this.maxY;
            }
            if (x < 0)
            {
                x += this.maxX;
            }
            else if (x >= this.maxX)
            {
                x -= this.maxX;
            }
            return this.cluster[x + (y * this.maxX)];
        }

        public HexaPoint HexaCoord(HexaPoint v, int t)
        {
            HexaPoint point1 = new HexaPoint(v);
            switch (t)
            {
                case 0:
                {
                    point1.y--;
                    if ((point1.y & 1) == 0)
                    {
                        point1.x--;
                    }
                    return point1;
                }
                case 1:
                {
                    point1.y--;
                    point1.x++;
                    if ((point1.y & 1) == 1)
                    {
                        point1.x++;
                    }
                    return point1;
                }
                case 2:
                {
                    point1.x--;
                    return point1;
                }
                case 3:
                {
                    point1.x++;
                    return point1;
                }
                case 4:
                {
                    point1.y++;
                    if ((point1.y & 1) == 0)
                    {
                        point1.x--;
                    }
                    return point1;
                }
                case 5:
                {
                    point1.y++;
                    if ((point1.y & 1) == 1)
                    {
                        point1.x++;
                    }
                    return point1;
                }
            }
            return null;
        }

        public HexaPoint HexaCoordNoBorder(HexaPoint v, int t)
        {
            HexaPoint point1 = new HexaPoint(v);
            switch (t)
            {
                case 0:
                {
                    point1.y--;
                    if (point1.y < 0)
                    {
                        point1.y += this.maxY;
                    }
                    if ((point1.y & 1) == 0)
                    {
                        point1.x--;
                        if (point1.x < 0)
                        {
                            point1.x += this.maxX;
                        }
                    }
                    return point1;
                }
                case 1:
                {
                    point1.y--;
                    if (point1.y < 0)
                    {
                        point1.y += this.maxY;
                    }
                    if ((point1.y & 1) == 1)
                    {
                        point1.x++;
                    }
                    if (point1.x >= this.maxX)
                    {
                        point1.x -= this.maxX;
                    }
                    return point1;
                }
                case 2:
                {
                    point1.x--;
                    if (point1.x < 0)
                    {
                        point1.x += this.maxX;
                    }
                    return point1;
                }
                case 3:
                {
                    point1.x++;
                    if (point1.x >= this.maxX)
                    {
                        point1.x -= this.maxX;
                    }
                    return point1;
                }
                case 4:
                {
                    point1.y++;
                    if (point1.y >= this.maxY)
                    {
                        point1.y -= this.maxY;
                    }
                    if ((point1.y & 1) == 0)
                    {
                        point1.x--;
                        if (point1.x < 0)
                        {
                            point1.x += this.maxX;
                        }
                    }
                    return point1;
                }
                case 5:
                {
                    point1.y++;
                    if (point1.y >= this.maxY)
                    {
                        point1.y -= this.maxY;
                    }
                    if ((point1.y & 1) == 1)
                    {
                        point1.x++;
                    }
                    if (point1.x >= this.maxX)
                    {
                        point1.x -= this.maxX;
                    }
                    return point1;
                }
            }
            return null;
        }

        public bool IsEmpty(HexaPoint hp)
        {
            if (this.cluster[hp.x + (hp.y * this.maxX)] == float.MinValue)
            {
                return true;
            }
            return false;
        }

        public bool IsEmpty(int x, int y)
        {
            if (this.cluster[x + (y * this.maxX)] == float.MinValue)
            {
                return true;
            }
            return false;
        }


        // Fields
        public float[] cluster;
        public int maxX;
        public int maxY;
        public static int[] oppose;
    }
}

