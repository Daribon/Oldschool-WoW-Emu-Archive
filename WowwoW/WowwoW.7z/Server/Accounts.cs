namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.IO;
    using System.Net;
    using System.Reflection;
    using System.Xml;

    [Serializable]
    public class Accounts : CollectionBase
    {
        // Methods
        public Accounts()
        {
        }

        public Accounts(GenericReader gr)
        {
            this.Deserialize(gr);
        }

        public Accounts(Account[] val)
        {
            this.AddRange(val);
        }

        public Accounts(Accounts val)
        {
            this.AddRange(val);
        }

        public Accounts(string fname)
        {
            this.Load(fname);
        }

        public int Add(Account val)
        {
            return base.List.Add(val);
        }

        public void AddRange(Account[] val)
        {
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void AddRange(Accounts val)
        {
            for (int num1 = 0; num1 < val.Count; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void BroadCastMessage(string str)
        {
            byte[] buffer1 = new byte[(((((str.Length + 4) + 4) + 8) + 1) + 2) + 0x20];
            int num1 = 4;
            buffer1[num1++] = 0;
            num1 = 0x11;
            Converter.ToBytes(str, buffer1, ref num1);
            foreach (Account account1 in this)
            {
                if (account1.SelectedChar != null)
                {
                    int num2 = 4;
                    Converter.ToBytes(10, buffer1, ref num2);
                    Converter.ToBytes((byte) 0, buffer1, ref num2);
                    Converter.ToBytes((ulong) 0, buffer1, ref num2);
                    Converter.ToBytes((int) (str.Length + 1), buffer1, ref num2);
                    Converter.ToBytes(str, buffer1, ref num2);
                    Converter.ToBytes((short) 0, buffer1, ref num2);
                    account1.Handler.Send(150, buffer1, num2);
                }
            }
        }

        public bool Contains(Account val)
        {
            return base.List.Contains(val);
        }

        public void CopyTo(Account[] array, int index)
        {
            base.List.CopyTo(array, index);
        }

        public void Deserialize(GenericReader gr)
        {
            base.List.Clear();
            if (!gr.notFound)
            {
                gr.ReadInt();
                int num1 = gr.ReadInt();
                for (int num2 = 0; num2 < num1; num2++)
                {
                    this.Add(new Account(gr));
                }
            }
            if (base.Count == 0)
            {
                Account account1 = new Account("admin", "changeme", AccessLevels.Admin);
                this.Add(account1);
            }
            if (!gr.notFound)
            {
                gr.Close();
            }
        }

        public Account FindAccountByIp(IPAddress e)
        {
            foreach (Account account1 in this)
            {
                if ((account1.Ip != null) && account1.Ip.Equals(e))
                {
                    return account1;
                }
            }
            return null;
        }

        public Account FindAccountByIp(IPAddress e, int port)
        {
            if (port == 0)
            {
                return this.FindAccountByIp(e);
            }
            foreach (Account account1 in this)
            {
                if (((account1.Ip == null) || !account1.Ip.Equals(e)) || ((port != account1.Port) && (account1.Port != 0)))
                {
                    continue;
                }
                return account1;
            }
            return null;
        }

        public Account FindByUserName(string user)
        {
            foreach (Account account1 in this)
            {
                if (account1.Username.ToUpper() == user)
                {
                    return account1;
                }
            }
            return null;
        }

        public Account FindNotLoggedAccountByIp(IPAddress e)
        {
            foreach (Account account1 in this)
            {
                if (((account1.Ip != null) && account1.Ip.Equals(e)) && (account1.SelectedChar == null))
                {
                    return account1;
                }
            }
            return null;
        }

        public new AccountEnumerator GetEnumerator()
        {
            return new AccountEnumerator(this);
        }

        public int IndexOf(Account val)
        {
            return base.List.IndexOf(val);
        }

        public void Insert(int index, Account val)
        {
            base.List.Insert(index, val);
        }

        public void Load(string filename)
        {
            if (File.Exists(filename))
            {
                XmlFile file1 = new XmlFile(filename);
                int num1 = 1;
                if (file1.DocumentElement.Attributes["version"] != null)
                {
                    try
                    {
                        num1 = Convert.ToInt32(file1.DocumentElement.Attributes["version"]);
                    }
                    catch
                    {
                        num1 = 1;
                    }
                }
                foreach (XmlNode node1 in file1.DocumentElement.SelectNodes("account"))
                {
                    Account account1 = new Account(num1, node1, file1);
                    if (account1 != null)
                    {
                        base.List.Add(account1);
                    }
                }
            }
            if (base.Count == 0)
            {
                Account account2 = new Account("admin", "changeme", AccessLevels.Admin);
                this.Add(account2);
            }
        }

        public void Remove(Account val)
        {
            base.List.Remove(val);
        }

        public void Save(string filename)
        {
            XmlFile file1 = new XmlFile(false, "", "accounts");
            int num1 = 0;
            file1.AddAttribute(file1.DocumentElement, "version", num1.ToString());
            foreach (Account account1 in this)
            {
                file1.DocumentElement.AppendChild(account1.Save(file1));
            }
            file1.Save(filename);
        }

        public void SendMessageToConnectedGM(string str)
        {
            byte[] buffer1 = new byte[(((((str.Length + 4) + 4) + 8) + 1) + 2) + 0x20];
            int num1 = 4;
            buffer1[num1++] = 0;
            num1 = 0x11;
            Converter.ToBytes(str, buffer1, ref num1);
            foreach (Account account1 in this)
            {
                if ((account1.SelectedChar != null) && (account1.AccessLevel != AccessLevels.PlayerLevel))
                {
                    int num2 = 4;
                    Converter.ToBytes(10, buffer1, ref num2);
                    Converter.ToBytes((byte) 0, buffer1, ref num2);
                    Converter.ToBytes((ulong) 0, buffer1, ref num2);
                    Converter.ToBytes((int) (str.Length + 1), buffer1, ref num2);
                    Converter.ToBytes(str, buffer1, ref num2);
                    Converter.ToBytes((short) 0, buffer1, ref num2);
                    account1.Handler.Send(150, buffer1, num2);
                }
            }
        }

        public void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            gw.Write(base.Count);
            AccountEnumerator enumerator1 = this.GetEnumerator();
            try
            {
                while (enumerator1.MoveNext())
                {
                    enumerator1.Current.Serialize(gw);
                }
            }
            finally
            {
                IDisposable disposable1 = enumerator1 as IDisposable;
                if (disposable1 != null)
                {
                    disposable1.Dispose();
                }
            }
            gw.Close();
        }


        // Properties
        public Account this[int index]
        {
            get
            {
                return (Account) base.List[index];
            }
            set
            {
                base.List[index] = value;
            }
        }


        // Nested Types
        public class AccountEnumerator : IEnumerator
        {
            // Methods
            public AccountEnumerator(Accounts mappings)
            {
                this.temp = mappings;
                this.baseEnumerator = this.temp.GetEnumerator();
            }

            public bool MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            public void Reset()
            {
                this.baseEnumerator.Reset();
            }


            // Properties
            public Account Current
            {
                get
                {
                    return (Account) this.baseEnumerator.Current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.baseEnumerator.Current;
                }
            }


            // Fields
            private IEnumerator baseEnumerator;
            private IEnumerable temp;
        }
    }
}

