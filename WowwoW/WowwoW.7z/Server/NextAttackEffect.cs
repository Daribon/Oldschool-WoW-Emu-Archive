namespace Server
{
    using System;

    public class NextAttackEffect
    {
        // Methods
        public NextAttackEffect(BaseAbility af, NextAttackEffectDelegate OnEffect)
        {
            this.number = 0;
            this.spell = af;
            this.onEffect = OnEffect;
        }

        public NextAttackEffect(BaseAbility af, NextAttackEffectDelegateMultiple OnEffect)
        {
            this.number = 0;
            this.spell = af;
            this.onEffect = OnEffect;
        }


        // Fields
        public int number;
        public object onEffect;
        public BaseAbility spell;
    }
}

