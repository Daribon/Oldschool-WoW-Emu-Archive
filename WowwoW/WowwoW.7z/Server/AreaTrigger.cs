namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void AreaTrigger(Character c, int areaId);

}

