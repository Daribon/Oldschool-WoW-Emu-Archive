namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Net;
    using System.Runtime.CompilerServices;
    using System.Threading;
    using System.Xml;

    public class Account
    {
        // Methods
        static Account()
        {
            Account.xml_attr_username = "name";
            Account.xml_attr_password = "pass";
            Account.xml_attr_accesslevel = "plevel";
            Account.xml_attr_guid = "guid";
        }

        public Account()
        {
            this.characteres = new ArrayList();
            this.lastHeartBeat = DateTime.Now;
            this.justLogged = true;
            this.packets = new Queue();
            this.mutex = new Mutex();
            this.playersNear = new ArrayList();
            this.knownObject = new ArrayList();
            this.toSendFirstTime = new ArrayList();
            this.timeout = 0;
            this.slowSpawnDelay = 0;
            this.lastRefreshPos = new Position(0f, 0f, 0f, 0);
        }

        public Account(GenericReader gr)
        {
            this.characteres = new ArrayList();
            this.lastHeartBeat = DateTime.Now;
            this.justLogged = true;
            this.packets = new Queue();
            this.mutex = new Mutex();
            this.playersNear = new ArrayList();
            this.knownObject = new ArrayList();
            this.toSendFirstTime = new ArrayList();
            this.timeout = 0;
            this.slowSpawnDelay = 0;
            this.lastRefreshPos = new Position(0f, 0f, 0f, 0);
            this.Deserialize(gr);
        }

        public Account(string u, string p) : this()
        {
            this.username = u;
            this.password = p;
        }

        public Account(int version, XmlNode node, XmlFile doc)
        {
            this.characteres = new ArrayList();
            this.lastHeartBeat = DateTime.Now;
            this.justLogged = true;
            this.packets = new Queue();
            this.mutex = new Mutex();
            this.playersNear = new ArrayList();
            this.knownObject = new ArrayList();
            this.toSendFirstTime = new ArrayList();
            this.timeout = 0;
            this.slowSpawnDelay = 0;
            this.lastRefreshPos = new Position(0f, 0f, 0f, 0);
            if (version == 1)
            {
                this.username = doc.GetAttributeVal(node, Account.xml_attr_username, null);
                this.password = doc.GetAttributeVal(node, Account.xml_attr_password, null);
                this.accessLevel = (AccessLevels) Convert.ToInt32(doc.GetAttributeVal(node, Account.xml_attr_accesslevel, "0"));
                foreach (XmlNode node1 in node.SelectNodes(Account.xml_attr_guid))
                {
                    ulong num1 = ulong.Parse(doc.GetInnerText(node1, "0"));
                    Character character1 = (Character) World.FindMobileByGUID(num1);
                    if (character1 != null)
                    {
                        this.characteres.Add(character1);
                        World.allMobiles.Remove(character1);
                    }
                }
            }
        }

        public Account(string u, string p, AccessLevels al) : this(u, p)
        {
            this.accessLevel = al;
        }

		public void AddCharacter(byte[] data)
		{
			Character character1 = new Character(this, data);
			if (character1.Name != null)
			{
				this.characteres.Add(character1);
			}
		}

        public void CancelLogout()
        {
            if (this.loggoutTimer != null)
            {
                this.loggoutTimer.Stop();
                this.loggoutTimer = null;
                byte[] buffer1 = new byte[4];
                this.Handler.Send(OpCodes.SMSG_LOGOUT_CANCEL_ACK, buffer1);
            }
        }

        public void DeleteChar(ulong guid)
        {
            Character character1 = null;
            foreach (Character character2 in this.characteres)
            {
                if (character2.Guid == guid)
                {
                    character1 = character2;
                    break;
                }
            }
            if (character1 != null)
            {
                this.characteres.Remove(character1);
                byte[] buffer1 = new byte[12];
                int num1 = 4;
                Converter.ToBytes(guid, buffer1, ref num1);
                this.Handler.Send(OpCodes.SMSG_CHAR_DELETE, buffer1);
            }
        }

        public void Deserialize(GenericReader gr)
        {
            this.characteres.Clear();
        }

        public Mobile FindMobileByGuid(ulong guid)
        {
            foreach (Server.Object obj1 in this.knownObject)
            {
                if (obj1.Guid == guid)
                {
                    return (Mobile) obj1;
                }
            }
            return null;
        }

        public Server.Object FindObjectByGuid(ulong guid)
        {
            foreach (Server.Object obj1 in this.knownObject)
            {
                if (obj1.Guid == guid)
                {
                    return obj1;
                }
            }
            return null;
        }

        public Character FindPlayerNearByGuid(ulong guid)
        {
            foreach (Character character1 in this.playersNear)
            {
                if (character1.Guid == guid)
                {
                    return character1;
                }
            }
            return null;
        }

        public void HeartBeat()
        {
            this.lastHeartBeat = DateTime.Now;
            if (this.selectedChar != null)
            {
                this.RefreshMobileList(true);
            }
        }

        public void Loggout(ulong guid)
        {
			//this.SelectedChar.QuitGroup();//fix
            this.realylogged = false;
            if (this.SelectedChar != null)
            {
                this.SelectedChar.QuitGroup();
                this.SelectedChar.OnLogout();
                World.allConnectedChars.Remove(this.selectedChar);
            }
            if (World.allConnectedAccounts.Contains(this))
            {
                World.allConnectedAccounts.Remove(this);
            }
            if (this.SelectedChar != null)
            {
                World.allMobiles.Remove(this.selectedChar);
            }
            this.playersNear = new ArrayList();
            this.knownObject = new ArrayList();
            this.Ip = null;
            this.SelectedChar = null;
        }

        public void LoggoutStartTimer()
        {
            new LoggoutTimer(this);
        }

        public Character Login(ulong guid)
        {
            this.realylogged = true;
            this.justLogged = true;
            this.SelectedChar = null;
            foreach (Character character1 in this.characteres)
            {
                if (character1.Guid == guid)
                {
                    this.SelectedChar = character1;
                    break;
                }
            }
            if (this.SelectedChar == null)
            {
                return null;
            }
            if (this.knownObject != null)
            {
                this.knownObject.Clear();
            }
            if (this.PlayersNear != null)
            {
                this.playersNear.Clear();
            }
            else
            {
                this.playersNear = new ArrayList();
            }
			this.selectedChar.Login(this);
			byte[] buffer1 = new byte[0x54];
			this.Handler.Send(0x209, buffer1);
			byte[] buffer4 = new byte[6];
			buffer4[1] = 4;
			buffer4[2] = 0x6b;
			this.Handler.Send(buffer4);
			this.SelectedChar.SendFriendList();
            this.Handler.Send(new byte[0x18] { 
                0, 0x16, 0x55, 1, 0x8f, 2, 0xc3, 0xc5, 0x39, 0x84, 0xa5, 0x43, 6, 0x61, 0xbf, 0x43, 
                1, 0, 0, 0, 0, 0, 0, 0
             } );
            buffer4 = new byte[8];
            buffer4[4] = 0x4b;
            buffer4[5] = 0x71;
            this.Handler.Send(0x21e, buffer4);
            this.Handler.Send(0x266, new byte[10] { 0, 0, 0, 0, 6, 10, 0x38, 0xff, 0xff, 0xff } );
            this.Handler.Send(new byte[0x24] { 
                0, 0x22, 0xfd, 0, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
                0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 0xff, 
                0xff, 0xff, 0xff, 0xff
             } );
            this.SelectedChar.SendAllSpells();
            this.SelectedChar.SendAllActionButtons();
            byte[] buffer2 = new byte[0x1b2] { 
                0, 0, 0, 0, 0xff, 0, 0, 0, 0x6a, 0, 0x61, 5, 0, 0, 0x60, 5, 
                0, 0, 0x5f, 5, 0, 0, 0x5e, 5, 0, 0, 0x5d, 5, 0, 0, 0x5c, 5, 
                0, 0, 0x5b, 5, 0, 0, 90, 5, 0, 0, 0x59, 5, 0, 0, 0x58, 5, 
                0, 0, 0x57, 5, 0, 0, 0x56, 5, 15, 0x27, 0x55, 5, 0, 0, 0x54, 5, 
                1, 0, 0x53, 5, 1, 0, 0x52, 5, 1, 0, 0x51, 5, 1, 0, 0x4f, 5, 
                0, 0, 0x4e, 5, 0, 0, 0x4d, 5, 1, 0, 0x4c, 5, 0, 0, 0x4b, 5, 
                0, 0, 0x45, 5, 0, 0, 0x43, 5, 1, 0, 0x42, 5, 0, 0, 0x40, 5, 
                0, 0, 0x3f, 5, 0, 0, 0x3e, 5, 1, 0, 0x3d, 5, 0, 0, 60, 5, 
                0, 0, 0x3b, 5, 0, 0, 0x3a, 5, 1, 0, 0x39, 5, 0, 0, 0x38, 5, 
                0, 0, 0x37, 5, 0, 0, 0x34, 5, 0, 0, 0x33, 5, 0, 0, 0x30, 5, 
                0, 0, 0x2f, 5, 0, 0, 0x2d, 5, 1, 0, 0x16, 5, 1, 0, 0x15, 5, 
                0, 0, 0xb6, 3, 0, 0, 0x45, 7, 2, 0, 0x36, 7, 1, 0, 0x35, 7, 
                1, 0, 0x34, 7, 1, 0, 0x33, 7, 1, 0, 50, 7, 1, 0, 2, 7, 
                0, 0, 1, 7, 0, 0, 0, 7, 0, 0, 0xfe, 6, 0, 0, 0xfd, 6, 
                0, 0, 0xfc, 6, 0, 0, 0xfb, 6, 0, 0, 0xf8, 6, 0, 0, 0xf7, 6, 
                0, 0, 0xf6, 6, 0, 0, 0xf4, 6, 0xd0, 7, 0xf2, 6, 0, 0, 0xf0, 6, 
                0, 0, 0xef, 6, 0, 0, 0xec, 6, 0, 0, 0xea, 6, 0, 0, 0xe9, 6, 
                0, 0, 0xe8, 6, 0, 0, 0xe7, 6, 0, 0, 0x18, 5, 0, 0, 0x17, 5, 
                0, 0, 3, 7, 0, 0, 0xf9, 6, 0, 0, 0xf3, 6, 0, 0, 0xf1, 6, 
                0, 0, 0xee, 6, 0, 0, 0xed, 6, 0, 0, 0x71, 5, 0, 0, 0x70, 5, 
                0, 0, 0x67, 5, 1, 0, 0x66, 5, 1, 0, 80, 5, 1, 0, 0x44, 5, 
                0, 0, 0x36, 5, 0, 0, 0x35, 5, 1, 0, 50, 5, 1, 0, 0x31, 5, 
                0, 0, 0x2e, 5, 0, 0, 0xc6, 3, 0, 0, 0xc4, 3, 0, 0, 0xc2, 3, 
                0, 0, 0xa3, 7, 15, 0x27, 0x74, 5, 0, 0, 0x73, 5, 0, 0, 0x72, 5, 
                0, 0, 0x6f, 5, 0, 0, 110, 5, 0, 0, 0x6d, 5, 0, 0, 0x6c, 5, 
                0, 0, 0x6b, 5, 0, 0, 0x6a, 5, 1, 0, 0x69, 5, 1, 0, 0x68, 5, 
                1, 0, 0x65, 5, 0, 0, 100, 5, 0, 0, 0x63, 5, 0, 0, 0x62, 5, 
                0, 0
             } ;
            this.Handler.Send(0x121, buffer2, buffer2.Length);
            this.Handler.Send(new byte[12] { 0, 10, 0x42, 0, 12, 0xc9, 0x16, 5, 0x89, 0x88, 0x88, 60 } );
            this.Handler.Send(0x269, new byte[8] { 1, 70, 0x22, 1, 0, 0, 0, 0 } );
            byte[] buffer3 = new byte[12];
            int num1 = 4;
            Converter.ToBytes(World.GetActualTime(), buffer3, ref num1);
            Converter.ToBytes((float) 0.017f, buffer3, ref num1);
            this.Handler.Send(0x42, buffer3);
            byte[] buffer5 = new byte[240];
            num1 = 4;
            this.RefreshFactionReactions();
            World.allConnectedChars.Add(this.selectedChar);
            World.allConnectedAccounts.Add(this);
            World.allMobiles.Add(this.selectedChar);
            this.knownObject.Add(this.selectedChar);
            this.toSendFirstTime.Add(this.selectedChar);
            this.selectedChar.FullUpdate(this.knownObject);
            this.selectedChar.ItemsUpdate();
            if (this.selectedChar.Summon != null)
            {
                this.selectedChar.SendPetActionBar();
            }
            this.HeartBeat();
            this.autoDeconnectTimer = new AutoDeconnect(this);
            this.SelectedChar.OnLogin();
            return this.SelectedChar;
        }

        public void MvtToAllPlayerNear(int code, byte[] data, int after, int len)
        {
            if (this.playersNear.Count != 0)
            {
                byte[] buffer1 = new byte[len + 8];
                System.Buffer.BlockCopy(data, after + 4, buffer1, 10, len - 4);
                ulong num1 = this.selectedChar.Guid;
                foreach (Character character1 in this.playersNear)
                {
                    if ((character1.Player != null) && character1.Player.PlayersNear.Contains(this.SelectedChar))
                    {
                        int num2 = 4;
                        Converter.ToBytes(num1, buffer1, ref num2);
                        character1.Player.Handler.Send(code, buffer1, (int) (len + 8));
                    }
                }
            }
        }

        public bool PacketHandler()
        {
            if (this.Handler == null)
            {
                Console.WriteLine("Handler == null ----> DrNexus");
            }
            if (this.Handler.Disposed)
            {
                this.timeout++;
                if (this.timeout > 500)
                {
                    this.StopPacketHandler();
                    this.timeout = 0;
                    return true;
                }
            }
            Packet packet1 = null;
            if (this.Packets == null)
            {
                Console.WriteLine("Packets == null ----> DrNexus");
            }
            lock (this.Packets)
            {
                if (this.Packets.Count > 0)
                {
                    packet1 = (Packet) this.Packets.Dequeue();
                }
            }
            if (packet1 != null)
            {
                this.Handler.DequeueData(packet1.data, packet1.len);
            }
            return false;
        }

        public void PreLogin()
        {
            this.packetHandler = new InternalPacketTimer(new PacketHandlerDelegate(this.PacketHandler));
        }

        public byte[] PrepareDataList(ref int t)
        {
            byte[] buffer1 = new byte[0x800];
            buffer1[t++] = (byte) this.characteres.Count;
            foreach (Character character1 in this.characteres)
            {
                character1.toData(ref buffer1, ref t);
            }
            return buffer1;
        }

        public void RefreshFactionReactions()
        {
            IDictionaryEnumerator enumerator1 = this.SelectedChar.ReputationAdjustments.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                int num1 = 4;
                Converter.ToBytes(1, this.SelectedChar.tempBuff, ref num1);
                Converter.ToBytes((int) enumerator1.Key, this.SelectedChar.tempBuff, ref num1);
                Converter.ToBytes((int) enumerator1.Value, this.SelectedChar.tempBuff, ref num1);
                this.SelectedChar.Send(OpCodes.SMSG_SET_FACTION_STANDING, this.SelectedChar.tempBuff, num1);
            }
        }

        public void RefreshMobileList()
        {
            this.RefreshMobileList(false);
        }

        public void RefreshMobileList(bool force)
        {
            if (this.selectedChar != null)
            {
                ArrayList list1 = new ArrayList();
                list1.Add(this.selectedChar);
                this.toSendFirstTime.Clear();
                foreach (Character character1 in World.allConnectedChars)
                {
                    if (this.knownObject.Contains(character1))
                    {
                        list1.Add(character1);
                        continue;
                    }
                    this.toSendFirstTime.Add(character1);
                    if (character1 != this.selectedChar)
                    {
                        this.playersNear.Add(character1);
                    }
                }
                if ((this.selectedChar.LinkedSpawner == -1) || (this.selectedChar.QuickDistance(World.allSpawners[this.selectedChar.LinkedSpawner]) > 0x15f9))
                {
                    int num1 = 0x7fffffff;
                    int num2 = this.selectedChar.MapId;
                    for (int num3 = 0; num3 < World.allSpawners.Count; num3++)
                    {
                        BaseSpawner spawner1 = World.allSpawners[num3];
                        if (spawner1.MapId == num2)
                        {
                            int num4 = spawner1.QuickDistance(this.selectedChar);
                            if (num4 < num1)
                            {
                                num1 = num4;
                                this.selectedChar.LinkedSpawner = num3;
                            }
                        }
                    }
                }
                if (this.selectedChar.LinkedSpawner != -1)
                {
                    ArrayList list2 = World.regSpawners[this.selectedChar.LinkedSpawner] as ArrayList;
                    if (list2 != null)
                    {
                        int num5 = this.selectedChar.LinkedSpawner;
                        BaseSpawner spawner2 = World.allSpawners[num5];
                        int num6 = spawner2.QuickDistance(this.selectedChar);
                        for (int num7 = -1; num7 < list2.Count; num7++)
                        {
                            BaseSpawner spawner3 = spawner2;
                            if (num7 >= 0)
                            {
                                int num8 = (int) list2[num7];
                                if (num8 >= 0)
                                {
                                    spawner3 = World.allSpawners[num8];
                                    int num9 = spawner3.QuickDistance(this.selectedChar);
                                    if (num9 < num6)
                                    {
                                        num9 = num6;
                                        num5 = (int) list2[num7];
                                    }
                                }
                            }
                            spawner3.StillActive(this.selectedChar);
                            if (this.accessLevel != AccessLevels.PlayerLevel)
                            {
                                if (this.knownObject.Contains(spawner3))
                                {
                                    list1.Add(spawner3);
                                }
                                else
                                {
                                    this.toSendFirstTime.Add(spawner3);
                                }
                            }
                            foreach (Server.Object obj1 in spawner3.Objects)
                            {
                                if (this.selectedChar.CanSee(obj1))
                                {
                                    if (obj1 is BaseCreature)
                                    {
                                        (obj1 as BaseCreature).StillActive(this.selectedChar);
                                    }
                                    if (this.knownObject.Contains(obj1))
                                    {
                                        list1.Add(obj1);
                                        continue;
                                    }
                                    this.toSendFirstTime.Add(obj1);
                                }
                            }
                        }
                        this.selectedChar.LinkedSpawner = num5;
                    }
                }
                foreach (Server.Object obj2 in this.knownObject)
                {
                    if (!list1.Contains(obj2))
                    {
                        this.selectedChar.DestroyObject(obj2.Guid);
                        if (obj2 is Character)
                        {
                            this.playersNear.Remove(obj2);
                        }
                    }
                }
                this.knownObject = list1;
                if (this.justLogged)
                {
                    this.selectedChar.FullUpdate(this.toSendFirstTime);
                    foreach (Server.Object obj3 in this.toSendFirstTime)
                    {
                        if ((obj3 is Character) && (obj3 != this.selectedChar))
                        {
                            (obj3 as Character).ItemsUpdateForOther(this);
                        }
                    }
                    this.selectedChar.ItemsUpdate();
                    if (this.selectedChar.Summon != null)
                    {
                        this.selectedChar.SendPetActionBar();
                    }
                }
                else
                {
                    this.selectedChar.PartialUpdate(this.toSendFirstTime);
                    foreach (Server.Object obj4 in this.toSendFirstTime)
                    {
                        if ((obj4 is Character) && (obj4 != this.selectedChar))
                        {
                            (obj4 as Character).ItemsUpdateForOther(this);
                        }
                    }
                }
                this.knownObject.AddRange(this.toSendFirstTime);
                this.toSendFirstTime.Clear();
            }
        }

        public void RefreshMobileListOld(bool force)
        {
            if (this.selectedChar != null)
            {
                ArrayList list1 = new ArrayList();
                list1.Add(this.selectedChar);
                this.toSendFirstTime.Clear();
                ArrayList list2 = World.allMobiles.GetContinent(this.selectedChar.MapId);
                if (force || (this.lastRefreshPos.QuickDistance(this.selectedChar) >= 0x57e4))
                {
                    this.slowSpawnDelay++;
                    this.lastRefreshPos = new Position(this.selectedChar.X, this.selectedChar.Y, this.selectedChar.Z, this.selectedChar.MapId);
                    if (this.accessLevel != AccessLevels.PlayerLevel)
                    {
                        int num1 = 0;
                        if (World.zones[this.selectedChar.ZoneId] != null)
                        {
                            num1 = (int) World.zones[this.selectedChar.ZoneId];
                        }
                        ArrayList list3 = World.allSpawners.Nearest((this.selectedChar.MapId * 0x400) + num1);
                        if (list3 != null)
                        {
                            foreach (BaseSpawner spawner1 in list3)
                            {
                                float single1 = this.selectedChar.Distance(spawner1);
                                if (single1 < 90000f)
                                {
                                    spawner1.StillActive(this.selectedChar);
                                    if (this.knownObject.Contains(spawner1))
                                    {
                                        list1.Add(spawner1);
                                        continue;
                                    }
                                    this.toSendFirstTime.Add(spawner1);
                                }
                            }
                        }
                    }
                    else
                    {
                        int num2 = 0;
                        if (World.zones[this.selectedChar.ZoneId] != null)
                        {
                            num2 = (int) World.zones[this.selectedChar.ZoneId];
                        }
                        ArrayList list4 = World.allSpawners.Nearest((this.selectedChar.MapId * 0x400) + num2);
                        if (list4 != null)
                        {
                            foreach (BaseSpawner spawner2 in list4)
                            {
                                if (this.selectedChar.Distance(spawner2) < 90000f)
                                {
                                    spawner2.StillActive(this.selectedChar);
                                }
                            }
                        }
                    }
                    if (list2 != null)
                    {
                        foreach (Mobile mobile1 in list2)
                        {
                            if (this.selectedChar.CanSee(mobile1))
                            {
                                if (mobile1 is BaseCreature)
                                {
                                    (mobile1 as BaseCreature).StillActive(this.selectedChar);
                                }
                                if (this.knownObject.Contains(mobile1))
                                {
                                    list1.Add(mobile1);
                                    continue;
                                }
                                if (!this.justLogged || (mobile1 is Character))
                                {
                                    this.toSendFirstTime.Add(mobile1);
                                }
                                if ((mobile1 is Character) && (mobile1 != this.selectedChar))
                                {
                                    this.playersNear.Add(mobile1);
                                }
                            }
                        }
						
                    }
                    if (!this.justLogged)
                    {
                        foreach (GameObject obj1 in World.allGameObjects)
                        {
                            if (obj1.SeenBy(this.selectedChar))
                            {
                                if (this.knownObject.Contains(obj1))
                                {
                                    list1.Add(obj1);
                                    continue;
                                }
                                this.toSendFirstTime.Add(obj1);
                            }
                        }
                    }
                    foreach (Server.Object obj2 in this.knownObject)
                    {
                        if (!list1.Contains(obj2))
                        {
                            this.selectedChar.DestroyObject(obj2.Guid);
                            if (obj2 is Character)
                            {
                                this.playersNear.Remove(obj2);
                            }
                        }
                    }
                    this.knownObject = list1;
                    if (this.justLogged)
                    {
						this.justLogged = false;//�����������
                        this.selectedChar.FullUpdate(this.toSendFirstTime);
                        foreach (Server.Object obj3 in this.toSendFirstTime)
                        {
                            if ((obj3 is Character) && (obj3 != this.selectedChar))
                            {
                                (obj3 as Character).ItemsUpdateForOther(this);
                            }
                        }
                        this.selectedChar.ItemsUpdate();
                        if (this.selectedChar.Summon != null)
                        {
                            this.selectedChar.SendPetActionBar();
                        }
                    }
                    else
                    {
                        this.selectedChar.PartialUpdate(this.toSendFirstTime);
                        foreach (Server.Object obj4 in this.toSendFirstTime)
                        {
                            if ((obj4 is Character) && (obj4 != this.selectedChar))
                            {
                                (obj4 as Character).ItemsUpdateForOther(this);
                            }
                        }
                    }
                    this.knownObject.AddRange(this.toSendFirstTime);
                    this.toSendFirstTime.Clear();
                    /*if (this.justLogged)//����
                    {
                        this.justLogged = false;
                        this.RefreshMobileList(true);
                    }*/
                }
            }
        }

        public XmlNode Save(XmlFile doc)
        {
            XmlNode node1 = doc.CreateNode("account", "");
            doc.AddAttribute(node1, Account.xml_attr_username, this.username);
            doc.AddAttribute(node1, Account.xml_attr_password, this.password);
            //doc.AddAttribute(node1, Account.xml_attr_accesslevel, this.accessLevel.ToString());
			doc.AddAttribute(node1, Account.xml_attr_accesslevel, Convert.ToString((int)this.accessLevel));//���plevel="2"������
            foreach (Character character1 in this.characteres)
            {
                ulong num1 = character1.Guid;
                doc.AddNode(node1, Account.xml_attr_guid, num1.ToString());
            }
            return node1;
        }

        public void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            gw.Write(this.username);
            gw.Write(this.password);
            gw.Write((int) this.accessLevel);
            gw.Write(this.characteres.Count);
            foreach (Character character1 in this.characteres)
            {
                gw.Write(character1.Guid);
            }
        }

        public void StopPacketHandler()
        {
            if (this.packetHandler != null)
            {
                this.packetHandler.Stop();
            }
            this.packetHandler = null;
            this.Ip = null;
        }

        public bool TestIfLoggout()
        {
            if (this.selectedChar != null)
            {
                TimeSpan span1 = DateTime.Now.Subtract(this.lastHeartBeat);
                if (span1.TotalSeconds > 60)
                {
                    this.Loggout(0);
                    return true;
                }
            }
            return false;
        }

        public void ToAllPlayerNear(OpCodes code, byte[] data)
        {
            this.ToAllPlayerNear(code, data, data.Length);
        }

        public void ToAllPlayerNear(OpCodes code, byte[] data, int len)
        {
            this.handler.Send(code, data, len);
            if (this.playersNear.Count != 0)
            {
                foreach (Character character1 in this.playersNear)
                {
                    if (character1.Player.PlayersNear.Contains(this.SelectedChar))
                    {
                        character1.Player.Handler.Send(code, data, len);
                    }
                }
            }
        }

        public void ToAllPlayerNear(Mobile m, OpCodes code, byte[] data, int len)
        {
            if (this.knownObject.Contains(m))
            {
                this.handler.Send(code, data, len);
            }
            if (this.playersNear.Count != 0)
            {
                foreach (Character character1 in this.playersNear)
                {
                    if (character1.Player.KnownObjects.Contains(m))
                    {
                        character1.Player.Handler.Send(code, data, len);
                    }
                }
            }
        }

        public void ToAllPlayerNear(OpCodes code, byte[] data, int after, int len)
        {
            byte[] buffer1 = new byte[len];
            System.Buffer.BlockCopy(data, after, buffer1, 0, len);
            this.handler.Send(code, buffer1, len);
            if (this.playersNear.Count != 0)
            {
                foreach (Character character1 in this.playersNear)
                {
                    if (character1.Player.PlayersNear.Contains(this.SelectedChar))
                    {
                        character1.Player.Handler.Send(code, buffer1, len);
                    }
                }
            }
        }

        public void ToAllPlayerNearExceptMe(OpCodes code, byte[] data, int len)
        {
            if (this.playersNear.Count != 0)
            {
                foreach (Character character1 in this.playersNear)
                {
                    if (character1.Player.PlayersNear.Contains(this.SelectedChar))
                    {
                        character1.Player.Handler.Send(code, data, len);
                    }
                }
            }
        }

        public void ToAllPlayerNearExceptMe(OpCodes code, byte[] data, int after, int len)
        {
            byte[] buffer1 = new byte[len];
            System.Buffer.BlockCopy(data, after, buffer1, 0, len);
            this.ToAllPlayerNearExceptMe(code, buffer1, len);
        }


        // Properties
        public AccessLevels AccessLevel
        {
            get
            {
                return this.accessLevel;
            }
            set
            {
                this.accessLevel = value;
            }
        }

        public Mutex ExMutuel
        {
            get
            {
                return this.mutex;
            }
        }

        public PlayerHandler Handler
        {
            get
            {
                return this.handler;
            }
            set
            {
                this.handler = value;
                if (value == null)
                {
                    Console.WriteLine("");
                }
            }
        }

        public IPAddress Ip
        {
            get
            {
                return this.ip;
            }
            set
            {
                this.ip = value;
            }
        }

        public byte[] K
        {
            get
            {
                return this.k;
            }
            set
            {
                this.k = value;
            }
        }

        public ArrayList KnownObjects
        {
            get
            {
                return this.knownObject;
            }
        }

        public Queue Packets
        {
            get
            {
                return this.packets;
            }
            set
            {
                this.packets = value;
            }
        }

        public string Password
        {
            get
            {
                return this.password;
            }
            set
            {
                this.password = value;
            }
        }

        public ArrayList PlayersNear
        {
            get
            {
                return this.playersNear;
            }
        }

        public int Port
        {
            get
            {
                return this.port;
            }
            set
            {
                this.port = value;
            }
        }

        public bool Realylogged
        {
            get
            {
                return this.realylogged;
            }
        }

        public Character SelectedChar
        {
            get
            {
                return this.selectedChar;
            }
            set
            {
                this.selectedChar = value;
            }
        }

        public string Username
        {
            get
            {
                return this.username;
            }
            set
            {
                this.username = value;
            }
        }


        // Fields
        private AccessLevels accessLevel;
        private AutoDeconnect autoDeconnectTimer;
        public ArrayList characteres;
        private PlayerHandler handler;
        private IPAddress ip;
        public bool justLogged;
        public byte[] k;
        private ArrayList knownObject;
        public DateTime lastHeartBeat;
        private Position lastRefreshPos;
        public LoggoutTimer loggoutTimer;
        private Mutex mutex;
        public InternalPacketTimer packetHandler;
        private Queue packets;
        private string password;
        private ArrayList playersNear;
        private int port;
        public bool realylogged;
        private Character selectedChar;
        private int slowSpawnDelay;
        public byte[] SS_Hash;
        private int timeout;
        private ArrayList toSendFirstTime;
        private string username;
        protected static string xml_attr_accesslevel;
        protected static string xml_attr_guid;
        protected static string xml_attr_password;
        protected static string xml_attr_username;

        // Nested Types
        private class AutoDeconnect : WowTimer
        {
            // Methods
            public AutoDeconnect(Account acc) : base(WowTimer.Priorities.Second5, 10000)
            {
                this.from = acc;
                base.Start();
            }

            public override void OnTick()
            {
                TimeSpan span1 = this.from.lastHeartBeat.Subtract(DateTime.Now);
                if (span1.TotalSeconds > 30)
                {
                    this.from.Loggout(this.from.SelectedChar.Guid);
                }
                base.OnTick();
                base.Stop();
            }


            // Fields
            private Account from;
        }

		public class InternalPacketTimer : WowTimer
		{
			// Methods
			public InternalPacketTimer(Account.PacketHandlerDelegate ph) : base(20)
			{
				this.handler = ph;
				base.Start();
			}

			public override void OnTick()
			{
				if (this.handler())
				{
					base.Stop();
				}
				else
				{
					base.OnTick();
				}
			}


            // Fields
            private Account.PacketHandlerDelegate handler;
        }

        public class LoggoutTimer : WowTimer
        {
            // Methods
            public LoggoutTimer(Account acc) : base(WowTimer.Priorities.Second, 3000)
            {
                this.from = acc;
                if (this.from.selectedChar == null)
                {
                    base.Stop();
                }
                base.Start();
            }

            public override void OnTick()
            {
                if (this.from.selectedChar == null)
                {
                    base.Stop();
                }
                else
                {
                    byte[] buffer1 = new byte[4];
                    this.from.Handler.Send(0x4d, buffer1);
                    this.from.Loggout(this.from.SelectedChar.Guid);
                }
                base.OnTick();
                base.Stop();
            }


            // Fields
            private Account from;
        }

        public delegate bool PacketHandlerDelegate();

    }
}

