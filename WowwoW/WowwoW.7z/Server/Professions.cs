namespace Server
{
    using System;

    public enum Professions
    {
        // Fields
        Alchemist = 1,
        Blacksmith = 4,
        Cooking = 11,
        Enchanter = 9,
        Engineer = 10,
        FirstAid = 12,
        Fishing = 6,
        Herborist = 3,
        LeatherWorker = 7,
        Miner = 2,
        NoProf = 0,
        Skinning = 8,
        Tailor = 5
    }
}

