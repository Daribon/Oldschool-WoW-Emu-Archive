namespace Server
{
    using System;

    public class TwoHandedAxeSkill : Skill
    {
        // Methods
        public TwoHandedAxeSkill()
        {
        }

        public TwoHandedAxeSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xac;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xac;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xc5;
            }
        }

    }
}

