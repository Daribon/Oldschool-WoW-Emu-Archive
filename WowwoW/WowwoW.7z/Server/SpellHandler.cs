namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool SpellHandler(Mobile c, int spell, Server.Object target);

}

