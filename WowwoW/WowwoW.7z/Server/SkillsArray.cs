namespace Server
{
    using System;
    using System.Collections;

    public class SkillsArray
    {
        // Methods
        public SkillsArray()
        {
            this._items = new ArrayList();
        }

        public void Add(qSkills skill_needed)
        {
            if (!this._items.Contains(skill_needed))
            {
                this._items.Add(skill_needed);
            }
        }


        // Properties
        public int Count
        {
            get
            {
                return this._items.Count;
            }
        }

        public qSkills[] Items
        {
            get
            {
                return (qSkills[]) this._items.ToArray(typeof(qSkills));
            }
        }


        // Fields
        private ArrayList _items;
    }
}

