namespace Server
{
    using System;

    public class HexaPoint
    {
        // Methods
        public HexaPoint()
        {
        }

        public HexaPoint(HexaPoint v)
        {
            this.x = v.x;
            this.y = v.y;
        }

        public HexaPoint(int xx, int yy)
        {
            this.x = xx;
            this.y = yy;
        }

        public HexaPoint Clone()
        {
            return new HexaPoint(this.x, this.y);
        }

        public double Distance(HexaPoint with)
        {
            float single1 = this.x;
            float single2 = this.y;
            float single3 = with.x;
            float single4 = with.y;
            if ((with.y & 1) == 0)
            {
                single3 += 0.5f;
            }
            if ((this.y & 1) == 0)
            {
                single1 += 0.5f;
            }
            float single5 = single1 - single3;
            single5 *= single5;
            float single6 = single2 - single4;
            single6 *= single6;
            single5 += single6;
            return (double) single5;
        }


        // Fields
        public int x;
        public int y;
    }
}

