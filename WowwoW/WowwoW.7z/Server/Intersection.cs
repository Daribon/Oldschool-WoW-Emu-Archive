namespace Server
{
    using System;

    public class Intersection : Coord
    {
        // Methods
        public Intersection(Coord t, Coord o, Coord l, Coord r, float a, float b, float c) : base(a, b, c, l, r)
        {
            this.left = t;
            this.right = o;
        }


        // Fields
        public Coord left;
        public Coord right;
    }
}

