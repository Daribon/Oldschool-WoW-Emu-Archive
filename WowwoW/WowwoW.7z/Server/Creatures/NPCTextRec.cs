namespace Server.Creatures
{
    using Server;
    using System;

    public class NPCTextRec
    {
        // Methods
        public NPCTextRec(string text)
        {
            this.lines = null;
            this.line = null;
            this.line = text;
        }

        public NPCTextRec(string[] textLines)
        {
            this.lines = null;
            this.line = null;
            this.lines = textLines;
        }


        // Properties
        public string GetText
        {
            get
            {
                if (this.line != null)
                {
                    return this.line;
                }
                return (string) Rnd.RandomObjectArr(this.lines);
            }
        }


        // Fields
        private string line;
        private string[] lines;
    }
}

