namespace Server.Creatures
{
    using Server;
    using Server.Items;
    using System;
    using System.Collections;

    public class BaseNPC : BaseCreature
    {
        // Methods
        static BaseNPC()
        {
            BaseNPC.Dialog_Taxi = "Taxi";
            BaseNPC.Dialog_Inkeeper_Bind = "Make this inn your home.";
            BaseNPC.Dialog_Inkeeper_Msg = "What Can I do at an inn?";
            BaseNPC.Dialog_Vendor = "I want to browse your goods.";
            BaseNPC.Dialog_Teach = "I can teach you somthing.";
            BaseNPC.Dialog_Bank = "Bank";
            BaseNPC.Message_Hello = "Hello.";
            BaseNPC._sNpcTextArr = new Hashtable();
        }

        public BaseNPC()
        {
            this._haveQuests = null;
            this._vendor = null;
            this._taxi = null;
            this._trainer = null;
            this._banker = null;
            this._inKeeper = null;
            this._onlyQuests = null;
            this._npcTextArr = new Hashtable();
        }

        public void addNpcText(int id, NPCTextRec val)
        {
            if (this._npcTextArr.ContainsKey(id))
            {
                this._npcTextArr.Remove(id);
            }
            this._npcTextArr.Add(id, val);
        }

        public void addNpcText(int id, string line)
        {
            this.addNpcText(id, new NPCTextRec(line));
        }

        public void addNpcText(int id, string[] lines)
        {
            this.addNpcText(id, new NPCTextRec(lines));
        }

        public static void AddNpcText(int id, NPCTextRec val)
        {
            if (BaseNPC._sNpcTextArr.ContainsKey(id))
            {
                BaseNPC._sNpcTextArr.Remove(id);
            }
            BaseNPC._sNpcTextArr.Add(id, val);
        }

        public static void AddNpcText(int id, string line)
        {
            BaseNPC.AddNpcText(id, new NPCTextRec(line));
        }

        public static void AddNpcText(int id, string[] lines)
        {
            BaseNPC.AddNpcText(id, new NPCTextRec(lines));
        }

        private static bool AllowedTo(BaseQuest bq, Character c)
        {
            if (((bq.MinLevel <= c.Level) && bq.AllowedClass(c)) && (bq.AllowedRace(c) && bq.AllowedSkills(c)))
            {
                return !bq.QuestIsBugged;
            }
            return false;
        }

        private int AmountActiveQuests(Character c)
        {
            int num1 = 0;
            ActiveQuest[] questArray1 = c.GetActiveQuests;
            for (int num2 = 0; num2 < questArray1.Length; num2++)
            {
                ActiveQuest quest1 = questArray1[num2];
                if ((quest1 != null) && (quest1.baseQuest != null))
                {
                    num1++;
                }
            }
            return num1;
        }

        public static int AmountMyQuests(Character c, BaseNPC npc)
        {
            int num1 = 0;
            if (npc.Quests != null)
            {
                BaseQuest[] questArray1 = npc.Quests;
                for (int num2 = 0; num2 < questArray1.Length; num2++)
                {
                    BaseQuest quest1 = questArray1[num2];
                    num1 += (c.HaveQuest(quest1) ? 1 : 0);
                }
            }
            return num1;
        }

        public override void DialogCharacterSelection(Character c, int id, int num)
        {
            NPCMenuId id1 = (NPCMenuId) id;
            if (id1 == NPCMenuId.MainMenu)
            {
                bool flag1;
                int num1 = num;
                switch (num1)
                {
                    case 1:
                    {
                        if (!this.Taxi)
                        {
                            goto Label_012E;
                        }
                        c.EndGossip();
                        return;
                    }
                    case 2:
                    {
                        if (!this.Vendor && !this.InKeeper)
                        {
                            goto Label_012E;
                        }
                        c.ShowMobileInventory(base.Guid);
                        return;
                    }
                    case 3:
                    {
                        if (!this.Trainer)
                        {
                            goto Label_012E;
                        }
                        c.TrainerList(base.Guid);
                        return;
                    }
                    case 4:
                    {
                        if (!this.Banker)
                        {
                            goto Label_012E;
                        }
                        c.EndGossip();
                        return;
                    }
                    case 5:
                    {
                        if (!this.InKeeper)
                        {
                            goto Label_012E;
                        }
                        flag1 = false;
                        Item[] itemArray1 = c.Items;
                        for (num1 = 0; num1 < itemArray1.Length; num1++)
                        {
                            Item item1 = itemArray1[num1];
                            if ((item1 != null) && (item1.Id == 0x1b24))
                            {
                                flag1 = true;
                                break;
                            }
                        }
                        break;
                    }
                    case 6:
                    {
                        if (!this.InKeeper)
                        {
                            goto Label_012E;
                        }
                        c.EndGossip();
                        return;
                    }
                    default:
                    {
                        goto Label_012E;
                    }
                }
                if (!flag1)
                {
                    Item item2 = World.CreateItemInPoolById(0x1b24);
                    if (item2 != null)
                    {
                        c.PutObjectInBackpack(item2, true);
                    }
                }
                c.BindingPointX = c.X;
                c.BindingPointY = c.Y;
                c.BindingPointZ = c.Z;
                c.BindingPointMapId = c.MapId;
                c.EndGossip();
            }
            return;
        Label_012E:
            c.ResponseMessage(this, 3, BaseNPC.Message_Hello);
        }

        private void DoQuestEvents(Character c, BaseQuest bq)
        {
            if (!c.QuestDone(bq))
            {
                qEmote[] emoteArray1;
                if (!c.QuestCompleted(bq))
                {
                    if (!c.HaveQuest(bq))
                    {
                        if (bq.HaveDeliveryObj && !this.HaveFreeSlot(c))
                        {
                            c.QuestFailed(qFailedReason.InventoryFull);
                        }
                        else if (this.AmountActiveQuests(c) >= 20)
                        {
                            c.QuestLogIsFull();
                        }
                        else
                        {
                            emoteArray1 = new qEmote[1] { new qEmote(Emote.ONESHOT_TALK, 500) } ;
                            c.ResponseQuestDetails(this, bq.Id, bq.Name, bq.Desc, bq.Details, emoteArray1);
                        }
                    }
                    else
                    {
                        c.ResponseMessage(this, this.OnlyQuests ? 3 : 1, bq.ProgressDialog);
                    }
                }
                else if (c.QuestCompleted(bq))
                {
                    emoteArray1 = new qEmote[1] { new qEmote(Emote.ONESHOT_TALK, 500) } ;
                    c.OfferReward(this, bq.Id, bq.FinishTitle, bq.FinishDialog, emoteArray1);
                }
            }
        }

        private BaseQuest[] GetQuestsFor(Character c)
        {
            ArrayList list1 = new ArrayList();
            for (int num1 = 0; num1 < this.Quests.Length; num1++)
            {
                BaseQuest quest1 = this.Quests[num1];
                if (((quest1 != null) && BaseNPC.AllowedTo(quest1, c)) && !c.QuestDone(quest1))
                {
                    if (quest1.PreviousQuest > 0)
                    {
                        BaseQuest quest2 = World.CreateQuestById(quest1.PreviousQuest);
                        if ((quest2 != null) && c.QuestDone(quest2))
                        {
                            list1.Add(quest1);
                        }
                    }
                    else
                    {
                        list1.Add(quest1);
                    }
                }
            }
            return (BaseQuest[]) list1.ToArray(typeof(BaseQuest));
        }

        private ArrayList GetStatusQuests(Character c)
        {
            ArrayList list1 = new ArrayList();
            for (int num1 = 0; num1 < 8; num1++)
            {
                list1.Add(0);
            }
            BaseQuest[] questArray1 = this.GetUnDoneQuestsFor(c);
            for (int num3 = 0; num3 < questArray1.Length; num3++)
            {
                BaseQuest quest1 = questArray1[num3];
                int num2 = (int) quest1.QuestStatus(this, c);
                list1[num2] = ((int) list1[num2]) + 1;
            }
            return list1;
        }

        private BaseQuest[] GetUnDoneQuestsFor(Character c)
        {
            ArrayList list1 = new ArrayList();
            for (int num1 = 0; num1 < this.Quests.Length; num1++)
            {
                BaseQuest quest1 = this.Quests[num1];
                if ((quest1 != null) && !c.QuestDone(quest1))
                {
                    list1.Add(quest1);
                }
            }
            return (BaseQuest[]) list1.ToArray(typeof(BaseQuest));
        }

        private bool HaveCompleatedQuestForMe(Character c)
        {
            bool flag1 = false;
            ActiveQuest[] questArray1 = c.GetActiveQuests;
            for (int num1 = 0; num1 < questArray1.Length; num1++)
            {
                ActiveQuest quest1 = questArray1[num1];
                if (((quest1 != null) && (quest1.baseQuest != null)) && (quest1.baseQuest.NPCTargetId == base.Id))
                {
                    flag1 = true;
                    break;
                }
            }
            return flag1;
        }

        public bool HaveFlag(NpcActions flag)
        {
            return ((((NpcActions) base.NpcFlags) | flag) == ((NpcActions) base.NpcFlags));
        }

        private bool HaveFreeSlot(Character c)
        {
            return (c.FindAFreeSlot() != Slots.None);
        }

        public bool HaveRewardOnHello(Character c)
        {
            bool flag1 = false;
            ActiveQuest[] questArray1 = c.GetActiveQuests;
            if (questArray1 != null)
            {
                ActiveQuest[] questArray2 = questArray1;
                for (int num1 = 0; num1 < questArray2.Length; num1++)
                {
                    ActiveQuest quest1 = questArray2[num1];
                    if ((quest1 != null) && (quest1.baseQuest != null))
                    {
                        BaseQuest quest2 = quest1.baseQuest;
                        if (quest2.HaveNPCTargetId && (quest2.NPCTargetId == base.Id))
                        {
                            qEmote[] emoteArray1 = new qEmote[1] { new qEmote(Emote.ONESHOT_TALK, 500) } ;
                            c.OfferReward(this, quest2.Id, quest2.FinishTitle, quest2.FinishDialog, emoteArray1);
                            flag1 = true;
                            break;
                        }
                    }
                }
            }
            return flag1;
        }

        public override void OnChooseQuest(Character c, int id)
        {
            BaseQuest[] questArray1 = this.Quests;
            for (int num1 = 0; num1 < questArray1.Length; num1++)
            {
                BaseQuest quest1 = questArray1[num1];
                if ((quest1 != null) && (quest1.Id == id))
                {
                    this.DoQuestEvents(c, quest1);
                    return;
                }
            }
            c.QuestFailed(qFailedReason.Failed);
        }

        public override DialogStatus OnDialogStatus(Character c)
        {
            if (this.HaveCompleatedQuestForMe(c))
            {
                return DialogStatus.SingleQuestCompleate;
            }
            ArrayList list1 = this.GetStatusQuests(c);
            for (int num1 = 6; num1 > 0; num1--)
            {
                if (((int) list1[num1]) > 0)
                {
                    return (DialogStatus) ((byte) num1);
                }
            }
            if (this.OnlyQuests)
            {
                return DialogStatus.ChatUnAvailable;
            }
            if (!this.HaveFlag(NpcActions.Dialog))
            {
                return DialogStatus.ChatUnAvailable;
            }
            return DialogStatus.ChatAvailable;
        }

        public override void OnHello(Character c)
        {
            if (this.Reputation(c) > 0.5f)
            {
                GMenu menu1 = new GMenu();
                GQMenu menu2 = new GQMenu();
                if (this.HaveQuests)
                {
                    if (this.HaveRewardOnHello(c))
                    {
                        return;
                    }
                    BaseQuest[] questArray1 = this.GetQuestsFor(c);
                    if (questArray1.Length == 1)
                    {
                        this.DoQuestEvents(c, questArray1[0]);
                        return;
                    }
                    for (int num1 = 0; num1 < questArray1.Length; num1++)
                    {
                        menu2.Add((uint) questArray1[num1].Id, questArray1[num1].QuestStatus(this, c), questArray1[num1].Name);
                    }
                    if (this.OnlyQuests)
                    {
                        if (menu2.Count > 0)
                        {
                            c.QuestList(this, "Message for only quests contain", new qEmote(Emote.ONESHOT_TALK, 500), questArray1);
                            return;
                        }
                        c.ResponseMessage(this, 3, BaseNPC.Message_Hello);
                        return;
                    }
                }
                if (this.Taxi)
                {
                    menu1.Add(1, GMenuIcons.Taxi, false, BaseNPC.Dialog_Taxi);
                }
                if (this.Vendor)
                {
                    menu1.Add(2, GMenuIcons.Vendor, false, BaseNPC.Dialog_Vendor);
                }
                if (this.Trainer)
                {
                    menu1.Add(3, GMenuIcons.Trainer, false, BaseNPC.Dialog_Teach);
                }
                if (this.Banker)
                {
                    menu1.Add(4, GMenuIcons.Banker, false, BaseNPC.Dialog_Bank);
                }
                if (this.InKeeper)
                {
                    menu1.Add(2, GMenuIcons.Vendor, false, BaseNPC.Dialog_Vendor);
                    menu1.Add(5, GMenuIcons.Binder, false, BaseNPC.Dialog_Inkeeper_Bind);
                }
                if ((menu1.Count > 0) || (menu2.Count > 0))
                {
                    c.SendGossip(this, 1, menu1, menu2);
                }
                else
                {
                    c.ResponseMessage(this, 3, BaseNPC.Message_Hello);
                }
            }
            else
            {
                c.ResponseMessage(this, 3, "Get lost skum..");
            }
        }

        public static DialogStatus QDS(Mobile questOwner, Character c, BaseQuest bq)
        {
            DialogStatus status1 = DialogStatus.ChatUnAvailable;
            if ((questOwner.Reputation(c) > bq.MinReputation) && !c.QuestDone(bq))
            {
                if (!c.HaveQuest(bq))
                {
                    if (!BaseNPC.AllowedTo(bq, c))
                    {
                        return status1;
                    }
                    if (bq.PreviousQuest > 0)
                    {
                        BaseQuest quest1 = World.CreateQuestById(bq.PreviousQuest);
                        if ((quest1 != null) && c.QuestDone(quest1))
                        {
                            status1 = DialogStatus.SingleQuestAvailable;
                        }
                        return status1;
                    }
                    return DialogStatus.SingleQuestAvailable;
                }
                ActiveQuest quest2 = c.FindPlayerQuest(bq);
                if (quest2.Completed)
                {
                    return (quest2.Repeatable ? DialogStatus.RepeatQuestCompleate : DialogStatus.SingleQuestCompleate);
                }
                if (!BaseNPC.QuestForNPC(bq, (BaseNPC) questOwner))
                {
                    status1 = DialogStatus.QuestUnCompleate;
                }
            }
            return status1;
        }

        public override string QueryNpcText(int id)
        {
            if (this._npcTextArr.ContainsKey(id))
            {
                return (this._npcTextArr[id] as NPCTextRec).GetText;
            }
            if (BaseNPC._sNpcTextArr.ContainsKey(id))
            {
                return (BaseNPC._sNpcTextArr[id] as NPCTextRec).GetText;
            }
            return "If you see this strings\n please contact with developers\n for correct Information";
        }

        public static bool QuestForNPC(BaseQuest bq, BaseNPC npc)
        {
            if (bq.HaveNPCTargetId)
            {
                return (bq.NPCTargetId == npc.Id);
            }
            return false;
        }


        // Properties
        public bool Banker
        {
            get
            {
                if (this._banker == null)
                {
                    this._banker = this.HaveFlag(NpcActions.Banker);
                }
                return (bool) this._banker;
            }
        }

        public bool HaveQuests
        {
            get
            {
                if (this._haveQuests == null)
                {
                    this._haveQuests = ((this.Quests != null) && (this.Quests.Length > 0)) && this.HaveFlag(NpcActions.Dialog);
                }
                return (bool) this._haveQuests;
            }
        }

        public bool InKeeper
        {
            get
            {
                if (this._inKeeper == null)
                {
                    this._inKeeper = this.HaveFlag(NpcActions.InKeeper);
                }
                return (bool) this._inKeeper;
            }
        }

        public bool OnlyQuests
        {
            get
            {
                if (this._onlyQuests == null)
                {
                    this._onlyQuests = (base.NpcFlags == 2) && (this.Quests.Length > 0);
                }
                return (bool) this._onlyQuests;
            }
        }

        public override BaseQuest[] Quests
        {
            get
            {
                if (base.Quests == null)
                {
                    if (NPCQuests.Status == InitStatus.None)
                    {
                        NPCQuests.Init();
                    }
                    base.Quests = NPCQuests.GetQuestsFor(base.Id);
                }
                return base.Quests;
            }
            set
            {
            }
        }

        public bool Taxi
        {
            get
            {
                if (this._taxi == null)
                {
                    this._taxi = this.HaveFlag(NpcActions.Taxi);
                }
                return (bool) this._taxi;
            }
        }

        public bool Trainer
        {
            get
            {
                if (this._trainer == null)
                {
                    this._trainer = ((base.Trains != null) && (base.Trains.Length > 0)) && this.HaveFlag(NpcActions.Trainer);
                }
                return (bool) this._trainer;
            }
        }

        public bool Vendor
        {
            get
            {
                if (this._vendor == null)
                {
                    this._vendor = (base.Sells != null) && this.HaveFlag(NpcActions.Vendor);
                }
                return (bool) this._vendor;
            }
        }


        // Fields
        private object _banker;
        private object _haveQuests;
        private object _inKeeper;
        private Hashtable _npcTextArr;
        private object _onlyQuests;
        private static Hashtable _sNpcTextArr;
        private object _taxi;
        private object _trainer;
        private object _vendor;
        public static string Dialog_Bank;
        public static string Dialog_Inkeeper_Bind;
        public static string Dialog_Inkeeper_Msg;
        public static string Dialog_Taxi;
        public static string Dialog_Teach;
        public static string Dialog_Vendor;
        public static string Message_Hello;
        public const string Version = "07.10.05";

        // Nested Types
        private class BaseQuestInit : IInitialize
        {
            // Methods
            public BaseQuestInit()
            {
            }

            public static void Initialize()
            {
                BaseQuest.onQuestStatus = new QuestDialogStatusDelegate(BaseNPC.QDS);
            }

        }
    }
}

