namespace Server.Creatures
{
    using System;

    public enum NPCMenuId
    {
        // Fields
        Hello = 3,
        MainMenu = 1,
        None = 0,
        Quests = 2
    }
}

