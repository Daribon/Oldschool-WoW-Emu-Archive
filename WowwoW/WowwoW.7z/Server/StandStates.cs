namespace Server
{
    using System;

    public enum StandStates
    {
        // Fields
        Ambient = 0x60000,
        AquaticForm = 0x40000,
        BattleStance = 0x110000,
        BearForm = 0x50000,
        BerserkerStance = 0x130000,
        CatForm = 0x10000,
        Dead = 7,
        DefensiveStance = 0x120000,
        FireBearForm = 0x80000,
        GhostWolf = 0x100000,
        Goul = 0x70000,
        Kneel = 8,
        ShadowForm = 0x1c0000,
        Sitting = 1,
        SittingChair = 2,
        SittingChairHigh = 6,
        SittingChairLow = 4,
        SittingChairMedium = 5,
        Sleeping = 3,
        Standing = 0,
        Stealth = 0x1e0000,
        TravelForm = 0x30000,
        TreeFrom = 0x20000
    }
}

