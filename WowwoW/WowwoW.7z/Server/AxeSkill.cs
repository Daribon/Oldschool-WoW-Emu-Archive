namespace Server
{
    using System;

    public class AxeSkill : Skill
    {
        // Methods
        public AxeSkill()
        {
        }

        public AxeSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x2c;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x2c;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xc4;
            }
        }

    }
}

