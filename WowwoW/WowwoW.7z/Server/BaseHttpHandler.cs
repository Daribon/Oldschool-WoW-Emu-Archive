namespace Server
{
    using System;

    public class BaseHttpHandler
    {
        // Methods
        public BaseHttpHandler()
        {
        }

        public virtual string Get()
        {
            return "";
        }

    }
}

