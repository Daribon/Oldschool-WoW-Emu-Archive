namespace Server
{
    using System;

    public class RewardArray : BaseRewardArray
    {
        // Methods
        public RewardArray() : base(4)
        {
        }

    }
}

