namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Runtime.CompilerServices;

    public class BaseCreature : Mobile
    {
        // Methods
        static BaseCreature()
        {
            BaseCreature.fakeList = new ArrayList();
            BaseCreature.probDir = new int[6, 3] {  { 5, 0, 1 } ,  { 0, 1, 2 } ,  { 1, 2, 3 } ,  { 2, 3, 4 } ,  { 3, 4, 5 } ,  { 4, 5, 0 }  } ;
            BaseCreature.NpcsCustomOnDialogStatus = new Hashtable();
            BaseCreature.NpcsCustomOnHello = new Hashtable();
            BaseCreature.NpcsCustomOnChooseQuest = new Hashtable();
            BaseCreature.NpcsCustomOnDialogCharacterSelection = new Hashtable();
            BaseCreature.NpcsCustomOnAcceptQuest = new Hashtable();
        }

        public BaseCreature()
        {
            int num1;
            this.curr = 0f;
            this.lastEtape = null;
            this.forward = true;
            this.HateList = new ArrayList();
            this.debugLast = DateTime.Now;
            this.lastDir = 0;
            base.BaseHitPoints = num1 = 1;
            base.HitPoints = num1;
            if (!World.Loading)
            {
                this.InitObjectives();
            }
            else
            {
                base.Delete();
            }
            this.peaceSpeed = base.Speed;
            if (base.RunSpeed == 0f)
            {
                base.RunSpeed = 7f;
            }
        }

        public BaseCreature(float x, float y, float z, float orient) : base(x, y, z, orient)
        {
            this.curr = 0f;
            this.lastEtape = null;
            this.forward = true;
            this.HateList = new ArrayList();
            this.debugLast = DateTime.Now;
            this.lastDir = 0;
        }

        public BaseCreature(int model, float x, float y, float z, float orient) : this(x, y, z, orient)
        {
            int num1;
            base.BaseHitPoints = num1 = 0x20;
            base.HitPoints = num1;
            base.Mana = num1 = 100;
            base.BaseMana = num1;
            this.manaType = 0;
            base.Level = 1;
            base.Str = 0;
            base.Agility = 0;
            base.Armor = 1;
            base.Iq = 0;
            base.Spirit = 0;
            base.Stamina = 0;
            base.Model = model;
        }

        public BaseCreature(float x, float y, float z, float bx, float by, float bz, float orient) : this(x, y, z, orient)
        {
            this.baseX = bx;
            this.baseY = by;
            this.baseZ = bz;
            this.X = this.baseX + (((float) Math.Sin((double) this.curr)) * 2f);
            this.Y = this.baseY + (((float) Math.Cos((double) this.curr)) * 2f);
        }

        public MapPoint ChooseDestinationPoint()
        {
            int num1 = BaseCreature.probDir[this.lastDir, Utility.Random(3)];
            MapPoint point1 = World.mapZones.Get(num1, base.ZoneId, base.MapId, this, true);
            if (point1 == null)
            {
                point1 = World.mapZones.NearestPoint(base.MapId, base.ZoneId, this.X, this.Y);
            }
            float single1 = 10f;
            if (point1 != null)
            {
                single1 = point1.x - this.X;
                float single2 = point1.y - this.Y;
                single1 *= single1;
                single2 *= single2;
                single1 += single2;
            }
            if ((point1 == null) || (single1 < 3f))
            {
                num1 = Utility.Random(6);
                point1 = World.mapZones.Get(num1, base.ZoneId, base.MapId, this, true);
            }
            this.lastDir = num1;
            return point1;
        }

        public Coord ChooseTrajet()
        {
            if (this.FreeMovement)
            {
                return null;
            }
            Trajet trajet1 = World.trajets.Find(base.SpawnerLink.TrajetGuid);
            return trajet1[0];
        }

        public override void Delete()
        {
            if (base.SpawnerLink != null)
            {
                base.SpawnerLink.Release(this);
            }
            World.Remove(this, this);
            base.Delete();
        }

        public override void Deserialize(GenericReader gr)
        {
            base.Deserialize(gr);
            gr.ReadInt();
        }

        public virtual void DialogCharacterSelection(Character c, int id, int num)
        {
            this.SpeakingFrom = DateTime.Now;
            base.AIState = AIStates.Speaking;
            if (BaseCreature.NpcsCustomOnDialogCharacterSelection[base.Id] != null)
            {
                (BaseCreature.NpcsCustomOnDialogCharacterSelection[base.Id] as OnDialogCharacterSelectionHandler)(this, c, id, num);
            }
        }

        public float Distance(Coord c)
        {
            float single1;
            float single2;
            float single3;
            this.moveVector.Get(out single1, out single2, out single3);
            float single4 = single1 - c.x;
            float single5 = single2 - c.y;
            float single6 = single3 - c.z;
            single4 *= single4;
            single5 *= single5;
            single6 *= single6;
            single4 += single5;
            return (single4 + single6);
        }

        public void Flee(Mobile m)
        {
            if (this.FreeMovement)
            {
                if (base.ReachDestination())
                {
                    float single1 = float.MinValue;
                    int num1 = 0;
                    MapPoint point1 = null;
                    for (int num2 = 0; num2 < 6; num2++)
                    {
                        MapPoint point2 = World.mapZones.Get(num2, base.ZoneId, base.MapId, this, true);
                        if (point2 != null)
                        {
                            float single2 = m.X - point2.x;
                            float single3 = m.Y - point2.y;
                            single2 *= single2;
                            single3 *= single3;
                            single2 += single3;
                            if (single2 > single1)
                            {
                                num1 = num2;
                                single1 = single2;
                                point1 = point2;
                            }
                        }
                    }
                    this.lastDir = num1;
                    if (point1 == null)
                    {
                        Console.WriteLine("Missing points at {0} {1}", this.X, this.Y);
                    }
                    else
                    {
                        base.MoveTo(point1.x, point1.y, point1.z, new Mobile.OnReachDelegate(this.OnTick));
                    }
                }
            }
            else if (this.currentTrajet == null)
            {
                this.currentTrajet = this.ChooseTrajet();
                if (this.currentTrajet != null)
                {
                    this.FleeToEtape(this.currentTrajet);
                }
            }
            else if (base.ReachDestination())
            {
                float single4 = this.currentTrajet.previous.x - m.X;
                float single5 = this.currentTrajet.previous.y - m.Y;
                float single6 = this.currentTrajet.previous.z - m.Z;
                single4 *= single4;
                single5 *= single5;
                single6 *= single6;
                float single7 = this.currentTrajet.next.x - m.X;
                float single8 = this.currentTrajet.next.y - m.Y;
                float single9 = this.currentTrajet.next.z - m.Z;
                single7 *= single7;
                single8 *= single8;
                single9 *= single9;
                float single10 = 0f;
                float single11 = 0f;
                float single12 = 0f;
                float single13 = 0f;
                float single14 = 0f;
                float single15 = 0f;
                if (this.currentTrajet is Intersection)
                {
                    Intersection intersection1 = (Intersection) this.currentTrajet;
                    single10 = intersection1.left.x - m.X;
                    single11 = intersection1.left.y - m.Y;
                    single12 = intersection1.left.z - m.Z;
                    single13 = intersection1.right.x - m.X;
                    single14 = intersection1.right.y - m.Y;
                    single15 = intersection1.right.z - m.Z;
                    single10 *= single10;
                    single13 *= single13;
                    single11 *= single11;
                    single14 *= single14;
                    single12 *= single12;
                    single15 *= single15;
                    single10 += (single11 + single12);
                    single13 += (single14 + single15);
                }
                single4 += (single5 + single6);
                single7 += (single8 + single9);
                if (((single4 >= single7) && (single4 >= single10)) && (single4 >= single13))
                {
                    this.currentTrajet = this.currentTrajet.previous;
                }
                else if (((single7 >= single4) && (single7 >= single10)) && (single4 >= single13))
                {
                    this.currentTrajet = this.currentTrajet.next;
                }
                else if (((single10 >= single4) && (single4 >= single7)) && (single4 >= single13))
                {
                    this.currentTrajet = (this.currentTrajet as Intersection).left;
                }
                else
                {
                    this.currentTrajet = (this.currentTrajet as Intersection).right;
                }
                this.FleeToEtape(this.currentTrajet);
            }
        }

        public void FleeToEtape(Coord c)
        {
            if (c.occ == this)
            {
                c.occ = null;
            }
            base.MoveTo(c.x, c.y, c.z, new Mobile.OnReachDelegate(this.OnTick));
        }

        public void FreeMove()
        {
        }

        public virtual void InitObjectives()
        {
        }

        public void InitStats()
        {
            if (base.Stamina == 0)
            {
                base.Stamina = 20 + base.Level;
            }
            if (base.Str == 0)
            {
                base.Str = 5 + (base.Level * 2);
            }
            if (base.Iq == 0)
            {
                base.Iq = 5 + base.Level;
            }
            if (base.Agility == 0)
            {
                base.Agility = 5 + base.Level;
            }
            if (base.Spirit == 0)
            {
                base.Spirit = 5 + base.Level;
            }
            if (base.BaseHitPoints < 2)
            {
                if (base.Stamina > 20)
                {
                    base.BaseHitPoints = 0x20 + ((base.Stamina - 20) * 10);
                }
                else
                {
                    base.BaseHitPoints = 0x20 + base.Stamina;
                }
            }
            base.HitPoints = base.BaseHitPoints;
            if (base.ManaType != 1)
            {
                base.Mana = base.BaseMana;
            }
            else
            {
                base.Mana = 0;
            }
            if (base.NpcType == 8)
            {
                int num1;
                base.BaseHitPoints = num1 = 1;
                base.HitPoints = num1;
            }
        }

        public bool IsFriend(Mobile m)
        {
            if (this.Reputation(m) > 0.334975f)
            {
                return true;
            }
            return false;
        }

        public bool IsHostile(Mobile m)
        {
            if (this.Reputation(m) <= 0.334975f)
            {
                return true;
            }
            return false;
        }

        public bool IsStillActive()
        {
            TimeSpan span1 = DateTime.Now.Subtract(this.lastTime);
            if (span1.TotalSeconds > 30)
            {
                return false;
            }
            return true;
        }

        public new ArrayList KnownObjects()
        {
            if (base.LastSeen == null)
            {
                return BaseCreature.fakeList;
            }
            return base.LastSeen.Player.KnownObjects;
        }

        public bool LightWound()
        {
            if (((base.HitPoints * 10) < (base.BaseHitPoints * 9)) && !this.Wounded())
            {
                return true;
            }
            return false;
        }

        public void MoveToEtape(Coord c)
        {
            if ((c.occ != null) && (c.occ.CurrentTrajet == c))
            {
                this.forward = !this.forward;
                if (this.lastEtape != null)
                {
                    this.currentTrajet = this.lastEtape;
                }
            }
            else
            {
                c.occ = this;
                if (this.lastEtape != null)
                {
                    this.lastEtape.occ = null;
                }
                base.MoveTo(c.x, c.y, c.z, new Mobile.OnReachDelegate(this.OnTick));
                this.lastEtape = this.currentTrajet;
            }
        }

        public bool NearDeath()
        {
            if (base.HitPoints < (base.BaseHitPoints / 10))
            {
                return true;
            }
            return false;
        }

        public bool NoWound()
        {
            if ((base.HitPoints * 10) > (base.BaseHitPoints * 9))
            {
                return true;
            }
            return false;
        }

        public virtual void OnAcceptQuest(Character c, int id)
        {
            this.SpeakingFrom = DateTime.Now;
            base.AIState = AIStates.Speaking;
            if (BaseCreature.NpcsCustomOnAcceptQuest[base.Id] != null)
            {
                (BaseCreature.NpcsCustomOnAcceptQuest[base.Id] as OnAcceptQuestHandler)(this, c, id);
            }
        }

        public virtual void OnAddToWorld()
        {
        }

        public virtual void OnChooseQuest(Character c, int id)
        {
            this.SpeakingFrom = DateTime.Now;
            base.AIState = AIStates.Speaking;
            if (BaseCreature.NpcsCustomOnChooseQuest[id] != null)
            {
                (BaseCreature.NpcsCustomOnChooseQuest[id] as OnChooseQuestHandler)(this, c, id);
            }
        }

        public virtual DialogStatus OnDialogStatus(Character c)
        {
            this.SpeakingFrom = DateTime.Now;
            base.AIState = AIStates.Speaking;
            if (BaseCreature.NpcsCustomOnDialogStatus[base.Id] != null)
            {
                return (BaseCreature.NpcsCustomOnDialogStatus[base.Id] as OnDialogStatusHandler)(this, c);
            }
            return DialogStatus.ChatUnAvailable;
        }

        public override void OnGetHit(Mobile by, bool sp, int damageAmount)
        {
            base.Running = true;
            base.OnGetHit(by, sp, damageAmount);
            if (this.aiEngine != null)
            {
                base.AIState = this.aiEngine.OnGetHit(by, base.AIState, damageAmount);
                if (base.AttackTarget == null)
                {
                    base.AttackTarget = by;
                }
                this.OnTick();
            }
            else
            {
                base.Running = true;
                if (base.AttackTarget == null)
                {
                    base.AttackTarget = by;
                }
                switch (base.AIState)
                {
                    case AIStates.Attack:
                    case AIStates.BeingAttacked:
                    case AIStates.Fighting:
                    {
                        return;
                    }
                }
                base.AIState = AIStates.BeingAttacked;
            }
        }

        public virtual void OnGossipHello(Character c)
        {
            this.SpeakingFrom = DateTime.Now;
            base.AIState = AIStates.Speaking;
        }

        public virtual void OnHello(Character c)
        {
            this.SpeakingFrom = DateTime.Now;
            base.AIState = AIStates.Speaking;
            if (BaseCreature.NpcsCustomOnHello[base.Id] != null)
            {
                (BaseCreature.NpcsCustomOnHello[base.Id] as OnHelloHandler)(this, c);
            }
        }

        public override void OnMovementHeartBeat()
        {
            if (base.LastSeen == null)
            {
                return;
            }
            if ((base.AIState == AIStates.Fighting) || ((base.AIState >= AIStates.Pause1) && (base.AIState <= AIStates.Pause9)))
            {
                return;
            }
            if (this.FreeMovement)
            {
                if (base.ReachDestination())
                {
                    MapPoint point1 = this.ChooseDestinationPoint();
                    if (point1 == null)
                    {
                        return;
                    }
                    base.MoveTo(point1.x, point1.y, point1.z, new Mobile.OnReachDelegate(this.OnTick));
                }
                return;
            }
            if (this.currentTrajet == null)
            {
                this.currentTrajet = this.ChooseTrajet();
                if (this.currentTrajet != null)
                {
                    this.MoveToEtape(this.currentTrajet);
                }
                return;
            }
            if (!base.ReachDestination())
            {
                return;
            }
            if (this.currentTrajet is Intersection)
            {
                Intersection intersection1 = this.currentTrajet as Intersection;
                switch (Utility.Random4())
                {
                    case 0:
                    {
                        this.currentTrajet = intersection1.right;
                        this.forward = true;
                        goto Label_0192;
                    }
                    case 1:
                    {
                        this.currentTrajet = intersection1.left;
                        this.forward = false;
                        goto Label_0192;
                    }
                    case 2:
                    {
                        this.currentTrajet = intersection1.next;
                        this.forward = true;
                        goto Label_0192;
                    }
                    case 3:
                    {
                        this.currentTrajet = intersection1.previous;
                        this.forward = false;
                        goto Label_0192;
                    }
                }
            }
            else if (this.forward)
            {
                if (this.currentTrajet.next == null)
                {
                    this.forward = false;
                }
                else
                {
                    this.currentTrajet = this.currentTrajet.next;
                }
            }
            else if (this.currentTrajet.previous == null)
            {
                this.forward = true;
            }
            else
            {
                this.currentTrajet = this.currentTrajet.previous;
            }
        Label_0192:
            this.MoveToEtape(this.currentTrajet);
        }

        public override void OnTick()
        {
            if (!this.IsStillActive())
            {
                base.HitPoints = base.BaseHitPoints;
                base.Mana = base.BaseMana;
                base.LastSeen = null;
                this.Delete();
                return;
            }
            if (this.DebugSniffer != null)
            {
                TimeSpan span1 = DateTime.Now.Subtract(this.debugLast);
                this.DebugSniffer.SendMessage("BaseCreature::OnTick " + span1.TotalMilliseconds.ToString());
                this.debugLast = DateTime.Now;
            }
            if (base.Deleted)
            {
                return;
            }
            if (base.Dead)
            {
                return;
            }
            if (base.Freeze)
            {
                return;
            }
            base.UpdateXYZ();
            if ((base.ForceFlee || base.ForceStun) || (base.ForceRoot || (this.aiEngine == null)))
            {
                goto Label_0331;
            }
            if ((base.SpawnerLink != null) && this.aiEngine.CustomBehaviours.Contains(CustomBehavioursTypes.Stay))
            {
                switch (base.AIState)
                {
                    case AIStates.Explore:
                    case AIStates.Attack:
                    case AIStates.BeingAttacked:
                    case AIStates.Fighting:
                    case AIStates.Flee:
                    {
                        goto Label_023D;
                    }
                }
                base.UpdateXYZ();
                if (base.Distance(base.SpawnerLink) > 5f)
                {
                    base.AIState = AIStates.ReturnHome;
                    if (Math.Abs((float) (this.Z - base.SpawnerLink.Z)) > 3f)
                    {
                        base.MoveTo(this.X + ((base.SpawnerLink.X - this.X) / 2f), this.Y + ((base.SpawnerLink.Y - this.Y) / 2f), this.Z + ((base.SpawnerLink.Z - this.Z) / 2f));
                    }
                    else
                    {
                        base.MoveTo(base.SpawnerLink.X, base.SpawnerLink.Y, base.SpawnerLink.Z);
                    }
                }
                else
                {
                    if (Math.Abs((float) (this.Z - base.SpawnerLink.Z)) > 1f)
                    {
                        base.InstantMoveTo(base.SpawnerLink.X, base.SpawnerLink.Y, base.SpawnerLink.Z);
                    }
                    base.AIState = AIStates.Pause1;
                }
            }
        Label_023D:
            if ((base.SpawnerLink != null) && this.aiEngine.CustomBehaviours.Contains(CustomBehavioursTypes.KeepOrientation))
            {
                switch (base.AIState)
                {
                    case AIStates.Explore:
                    case AIStates.Attack:
                    case AIStates.BeingAttacked:
                    case AIStates.Fighting:
                    case AIStates.Flee:
                    case AIStates.ReturnHome:
                    {
                        goto Label_0326;
                    }
                }
                if (Math.Abs((float) (base.Orientation - base.SpawnerLink.Orientation)) > 0.1)
                {
                    base.UpdateXYZ();
                    float single1 = this.X + (((float) Math.Cos((double) base.SpawnerLink.Orientation)) / 2f);
                    float single2 = this.Y + (((float) Math.Sin((double) base.SpawnerLink.Orientation)) / 2f);
                    base.MoveTo(single1, single2, this.Z);
                    base.Orientation = base.SpawnerLink.Orientation;
                }
            }
        Label_0326:
            this.aiEngine.OnTick();
        Label_0331:
            this.Regeneration();
            if (base.ForceFlee)
            {
                base.AIState = AIStates.Flee;
            }
            if (base.ForceStun)
            {
                base.AIState = AIStates.Pause1;
            }
            switch (base.AIState)
            {
                case AIStates.Explore:
                case AIStates.LookingForPrey:
                {
                    this.OnMovementHeartBeat();
                    break;
                }
                case AIStates.BeingAttacked:
                {
                    if ((base.AttackTarget == null) || (base.AttackTarget.HitPoints <= 0))
                    {
                        base.AIState = AIStates.DoingNothing;
                        break;
                    }
                    base.AIState = AIStates.Fighting;
                    base.BeginCombatWith(base.AttackTarget);
                    break;
                }
                case AIStates.Flee:
                {
                    if (base.ForceFlee || (base.Distance(base.AttackTarget) <= 1600f))
                    {
                        base.Running = true;
                        this.Flee(base.AttackTarget);
                        break;
                    }
                    base.Running = false;
                    base.AIState = AIStates.Explore;
                    base.AttackTarget = null;
                    break;
                }
            }
            if (this.DebugSniffer != null)
            {
                this.DebugSniffer.SendMessage("BaseCreature::OnTick::FinalAIState = " + base.AIState);
            }
        }

        public virtual string QueryNpcText(int id)
        {
            this.SpeakingFrom = DateTime.Now;
            base.AIState = AIStates.Speaking;
            return " ";
        }

        public override void Serialize(GenericWriter gw)
        {
            base.Serialize(gw);
            gw.Write(0);
        }

        public bool SeriouslyDeath()
        {
            if ((base.HitPoints < (base.BaseHitPoints / 5)) && !this.NearDeath())
            {
                return true;
            }
            return false;
        }

        public void StillActive(Character from)
        {
            this.lastTime = DateTime.Now;
            if (base.SpawnerLink != null)
            {
                base.SpawnerLink.StillActive(from, true);
            }
            base.LastSeen = from;
        }

        public bool Wounded()
        {
            if ((base.HitPoints < (base.BaseHitPoints / 2)) && !this.SeriouslyDeath())
            {
                return true;
            }
            return false;
        }


        // Properties
        public BaseAIType AIEngine
        {
            get
            {
                return this.aiEngine;
            }
            set
            {
                this.aiEngine = value;
            }
        }

        public AITypes AIType
        {
            get
            {
                return this.aiEngine.AIType;
            }
        }

        public Coord CurrentTrajet
        {
            get
            {
                return this.currentTrajet;
            }
        }

        private bool FreeMovement
        {
            get
            {
                if ((base.SpawnerLink != null) && (base.SpawnerLink.TrajetGuid > 0))
                {
                    return false;
                }
                return true;
            }
        }

        public int Gender
        {
            get
            {
                return this.gender;
            }
            set
            {
                this.gender = value;
            }
        }

        public string NpcText00
        {
            get
            {
                return this.npcText00;
            }
            set
            {
                this.npcText00 = value;
            }
        }

        public string NpcText01
        {
            get
            {
                return this.npcText01;
            }
            set
            {
                this.npcText01 = value;
            }
        }

        public virtual BaseQuest[] Quests
        {
            get
            {
                return this.quests;
            }
            set
            {
                this.quests = value;
            }
        }

        public DateTime SpeakingFrom
        {
            get
            {
                return this.speakingFrom;
            }
            set
            {
                this.speakingFrom = value;
            }
        }


        // Fields
        private BaseAIType aiEngine;
        public AIStances AIStance;
        private float baseX;
        private float baseY;
        private float baseZ;
        public float curr;
        private Coord currentTrajet;
        private DateTime debugLast;
        public Character DebugSniffer;
        private static ArrayList fakeList;
        private bool forward;
        private int gender;
        public ArrayList HateList;
        private int lastDir;
        private Coord lastEtape;
        private DateTime lastTime;
        public int npcMenuId;
        public static Hashtable NpcsCustomOnAcceptQuest;
        public static Hashtable NpcsCustomOnChooseQuest;
        public static Hashtable NpcsCustomOnDialogCharacterSelection;
        public static Hashtable NpcsCustomOnDialogStatus;
        public static Hashtable NpcsCustomOnHello;
        private string npcText00;
        private string npcText01;
        private float peaceSpeed;
        private static int[,] probDir;
        private BaseQuest[] quests;
        private DateTime speakingFrom;

        // Nested Types
        public delegate void OnAcceptQuestHandler(Mobile from, Character c, int id);


        public delegate void OnChooseQuestHandler(Mobile from, Character c, int id);


        public delegate void OnDialogCharacterSelectionHandler(Mobile from, Character c, int id, int num);


        public delegate DialogStatus OnDialogStatusHandler(Mobile from, Character c);


        public delegate void OnHelloHandler(Mobile from, Character c);

    }
}

