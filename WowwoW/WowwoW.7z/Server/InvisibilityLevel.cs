namespace Server
{
    using System;

    public enum InvisibilityLevel
    {
        // Fields
        GM = 4,
        Greater = 3,
        Lesser = 1,
        Medium = 2,
        True = 5,
        Visible = 0
    }
}

