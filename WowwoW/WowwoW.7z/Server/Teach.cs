namespace Server
{
    using System;

    public class Teach : BaseAbility
    {
        // Methods
        public Teach(int _teach, ushort _id, int _cost, int _classe) : base(_id, 0x7d0)
        {
            this.teach = _teach;
            this.buyPrice = _cost;
        }


        // Properties
        public int BuyPrice
        {
            get
            {
                return this.buyPrice;
            }
        }

        public int TeachId
        {
            get
            {
                return this.teach;
            }
        }


        // Fields
        private int buyPrice;
        private int teach;
    }
}

