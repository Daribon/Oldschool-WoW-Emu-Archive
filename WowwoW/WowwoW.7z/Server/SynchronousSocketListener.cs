namespace Server
{
    using System;
    using System.Net;
    using System.Net.Sockets;

    public class SynchronousSocketListener
    {
        // Methods
        public SynchronousSocketListener(int nThread, int port, string handle)
        {
            this.portNum = 0x2784;
            this.stop = false;
            this.handler = handle;
            this.numOfThread = nThread;
            this.portNum = port;
        }

        public void StartListening()
        {
            ClientConnectionPool pool1 = new ClientConnectionPool();
            this.ClientTask = new ClientService(pool1, this.numOfThread);
            this.ClientTask.Start();
            TcpListener listener1 = null;
            listener1 = new TcpListener(IPAddress.Any, this.portNum);
            try
            {
                listener1.Start();
                int num1 = 0;
                Console.WriteLine("Port {0} waiting for a connection...", this.portNum);
                while (!this.stop)
                {
                    TcpClientBis bis1 = new TcpClientBis(listener1.AcceptSocket());
                    if (bis1 == null)
                    {
                        break;
                    }
                    if (bis1.ReceiveBufferSize == 0)
                    {
                        Console.WriteLine("Socket error !");
                        bis1.Close();
                    }
                    num1++;
                    pool1.Enqueue(new ClientHandler(bis1, num1 - 1, this.handler));
                }
                listener1.Stop();
                this.ClientTask.Stop();
            }
            catch (Exception exception1)
            {
                Console.WriteLine(exception1.ToString());
            }
        }

        public void Stop()
        {
            this.stop = true;
            this.ClientTask.Stop();
        }


        // Fields
        public ClientService ClientTask;
        private string handler;
        private int numOfThread;
        private int portNum;
        private bool stop;
    }
}

