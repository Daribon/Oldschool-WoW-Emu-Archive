namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.IO;
    using System.Reflection;
    using System.Text;

    public class Docs
    {
        // Methods
        static Docs()
        {
            string[,] textArray1 = new string[0x10, 2];
            textArray1[0, 0] = "System.Object";
            textArray1[0, 1] = "<font color=\"blue\">object</font>";
            textArray1[1, 0] = "System.String";
            textArray1[1, 1] = "<font color=\"blue\">string</font>";
            textArray1[2, 0] = "System.Boolean";
            textArray1[2, 1] = "<font color=\"blue\">bool</font>";
            textArray1[3, 0] = "System.Byte";
            textArray1[3, 1] = "<font color=\"blue\">byte</font>";
            textArray1[4, 0] = "System.SByte";
            textArray1[4, 1] = "<font color=\"blue\">sbyte</font>";
            textArray1[5, 0] = "System.Int16";
            textArray1[5, 1] = "<font color=\"blue\">short</font>";
            textArray1[6, 0] = "System.UInt16";
            textArray1[6, 1] = "<font color=\"blue\">ushort</font>";
            textArray1[7, 0] = "System.Int32";
            textArray1[7, 1] = "<font color=\"blue\">int</font>";
            textArray1[8, 0] = "System.UInt32";
            textArray1[8, 1] = "<font color=\"blue\">uint</font>";
            textArray1[9, 0] = "System.Int64";
            textArray1[9, 1] = "<font color=\"blue\">long</font>";
            textArray1[10, 0] = "System.UInt64";
            textArray1[10, 1] = "<font color=\"blue\">ulong</font>";
            textArray1[11, 0] = "System.Single";
            textArray1[11, 1] = "<font color=\"blue\">float</font>";
            textArray1[12, 0] = "System.Double";
            textArray1[12, 1] = "<font color=\"blue\">double</font>";
            textArray1[13, 0] = "System.Decimal";
            textArray1[13, 1] = "<font color=\"blue\">decimal</font>";
            textArray1[14, 0] = "System.Char";
            textArray1[14, 1] = "<font color=\"blue\">char</font>";
            textArray1[15, 0] = "System.Void";
            textArray1[15, 1] = "<font color=\"blue\">void</font>";
            Docs.m_Aliases = textArray1;
            Docs.m_RootDirectory = Path.GetDirectoryName(Environment.GetCommandLineArgs()[0]);
            Docs.m_AliasLength = Docs.m_Aliases.GetLength(0);
        }

        public Docs()
        {
        }

        private static void AddIndexLink(StreamWriter html, string filePath, string label, string desc)
        {
            html.WriteLine("      <h2><a href=\"{0}\" title=\"{1}\">{2}</a></h2>", filePath, desc, label);
        }

        private static void DeleteDirectory(string path)
        {
            path = Path.Combine(Docs.m_RootDirectory, path);
            if (Directory.Exists(path))
            {
                Directory.Delete(path, true);
            }
        }

        public static void Document()
        {
            Docs.DeleteDirectory("docs/");
            Docs.EnsureDirectory("docs/");
            Docs.EnsureDirectory("docs/namespaces/");
            Docs.EnsureDirectory("docs/types/");
            Docs.GenerateStyles();
            Docs.GenerateIndex();
            Docs.m_Types = new Hashtable();
            Docs.m_Namespaces = new Hashtable();
            ArrayList list1 = new ArrayList();
            list1.Add(Utility.externAsm);
            list1.Add(Assembly.GetAssembly(typeof(Mobile)));
            Assembly[] assemblyArray1 = (Assembly[]) list1.ToArray(typeof(Assembly));
            for (int num1 = 0; num1 < assemblyArray1.Length; num1++)
            {
                Docs.LoadTypes(assemblyArray1[num1], assemblyArray1);
            }
            Docs.DocumentLoadedTypes();
        }

        private static void DocumentLoadedTypes()
        {
            using (StreamWriter writer1 = Docs.GetWriter("docs/", "overview.html"))
            {
                writer1.WriteLine("<html>");
                writer1.WriteLine("   <head>");
                writer1.WriteLine("      <title>WowwoW {0} Documentation - Class Overview</title>", World.Version);
                writer1.WriteLine("   </head>");
                writer1.WriteLine("   <body bgcolor=\"white\" style=\"font-family: Courier New\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#808080\">");
                writer1.WriteLine("      <h4><a href=\"index.html\">Back to the index</a></h4>");
                writer1.WriteLine("      <h2>Namespaces</h2>");
                ArrayList list1 = new ArrayList(Docs.m_Namespaces);
                list1.Sort(new NamespaceComparer());
                for (int num1 = 0; num1 < list1.Count; num1++)
                {
                    DictionaryEntry entry1 = (DictionaryEntry) list1[num1];
                    string text1 = (string) entry1.Key;
                    ArrayList list2 = (ArrayList) entry1.Value;
                    list2.Sort(new TypeComparer());
                    Docs.SaveNamespace(text1, list2, writer1);
                }
                writer1.WriteLine("   </body>");
                writer1.WriteLine("</html>");
            }
        }

        private static void EnsureDirectory(string path)
        {
            path = Path.Combine(Docs.m_RootDirectory, path);
            if (!Directory.Exists(path))
            {
                Directory.CreateDirectory(path);
            }
        }

        private static void GenerateIndex()
        {
            using (StreamWriter writer1 = Docs.GetWriter("docs/", "index.html"))
            {
                writer1.WriteLine("<html>");
                writer1.WriteLine("   <head>");
                writer1.WriteLine("      <title>WowwoW {0} Documentation - Index</title>", World.Version);
                writer1.WriteLine("      <link rel=\"stylesheet\" type=\"text/css\" href=\"styles.css\" />");
                writer1.WriteLine("   </head>");
                writer1.WriteLine("   <body>");
                Docs.AddIndexLink(writer1, "overview.html", "Class Overview", "Scripting reference. Contains every class type and contained methods in the core and scripts.");
                writer1.WriteLine("   </body>");
                writer1.WriteLine("</html>");
            }
        }

        private static void GenerateStyles()
        {
            using (StreamWriter writer1 = Docs.GetWriter("docs/", "styles.css"))
            {
                writer1.WriteLine("body { background-color: #FFFFFF; font-family: verdana, arial; font-size: 11px; }");
                writer1.WriteLine("a { color: #28435E; }");
                writer1.WriteLine("a:hover { color: #4878A9; }");
                writer1.WriteLine("td.header { background-color: #9696AA; font-weight: bold; font-size: 12px; }");
                writer1.WriteLine("td.lentry { background-color: #D7D7EB; width: 10%; }");
                writer1.WriteLine("td.rentry { background-color: #FFFFFF; width: 90%; }");
                writer1.WriteLine("td.entry { background-color: #FFFFFF; }");
                writer1.WriteLine("td { font-size: 11px; }");
                writer1.WriteLine(".tbl-border { background-color: #46465A; }");
            }
        }

        public static string GetFileName(string root, string name, string ext)
        {
            int num1 = 0;
            string text1 = name + ext;
            while (File.Exists(Path.Combine(root, text1)))
            {
                text1 = name + ++num1 + ext;
            }
            return text1;
        }

        public static string GetPair(Type varType, string name, bool ignoreRef)
        {
            string text1 = "";
            StringBuilder builder1 = new StringBuilder();
            Type type1 = varType;
            if (varType.IsByRef)
            {
                if (!ignoreRef)
                {
                    text1 = "<font color=\"blue\">ref</font> ";
                }
                type1 = varType.GetElementType();
            }
            if (type1.IsPointer)
            {
                if (type1.IsArray)
                {
                    builder1.Append('*');
                    do
                    {
                        builder1.Append('[');
                        for (int num1 = 1; num1 < type1.GetArrayRank(); num1++)
                        {
                            builder1.Append(',');
                        }
                        builder1.Append(']');
                        type1 = type1.GetElementType();
                    }
                    while (type1.IsArray);
                    builder1.Append(' ');
                }
                else
                {
                    type1 = type1.GetElementType();
                    builder1.Append(" *");
                }
            }
            else if (type1.IsArray)
            {
                do
                {
                    builder1.Append('[');
                    for (int num2 = 1; num2 < type1.GetArrayRank(); num2++)
                    {
                        builder1.Append(',');
                    }
                    builder1.Append(']');
                    type1 = type1.GetElementType();
                }
                while (type1.IsArray);
                builder1.Append(' ');
            }
            else
            {
                builder1.Append(' ');
            }
            string text2 = type1.FullName;
            string text3 = null;
            TypeInfo info1 = (TypeInfo) Docs.m_Types[type1];
            if (info1 != null)
            {
                text3 = string.Format("<a href=\"{0}\">{1}</a>", info1.m_FileName, info1.m_TypeName);
            }
            else
            {
                for (int num3 = 0; num3 < Docs.m_AliasLength; num3++)
                {
                    if (Docs.m_Aliases[num3, 0] == text2)
                    {
                        text3 = Docs.m_Aliases[num3, 1];
                        break;
                    }
                }
                if (text3 == null)
                {
                    text3 = type1.Name;
                }
            }
            object[] objArray1 = new object[4] { text1, text3, builder1, name } ;
            return string.Concat(objArray1);
        }

        private static StreamWriter GetWriter(string path)
        {
            return new StreamWriter(Path.Combine(Docs.m_RootDirectory, path));
        }

        private static StreamWriter GetWriter(string root, string name)
        {
            return new StreamWriter(Path.Combine(Path.Combine(Docs.m_RootDirectory, root), name));
        }

        private static bool InAssemblies(Type t, Assembly[] asms)
        {
            Assembly assembly1 = t.Assembly;
            for (int num1 = 0; num1 < asms.Length; num1++)
            {
                if (assembly1 == asms[num1])
                {
                    return true;
                }
            }
            return false;
        }

        private static void LoadTypes(Assembly a, Assembly[] asms)
        {
            Type[] typeArray1 = a.GetTypes();
            for (int num1 = 0; num1 < typeArray1.Length; num1++)
            {
                Type type1 = typeArray1[num1];
                string text1 = type1.Namespace;
                if ((text1 != null) && ((text1.StartsWith("Server") || text1.StartsWith("Utility")) || text1.StartsWith("HelperTools")))
                {
                    string text2 = type1.Name;
                    if ((((((!text2.StartsWith("TcpIPSocketClient") && !text2.StartsWith("Trajet")) && (!text2.StartsWith("TcpClientBis") && !text2.StartsWith("SocketClient"))) && ((!text2.StartsWith("ServerGroup") && !text2.StartsWith("ServerGroupHandler")) && (!text2.StartsWith("ServerGroupMessageType") && !text2.StartsWith("PlayerHandler")))) && (((!text2.StartsWith("NetWork") && !text2.StartsWith("ISocket")) && (!text2.StartsWith("GameServer") && !text2.StartsWith("Data"))) && ((!text2.StartsWith("ClientConnection") && !text2.StartsWith("ClientConnectionPool")) && (!text2.StartsWith("ClientHandler") && !text2.StartsWith("ClientService"))))) && ((((!text2.StartsWith("ClientConnection") && !text2.StartsWith("Coord")) && (!text2.StartsWith("Docs") && !text2.StartsWith("MainConsole"))) && ((!text2.StartsWith("Packet") && !text2.StartsWith("Base64Decoder")) && (!text2.StartsWith("Base64Encoder") && !text2.StartsWith("ByteArray")))) && (((!text2.StartsWith("ByteArrayBase") && !text2.StartsWith("ByteArrayBuilder")) && (!text2.StartsWith("Converter") && !text2.StartsWith("HexViewer"))) && ((!text2.StartsWith("Logs") && !text2.StartsWith("RandomList")) && (!text2.StartsWith("Zip") && !text2.StartsWith("ClientConnectionPool")))))) && ((text1 != null) && !type1.IsSpecialName))
                    {
                        TypeInfo info1 = new TypeInfo(type1);
                        Docs.m_Types[type1] = info1;
                        ArrayList list1 = (ArrayList) Docs.m_Namespaces[text1];
                        if (list1 == null)
                        {
                            Docs.m_Namespaces[text1] = list1 = new ArrayList();
                        }
                        list1.Add(info1);
                        Type type2 = info1.m_BaseType;
                        if ((type2 != null) && Docs.InAssemblies(type2, asms))
                        {
                            TypeInfo info2 = (TypeInfo) Docs.m_Types[type2];
                            if (info2 == null)
                            {
                                Docs.m_Types[type2] = info2 = new TypeInfo(type2);
                            }
                            if (info2.m_Derived == null)
                            {
                                info2.m_Derived = new ArrayList();
                            }
                            info2.m_Derived.Add(info1);
                        }
                        Type type3 = info1.m_Declaring;
                        if (type3 != null)
                        {
                            TypeInfo info3 = (TypeInfo) Docs.m_Types[type3];
                            if (info3 == null)
                            {
                                Docs.m_Types[type3] = info3 = new TypeInfo(type3);
                            }
                            if (info3.m_Nested == null)
                            {
                                info3.m_Nested = new ArrayList();
                            }
                            info3.m_Nested.Add(info1);
                        }
                        for (int num2 = 0; num2 < info1.m_Interfaces.Length; num2++)
                        {
                            Type type4 = info1.m_Interfaces[num2];
                            if (Docs.InAssemblies(type4, asms))
                            {
                                TypeInfo info4 = (TypeInfo) Docs.m_Types[type4];
                                if (info4 == null)
                                {
                                    Docs.m_Types[type4] = info4 = new TypeInfo(type4);
                                }
                                if (info4.m_Derived == null)
                                {
                                    info4.m_Derived = new ArrayList();
                                }
                                info4.m_Derived.Add(info1);
                            }
                        }
                    }
                }
            }
        }

        private static void SaveNamespace(string name, ArrayList types, StreamWriter indexHtml)
        {
            string text1 = Docs.GetFileName("docs/namespaces/", name, ".html");
            indexHtml.WriteLine("      <a href=\"namespaces/{0}\">{1}</a><br>", text1, name);
            using (StreamWriter writer1 = Docs.GetWriter("docs/namespaces/", text1))
            {
                writer1.WriteLine("<html>");
                writer1.WriteLine("   <head>");
                writer1.WriteLine("      <title>WowwoW {0} Documentation - Class Overview - {1}</title>", World.Version, name);
                writer1.WriteLine("   </head>");
                writer1.WriteLine("   <body bgcolor=\"white\" style=\"font-family: Courier New\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#808080\">");
                writer1.WriteLine("      <h4><a href=\"../overview.html\">Back to the namespace index</a></h4>");
                writer1.WriteLine("      <h2>{0}</h2>", name);
                for (int num1 = 0; num1 < types.Count; num1++)
                {
                    Docs.SaveType((TypeInfo) types[num1], writer1, text1, name);
                }
                writer1.WriteLine("   </body>");
                writer1.WriteLine("</html>");
            }
        }

        private static void SaveType(TypeInfo info, StreamWriter nsHtml, string nsFileName, string nsName)
        {
            if (info.m_Declaring == null)
            {
                nsHtml.WriteLine("      <a href=\"../types/{0}\">{1}<br>", info.m_FileName, info.m_TypeName);
            }
            using (StreamWriter writer1 = info.m_Writer)
            {
                writer1.WriteLine("<html>");
                writer1.WriteLine("   <head>");
                writer1.WriteLine("      <title>WowwoW {0} Documentation - Class Overview - {1}</title>", World.Version, info.m_TypeName);
                writer1.WriteLine("   </head>");
                writer1.WriteLine("   <body bgcolor=\"white\" style=\"font-family: Courier New\" text=\"#000000\" link=\"#000000\" vlink=\"#000000\" alink=\"#808080\">");
                writer1.WriteLine("      <h4><a href=\"../namespaces/{0}\">Back to {1}</a></h4>", nsFileName, nsName);
                if (info.m_Type.IsEnum)
                {
                    Docs.WriteEnum(info, writer1);
                }
                else
                {
                    Docs.WriteType(info, writer1);
                }
                writer1.WriteLine("   </body>");
                writer1.WriteLine("</html>");
            }
        }

        private static void WriteCtor(string name, ConstructorInfo ctor, StreamWriter html)
        {
            if (!ctor.IsStatic)
            {
                html.Write("      ");
                html.Write("(<font color=\"blue\">ctor</font>) ");
                html.Write(name);
                html.Write('(');
                ParameterInfo[] infoArray1 = ctor.GetParameters();
                if (infoArray1.Length > 0)
                {
                    html.Write(' ');
                    for (int num1 = 0; num1 < infoArray1.Length; num1++)
                    {
                        ParameterInfo info1 = infoArray1[num1];
                        if (num1 != 0)
                        {
                            html.Write(", ");
                        }
                        if (info1.IsIn)
                        {
                            html.Write("<font color=\"blue\">in</font> ");
                        }
                        else if (info1.IsOut)
                        {
                            html.Write("<font color=\"blue\">out</font> ");
                        }
                        html.Write(Docs.GetPair(info1.ParameterType, info1.Name, info1.IsOut));
                    }
                    html.Write(' ');
                }
                html.WriteLine(")<br>");
            }
        }

        private static void WriteEnum(TypeInfo info, StreamWriter typeHtml)
        {
            string text1;
            Type type1 = info.m_Type;
            typeHtml.WriteLine("      <h2>{0} (Enum)</h2>", info.m_TypeName);
            string[] textArray1 = Enum.GetNames(type1);
            if (type1.IsDefined(typeof(FlagsAttribute), false))
            {
                text1 = "      {0:G} = 0x{1:X}{2}<br>";
            }
            else
            {
                text1 = "      {0:G} = {1:D}{2}<br>";
            }
            for (int num1 = 0; num1 < textArray1.Length; num1++)
            {
                object obj1 = Enum.Parse(type1, textArray1[num1]);
                typeHtml.WriteLine(text1, textArray1[num1], obj1, (num1 < (textArray1.Length - 1)) ? "," : "");
            }
        }

        private static void WriteMethod(MethodInfo mi, StreamWriter html)
        {
            if (!mi.IsSpecialName)
            {
                html.Write("      ");
                if (mi.IsStatic)
                {
                    html.Write("(<font color=\"blue\">static</font>) ");
                }
                if (mi.IsVirtual)
                {
                    html.Write("<font color=\"blue\">virtual</font> ");
                }
                html.Write(Docs.GetPair(mi.ReturnType, mi.Name, false));
                html.Write('(');
                ParameterInfo[] infoArray1 = mi.GetParameters();
                if (infoArray1.Length > 0)
                {
                    html.Write(' ');
                    for (int num1 = 0; num1 < infoArray1.Length; num1++)
                    {
                        ParameterInfo info1 = infoArray1[num1];
                        if (num1 != 0)
                        {
                            html.Write(", ");
                        }
                        if (info1.IsIn)
                        {
                            html.Write("<font color=\"blue\">in</font> ");
                        }
                        else if (info1.IsOut)
                        {
                            html.Write("<font color=\"blue\">out</font> ");
                        }
                        html.Write(Docs.GetPair(info1.ParameterType, info1.Name, info1.IsOut));
                    }
                    html.Write(' ');
                }
                html.WriteLine(")<br>");
            }
        }

        private static void WriteProperty(PropertyInfo pi, StreamWriter html)
        {
            html.Write("      ");
            MethodInfo info1 = pi.GetGetMethod();
            MethodInfo info2 = pi.GetSetMethod();
            if (((info1 != null) && info1.IsStatic) || ((info2 != null) && info2.IsStatic))
            {
                html.Write("(<font color=\"blue\">static</font>) ");
            }
            html.Write(Docs.GetPair(pi.PropertyType, pi.Name, false));
            html.Write('(');
            if (pi.CanRead)
            {
                html.Write(" <font color=\"blue\">get</font>;");
            }
            if (pi.CanWrite)
            {
                html.Write(" <font color=\"blue\">set</font>;");
            }
            html.WriteLine(" )<br>");
        }

        private static void WriteType(TypeInfo info, StreamWriter typeHtml)
        {
            Type type1 = info.m_Type;
            typeHtml.Write("      <h2>");
            Type type2 = info.m_Declaring;
            if (type2 != null)
            {
                typeHtml.Write('(');
                TypeInfo info1 = (TypeInfo) Docs.m_Types[type2];
                if (info1 == null)
                {
                    typeHtml.Write(type2.Name);
                }
                else
                {
                    typeHtml.Write("<a href=\"{0}\">{1}</a>", info1.m_FileName, info1.m_TypeName);
                }
                typeHtml.Write(") - ");
            }
            typeHtml.Write(info.m_TypeName);
            Type[] typeArray1 = info.m_Interfaces;
            Type type3 = info.m_BaseType;
            int num1 = 0;
            if (((type3 != null) && (type3 != typeof(object))) && ((type3 != typeof(ValueType)) && !type3.IsPrimitive))
            {
                typeHtml.Write(" : ");
                TypeInfo info2 = (TypeInfo) Docs.m_Types[type3];
                if (info2 == null)
                {
                    typeHtml.Write(type3.Name);
                }
                else
                {
                    typeHtml.Write("<a href=\"{0}\">{1}</a>", info2.m_FileName, info2.m_TypeName);
                }
                num1++;
            }
            if (typeArray1.Length > 0)
            {
                if (num1 == 0)
                {
                    typeHtml.Write(" : ");
                }
                for (int num2 = 0; num2 < typeArray1.Length; num2++)
                {
                    Type type4 = typeArray1[num2];
                    TypeInfo info3 = (TypeInfo) Docs.m_Types[type4];
                    if (num1 != 0)
                    {
                        typeHtml.Write(", ");
                    }
                    num1++;
                    if (info3 == null)
                    {
                        typeHtml.Write(type4.Name);
                    }
                    else
                    {
                        typeHtml.Write("<a href=\"{0}\">{1}</a>", info3.m_FileName, info3.m_TypeName);
                    }
                }
            }
            typeHtml.WriteLine("</h2>");
            ArrayList list1 = info.m_Derived;
            if (list1 != null)
            {
                typeHtml.Write("<h4>Derived Types: ");
                list1.Sort(new TypeComparer());
                for (int num3 = 0; num3 < list1.Count; num3++)
                {
                    TypeInfo info4 = (TypeInfo) list1[num3];
                    if (num3 != 0)
                    {
                        typeHtml.Write(", ");
                    }
                    typeHtml.Write("<a href=\"{0}\">{1}</a>", info4.m_FileName, info4.m_TypeName);
                }
                typeHtml.WriteLine("</h4>");
            }
            ArrayList list2 = info.m_Nested;
            if (list2 != null)
            {
                typeHtml.Write("<h4>Nested Types: ");
                list2.Sort(new TypeComparer());
                for (int num4 = 0; num4 < list2.Count; num4++)
                {
                    TypeInfo info5 = (TypeInfo) list2[num4];
                    if (num4 != 0)
                    {
                        typeHtml.Write(", ");
                    }
                    typeHtml.Write("<a href=\"{0}\">{1}</a>", info5.m_FileName, info5.m_TypeName);
                }
                typeHtml.WriteLine("</h4>");
            }
            MemberInfo[] infoArray1 = type1.GetMembers(BindingFlags.NonPublic | (BindingFlags.Public | (BindingFlags.Static | (BindingFlags.Instance | BindingFlags.DeclaredOnly))));
            Array.Sort(infoArray1, new MemberComparer());
            for (int num5 = 0; num5 < infoArray1.Length; num5++)
            {
                MemberInfo info6 = infoArray1[num5];
                if (info6 is PropertyInfo)
                {
                    Docs.WriteProperty((PropertyInfo) info6, typeHtml);
                }
                else if (info6 is ConstructorInfo)
                {
                    Docs.WriteCtor(info.m_TypeName, (ConstructorInfo) info6, typeHtml);
                }
                else if (info6 is MethodInfo)
                {
                    Docs.WriteMethod((MethodInfo) info6, typeHtml);
                }
            }
        }


        // Fields
        private const string CtorString = "(<font color=\"blue\">ctor</font>) ";
        private const string GetString = " <font color=\"blue\">get</font>;";
        private const string HtmlNewLine = "";
        private const string InString = "<font color=\"blue\">in</font> ";
        private static string[,] m_Aliases;
        private static int m_AliasLength;
        private static Hashtable m_Namespaces;
        private static string m_RootDirectory;
        private static Hashtable m_Types;
        private const string OutString = "<font color=\"blue\">out</font> ";
        private const string RefString = "<font color=\"blue\">ref</font> ";
        private const string SetString = " <font color=\"blue\">set</font>;";
        private const string StaticString = "(<font color=\"blue\">static</font>) ";
        private const string VirtString = "<font color=\"blue\">virtual</font> ";

        // Nested Types
        private class MemberComparer : IComparer
        {
            // Methods
            public MemberComparer()
            {
            }

            public int Compare(object x, object y)
            {
                int num2;
                if (x == y)
                {
                    return 0;
                }
                ConstructorInfo info1 = x as ConstructorInfo;
                ConstructorInfo info2 = y as ConstructorInfo;
                PropertyInfo info3 = x as PropertyInfo;
                PropertyInfo info4 = y as PropertyInfo;
                MethodInfo info5 = x as MethodInfo;
                MethodInfo info6 = y as MethodInfo;
                bool flag1 = this.GetStaticFor(info1, info3, info5);
                bool flag2 = this.GetStaticFor(info2, info4, info6);
                if (flag1 && !flag2)
                {
                    return -1;
                }
                if (!flag1 && flag2)
                {
                    return 1;
                }
                int num1 = 0;
                if (info1 != null)
                {
                    if (info2 == null)
                    {
                        num1 = -1;
                    }
                }
                else if (info2 != null)
                {
                    if (info1 == null)
                    {
                        num1 = 1;
                    }
                }
                else if (info3 != null)
                {
                    if (info4 == null)
                    {
                        num1 = -1;
                    }
                }
                else if ((info4 != null) && (info3 == null))
                {
                    num1 = 1;
                }
                if (num1 == 0)
                {
                    num1 = this.GetNameFrom(info1, info3, info5).CompareTo(this.GetNameFrom(info2, info4, info6));
                }
                if (((num1 == 0) && (info1 != null)) && (info2 != null))
                {
                    num2 = info1.GetParameters().Length;
                    return num2.CompareTo(info2.GetParameters().Length);
                }
                if (((num1 == 0) && (info5 != null)) && (info6 != null))
                {
                    num2 = info5.GetParameters().Length;
                    num1 = num2.CompareTo(info6.GetParameters().Length);
                }
                return num1;
            }

            private string GetNameFrom(ConstructorInfo ctor, PropertyInfo prop, MethodInfo method)
            {
                if (ctor != null)
                {
                    return ctor.DeclaringType.Name;
                }
                if (prop != null)
                {
                    return prop.Name;
                }
                if (method != null)
                {
                    return method.Name;
                }
                return "";
            }

            private bool GetStaticFor(ConstructorInfo ctor, PropertyInfo prop, MethodInfo method)
            {
                if (ctor != null)
                {
                    return ctor.IsStatic;
                }
                if (method != null)
                {
                    return method.IsStatic;
                }
                if (prop != null)
                {
                    MethodInfo info1 = prop.GetGetMethod();
                    MethodInfo info2 = prop.GetGetMethod();
                    if ((info1 != null) && info1.IsStatic)
                    {
                        return true;
                    }
                    if (info2 != null)
                    {
                        return info2.IsStatic;
                    }
                }
                return false;
            }

        }

        private class NamespaceComparer : IComparer
        {
            // Methods
            public NamespaceComparer()
            {
            }

            public int Compare(object x, object y)
            {
                DictionaryEntry entry1 = (DictionaryEntry) x;
                DictionaryEntry entry2 = (DictionaryEntry) y;
                return ((string) entry1.Key).CompareTo((string) entry2.Key);
            }

        }

        private class TypeComparer : IComparer
        {
            // Methods
            public TypeComparer()
            {
            }

            public int Compare(object x, object y)
            {
                if ((x == null) && (y == null))
                {
                    return 0;
                }
                if (x == null)
                {
                    return -1;
                }
                if (y == null)
                {
                    return 1;
                }
                Docs.TypeInfo info1 = x as Docs.TypeInfo;
                Docs.TypeInfo info2 = y as Docs.TypeInfo;
                if ((info1 == null) || (info2 == null))
                {
                    throw new ArgumentException();
                }
                return info1.m_TypeName.CompareTo(info2.m_TypeName);
            }

        }

        private class TypeInfo
        {
            // Methods
            public TypeInfo(Type type)
            {
                this.m_Type = type;
                this.m_BaseType = type.BaseType;
                this.m_Declaring = type.DeclaringType;
                this.m_Interfaces = type.GetInterfaces();
                this.m_TypeName = type.Name;
                this.m_FileName = Docs.GetFileName("docs/types/", this.m_TypeName, ".html");
                this.m_Writer = Docs.GetWriter("docs/types/", this.m_FileName);
            }


            // Fields
            public Type m_BaseType;
            public Type m_Declaring;
            public ArrayList m_Derived;
            public string m_FileName;
            public Type[] m_Interfaces;
            public ArrayList m_Nested;
            public Type m_Type;
            public string m_TypeName;
            public StreamWriter m_Writer;
        }
    }
}

