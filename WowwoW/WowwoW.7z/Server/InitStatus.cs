namespace Server
{
    using System;

    public enum InitStatus : byte
    {
        // Fields
        Done = 2,
        None = 0,
        Started = 1
    }
}

