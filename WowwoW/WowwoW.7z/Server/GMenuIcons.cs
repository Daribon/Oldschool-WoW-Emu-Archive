namespace Server
{
    using System;

    public enum GMenuIcons : byte
    {
        // Fields
        Auctioneer = 10,
        Banker = 6,
        Battlemaster = 9,
        Binder = 5,
        Gossip = 0,
        Gossip2 = 11,
        Gossip3 = 12,
        Healer = 4,
        Petition = 7,
        Tabard = 8,
        Taxi = 2,
        Trainer = 3,
        Vendor = 1
    }
}

