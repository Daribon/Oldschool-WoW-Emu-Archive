namespace Server
{
    using System;

    public class Poisons : Skill
    {
        // Methods
        public Poisons()
        {
        }

        public Poisons(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xa3;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xa3;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

