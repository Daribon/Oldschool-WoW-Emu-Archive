namespace Server
{
    using System;
    using System.Collections;
    using System.Runtime.CompilerServices;

    public delegate void SingleTargetSpellEffectMultiple(BaseAbility ba, Mobile c, Mobile m, ArrayList addTargets);

}

