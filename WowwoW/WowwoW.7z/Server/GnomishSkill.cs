namespace Server
{
    using System;

    public class GnomishSkill : Skill
    {
        // Methods
        public GnomishSkill()
        {
        }

        public GnomishSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x139;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x139;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x1cac;
            }
        }

    }
}

