namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;

    public class StandingGuardAI : BaseAIType
    {
        // Methods
        public StandingGuardAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.Pause1;
            base.CustomBehaviours.Add(CustomBehavioursTypes.Stay);
            base.CustomBehaviours.Add(CustomBehavioursTypes.KeepOrientation);
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if ((AIState != AIStates.Attack) && (AIState != AIStates.Fighting))
            {
                base.OnBeginFight(by);
                return AIStates.BeingAttacked;
            }
            return AIState;
        }

        public override void OnTick()
        {
            if (base.From.DebugSniffer != null)
            {
                base.From.DebugSniffer.SendMessage("PredatorAI::OnTick");
            }
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 1800f))
            {
                base.From.AIState = AIStates.LookingForPrey;
                base.From.AttackTarget = null;
            }
            else
            {
                if ((base.From.AttackTarget == null) || base.From.AttackTarget.Dead)
                {
                    ArrayList list1 = base.From.KnownObjects();
                    foreach (Server.Object obj1 in list1)
                    {
                        if (!(obj1 is Mobile))
                        {
                            continue;
                        }
                        Mobile mobile1 = obj1 as Mobile;
                        if ((((base.From.Distance(mobile1) < base.MaxViewDistance) && (Utility.Random4() == 0)) && (base.From.IsHostile(mobile1) && base.From.CanSee(mobile1))) && !mobile1.Dead)
                        {
                            base.From.AIState = AIStates.BeingAttacked;
                            base.From.AttackTarget = mobile1;
                            return;
                        }
                    }
                }
                AIStates states1 = base.AIState;
                if (states1 != AIStates.DoingNothing)
                {
                    if (states1 == AIStates.LookingForPrey)
                    {
                        base.AIState = AIStates.Pause1;
                    }
                    else if (states1 != AIStates.Pause1)
                    {
                    }
                }
                else
                {
                    base.AIState = AIStates.Pause1;
                    base.From.Running = false;
                }
            }
        }

    }
}

