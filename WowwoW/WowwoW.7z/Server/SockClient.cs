namespace Server
{
    using HelperTools;
    using System;
    using System.IO;
    using System.Net;
    using System.Net.Sockets;

    public class SockClient : IDisposable
    {
        // Methods
        public SockClient(Socket from, RemoveClientDelegate rftsl)
        {
            this.dataReceive = new byte[0x10000];
            this.disposed = false;
            this.ms = new MemoryStream();
            this.removeFromTheServerList = rftsl;
            this.clientSocket = from;
        }

        public void Dispose()
        {
            if (!this.disposed)
            {
                this.disposed = true;
                try
                {
                    this.clientSocket.Shutdown(SocketShutdown.Both);
                }
                catch
                {
                }
                if (this.clientSocket != null)
                {
                    this.clientSocket.Close();
                }
                this.clientSocket = null;
                if (this.removeFromTheServerList != null)
                {
                    this.removeFromTheServerList(this);
                }
            }
        }

        public virtual void OnReceiveData(IAsyncResult ar)
        {
            try
            {
                if (this.disposed)
                {
                    return;
                }
                int num1 = this.clientSocket.EndReceive(ar);
                if (num1 <= 0)
                {
                    this.Dispose();
                }
                else
                {
                    byte[] buffer1 = this.ProcessDataReceived(this.dataReceive, num1);
                    if (buffer1 != null)
                    {
                        this.clientSocket.BeginSend(buffer1, 0, buffer1.Length, SocketFlags.None, new AsyncCallback(this.OnSended), this);
                    }
                    else
                    {
                        this.clientSocket.BeginReceive(this.dataReceive, 0, this.dataReceive.Length, SocketFlags.None, new AsyncCallback(this.OnReceiveData), this);
                    }
                }
            }
            catch (Exception)
            {
                this.Dispose();
            }
        }

        public void OnSended(IAsyncResult ar)
        {
            try
            {
                if (this.disposed)
                {
                    return;
                }
                this.clientSocket.EndSend(ar);
                this.clientSocket.BeginReceive((ar.AsyncState as SockClient).dataReceive, 0, (ar.AsyncState as SockClient).dataReceive.Length, SocketFlags.None, new AsyncCallback(this.OnReceiveData), ar.AsyncState);
            }
            catch
            {
                this.Dispose();
            }
        }

        public void OnSended2(IAsyncResult ar)
        {
            try
            {
                if (this.disposed)
                {
                    return;
                }
                this.clientSocket.EndSend(ar);
            }
            catch (Exception)
            {
                this.Dispose();
            }
        }

        public virtual byte[] ProcessDataReceived(byte[] data, int length)
        {
            return null;
        }

        public virtual void Send(string str)
        {
            try
            {
                int num1 = 0;
                if (this.disposed)
                {
                    return;
                }
                byte[] buffer1 = new byte[str.Length];
                Converter.ToBytes(str, buffer1, ref num1);
                this.clientSocket.BeginSend(buffer1, 0, num1, SocketFlags.None, new AsyncCallback(this.OnSended2), this);
            }
            catch (Exception)
            {
                this.Dispose();
            }
        }

        public virtual void Send(byte[] toSendBuff, int len)
        {
            try
            {
                if (this.disposed)
                {
                    return;
                }
                byte[] buffer1 = new byte[len];
                Buffer.BlockCopy(toSendBuff, 0, buffer1, 0, len);
                this.clientSocket.BeginSend(buffer1, 0, len, SocketFlags.None, new AsyncCallback(this.OnSended2), this);
            }
            catch (Exception)
            {
                this.Dispose();
            }
        }

        public virtual void Send(char[] toSendBuff, int len)
        {
            try
            {
                if (this.disposed)
                {
                    return;
                }
                byte[] buffer1 = new byte[len];
                Buffer.BlockCopy(toSendBuff, 0, buffer1, 0, len);
                this.clientSocket.BeginSend(buffer1, 0, len, SocketFlags.None, new AsyncCallback(this.OnSended2), this);
            }
            catch (Exception)
            {
                this.Dispose();
            }
        }

        public virtual void Send(byte[] toSendBuff, int offset, int len)
        {
            try
            {
                if (this.disposed)
                {
                    return;
                }
                byte[] buffer1 = new byte[len];
                Buffer.BlockCopy(toSendBuff, offset, buffer1, 0, len);
                if (this.disposed)
                {
                    return;
                }
                this.clientSocket.BeginSend(buffer1, 0, len, SocketFlags.None, new AsyncCallback(this.OnSended2), this);
            }
            catch (Exception)
            {
                this.Dispose();
            }
        }

        public void Start()
        {
            this.clientSocket.BeginReceive(this.dataReceive, 0, this.dataReceive.Length, SocketFlags.None, new AsyncCallback(this.OnReceiveData), this);
        }


        // Properties
        public bool Disposed
        {
            get
            {
                return this.disposed;
            }
        }

        public IPAddress IP
        {
            get
            {
                try
                {
                    if (this.disposed)
                    {
                        return null;
                    }
                    return ((IPEndPoint) this.clientSocket.RemoteEndPoint).Address;
                }
                catch
                {
                    this.Dispose();
                }
                return null;
            }
        }


        // Fields
        public Socket clientSocket;
        private byte[] dataReceive;
        private bool disposed;
        private MemoryStream ms;
        private RemoveClientDelegate removeFromTheServerList;
    }
}

