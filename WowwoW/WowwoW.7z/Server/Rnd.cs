namespace Server
{
    using System;

    public class Rnd
    {
        // Methods
        static Rnd()
        {
            Rnd._random = new System.Random();
        }

        public Rnd()
        {
        }

        public static int Dice(int numDice, int numSides, int bonus)
        {
            int num1 = 0;
            for (int num2 = 0; num2 < numDice; num2++)
            {
                num1 += (Rnd.Random(numSides) + 1);
            }
            return (num1 + bonus);
        }

        public static int Random(int count)
        {
            return Rnd._random.Next(count);
        }

        public static int Random(int from, int count)
        {
            if (count == 0)
            {
                return from;
            }
            if (count > 0)
            {
                return (from + Rnd._random.Next(count));
            }
            return (from - Rnd._random.Next(-count));
        }

        public static bool RandomBool()
        {
            return (Rnd._random.Next(2) == 0);
        }

        public static double RandomDouble()
        {
            return Rnd._random.NextDouble();
        }

        public static double RandomDoubleArr(params double[] arr)
        {
            return arr[Rnd._random.Next(arr.Length)];
        }

        public static float RandomFloatArr(params float[] arr)
        {
            return arr[Rnd._random.Next(arr.Length)];
        }

        public static int RandomIntArr(params int[] arr)
        {
            return arr[Rnd._random.Next(arr.Length)];
        }

        public static int RandomMinMax(int min, int max)
        {
            if (min > max)
            {
                int num1 = min;
                min = max;
                max = num1;
            }
            else if (min == max)
            {
                return min;
            }
            return (min + Rnd._random.Next((max - min) + 1));
        }

        public static object RandomObjectArr(params object[] arr)
        {
            return arr[Rnd._random.Next(arr.Length)];
        }


        // Fields
        private static System.Random _random;
    }
}

