namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Net.Sockets;
    using System.Security.Cryptography;

    public class ClientConnection : SockClient
    {
        // Methods
        static ClientConnection()
        {
            ClientConnection.s1 = 1;
            ClientConnection.N = new byte[0x20] { 
                0x89, 0x4b, 100, 0x5e, 0x89, 0xe1, 0x53, 0x5b, 0xbd, 0xad, 0x5b, 0x8b, 0x29, 6, 80, 0x53, 
                8, 1, 0xb1, 0x8e, 0xbf, 0xbf, 0x5e, 0x8f, 0xab, 60, 130, 0x87, 0x2a, 0x3e, 0x9b, 0xb7
             } ;
            ClientConnection.rN = ClientConnection.Reverse(ClientConnection.N);
            ClientConnection.rand = new Random();
            ClientConnection.tryLoggin = new Hashtable();
        }

        public ClientConnection(Socket sock, RemoveClientDelegate rcd) : base(sock, rcd)
        {
            this.salt = new byte[0x20];
            this.b = new byte[20];
        }

        public static byte[] Concat(byte[] a, byte[] b)
        {
            byte[] buffer1 = new byte[a.Length + b.Length];
            for (int num1 = 0; num1 < a.Length; num1++)
            {
                buffer1[num1] = a[num1];
            }
            for (int num2 = 0; num2 < b.Length; num2++)
            {
                buffer1[num2 + a.Length] = b[num2];
            }
            return buffer1;
        }

        public override byte[] ProcessDataReceived(byte[] data, int length)
        {
            int num1;
            BigInteger integer4;
            BigInteger integer5;
            BigInteger integer6;
            byte[] buffer29;
            byte[] buffer32;
            byte num8 = data[0];
            switch (num8)
            {
                case 0:
                {
                    byte num10 = data[11];
                    byte num11 = data[12];
                    byte num2 = data[0x21];
                    this.userName = new byte[num2];
                    string text1 = "";
                    num1 = 0;
                    while (num1 < num2)
                    {
                        this.userName[num1] = data[0x22 + num1];
                        text1 = text1 + "" + ((char) data[0x22 + num1]);
                        num1++;
                    }
                    this.myAccount = World.allAccounts.FindByUserName(text1);
                    if (World.FreeForAll && (this.myAccount == null))
                    {
                        Account account1;
                        this.myAccount = account1 = new Account(text1, text1);
                        World.allAccounts.Add(account1);
                    }
                    if (this.myAccount == null)
                    {
                        return new byte[2] { 1, 4 } ;
                    }
                    if (this.myAccount.SelectedChar != null)
                    {
                        return new byte[2] { 1, 6 } ;
                    }
                    SHA1 sha1 = new SHA1CryptoServiceProvider();
                    string text2 = ":" + this.myAccount.Password.ToUpper();
                    char[] chArray1 = text2.ToCharArray();
                    byte[] buffer1 = new byte[chArray1.Length];
                    int num3 = 0;
                    char[] chArray2 = chArray1;
                    int num9 = 0;
                    while (num9 < chArray2.Length)
                    {
                        char ch1 = chArray2[num9];
                        buffer1[num3++] = (byte) ch1;
                        num9++;
                    }
                    byte[] buffer2 = ClientConnection.Concat(this.userName, buffer1);
                    byte[] buffer3 = sha1.ComputeHash(buffer2, 0, buffer2.Length);
                    byte[] buffer4 = new byte[buffer3.Length + this.salt.Length];
                    num1 = 0;
                    ClientConnection.rand.NextBytes(this.salt);
                    buffer32 = this.salt;
                    num9 = 0;
                    while (num9 < buffer32.Length)
                    {
                        byte num4 = buffer32[num9];
                        buffer4[num1++] = num4;
                        num9++;
                    }
                    buffer32 = buffer3;
                    for (num9 = 0; num9 < buffer32.Length; num9++)
                    {
                        byte num5 = buffer32[num9];
                        buffer4[num1++] = num5;
                    }
                    byte[] buffer5 = sha1.ComputeHash(buffer4, 0, buffer4.Length);
                    byte[] buffer6 = ClientConnection.Reverse(buffer5);
                    ClientConnection.rN = ClientConnection.Reverse(ClientConnection.N);
                    ClientConnection.rand.NextBytes(this.b);
                    this.rb = ClientConnection.Reverse(this.b);
                    BigInteger integer1 = new BigInteger(buffer6);
                    BigInteger integer2 = new BigInteger(ClientConnection.rN);
                    buffer32 = new byte[1] { 7 } ;
                    BigInteger integer3 = new BigInteger(buffer32);
                    this.v = integer3.modPow(integer1, integer2);
                    buffer32 = new byte[1] { 3 } ;
                    this.K = new BigInteger(buffer32);
                    integer4 = this.K * this.v;
                    integer5 = integer3.modPow(new BigInteger(this.rb), new BigInteger(ClientConnection.rN));
                    integer6 = integer4 + integer5;
                    //this.B = BigInteger.op_Modulus(integer6, new BigInteger(ClientConnection.rN));
					this.B = (integer6 % (new BigInteger(ClientConnection.rN)));//fix
                    byte[] buffer7 = new byte[0x76];
                    buffer7[1] = (byte) (num8 = 0);
                    buffer7[0] = num8;
                    byte[] buffer8 = ClientConnection.Reverse(this.B.getBytes());
                    num1 = 0;
                    while (num1 < buffer8.Length)
                    {
                        buffer7[3 + num1] = buffer8[num1];
                        num1++;
                    }
                    buffer7[0x23] = 1;
                    buffer7[0x24] = 7;
                    buffer7[0x25] = 0x20;
                    num1 = 0;
                    while (num1 < ClientConnection.N.Length)
                    {
                        buffer7[0x26 + num1] = ClientConnection.N[num1];
                        num1++;
                    }
                    num1 = 0;
                    while (num1 < this.salt.Length)
                    {
                        buffer7[70 + num1] = this.salt[num1];
                        num1++;
                    }
                    for (num1 = 0; num1 < 0x10; num1++)
                    {
                        buffer7[0x66 + num1] = 0;
                    }
                    return buffer7;
                }
                case 1:
                {
                    byte[] buffer9 = new byte[0x20];
                    num1 = 0;
                    while (num1 < 0x20)
                    {
                        buffer9[num1] = data[num1 + 1];
                        num1++;
                    }
                    byte[] buffer10 = new byte[20];
                    num1 = 0;
                    while (num1 < 20)
                    {
                        buffer10[num1] = data[(num1 + 1) + 0x20];
                        num1++;
                    }
                    byte[] buffer11 = ClientConnection.Reverse(buffer9);
                    byte[] buffer12 = ClientConnection.Concat(buffer9, ClientConnection.Reverse(this.B.getBytes()));
                    SHA1 sha2 = new SHA1CryptoServiceProvider();
                    byte[] buffer13 = sha2.ComputeHash(buffer12);
                    byte[] buffer14 = ClientConnection.Reverse(buffer13);
                    integer4 = this.v.modPow(new BigInteger(buffer14), new BigInteger(ClientConnection.rN));
                    integer5 = integer4 * new BigInteger(buffer11);
                    integer6 = integer5.modPow(new BigInteger(this.rb), new BigInteger(ClientConnection.rN));
                    byte[] buffer15 = new byte[0x10];
                    byte[] buffer16 = new byte[0x10];
                    byte[] buffer17 = new byte[0x20];
                    byte[] buffer18 = integer6.getBytes();
                    Buffer.BlockCopy(buffer18, 0, buffer17, 0, buffer18.Length);
                    byte[] buffer19 = ClientConnection.Reverse(buffer17);
                    num1 = 0;
                    while (num1 < 0x10)
                    {
                        buffer15[num1] = buffer19[num1 * 2];
                        buffer16[num1] = buffer19[(num1 * 2) + 1];
                        num1++;
                    }
                    byte[] buffer20 = sha2.ComputeHash(buffer15);
                    byte[] buffer21 = sha2.ComputeHash(buffer16);
                    this.myAccount.SS_Hash = new byte[buffer20.Length + buffer21.Length];
                    num1 = 0;
                    while (num1 < buffer20.Length)
                    {
                        this.myAccount.SS_Hash[num1 * 2] = buffer20[num1];
                        this.myAccount.SS_Hash[(num1 * 2) + 1] = buffer21[num1];
                        num1++;
                    }
                    byte[] buffer22 = sha2.ComputeHash(ClientConnection.N);
                    buffer32 = new byte[1] { 7 } ;
                    byte[] buffer23 = sha2.ComputeHash(buffer32);
                    byte[] buffer24 = sha2.ComputeHash(this.userName);
                    byte[] buffer25 = new byte[20];
                    num1 = 0;
                    while (num1 < 20)
                    {
                        buffer25[num1] = (byte) (buffer22[num1] ^ buffer23[num1]);
                        num1++;
                    }
                    byte[] buffer26 = ClientConnection.Concat(buffer25, buffer24);
                    buffer26 = ClientConnection.Concat(buffer26, this.salt);
                    buffer26 = ClientConnection.Concat(buffer26, buffer9);
                    buffer26 = ClientConnection.Concat(buffer26, this.B.getBytes());
                    buffer26 = ClientConnection.Concat(buffer26, this.K.getBytes());
                    sha2.ComputeHash(buffer26);
                    buffer26 = ClientConnection.Concat(buffer9, buffer10);
                    buffer26 = ClientConnection.Concat(buffer26, this.myAccount.SS_Hash);
                    byte[] buffer27 = sha2.ComputeHash(buffer26);
                    byte[] buffer28 = new byte[(buffer27.Length + 4) + 2];
                    buffer28[0] = 1;
                    buffer28[1] = 0;
                    for (num1 = 0; num1 < buffer27.Length; num1++)
                    {
                        buffer28[num1 + 2] = buffer27[num1];
                    }
                    Console.WriteLine("Logon proof for {0},{1}", base.IP.ToString(), this.myAccount.Username);
                    this.myAccount.Ip = base.IP;
                    this.myAccount.Port = 0;
                    this.myAccount.K = this.myAccount.SS_Hash;
                    return buffer28;
                }
                case 2:
                {
                    buffer29 = new byte[0x22];
                    buffer29[0] = 2;
                    buffer29[1] = 0;
                    num1 = 0;
                    goto Label_06AC;
                }
                case 3:
                {
                    buffer32 = new byte[2];
                    buffer32[0] = 3;
                    return buffer32;
                }
                case 4:
                {
                    goto Label_0815;
                }
                case 0x10:
                {
                    string text3 = World.ServerIP;
                    if (base.IP.ToString() == "127.0.0.1")
                    {
                        text3 = "127.0.0.1";
                    }
                    byte[] buffer30 = new byte[((0x19 + text3.Length) + World.ServerName.Length) + World.ServerPort.ToString().Length];
					int num6 = 0;
                    Converter.ToBytes((byte) 0x10, buffer30, ref num6);
                    Converter.ToBytes((byte) 0x2b, buffer30, ref num6);
                    Converter.ToBytes(1, buffer30, ref num6);
                    Converter.ToBytes((byte) 0, buffer30, ref num6);
                    Converter.ToBytes(1, buffer30, ref num6);
                    Converter.ToBytes((short) 0, buffer30, ref num6);
                    Converter.ToBytes(World.ServerName, buffer30, ref num6);
                    Converter.ToBytes((byte) 0, buffer30, ref num6);
                    Converter.ToBytes(text3, buffer30, ref num6);
                    Converter.ToBytes((byte) 0x3a, buffer30, ref num6);
                    Converter.ToBytes(World.ServerPort.ToString(), buffer30, ref num6);
                    Converter.ToBytes((byte) 0, buffer30, ref num6);
                    Converter.ToBytes(0, buffer30, ref num6);
                    Converter.ToBytes((short) World.allConnectedChars.Count, buffer30, ref num6);
                    Converter.ToBytes((byte) 0, buffer30, ref num6);
                    Converter.ToBytes((short) 1, buffer30, ref num6);
                    int num7 = 1;
                    num6 -= 3;
                    Converter.ToBytes(num6, buffer30, ref num7);
                    Console.WriteLine("Connected player(s) {0}", World.allConnectedChars.Count);
                    return buffer30;
                }
                default:
                {
                    Console.WriteLine("Receive unknown command {0}", data[0]);
                    goto Label_0815;
                }
            }
        Label_06AC:
            if (num1 >= 0x10)
            {
                return buffer29;
            }
            buffer29[0x12 + num1] = 0;
            num1++;
            goto Label_06AC;
        Label_0815:
            return new byte[4];
        }

        public static byte[] Reverse(byte[] from)
        {
            byte[] buffer1 = new byte[from.Length];
            int num1 = 0;
            for (int num2 = from.Length - 1; num2 >= 0; num2--)
            {
                buffer1[num1++] = from[num2];
            }
            return buffer1;
        }


        // Fields
        private byte[] b;
        private BigInteger B;
        private BigInteger K;
        private Account myAccount;
        private static byte[] N;
        private static Random rand;
        private byte[] rb;
        private static byte[] rN;
        public static int s1;
        private byte[] salt;
        public static Hashtable tryLoggin;
        private byte[] userName;
        private BigInteger v;
    }
}

