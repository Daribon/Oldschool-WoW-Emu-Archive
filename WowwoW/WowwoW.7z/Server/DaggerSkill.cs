namespace Server
{
    using System;

    public class DaggerSkill : Skill
    {
        // Methods
        public DaggerSkill()
        {
        }

        public DaggerSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xad;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xad;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x49c;
            }
        }

    }
}

