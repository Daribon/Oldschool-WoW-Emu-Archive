namespace Server
{
    using System;

    public class Retribution : Skill
    {
        // Methods
        public Retribution()
        {
        }

        public Retribution(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xb8;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xb8;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

