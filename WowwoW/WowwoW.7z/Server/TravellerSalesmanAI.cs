namespace Server
{
    using System;

    public class TravellerSalesmanAI : BaseAIType
    {
        // Methods
        public TravellerSalesmanAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.LookingForPrey;
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if ((AIState != AIStates.Attack) && (AIState != AIStates.Fighting))
            {
                return AIStates.BeingAttacked;
            }
            return AIState;
        }

        public override void OnTick()
        {
            if (base.From.DebugSniffer != null)
            {
                base.From.DebugSniffer.SendMessage("PredatorAI::OnTick");
            }
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 2450f))
            {
                base.From.AIState = AIStates.LookingForPrey;
                base.From.AttackTarget = null;
            }
            else
            {
                AIStates states1 = base.AIState;
                if (states1 != AIStates.DoingNothing)
                {
                    if (states1 != AIStates.LookingForPrey)
                    {
                        return;
                    }
                }
                else
                {
                    base.AIState = AIStates.LookingForPrey;
                    base.From.Running = false;
                    return;
                }
                base.From.Running = false;
            }
        }

    }
}

