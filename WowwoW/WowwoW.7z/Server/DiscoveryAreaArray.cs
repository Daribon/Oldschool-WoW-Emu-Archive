namespace Server
{
    using System;
    using System.Collections;

    public class DiscoveryAreaArray
    {
        // Methods
        public DiscoveryAreaArray()
        {
            this._items = new ArrayList();
        }

        public void Add(int areaTriggerId)
        {
            if (!this._items.Contains(areaTriggerId))
            {
                this._items.Add(areaTriggerId);
            }
        }

        public bool Contains(int val)
        {
            return this._items.Contains(val);
        }


        // Properties
        public int Count
        {
            get
            {
                return this._items.Count;
            }
        }

        public int[] Items
        {
            get
            {
                return (int[]) this._items.ToArray(typeof(int));
            }
        }


        // Fields
        private ArrayList _items;
    }
}

