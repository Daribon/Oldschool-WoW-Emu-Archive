namespace Server
{
    using System;

    public enum AIStates
    {
        // Fields
        Attack = 5,
        BeingAttacked = 6,
        CallForHelp = 9,
        DoingNothing = 0,
        Explore = 1,
        Fighting = 7,
        Flee = 8,
        Follow = 0x17,
        HealFriend = 12,
        LookingForPrey = 4,
        MoveFar = 3,
        MoveFarFrom = 11,
        MoveNear = 2,
        MoveTo = 10,
        Moving = 0x16,
        Pause1 = 13,
        Pause2 = 14,
        Pause3 = 15,
        Pause4 = 0x10,
        Pause5 = 0x11,
        Pause6 = 0x12,
        Pause7 = 0x13,
        Pause8 = 20,
        Pause9 = 0x15,
        ReturnHome = 0x18,
        Speaking = 0x19
    }
}

