namespace Server
{
    using System;

    public class PermanentAura
    {
        // Methods
        public PermanentAura(Aura _aura, int _id)
        {
            this.aura = _aura;
            this.id = _id;
        }


        // Properties
        public int Id
        {
            get
            {
                return this.id;
            }
        }


        // Fields
        public Aura aura;
        private int id;
    }
}

