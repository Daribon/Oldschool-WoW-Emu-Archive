namespace Server
{
    using System;

    public enum qFailedReason
    {
        // Fields
        DupeItemFound = 0x10,
        Failed = 0,
        InventoryFull = 4
    }
}

