namespace Server
{
    using System;
    using System.Collections;
    using System.Reflection;

    public class Skills : IDictionary, ICollection, IEnumerable, ICloneable
    {
        // Methods
        public Skills()
        {
            this.innerHash = new Hashtable();
        }

        public Skills(Skills original)
        {
            this.innerHash = new Hashtable(original.innerHash);
        }

        public Skills(IDictionary dictionary)
        {
            this.innerHash = new Hashtable(dictionary);
        }

        public Skills(int capacity)
        {
            this.innerHash = new Hashtable(capacity);
        }

        public Skills(IDictionary dictionary, float loadFactor)
        {
            this.innerHash = new Hashtable(dictionary, loadFactor);
        }

        public Skills(IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(codeProvider, comparer);
        }

        public Skills(int capacity, int loadFactor)
        {
            this.innerHash = new Hashtable(capacity, (float) loadFactor);
        }

        public Skills(IDictionary dictionary, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(dictionary, codeProvider, comparer);
        }

        public Skills(int capacity, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(capacity, codeProvider, comparer);
        }

        public Skills(IDictionary dictionary, float loadFactor, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(dictionary, loadFactor, codeProvider, comparer);
        }

        public Skills(int capacity, float loadFactor, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(capacity, loadFactor, codeProvider, comparer);
        }

        public void Add(Skill s)
        {
            this[s.Id] = s;
        }

        public void Add(ushort key, Skill value)
        {
            this.innerHash.Add(key, value);
        }

        public void Clear()
        {
            this.innerHash.Clear();
        }

        public Skills Clone()
        {
            Skills skills1 = new Skills();
            skills1.innerHash = (Hashtable) this.innerHash.Clone();
            return skills1;
        }

        public bool Contains(ushort key)
        {
            return this.innerHash.Contains(key);
        }

        public bool ContainsKey(ushort key)
        {
            return this.innerHash.ContainsKey(key);
        }

        public bool ContainsValue(Skill value)
        {
            return this.innerHash.ContainsValue(value);
        }

        public void CopyTo(Array array, int index)
        {
            this.innerHash.CopyTo(array, index);
        }

        public SkillsEnumerator GetEnumerator()
        {
            return new SkillsEnumerator(this);
        }

        public void Remove(ushort key)
        {
            this.innerHash.Remove(key);
        }

        public static Skills Synchronized(Skills nonSync)
        {
            Skills skills1 = new Skills();
            skills1.innerHash = Hashtable.Synchronized(nonSync.innerHash);
            return skills1;
        }

        void IDictionary.Add(object key, object value)
        {
            this.Add((ushort) key, (Skill) value);
        }

        bool IDictionary.Contains(object key)
        {
            return this.Contains((ushort) key);
        }

        IDictionaryEnumerator IDictionary.GetEnumerator()
        {
            return new SkillsEnumerator(this);
        }

        void IDictionary.Remove(object key)
        {
            this.Remove((ushort) key);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        object ICloneable.Clone()
        {
            return this.Clone();
        }


        // Properties
        public int Count
        {
            get
            {
                return this.innerHash.Count;
            }
        }

        internal Hashtable InnerHash
        {
            get
            {
                return this.innerHash;
            }
        }

        public bool IsFixedSize
        {
            get
            {
                return this.innerHash.IsFixedSize;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return this.innerHash.IsReadOnly;
            }
        }

        public bool IsSynchronized
        {
            get
            {
                return this.innerHash.IsSynchronized;
            }
        }

        public Skill this[ushort key]
        {
            get
            {
                return (Skill) this.innerHash[key];
            }
            set
            {
                this.innerHash[key] = value;
            }
        }

        public ICollection Keys
        {
            get
            {
                return this.innerHash.Keys;
            }
        }

        public object SyncRoot
        {
            get
            {
                return this.innerHash.SyncRoot;
            }
        }

        object IDictionary.this[object key]
        {
            get
            {
                return this[(ushort) key];
            }
            set
            {
                this[(ushort) key] = (Skill) value;
            }
        }

        public ICollection Values
        {
            get
            {
                return this.innerHash.Values;
            }
        }


        // Fields
        protected Hashtable innerHash;
    }
}

