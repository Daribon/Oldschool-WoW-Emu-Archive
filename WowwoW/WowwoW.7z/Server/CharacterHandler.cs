namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool CharacterHandler(Character c);

}

