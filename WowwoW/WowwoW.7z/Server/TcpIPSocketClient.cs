namespace Server
{
    using System;
    using System.IO;
    using System.Net.Sockets;
    using System.Text;
    using System.Threading;

    public class TcpIPSocketClient : TcpClient
    {
        // Methods
        public TcpIPSocketClient()
        {
            this.portNum = 0x2784;
        }

        public TcpIPSocketClient(string ip, int port)
        {
            this.portNum = 0x2784;
            this.portNum = port;
            this.m_Ready = false;
            this.m_Ip = ip;
            ThreadStart start1 = new ThreadStart(this.ConnectThread);
            this.m_Thread = new Thread(start1);
            this.m_Thread.Start();
        }

        public void CloseSocket()
        {
            this.m_Thread.Abort();
            this.networkStream.Close();
            base.Close();
        }

        public void ConnectThread()
        {
            try
            {
                base.Connect(this.m_Ip, this.portNum);
                this.networkStream = base.GetStream();
                if (this.networkStream.CanWrite && this.networkStream.CanRead)
                {
                    this.m_Ready = true;
                    string text1 = "";
                    while (text1 != "quit")
                    {
                        if (this.networkStream.DataAvailable)
                        {
                            byte[] buffer1 = new byte[base.ReceiveBufferSize];
                            int num1 = this.networkStream.ReadByte();
                            int num2 = this.networkStream.Read(buffer1, 0, num1);
                            string text2 = Encoding.ASCII.GetString(buffer1, 0, num2);
                            if ((text2 == "(string)") || !text2.StartsWith("("))
                            {
                                num2 = this.networkStream.Read(buffer1, 0, base.ReceiveBufferSize - (num1 + 1));
                                string text3 = Encoding.ASCII.GetString(buffer1, 0, num2);
                                if (text3.EndsWith("$Fin$"))
                                {
                                    text3 = text3.Remove(text3.Length - 5, 5);
                                }
                                this.OnReceived(text3);
                                continue;
                            }
                            this.OnReceivedData(this.networkStream, text2.Substring(1, text2.Length - 2), base.ReceiveBufferSize - (num1 + 1));
                            continue;
                        }
                        Thread.Sleep(50);
                    }
                    this.networkStream.Close();
                    base.Close();
                }
                else if (!this.networkStream.CanRead)
                {
                    base.Close();
                }
                else if (!this.networkStream.CanWrite)
                {
                    base.Close();
                }
            }
            catch (ThreadAbortException)
            {
                Thread.ResetAbort();
            }
            catch (SocketException)
            {
                this.OnLinkBroken();
            }
            catch (IOException)
            {
                this.OnLinkBroken();
            }
            catch (Exception)
            {
                this.OnLinkBroken();
            }
        }

        public virtual void OnLinkBroken()
        {
        }

        public virtual void OnReceived(string rec)
        {
        }

        public virtual void OnReceivedData(NetworkStream ns, string classname, int len)
        {
        }

        public virtual byte[] ProcessDataReceived(byte[] data, ClientHandler ch, int len)
        {
            return null;
        }

        public virtual string ProcessObjectReceived(MemoryStream stream, string classname)
        {
            return "";
        }

        public void Send(string rec)
        {
            try
            {
                if (rec.Length == 0)
                {
                    return;
                }
                goto Label_0014;
            Label_000D:
                Thread.Sleep(100);
            Label_0014:
                if (!this.m_Ready)
                {
                    goto Label_000D;
                }
                string text1 = "(string)";
                this.networkStream.WriteByte((byte) text1.Length);
                char[] chArray1 = text1.ToCharArray();
                byte[] buffer1 = new byte[chArray1.Length];
                int num1 = 0;
                char[] chArray2 = chArray1;
                for (int num2 = 0; num2 < chArray2.Length; num2++)
                {
                    char ch1 = chArray2[num2];
                    buffer1[num1++] = (byte) ch1;
                }
                this.networkStream.Write(buffer1, 0, buffer1.Length);
                rec = rec + "$Fin$";
                byte[] buffer2 = Encoding.ASCII.GetBytes(rec);
                this.networkStream.Write(buffer2, 0, buffer2.Length);
            }
            catch (SocketException)
            {
                this.OnLinkBroken();
            }
            catch (IOException)
            {
                this.OnLinkBroken();
            }
            catch (Exception)
            {
                this.OnLinkBroken();
            }
        }


        // Properties
        public NetworkStream NetStream
        {
            get
            {
                return this.networkStream;
            }
        }

        public virtual byte[] SS_Hash
        {
            get
            {
                return null;
            }
        }


        // Fields
        private string m_Ip;
        private bool m_Ready;
        private Thread m_Thread;
        private NetworkStream networkStream;
        private int portNum;
        public ClientHandler theClientHandler;
    }
}

