namespace Server
{
    using System;
    using System.Collections;

    public class NpcQuestMenu
    {
        // Methods
        public NpcQuestMenu()
        {
            this.menus = new ArrayList();
            this.quests = new ArrayList();
            this.title = "";
        }

        public NpcQuestMenu(string _title)
        {
            this.menus = new ArrayList();
            this.quests = new ArrayList();
            this.title = _title;
        }

        public void AddMenu(string menu, BaseQuest bq)
        {
            this.menus.Add(menu);
            this.quests.Add(bq);
        }


        // Properties
        public ArrayList Menu
        {
            get
            {
                return this.menus;
            }
        }

        public ArrayList Quests
        {
            get
            {
                return this.quests;
            }
        }

        public string Title
        {
            get
            {
                return this.title;
            }
        }


        // Fields
        private ArrayList menus;
        private ArrayList quests;
        private string title;
    }
}

