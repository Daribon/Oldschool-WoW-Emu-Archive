namespace Server
{
    using System;

    public class Demonology : Skill
    {
        // Methods
        public Demonology()
        {
        }

        public Demonology(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x162;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x162;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

