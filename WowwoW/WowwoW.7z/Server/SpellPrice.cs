namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int SpellPrice(Character c, int id);

}

