namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate float SkillProgressFactorHandler(Mobile m, int val, int skillid);

}

