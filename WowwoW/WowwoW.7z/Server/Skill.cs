namespace Server
{
    using HelperTools;
    using System;
    using System.Reflection;

    public class Skill : BaseAbility
    {
        // Methods
        public Skill()
        {
        }

        public Skill(int min, int m)
        {
            this.current = (ushort) min;
            this.max = (ushort) m;
        }

        public Skill(ushort min, ushort ind)
        {
            this.current = min;
            this.index = ind;
        }

        public int AgiSkillCheck(Mobile m, int diff)
        {
            if (m.StatUp(m.Agility, diff, 1))
            {
                m.Agility++;
            }
            int num1 = Utility.Random(100);
            if (num1 > 0x5f)
            {
                num1 += Utility.Random(100);
                if (num1 > 0x5f)
                {
                    num1 += Utility.Random(100);
                }
            }
            else if (num1 < 5)
            {
                num1 -= Utility.Random(100);
            }
            num1 += ((m.Agility - 30) / 10);
            return (num1 + diff);
        }

        public ushort Cap(Mobile from)
        {
            if (this.max == 0xffff)
            {
                return (ushort) (from.Level * 5);
            }
            return this.max;
        }

        public override int CastingTime(Mobile from)
        {
            return 0;
        }

        public ushort CurrentBonus(Mobile from)
        {
            int num1 = 0;
            foreach (Mobile.AuraReleaseTimer timer1 in from.Auras)
            {
                if (timer1.aura.SkillId == this.Id)
                {
                    num1 += (timer1.aura.SkillBonus - timer1.aura.SkillMalus);
                }
            }
            foreach (PermanentAura aura1 in from.PermanentAuras)
            {
                if (aura1.aura.SkillId == this.Id)
                {
                    num1 += (aura1.aura.SkillBonus - aura1.aura.SkillMalus);
                }
            }
            return (ushort) num1;
        }

        public ushort CurrentVal(Mobile from)
        {
            int num1 = 0;
            foreach (Mobile.AuraReleaseTimer timer1 in from.Auras)
            {
                if (timer1.aura.SkillId == this.Id)
                {
                    num1 += (timer1.aura.SkillBonus - timer1.aura.SkillMalus);
                }
            }
            foreach (PermanentAura aura1 in from.PermanentAuras)
            {
                if (aura1.aura.SkillId == this.Id)
                {
                    num1 += (aura1.aura.SkillBonus - aura1.aura.SkillMalus);
                }
            }
            if (((from.Classe == Classes.Warrior) && (this.Id == DefenseSkill.SkillId)) && from.HaveTalent(Talents.Anticipation))
            {
                AuraEffect effect1 = (AuraEffect) from.GetTalentEffect(Talents.Anticipation);
                num1 += effect1.S1;
            }
            if ((this.current + num1) < 0)
            {
                return 0;
            }
            return (ushort) (this.current + num1);
        }

        public static Skill Deserialize(GenericReader gr, int ind)
        {
            string text1 = gr.ReadString();
            if (text1 == "TwoHandedSkill")
            {
                text1 = "TwoHandedSwordSkill";
            }
            ConstructorInfo info1 = Utility.FindConstructor(text1);
            Skill skill1 = (Skill) info1.Invoke(null);
            skill1.Deserialize(gr, ind, true);
            return skill1;
        }

        public virtual void Deserialize(GenericReader gr, int ind, bool fake)
        {
            gr.ReadInt();
            this.index = (ushort) ind;
            this.current = (ushort) gr.ReadShort();
            this.max = (ushort) gr.ReadShort();
        }

        public int IqSkillCheck(Mobile m, int diff)
        {
            if (m.StatUp(m.Str, diff, 1))
            {
                m.Iq++;
            }
            int num1 = Utility.Random(100);
            if (num1 > 0x5f)
            {
                num1 += Utility.Random(100);
                if (num1 > 0x5f)
                {
                    num1 += Utility.Random(100);
                }
            }
            else if (num1 < 5)
            {
                num1 -= Utility.Random(100);
            }
            num1 += ((m.Iq - 30) / 10);
            return (num1 + diff);
        }

        public virtual void Serialize(GenericWriter gw)
        {
            gw.Write(Utility.ClassName(this));
            gw.Write(0);
            gw.Write(this.current);
            gw.Write(this.max);
        }

        public int SpiritSkillCheck(Mobile m, int diff)
        {
            if (m.StatUp(m.Spirit, diff, 1))
            {
                m.Spirit++;
            }
            int num1 = Utility.Random(100);
            if (num1 > 0x5f)
            {
                num1 += Utility.Random(100);
                if (num1 > 0x5f)
                {
                    num1 += Utility.Random(100);
                }
            }
            else if (num1 < 5)
            {
                num1 -= Utility.Random(100);
            }
            num1 += ((m.Spirit - 30) / 10);
            return (num1 + diff);
        }

        public int StrSkillCheck(Mobile m, int diff)
        {
            if (m.StatUp(m.Str, diff, 1))
            {
                m.Str++;
            }
            int num1 = Utility.Random(100);
            if (num1 > 0x5f)
            {
                num1 += Utility.Random(100);
                if (num1 > 0x5f)
                {
                    num1 += Utility.Random(100);
                }
            }
            else if (num1 < 5)
            {
                num1 -= Utility.Random(100);
            }
            num1 += ((m.Str - 30) / 10);
            return (num1 + diff);
        }


        // Properties
        public ushort Current
        {
            get
            {
                return this.current;
            }
            set
            {
                this.current = value;
            }
        }

        public override ushort Id
        {
            get
            {
                return 0;
            }
        }

        public virtual ushort Index
        {
            get
            {
                return this.index;
            }
        }

        public ushort Max
        {
            set
            {
                this.max = value;
            }
        }

        public virtual ushort SpellId
        {
            get
            {
                return 0;
            }
        }


        // Fields
        private ushort current;
        private ushort index;
        private ushort max;
    }
}

