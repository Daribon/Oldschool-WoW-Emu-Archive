namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Reflection;

    [Serializable]
    public class SpawnerList : CollectionBase
    {
        // Methods
        static SpawnerList()
        {
            SpawnerList.TempSpawner = new Hashtable();
        }

        public SpawnerList()
        {
            this.dirty = false;
            this.spawnZones = new Hashtable();
        }

        public SpawnerList(GenericReader gr)
        {
            this.dirty = false;
            this.spawnZones = new Hashtable();
            base.List.Clear();
            if (!gr.notFound)
            {
                this.Deserialize(gr);
            }
        }

        public SpawnerList(SpawnerList val)
        {
            this.dirty = false;
            this.spawnZones = new Hashtable();
            this.dirty = true;
            this.AddRange(val);
        }

        public SpawnerList(BaseSpawner[] val)
        {
            this.dirty = false;
            this.spawnZones = new Hashtable();
            this.dirty = true;
            this.AddRange(val);
        }

        public int Add(BaseSpawner val)
        {
            this.dirty = true;
            if (val.ZoneId == 0)
            {
                return base.List.Add(val);
            }
            int num1 = val.MapId * 0x400;
            ArrayList list1 = (ArrayList) this.spawnZones[num1 + ((int) World.zones[val.ZoneId])];
            if (list1 == null)
            {
                object obj1;
                this.spawnZones[num1 + ((int) World.zones[val.ZoneId])] = obj1 = new ArrayList();
                list1 = (ArrayList) obj1;
            }
            list1.Add(val);
            return base.List.Add(val);
        }

        public void AddRange(BaseSpawner[] val)
        {
            this.dirty = true;
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void AddRange(SpawnerList val)
        {
            this.dirty = true;
            for (int num1 = 0; num1 < val.Count; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public bool Contains(BaseSpawner val)
        {
            return base.List.Contains(val);
        }

        public void CopyTo(BaseSpawner[] array, int index)
        {
            this.dirty = true;
            base.List.CopyTo(array, index);
        }

        public virtual void Deserialize(GenericReader gr)
        {
            SpawnerList.TempSpawner[0] = null;
            gr.ReadInt();
            while (true)
            {
                int num1 = gr.ReadInt();
                if (num1 == 0)
                {
                    break;
                }
                this.Add(new BaseSpawner(gr));
            }
            int num2 = gr.ReadInt();
            for (int num3 = 0; num3 < num2; num3++)
            {
                int num4 = gr.ReadInt();
                int num5 = gr.ReadInt();
                ArrayList list1 = new ArrayList(num5);
                World.regSpawners[num4] = list1;
                for (int num6 = 0; num6 < num5; num6++)
                {
                    list1.Add(gr.ReadInt());
                }
            }
            gr.Close();
            SpawnerList.TempSpawner.Clear();
            SpawnerList.TempSpawner = null;
        }

        public new BaseSpawnerEnumerator GetEnumerator()
        {
            return new BaseSpawnerEnumerator(this);
        }

        public int IndexOf(BaseSpawner val)
        {
            return base.List.IndexOf(val);
        }

        public void Insert(int index, BaseSpawner val)
        {
            this.dirty = true;
            base.List.Insert(index, val);
        }

        public ArrayList Nearest(int zoneid)
        {
            return (ArrayList) this.spawnZones[zoneid];
        }

        public void Remove(BaseSpawner val)
        {
            int num1 = val.MapId * 0x400;
            ArrayList list1 = (ArrayList) this.spawnZones[num1 + ((int) World.zones[val.ZoneId])];
            if (list1 != null)
            {
                ((ArrayList) this.spawnZones[num1 + ((int) World.zones[val.ZoneId])]).Remove(val);
            }
            int num2 = base.List.IndexOf(val);
            for (int num3 = 0; num3 < World.regSpawners.Count; num3++)
            {
                ArrayList list2 = (ArrayList) World.regSpawners[num3];
                if (list2 != null)
                {
                    int num4 = -1;
                    for (int num5 = 0; num5 < list2.Count; num5++)
                    {
                        int num6 = (int) list2[num5];
                        if (num6 > num2)
                        {
                            list2[num5] = num6 - 1;
                        }
                        else if (num6 == num2)
                        {
                            num4 = num5;
                        }
                    }
                    if (num4 != -1)
                    {
                        ((ArrayList) World.regSpawners[num3]).RemoveAt(num4);
                    }
                }
            }
            for (int num7 = num2; num7 < (World.regSpawners.Count - 1); num7++)
            {
                World.regSpawners[num7] = World.regSpawners[num7 + 1];
            }
            this.dirty = true;
            base.List.Remove(val);
        }

        public virtual void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            foreach (BaseSpawner spawner1 in this)
            {
                gw.Write(1);
                spawner1.Serialize(gw);
            }
            gw.Write(0);
            gw.Write(World.regSpawners.Count);
            IDictionaryEnumerator enumerator1 = World.regSpawners.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                if (enumerator1.Value == null)
                {
                    continue;
                }
                gw.Write((int) enumerator1.Key);
                gw.Write((enumerator1.Value as ArrayList).Count);
                foreach (int num1 in (enumerator1.Value as ArrayList))
                {
                    gw.Write(num1);
                }
            }
            gw.Close();
            this.dirty = false;
        }


        // Properties
        public bool Dirty
        {
            get
            {
                return this.dirty;
            }
        }

        public BaseSpawner this[int index]
        {
            get
            {
                return (BaseSpawner) base.List[index];
            }
            set
            {
                this.dirty = true;
                base.List[index] = value;
            }
        }


        // Fields
        private bool dirty;
        private Hashtable spawnZones;
        public static Hashtable TempSpawner;

        // Nested Types
        public class BaseSpawnerEnumerator : IEnumerator
        {
            // Methods
            public BaseSpawnerEnumerator(SpawnerList mappings)
            {
                this.temp = mappings;
                this.baseEnumerator = this.temp.GetEnumerator();
            }

            public bool MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            public void Reset()
            {
                this.baseEnumerator.Reset();
            }


            // Properties
            public BaseSpawner Current
            {
                get
                {
                    return (BaseSpawner) this.baseEnumerator.Current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.baseEnumerator.Current;
                }
            }


            // Fields
            private IEnumerator baseEnumerator;
            private IEnumerable temp;
        }
    }
}

