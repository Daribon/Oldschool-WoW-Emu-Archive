namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Reflection;

    public class BaseSpawner : Server.Object
    {
        // Methods
        public BaseSpawner() : base((ulong) (0xf100000000000000 + Server.Object.GUID))
        {
            this.lastTime = DateTime.Now.Subtract(new TimeSpan((long) 0x3b9aca00));
            this.lastSpawn = DateTime.Now.Subtract(new TimeSpan((long) 0x3b9aca00));
            this.objects = new ArrayList();
            Server.Object.GUID++;
            this.lastSpawn = DateTime.Now.Subtract(new TimeSpan(0, 12, 0, 0, 0));
        }

        public BaseSpawner(GenericReader gr) : this()
        {
            this.Deserialize(gr);
        }

        public void Bind(Server.Object m)
        {
            this.objects.Add(m);
            m.SpawnerLink = this;
            this.currentAmount++;
        }

        public void DelayedRespawn()
        {
            this.compteur = this.frequency;
        }

        public override void Deserialize(GenericReader gr)
        {
            base.Deserialize(gr);
            int num1 = gr.ReadInt();
            if (num1 >= 2)
            {
                this.trajetGuid = gr.ReadInt64();
            }
            if (num1 >= 1)
            {
                this.realx = gr.ReadFloat();
                this.realy = gr.ReadFloat();
                this.realz = gr.ReadFloat();
            }
            this.currentAmount = gr.ReadInt();
            this.id = gr.ReadInt();
            this.model = gr.ReadInt();
            this.frequency = gr.ReadInt();
            this.howMuch = gr.ReadInt();
            int num2 = gr.ReadInt();
            if (num2 == 1)
            {
                this.iid = gr.ReadInt();
                this.ci = World.MobilePool(this.iid);
                this.creature = this.ci.ReflectedType;
            }
            int num3 = gr.ReadInt();
            if (num3 == 1)
            {
                this.gameObjectHandler = gr.ReadString();
            }
            this.DelayedRespawn();
            this.currentAmount = 0;
        }

        public void DisplayInfo(Character ch)
        {
            ch.SendMessage("Spawner for " + this.Name);
            if ((this.gameObjectHandler == null) && (this.howMuch >= 0))
            {
                ch.SendMessage("Amount " + this.currentAmount.ToString() + "/" + this.howMuch.ToString());
            }
        }

        public void ForceRespawn()
        {
            this.compteur = this.frequency;
            this.OnTick();
        }

        public void Init(int _id, int freq)
        {
            this.howMuch = _id;
            this.frequency = freq;
        }

        public void Init(string cls, int freq)
        {
            this.frequency = freq;
            ConstructorInfo info1 = Utility.FindConstructor(cls);
            GameObject obj1 = (GameObject) info1.Invoke(null);
            if (obj1.DefaultModel != 0)
            {
                this.howMuch = -obj1.DefaultModel;
            }
            else
            {
                this.howMuch = -obj1.Id;
            }
            this.gameObjectHandler = cls;
        }

        public void Init(int _id, int freq, string cls)
        {
            if ((cls == null) && World.GameObjectsAssociated.Exist(_id))
            {
                this.Init(_id, freq, Utility.ClassName(World.GameObjectsAssociated[_id].ToString()));
            }
            else
            {
                this.frequency = freq;
                this.howMuch = _id;
                this.gameObjectHandler = cls;
            }
        }

        public void Init(ConstructorInfo ct, int id, int freq, int how)
        {
            this.howMuch = how;
            this.frequency = freq;
            this.ci = ct;
            this.creature = this.ci.ReflectedType;
            this.iid = id;
        }

        public void OnTick()
        {
            TimeSpan span1 = DateTime.Now.Subtract(this.lastSpawn);
            this.compteur = (int) span1.TotalSeconds;
            if ((this.compteur > this.frequency) && ((this.gameObjectHandler != null) || (this.howMuch < 0)))
            {
                if ((this.currentAmount == 0) && (this.gameObjectHandler != null))
                {
                    GameObject obj1 = World.Add(0, this.gameObjectHandler, this.X, this.Y, this.Z, base.MapId);
                    obj1.SpawnerLink = this;
                    obj1.Id = -this.howMuch;
                    obj1.ZoneId = base.ZoneId;
                    this.Bind(obj1);
                    this.lastSpawn = DateTime.Now;
                }
                else if ((this.howMuch < 0) && (this.currentAmount == 0))
                {
                    GameObject obj2 = World.Add(-this.howMuch, this.X, this.Y, this.Z, base.MapId);
                    obj2.SpawnerLink = this;
                    obj2.ZoneId = base.ZoneId;
                    this.Bind(obj2);
                    this.lastSpawn = DateTime.Now;
                }
            }
            else if (this.frequency == 0)
            {
                object[] objArray1 = new object[5] { this.ci.ToString(), this.X, this.Y, this.Z, base.MapId } ;
                Console.WriteLine("BaseSpawner frequency = 0, {0},{1},{2},{3},{4}", objArray1);
            }
            else
            {
                if ((this.compteur / this.frequency) > this.howMuch)
                {
                    this.compteur = this.howMuch * this.frequency;
                }
                while (this.compteur > 0)
                {
                    if (this.currentAmount >= this.howMuch)
                    {
                        return;
                    }
                    BaseCreature creature1 = (BaseCreature) this.ci.Invoke(null);
                    creature1.InitStats();
                    creature1.SpawnerLink = this;
                    creature1.Orientation = base.Orientation;
                    if (((creature1.AIEngine != null) && (creature1.AIEngine.CustomBehaviours != null)) && creature1.AIEngine.CustomBehaviours.Contains(CustomBehavioursTypes.Stay))
                    {
                        World.Add(creature1, this.X, this.Y, this.Z, base.MapId);
                    }
                    else
                    {
                        World.Add(creature1, this.realx, this.realy, this.realz, base.MapId);
                    }
                    this.Bind(creature1);
                    creature1.ZoneId = base.ZoneId;
                    this.lastSpawn = DateTime.Now;
                    this.compteur -= this.frequency;
                    creature1.OnAddToWorld();
                }
            }
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther)
        {
            this.PrepareUpdateData(data, ref offset, type, forOther, null);
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther, Character f)
        {
            data[offset++] = 2;
            Converter.ToBytes(base.Guid, data, ref offset);
            Converter.ToBytes((byte) 3, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(this.X, data, ref offset);
            Converter.ToBytes(this.Y, data, ref offset);
            Converter.ToBytes(this.Z, data, ref offset);
            Converter.ToBytes(base.Orientation, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes((float) 4.5f, data, ref offset);
            Converter.ToBytes((float) 4.5f, data, ref offset);
            Converter.ToBytes((float) 4.5f, data, ref offset);
            Converter.ToBytes((float) 4.5f, data, ref offset);
            Converter.ToBytes((float) 4.5f, data, ref offset);
            Converter.ToBytes((float) 3.141593f, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 1, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            base.ResetBitmap();
            base.setUpdateValue(0, base.Guid);
            base.setUpdateValue(2, 9);
            if (this.id <= 0)
            {
                base.setUpdateValue(3, 0xf423f);
            }
            else
            {
                base.setUpdateValue(3, this.id);
            }
            base.setUpdateValue(4, (float) 0.5f);
            base.setUpdateValue(0x16, 0x3e8);
            base.setUpdateValue(0x17, 0);
            base.setUpdateValue(0x1c, 0x3e8);
            base.setUpdateValue(0x1d, 0);
            base.setUpdateValue(0x22, 1);
            base.setUpdateValue(0x23, 0x23);
            uint num1 = 0x100;
            base.setUpdateValue(0x24, num1);
            base.setUpdateValue(0x2e, 0);
            base.setUpdateValue(0x83, 0x3e8);
            base.setUpdateValue(0x84, 0x3e8);
            base.setUpdateValue(0x86, (float) 1f);
            base.setUpdateValue(0x87, (float) 1f);
            if (this.id <= 0)
            {
                base.setUpdateValue(0x88, 0x164);
            }
            else
            {
                base.setUpdateValue(0x88, this.model);
            }
            base.setUpdateValue(0x89, this.model);
            base.setUpdateValue(0x8a, 0);
            base.setUpdateValue(0x8b, (float) 1f);
            base.setUpdateValue(140, (float) 1f);
            base.setUpdateValue(0x97, 1);
            base.setUpdateValue(0x98, 0);
            base.setUpdateValue(0xa7, 0);
            base.setUpdateValue(170, 1);
            base.setUpdateValue(0xab, 0);
            base.FlushUpdateData(data, ref offset, 6);
        }

        public void Release(Server.Object m)
        {
            this.objects.Remove(m);
            this.currentAmount--;
        }

        public override bool SeenBy(Character c)
        {
            if (c.Player.AccessLevel == AccessLevels.PlayerLevel)
            {
                return false;
            }
            if (base.Distance(c) > 180000f)
            {
                return false;
            }
            return true;
        }

        public override void Serialize(GenericWriter gw)
        {
            base.Serialize(gw);
            gw.Write(2);
            gw.Write(this.trajetGuid);
            gw.Write(this.realx);
            gw.Write(this.realy);
            gw.Write(this.realz);
            gw.Write(this.currentAmount);
            gw.Write(this.id);
            gw.Write(this.model);
            gw.Write(this.frequency);
            gw.Write(this.howMuch);
            if (this.creature == null)
            {
                gw.Write(0);
            }
            else
            {
                gw.Write(1);
                gw.Write(this.iid);
            }
            if (this.gameObjectHandler == null)
            {
                gw.Write(0);
            }
            else
            {
                gw.Write(1);
                gw.Write(this.gameObjectHandler);
            }
        }

        public void StillActive(Character ch)
        {
            this.StillActive(ch, false);
        }

        public void StillActive(Character ch, bool noRespawn)
        {
            if (!this.IsStillActive && !noRespawn)
            {
                this.spawnerTimer = new SpawnerTimer(this);
                this.OnTick();
            }
            this.lastTime = DateTime.Now;
        }


        // Properties
        public int Amount
        {
            get
            {
                return this.howMuch;
            }
            set
            {
                this.howMuch = value;
            }
        }

        public int CurrentAmount
        {
            get
            {
                return this.currentAmount;
            }
            set
            {
                this.currentAmount = value;
            }
        }

        public int Frequency
        {
            get
            {
                return this.frequency;
            }
            set
            {
                this.frequency = value;
            }
        }

        public int Id
        {
            get
            {
                return this.id;
            }
            set
            {
                this.id = value;
            }
        }

        public bool IsStillActive
        {
            get
            {
                TimeSpan span1 = DateTime.Now.Subtract(this.lastTime);
                if (span1.TotalSeconds > 30)
                {
                    return false;
                }
                return true;
            }
        }

        public DateTime LastSpawn
        {
            get
            {
                return this.lastSpawn;
            }
            set
            {
                this.lastSpawn = value;
            }
        }

        public int Model
        {
            get
            {
                return this.model;
            }
            set
            {
                this.model = value;
            }
        }

        public string Name
        {
            get
            {
                if ((this.gameObjectHandler != null) || (this.howMuch < 0))
                {
                    int num1 = -this.howMuch;
                    return ("Game object id = " + num1.ToString());
                }
                BaseCreature creature1 = (BaseCreature) this.ci.Invoke(null);
                return (creature1.Name + ", " + base.ZoneId);
            }
        }

        public ArrayList Objects
        {
            get
            {
                return this.objects;
            }
        }

        public float RealX
        {
            get
            {
                return this.realx;
            }
            set
            {
                this.realx = value;
            }
        }

        public float RealY
        {
            get
            {
                return this.realy;
            }
            set
            {
                this.realy = value;
            }
        }

        public float RealZ
        {
            get
            {
                return this.realz;
            }
            set
            {
                this.realz = value;
            }
        }

        public ulong TrajetGuid
        {
            get
            {
                return this.trajetGuid;
            }
            set
            {
                this.trajetGuid = value;
            }
        }


        // Fields
        private ConstructorInfo ci;
        private int compteur;
        private Type creature;
        private int currentAmount;
        private int frequency;
        private string gameObjectHandler;
        private int howMuch;
        private int id;
        private int iid;
        private DateTime lastSpawn;
        private DateTime lastTime;
        private int model;
        private ArrayList objects;
        private float realx;
        private float realy;
        private float realz;
        private SpawnerTimer spawnerTimer;
        private ulong trajetGuid;
        private Trajets trajets;

        // Nested Types
        private class SpawnerTimer : WowTimer
        {
            // Methods
            public SpawnerTimer(BaseSpawner f) : base(WowTimer.Priorities.Second, 10000)
            {
                this.from = f;
                base.Start();
            }

            public override void OnTick()
            {
                this.from.OnTick();
                if (!this.from.IsStillActive)
                {
                    base.Stop();
                }
                base.OnTick();
            }


            // Fields
            private BaseSpawner from;
        }
    }
}

