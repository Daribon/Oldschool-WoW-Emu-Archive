namespace Server
{
    using System;
    using System.Collections;
    using System.Reflection;

    [Serializable]
    public class SpellsList : CollectionBase
    {
        // Methods
        public SpellsList()
        {
        }

        public SpellsList(SpellsList val)
        {
            this.AddRange(val);
        }

        public SpellsList(BaseAbility[] val)
        {
            this.AddRange(val);
        }

        public int Add(BaseAbility val)
        {
            return base.List.Add(val);
        }

        public int Add(int val)
        {
            return base.List.Add(Abilities.abilities[val]);
        }

        public void AddRange(BaseAbility[] val)
        {
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void AddRange(SpellsList val)
        {
            for (int num1 = 0; num1 < val.Count; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public bool Contains(BaseAbility val)
        {
            return base.List.Contains(val);
        }

        public void CopyTo(BaseAbility[] array, int index)
        {
            base.List.CopyTo(array, index);
        }

        public new BaseAbilityEnumerator GetEnumerator()
        {
            return new BaseAbilityEnumerator(this);
        }

        public int IndexOf(BaseAbility val)
        {
            return base.List.IndexOf(val);
        }

        public void Insert(int index, BaseAbility val)
        {
            base.List.Insert(index, val);
        }

        public void Remove(BaseAbility val)
        {
            base.List.Remove(val);
        }


        // Properties
        public BaseAbility this[int index]
        {
            get
            {
                return (BaseAbility) base.List[index];
            }
            set
            {
                base.List[index] = value;
            }
        }


        // Nested Types
        public class BaseAbilityEnumerator : IEnumerator
        {
            // Methods
            public BaseAbilityEnumerator(SpellsList mappings)
            {
                this.temp = mappings;
                this.baseEnumerator = this.temp.GetEnumerator();
            }

            public bool MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            public void Reset()
            {
                this.baseEnumerator.Reset();
            }


            // Properties
            public BaseAbility Current
            {
                get
                {
                    return (BaseAbility) this.baseEnumerator.Current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.baseEnumerator.Current;
                }
            }


            // Fields
            private IEnumerator baseEnumerator;
            private IEnumerable temp;
        }
    }
}

