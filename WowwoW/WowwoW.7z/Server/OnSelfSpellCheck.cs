namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate SpellFailedReason OnSelfSpellCheck(BaseAbility ba, Mobile c);

}

