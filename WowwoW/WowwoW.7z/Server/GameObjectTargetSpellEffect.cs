namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void GameObjectTargetSpellEffect(BaseAbility ba, Mobile c, GameObject go);

}

