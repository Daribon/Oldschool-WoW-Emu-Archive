namespace Server
{
    using System;
    using System.Collections;

    public class SkillsEnumerator : IDictionaryEnumerator, IEnumerator
    {
        // Methods
        internal SkillsEnumerator(Skills enumerable)
        {
            this.innerEnumerator = enumerable.InnerHash.GetEnumerator();
        }

        public bool MoveNext()
        {
            return this.innerEnumerator.MoveNext();
        }

        public void Reset()
        {
            this.innerEnumerator.Reset();
        }


        // Properties
        public object Current
        {
            get
            {
                return this.innerEnumerator.Current;
            }
        }

        public DictionaryEntry Entry
        {
            get
            {
                return this.innerEnumerator.Entry;
            }
        }

        public ushort Key
        {
            get
            {
                return (ushort) this.innerEnumerator.Key;
            }
        }

        object IDictionaryEnumerator.Key
        {
            get
            {
                return this.Key;
            }
        }

        object IDictionaryEnumerator.Value
        {
            get
            {
                return this.Value;
            }
        }

        public Skill Value
        {
            get
            {
                return (Skill) this.innerEnumerator.Value;
            }
        }


        // Fields
        private IDictionaryEnumerator innerEnumerator;
    }
}

