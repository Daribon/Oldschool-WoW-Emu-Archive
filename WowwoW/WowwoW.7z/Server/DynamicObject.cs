namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;

    public class DynamicObject : Server.Object
    {
        // Methods
        public DynamicObject(float X, float Y, float Z, ushort MapId, Mobile _caster, uint _spell, float _radius) : base(++Server.Object.GUID, X, Y, Z, 0f, MapId)
        {
            this.aura = new ArrayList();
            base.Guid |= 0xf000700000000000;
            this.caster = _caster;
            this.spell = _spell;
            this.radius = _radius;
        }

        public void End()
        {
            (this.caster as Character).DestroyObject(base.Guid);
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther, Character f)
        {
            Converter.ToBytes((byte) 2, data, ref offset);
            Converter.ToBytes(base.Guid, data, ref offset);
            Converter.ToBytes((byte) 6, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes(base.X, data, ref offset);
            Converter.ToBytes(base.Y, data, ref offset);
            Converter.ToBytes(base.Z, data, ref offset);
            Converter.ToBytes(base.Orientation, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes((float) 1f, data, ref offset);
            Converter.ToBytes((float) 1f, data, ref offset);
            Converter.ToBytes((float) 1f, data, ref offset);
            Converter.ToBytes((float) 1f, data, ref offset);
            Converter.ToBytes((float) 1f, data, ref offset);
            Converter.ToBytes((float) 1f, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 1, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((ulong) 0, data, ref offset);
            base.ResetBitmap();
            base.setUpdateValue(0, base.Guid);
            base.setUpdateValue(2, (uint) 0x41);
            base.setUpdateValue(3, this.spell);
            base.setUpdateValue(4, (float) 1f);
            base.setUpdateValue(6, this.caster.Guid);
            base.setUpdateValue(8, (uint) 1);
            base.setUpdateValue(9, this.spell);
            base.setUpdateValue(10, this.radius);
            base.setUpdateValue(11, base.X);
            base.setUpdateValue(12, base.Y);
            base.setUpdateValue(13, base.Z);
            base.setUpdateValue(14, base.Orientation);
            base.FlushUpdateData(data, ref offset, 1);
        }

        public virtual void SendSmallUpdate(int[] pos, object[] val)
        {
            int num1 = 4;
            this.tempBuff[num1++] = 1;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.tempBuff[num1++] = 0;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            int num2 = 2 + ((pos[pos.Length - 1] + 1) / 0x20);
            if (num2 > 0x21)
            {
                num2 = 0x21;
            }
            this.tempBuff[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank, 0, this.tempBuff, num1, Server.Object.Blank.Length);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer1;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer1 = this.tempBuff)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer1[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, this.tempBuff, ref num1);
            }
            this.caster.ToAllPlayerNear(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public void Start()
        {
            byte[] buffer1 = new byte[0x9c4];
            int num1 = 4;
            Converter.ToBytes((uint) 1, buffer1, ref num1);
            Converter.ToBytes((byte) 0, buffer1, ref num1);
            Converter.ToBytes((byte) 2, buffer1, ref num1);
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            Converter.ToBytes((byte) 6, buffer1, ref num1);
            Converter.ToBytes((uint) 0, buffer1, ref num1);
            Converter.ToBytes((uint) 0, buffer1, ref num1);
            Converter.ToBytes(base.X, buffer1, ref num1);
            Converter.ToBytes(base.Y, buffer1, ref num1);
            Converter.ToBytes(base.Z, buffer1, ref num1);
            Converter.ToBytes(base.Orientation, buffer1, ref num1);
            Converter.ToBytes((float) 0f, buffer1, ref num1);
            Converter.ToBytes((float) 1f, buffer1, ref num1);
            Converter.ToBytes((float) 1f, buffer1, ref num1);
            Converter.ToBytes((float) 1f, buffer1, ref num1);
            Converter.ToBytes((float) 1f, buffer1, ref num1);
            Converter.ToBytes((float) 1f, buffer1, ref num1);
            Converter.ToBytes((float) 1f, buffer1, ref num1);
            Converter.ToBytes((uint) 0, buffer1, ref num1);
            Converter.ToBytes((uint) 1, buffer1, ref num1);
            Converter.ToBytes((uint) 0, buffer1, ref num1);
            Converter.ToBytes((ulong) 0, buffer1, ref num1);
            base.ResetBitmap();
            base.setUpdateValue(0, base.Guid);
            base.setUpdateValue(2, (uint) 0x41);
            base.setUpdateValue(3, this.spell);
            base.setUpdateValue(4, (float) 1f);
            base.setUpdateValue(6, this.caster.Guid);
            base.setUpdateValue(8, (uint) 1);
            base.setUpdateValue(9, this.spell);
            base.setUpdateValue(10, this.radius);
            base.setUpdateValue(11, base.X);
            base.setUpdateValue(12, base.Y);
            base.setUpdateValue(13, base.Z);
            base.setUpdateValue(14, base.Orientation);
            base.FlushUpdateData(buffer1, ref num1, 1);
            this.caster.ToAllPlayerNear(OpCodes.SMSG_UPDATE_OBJECT, buffer1, num1);
        }

        public virtual void ToAllPlayerNear(OpCodes code, byte[] data)
        {
            this.caster.ToAllPlayerNear(code, data, data.Length);
        }


        // Fields
        private ArrayList aura;
        private Mobile caster;
        private float radius;
        private uint spell;
    }
}

