namespace Server
{
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct GQMenuItem
    {
        private uint _menuId;
        private DialogStatus _icon;
        private string _text;
        public GQMenuItem(uint menuId, DialogStatus icon, string text)
        {
            this._menuId = menuId;
            this._icon = icon;
            this._text = text;
        }
        public uint MenuId
        {
            get
            {
                return this._menuId;
            }
        }
        public byte Icon
        {
            get
            {
                return (byte) this._icon;
            }
        }
        public string Text
        {
            get
            {
                return this._text;
            }
        }
    }
}

