namespace Server
{
    using System;

    public class Vector
    {
        // Methods
        public Vector()
        {
        }

        public static float Angle(int d)
        {
            d &= 0x1ff;
            float single1 = d;
            single1 /= 256f;
            return (single1 * 3.141593f);
        }

        public static float Distance(ushort d)
        {
            d = (ushort) (d >> 9);
            float single1 = d;
            return (single1 / 4f);
        }

        public static float ToAngleDistance(float a, float dist)
        {
            a = a % 6.283185f;
            a /= 6.283185f;
            a *= 256f;
            int num1 = ((int) a) + 0x100;
            dist *= 4f;
            int num2 = (int) dist;
            num1 += (num2 << 9);
            return (float) ((ushort) num1);
        }

        public static ushort ToAngleDistance(float x1, float y1, float x2, float y2)
        {
            float single1 = (float) Math.Atan2((double) (y2 - y1), (double) (x2 - x1));
            x1 = x2 - x1;
            y1 = y2 - y1;
            float single2 = (float) Math.Sqrt((double) ((x1 * x1) + (y1 * y1)));
            if (single1 >= 6.2831853071795862)
            {
                single1 = single1 % 6.283185f;
            }
            else if (single1 < 0f)
            {
                single1 = 6.283185f - (-single1 % 6.283185f);
            }
            single1 /= 6.283185f;
            single1 *= 512f;
            int num1 = (int) single1;
            single2 *= 4f;
            int num2 = (int) single2;
            num1 += (num2 << 9);
            return (ushort) num1;
        }

        public static ushort[] Transform(Coord[] coords)
        {
            float single3;
            float single4;
            float single1 = coords[0].x;
            float single2 = coords[0].y;
            ushort[] numArray1 = new ushort[coords.Length - 1];
            for (int num1 = 1; num1 < coords.Length; num1++)
            {
                ushort num2 = Vector.ToAngleDistance(single1, single2, coords[num1].x, coords[num1].y);
                numArray1[num1 - 1] = num2;
                float single5 = single1 + (Vector.Distance(num2) * ((float) Math.Cos((double) Vector.Angle(num2))));
                float single6 = single2 + (Vector.Distance(num2) * ((float) Math.Sin((double) Vector.Angle(num2))));
                single1 = single5;
                single2 = single6;
                single3 = single1 - coords[num1].x;
                single4 = single2 - coords[num1].y;
            }
            single3 = single1 - coords[coords.Length - 1].x;
            single4 = single2 - coords[coords.Length - 1].y;
            Console.WriteLine("D\x00e9viation final : {0}", Math.Sqrt((double) ((single3 * single3) + (single4 * single4))));
            return numArray1;
        }

    }
}

