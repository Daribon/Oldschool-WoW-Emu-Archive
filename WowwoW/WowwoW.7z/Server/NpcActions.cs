namespace Server
{
    using System;

    public enum NpcActions : uint
    {
        // Fields
        Auctionner = 0x1000,
        Banker = 0x100,
        BattleFieldSpiritHealer = 0x40,
        BattleMaster = 0x800,
        Dialog = 2,
        Healer = 0x20,
        InKeeper = 0x80,
        Petition = 0x200,
        SpiritHealer = 1,
        StableMaster = 0x2000,
        Tabard = 0x400,
        Taxi = 8,
        Trainer = 0x10,
        Vendor = 4
    }
}

