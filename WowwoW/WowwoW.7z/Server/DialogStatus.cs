namespace Server
{
    using System;

    public enum DialogStatus : byte
    {
        // Fields
        ChatAvailable = 2,
        ChatUnAvailable = 0,
        None = 0,
        QuestUnAvailable = 1,
        QuestUnCompleate = 3,
        RepeatQuestCompleate = 4,
        SingleQuestAvailable = 5,
        SingleQuestCompleate = 6
    }
}

