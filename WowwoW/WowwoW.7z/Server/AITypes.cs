namespace Server
{
    using System;

    public enum AITypes
    {
        // Fields
        Beast = 1,
        Berserk = 3,
        Custom = 5,
        Marchant = 2,
        NonAgressiveAnimalAI = 0,
        Predator = 4
    }
}

