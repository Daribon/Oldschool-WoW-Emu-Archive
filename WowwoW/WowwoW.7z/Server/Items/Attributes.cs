namespace Server.Items
{
    using System;

    public enum Attributes
    {
        // Fields
        Agility = 3,
        Health = 1,
        Iq = 6,
        Mana = 0,
        Spirit = 5,
        Stamina = 7,
        Strenght = 4
    }
}

