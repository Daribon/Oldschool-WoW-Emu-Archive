namespace Server.Items
{
    using HelperTools;
    using Server;
    using System;
    using System.Collections;
    using System.Reflection;

    public class Item : Server.Object
    {
        // Methods
        static Item()
        {
            Item.skillIdAssoc = new Hashtable();
        }

        public Item()
        {
            this.resistance = new int[7];
            this.lockId = 0x700;
            this.nSpellAbility = 0;
            this.spells = new SpecialAbility[5];
            this.strBonus = 0;
            this.iqBonus = 0;
            this.spiritBonus = 0;
            this.agilityBonus = 0;
            this.staminaBonus = 0;
            this.manaBonus = 0;
            this.healthBonus = 0;
            this.itemDamages = new ItemDamage[7];
            Type type1 = base.GetType();
            ConstructorInfo[] infoArray1 = type1.GetConstructors();
            this.quickConstructor = infoArray1[0];
            Server.Object.GUID++;
            base.Guid = Server.Object.GUID + 0x4000000000000000;
        }

        public Item(Type type, int pos)
        {
            this.resistance = new int[7];
            this.lockId = 0x700;
            this.nSpellAbility = 0;
            this.spells = new SpecialAbility[5];
            this.strBonus = 0;
            this.iqBonus = 0;
            this.spiritBonus = 0;
            this.agilityBonus = 0;
            this.staminaBonus = 0;
            this.manaBonus = 0;
            this.healthBonus = 0;
            this.itemDamages = new ItemDamage[7];
        }

        public Item(int _model, InventoryTypes _inventoryType, int _objectclass, int _subclass, int _quality, int _sheath, int param1, int param2, int param3)
        {
            this.resistance = new int[7];
            this.lockId = 0x700;
            this.nSpellAbility = 0;
            this.spells = new SpecialAbility[5];
            this.strBonus = 0;
            this.iqBonus = 0;
            this.spiritBonus = 0;
            this.agilityBonus = 0;
            this.staminaBonus = 0;
            this.manaBonus = 0;
            this.healthBonus = 0;
            this.itemDamages = new ItemDamage[7];
            this.model = _model;
            this.inventoryType = _inventoryType;
            this.quality = _quality;
            this.subClass = _subclass;
            this.objectClass = _objectclass;
            this.sheath = _sheath;
        }

        public Item Clone()
        {
            return (Item) this.quickConstructor.Invoke(null);
        }

        private void Deserialize(GenericReader gr, bool fake)
        {
            gr.ReadInt();
            base.Guid = gr.ReadInt64();
            this.maxCount = gr.ReadInt();
        }

        public int GetSkillId()
        {
            object obj1 = Item.skillIdAssoc[(this.objectClass * 100) + this.subClass];
            if (obj1 == null)
            {
                return 0;
            }
            return (int) obj1;
        }

        public static Item Load(GenericReader gr)
        {
            string text1 = gr.ReadString();
            ConstructorInfo info1 = Utility.FindConstructor(text1, Utility.externAsmItem);
            Item item1 = (Item) info1.Invoke(null);
            item1.Deserialize(gr, true);
            return item1;
        }

        public void PrepareData(byte[] data, ref int offset)
        {
            Converter.ToBytes(this.id, data, ref offset);
            Converter.ToBytes(this.objectClass, data, ref offset);
            Converter.ToBytes(this.subClass, data, ref offset);
            Converter.ToBytes(this.name, data, ref offset);
            Converter.ToBytes((byte) 0, data, ref offset);
            if (this.name2 != null)
            {
                Converter.ToBytes(this.name2, data, ref offset);
            }
            else
            {
                Converter.ToBytes("", data, ref offset);
            }
            Converter.ToBytes((byte) 0, data, ref offset);
            Converter.ToBytes("", data, ref offset);
            Converter.ToBytes((byte) 0, data, ref offset);
            Converter.ToBytes("", data, ref offset);
            Converter.ToBytes((byte) 0, data, ref offset);
            Converter.ToBytes(this.model, data, ref offset);
            Converter.ToBytes(this.quality, data, ref offset);
            Converter.ToBytes(this.flags, data, ref offset);
            Converter.ToBytes(this.buyPrice, data, ref offset);
            Converter.ToBytes(this.sellPrice, data, ref offset);
            Converter.ToBytes((int) this.inventoryType, data, ref offset);
            Converter.ToBytes(this.availableClasses, data, ref offset);
            Converter.ToBytes(this.availableRaces, data, ref offset);
            Converter.ToBytes(this.level, data, ref offset);
            Converter.ToBytes(this.reqLevel, data, ref offset);
            Converter.ToBytes(this.skill, data, ref offset);
            Converter.ToBytes(this.skillRank, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(this.stackable, data, ref offset);
            Converter.ToBytes(this.containerSlots, data, ref offset);
            int num1 = 0;
            if (this.strBonus != 0)
            {
                Converter.ToBytes(4, data, ref offset);
                Converter.ToBytes(this.strBonus, data, ref offset);
                num1++;
            }
            if (this.iqBonus != 0)
            {
                Converter.ToBytes(6, data, ref offset);
                Converter.ToBytes(this.iqBonus, data, ref offset);
                num1++;
            }
            if (this.staminaBonus != 0)
            {
                Converter.ToBytes(7, data, ref offset);
                Converter.ToBytes(this.staminaBonus, data, ref offset);
                num1++;
            }
            if (this.spiritBonus != 0)
            {
                Converter.ToBytes(5, data, ref offset);
                Converter.ToBytes(this.spiritBonus, data, ref offset);
                num1++;
            }
            if (this.agilityBonus != 0)
            {
                Converter.ToBytes(3, data, ref offset);
                Converter.ToBytes(this.agilityBonus, data, ref offset);
                num1++;
            }
            if (this.manaBonus != 0)
            {
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(this.manaBonus, data, ref offset);
                num1++;
            }
            if (this.healthBonus != 0)
            {
                Converter.ToBytes(1, data, ref offset);
                Converter.ToBytes(this.healthBonus, data, ref offset);
                num1++;
            }
            for (int num2 = num1; num2 < 10; num2++)
            {
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
            }
            int num3 = 0;
            for (int num4 = 0; num4 < 7; num4++)
            {
                if (this.itemDamages[num4] != null)
                {
                    Converter.ToBytes(this.itemDamages[num4].MinDamage, data, ref offset);
                    Converter.ToBytes(this.itemDamages[num4].MaxDamage, data, ref offset);
                    Converter.ToBytes(num4, data, ref offset);
                    num3++;
                }
            }
            for (int num5 = num3; num5 < 5; num5++)
            {
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
            }
            Converter.ToBytes(this.resistance[0], data, ref offset);
            Converter.ToBytes(this.resistance[1], data, ref offset);
            Converter.ToBytes(this.resistance[2], data, ref offset);
            Converter.ToBytes(this.resistance[3], data, ref offset);
            Converter.ToBytes(this.resistance[4], data, ref offset);
            Converter.ToBytes(this.resistance[5], data, ref offset);
            Converter.ToBytes(this.resistance[6], data, ref offset);
            Converter.ToBytes(this.delay, data, ref offset);
            Converter.ToBytes(this.ammoType, data, ref offset);
            for (int num6 = 0; num6 < 5; num6++)
            {
                if (this.spells[num6] == null)
                {
                    Converter.ToBytes(-1, data, ref offset);
                    Converter.ToBytes(0, data, ref offset);
                    Converter.ToBytes(0, data, ref offset);
                    Converter.ToBytes(0, data, ref offset);
                    Converter.ToBytes(-1, data, ref offset);
                    Converter.ToBytes(0, data, ref offset);
                }
                else
                {
                    this.spells[num6].PrepareData(data, ref offset);
                }
            }
            Converter.ToBytes(this.bonding, data, ref offset);
            if (this.description != null)
            {
                Converter.ToBytes(this.description, data, ref offset);
                Converter.ToBytes((byte) 0, data, ref offset);
            }
            else
            {
                Converter.ToBytes((byte) 0, data, ref offset);
            }
            Converter.ToBytes(this.pageText, data, ref offset);
            Converter.ToBytes(this.language, data, ref offset);
            Converter.ToBytes(this.PageMaterial, data, ref offset);
            Converter.ToBytes(this.startQuest, data, ref offset);
            Converter.ToBytes(this.lockId, data, ref offset);
            Converter.ToBytes(this.material, data, ref offset);
            Converter.ToBytes(this.sheath, data, ref offset);
            Converter.ToBytes(this.ammoType, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
        }

        public void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, Character owner)
        {
            data[offset++] = 2;
            Converter.ToBytes(base.Guid, data, ref offset);
            if (this.IsContainer)
            {
                Converter.ToBytes((byte) 2, data, ref offset);
            }
            else
            {
                Converter.ToBytes((byte) 1, data, ref offset);
            }
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes((float) 2.5f, data, ref offset);
            Converter.ToBytes((float) 7f, data, ref offset);
            Converter.ToBytes((float) 2.5f, data, ref offset);
            Converter.ToBytes((float) 4.7222f, data, ref offset);
            Converter.ToBytes((float) 4.5f, data, ref offset);
            Converter.ToBytes((float) 3.141593f, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 1, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            int num1 = 0;
            base.ResetBitmap();
            base.setUpdateValue(0, base.Guid);
            if (this.IsContainer)
            {
                base.setUpdateValue(2, 7);
                base.setUpdateValue(3, this.Id);
                base.setUpdateValue(4, (float) 1f);
                base.setUpdateValue(6, owner.Guid);
                base.setUpdateValue(8, owner.Guid);
                base.setUpdateValue(14, this.MaxCount);
                base.setUpdateValue(num1 = 0x30, this.containerSlots);
                for (int num2 = 0x13; num2 < 0x17; num2++)
                {
                    if (owner.Items[num2] == this)
                    {
                        int num3 = ((num2 - 0x13) * 0x10) + 40;
                        for (int num4 = 0; num4 < 0x10; num4++)
                        {
                            if (owner.Items[num3 + num4] != null)
                            {
                                base.setUpdateValue(num1 = 50 + (num4 * 2), owner.Items[num4 + num3].Guid);
                            }
                        }
                    }
                }
            }
            else
            {
                base.setUpdateValue(2, 3);
                base.setUpdateValue(3, this.Id);
                base.setUpdateValue(4, (float) 1f);
                base.setUpdateValue(6, owner.Guid);
                base.setUpdateValue(8, owner.Guid);
                base.setUpdateValue(num1 = 14, this.MaxCount);
            }
            base.FlushUpdateData(data, ref offset, (num1 / 0x20) + 2);
        }

        public void SendSmallUpdate(int[] pos, object[] val, Character c)
        {
            int num1 = 4;
            byte[] buffer1 = c.tempBuff;
            buffer1[num1++] = 1;
            Converter.ToBytes(0, buffer1, ref num1);
            buffer1[num1++] = 0;
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            int num2 = 2 + ((pos[pos.Length - 1] + 1) / 0x20);
            if (num2 > 0x24)
            {
                num2 = 0x24;
            }
            buffer1[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank26, 0, buffer1, num1, Server.Object.Blank26.Length);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer2;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer2 = buffer1)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer2[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, buffer1, ref num1);
            }
            c.Send(OpCodes.SMSG_UPDATE_OBJECT, buffer1, num1);
        }

        public void SendTinyUpdate(int[] pos, object[] val, Character c)
        {
            int num1 = 4;
            byte[] buffer1 = new byte[0x80];
            buffer1[num1++] = 1;
            Converter.ToBytes(0, buffer1, ref num1);
            buffer1[num1++] = 0;
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            buffer1[num1++] = 2;
            int[] numArray1 = pos;
            int num6 = 0;
            while (num6 < numArray1.Length)
            {
                byte[] buffer2;
                IntPtr ptr1;
                int num2 = numArray1[num6];
                int num3 = num2;
                int num4 = num3 >> 3;
                int num5 = num3 & 7;
                num5 = 1 << (num5 & 0x1f);
                (buffer2 = buffer1)[(int) (ptr1 = (IntPtr) (num1 + num4))] = (byte) (buffer2[(int) ptr1] + ((byte) num5));
                num6++;
            }
            num1 += 8;
            object[] objArray1 = val;
            for (num6 = 0; num6 < objArray1.Length; num6++)
            {
                object obj1 = objArray1[num6];
                Converter.ToBytes(obj1, buffer1, ref num1);
            }
            c.Send(OpCodes.SMSG_UPDATE_OBJECT, buffer1, num1);
        }

        public override void Serialize(GenericWriter gw)
        {
            gw.Write(Utility.ClassName(this));
            gw.Write(0);
            gw.Write(base.Guid);
            gw.Write(this.maxCount);
        }

        public void SetBonus(int min, int max)
        {
            this.minBonus = min;
            this.maxBonus = max;
        }

        public void SetDamage(float min, float max, Resistances res)
        {
            this.itemDamages[(int) res] = new ItemDamage(min, max);
        }

        public void SetSpecialEffect(Mobile m)
        {
            SpecialAbility[] abilityArray1 = this.spells;
            for (int num1 = 0; num1 < abilityArray1.Length; num1++)
            {
                SpecialAbility ability1 = abilityArray1[num1];
                if ((ability1 != null) && (ability1.Trigger == 1))
                {
                    BaseAbility ability2 = ability1.Spell;
                    if (SpellTemplate.SpellEffects[(int) ability2.Id] is OnSelfItemSpellEffect)
                    {
                        (SpellTemplate.SpellEffects[(int) ability2.Id] as OnSelfItemSpellEffect)(ability2, m, ability1, this);
                    }
                    else if (SpellTemplate.SpellEffects[(int) ability2.Id] is SingleTargetSpellEffect)
                    {
                        (SpellTemplate.SpellEffects[(int) ability2.Id] as SingleTargetSpellEffect)(ability2, m, m);
                    }
                }
            }
        }

        public void SetSpell(int p1, int p2, int p3, int p4, int p5, int p6)
        {
            this.spells[this.nSpellAbility++] = new SpecialAbility(p1, p2, p3, p4, p5, p6, 1f);
        }

        public void SetSpell(int p1, int p2, int p3, int p4, int p5, int p6, float prob)
        {
            this.spells[this.nSpellAbility++] = new SpecialAbility(p1, p2, p3, p4, p5, p6, prob);
        }

        public static Slots SlotNum(byte a, byte b)
        {
            int num1 = 0;
            if (a == 0xff)
            {
                num1 = b;
            }
            else
            {
                num1 = ((b + 0x18) + 0x10) + ((a - 0x13) * 0x10);
            }
            return (Slots) num1;
        }

        public SpecialAbility Spells(int n)
        {
            return this.spells[n];
        }

        public void TriggerOnHit(Mobile from, Mobile target)
        {
            SpecialAbility[] abilityArray1 = this.spells;
            for (int num1 = 0; num1 < abilityArray1.Length; num1++)
            {
                SpecialAbility ability1 = abilityArray1[num1];
                if (((ability1 != null) && (ability1.Trigger == 2)) && (ability1.Proba > ((float) Utility.RandomDouble())))
                {
                    BaseAbility ability2 = ability1.Spell;
                    if (SpellTemplate.SpellEffects[(int) ability2.Id] is OnSelfItemSpellEffect)
                    {
                        (SpellTemplate.SpellEffects[(int) ability2.Id] as OnSelfItemSpellEffect)(ability2, from, ability1, this);
                    }
                    else if (SpellTemplate.SpellEffects[(int) ability2.Id] is OnSingleTargetItemSpellEffect)
                    {
                        (SpellTemplate.SpellEffects[(int) ability2.Id] as OnSingleTargetItemSpellEffect)(ability2, from, target, ability1, this);
                    }
                }
            }
        }


        // Properties
        public int AgilityBonus
        {
            get
            {
                return this.agilityBonus;
            }
            set
            {
                this.agilityBonus = value;
            }
        }

        public int AmmoType
        {
            get
            {
                return this.ammoType;
            }
            set
            {
                this.ammoType = value;
            }
        }

        public int AvailableClasses
        {
            get
            {
                return this.availableClasses;
            }
            set
            {
                this.availableClasses = value;
            }
        }

        public int AvailableRaces
        {
            get
            {
                return this.availableRaces;
            }
            set
            {
                this.availableRaces = value;
            }
        }

        public int Block
        {
            get
            {
                return this.block;
            }
            set
            {
                this.block = value;
            }
        }

        public int Bonding
        {
            get
            {
                return this.bonding;
            }
            set
            {
                this.bonding = value;
            }
        }

        public int BuyPrice
        {
            get
            {
                return this.buyPrice;
            }
            set
            {
                this.buyPrice = value;
            }
        }

        public Slots CanBeEquipedIn
        {
            get
            {
                if (this.inventoryType > InventoryTypes.None)
                {
                    switch (this.InventoryType)
                    {
                        case InventoryTypes.Head:
                        {
                            return Slots.Head;
                        }
                        case InventoryTypes.Neck:
                        {
                            return Slots.Neck;
                        }
                        case InventoryTypes.Shoulder:
                        {
                            return Slots.Shoulders;
                        }
                        case InventoryTypes.Shirt:
                        {
                            return Slots.Shirt;
                        }
                        case InventoryTypes.Chest:
                        {
                            return Slots.Chest;
                        }
                        case InventoryTypes.Waist:
                        {
                            return Slots.Waist;
                        }
                        case InventoryTypes.Legs:
                        {
                            return Slots.Legs;
                        }
                        case InventoryTypes.Feet:
                        {
                            return Slots.Feet;
                        }
                        case InventoryTypes.Wrist:
                        {
                            return Slots.Wrists;
                        }
                        case InventoryTypes.Hands:
                        {
                            return Slots.Hands;
                        }
                        case InventoryTypes.Finger:
                        {
                            return Slots.FingerLeft;
                        }
                        case InventoryTypes.Trinket1:
                        {
                            return Slots.TrinketLeft;
                        }
                        case InventoryTypes.MainGauche:
                        case InventoryTypes.Shield:
                        case InventoryTypes.OffHand:
                        {
                            return Slots.OffHand;
                        }
                        case InventoryTypes.Ranged:
                        case InventoryTypes.Thrown:
                        case InventoryTypes.RangeRight:
                        {
                            return Slots.Ranged;
                        }
                        case InventoryTypes.Back:
                        {
                            return Slots.Back;
                        }
                        case InventoryTypes.TwoHanded:
                        case InventoryTypes.OneHand:
                        {
                            return Slots.MainHand;
                        }
                        case InventoryTypes.Tabard:
                        {
                            return Slots.Tabard;
                        }
                        case InventoryTypes.Robe:
                        {
                            return Slots.Chest;
                        }
                    }
                }
                return Slots.None;
            }
        }

        public int ContainerSlots
        {
            get
            {
                return this.containerSlots;
            }
            set
            {
                this.containerSlots = value;
            }
        }

        public int Delay
        {
            get
            {
                return this.delay;
            }
            set
            {
                this.delay = value;
            }
        }

        public string Description
        {
            get
            {
                return this.description;
            }
            set
            {
                this.description = value;
            }
        }

        public int Durability
        {
            get
            {
                return this.durability;
            }
            set
            {
                this.durability = value;
            }
        }

        public int Extra
        {
            get
            {
                return this.extra;
            }
            set
            {
                this.extra = value;
            }
        }

        public int Flags
        {
            get
            {
                return this.flags;
            }
            set
            {
                this.flags = value;
            }
        }

        public int HealthBonus
        {
            get
            {
                return this.healthBonus;
            }
            set
            {
                this.healthBonus = value;
            }
        }

        public int Id
        {
            get
            {
                return this.id;
            }
            set
            {
                this.id = value;
            }
        }

        public InventoryTypes InventoryType
        {
            get
            {
                return this.inventoryType;
            }
            set
            {
                this.inventoryType = value;
            }
        }

        public int IqBonus
        {
            get
            {
                return this.iqBonus;
            }
            set
            {
                this.iqBonus = value;
            }
        }

        public bool IsContainer
        {
            get
            {
                if (this.containerSlots > 0)
                {
                    return true;
                }
                return false;
            }
        }

        public bool IsQuestItem
        {
            get
            {
                if ((((this.objectClass == 7) || (this.objectClass == 12)) || (this.objectClass == 15)) && (this.subClass == 0))
                {
                    return true;
                }
                return false;
            }
        }

        public bool IsShield
        {
            get
            {
                if ((this.ObjectClass == 4) && (this.SubClass == 6))
                {
                    return true;
                }
                return false;
            }
        }

        public bool IsWeapon
        {
            get
            {
                if (this.objectClass == 2)
                {
                    return true;
                }
                return false;
            }
        }

        public int Language
        {
            get
            {
                return this.language;
            }
            set
            {
                this.language = value;
            }
        }

        public int Level
        {
            get
            {
                return this.level;
            }
            set
            {
                this.level = value;
            }
        }

        public int LockId
        {
            get
            {
                return this.lockId;
            }
            set
            {
                this.lockId = value;
            }
        }

        public int ManaBonus
        {
            get
            {
                return this.manaBonus;
            }
            set
            {
                this.manaBonus = value;
            }
        }

        public int Material
        {
            get
            {
                return this.material;
            }
            set
            {
                this.material = value;
            }
        }

        public int MaxCount
        {
            get
            {
                return this.maxCount;
            }
            set
            {
                this.maxCount = value;
            }
        }

        public int Model
        {
            get
            {
                return this.model;
            }
            set
            {
                this.model = value;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public string Name2
        {
            get
            {
                return this.name2;
            }
            set
            {
                this.name2 = value;
            }
        }

        public int ObjectClass
        {
            get
            {
                return this.objectClass;
            }
            set
            {
                this.objectClass = value;
            }
        }

        public int PageMaterial
        {
            get
            {
                return this.pageMaterial;
            }
            set
            {
                this.pageMaterial = value;
            }
        }

        public int PageText
        {
            get
            {
                return this.pageText;
            }
            set
            {
                this.pageText = value;
            }
        }

        public float PhysicalMaxDamage
        {
            get
            {
                if (this.itemDamages[0] == null)
                {
                    Console.WriteLine("The object {0} do not have physical damage, please contact DrNexus !!!!!", this.ToString());
                    return 1f;
                }
                return this.itemDamages[0].MaxDamage;
            }
        }

        public float PhysicalMinDamage
        {
            get
            {
                if (this.itemDamages[0] == null)
                {
                    Console.WriteLine("The object {0} do not have physical damage, please contact DrNexus !!!!!", this.ToString());
                    return 1f;
                }
                return this.itemDamages[0].MinDamage;
            }
        }

        public int Quality
        {
            get
            {
                return this.quality;
            }
            set
            {
                this.quality = value;
            }
        }

        public string QuestName
        {
            get
            {
                return this.questName;
            }
            set
            {
                this.questName = value;
            }
        }

        public int ReqLevel
        {
            get
            {
                return this.reqLevel;
            }
            set
            {
                this.reqLevel = value;
            }
        }

        public int[] Resistance
        {
            get
            {
                return this.resistance;
            }
            set
            {
                this.resistance = value;
            }
        }

        public int SellPrice
        {
            get
            {
                return this.sellPrice;
            }
            set
            {
                this.sellPrice = value;
            }
        }

        public int Sets
        {
            get
            {
                return this.sets;
            }
            set
            {
                this.sets = value;
            }
        }

        public int Sheath
        {
            get
            {
                return this.sheath;
            }
            set
            {
                this.sheath = value;
            }
        }

        public int Skill
        {
            get
            {
                return this.skill;
            }
            set
            {
                this.skill = value;
            }
        }

        public int SkillRank
        {
            get
            {
                return this.skillRank;
            }
            set
            {
                this.skillRank = value;
            }
        }

        public int SpellReq
        {
            get
            {
                return this.spellreq;
            }
            set
            {
                this.spellreq = value;
            }
        }

        public int SpiritBonus
        {
            get
            {
                return this.spiritBonus;
            }
            set
            {
                this.spiritBonus = value;
            }
        }

        public int Stackable
        {
            get
            {
                return this.stackable;
            }
            set
            {
                this.stackable = value;
            }
        }

        public int StaminaBonus
        {
            get
            {
                return this.staminaBonus;
            }
            set
            {
                this.staminaBonus = value;
            }
        }

        public int StartQuest
        {
            get
            {
                return this.startQuest;
            }
            set
            {
                this.startQuest = value;
            }
        }

        public int StrBonus
        {
            get
            {
                return this.strBonus;
            }
            set
            {
                this.strBonus = value;
            }
        }

        public int SubClass
        {
            get
            {
                return this.subClass;
            }
            set
            {
                this.subClass = value;
            }
        }

        public int Unk1
        {
            get
            {
                return this.unk1;
            }
            set
            {
                this.unk1 = value;
            }
        }


        // Fields
        private int agilityBonus;
        private int ammoType;
        private int availableClasses;
        private int availableRaces;
        private int block;
        private int bonding;
        private int buyPrice;
        private int containerSlots;
        private int delay;
        private string description;
        private int durability;
        private int extra;
        private int flags;
        private int healthBonus;
        private int id;
        private InventoryTypes inventoryType;
        private int iqBonus;
        private ItemDamage[] itemDamages;
        private int language;
        private int level;
        private int lockId;
        private int manaBonus;
        private int material;
        private int maxBonus;
        private int maxCount;
        private float maxDamage;
        private int minBonus;
        private float minDamage;
        private int model;
        private string name;
        private string name2;
        private int nSpellAbility;
        private int objectClass;
        private int pageMaterial;
        private int pageText;
        private int quality;
        private string questName;
        private ConstructorInfo quickConstructor;
        private int reqLevel;
        private int[] resistance;
        private int sellPrice;
        private int sets;
        private int sheath;
        private int skill;
        public static Hashtable skillIdAssoc;
        private int skillRank;
        private int spellreq;
        private SpecialAbility[] spells;
        private int spiritBonus;
        private int stackable;
        private int staminaBonus;
        private int startQuest;
        private int strBonus;
        private int subClass;
        private int unk1;

        // Nested Types
        public class ItemDamage
        {
            // Methods
            public ItemDamage()
            {
            }

            public ItemDamage(float min, float max)
            {
                this.minDamage = min;
                this.maxDamage = max;
            }


            // Properties
            public float MaxDamage
            {
                get
                {
                    return this.maxDamage;
                }
            }

            public float MinDamage
            {
                get
                {
                    return this.minDamage;
                }
            }


            // Fields
            private float maxDamage;
            private float minDamage;
        }

        public class SpecialAbility
        {
            // Methods
            public SpecialAbility(int p1, int p2, int p3, int p4, int p5, int p6)
            {
                this.id = p1;
                this.trigger = p2;
                this.charges = p3;
                this.cooldown = p4;
                this.category = p5;
                this.categoryCooldown = p6;
                this.proba = 1f;
            }

            public SpecialAbility(int p1, int p2, int p3, int p4, int p5, int p6, float prob)
            {
                this.id = p1;
                this.trigger = p2;
                this.charges = p3;
                this.cooldown = p4;
                this.category = p5;
                this.categoryCooldown = p6;
                this.proba = prob;
            }

            public void PrepareData(byte[] data, ref int offset)
            {
                Converter.ToBytes(this.id, data, ref offset);
                Converter.ToBytes(this.trigger, data, ref offset);
                Converter.ToBytes(this.charges, data, ref offset);
                Converter.ToBytes(this.cooldown, data, ref offset);
                Converter.ToBytes(this.category, data, ref offset);
                Converter.ToBytes(this.categoryCooldown, data, ref offset);
            }


            // Properties
            public Aura ActiveAura
            {
                get
                {
                    return this.aura;
                }
                set
                {
                    this.aura = value;
                }
            }

            public float Proba
            {
                get
                {
                    return this.proba;
                }
            }

            public BaseAbility Spell
            {
                get
                {
                    return Abilities.abilities[this.id];
                }
            }

            public int Trigger
            {
                get
                {
                    return this.trigger;
                }
            }


            // Fields
            private Aura aura;
            private int category;
            private int categoryCooldown;
            private int charges;
            private int cooldown;
            private int id;
            private float proba;
            private int trigger;
        }
    }
}

