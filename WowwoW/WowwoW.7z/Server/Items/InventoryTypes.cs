namespace Server.Items
{
    using System;

    public enum InventoryTypes
    {
        // Fields
        Back = 0x10,
        Bag = 0x12,
        Chest = 5,
        Feet = 8,
        Finger = 11,
        Hands = 10,
        Head = 1,
        HeldInHand = 0x17,
        Junk = 0x12,
        Legs = 7,
        MainGauche = 13,
        Neck = 2,
        None = 0,
        OffHand = 0x16,
        OneHand = 0x15,
        Projectile = 0x18,
        Ranged = 15,
        RangeRight = 0x1a,
        Robe = 20,
        Shield = 14,
        Shirt = 4,
        Shoulder = 3,
        Tabard = 0x13,
        Thrown = 0x19,
        Trinket1 = 12,
        TwoHanded = 0x11,
        Waist = 6,
        Wrist = 9
    }
}

