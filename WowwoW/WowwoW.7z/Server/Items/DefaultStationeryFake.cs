namespace Server.Items
{
    using System;

    public class DefaultStationeryFake : Item
    {
        // Methods
        public DefaultStationeryFake()
        {
            base.AvailableRaces = 0x1ff;
            base.SubClass = 0;
            base.Material = -1;
            base.PageMaterial = 1;
            base.Stackable = 1;
            base.Model = 0x1e76;
            base.ObjectClass = 0;
            base.Name = "Default Stationery";
            base.AvailableClasses = 0x7fff;
            base.Quality = 1;
            base.Id = 0x245f;
        }

    }
}

