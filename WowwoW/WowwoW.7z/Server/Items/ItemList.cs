namespace Server.Items
{
    using System;
    using System.Collections;
    using System.Reflection;

    [Serializable]
    public class ItemList : CollectionBase
    {
        // Methods
        public ItemList()
        {
        }

        public ItemList(ItemList val)
        {
            this.AddRange(val);
        }

        public ItemList(Item[] val)
        {
            this.AddRange(val);
        }

        public int Add(Item val)
        {
            return base.List.Add(val);
        }

        public void AddRange(Item[] val)
        {
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void AddRange(ItemList val)
        {
            for (int num1 = 0; num1 < val.Count; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public bool Contains(Item val)
        {
            return base.List.Contains(val);
        }

        public void CopyTo(Item[] array, int index)
        {
            base.List.CopyTo(array, index);
        }

        public new ItemEnumerator GetEnumerator()
        {
            return new ItemEnumerator(this);
        }

        public int IndexOf(Item val)
        {
            return base.List.IndexOf(val);
        }

        public void Insert(int index, Item val)
        {
            base.List.Insert(index, val);
        }

        public void Remove(Item val)
        {
            base.List.Remove(val);
        }


        // Properties
        public Item this[int index]
        {
            get
            {
                return (Item) base.List[index];
            }
            set
            {
                base.List[index] = value;
            }
        }


        // Nested Types
        public class ItemEnumerator : IEnumerator
        {
            // Methods
            public ItemEnumerator(ItemList mappings)
            {
                this.temp = mappings;
                this.baseEnumerator = this.temp.GetEnumerator();
            }

            public bool MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            public void Reset()
            {
                this.baseEnumerator.Reset();
            }

            bool IEnumerator.MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            void IEnumerator.Reset()
            {
                this.baseEnumerator.Reset();
            }


            // Properties
            public Item Current
            {
                get
                {
                    return (Item) this.baseEnumerator.Current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.baseEnumerator.Current;
                }
            }


            // Fields
            private IEnumerator baseEnumerator;
            private IEnumerable temp;
        }
    }
}

