namespace Server.Items
{
    using System;

    public class Money : Item
    {
        // Methods
        public Money()
        {
        }

    }
}

