namespace Server.Items
{
    using System;

    public class TestStationeryFake : Item
    {
        // Methods
        public TestStationeryFake()
        {
            base.BuyPrice = 10;
            base.SubClass = 0;
            base.Material = -1;
            base.Stackable = 10;
            base.Model = 0x42d;
            base.ObjectClass = 0;
            base.Name = "Test Stationery";
            base.AvailableClasses = 0x7fff;
            base.Quality = 1;
            base.SellPrice = 2;
            base.AvailableRaces = 0x1ff;
            base.Id = 0x1fe4;
        }

    }
}

