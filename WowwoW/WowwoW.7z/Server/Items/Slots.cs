namespace Server.Items
{
    using System;

    public enum Slots
    {
        // Fields
        Back = 14,
        Bag1 = 0x13,
        Bag2 = 20,
        Bag3 = 0x15,
        Bag4 = 0x16,
        Bag5 = 0x17,
        Chest = 4,
        Feet = 7,
        FingerLeft = 10,
        FingerRight = 11,
        Hands = 9,
        Head = 0,
        Legs = 6,
        MainHand = 15,
        Neck = 1,
        None = -1,
        OffHand = 0x10,
        Ranged = 0x11,
        Shirt = 3,
        Shoulders = 2,
        Tabard = 0x12,
        TrinketLeft = 12,
        TrinketRight = 13,
        Waist = 5,
        Wrists = 8
    }
}

