namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool LevelUp(Character c, int level, ref int gainHp, ref int gainMana, ref float gainStrength, ref float gainAgility, ref float gainStamina, ref float gainInt, ref float gainSpirit);

}

