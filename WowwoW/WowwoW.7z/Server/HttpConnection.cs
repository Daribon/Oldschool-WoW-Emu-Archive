namespace Server
{
    using HelperTools;
    using Microsoft.CSharp;
    using System;
    using System.CodeDom.Compiler;
    using System.IO;
    using System.Net.Sockets;
    using System.Reflection;

    public class HttpConnection : SockClient
    {
        // Methods
        public HttpConnection(Socket sock, RemoveClientDelegate rcd) : base(sock, rcd)
        {
            this.state = 0;
        }

        public override byte[] ProcessDataReceived(byte[] data, int length)
        {
            object[] objArray1 = new object[4] { "", '\r', "", '\n' } ;
            string text1 = string.Concat(objArray1);
            if ((World.AllowHttpFrom != "0.0.0.0") && (World.AllowHttpFrom != base.IP.ToString()))
            {
                this.Send403();
                return null;
            }
            if (World.onHttpDataReceived(this, data, length))
            {
                try
                {
                    string[] textArray3;
                    string text2 = "";
                    for (int num1 = 0; num1 < length; num1++)
                    {
                        text2 = text2 + "" + ((char) data[num1]);
                    }
                    char[] chArray1 = new char[1] { ' ' } ;
                    string[] textArray1 = text2.Split(chArray1);
                    if ((textArray1[0] == "POST") && (textArray1[1] == "/account.htm"))
                    {
                        int num2 = text2.IndexOf("username=");
                        text2.IndexOf("password=");
                        string text3 = text2.Substring(num2);
                        chArray1 = new char[1] { '&' } ;
                        string[] textArray2 = text3.Split(chArray1);
                        text3 = textArray2[0].Substring(9);
                        string text4 = textArray2[1].Substring(9);
                        if ((text3.Length <= 12) && (text4.Length <= 12))
                        {
                            Account account1 = new Account(text3, text4, AccessLevels.PlayerLevel);
                            Account account2 = World.allAccounts.FindByUserName(text3.ToUpper());
                            if (account2 == null)
                            {
                                World.allAccounts.Add(account1);
                                TextReader reader1 = new StreamReader("./http/accountcreated.htm");
                                string text5 = reader1.ReadToEnd();
                                reader1.Close();
                                textArray3 = new string[0x13] { 
                                    "HTTP/1.1 200 OK", text1, "Date: ", DateTime.Now.ToString("r"), text1, "Server: Dr Nexus 0.1a", text1, "X-Powered-By: Dr Nexus", text1, "Cache-Control: private", text1, "Connection: close", text1, "Content-Length: ", text5.Length.ToString(), text1, 
                                    "Content-Type: text/html", text1, text1
                                 } ;
                                string text6 = string.Concat(textArray3);
                                string text7 = text6 + text5;
                                this.Send(text7);
                                return null;
                            }
                            World.allAccounts.Add(account1);
                            TextReader reader2 = new StreamReader("./http/accounterror.htm");
                            string text8 = reader2.ReadToEnd();
                            reader2.Close();
                            textArray3 = new string[0x13] { 
                                "HTTP/1.1 200 OK", text1, "Date: ", DateTime.Now.ToString("r"), text1, "Server: Dr Nexus 0.1a", text1, "X-Powered-By: Dr Nexus", text1, "Cache-Control: private", text1, "Connection: close", text1, "Content-Length: ", text8.Length.ToString(), text1, 
                                "Content-Type: text/html", text1, text1
                             } ;
                            string text9 = string.Concat(textArray3);
                            string text10 = text9 + text8;
                            this.Send(text10);
                        }
                        return null;
                    }
                    if (textArray1[0] == "GET")
                    {
                        if (textArray1[1] == "/status.htm")
                        {
                            TextReader reader3 = new StreamReader("./http/status.htm");
                            string text11 = reader3.ReadToEnd();
                            reader3.Close();
                            string text12 = "";
                            string text13 = "";
                            for (int num3 = 0; num3 < text11.Length; num3++)
                            {
                                if ((text11[num3] == '<') && (this.state == 0))
                                {
                                    this.state = 1;
                                }
                                else if ((text11[num3] == '?') && (this.state == 1))
                                {
                                    this.state = 2;
                                }
                                else if ((text11[num3] == '?') && (this.state == 2))
                                {
                                    this.state = 3;
                                }
                                else if ((text11[num3] == '>') && (this.state == 3))
                                {
                                    this.state = 0;
                                    text13 = "using System;using System.Collections;using Server.Items;using HelperTools; namespace Server { " + text13 + " }";
                                    CSharpCodeProvider provider1 = new CSharpCodeProvider();
                                    ICodeCompiler compiler1 = provider1.CreateCompiler();
                                    CompilerParameters parameters1 = new CompilerParameters();
                                    parameters1.GenerateExecutable = false;
                                    parameters1.GenerateInMemory = true;
                                    parameters1.MainClass = "";
                                    Assembly[] assemblyArray1 = AppDomain.CurrentDomain.GetAssemblies();
                                    for (int num4 = 0; num4 < assemblyArray1.Length; num4++)
                                    {
                                        Assembly assembly1 = assemblyArray1[num4];
                                        parameters1.ReferencedAssemblies.Add(assembly1.Location);
                                    }
                                    parameters1.IncludeDebugInformation = false;
                                    CompilerResults results1 = compiler1.CompileAssemblyFromSource(parameters1, text13);
                                    if (results1.Errors.Count > 0)
                                    {
                                        string text14 = "Compilation failed:\n";
                                        foreach (CompilerError error1 in results1.Errors)
                                        {
                                            text14 = text14 + error1.ToString() + "\n";
                                        }
                                        text12 = text12 + "<p>" + text14 + "</p>";
                                    }
                                    else
                                    {
                                        Assembly assembly2 = results1.CompiledAssembly;
                                        ConstructorInfo info1 = Utility.FindConstructor("HttpHandler", assembly2);
                                        BaseHttpHandler handler1 = (BaseHttpHandler) info1.Invoke(null);
                                        text12 = text12 + handler1.Get();
                                    }
                                }
                                else if (this.state == 2)
                                {
                                    text13 = text13 + text11[num3];
                                }
                                else
                                {
                                    if (this.state == 1)
                                    {
                                        text12 = text12 + "<";
                                    }
                                    this.state = 0;
                                    text12 = text12 + text11[num3];
                                }
                            }
                            textArray3 = new string[0x13] { 
                                "HTTP/1.1 200 OK", text1, "Date: ", DateTime.Now.ToString("r"), text1, "Server: Dr Nexus 0.1a", text1, "X-Powered-By: Dr Nexus", text1, "Cache-Control: private", text1, "Connection: close", text1, "Content-Length: ", text12.Length.ToString(), text1, 
                                "Content-Type: text/html", text1, text1
                             } ;
                            string text15 = string.Concat(textArray3);
                            this.Send(text15 + text12);
                            return null;
                        }
                        if (textArray1[1] == "/account.htm")
                        {
                            TextReader reader4 = new StreamReader("./http/account.htm");
                            string text16 = reader4.ReadToEnd();
                            reader4.Close();
                            textArray3 = new string[0x13] { 
                                "HTTP/1.1 200 OK", text1, "Date: ", DateTime.Now.ToString("r"), text1, "Server: Dr Nexus 0.1a", text1, "X-Powered-By: Dr Nexus", text1, "Cache-Control: private", text1, "Connection: close", text1, "Content-Length: ", text16.Length.ToString(), text1, 
                                "Content-Type: text/html", text1, text1
                             } ;
                            string text17 = string.Concat(textArray3);
                            this.Send(text17 + text16);
                            return null;
                        }
                        this.Send404();
                    }
                }
                catch (Exception)
                {
                }
                this.Send403();
            }
            return null;
        }

        public void Send403()
        {
            this.SendError(0x193, "Forbidden", "You don't have permission to access this page on this server");
        }

        public void Send404()
        {
            this.SendError(0x194, "Not Found", "The page cannot be found");
        }

        public void SendError(int num, string title, string msg)
        {
            object[] objArray1 = new object[4] { "", '\r', "", '\n' } ;
            string text1 = string.Concat(objArray1);
            string[] textArray1 = new string[13] { "137", text1, "<!DOCTYPE HTML PUBLIC \"-//IETF//DTD HTML 2.0//EN\">.<HTML><HEAD>.<TITLE>", num.ToString(), title, "</TITLE>.</HEAD><BODY>.<H1>", title, "</H1>", msg, "<P>.<HR></BODY></HTML>", text1, "0", text1 } ;
            string text2 = string.Concat(textArray1);
            textArray1 = new string[0x16] { 
                "HTTP/1.1 ", num.ToString(), " ", title, text1, "Date: ", DateTime.Now.ToString("r"), text1, "Server: Dr Nexus 0.1a", text1, "X-Powered-By: Dr Nexus", text1, "Cache-Control: private", text1, "Connection: close", text1, 
                "Content-Length: ", text2.Length.ToString(), text1, "Content-Type: text/html", text1, text1
             } ;
            string text3 = string.Concat(textArray1);
            this.Send(text3);
            this.Send(text2);
        }


        // Fields
        private int state;
    }
}

