namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public class TalentHandlers
    {
        // Methods
        public TalentHandlers()
        {
        }


        // Nested Types
        public delegate void TalentHandler(BaseAbility ba, Mobile src);

    }
}

