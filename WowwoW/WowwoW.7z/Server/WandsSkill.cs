namespace Server
{
    using System;

    public class WandsSkill : Skill
    {
        // Methods
        public WandsSkill()
        {
        }

        public WandsSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xe4;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xe4;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x1391;
            }
        }

    }
}

