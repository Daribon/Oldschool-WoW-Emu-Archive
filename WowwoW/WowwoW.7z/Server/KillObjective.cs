namespace Server
{
    using System;
    using System.Reflection;

    public class KillObjective
    {
        // Methods
        public KillObjective(Type t, int a)
        {
            this.type = t;
            this.amount = a;
        }

        public KillObjective GetKillObjective(int id, int a)
        {
            return new KillObjective(World.MobileTypeById(id), a);
        }


        // Properties
        public int Amount
        {
            get
            {
                return this.amount;
            }
        }

        public int Id
        {
            get
            {
                ConstructorInfo[] infoArray1 = this.type.GetConstructors();
                Mobile mobile1 = (Mobile) infoArray1[0].Invoke(null);
                return mobile1.Id;
            }
        }


        // Fields
        private int amount;
        private Type type;
    }
}

