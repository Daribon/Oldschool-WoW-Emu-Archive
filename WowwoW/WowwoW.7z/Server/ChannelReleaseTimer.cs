namespace Server
{
    using HelperTools;
    using System;

    public class ChannelReleaseTimer : WowTimer
    {
        // Methods
        public ChannelReleaseTimer(Mobile _caster, long _duration) : base(WowTimer.Priorities.Milisec100, (double) _duration)
        {
            this.caster = _caster;
        }

        public override void OnTick()
        {
            object[] objArray1 = new object[3] { 0, 0, 0 } ;
            this.caster.SendSmallUpdateToPlayerNearMe(new int[3] { 20, 0x15, 0x95 } , objArray1);
            base.Stop();
        }


        // Fields
        private Mobile caster;
    }
}

