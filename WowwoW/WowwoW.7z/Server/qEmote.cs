namespace Server
{
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct qEmote
    {
        private Emote _emote;
        private int _delay;
        public qEmote(Emote e, int msec_delay)
        {
            this._emote = e;
            this._delay = msec_delay;
        }
        public Emote emote
        {
            get
            {
                return this._emote;
            }
        }
        public int Delay
        {
            get
            {
                return this._delay;
            }
        }
    }
}

