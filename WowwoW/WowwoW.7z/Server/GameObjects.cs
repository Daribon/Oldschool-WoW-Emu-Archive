namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Reflection;

    [Serializable]
    public class GameObjects : CollectionBase
    {
        // Methods
        static GameObjects()
        {
            GameObjects.TempSpawner = new Hashtable();
        }

        public GameObjects()
        {
            this.dirty = false;
        }

        public GameObjects(GenericReader gr)
        {
            this.dirty = false;
            base.List.Clear();
            if (!gr.notFound)
            {
                this.Deserialize(gr);
            }
        }

        public GameObjects(GameObjects val)
        {
            this.dirty = false;
            this.dirty = true;
            this.AddRange(val);
        }

        public GameObjects(GameObject[] val)
        {
            this.dirty = false;
            this.dirty = true;
            this.AddRange(val);
        }

        public int Add(GameObject val)
        {
            this.dirty = true;
            return base.List.Add(val);
        }

        public void AddRange(GameObject[] val)
        {
            this.dirty = true;
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void AddRange(GameObjects val)
        {
            this.dirty = true;
            for (int num1 = 0; num1 < val.Count; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public bool Contains(GameObject val)
        {
            return base.List.Contains(val);
        }

        public void CopyTo(GameObject[] array, int index)
        {
            this.dirty = true;
            base.List.CopyTo(array, index);
        }

        public virtual void Deserialize(GenericReader gr)
        {
            GameObjects.TempSpawner[0] = null;
            gr.ReadInt();
            while (true)
            {
                int num1 = gr.ReadInt();
                if (num1 == 0)
                {
                    break;
                }
                this.Add(new GameObject(gr));
            }
            gr.Close();
            GameObjects.TempSpawner.Clear();
            GameObjects.TempSpawner = null;
        }

        public new GameObjectEnumerator GetEnumerator()
        {
            return new GameObjectEnumerator(this);
        }

        public int IndexOf(GameObject val)
        {
            return base.List.IndexOf(val);
        }

        public void Insert(int index, GameObject val)
        {
            this.dirty = true;
            base.List.Insert(index, val);
        }

        public void Remove(GameObject val)
        {
            this.dirty = true;
            base.List.Remove(val);
        }

        public virtual void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            foreach (GameObject obj1 in this)
            {
                if (obj1.SpawnerLink == null)
                {
                    gw.Write(1);
                    obj1.Serialize(gw);
                }
            }
            gw.Write(0);
            gw.Close();
            this.dirty = false;
        }


        // Properties
        public bool Dirty
        {
            get
            {
                return this.dirty;
            }
        }

        public GameObject this[int index]
        {
            get
            {
                return (GameObject) base.List[index];
            }
            set
            {
                this.dirty = true;
                base.List[index] = value;
            }
        }


        // Fields
        private bool dirty;
        public static Hashtable TempSpawner;

        // Nested Types
        public class GameObjectEnumerator : IEnumerator
        {
            // Methods
            public GameObjectEnumerator(GameObjects mappings)
            {
                this.temp = mappings;
                this.baseEnumerator = this.temp.GetEnumerator();
            }

            public bool MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            public void Reset()
            {
                this.baseEnumerator.Reset();
            }


            // Properties
            public GameObject Current
            {
                get
                {
                    return (GameObject) this.baseEnumerator.Current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.baseEnumerator.Current;
                }
            }


            // Fields
            private IEnumerator baseEnumerator;
            private IEnumerable temp;
        }
    }
}

