namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;

    public class Profession : Skill
    {
        // Methods
        public Profession()
        {
        }

        public Profession(ProfessionLevels t, int i, int casttime, int cooldown)
        {
            this.level = t;
            if (casttime == 0)
            {
                casttime = 0x9c4;
            }
            this.coolDown = cooldown;
            this.castingTime = casttime;
            this.id = i;
            switch (this.level)
            {
                case ProfessionLevels.Apprentice:
                {
                    base.Current = 15;
                    base.Max = 0x4b;
                    return;
                }
                case ProfessionLevels.Journeyman:
                {
                    base.Max = 150;
                    return;
                }
                case ProfessionLevels.Expert:
                {
                    base.Max = 0xe1;
                    return;
                }
                case ProfessionLevels.Artisan:
                {
                    base.Max = 300;
                    return;
                }
            }
        }

        public Profession(ProfessionLevels t, int i, ushort cur, ushort ind) : base(cur, ind)
        {
            this.level = t;
            this.id = i;
            switch (this.level)
            {
                case ProfessionLevels.Apprentice:
                {
                    base.Current = 15;
                    base.Max = 0x4b;
                    return;
                }
                case ProfessionLevels.Journeyman:
                {
                    base.Max = 150;
                    return;
                }
                case ProfessionLevels.Expert:
                {
                    base.Max = 0xe1;
                    return;
                }
                case ProfessionLevels.Artisan:
                {
                    base.Max = 300;
                    return;
                }
            }
        }

        public override int CastingTime(Mobile from)
        {
            return this.castingTime;
        }

        public Profession Clone(ushort cur, ushort ind)
        {
            return new Profession(this.level, this.id, cur, ind);
        }

        public override void Deserialize(GenericReader gr, int ind, bool fake)
        {
            base.Deserialize(gr, ind, true);
            gr.ReadInt();
            this.id = gr.ReadInt();
            this.level = (ProfessionLevels) gr.ReadShort();
        }

        public static void OnFindMineral(BaseAbility ba, Mobile c)
        {
            AuraEffect effect1 = (AuraEffect) ba;
            Aura aura1 = new Aura(EffectTypes.FindMineral);
            c.CumulativeAuraEffects[EffectTypes.FindMineral] = true;
            c.AddAura(effect1, aura1);
            int[] numArray1 = new int[1] { 0x3f3 } ;
            object[] objArray1 = new object[1] { 4 } ;
            c.SendSmallUpdate(numArray1, objArray1);
        }

        public void OnLearn(Character c)
        {
        }

        public override void Serialize(GenericWriter gw)
        {
            base.Serialize(gw);
            gw.Write(0);
            gw.Write(this.id);
            gw.Write((short) this.level);
        }

        public static int Slots(int p)
        {
            return (0x270 + (p * 3));
        }

        public void UseFishing(Mobile.Casting cast, Character c)
        {
            GameObject obj1 = c.InsideFishingZone();
            if (obj1 == null)
            {
                c.SpellFaillure(SpellFailedReason.TheyArentAnyFishHere);
            }
            else
            {
                int num1 = base.CurrentVal(c);
                int num2 = base.AgiSkillCheck(c, num1);
                if (num2 > 50)
                {
                    if ((base.Current < base.Cap(c)) && c.SkillUp(base.Current, num1, 1))
                    {
                        base.Current = (ushort) (base.Current + 1);
                        c.SendSkillUpdate();
                    }
                    c.SpellSuccess();
                    float single1 = num2;
                    single1 /= 10f;
                    string text1 = "Reussite : " + single1.ToString();
                    c.SendMessage(text1);
                    if (!obj1.CheckLoot(c, single1))
                    {
                        c.SpellFaillure(SpellFailedReason.FailedAttempt);
                    }
                }
                else
                {
                    c.SpellFaillure(SpellFailedReason.FailedAttempt);
                }
            }
        }

        public void UseHerbalist(Mobile.Casting cast, Character c, GameObject go)
        {
            Hashtable hashtable1 = new Hashtable();
            hashtable1[0x1d] = 0;
            hashtable1[8] = 20;
            hashtable1[9] = 50;
            hashtable1[10] = 0x4b;
            hashtable1[11] = 100;
            hashtable1[0x1a] = 0x7d;
            hashtable1[0x1b] = 150;
            hashtable1[0x23] = 140;
            hashtable1[0x2d] = 0x7d;
            hashtable1[0x2f] = 160;
            hashtable1[0x30] = 0xd7;
            hashtable1[0x31] = 0xb9;
            hashtable1[50] = 0xcd;
            hashtable1[0x33] = 0xc3;
            int num1 = base.CurrentVal(c) - ((int) hashtable1[(int) go.Sound[0]]);
            int num2 = base.IqSkillCheck(c, num1);
            if (num2 > 50)
            {
                if ((base.Current < base.Cap(c)) && c.SkillUp(base.Current, num1, 1))
                {
                    base.Current = (ushort) (base.Current + 1);
                    c.SendSkillUpdate();
                }
                c.SpellSuccess();
                float single1 = num2;
                single1 /= 10f;
                string text1 = "Reussite : " + single1.ToString();
                c.SendMessage(text1);
                if (!go.CheckLoot(c, single1))
                {
                    c.SpellFaillure(SpellFailedReason.FailedAttempt);
                }
            }
            else
            {
                c.SpellFaillure(SpellFailedReason.FailedAttempt);
            }
        }

        public void UseMining(Mobile.Casting cast, Character c, GameObject go)
        {
            Hashtable hashtable1 = new Hashtable();
            hashtable1[0x12] = 0x19;
            hashtable1[0x13] = 50;
            hashtable1[20] = 0x4b;
            hashtable1[0x15] = 100;
            hashtable1[0x16] = 0x7d;
            hashtable1[0x19] = 150;
            hashtable1[0x26] = 0;
            hashtable1[0x27] = 50;
            hashtable1[40] = 100;
            hashtable1[0x29] = 150;
            hashtable1[0x2a] = 200;
            int num1 = base.CurrentVal(c) - ((int) hashtable1[(int) go.Sound[0]]);
            int num2 = base.StrSkillCheck(c, num1);
            if (num2 > 50)
            {
                if ((base.Current < base.Cap(c)) && c.SkillUp(base.Current, num1, 1))
                {
                    base.Current = (ushort) (base.Current + 1);
                    c.SendSkillUpdate();
                }
                c.SpellSuccess();
                float single1 = num2;
                single1 /= 10f;
                if (!go.CheckLoot(c, single1))
                {
                    c.SpellFaillure(SpellFailedReason.FailedAttempt);
                }
            }
            else
            {
                c.SpellFaillure(SpellFailedReason.FailedAttempt);
            }
        }

        public void UseSkinning(Mobile.Casting cast, Character c, Mobile go)
        {
            int[] numArray1;
            object[] objArray1;
            c.cast = cast;
            int num1 = base.CurrentVal(c) - 1;
            int num2 = base.StrSkillCheck(c, num1);
            if ((num2 > 50) && !go.Skinned)
            {
                float single1 = num2;
                single1 /= 10f;
                new ArrayList();
                c.LootOwner = go.Guid;
                if (go.SkinLoot != null)
                {
                    ArrayList list1 = new ArrayList();
                    Loot[] lootArray1 = go.SkinLoot;
                    for (int num3 = 0; num3 < lootArray1.Length; num3++)
                    {
                        Loot loot1 = lootArray1[num3];
                        if ((Utility.RandomDouble() * 100) < loot1.Probability)
                        {
                            float single2 = loot1.Probability;
                            list1.Add(loot1.Create(1));
                        }
                    }
                    if (list1.Count == 0)
                    {
                        c.SpellFaillure(SpellFailedReason.FailedAttempt);
                    }
                    else
                    {
                        go.Skinned = true;
                        if ((base.Current < base.Cap(c)) && c.SkillUp(base.Current, num1, 1))
                        {
                            base.Current = (ushort) (base.Current + 1);
                            c.SendSkillUpdate();
                        }
                        c.SpellSuccess();
                        c.previousSpellCasted = cast.id;
                        go.Treasure = (Item[]) list1.ToArray(typeof(Item));
                        c.SendLootDetails(go.Guid, go, 0);
                        numArray1 = new int[2] { 0x94, 0x2e } ;
                        objArray1 = new object[2] { go.DynFlags(c), go.Flags } ;
                        go.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    }
                }
                else
                {
                    c.SpellFaillure(SpellFailedReason.FailedAttempt);
                }
            }
            else
            {
                c.SpellFaillure(SpellFailedReason.FailedAttempt);
                numArray1 = new int[2] { 0x94, 0x2e } ;
                objArray1 = new object[2] { go.DynFlags(c), go.Flags } ;
                go.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
            }
        }


        // Properties
        public override ushort Id
        {
            get
            {
                int num1 = this.id;
                if (num1 <= 0x1cf5)
                {
                    if (num1 <= 0xcca)
                    {
                        if (num1 <= 0x940)
                        {
                            if (num1 <= 0x83c)
                            {
                                if (num1 == 0x7e2)
                                {
                                    goto Label_02B5;
                                }
                                if (num1 == 0x83c)
                                {
                                    goto Label_0297;
                                }
                                goto Label_02DF;
                            }
                            if (num1 == 0x8d3)
                            {
                                goto Label_029D;
                            }
                            switch (num1)
                            {
                                case 0x93e:
                                case 0x940:
                                {
                                    goto Label_02A3;
                                }
                                case 0x93f:
                                {
                                    goto Label_02DF;
                                }
                            }
                            goto Label_02DF;
                        }
                        if (num1 <= 0xa10)
                        {
                            if (num1 == 0x9f6)
                            {
                                goto Label_02AF;
                            }
                            switch (num1)
                            {
                                case 0xa0f:
                                case 0xa10:
                                {
                                    goto Label_02A9;
                                }
                            }
                            goto Label_02DF;
                        }
                        switch (num1)
                        {
                            case 0xc1c:
                            {
                                goto Label_02B5;
                            }
                            case 0xc1d:
                            {
                                goto Label_029D;
                            }
                            case 0xc1e:
                            {
                                goto Label_02AF;
                            }
                            case 0xc1f:
                            {
                                goto Label_02DF;
                            }
                            case 0xc20:
                            {
                                goto Label_0297;
                            }
                            case 0xcc9:
                            case 0xcca:
                            {
                                goto Label_02C1;
                            }
                        }
                        goto Label_02DF;
                    }
                    if (num1 <= 0xdec)
                    {
                        if (num1 <= 0xd88)
                        {
                            if (num1 == 0xd55)
                            {
                                goto Label_02AF;
                            }
                            if (num1 == 0xd88)
                            {
                                goto Label_029D;
                            }
                            goto Label_02DF;
                        }
                        if (num1 == 0xdd2)
                        {
                            goto Label_02B5;
                        }
                        if (num1 == 0xdec)
                        {
                            goto Label_02A9;
                        }
                        goto Label_02DF;
                    }
                    if (num1 <= 0xee3)
                    {
                        if (num1 == 0xdf2)
                        {
                            goto Label_02A3;
                        }
                        if (num1 == 0xee3)
                        {
                            goto Label_0297;
                        }
                        goto Label_02DF;
                    }
                    switch (num1)
                    {
                        case 0xf44:
                        case 0xf45:
                        case 0xf46:
                        {
                            goto Label_02D3;
                        }
                        case 0xfc4:
                        case 0xfc5:
                        case 0xfc6:
                        {
                            goto Label_02CD;
                        }
                        case 0x1cf3:
                        case 0x1cf4:
                        case 0x1cf5:
                        {
                            goto Label_02C7;
                        }
                    }
                    goto Label_02DF;
                }
                if (num1 <= 0x29a6)
                {
                    if (num1 <= 0x21a5)
                    {
                        if (num1 <= 0x1e34)
                        {
                            if (num1 == 0x1dc4)
                            {
                                goto Label_02BB;
                            }
                            switch (num1)
                            {
                                case 0x1e33:
                                case 0x1e34:
                                {
                                    goto Label_02BB;
                                }
                            }
                            goto Label_02DF;
                        }
                        if (num1 == 0x1ef4)
                        {
                            goto Label_02C1;
                        }
                        if (num1 == 0x21a5)
                        {
                            goto Label_02D9;
                        }
                        goto Label_02DF;
                    }
                    if (num1 <= 0x2639)
                    {
                        switch (num1)
                        {
                            case 0x21a9:
                            case 0x21aa:
                            {
                                goto Label_02D9;
                            }
                            case 0x2639:
                            {
                                goto Label_02B5;
                            }
                        }
                        goto Label_02DF;
                    }
                    if (num1 == 0x2808)
                    {
                        goto Label_02A9;
                    }
                    if (num1 == 0x29a6)
                    {
                        goto Label_0297;
                    }
                    goto Label_02DF;
                }
                if (num1 <= 0x2ed9)
                {
                    if (num1 <= 0x2a5e)
                    {
                        if (num1 == 0x2a10)
                        {
                            goto Label_02D9;
                        }
                        if (num1 == 0x2a5e)
                        {
                            goto Label_02C1;
                        }
                        goto Label_02DF;
                    }
                    if (num1 == 0x2d5b)
                    {
                        goto Label_029D;
                    }
                    if (num1 == 0x2ed9)
                    {
                        goto Label_02A3;
                    }
                    goto Label_02DF;
                }
                if (num1 <= 0x3170)
                {
                    if (num1 == 0x2f94)
                    {
                        goto Label_02D3;
                    }
                    if (num1 == 0x3170)
                    {
                        goto Label_02CD;
                    }
                    goto Label_02DF;
                }
                if (num1 == 0x3660)
                {
                    goto Label_02C7;
                }
                if (num1 == 0x4748)
                {
                    goto Label_02BB;
                }
                if (num1 == 0x4754)
                {
                    goto Label_02AF;
                }
                goto Label_02DF;
            Label_0297:
                return 0xa5;
            Label_029D:
                return 0xab;
            Label_02A3:
                return 0xb6;
            Label_02A9:
                return 0xba;
            Label_02AF:
                return 0xb9;
            Label_02B5:
                return 0xa4;
            Label_02BB:
                return 0x164;
            Label_02C1:
                return 0x81;
            Label_02C7:
                return 0x14d;
            Label_02CD:
                return 0xca;
            Label_02D3:
                return 0xc5;
            Label_02D9:
                return 0x189;
            Label_02DF:
                return 0;
            }
        }

        public ProfessionLevels Level
        {
            get
            {
                return this.level;
            }
        }

        public Professions ProfessionType
        {
            get
            {
                int num1 = this.id;
                if (num1 <= 0x1cf5)
                {
                    if (num1 <= 0xcca)
                    {
                        if (num1 <= 0x940)
                        {
                            if (num1 <= 0x83c)
                            {
                                if (num1 == 0x7e2)
                                {
                                    goto Label_0299;
                                }
                                if (num1 == 0x83c)
                                {
                                    goto Label_028E;
                                }
                                goto Label_02AA;
                            }
                            if (num1 == 0x8d3)
                            {
                                goto Label_0290;
                            }
                            switch (num1)
                            {
                                case 0x93e:
                                case 0x940:
                                {
                                    goto Label_0292;
                                }
                                case 0x93f:
                                {
                                    goto Label_02AA;
                                }
                            }
                            goto Label_02AA;
                        }
                        if (num1 <= 0xa10)
                        {
                            if (num1 == 0x9f6)
                            {
                                goto Label_0296;
                            }
                            switch (num1)
                            {
                                case 0xa0f:
                                case 0xa10:
                                {
                                    goto Label_0294;
                                }
                            }
                            goto Label_02AA;
                        }
                        switch (num1)
                        {
                            case 0xc1c:
                            {
                                goto Label_0299;
                            }
                            case 0xc1d:
                            {
                                goto Label_0290;
                            }
                            case 0xc1e:
                            {
                                goto Label_0296;
                            }
                            case 0xc1f:
                            {
                                goto Label_02AA;
                            }
                            case 0xc20:
                            {
                                goto Label_028E;
                            }
                            case 0xcc9:
                            case 0xcca:
                            {
                                goto Label_029D;
                            }
                        }
                        goto Label_02AA;
                    }
                    if (num1 <= 0xdec)
                    {
                        if (num1 <= 0xd88)
                        {
                            if (num1 == 0xd55)
                            {
                                goto Label_0296;
                            }
                            if (num1 == 0xd88)
                            {
                                goto Label_0290;
                            }
                            goto Label_02AA;
                        }
                        if (num1 == 0xdd2)
                        {
                            goto Label_0299;
                        }
                        if (num1 == 0xdec)
                        {
                            goto Label_0294;
                        }
                        goto Label_02AA;
                    }
                    if (num1 <= 0xee3)
                    {
                        if (num1 == 0xdf2)
                        {
                            goto Label_0292;
                        }
                        if (num1 == 0xee3)
                        {
                            goto Label_028E;
                        }
                        goto Label_02AA;
                    }
                    switch (num1)
                    {
                        case 0xf44:
                        case 0xf45:
                        case 0xf46:
                        {
                            goto Label_02A6;
                        }
                        case 0xfc4:
                        case 0xfc5:
                        case 0xfc6:
                        {
                            goto Label_02A3;
                        }
                        case 0x1cf3:
                        case 0x1cf4:
                        case 0x1cf5:
                        {
                            goto Label_02A0;
                        }
                    }
                    goto Label_02AA;
                }
                if (num1 <= 0x29a6)
                {
                    if (num1 <= 0x21a5)
                    {
                        if (num1 <= 0x1e34)
                        {
                            if (num1 == 0x1dc4)
                            {
                                goto Label_029B;
                            }
                            switch (num1)
                            {
                                case 0x1e33:
                                case 0x1e34:
                                {
                                    goto Label_029B;
                                }
                            }
                            goto Label_02AA;
                        }
                        if (num1 == 0x1ef4)
                        {
                            goto Label_029D;
                        }
                        if (num1 == 0x21a5)
                        {
                            goto Label_02A8;
                        }
                        goto Label_02AA;
                    }
                    if (num1 <= 0x2639)
                    {
                        switch (num1)
                        {
                            case 0x21a9:
                            case 0x21aa:
                            {
                                goto Label_02A8;
                            }
                            case 0x2639:
                            {
                                goto Label_0299;
                            }
                        }
                        goto Label_02AA;
                    }
                    if (num1 == 0x2808)
                    {
                        goto Label_0294;
                    }
                    if (num1 == 0x29a6)
                    {
                        goto Label_028E;
                    }
                    goto Label_02AA;
                }
                if (num1 <= 0x2ed9)
                {
                    if (num1 <= 0x2a5e)
                    {
                        if (num1 == 0x2a10)
                        {
                            goto Label_02A8;
                        }
                        if (num1 == 0x2a5e)
                        {
                            goto Label_029D;
                        }
                        goto Label_02AA;
                    }
                    if (num1 == 0x2d5b)
                    {
                        goto Label_0290;
                    }
                    if (num1 == 0x2ed9)
                    {
                        goto Label_0292;
                    }
                    goto Label_02AA;
                }
                if (num1 <= 0x3170)
                {
                    if (num1 == 0x2f94)
                    {
                        goto Label_02A6;
                    }
                    if (num1 == 0x3170)
                    {
                        goto Label_02A3;
                    }
                    goto Label_02AA;
                }
                if (num1 == 0x3660)
                {
                    goto Label_02A0;
                }
                if (num1 == 0x4748)
                {
                    goto Label_029B;
                }
                if (num1 == 0x4754)
                {
                    goto Label_0296;
                }
                goto Label_02AA;
            Label_028E:
                return Professions.LeatherWorker;
            Label_0290:
                return Professions.Alchemist;
            Label_0292:
                return Professions.Herborist;
            Label_0294:
                return Professions.Miner;
            Label_0296:
                return Professions.Cooking;
            Label_0299:
                return Professions.Blacksmith;
            Label_029B:
                return Professions.Fishing;
            Label_029D:
                return Professions.FirstAid;
            Label_02A0:
                return Professions.Enchanter;
            Label_02A3:
                return Professions.Engineer;
            Label_02A6:
                return Professions.Tailor;
            Label_02A8:
                return Professions.Skinning;
            Label_02AA:
                return Professions.NoProf;
            }
        }

        public new int SpellId//fix
        {
            get
            {
                return this.id;
            }
        }


        // Fields
        private int castingTime;
        private int coolDown;
        private int id;
        private ProfessionLevels level;
    }
}

