namespace Server
{
    using System;

    public enum LootMethod
    {
        // Fields
        FreeForAll = 0,
        GroupLoot = 3,
        MasterLooter = 2,
        NeedBeforeGreed = 4,
        RoundRobin = 1
    }
}

