namespace Server
{
    using System;

    public class LeatherSkill : Skill
    {
        // Methods
        public LeatherSkill()
        {
        }

        public LeatherSkill(int current, int max) : base(1, 1)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x19e;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x19e;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x2375;
            }
        }

    }
}

