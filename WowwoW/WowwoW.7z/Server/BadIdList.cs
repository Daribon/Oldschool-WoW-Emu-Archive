namespace Server
{
    using System;
    using System.Collections;
    using System.IO;

    public class BadIdList
    {
        // Methods
        static BadIdList()
        {
            BadIdList._items = new ArrayList();
            BadIdList._mobiles = new ArrayList();
            BadIdList._gobjects = new ArrayList();
        }

        public BadIdList()
        {
        }

        public static void AddGameObjId(int id)
        {
            if (!BadIdList._gobjects.Contains(id))
            {
                BadIdList._gobjects.Add(id);
            }
        }

        public static void AddItemId(int id)
        {
            if (!BadIdList._items.Contains(id))
            {
                BadIdList._items.Add(id);
            }
        }

        public static void AddMobileId(int id)
        {
            if (!BadIdList._items.Contains(id))
            {
                BadIdList._items.Add(id);
            }
        }

        public static void GenerateLog(string fileName, bool overrvrite)
        {
            using (StreamWriter writer1 = new StreamWriter(fileName, overrvrite))
            {
                writer1.WriteLine("Does not exist yet lists [{0}]", DateTime.Now);
                writer1.WriteLine(" ");
                writer1.WriteLine("[Mobile id numbers] Total: {0}", BadIdList.CountMobiles);
                foreach (int num1 in BadIdList._mobiles)
                {
                    writer1.WriteLine(" {0}", num1);
                }
                writer1.WriteLine(" ");
                writer1.WriteLine("[GameObject id numbers] Total: {0}", BadIdList.CountMobiles);
                foreach (int num2 in BadIdList._gobjects)
                {
                    writer1.WriteLine(" {0}", num2);
                }
                writer1.WriteLine(" ");
                writer1.WriteLine("[Item id numbers] Total: {0}", BadIdList.CountItems);
                foreach (int num3 in BadIdList._items)
                {
                    writer1.WriteLine(" {0}", num3);
                }
            }
        }


        // Properties
        private static int CountGameObjects
        {
            get
            {
                return BadIdList._gobjects.Count;
            }
        }

        private static int CountItems
        {
            get
            {
                return BadIdList._items.Count;
            }
        }

        private static int CountMobiles
        {
            get
            {
                return BadIdList._mobiles.Count;
            }
        }


        // Fields
        private static ArrayList _gobjects;
        private static ArrayList _items;
        private static ArrayList _mobiles;
    }
}

