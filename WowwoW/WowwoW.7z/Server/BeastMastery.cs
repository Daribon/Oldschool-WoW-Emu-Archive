namespace Server
{
    using System;

    public class BeastMastery : Skill
    {
        // Methods
        public BeastMastery()
        {
        }

        public BeastMastery(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 50;
            }
        }

        public static int SkillId
        {
            get
            {
                return 50;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

