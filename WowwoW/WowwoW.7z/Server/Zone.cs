namespace Server
{
    using System;

    public class Zone
    {
        // Methods
        static Zone()
        {
            Zone.quickX = new float[0x91];
            Zone.quickY = new float[0x91];
        }

        public Zone(float _x, float _y, float _z, int zid, float[] _h)
        {
            this.zoneId = zid;
            this.x = _x;
            this.y = _y;
            this.h = _h;
            this.z = _z;
        }

        public float X(int p)
        {
            return (this.x - Zone.quickX[p]);
        }

        public float Y(int p)
        {
            return (this.y - Zone.quickY[p]);
        }

        public float Z(int p)
        {
            return this.h[p];
        }


        // Fields
        public float[] h;
        public static float[] quickX;
        public static float[] quickY;
        public float x;
        public float y;
        public float z;
        public int zoneId;
    }
}

