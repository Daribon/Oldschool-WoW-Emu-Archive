namespace Server
{
    using System;
    using System.Collections;
    using System.Reflection;

    public class GameObjectsList : IDictionary, ICollection, IEnumerable, ICloneable
    {
        // Methods
        public GameObjectsList()
        {
            this.innerHash = new Hashtable();
        }

        public GameObjectsList(GameObjectsList original)
        {
            this.innerHash = new Hashtable(original.innerHash);
        }

        public GameObjectsList(IDictionary dictionary)
        {
            this.innerHash = new Hashtable(dictionary);
        }

        public GameObjectsList(int capacity)
        {
            this.innerHash = new Hashtable(capacity);
        }

        public GameObjectsList(IDictionary dictionary, float loadFactor)
        {
            this.innerHash = new Hashtable(dictionary, loadFactor);
        }

        public GameObjectsList(IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(codeProvider, comparer);
        }

        public GameObjectsList(int capacity, int loadFactor)
        {
            this.innerHash = new Hashtable(capacity, (float) loadFactor);
        }

        public GameObjectsList(IDictionary dictionary, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(dictionary, codeProvider, comparer);
        }

        public GameObjectsList(int capacity, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(capacity, codeProvider, comparer);
        }

        public GameObjectsList(IDictionary dictionary, float loadFactor, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(dictionary, loadFactor, codeProvider, comparer);
        }

        public GameObjectsList(int capacity, float loadFactor, IHashCodeProvider codeProvider, IComparer comparer)
        {
            this.innerHash = new Hashtable(capacity, loadFactor, codeProvider, comparer);
        }

        public void Add(int key, Type value)
        {
            this.innerHash.Add(key, value);
        }

        public void Clear()
        {
            this.innerHash.Clear();
        }

        public GameObjectsList Clone()
        {
            GameObjectsList list1 = new GameObjectsList();
            list1.innerHash = (Hashtable) this.innerHash.Clone();
            return list1;
        }

        public bool Contains(int key)
        {
            return this.innerHash.Contains(key);
        }

        public bool ContainsKey(int key)
        {
            return this.innerHash.ContainsKey(key);
        }

        public bool ContainsValue(Type value)
        {
            return this.innerHash.ContainsValue(value);
        }

        public void CopyTo(Array array, int index)
        {
            this.innerHash.CopyTo(array, index);
        }

        public bool Exist(int id)
        {
            if (this.innerHash[id] == null)
            {
                return false;
            }
            return true;
        }

        public GameObjectsListEnumerator GetEnumerator()
        {
            return new GameObjectsListEnumerator(this);
        }

        public void Remove(int key)
        {
            this.innerHash.Remove(key);
        }

        public static GameObjectsList Synchronized(GameObjectsList nonSync)
        {
            GameObjectsList list1 = new GameObjectsList();
            list1.innerHash = Hashtable.Synchronized(nonSync.innerHash);
            return list1;
        }

        void IDictionary.Add(object key, object value)
        {
            this.Add((int) key, (Type) value);
        }

        bool IDictionary.Contains(object key)
        {
            return this.Contains((int) key);
        }

        IDictionaryEnumerator IDictionary.GetEnumerator()
        {
            return new GameObjectsListEnumerator(this);
        }

        void IDictionary.Remove(object key)
        {
            this.Remove((int) key);
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return this.GetEnumerator();
        }

        object ICloneable.Clone()
        {
            return this.Clone();
        }


        // Properties
        public int Count
        {
            get
            {
                return this.innerHash.Count;
            }
        }

        internal Hashtable InnerHash
        {
            get
            {
                return this.innerHash;
            }
        }

        public bool IsFixedSize
        {
            get
            {
                return this.innerHash.IsFixedSize;
            }
        }

        public bool IsReadOnly
        {
            get
            {
                return this.innerHash.IsReadOnly;
            }
        }

        public bool IsSynchronized
        {
            get
            {
                return this.innerHash.IsSynchronized;
            }
        }

        public Type this[int key]
        {
            get
            {
                return (Type) this.innerHash[key];
            }
            set
            {
                this.innerHash[key] = value;
            }
        }

        public ICollection Keys
        {
            get
            {
                return this.innerHash.Keys;
            }
        }

        public object SyncRoot
        {
            get
            {
                return this.innerHash.SyncRoot;
            }
        }

        object IDictionary.this[object key]
        {
            get
            {
                return this[(int) key];
            }
            set
            {
                this[(int) key] = (Type) value;
            }
        }

        public ICollection Values
        {
            get
            {
                return this.innerHash.Values;
            }
        }


        // Fields
        protected Hashtable innerHash;
    }
}

