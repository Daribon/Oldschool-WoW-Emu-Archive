namespace Server
{
    using System;

    public enum TargetType
    {
        // Fields
        Enemy = 1,
        Friend = 2,
        GameObj = 4,
        Party = 0,
        Pet = 3
    }
}

