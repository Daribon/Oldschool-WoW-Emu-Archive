namespace Server
{
    using System;

    public class DwarvenSkill : Skill
    {
        // Methods
        public DwarvenSkill()
        {
        }

        public DwarvenSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x6f;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x6f;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x2a0;
            }
        }

    }
}

