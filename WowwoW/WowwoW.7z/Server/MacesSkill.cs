namespace Server
{
    using System;

    public class MacesSkill : Skill
    {
        // Methods
        public MacesSkill()
        {
        }

        public MacesSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x36;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x36;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xc6;
            }
        }

    }
}

