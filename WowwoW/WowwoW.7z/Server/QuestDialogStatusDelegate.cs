namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate DialogStatus QuestDialogStatusDelegate(Mobile questOwner, Character c, BaseQuest bq);

}

