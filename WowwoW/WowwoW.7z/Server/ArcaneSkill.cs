namespace Server
{
    using System;

    public class ArcaneSkill : Skill
    {
        // Methods
        public ArcaneSkill()
        {
        }

        public ArcaneSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xed;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xed;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

