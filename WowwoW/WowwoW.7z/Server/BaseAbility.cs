namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;

    public class BaseAbility
    {
        // Methods
        static BaseAbility()
        {
            BaseAbility.SpellCheck = new Hashtable();
        }

        public BaseAbility()
        {
            this.cooldown = 0x7d0;
        }

        public BaseAbility(ushort i, int c)
        {
            this.cooldown = 0x7d0;
            this.id = i;
            this.cooldown = c;
        }

        public BaseAbility(ushort i, int _customFlags1, int c)
        {
            this.cooldown = 0x7d0;
            this.id = i;
            this.cooldown = c;
            this.customFlags1 = _customFlags1;
        }

        public virtual int CastingTime(Mobile from)
        {
            return 0;
        }

        public bool CheckSpell(Mobile from, Server.Object target)
        {
            if (!(this is SpellTemplate) && !(this is AuraEffect))
            {
                Console.WriteLine("Ability/Teach spell casted - Id: " + this.Id);
                goto Label_0443;
            }
            if ((this is AuraEffect) && (target is Mobile))
            {
                AuraEffect effect1 = (AuraEffect) this;
                byte num1 = effect1.GetPureBin();
                Console.WriteLine(num1);
                ArrayList list1 = new ArrayList();
                foreach (Mobile.AuraReleaseTimer timer1 in (target as Mobile).Auras)
                {
                    AuraEffect effect2 = timer1.ae;
                    if (effect2.Aura == effect1.Aura)
                    {
                        if (effect2.Id > effect1.Id)
                        {
                            (from as Character).SpellFaillure(SpellFailedReason.AMorePowerfulSpellAlreadyActive);
                            return false;
                        }
                        list1.Add(timer1);
                    }
                }
                foreach (Mobile.AuraReleaseTimer timer2 in list1)
                {
                    (target as Mobile).ReleaseAura(timer2);
                }
            }
            if (from.ForceSilence)
            {
                from.SpellFaillure(SpellFailedReason.CanDoWhileSilenced);
                return false;
            }
            foreach (Mobile.AuraReleaseTimer timer3 in from.Auras)
            {
                if ((timer3.aura.AvoidCastMagicClass != 0) && (AbilityClasses.abilityClasses[this.Id] == timer3.aura.AvoidCastMagicClass))
                {
                    from.SpellFaillure(SpellFailedReason.YouCantDoThatYet);
                    return false;
                }
            }
            if ((!(from is Character) || ((from as Character).Player.AccessLevel == AccessLevels.PlayerLevel)) && ((this as SpellTemplate).GetManaCost(from) > from.Mana))
            {
                from.SpellFaillure(SpellFailedReason.NotEnoughMana);
                return false;
            }
            if (((SpellTemplate.SpellEffects[this.Id] is SingleTargetSpellEffect) && !(target is Mobile)) && !(target is Character))
            {
                from.SpellFaillure(SpellFailedReason.InvalidTarget);
                return false;
            }
            if ((SpellTemplate.SpellEffects[this.Id] is OnSingleTargetItemSpellEffect) && !(target is Item))
            {
                from.SpellFaillure(SpellFailedReason.InvalidTarget);
                return false;
            }
            if ((SpellTemplate.SpellEffects[this.Id] is TargetXYZSpellEffect) && (target != null))
            {
                from.SpellFaillure(SpellFailedReason.InvalidTarget);
                return false;
            }
            if ((SpellTemplate.SpellEffects[this.Id] is OnSelfSpellEffect) && (target != from))
            {
                from.SpellFaillure(SpellFailedReason.InvalidTarget);
                return false;
            }
            if ((SpellTemplate.SpellEffects[this.Id] is GameObjectTargetSpellEffect) && (target is GameObject))
            {
                from.SpellFaillure(SpellFailedReason.InvalidTarget);
                return false;
            }
            if (from is Character)
            {
                int num2 = ((int) from.StandState) & 0xffff;
                StandStates states1 = (StandStates) num2;
                if (states1 != StandStates.Standing)
                {
                    from.SpellFaillure(SpellFailedReason.YouHaveToStandingToDoThat);
                    return false;
                }
            }
            if (from.Dead)
            {
                from.SpellFaillure(SpellFailedReason.YouAreDead);
                return false;
            }
            if (!from.HaveSpell(this.Id))
            {
                from.SpellFaillure(SpellFailedReason.SpellNotLearned);
                return false;
            }
            if (from is Character)
            {
                if ((((from as Character).AccountLevel == AccessLevels.Admin) || ((from as Character).AccountLevel == AccessLevels.GM)) || (from.Level >= (this as SpellTemplate).RequieredLevel))
                {
                    goto Label_0373;
                }
                from.SpellFaillure(SpellFailedReason.YouAreNotEnoughLevel);
                return false;
            }
            if (((this is SpellTemplate) || (this is AuraEffect)) && (from.Level < (this as SpellTemplate).RequieredLevel))
            {
                from.SpellFaillure(SpellFailedReason.YouAreNotEnoughLevel);
                return false;
            }
        Label_0373:
            if ((SpecificSpellTargets.specificSpellTargets[this.Id] != 0) && (target is Mobile))
            {
                int num3 = SpecificSpellTargets.specificSpellTargets[this.Id];
                int num4 = num3;
                Mobile mobile1 = (Mobile) target;
                Console.WriteLine(" " + num4 + " ");
                num4 &= mobile1.NpcType;
                object[] objArray1 = new object[4] { " ", num4, " ", mobile1.NpcType } ;
                Console.WriteLine(string.Concat(objArray1));
                if (num4 == 0)
                {
                    from.SpellFaillure(SpellFailedReason.RequiredExoticAmno);
                    Console.WriteLine("upppppps");
                    return false;
                }
            }
        Label_0443:
            return true;
        }

        public bool CheckSpellCaster(Mobile from)
        {
            if ((this is SpellTemplate) || (this is AuraEffect))
            {
                if (from.ForceSilence)
                {
                    from.SpellFaillure(SpellFailedReason.CanDoWhileSilenced);
                    return false;
                }
                foreach (Mobile.AuraReleaseTimer timer1 in from.Auras)
                {
                    if ((timer1.aura.AvoidCastMagicClass != 0) && (AbilityClasses.abilityClasses[this.Id] == timer1.aura.AvoidCastMagicClass))
                    {
                        from.SpellFaillure(SpellFailedReason.YouCantDoThatYet);
                        return false;
                    }
                }
                if ((!(from is Character) || ((from as Character).Player.AccessLevel == AccessLevels.PlayerLevel)) && ((this as SpellTemplate).GetManaCost(from) > from.Mana))
                {
                    from.SpellFaillure(SpellFailedReason.NotEnoughMana);
                    return false;
                }
                if (from is Character)
                {
                    int num1 = ((int) from.StandState) & 0xffff;
                    StandStates states1 = (StandStates) num1;
                    if (states1 != StandStates.Standing)
                    {
                        from.SpellFaillure(SpellFailedReason.YouHaveToStandingToDoThat);
                        return false;
                    }
                }
                if (from.Dead)
                {
                    from.SpellFaillure(SpellFailedReason.YouAreDead);
                    return false;
                }
                if (!from.HaveSpell(this.Id))
                {
                    from.SpellFaillure(SpellFailedReason.SpellNotLearned);
                    return false;
                }
                if ((!(this is SpellTemplate) && !(this is AuraEffect)) || (from.Level >= (this as SpellTemplate).RequieredLevel))
                {
                    goto Label_0165;
                }
                from.SpellFaillure(SpellFailedReason.YouAreNotEnoughLevel);
                return false;
            }
            Console.WriteLine("Ability/Teach spell casted - Id: " + this.Id);
        Label_0165:
            return true;
        }

        public bool CheckSpellTarget(Mobile from, Server.Object target)
        {
            if ((this is SpellTemplate) || (this is AuraEffect))
            {
                if ((this is AuraEffect) && (target is Mobile))
                {
                    AuraEffect effect1 = (AuraEffect) this;
                    byte num1 = effect1.GetPureBin();
                    Console.WriteLine(num1);
                    ArrayList list1 = new ArrayList();
                    foreach (Mobile.AuraReleaseTimer timer1 in (target as Mobile).Auras)
                    {
                        AuraEffect effect2 = timer1.ae;
                        if (effect2.Aura == effect1.Aura)
                        {
                            if (effect2.Id > effect1.Id)
                            {
                                (from as Character).SpellFaillure(SpellFailedReason.AMorePowerfulSpellAlreadyActive);
                                return false;
                            }
                            list1.Add(timer1);
                        }
                    }
                    foreach (Mobile.AuraReleaseTimer timer2 in list1)
                    {
                        (target as Mobile).ReleaseAura(timer2);
                    }
                }
                if (((SpellTemplate.SpellEffects[this.Id] is SingleTargetSpellEffect) && !(target is Mobile)) && !(target is Character))
                {
                    from.SpellFaillure(SpellFailedReason.InvalidTarget);
                    return false;
                }
                if ((SpellTemplate.SpellEffects[this.Id] is OnSingleTargetItemSpellEffect) && !(target is Item))
                {
                    from.SpellFaillure(SpellFailedReason.InvalidTarget);
                    return false;
                }
                if ((SpellTemplate.SpellEffects[this.Id] is TargetXYZSpellEffect) && (target != null))
                {
                    from.SpellFaillure(SpellFailedReason.InvalidTarget);
                    return false;
                }
                if ((SpellTemplate.SpellEffects[this.Id] is OnSelfSpellEffect) && (target != from))
                {
                    from.SpellFaillure(SpellFailedReason.InvalidTarget);
                    return false;
                }
                if ((SpellTemplate.SpellEffects[this.Id] is GameObjectTargetSpellEffect) && (target is GameObject))
                {
                    from.SpellFaillure(SpellFailedReason.InvalidTarget);
                    return false;
                }
                if (!(target is Mobile) || !(target as Mobile).Dead)
                {
                    goto Label_0229;
                }
                from.SpellFaillure(SpellFailedReason.YouAreDead);
                return false;
            }
            Console.WriteLine("Ability/Teach spell casted - Id: " + this.Id);
        Label_0229:
            return true;
        }

        public bool CheckSpellTargetMultiple(Mobile from, Server.Object target)
        {
            if ((this is SpellTemplate) || (this is AuraEffect))
            {
                if ((this is AuraEffect) && (target is Mobile))
                {
                    AuraEffect effect1 = (AuraEffect) this;
                    byte num1 = effect1.GetPureBin();
                    Console.WriteLine(num1);
                    ArrayList list1 = new ArrayList();
                    foreach (Mobile.AuraReleaseTimer timer1 in (target as Mobile).Auras)
                    {
                        AuraEffect effect2 = timer1.ae;
                        if (effect2.Aura == effect1.Aura)
                        {
                            if (effect2.Id > effect1.Id)
                            {
                                return false;
                            }
                            list1.Add(timer1);
                        }
                    }
                    foreach (Mobile.AuraReleaseTimer timer2 in list1)
                    {
                        (target as Mobile).ReleaseAura(timer2);
                    }
                }
                if ((target is Mobile) && (target as Mobile).Dead)
                {
                    return false;
                }
            }
            else
            {
                Console.WriteLine("Ability/Teach spell casted - Id: " + this.Id);
            }
            return true;
        }

        public virtual int CoolDown(Mobile from)
        {
            int num2;
            int num1 = this.cooldown;
            AuraEffect effect1 = null;
            if (!(this is SpellTemplate))
            {
                goto Label_01E0;
            }
            Classes classes1 = from.Classe;
            if (classes1 != Classes.Warrior)
            {
                switch (classes1)
                {
                    case Classes.Mage:
                    {
                        if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x858]) && from.HaveTalent(Talents.ImprovedFireBlast))
                        {
                            effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedFireBlast);
                            num1 += effect1.S1;
                        }
                        if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x17f3]) && from.HaveTalent(Talents.ImprovedFrostNova))
                        {
                            effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedFrostNova);
                            num1 += effect1.S1;
                        }
                        goto Label_0181;
                    }
                    case Classes.Warlock:
                    {
                        goto Label_0181;
                    }
                }
            }
            else
            {
                if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x163]) && from.HaveTalent(Talents.ImprovedTaunt))
                {
                    effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedTaunt);
                    num1 += effect1.S1;
                }
                if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x4f1c]) && from.HaveTalent(Talents.ImprovedIntercept))
                {
                    effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedIntercept);
                    num1 += effect1.S1;
                }
            }
        Label_0181:
            if (((from.SummonedBy != null) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x1124])) && from.SummonedBy.HaveTalent(Talents.ImprovedLashOfPain))
            {
                effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedLashOfPain);
                num1 += effect1.S1;
            }
        Label_01E0:
            num2 = num1;
            foreach (Mobile.AuraReleaseTimer timer1 in from.Auras)
            {
                if ((timer1.aura.CooldownEffectedAbilityList != 0) && (from.SpecialForAuras[timer1.aura.CooldownEffectedAbilityList] != null))
                {
                    if ((from.SpecialForAuras[timer1.aura.CooldownEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[timer1.aura.CooldownEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num2 = (int) ((num2 + timer1.aura.CooldownBonusForAbility) * timer1.aura.CooldownModificatorForAbility);
                    }
                    if (from.SpecialForAuras[timer1.aura.CooldownEffectedAbilityList] is int)
                    {
                        int num3 = (int) from.SpecialForAuras[timer1.aura.CooldownEffectedAbilityList];
                        if (num3 == this.Id)
                        {
                            num2 = (int) ((num2 + timer1.aura.CooldownBonusForAbility) * timer1.aura.CooldownModificatorForAbility);
                        }
                    }
                }
                if ((timer1.aura.CooldownEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == timer1.aura.CooldownEffectedAbilityClass))
                {
                    num2 = (int) ((num2 + timer1.aura.CooldownBonusForAbility) * timer1.aura.CooldownModificatorForAbility);
                }
            }
            foreach (PermanentAura aura1 in from.PermanentAuras)
            {
                if ((aura1.aura.CooldownEffectedAbilityList != 0) && (from.SpecialForAuras[aura1.aura.CooldownEffectedAbilityList] != null))
                {
                    if ((from.SpecialForAuras[aura1.aura.CooldownEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[aura1.aura.CooldownEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num2 = (int) ((num2 + aura1.aura.CooldownBonusForAbility) * aura1.aura.CooldownModificatorForAbility);
                    }
                    if (from.SpecialForAuras[aura1.aura.CooldownEffectedAbilityList] is int)
                    {
                        int num4 = (int) from.SpecialForAuras[aura1.aura.CooldownEffectedAbilityList];
                        if (num4 == this.Id)
                        {
                            num2 = (int) ((num2 + aura1.aura.CooldownBonusForAbility) * aura1.aura.CooldownModificatorForAbility);
                        }
                    }
                }
                if ((aura1.aura.CooldownEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == aura1.aura.CooldownEffectedAbilityClass))
                {
                    num2 = (int) ((num2 + aura1.aura.CooldownBonusForAbility) * aura1.aura.CooldownModificatorForAbility);
                }
            }
            return num2;
        }

        public byte GetPureBin()
        {
            byte num1 = 0;
            byte num2 = 0;
            num2 = (byte) ((0xff000000 & this.customFlags1) >> 0x18);
            return (byte) ((num2 & 0xc0) >> 6);
        }

        public bool IsBinary()
        {
            return true;
        }

        public bool IsType(int Eff)
        {
            byte[] buffer1 = new byte[3];
            byte[] buffer2 = new byte[3];
            byte[] buffer3 = new byte[4];
            byte[] buffer4 = new byte[4] { (byte) (0xff & this.customFlags1), (byte) ((0xff00 & this.customFlags1) >> 8), (byte) ((0xff0000 & this.customFlags1) >> 0x10), (byte) ((0xff000000 & this.customFlags1) >> 0x18) } ;
            buffer3[0] = (byte) (buffer4[3] & 3);
            buffer3[1] = (byte) ((buffer4[3] & 12) >> 2);
            buffer3[2] = (byte) ((buffer4[3] & 0x30) >> 4);
            for (int num1 = 0; num1 < 3; num1++)
            {
                if (buffer3[num1] == 0)
                {
                    buffer1[num1] = buffer4[num1];
                    buffer2[num1] = 0;
                }
                else if (buffer3[num1] == 1)
                {
                    buffer1[num1] = 6;
                    buffer2[num1] = buffer4[num1];
                }
                else if (buffer3[num1] == 2)
                {
                    buffer1[num1] = 0x23;
                    buffer2[num1] = buffer4[num1];
                }
                else
                {
                    buffer1[num1] = 0x1b;
                    buffer2[num1] = buffer4[num1];
                }
            }
            byte[] buffer5 = buffer1;
            for (int num3 = 0; num3 < buffer5.Length; num3++)
            {
                byte num2 = buffer5[num3];
                if (num2 == Eff)
                {
                    return true;
                }
            }
            return false;
        }

        public virtual void SendCooldown(Mobile.Casting cast, Mobile c)
        {
            if (c is Character)
            {
                int num1 = 4;
                Converter.ToBytes((uint) cast.id, c.tempBuff, ref num1);
                Converter.ToBytes(c.Guid, c.tempBuff, ref num1);
                Converter.ToBytes((ushort) cast.cool, c.tempBuff, ref num1);
                (c as Character).Send(OpCodes.SMSG_SPELL_COOLDOWN, c.tempBuff, num1);
            }
        }

        public virtual void SendCooldown(int spell, Mobile c)
        {
            if (c is Character)
            {
                int num1 = 4;
                Converter.ToBytes((uint) spell, c.tempBuff, ref num1);
                Converter.ToBytes(c.Guid, c.tempBuff, ref num1);
                Converter.ToBytes((ushort) Abilities.abilities[spell].CoolDown(c), c.tempBuff, ref num1);
                (c as Character).Send(OpCodes.SMSG_SPELL_COOLDOWN, c.tempBuff, num1);
            }
        }

        public virtual void SendCooldownEvent(int spell, Mobile c)
        {
            if (c is Character)
            {
                int num1 = 4;
                Converter.ToBytes((uint) spell, c.tempBuff, ref num1);
                Converter.ToBytes(c.Guid, c.tempBuff, ref num1);
                (c as Character).Send(OpCodes.SMSG_COOLDOWN_EVENT, c.tempBuff, num1);
            }
        }


        // Properties
        public virtual int CustomFlags1
        {
            get
            {
                return this.customFlags1;
            }
        }

        public virtual ushort Id
        {
            get
            {
                return this.id;
            }
        }


        // Fields
        private int cooldown;
        private int customFlags1;
        private ushort id;
        public static Hashtable SpellCheck;
    }
}

