namespace Server
{
    using System;

    public enum SpellDamage
    {
        // Fields
        TypeS1 = 0,
        TypeS2 = 1
    }
}

