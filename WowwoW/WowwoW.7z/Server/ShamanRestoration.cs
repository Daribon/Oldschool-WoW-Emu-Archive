namespace Server
{
    using System;

    public class ShamanRestoration : Skill
    {
        // Methods
        public ShamanRestoration()
        {
        }

        public ShamanRestoration(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x176;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x176;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

