namespace Server
{
    using System;
    using System.Collections;

    public class SpellTargets
    {
        // Methods
        public SpellTargets()
        {
        }

        public static ArrayList closeTargets(Mobile src, float area, int quantity, TargetType tt)
        {
            int num1;
            TargetType type1;
            ArrayList list1 = new ArrayList();
            Mobile mobile1 = null;
            ArrayList list2 = new ArrayList();
            if (src is Character)
            {
                type1 = tt;
                switch (type1)
                {
                    case TargetType.Party:
                    {
                        foreach (Character character1 in (src as Character).GroupMembers.Members)
                        {
                            if ((character1 == src) && (character1.Distance(src) < (area * area)))
                            {
                                list1.Add(character1);
                            }
                        }
                        goto Label_02AF;
                    }
                    case TargetType.Enemy:
                    {
                        foreach (Server.Object obj2 in (src as Character).Player.KnownObjects)
                        {
                            if ((obj2 is Mobile) && (obj2 != src))
                            {
                                Mobile mobile3 = obj2 as Mobile;
                                if ((mobile3.Distance(src) < (area * area)) && !(mobile3 as BaseCreature).IsFriend(src))
                                {
                                    list1.Add(mobile3);
                                }
                            }
                        }
                        goto Label_02AF;
                    }
                    case TargetType.Friend:
                    {
                        break;
                    }
                    default:
                    {
                        goto Label_02AF;
                    }
                }
                foreach (Server.Object obj1 in (src as Character).Player.KnownObjects)
                {
                    if ((obj1 is Mobile) && (obj1 != src))
                    {
                        Mobile mobile2 = obj1 as Mobile;
                        if ((mobile2.Distance(src) < (area * area)) && (mobile2 as BaseCreature).IsFriend(src))
                        {
                            list1.Add(mobile2);
                        }
                    }
                }
            }
            else
            {
                type1 = tt;
                switch (type1)
                {
                    case TargetType.Enemy:
                    {
                        break;
                    }
                    case TargetType.Friend:
                    {
                        foreach (Server.Object obj3 in src.KnownObjects)
                        {
                            if ((obj3 is Mobile) && (obj3 != src))
                            {
                                Mobile mobile4 = obj3 as Mobile;
                                if ((mobile4.Distance(src) < (area * area)) && (mobile4 as BaseCreature).IsFriend(src))
                                {
                                    list1.Add(mobile4);
                                }
                            }
                        }
                        goto Label_02AF;
                    }
                    default:
                    {
                        goto Label_02AF;
                    }
                }
                foreach (Server.Object obj4 in src.KnownObjects)
                {
                    if ((obj4 is Mobile) && (obj4 != src))
                    {
                        Mobile mobile5 = obj4 as Mobile;
                        if ((mobile5.Distance(src) < (area * area)) && !(mobile5 as BaseCreature).IsFriend(src))
                        {
                            list1.Add(mobile5);
                        }
                    }
                }
            }
        Label_02AF:
            num1 = 0;
            while (num1 < quantity)
            {
                int num2 = 1;
                foreach (Mobile mobile6 in list1)
                {
                    if (num2 == 1)
                    {
                        mobile1 = mobile6;
                        continue;
                    }
                    num1++;
                    if (src.Distance(mobile1) < src.Distance(mobile6))
                    {
                        mobile1 = mobile6;
                    }
                }
                if (mobile1 != null)
                {
                    list2.Add(mobile1);
                }
                num1++;
            }
            return list2;
        }

        public static bool FaceToBehind(Mobile _char, Mobile _creature)
        {
            float single1 = 0.7853982f;
            float single2 = _char.Orientation;
            float single3 = _creature.Orientation;
            float single4 = single2 + single1;
            float single5 = single2 - single1;
            if ((single4 >= single3) && (single3 >= single5))
            {
                return (SpellTargets.GetDirection(_char, _creature) == Server.SpellTargets.Pos.Behind);
            }
            return false;
        }

        public static Server.SpellTargets.Pos GetDirection(Mobile from, Mobile to)
        {
            float single1 = 3.141593f;
            float single2 = 6.283185f;
            float single3 = from.X - to.X;
            float single4 = from.Y - to.Y;
            float single5 = (float) Math.Atan2((double) single4, (double) single3);
            float single6 = Math.Abs((float) (single5 - to.Orientation));
            float single7 = (2f * single6) / single1;
            float single8 = ((int) (single6 / single2)) * 4;
            if (((1f + single8) < single7) && (single7 < (3f + single8)))
            {
                return Server.SpellTargets.Pos.Behind;
            }
            return Server.SpellTargets.Pos.Front;
        }

        public static bool InBehindOf(Mobile ch, Mobile target, double maxDifference)
        {
            double num1 = Math.Atan2((double) (ch.Y - target.Y), (double) (ch.X - target.X));
            Console.WriteLine(num1);
            if ((num1 > -3.1415926535897931) && (num1 < -1.5707963267948966))
            {
                num1 += 6.2831853071795862;
            }
            if ((num1 > -1.5707963267948966) && (num1 < 0))
            {
                num1 += 6.2831853071795862;
            }
            Console.WriteLine(ch.Orientation);
            if (((ch.Orientation + (maxDifference / 2)) >= num1) && ((ch.Orientation - (maxDifference / 2)) <= num1))
            {
                return true;
            }
            return false;
        }

        public static bool InFrontOf(Mobile ch, Mobile target, double maxDifference)
        {
            double num1 = Math.Atan2((double) (ch.Y - target.Y), (double) (ch.X - target.X));
            if ((num1 > -3.1415926535897931) && (num1 < -1.5707963267948966))
            {
                num1 += 6.2831853071795862;
            }
            if ((num1 > -1.5707963267948966) && (num1 < 0))
            {
                num1 += 6.2831853071795862;
            }
            num1 -= 3.1415926535897931;
            if (num1 < 0)
            {
                num1 = 6.2831853071795862 + num1;
            }
            if (Math.Abs((double) (ch.Orientation - num1)) < maxDifference)
            {
                return true;
            }
            return false;
        }

        public static ArrayList targetsAround(Mobile src, float area, TargetType tt)
        {
            TargetType type1;
            ArrayList list1 = new ArrayList();
            if (src is Character)
            {
                type1 = tt;
                switch (type1)
                {
                    case TargetType.Party:
                    {
                        foreach (Character character1 in (src as Character).GroupMembers.Members)
                        {
                            if ((character1 == src) && (character1.Distance(src) < (area * area)))
                            {
                                list1.Add(character1);
                            }
                        }
                        return list1;
                    }
                    case TargetType.Enemy:
                    {
                        foreach (Server.Object obj2 in (src as Character).Player.KnownObjects)
                        {
                            if ((obj2 is Mobile) && (obj2 != src))
                            {
                                Mobile mobile2 = obj2 as Mobile;
                                if ((mobile2.Distance(src) < (area * area)) && (mobile2 as BaseCreature).IsHostile(src))
                                {
                                    list1.Add(mobile2);
                                }
                            }
                        }
                        return list1;
                    }
                    case TargetType.Friend:
                    {
                        break;
                    }
                    default:
                    {
                        return list1;
                    }
                }
                foreach (Server.Object obj1 in (src as Character).Player.KnownObjects)
                {
                    if ((obj1 is Mobile) && (obj1 != src))
                    {
                        Mobile mobile1 = obj1 as Mobile;
                        if ((mobile1.Distance(src) < (area * area)) && !(mobile1 as BaseCreature).IsHostile(src))
                        {
                            list1.Add(mobile1);
                        }
                    }
                }
                return list1;
            }
            type1 = tt;
            switch (type1)
            {
                case TargetType.Enemy:
                {
                    break;
                }
                case TargetType.Friend:
                {
                    foreach (Mobile mobile3 in src.KnownObjects)
                    {
                        if (((mobile3 != src) && (mobile3.Distance(src) < (area * area))) && (mobile3 as BaseCreature).IsFriend(src))
                        {
                            list1.Add(mobile3);
                        }
                    }
                    return list1;
                }
                default:
                {
                    return list1;
                }
            }
            foreach (Mobile mobile4 in src.KnownObjects)
            {
                if (((mobile4 != src) && (mobile4.Distance(src) < (area * area))) && !(mobile4 as BaseCreature).IsFriend(src))
                {
                    list1.Add(mobile4);
                }
            }
            return list1;
        }

        public static ArrayList targetsAroundXYZ(Mobile src, float X, float Y, float Z, float area, TargetType tt)
        {
            TargetType type1;
            ArrayList list1 = new ArrayList();
            if (src is Character)
            {
                type1 = tt;
                switch (type1)
                {
                    case TargetType.Party:
                    {
                        foreach (Character character1 in (src as Character).GroupMembers.Members)
                        {
                            if (((character1 == src) && (character1.Distance(X, Y, Z) < (area * area))) && (character1.MapId == src.MapId))
                            {
                                list1.Add(character1);
                            }
                        }
                        return list1;
                    }
                    case TargetType.Enemy:
                    {
                        foreach (Server.Object obj2 in (src as Character).Player.KnownObjects)
                        {
                            if ((obj2 is Mobile) && (obj2 != src))
                            {
                                Mobile mobile2 = obj2 as Mobile;
                                if (((mobile2.Distance(X, Y, Z) < (area * area)) && !(mobile2 as BaseCreature).IsFriend(src)) && (mobile2.MapId == src.MapId))
                                {
                                    list1.Add(mobile2);
                                }
                            }
                        }
                        return list1;
                    }
                    case TargetType.Friend:
                    {
                        break;
                    }
                    default:
                    {
                        return list1;
                    }
                }
                foreach (Server.Object obj1 in (src as Character).Player.KnownObjects)
                {
                    if ((obj1 is Mobile) && (obj1 != src))
                    {
                        Mobile mobile1 = obj1 as Mobile;
                        if (((mobile1.Distance(X, Y, Z) < (area * area)) && (mobile1 as BaseCreature).IsFriend(src)) && (mobile1.MapId == src.MapId))
                        {
                            list1.Add(mobile1);
                        }
                    }
                }
                return list1;
            }
            type1 = tt;
            switch (type1)
            {
                case TargetType.Enemy:
                {
                    break;
                }
                case TargetType.Friend:
                {
                    foreach (Mobile mobile3 in src.KnownObjects)
                    {
                        if (((mobile3 != src) && (mobile3.Distance(X, Y, Z) < (area * area))) && ((mobile3 as BaseCreature).IsFriend(src) && (mobile3.MapId == src.MapId)))
                        {
                            list1.Add(mobile3);
                        }
                    }
                    return list1;
                }
                default:
                {
                    return list1;
                }
            }
            foreach (Mobile mobile4 in src.KnownObjects)
            {
                if (((mobile4 != src) && (mobile4.Distance(X, Y, Z) < (area * area))) && (!(mobile4 as BaseCreature).IsFriend(src) && (mobile4.MapId == src.MapId)))
                {
                    list1.Add(mobile4);
                }
            }
            return list1;
        }

        public static ArrayList targetsInConeBehind(Mobile src, float area, TargetType tt, int divider)
        {
            TargetType type1;
            ArrayList list1 = new ArrayList();
            if (divider == 0)
            {
                divider = 1;
            }
            if (src is Character)
            {
                type1 = tt;
                switch (type1)
                {
                    case TargetType.Party:
                    {
                        foreach (Character character1 in (src as Character).GroupMembers.Members)
                        {
                            if (((character1 == src) && (src.Distance(character1) < (area * area))) && SpellTargets.InBehindOf(src, character1, 3.1415926535897931 / ((double) divider)))
                            {
                                list1.Add(character1);
                            }
                        }
                        return list1;
                    }
                    case TargetType.Enemy:
                    {
                        foreach (Server.Object obj2 in (src as Character).Player.KnownObjects)
                        {
                            if ((obj2 is Mobile) && (obj2 != src))
                            {
                                Mobile mobile2 = obj2 as Mobile;
                                if (((mobile2.Distance(src) < (area * area)) && !(mobile2 as BaseCreature).IsFriend(src)) && SpellTargets.InBehindOf(src, mobile2, 3.1415926535897931 / ((double) divider)))
                                {
                                    list1.Add(mobile2);
                                }
                            }
                        }
                        return list1;
                    }
                    case TargetType.Friend:
                    {
                        break;
                    }
                    default:
                    {
                        return list1;
                    }
                }
                foreach (Server.Object obj1 in (src as Character).Player.KnownObjects)
                {
                    if ((obj1 is Mobile) && (obj1 != src))
                    {
                        Mobile mobile1 = obj1 as Mobile;
                        if (((mobile1.Distance(src) < (area * area)) && (mobile1 as BaseCreature).IsFriend(src)) && SpellTargets.InBehindOf(src, mobile1, 3.1415926535897931 / ((double) divider)))
                        {
                            list1.Add(mobile1);
                        }
                    }
                }
                return list1;
            }
            type1 = tt;
            switch (type1)
            {
                case TargetType.Enemy:
                {
                    break;
                }
                case TargetType.Friend:
                {
                    foreach (Mobile mobile3 in src.KnownObjects)
                    {
                        if (((mobile3 != src) && (mobile3.Distance(src) < (area * area))) && ((mobile3 as BaseCreature).IsFriend(src) && SpellTargets.InBehindOf(src, mobile3, 3.1415926535897931 / ((double) divider))))
                        {
                            list1.Add(mobile3);
                        }
                    }
                    return list1;
                }
                default:
                {
                    return list1;
                }
            }
            foreach (Mobile mobile4 in src.KnownObjects)
            {
                if (((mobile4 != src) && (mobile4.Distance(src) < (area * area))) && (!(mobile4 as BaseCreature).IsFriend(src) && SpellTargets.InBehindOf(src, mobile4, 3.1415926535897931 / ((double) divider))))
                {
                    list1.Add(mobile4);
                }
            }
            return list1;
        }

        public static ArrayList targetsInConeFront(Mobile src, float area, TargetType tt, int divider)
        {
            TargetType type1;
            ArrayList list1 = new ArrayList();
            if (divider == 0)
            {
                divider = 1;
            }
            if (src is Character)
            {
                type1 = tt;
                switch (type1)
                {
                    case TargetType.Party:
                    {
                        foreach (Character character1 in (src as Character).GroupMembers.Members)
                        {
                            if (((character1 == src) && (src.Distance(character1) < (area * area))) && SpellTargets.InFrontOf(src as Character, character1, 3.1415926535897931 / ((double) divider)))
                            {
                                list1.Add(character1);
                            }
                        }
                        return list1;
                    }
                    case TargetType.Enemy:
                    {
                        foreach (Server.Object obj2 in (src as Character).Player.KnownObjects)
                        {
                            if ((obj2 is Mobile) && (obj2 != src))
                            {
                                Mobile mobile2 = obj2 as Mobile;
                                if (((mobile2.Distance(src) < (area * area)) && !(mobile2 as BaseCreature).IsFriend(src)) && SpellTargets.InFrontOf(src as Character, mobile2, 3.1415926535897931 / ((double) divider)))
                                {
                                    list1.Add(mobile2);
                                }
                            }
                        }
                        return list1;
                    }
                    case TargetType.Friend:
                    {
                        break;
                    }
                    default:
                    {
                        return list1;
                    }
                }
                foreach (Server.Object obj1 in (src as Character).Player.KnownObjects)
                {
                    if ((obj1 is Mobile) && (obj1 != src))
                    {
                        Mobile mobile1 = obj1 as Mobile;
                        if (((mobile1.Distance(src) < (area * area)) && (mobile1 as BaseCreature).IsFriend(src)) && SpellTargets.InFrontOf(src as Character, mobile1, 3.1415926535897931 / ((double) divider)))
                        {
                            list1.Add(mobile1);
                        }
                    }
                }
                return list1;
            }
            type1 = tt;
            switch (type1)
            {
                case TargetType.Enemy:
                {
                    break;
                }
                case TargetType.Friend:
                {
                    foreach (Mobile mobile3 in src.KnownObjects)
                    {
                        if (((mobile3 != src) && (mobile3.Distance(src) < (area * area))) && ((mobile3 as BaseCreature).IsFriend(src) && SpellTargets.InFrontOf(src as Character, mobile3, 3.1415926535897931 / ((double) divider))))
                        {
                            list1.Add(mobile3);
                        }
                    }
                    return list1;
                }
                default:
                {
                    return list1;
                }
            }
            foreach (Mobile mobile4 in src.KnownObjects)
            {
                if (((mobile4 != src) && (mobile4.Distance(src) < (area * area))) && (!(mobile4 as BaseCreature).IsFriend(src) && SpellTargets.InFrontOf(src as Character, mobile4, 3.1415926535897931 / ((double) divider))))
                {
                    list1.Add(mobile4);
                }
            }
            return list1;
        }


        // Nested Types
        public enum Pos
        {
            // Fields
            Behind = 1,
            Front = 0
        }
    }
}

