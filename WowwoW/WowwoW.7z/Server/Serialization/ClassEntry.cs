namespace Server.Serialization
{
    using HelperTools;
    using System;
    using System.Reflection;

    public class ClassEntry
    {
        // Methods
        public ClassEntry(string Name, long pos, int length)
        {
            ConstructorInfo info1 = Utility.FindConstructor(Name);
            if (info1 != null)
            {
                this.m_Class = (ISerialize) info1.Invoke(null);
            }
            this.m_Position = pos;
            this.m_Length = length;
            this.m_ClassName = Name;
        }


        // Properties
        public ISerialize Class
        {
            get
            {
                return this.m_Class;
            }
        }

        public string ClassName
        {
            get
            {
                return this.m_ClassName;
            }
        }

        public int Length
        {
            get
            {
                return this.m_Length;
            }
        }

        public long Position
        {
            get
            {
                return this.m_Position;
            }
        }


        // Fields
        private ISerialize m_Class;
        private string m_ClassName;
        private int m_Length;
        private long m_Position;
    }
}

