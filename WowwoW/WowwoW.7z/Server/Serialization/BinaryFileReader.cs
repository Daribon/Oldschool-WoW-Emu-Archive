namespace Server.Serialization
{
    using Server;
    using System;
    using System.IO;
    using System.Net;

    public class BinaryFileReader : GenReader
    {
        // Methods
        public BinaryFileReader(BinaryReader br)
        {
            this.m_File = br;
        }

        public void Close()
        {
            this.m_File.Close();
        }

        public override bool End()
        {
            return (this.m_File.PeekChar() == -1);
        }

        public override Account ReadAccount()
        {
            string text1 = this.ReadString();
            foreach (Account account1 in World.allAccounts)
            {
                if (account1.Username == text1)
                {
                    return account1;
                }
            }
            return null;
        }

        public override BaseCreature ReadBaseCreature()
        {
            ulong num1 = this.ReadULong();
            foreach (Mobile mobile1 in World.allMobiles)
            {
                if (mobile1.Guid == num1)
                {
                    return (mobile1 as BaseCreature);
                }
            }
            return null;
        }

        public override bool ReadBool()
        {
            return this.m_File.ReadBoolean();
        }

        public override byte ReadByte()
        {
            return this.m_File.ReadByte();
        }

        public override char ReadChar()
        {
            return this.m_File.ReadChar();
        }

        public override Character ReadCharacter()
        {
            ulong num1 = this.ReadULong();
            Accounts.AccountEnumerator enumerator1 = World.allAccounts.GetEnumerator();
            try
            {
                while (enumerator1.MoveNext())
                {
                    foreach (Mobile mobile1 in enumerator1.Current.characteres)
                    {
                        if (mobile1.Guid == num1)
                        {
                            return (mobile1 as Character);
                        }
                    }
                }
            }
            finally
            {
                IDisposable disposable1 = enumerator1 as IDisposable;
                if (disposable1 != null)
                {
                    disposable1.Dispose();
                }
            }
            return null;
        }

        public override DateTime ReadDateTime()
        {
            return new DateTime(this.m_File.ReadInt64());
        }

        public override decimal ReadDecimal()
        {
            return this.m_File.ReadDecimal();
        }

        public override DateTime ReadDeltaTime()
        {
            DateTime time1;
            long num1 = this.m_File.ReadInt64();
            long num2 = DateTime.Now.Ticks;
            if ((num1 > 0) && ((num1 + num2) < 0))
            {
                return DateTime.MaxValue;
            }
            if ((num1 < 0) && ((num1 + num2) < 0))
            {
                return DateTime.MinValue;
            }
            try
            {
                time1 = new DateTime(num2 + num1);
            }
            catch
            {
                if (num1 > 0)
                {
                    return DateTime.MaxValue;
                }
                time1 = DateTime.MinValue;
            }
            return time1;
        }

        public override double ReadDouble()
        {
            return this.m_File.ReadDouble();
        }

        public override int ReadEncodedInt()
        {
            byte num3;
            int num1 = 0;
            int num2 = 0;
            do
            {
                num3 = this.m_File.ReadByte();
                num1 |= ((num3 & 0x7f) << (num2 & 0x1f));
                num2 += 7;
            }
            while (num3 >= 0x80);
            return num1;
        }

        public override float ReadFloat()
        {
            return this.m_File.ReadSingle();
        }

        public override GameObject ReadGameObject()
        {
            ulong num1 = this.ReadULong();
            foreach (GameObject obj1 in World.allGameObjects)
            {
                if (obj1.Guid == num1)
                {
                    return obj1;
                }
            }
            return null;
        }

        public override int ReadInt()
        {
            return this.m_File.ReadInt32();
        }

        public override IPAddress ReadIPAddress()
        {
            return IPAddress.Parse(this.ReadString());
        }

        public override long ReadLong()
        {
            return this.m_File.ReadInt64();
        }

        public override sbyte ReadSByte()
        {
            return this.m_File.ReadSByte();
        }

        public override short ReadShort()
        {
            return this.m_File.ReadInt16();
        }

        public override string ReadString()
        {
            if (this.ReadByte() != 0)
            {
                return this.m_File.ReadString();
            }
            return null;
        }

        public override TimeSpan ReadTimeSpan()
        {
            return new TimeSpan(this.m_File.ReadInt64());
        }

        public override uint ReadUInt()
        {
            return this.m_File.ReadUInt32();
        }

        public override ulong ReadULong()
        {
            return this.m_File.ReadUInt64();
        }

        public override ushort ReadUShort()
        {
            return this.m_File.ReadUInt16();
        }

        public long Seek(long offset, SeekOrigin origin)
        {
            return this.m_File.BaseStream.Seek(offset, origin);
        }


        // Properties
        public long Position
        {
            get
            {
                return this.m_File.BaseStream.Position;
            }
        }


        // Fields
        private BinaryReader m_File;
    }
}

