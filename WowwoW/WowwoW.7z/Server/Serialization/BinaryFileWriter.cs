namespace Server.Serialization
{
    using HelperTools;
    using Server;
    using System;
    using System.IO;
    using System.Net;
    using System.Text;

    public class BinaryFileWriter : GenWriter
    {
        // Methods
        public BinaryFileWriter(FileStream strm)
        {
            this.m_SingleCharBuffer = new char[1];
            this.m_Encoding = Utility.UTF8;
            this.m_Buffer = new byte[0x1000];
            this.m_File = strm;
        }

        public BinaryFileWriter(string filename)
        {
            this.m_SingleCharBuffer = new char[1];
            this.m_Buffer = new byte[0x1000];
            this.m_File = new FileStream(filename, FileMode.Create, FileAccess.Write, FileShare.None);
            this.m_Encoding = Utility.UTF8WithEncoding;
        }

        public override void Close()
        {
            this.Flush();
            this.m_File.Close();
        }

        public void Flush()
        {
            if (this.m_Index > 0)
            {
                this.m_File.Write(this.m_Buffer, 0, this.m_Index);
                this.m_Index = 0;
            }
        }

        internal void InternalWriteString(string value)
        {
            int num1 = this.m_Encoding.GetByteCount(value);
            this.WriteEncodedInt(num1);
            if (this.m_CharacterBuffer == null)
            {
                this.m_CharacterBuffer = new byte[0x100];
                this.m_MaxBufferChars = 0x100 / this.m_Encoding.GetMaxByteCount(1);
            }
            if (num1 > 0x100)
            {
                int num4;
                int num2 = 0;
                for (int num3 = value.Length; num3 > 0; num3 -= num4)
                {
                    num4 = (num3 > this.m_MaxBufferChars) ? this.m_MaxBufferChars : num3;
                    int num5 = this.m_Encoding.GetBytes(value, num2, num4, this.m_CharacterBuffer, 0);
                    if ((this.m_Index + num5) > 0x1000)
                    {
                        this.Flush();
                    }
                    Buffer.BlockCopy(this.m_CharacterBuffer, 0, this.m_Buffer, this.m_Index, num5);
                    this.m_Index += num5;
                    num2 += num4;
                }
            }
            else
            {
                int num6 = this.m_Encoding.GetBytes(value, 0, value.Length, this.m_CharacterBuffer, 0);
                if ((this.m_Index + num6) > 0x1000)
                {
                    this.Flush();
                }
                Buffer.BlockCopy(this.m_CharacterBuffer, 0, this.m_Buffer, this.m_Index, num6);
                this.m_Index += num6;
            }
        }

        public override void Write(Account value)
        {
            this.Write(value.Username);
        }

        public override void Write(BaseCreature value)
        {
            this.Write(value.Guid);
        }

        public override void Write(Character value)
        {
            this.Write(value.Guid);
        }

        public override void Write(GameObject value)
        {
            this.Write(value.Guid);
        }

        public override void Write(bool value)
        {
            if ((this.m_Index + 1) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index++] = value ? ((byte) 1) : ((byte) 0);
        }

        public override void Write(byte value)
        {
            if ((this.m_Index + 1) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index++] = value;
        }

        public override void Write(char value)
        {
            if ((this.m_Index + 8) > 0x1000)
            {
                this.Flush();
            }
            this.m_SingleCharBuffer[0] = value;
            int num1 = this.m_Encoding.GetBytes(this.m_SingleCharBuffer, 0, 1, this.m_Buffer, this.m_Index);
            this.m_Index += num1;
        }

        public override void Write(DateTime value)
        {
            this.Write(value.Ticks);
        }

        public override void Write(decimal value)
        {
            int[] numArray1 = decimal.GetBits(value);
            for (int num1 = 0; num1 < numArray1.Length; num1++)
            {
                this.Write(numArray1[num1]);
            }
        }

        public override void Write(double value)
        {
            if ((this.m_Index + 8) > 0x1000)
            {
                this.Flush();
            }
            byte[] buffer1 = BitConverter.GetBytes(value);
            for (int num1 = 0; num1 < 8; num1++)
            {
                this.m_Buffer[this.m_Index + num1] = buffer1[num1];
            }
            this.m_Index += 8;
        }

        public override void Write(short value)
        {
            if ((this.m_Index + 2) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index] = (byte) value;
            this.m_Buffer[this.m_Index + 1] = (byte) (value >> 8);
            this.m_Index += 2;
        }

        public override void Write(int value)
        {
            if ((this.m_Index + 4) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index] = (byte) value;
            this.m_Buffer[this.m_Index + 1] = (byte) (value >> 8);
            this.m_Buffer[this.m_Index + 2] = (byte) (value >> 0x10);
            this.m_Buffer[this.m_Index + 3] = (byte) (value >> 0x18);
            this.m_Index += 4;
        }

        public override void Write(long value)
        {
            if ((this.m_Index + 8) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index] = (byte) value;
            this.m_Buffer[this.m_Index + 1] = (byte) (value >> 8);
            this.m_Buffer[this.m_Index + 2] = (byte) (value >> 0x10);
            this.m_Buffer[this.m_Index + 3] = (byte) (value >> 0x18);
            this.m_Buffer[this.m_Index + 4] = (byte) (value >> 0x20);
            this.m_Buffer[this.m_Index + 5] = (byte) (value >> 40);
            this.m_Buffer[this.m_Index + 6] = (byte) (value >> 0x30);
            this.m_Buffer[this.m_Index + 7] = (byte) (value >> 0x38);
            this.m_Index += 8;
        }

        public override void Write(IPAddress value)
        {
            this.Write(value.ToString());
        }

        public override void Write(sbyte value)
        {
            if ((this.m_Index + 1) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index++] = (byte) value;
        }

        public override void Write(float value)
        {
            if ((this.m_Index + 4) > 0x1000)
            {
                this.Flush();
            }
            byte[] buffer1 = BitConverter.GetBytes(value);
            for (int num1 = 0; num1 < 4; num1++)
            {
                this.m_Buffer[this.m_Index + num1] = buffer1[num1];
            }
            this.m_Index += 4;
        }

        public override void Write(string value)
        {
            if (value == null)
            {
                if ((this.m_Index + 1) > 0x1000)
                {
                    this.Flush();
                }
                this.m_Buffer[this.m_Index++] = 0;
            }
            else
            {
                if ((this.m_Index + 1) > 0x1000)
                {
                    this.Flush();
                }
                this.m_Buffer[this.m_Index++] = 1;
                this.InternalWriteString(value);
            }
        }

        public override void Write(TimeSpan value)
        {
            this.Write(value.Ticks);
        }

        public override void Write(ushort value)
        {
            if ((this.m_Index + 2) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index] = (byte) value;
            this.m_Buffer[this.m_Index + 1] = (byte) (value >> 8);
            this.m_Index += 2;
        }

        public override void Write(uint value)
        {
            if ((this.m_Index + 4) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index] = (byte) value;
            this.m_Buffer[this.m_Index + 1] = (byte) (value >> 8);
            this.m_Buffer[this.m_Index + 2] = (byte) (value >> 0x10);
            this.m_Buffer[this.m_Index + 3] = (byte) (value >> 0x18);
            this.m_Index += 4;
        }

        public override void Write(ulong value)
        {
            if ((this.m_Index + 8) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index] = (byte) value;
            this.m_Buffer[this.m_Index + 1] = (byte) (value >> 8);
            this.m_Buffer[this.m_Index + 2] = (byte) (value >> 0x10);
            this.m_Buffer[this.m_Index + 3] = (byte) (value >> 0x18);
            this.m_Buffer[this.m_Index + 4] = (byte) (value >> 0x20);
            this.m_Buffer[this.m_Index + 5] = (byte) (value >> 40);
            this.m_Buffer[this.m_Index + 6] = (byte) (value >> 0x30);
            this.m_Buffer[this.m_Index + 7] = (byte) (value >> 0x38);
            this.m_Index += 8;
        }

        public override void WriteDeltaTime(DateTime value)
        {
            TimeSpan span1;
            long num1 = value.Ticks;
            long num2 = DateTime.Now.Ticks;
            try
            {
                span1 = new TimeSpan(num1 - num2);
            }
            catch
            {
                if (num1 < num2)
                {
                    span1 = TimeSpan.MaxValue;
                }
                else
                {
                    span1 = TimeSpan.MaxValue;
                }
            }
            this.Write(span1);
        }

        public override void WriteEncodedInt(int value)
        {
            uint num1 = (uint) value;
            while (num1 >= 0x80)
            {
                if ((this.m_Index + 1) > 0x1000)
                {
                    this.Flush();
                }
                this.m_Buffer[this.m_Index++] = (byte) (num1 | 0x80);
                num1 = num1 >> 7;
            }
            if ((this.m_Index + 1) > 0x1000)
            {
                this.Flush();
            }
            this.m_Buffer[this.m_Index++] = (byte) num1;
        }


        // Properties
        public override long Position
        {
            get
            {
                this.Flush();
                return this.m_File.Position;
            }
        }

        public Stream UnderlyingStream
        {
            get
            {
                this.Flush();
                return this.m_File;
            }
        }


        // Fields
        private const int BufferSize = 0x1000;
        private const int LargeByteBufferSize = 0x100;
        private byte[] m_Buffer;
        private byte[] m_CharacterBuffer;
        private Encoding m_Encoding;
        private FileStream m_File;
        private int m_Index;
        private int m_MaxBufferChars;
        private char[] m_SingleCharBuffer;
    }
}

