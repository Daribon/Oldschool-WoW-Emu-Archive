namespace Server.Serialization
{
    using System;

    public interface ISerialize
    {
        // Methods
        void Deserialize(GenReader reader);

        void Serialize(GenWriter writer);

    }
}

