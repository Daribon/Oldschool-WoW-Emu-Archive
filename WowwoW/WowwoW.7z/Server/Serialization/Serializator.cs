namespace Server.Serialization
{
    using HelperTools;
    using Server;
    using System;
    using System.Collections;
    using System.IO;
    using System.Reflection;

    public class Serializator : IInitialize
    {
        // Methods
        static Serializator()
        {
            Serializator.SerializeList = new ArrayList();
        }

        public Serializator()
        {
        }

        public static void GenerateList()
        {
            Type[] typeArray1 = Utility.externAsm.GetTypes();
            for (int num1 = 0; num1 < typeArray1.Length; num1++)
            {
                if (typeArray1[num1].GetInterface("ISerialize", true) != null)
                {
                    ConstructorInfo info1 = Utility.FindConstructor(typeArray1[num1].FullName);
                    Serializator.SerializeList.Add(info1.Invoke(null));
                }
            }
        }

        public static void Initialize()
        {
            World.onSave = (World.OnSaveDelegate) Delegate.Combine(World.onSave, new World.OnSaveDelegate(Serializator.Save));
            Serializator.Load();
            Serializator.GenerateList();
        }

        public static void Load()
        {
            ArrayList list1 = new ArrayList();
            if (File.Exists("Scriptsave.bin") || File.Exists("Scriptsave.idx"))
            {
                Console.Write("Scriptsave: Loading...");
                using (FileStream stream1 = new FileStream("Scriptsave.idx", FileMode.Open, FileAccess.Read, FileShare.Read))
                {
                    BinaryFileReader reader1 = new BinaryFileReader(new BinaryReader(stream1));
                    int num1 = reader1.ReadInt();
                    for (int num2 = 0; num2 < num1; num2++)
                    {
                        string text1 = reader1.ReadString();
                        ConstructorInfo info1 = Utility.FindConstructor(text1);
                        if (info1 == null)
                        {
                            Console.WriteLine("failed");
                            Console.WriteLine("Error: Type '{0}' was not found. Delete this type? (y/n)", text1);
                            if (Console.ReadLine() == "y")
                            {
                                Console.Write("Scriptsave: Loading...");
                                reader1.ReadLong();
                                reader1.ReadInt();
                                goto Label_0155;
                            }
                            Console.WriteLine("Type will not be deleted. An exception will be thrown when you press return");
                            Console.ReadLine();
                            throw new Exception(string.Format("Bad type '{0}'", text1));
                        }
                        long num3 = reader1.ReadLong();
                        int num4 = reader1.ReadInt();
                        if (info1.Invoke(null) is ISerialize)
                        {
                            list1.Add(new ClassEntry(text1, num3, num4));
                        }
                        else
                        {
                            Console.WriteLine("failed");
                            Console.WriteLine("Error: Type '{0}' is not ISerialize. Delete this type? (y/n)", text1);
                            if (Console.ReadLine() == "y")
                            {
                                Console.Write("Scriptsave: Loading...");
                            }
                            else
                            {
                                Console.WriteLine("Type will not be deleted. An exception will be thrown when you press return");
                                Console.ReadLine();
                                throw new Exception(string.Format("Bad type '{0}'", text1));
                            }
                        }
                    Label_0155:;
                    }
                }
                if (File.Exists("Scriptsave.bin"))
                {
                    using (FileStream stream2 = new FileStream("Scriptsave.bin", FileMode.Open, FileAccess.Read, FileShare.Read))
                    {
                        BinaryFileReader reader2 = new BinaryFileReader(new BinaryReader(stream2));
                        for (int num5 = 0; num5 < list1.Count; num5++)
                        {
                            ClassEntry entry1 = (ClassEntry) list1[num5];
                            ISerialize serialize1 = entry1.Class;
                            reader2.Seek(entry1.Position, SeekOrigin.Begin);
                            serialize1.Deserialize(reader2);
                            if (reader2.Position != (entry1.Position + entry1.Length))
                            {
                                Console.WriteLine("failed");
                                Console.WriteLine(string.Format("***** Bad serialize on '{0}' type *****", entry1.ClassName));
                                Console.WriteLine("Do you want to remove this serialize? (y/n)");
                                string text2 = entry1.ClassName;
                                if (Console.ReadLine() == "y")
                                {
                                    list1.RemoveAt(num5);
                                    BinaryFileWriter writer1 = new BinaryFileWriter("Scriptsave.idx");
                                    writer1.Write(list1.Count);
                                    foreach (ClassEntry entry2 in list1)
                                    {
                                        writer1.Write(entry2.ClassName);
                                        writer1.Write(entry2.Position);
                                        writer1.Write(entry2.Length);
                                    }
                                    writer1.Close();
                                    Console.WriteLine("Serialization of '" + text2 + "' removed.");
                                    Console.WriteLine("An exception will be thrown when you press return");
                                    Console.ReadLine();
                                    throw new Exception(string.Format("Bad serialize", new object[0]));
                                }
                                Console.WriteLine("Serialization of '" + text2 + "' don't removed.");
                                Console.WriteLine("An exception will be thrown when you press return");
                                Console.ReadLine();
                                throw new Exception(string.Format("Bad serialize", new object[0]));
                            }
                        }
                        reader2.Close();
                        Console.WriteLine("done");
                    }
                }
            }
        }

        public static void Save()
        {
            Console.Write("Saving serialized classes...");
            BinaryFileWriter writer1 = new BinaryFileWriter("Scriptsave.bin");
            BinaryFileWriter writer2 = new BinaryFileWriter("Scriptsave.idx");
            writer2.Write(Serializator.SerializeList.Count);
            foreach (ISerialize serialize1 in Serializator.SerializeList)
            {
                writer2.Write(serialize1.GetType().FullName);
                long num1 = writer1.Position;
                writer2.Write(num1);
                serialize1.Serialize(writer1);
                writer2.Write((int) (writer1.Position - num1));
            }
            Console.WriteLine("done.");
            writer1.Close();
            writer2.Close();
        }


        // Fields
        public static ArrayList SerializeList;
    }
}

