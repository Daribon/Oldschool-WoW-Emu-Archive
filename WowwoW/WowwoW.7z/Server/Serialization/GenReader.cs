namespace Server.Serialization
{
    using Server;
    using System;
    using System.Net;

    public abstract class GenReader
    {
        // Methods
        public GenReader()
        {
        }

        public abstract bool End();

        public abstract Account ReadAccount();

        public abstract BaseCreature ReadBaseCreature();

        public abstract bool ReadBool();

        public abstract byte ReadByte();

        public abstract char ReadChar();

        public abstract Character ReadCharacter();

        public abstract DateTime ReadDateTime();

        public abstract decimal ReadDecimal();

        public abstract DateTime ReadDeltaTime();

        public abstract double ReadDouble();

        public abstract int ReadEncodedInt();

        public abstract float ReadFloat();

        public abstract GameObject ReadGameObject();

        public abstract int ReadInt();

        public abstract IPAddress ReadIPAddress();

        public abstract long ReadLong();

        public abstract sbyte ReadSByte();

        public abstract short ReadShort();

        public abstract string ReadString();

        public abstract TimeSpan ReadTimeSpan();

        public abstract uint ReadUInt();

        public abstract ulong ReadULong();

        public abstract ushort ReadUShort();

    }
}

