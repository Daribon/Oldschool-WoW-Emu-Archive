namespace Server
{
    using System;

    public class Marksmanship : Skill
    {
        // Methods
        public Marksmanship()
        {
        }

        public Marksmanship(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xa3;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xa3;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

