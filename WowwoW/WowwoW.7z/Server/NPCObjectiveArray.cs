namespace Server
{
    using System;
    using System.Collections;

    public class NPCObjectiveArray
    {
        // Methods
        static NPCObjectiveArray()
        {
            NPCObjectiveArray._max = 4;
        }

        public NPCObjectiveArray()
        {
            this._items = new ArrayList();
        }

        public void Add(NPCObjective npco)
        {
            if (npco.TypeObj == TypeNpcObj.Mobile)
            {
                if (npco.ExistsInWorld)
                {
                    if (!this.CanAdd)
                    {
                        return;
                    }
                    this._items.Add(npco);
                }
                else
                {
                    BadIdList.AddMobileId(npco.Id);
                }
            }
        }

        public void Add(int id, int amount)
        {
            this.Add(new NPCObjective(id, amount));
        }

        public void Add(int id, int amount, TypeNpcObj typeObj, string description)
        {
            this.Add(new NPCObjective(id, amount, typeObj, description));
        }

        public NPCObjective GetById(int id)
        {
            NPCObjective objective1 = null;
            foreach (NPCObjective objective2 in this._items)
            {
                if (objective2.Id2 == id)
                {
                    return objective2;
                }
            }
            return objective1;
        }


        // Properties
        private bool CanAdd
        {
            get
            {
                return (this.Count < NPCObjectiveArray._max);
            }
        }

        public int Count
        {
            get
            {
                return this._items.Count;
            }
        }

        public NPCObjective[] Items
        {
            get
            {
                return (NPCObjective[]) this._items.ToArray(typeof(NPCObjective));
            }
        }


        // Fields
        private ArrayList _items;
        private static int _max;
    }
}

