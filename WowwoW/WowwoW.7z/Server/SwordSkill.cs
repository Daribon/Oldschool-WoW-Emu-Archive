namespace Server
{
    using System;

    public class SwordSkill : Skill
    {
        // Methods
        public SwordSkill()
        {
        }

        public SwordSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x2b;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x2b;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xc9;
            }
        }

    }
}

