namespace Server
{
    using System;

    public enum AccessLevels
    {
        // Fields
        Admin = 2,
        GM = 1,
        PlayerLevel = 0
    }
}

