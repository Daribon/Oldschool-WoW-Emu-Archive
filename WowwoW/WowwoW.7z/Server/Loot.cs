namespace Server
{
    using Server.Items;
    using System;
    using System.Reflection;

    public class Loot
    {
        // Methods
        public Loot(Type type, float proba)
        {
            try
            {
                int num1;
                this.maxAmount = num1 = 1;
                this.minAmount = num1;
                ConstructorInfo[] infoArray1 = type.GetConstructors();
                ConstructorInfo[] infoArray3 = infoArray1;
                for (num1 = 0; num1 < infoArray3.Length; num1++)
                {
                    ConstructorInfo info1 = infoArray3[num1];
                    ParameterInfo[] infoArray2 = info1.GetParameters();
                    if (infoArray2.Length == 0)
                    {
                        this.constructor = info1;
                    }
                }
                this.probability = proba;
            }
            catch (Exception)
            {
                Console.WriteLine("Error while constructing {0}", type.ToString());
            }
        }

        public Loot(Type type, int minamount, int maxamount, float proba)
        {
            try
            {
                this.minAmount = minamount;
                this.maxAmount = maxamount;
                ConstructorInfo[] infoArray1 = type.GetConstructors();
                ConstructorInfo[] infoArray3 = infoArray1;
                for (int num1 = 0; num1 < infoArray3.Length; num1++)
                {
                    ConstructorInfo info1 = infoArray3[num1];
                    ParameterInfo[] infoArray2 = info1.GetParameters();
                    if (infoArray2.Length == 0)
                    {
                        this.constructor = info1;
                    }
                }
                this.probability = proba;
            }
            catch (Exception)
            {
                Console.WriteLine("Error while constructing {0}", type.ToString());
            }
        }

        public Item Create()
        {
            return (Item) this.constructor.Invoke(null);
        }

        public Item Create(int n)
        {
            Item item1 = (Item) this.constructor.Invoke(null);
            item1.MaxCount = n;
            return item1;
        }


        // Properties
        public ConstructorInfo Constructor
        {
            get
            {
                return this.constructor;
            }
        }

        public int MaxAmount
        {
            get
            {
                return this.maxAmount;
            }
        }

        public int MinAmount
        {
            get
            {
                return this.minAmount;
            }
        }

        public float Probability
        {
            get
            {
                return this.probability;
            }
        }


        // Fields
        private ConstructorInfo constructor;
        private int maxAmount;
        private int minAmount;
        private float probability;
    }
}

