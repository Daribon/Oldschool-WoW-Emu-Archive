namespace Server
{
    using System;

    public class ShieldSkill : Skill
    {
        // Methods
        public ShieldSkill()
        {
        }

        public ShieldSkill(int current, int max) : base(1, 1)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x1b1;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x1b1;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x239c;
            }
        }

    }
}

