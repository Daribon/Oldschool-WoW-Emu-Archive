namespace Server
{
    using System;

    public class DotAura : Aura
    {
        // Methods
        public DotAura(SpellTemplate st, Mobile c, Mobile t, int d, int dur, int freq)
        {
            if (!t.Dead)
            {
                this.spell = st;
                this.from = c;
                this.target = t;
                this.dmg = d;
                this.duration = dur;
                this.frequency = freq;
                base.PeriodicAura(new Aura.AuraPeriodicEffect(this.PeriodicDamage), dur, freq);
            }
        }

        public void PeriodicDamage()
        {
            this.spell.MakeDamage(this.from, this.target, this.dmg, false);
        }


        // Fields
        private float dmg;
        private int duration;
        private int frequency;
        private Mobile from;
        private SpellTemplate spell;
        private Mobile target;
    }
}

