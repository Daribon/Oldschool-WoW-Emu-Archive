namespace Server
{
    using Server.Creatures;
    using System;
    using System.Collections;
    using System.IO;
    using System.Threading;

    public class NPCQuests
    {
        // Methods
        static NPCQuests()
        {
            NPCQuests.status = InitStatus.None;
            NPCQuests._NPCQuests = new Hashtable();
            NPCQuests.errors = new ArrayList();
        }

        public NPCQuests()
        {
        }

        private static void AddErr(string text, params string[] data)
        {
            NPCQuests.errors.Add(new Err(text, data));
        }

        private static void AddErrHeader(string format, params object[] args)
        {
            NPCQuests.errors.Add(string.Format(format, args));
        }

        private static void AddQuest(int npcId, int questId)
        {
            NPCQuests.AddTo(NPCQuests._NPCQuests, npcId, questId);
        }

        private static void AddTo(Hashtable _list, int _key, int _val)
        {
            if (_list.ContainsKey(_key))
            {
                ArrayList list1 = (ArrayList) _list[_key];
                if (list1.Contains(_val))
                {
                    return;
                }
                list1.Add(_val);
            }
            else
            {
                ArrayList list2 = new ArrayList();
                list2.Add(_val);
                _list.Add(_key, list2);
            }
        }

        private static void CheckQuest(Hashtable _cArr, int _cId, BaseQuest bq, bool addQuest, string nameVar)
        {
            string[] textArray1;
            if (_cId > 0)
            {
                if (_cArr.ContainsKey(_cId))
                {
                    if (((BaseCreature) _cArr[_cId]) is BaseNPC)
                    {
                        if (addQuest)
                        {
                            NPCQuests.AddQuest(_cId, bq.Id);
                        }
                    }
                    else
                    {
                        string text1 = string.Format("* {0} have bad \"{1} = {2};\" link", bq.GetType().Name, nameVar, _cId);
                        string text2 = string.Format("\t> Need change \"BaseCreature\" to \"BaseNPC\" in inherite (header) area.", new object[0]);
                        string text3 = string.Format("\t-> Ex: \"public class {0}: BaseNPC\"", ((BaseCreature) _cArr[_cId]).GetType().Name);
                        textArray1 = new string[2] { text2, text3 } ;
                        NPCQuests.AddErr(text1, textArray1);
                    }
                }
                else
                {
                    string text4 = string.Format("* {0} have bad \"{1}\" link ( Creature \"Id = {2}\" is not exist: need remark this and use questisBugged or write this creature script )", bq.GetType().Name, nameVar, _cId);
                    string text5 = string.Format("\t> Need create this creature \"Id = {0};\"", _cId);
                    string text6 = string.Format("\t> Or Remark line \"//{1} = {0};\" and use \"questIsBugged = true;\"", _cId, nameVar);
                    textArray1 = new string[2] { text5, text6 } ;
                    NPCQuests.AddErr(text4, textArray1);
                }
            }
            else if (addQuest)
            {
                string text7 = string.Format("* {0} have bad \"{1} = ?;\" link ( need use Id from NPC questOwner )", bq.GetType().Name, nameVar);
                string text8 = string.Format("\t> Need search and find this creature questOwner and then use Id number to \"npcId = (Id);\"", new object[0]);
                string text9 = string.Format("\t> Or create this creature and then use it number..", new object[0]);
                textArray1 = new string[2] { text8, text9 } ;
                NPCQuests.AddErr(text7, textArray1);
            }
        }

        private static BaseCreature[] GetAllCreaturesInWorld()
        {
            ArrayList list1 = new ArrayList();
            foreach (BaseCreature creature1 in World.allMobs)
            {
                list1.Add(creature1);
            }
            return (BaseCreature[]) list1.ToArray(typeof(BaseCreature));
        }

        private static BaseQuest[] GetAllQuestsInWorld()
        {
            ArrayList list1 = new ArrayList();
            list1.AddRange(World.QuestPool.Values);
            return (BaseQuest[]) list1.ToArray(typeof(BaseQuest));
        }

        private static ArrayList GetFrom(Hashtable _list, int _key)
        {
            ArrayList list1 = new ArrayList();
            if (_list.ContainsKey(_key))
            {
                list1.AddRange((ArrayList) _list[_key]);
            }
            return list1;
        }

        public static BaseQuest[] GetQuestsFor(int npcId)
        {
            if (NPCQuests._NPCQuests.ContainsKey(npcId))
            {
                if (NPCQuests._NPCQuests[npcId] is BaseQuest[])
                {
                    return (BaseQuest[]) NPCQuests._NPCQuests[npcId];
                }
                if (NPCQuests._NPCQuests[npcId] is ArrayList)
                {
                    ArrayList list1 = new ArrayList();
                    foreach (int num1 in (NPCQuests._NPCQuests[npcId] as ArrayList))
                    {
                        BaseQuest quest1 = World.CreateQuestById(num1);
                        if (quest1 != null)
                        {
                            list1.Add(quest1);
                        }
                    }
                    return (BaseQuest[]) list1.ToArray(typeof(BaseQuest));
                }
            }
            return new BaseQuest[0];
        }

        public static void Init()
        {
            if ((NPCQuests.status == InitStatus.None) && !World.Loading)
            {
                NPCQuests.status = InitStatus.Started;
                ThreadPriority priority1 = Thread.CurrentThread.Priority;
                Thread.CurrentThread.Priority = ThreadPriority.Highest;
                bool flag1 = false;
                bool flag2 = false;
                try
                {
                    string[] textArray1;
                    BaseQuest[] questArray1 = NPCQuests.GetAllQuestsInWorld();
                    BaseCreature[] creatureArray1 = NPCQuests.GetAllCreaturesInWorld();
                    Hashtable hashtable1 = new Hashtable();
                    BaseCreature[] creatureArray2 = creatureArray1;
                    int num3 = 0;
                    while (num3 < creatureArray2.Length)
                    {
                        BaseCreature creature1 = creatureArray2[num3];
                        if (!hashtable1.ContainsKey(creature1.Id))
                        {
                            hashtable1.Add(creature1.Id, creature1);
                        }
                        else if (creature1.Id > 0)
                        {
                            string text1 = string.Format("* {0} is already have ( [{2}].Id = {1} )", creature1.GetType().Name, creature1.Id, ((BaseCreature) hashtable1[creature1.Id]).GetType().Name);
                            string text2 = string.Format("\t> Check this creatureId \"{0}\" in each script", creature1.Id);
                            textArray1 = new string[1] { text2 } ;
                            NPCQuests.AddErr(text1, textArray1);
                        }
                        if (((creature1.Quests != null) && (creature1.GetType().Name != "BaseNPC")) && (creature1.Quests.Length > 0))
                        {
                            string text3 = string.Format("* {0} already have Quests line", creature1.GetType().Name);
                            string text4 = string.Format("\t> Need remove/remark this line \"Quests = new ...\"", new object[0]);
                            string text5 = string.Format("\t-> remark mean \"//Quests = new ...\"", new object[0]);
                            textArray1 = new string[2] { text4, text5 } ;
                            NPCQuests.AddErr(text3, textArray1);
                        }
                        num3++;
                    }
                    if (NPCQuests.errors.Count > 0)
                    {
                        NPCQuests.errors.Insert(0, "");
                        NPCQuests.errors.Insert(0, "Start checking Creatures [Server.Creatures]");
                        NPCQuests.AddErrHeader("", new object[0]);
                        NPCQuests.AddErrHeader("Start checking Quests [Server.Quests]", new object[0]);
                        NPCQuests.AddErrHeader("", new object[0]);
                        flag2 = true;
                    }
                    BaseQuest[] questArray2 = questArray1;
                    for (num3 = 0; num3 < questArray2.Length; num3++)
                    {
                        BaseQuest quest1 = questArray2[num3];
                        NPCQuests.CheckQuest(hashtable1, quest1.NPCId, quest1, true, "NPCId");
                        NPCQuests.CheckQuest(hashtable1, quest1.NPCTargetId, quest1, false, "NpcTargetId");
                        if (!quest1.QuestIsBugged)
                        {
                            if ((quest1.PreviousQuest > 0) && !NPCQuests.QuestExists(quest1.PreviousQuest))
                            {
                                string text6 = string.Format("* {0} have bad link to PreviousQuest (prev quest is not exist)", quest1.GetType().Name);
                                string text7 = string.Format("\t> Try do quest by number {0}", quest1.PreviousQuest);
                                string text8 = string.Format("\t> Or comment this line \"previousQuest = {0};\"", quest1.PreviousQuest);
                                textArray1 = new string[2] { text7, text8 } ;
                                NPCQuests.AddErr(text6, textArray1);
                            }
                            if ((quest1.NextQuest > 0) && !NPCQuests.QuestExists(quest1.NextQuest))
                            {
                                string text9 = string.Format("* {0} have bad link to NextQuest (next quest is not exist)", quest1.GetType().Name);
                                string text10 = string.Format("\t> Try do quest by number {0}", quest1.NextQuest);
                                string text11 = string.Format("\t> Or comment this line \"nextQuest = {0};\"", quest1.NextQuest);
                                textArray1 = new string[2] { text10, text11 } ;
                                NPCQuests.AddErr(text9, textArray1);
                            }
                            if (quest1.QuestFlags == 0)
                            {
                                string text12 = string.Format("* {0} have bad questFlags ( value is 0 )", quest1.GetType().Name);
                                string text13 = string.Format("\t> Try change value to \"questFlags = 0x20;\"", new object[0]);
                                textArray1 = new string[1] { text13 } ;
                                NPCQuests.AddErr(text12, textArray1);
                            }
                        }
                    }
                    if ((NPCQuests.errors.Count > 0) && !flag2)
                    {
                        NPCQuests.errors.Insert(0, "");
                        NPCQuests.errors.Insert(0, "Start checking Quests [Server.Quests]");
                    }
                    Hashtable hashtable2 = new Hashtable();
                    foreach (int num1 in NPCQuests._NPCQuests.Keys)
                    {
                        ArrayList list1 = (ArrayList) NPCQuests._NPCQuests[num1];
                        ArrayList list2 = new ArrayList();
                        foreach (int num2 in list1)
                        {
                            BaseQuest quest2 = World.CreateQuestById(num2);
                            if (quest2 != null)
                            {
                                list2.Add(quest2);
                            }
                        }
                        hashtable2.Add(num1, (BaseQuest[]) list2.ToArray(typeof(BaseQuest)));
                    }
                    NPCQuests._NPCQuests.Clear();
                    NPCQuests._NPCQuests = hashtable2;
                }
                catch (Exception exception1)
                {
                    flag1 = true;
                    NPCQuests.AddErrHeader("", new object[0]);
                    object[] objArray1 = new object[1] { exception1 } ;
                    NPCQuests.AddErrHeader("Exeption: {0}", objArray1);
                    NPCQuests.AddErrHeader("", new object[0]);
                    objArray1 = new object[1] { exception1.Message } ;
                    NPCQuests.AddErrHeader("message: {0}", objArray1);
                    objArray1 = new object[1] { exception1.Source } ;
                    NPCQuests.AddErrHeader("source: {0}", objArray1);
                    objArray1 = new object[1] { exception1.StackTrace } ;
                    NPCQuests.AddErrHeader("stack trace: {0}", objArray1);
                    objArray1 = new object[1] { exception1.InnerException } ;
                    NPCQuests.AddErrHeader("inner exeption: {0}", objArray1);
                    objArray1 = new object[1] { exception1.TargetSite } ;
                    NPCQuests.AddErrHeader("target site: {0}", objArray1);
                    objArray1 = new object[1] { exception1.HelpLink } ;
                    NPCQuests.AddErrHeader("help link: {0}", objArray1);
                }
                finally
                {
                    Thread.CurrentThread.Priority = priority1;
                }
                if (!flag1)
                {
                    NPCQuests.status = InitStatus.Done;
                }
            }
        }

        public static void LOGErrors(string filename, bool overvrite)
        {
            using (StreamWriter writer1 = new StreamWriter(filename, overvrite))
            {
                writer1.WriteLine(" Warning List from [{0}], please read carefuly ", DateTime.Now);
                writer1.WriteLine("");
                foreach (object obj1 in NPCQuests.errors)
                {
                    writer1.WriteLine(obj1.ToString());
                }
            }
        }

        private static bool QuestExists(int qId)
        {
            return (World.QuestPool[qId] != null);
        }


        // Properties
        private static int errorsCount
        {
            get
            {
                int num1 = 0;
                for (int num2 = 0; num2 < NPCQuests.errors.Count; num2++)
                {
                    if (NPCQuests.errors[num2] is Err)
                    {
                        num1++;
                    }
                }
                return num1;
            }
        }

        public static InitStatus Status
        {
            get
            {
                return NPCQuests.status;
            }
        }


        // Fields
        private static Hashtable _NPCQuests;
        private static ArrayList errors;
        private static InitStatus status;
        public const string Version = "04.10.05";

        // Nested Types
        private class Err
        {
            // Methods
            public Err(string text, params string[] data)
            {
                this.num = 1;
                this._text = "";
                this._data = null;
                this._text = text;
                this._data = data;
            }

            public override string ToString()
            {
                string text1 = this._text;
                if (this._data != null)
                {
                    string[] textArray1 = this._data;
                    for (int num1 = 0; num1 < textArray1.Length; num1++)
                    {
                        string text2 = textArray1[num1];
                        text1 = text1 + "\r\n" + text2;
                    }
                }
                return text1;
            }


            // Fields
            private string[] _data;
            private string _text;
            public int num;
        }
    }
}

