namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void OnSelfSpellEffect(BaseAbility ba, Mobile c);

}

