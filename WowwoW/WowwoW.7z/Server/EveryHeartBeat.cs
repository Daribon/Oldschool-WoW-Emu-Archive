namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool EveryHeartBeat(Character c);

}

