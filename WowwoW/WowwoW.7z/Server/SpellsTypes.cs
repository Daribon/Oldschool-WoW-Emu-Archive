namespace Server
{
    using System;

    public enum SpellsTypes
    {
        // Fields
        Curse = 4,
        Defensive = 2,
        Healing = 3,
        None = 0,
        Offensive = 1
    }
}

