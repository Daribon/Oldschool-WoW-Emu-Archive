namespace Server
{
    using System;

    public class TaxiPathNode
    {
        // Methods
        public TaxiPathNode(int _id, int _taxiPath, int _index, int _mapId, double _x, double _y, double _z)
        {
            this.id = _id;
            this.taxiPath = _taxiPath;
            this.index = _index;
            this.mapId = _mapId;
            this.x = (float) _x;
            this.z = (float) _z;
            this.y = (float) _y;
        }


        // Properties
        public int Id
        {
            get
            {
                return this.id;
            }
        }

        public int Index
        {
            get
            {
                return this.index;
            }
        }

        public int MapId
        {
            get
            {
                return this.mapId;
            }
        }

        public int TaxiPath
        {
            get
            {
                return this.taxiPath;
            }
        }

        public float X
        {
            get
            {
                return this.x;
            }
        }

        public float Y
        {
            get
            {
                return this.y;
            }
        }

        public float Z
        {
            get
            {
                return this.z;
            }
        }


        // Fields
        private int id;
        private int index;
        private int mapId;
        private int taxiPath;
        private float x;
        private float y;
        private float z;
    }
}

