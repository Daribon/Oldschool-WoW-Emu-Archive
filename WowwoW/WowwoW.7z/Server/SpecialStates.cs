namespace Server
{
    using System;

    public enum SpecialStates
    {
        // Fields
        AmplifyCurse = 5,
        ArcanePower = 3,
        Bloodthirst = 4,
        Combustion = 1,
        FelDomination = 6,
        None = 0,
        PresenceOfMind = 2,
        WarlockCurse = 8,
        WarlockFear = 7
    }
}

