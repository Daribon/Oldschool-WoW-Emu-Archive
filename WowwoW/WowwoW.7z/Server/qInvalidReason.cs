namespace Server
{
    using System;

    public enum qInvalidReason
    {
        // Fields
        DontHaveReq = 0,
        DontHaveReqItems = 0x13,
        DontHaveReqMoney = 0x15,
        NotAvailableRace = 6,
        NotEnoughLevel = 1,
        ReadyHaveThatQuest = 13,
        ReadyHaveTimedQuest = 12
    }
}

