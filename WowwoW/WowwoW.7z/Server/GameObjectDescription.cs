namespace Server
{
    using System;
    using System.Collections;

    public class GameObjectDescription
    {
        // Methods
        static GameObjectDescription()
        {
            GameObjectDescription.all = new Hashtable();
        }

        public GameObjectDescription(string n, int t, int mod)
        {
            this.name = n;
            this.type = (byte) t;
            this.model = (ushort) mod;
        }

        public GameObjectDescription(string n, int t, int mod, uint[] s) : this(n, t, mod)
        {
            this.sound = s;
        }

        public GameObjectDescription(string n, int t, int mod, float siz, int flag, uint[] s) : this(n, t, mod)
        {
            this.sound = s;
            this.size = siz;
            this.flags = flag;
            this.type = (byte) t;
        }

        public GameObjectDescription(string n, int t, int mod, float siz, int flag, Loot[] l, uint[] s) : this(n, t, mod)
        {
            BaseTreasure[] treasureArray2 = new BaseTreasure[1] { new BaseTreasure(l, 100f) } ;
            BaseTreasure[] treasureArray1 = treasureArray2;
            this.sound = s;
            this.loots = treasureArray1;
            this.size = siz;
            this.flags = flag;
            this.type = (byte) t;
        }


        // Properties
        public int Flags
        {
            get
            {
                return this.flags;
            }
        }

        public BaseTreasure[] Loots
        {
            get
            {
                return this.loots;
            }
        }

        public int Model
        {
            get
            {
                return this.model;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public int ObjectType
        {
            get
            {
                return this.type;
            }
        }

        public float Size
        {
            get
            {
                return this.size;
            }
        }

        public uint[] Sound
        {
            get
            {
                return this.sound;
            }
        }

        public int Type
        {
            get
            {
                return this.type;
            }
        }


        // Fields
        public static Hashtable all;
        private int flags;
        private BaseTreasure[] loots;
        private ushort model;
        private string name;
        private float size;
        private uint[] sound;
        private byte type;
    }
}

