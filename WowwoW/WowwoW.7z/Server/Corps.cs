namespace Server
{
    using HelperTools;
    using System;

    public class Corps : Mobile
    {
        // Methods
        public Corps()
        {
        }

        public Corps(ulong guid)
        {
            this.owner = guid;
        }

        public override void Deserialize(GenericReader gr)
        {
            base.Deserialize(gr);
            gr.ReadInt();
            this.owner = gr.ReadInt64();
            this.bytes2 = (uint) gr.ReadInt();
            this.bytes3 = (uint) gr.ReadInt();
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther)
        {
            this.tempBuff[offset++] = 2;
            Converter.ToBytes(base.Guid, this.tempBuff, ref offset);
            base.ResetBitmap();
            Converter.ToBytes((byte) 7, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(this.X, this.tempBuff, ref offset);
            Converter.ToBytes(this.Y, this.tempBuff, ref offset);
            Converter.ToBytes(this.Z, this.tempBuff, ref offset);
            Converter.ToBytes(base.Orientation, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes((float) 2.5f, this.tempBuff, ref offset);
            Converter.ToBytes((float) 7f, this.tempBuff, ref offset);
            Converter.ToBytes((float) 2.5f, this.tempBuff, ref offset);
            Converter.ToBytes((float) 4.5f, this.tempBuff, ref offset);
            Converter.ToBytes((float) 4.7222f, this.tempBuff, ref offset);
            Converter.ToBytes((float) 3.141593f, this.tempBuff, ref offset);
            Converter.ToBytes((uint) 0, this.tempBuff, ref offset);
            Converter.ToBytes((uint) 1, this.tempBuff, ref offset);
            Converter.ToBytes((uint) 0, this.tempBuff, ref offset);
            Converter.ToBytes((uint) 0, this.tempBuff, ref offset);
            Converter.ToBytes((uint) 0, this.tempBuff, ref offset);
            base.setUpdateValue(Const.OBJECT_FIELD_GUID, base.Guid);
            base.setUpdateValue(Const.OBJECT_FIELD_TYPE, 0x81);
            base.setUpdateValue(Const.OBJECT_FIELD_SCALE_X, (float) 1f);
            base.setUpdateValue(6, this.owner);
            base.setUpdateValue(8, base.Orientation);
            base.setUpdateValue(9, this.X);
            base.setUpdateValue(10, this.Y);
            base.setUpdateValue(11, this.Z);
            base.setUpdateValue(12, base.Model);
            base.setUpdateValue(0x20, this.bytes2);
            base.setUpdateValue(0x21, this.bytes3);
            base.setUpdateValue(0x23, (int) base.Faction);
            base.FlushUpdateData(this.tempBuff, ref offset, 2);
        }

        public override bool SeenBy(Character c)
        {
            return true;
        }

        public override void Serialize(GenericWriter gw)
        {
            base.Serialize(gw);
            gw.Write(0);
            gw.Write(this.owner);
            gw.Write(this.bytes2);
            gw.Write(this.bytes3);
        }


        // Properties
        public uint Bytes2
        {
            get
            {
                return this.bytes2;
            }
            set
            {
                this.bytes2 = value;
            }
        }

        public uint Bytes3
        {
            get
            {
                return this.bytes3;
            }
            set
            {
                this.bytes3 = value;
            }
        }

        public DateTime Decay
        {
            get
            {
                return this.decay;
            }
            set
            {
                this.decay = value;
            }
        }


        // Fields
        private uint bytes2;
        private uint bytes3;
        private DateTime decay;
        private ulong owner;
    }
}

