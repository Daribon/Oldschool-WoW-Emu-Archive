namespace Server
{
    using HelperTools;
    using System;

    public class NonAgressiveAnimalAI : BaseAIType
    {
        // Methods
        public NonAgressiveAnimalAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.Explore;
        }

        public override AIStates OnGetHit(Mobile from, AIStates AIState, int dmg)
        {
            base.From.AttackTarget = from;
            return AIStates.Flee;
        }

        public override void OnTick()
        {
            switch (base.AIState)
            {
                case AIStates.DoingNothing:
                {
                    base.AIState = AIStates.Explore;
                    return;
                }
                case AIStates.Explore:
                {
                    if (Utility.Random4() != 0)
                    {
                        if (Utility.Random4() < 3)
                        {
                            base.AIState = AIStates.Pause4;
                        }
                        return;
                    }
                    base.AIState = AIStates.Pause1;
                    return;
                }
                case AIStates.Pause1:
                {
                    base.AIState = AIStates.Pause2;
                    return;
                }
                case AIStates.Pause2:
                {
                    base.AIState = AIStates.Pause3;
                    return;
                }
                case AIStates.Pause3:
                {
                    base.AIState = AIStates.Pause4;
                    return;
                }
                case AIStates.Pause4:
                {
                    base.AIState = AIStates.Pause5;
                    return;
                }
                case AIStates.Pause5:
                {
                    base.AIState = AIStates.Pause6;
                    return;
                }
                case AIStates.Pause6:
                {
                    base.AIState = AIStates.Pause7;
                    return;
                }
                case AIStates.Pause7:
                {
                    base.AIState = AIStates.Pause8;
                    return;
                }
                case AIStates.Pause8:
                {
                    base.AIState = AIStates.Pause9;
                    return;
                }
                case AIStates.Pause9:
                {
                    base.AIState = AIStates.Explore;
                    return;
                }
            }
        }

    }
}

