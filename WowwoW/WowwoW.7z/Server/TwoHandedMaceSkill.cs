namespace Server
{
    using System;

    public class TwoHandedMaceSkill : Skill
    {
        // Methods
        public TwoHandedMaceSkill()
        {
        }

        public TwoHandedMaceSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 160;
            }
        }

        public static int SkillId
        {
            get
            {
                return 160;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xc7;
            }
        }

    }
}

