namespace Server
{
    using System;

    public class SpecificSpellTargets
    {
        // Methods
        static SpecificSpellTargets()
        {
            SpecificSpellTargets.specificSpellTargets = new int[0x7530];
            SpecificSpellTargets.temp = new SpecificSpellTargets();
        }

        public SpecificSpellTargets()
        {
            SpecificSpellTargets.specificSpellTargets[0x5b6] = 1;
            SpecificSpellTargets.specificSpellTargets[0x504d] = 1;
            SpecificSpellTargets.specificSpellTargets[0xa51] = 1;
            SpecificSpellTargets.specificSpellTargets[0x140e] = 1;
            SpecificSpellTargets.specificSpellTargets[0x5f8] = 1;
            SpecificSpellTargets.specificSpellTargets[0x1b39] = 1;
            SpecificSpellTargets.specificSpellTargets[0x519d] = 1;
            SpecificSpellTargets.specificSpellTargets[0x5e9] = 1;
            SpecificSpellTargets.specificSpellTargets[0x37f6] = 1;
            SpecificSpellTargets.specificSpellTargets[0x37f7] = 1;
            SpecificSpellTargets.specificSpellTargets[0xb5c] = 1;
            SpecificSpellTargets.specificSpellTargets[0x22fb] = 1;
            SpecificSpellTargets.specificSpellTargets[0x26ad] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4ce8] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4cf1] = 1;
            SpecificSpellTargets.specificSpellTargets[0x5eb] = 1;
            SpecificSpellTargets.specificSpellTargets[0x34a9] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4cee] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4c5c] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4cda] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4cf3] = 1;
            SpecificSpellTargets.specificSpellTargets[0xa5a] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4ce9] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4ce7] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4cf4] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4cf0] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4cec] = 1;
            SpecificSpellTargets.specificSpellTargets[0x4ced] = 1;
            SpecificSpellTargets.specificSpellTargets[0x5b3c] = 1;
            SpecificSpellTargets.specificSpellTargets[0x24ef] = 1;
            SpecificSpellTargets.specificSpellTargets[0x2690] = 2;
            SpecificSpellTargets.specificSpellTargets[0x3eb5] = 2;
            SpecificSpellTargets.specificSpellTargets[0x5d9f] = 2;
            SpecificSpellTargets.specificSpellTargets[0x50f6] = 2;
            SpecificSpellTargets.specificSpellTargets[0x25f0] = 2;
            SpecificSpellTargets.specificSpellTargets[0xa4d] = 3;
            SpecificSpellTargets.specificSpellTargets[0x48e1] = 3;
            SpecificSpellTargets.specificSpellTargets[0x48e2] = 3;
            SpecificSpellTargets.specificSpellTargets[0x44a] = 4;
            SpecificSpellTargets.specificSpellTargets[0x2dcd] = 4;
            SpecificSpellTargets.specificSpellTargets[0x2dce] = 4;
            SpecificSpellTargets.specificSpellTargets[0x5192] = 4;
            SpecificSpellTargets.specificSpellTargets[0x3653] = 4;
            SpecificSpellTargets.specificSpellTargets[0x4a54] = 4;
            SpecificSpellTargets.specificSpellTargets[710] = 12;
            SpecificSpellTargets.specificSpellTargets[0x48d7] = 12;
            SpecificSpellTargets.specificSpellTargets[0x55ac] = 0x10;
            SpecificSpellTargets.specificSpellTargets[0x4f] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x15ee] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x15ef] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x2848] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x2849] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x284a] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x42fb] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x42fd] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0xafc] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x284e] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x250c] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x250d] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x2acb] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x2cb4] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x438b] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0xb3e] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x15fb] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x2856] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x4d0d] = 0x20;
            SpecificSpellTargets.specificSpellTargets[0x2608] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0xd72] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x337c] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x25d] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x2a9f] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x2aa0] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x1c5] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x2000] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x2ac9] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x4e62] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x816] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x1a72] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x2c21] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x18d6] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x65] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x1a74] = 0x40;
            SpecificSpellTargets.specificSpellTargets[0x5061] = 0x60;
            SpecificSpellTargets.specificSpellTargets[0x76] = 0xc1;
            SpecificSpellTargets.specificSpellTargets[0x3218] = 0xc1;
            SpecificSpellTargets.specificSpellTargets[0x3219] = 0xc1;
            SpecificSpellTargets.specificSpellTargets[0x321a] = 0xc1;
            SpecificSpellTargets.specificSpellTargets[0x5702] = 0xd3;
            SpecificSpellTargets.specificSpellTargets[0x340b] = 0xd3;
            SpecificSpellTargets.specificSpellTargets[0x3cae] = 0xd3;
            SpecificSpellTargets.specificSpellTargets[0x2099] = 0x100;
            SpecificSpellTargets.specificSpellTargets[0x5434] = 0x100;
            SpecificSpellTargets.specificSpellTargets[0x543e] = 0x100;
            SpecificSpellTargets.specificSpellTargets[0x3ad1] = 0x100;
            SpecificSpellTargets.specificSpellTargets[0x209a] = 0x100;
            SpecificSpellTargets.specificSpellTargets[0x209b] = 0x100;
            SpecificSpellTargets.specificSpellTargets[0x2098] = 0x100;
            SpecificSpellTargets.specificSpellTargets[0x5b02] = 0x3ff;
        }


        // Fields
        public static int[] specificSpellTargets;
        private static SpecificSpellTargets temp;
    }
}

