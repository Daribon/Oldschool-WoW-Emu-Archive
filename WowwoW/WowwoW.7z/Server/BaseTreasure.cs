namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;

    public class BaseTreasure
    {
        // Methods
        public BaseTreasure(Loot[] l, float prob)
        {
            this.loots = l;
            this.probability = prob;
        }

        public bool IsDrop()
        {
            if ((Utility.RandomDouble() * 100) < (this.probability * World.DropMultiplier))
            {
                return true;
            }
            return false;
        }

        public ArrayList RandomDrop(ref int lootMoney)
        {
            ArrayList list1 = new ArrayList();
            if (this.loots == null)
            {
                return null;
            }
            Loot[] lootArray1 = this.loots;
            for (int num2 = 0; num2 < lootArray1.Length; num2++)
            {
                Loot loot1 = lootArray1[num2];
                if ((Utility.RandomDouble() * 100) < (loot1.Probability * World.DropMultiplier))
                {
                    int num1 = Utility.Random(loot1.MinAmount, loot1.MaxAmount);
                    Item item1 = loot1.Create(num1);
                    if (item1 is Money)
                    {
                        lootMoney += (num1 * World.DropGoldMultiplier);
                    }
                    list1.Add(item1);
                }
            }
            return list1;
        }


        // Fields
        private Loot[] loots;
        private float probability;
    }
}

