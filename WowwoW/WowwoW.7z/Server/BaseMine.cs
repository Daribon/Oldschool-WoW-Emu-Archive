namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;

    public class BaseMine : GameObject
    {
        // Methods
        public BaseMine()
        {
            this.locked = false;
            base.DefaultModel = 0x20;
            base.Charge = 1 + Utility.Random4();
        }

        public override bool OnRelease(Mobile from)
        {
            base.Charge--;
            if (base.Charge > 0)
            {
                return false;
            }
            if (base.SpawnerLink != null)
            {
                base.SpawnerLink.LastSpawn = DateTime.Now;
            }
            return base.OnRelease(from);
        }

        public override bool OnUse(Mobile from)
        {
            if (!(from is Character))
            {
                return false;
            }
            this.lootMoney = 0;
            (from as Character).LootOwner = base.Guid;
            ArrayList list1 = new ArrayList();
            BaseTreasure[] treasureArray1 = base.Loots;
            for (int num1 = 0; num1 < treasureArray1.Length; num1++)
            {
                BaseTreasure treasure1 = treasureArray1[num1];
                if (treasure1.IsDrop())
                {
                    list1.AddRange(treasure1.RandomDrop(ref this.lootMoney));
                }
            }
            base.Treasure = (Item[]) list1.ToArray(typeof(Item));
            (from as Character).SendLootDetails(base.Guid, this, this.lootMoney);
            return true;
        }


        // Properties
        public bool Locked
        {
            get
            {
                return this.locked;
            }
            set
            {
                this.locked = value;
            }
        }

        public int LootMoney
        {
            get
            {
                return 0;
            }
            set
            {
                this.lootMoney = value;
            }
        }


        // Fields
        private bool locked;
        private int lootMoney;
    }
}

