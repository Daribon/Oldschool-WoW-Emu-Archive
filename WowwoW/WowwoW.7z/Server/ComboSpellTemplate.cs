namespace Server
{
    using HelperTools;
    using System;

    public class ComboSpellTemplate : SpellTemplate
    {
        // Methods
        public ComboSpellTemplate(ushort _id, int _customFlags1, int _levelMin, int _levelMax, int _bonus1, int _bonus2, int _s1, int _s2, int _s3, Resistances _res, DispelType _dis, int _manacost, int _castingtime, byte _range, float _comboModifier, int _duration, int _cooldown, int _h, int _classe) : base(_id, _customFlags1, _levelMin, _levelMax, _bonus1, _bonus2, _s1, _s2, _s3, _res, _dis, _manacost, _castingtime, _range, _duration, _cooldown, _h, 0, 0, 0, _classe)
        {
            this.comboModifier = _comboModifier;
        }

        public void ComboHit(Mobile from, Mobile target, SpellDamage typedamage)
        {
            float single1 = 1f;
            switch (typedamage)
            {
                case SpellDamage.TypeS1:
                {
                    single1 = base.Bonus1;
                    break;
                }
                case SpellDamage.TypeS2:
                {
                    single1 = base.Bonus2;
                    break;
                }
            }
            float single2 = from.Hit(target, (float) (single1 + (from.ComboPoints * this.comboModifier)));
            if (single2 > 0f)
            {
                from.ResetCombo(target);
                target.LooseHits(from, (int) single2, true);
                int num1 = 4;
                Converter.ToBytes(target.Guid, from.tempBuff, ref num1);
                Converter.ToBytes(from.Guid, from.tempBuff, ref num1);
                Converter.ToBytes(this.Id, from.tempBuff, ref num1);
                Converter.ToBytes((int) single2, from.tempBuff, ref num1);
                Converter.ToBytes(2, from.tempBuff, ref num1);
                Converter.ToBytes(target.Guid, from.tempBuff, ref num1);
                Converter.ToBytes(0, from.tempBuff, ref num1);
                from.ToAllPlayerNear(OpCodes.SMSG_SPELLNONMELEEDAMAGELOG, from.tempBuff, num1);
            }
        }


        // Properties
        public float ComboModifier
        {
            get
            {
                return this.comboModifier;
            }
            set
            {
                this.comboModifier = value;
            }
        }


        // Fields
        private float comboModifier;
    }
}

