namespace Server
{
    using System;

    public class Member
    {
        // Methods
        public Member(Character c)
        {
            this.droits = 1;
            this.character = c;
        }


        // Properties
        public Character Char
        {
            get
            {
                return this.character;
            }
        }

        public ushort Droits
        {
            get
            {
                return this.droits;
            }
            set
            {
                this.droits = value;
            }
        }


        // Fields
        private Character character;
        private ushort droits;
    }
}

