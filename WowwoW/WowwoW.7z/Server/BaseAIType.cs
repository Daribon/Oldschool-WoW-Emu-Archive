namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;

    public class BaseAIType
    {
        // Methods
        static BaseAIType()
        {
            BaseAIType.aiTypes = new BaseAIType[0x20];
        }

        public BaseAIType(AITypes _aiType, BaseCreature bc)
        {
            this.customBehaviours = new ArrayList();
            this.aiType = _aiType;
            this.from = bc;
        }

        public void OnBeginFight(Mobile m)
        {
            int num1 = 4;
            Converter.ToBytes(this.From.Guid, this.From.tempBuff, ref num1);
            Converter.ToBytes(2, this.From.tempBuff, ref num1);
            this.From.ToAllPlayerNear(OpCodes.SMSG_AI_REACTION, this.From.tempBuff, num1);
        }

        public virtual AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            return AIStates.Flee;
        }

        public virtual void OnTick()
        {
        }


        // Properties
        public AIStates AIState
        {
            get
            {
                return this.From.AIState;
            }
            set
            {
                this.From.AIState = value;
            }
        }

        public AITypes AIType
        {
            get
            {
                return this.aiType;
            }
        }

        public ArrayList CustomBehaviours
        {
            get
            {
                return this.customBehaviours;
            }
        }

        public BaseCreature From
        {
            get
            {
                return this.from;
            }
        }

        protected int MaxViewDistance
        {
            get
            {
                if (this.From.Level > 60)
                {
                    return 0x3b1;
                }
                return World.ViewingDistance[this.From.Level];
            }
        }

        public static BaseAIType NonAgressiveAnimalsAI
        {
            get
            {
                return BaseAIType.aiTypes[0];
            }
        }


        // Fields
        private AITypes aiType;
        public static BaseAIType[] aiTypes;
        private ArrayList customBehaviours;
        private BaseCreature from;
    }
}

