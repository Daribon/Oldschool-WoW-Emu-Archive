namespace Server
{
    using System;

    public class Restoration : Skill
    {
        // Methods
        public Restoration()
        {
        }

        public Restoration(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x23d;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x23d;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

