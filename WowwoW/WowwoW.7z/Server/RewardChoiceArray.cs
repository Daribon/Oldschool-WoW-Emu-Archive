namespace Server
{
    using System;

    public class RewardChoiceArray : BaseRewardArray
    {
        // Methods
        public RewardChoiceArray() : base(6)
        {
        }

    }
}

