namespace Server
{
    using Server.Items;
    using System;
    using System.Runtime.CompilerServices;

    public delegate void OnSingleTargetItemSpellEffect(BaseAbility ba, Mobile c, Mobile target, Item.SpecialAbility sa, Item it);

}

