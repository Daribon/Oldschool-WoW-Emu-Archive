namespace Server
{
    using Server.Items;
    using System;

    public class Reward
    {
        // Methods
        public Reward(int id, int amount)
        {
            this._id = id;
            this._amount = amount;
        }

        public Item Create()
        {
            return World.CreateItemInPoolById(this._id);
        }

        public Item CreateItem()
        {
            return World.CreateItemInPoolById(this._id);
        }


        // Properties
        public int Amount
        {
            get
            {
                return this._amount;
            }
        }

        public bool ExistsInWorld
        {
            get
            {
                return (this.Create() != null);
            }
        }

        public int Id
        {
            get
            {
                return this._id;
            }
        }

        public int Model
        {
            get
            {
                if (this._model == 0)
                {
                    Item item1 = this.Create();
                    this._model = (item1 != null) ? item1.Model : 0;
                }
                return this._model;
            }
        }


        // Fields
        private int _amount;
        private int _id;
        private int _model;
    }
}

