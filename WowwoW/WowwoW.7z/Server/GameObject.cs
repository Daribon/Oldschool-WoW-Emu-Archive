namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;

    public class GameObject : Server.Object
    {
        // Methods
        public GameObject() : base(Server.Object.GUID)
        {
            Server.Object.GUID++;
            base.Guid += 0xa000000000000000;
            this.charge = Utility.Random4() + 1;
        }

        public GameObject(GenericReader gr)
        {
            this.Deserialize(gr);
            this.charge = Utility.Random4() + 1;
        }

        public GameObject(int gameObjectId, float X, float Y, float Z, ushort MapId) : base(Server.Object.GUID, X, Y, Z, 0f, MapId)
        {
            Server.Object.GUID++;
            this.id = gameObjectId;
            base.Guid += 0xa000000000000000;
            this.charge = Utility.Random4() + 1;
        }

        public bool CheckLoot(Character c, float reussite)
        {
            GameObjectDescription description1 = (GameObjectDescription) GameObjectDescription.all[this.id];
            if (description1 == null)
            {
                return false;
            }
            ArrayList list1 = new ArrayList();
            c.LootOwner = base.Guid;
            if (description1.Loots == null)
            {
                return false;
            }
            int num1 = 0;
            BaseTreasure[] treasureArray1 = description1.Loots;
            for (int num2 = 0; num2 < treasureArray1.Length; num2++)
            {
                BaseTreasure treasure1 = treasureArray1[num2];
                if (treasure1.IsDrop())
                {
                    ArrayList list2 = treasure1.RandomDrop(ref num1);
                    if (list2 != null)
                    {
                        list1.AddRange(list2);
                    }
                }
            }
            base.Treasure = (Item[]) list1.ToArray(typeof(Item));
            c.SendLootDetails(base.Guid, this, num1);
            return true;
        }

        public override void Deserialize(GenericReader gr)
        {
            base.Deserialize(gr);
            int num1 = gr.ReadInt();
            this.id = gr.ReadInt();
            if (num1 > 0)
            {
                this.charge = gr.ReadInt();
                int num2 = gr.ReadInt();
                if (num2 == 1)
                {
                    gr.ReadInt64();
                    base.SpawnerLink = null;
                }
            }
        }

        public void ForceLoot(Character c)
        {
            int num1 = 4;
            Converter.ToBytes(c.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            c.Send(OpCodes.CMSG_LOOT, this.tempBuff, num1);
        }

        public virtual bool OnRelease(Mobile from)
        {
            int num1 = 4;
            Converter.ToBytes(base.Guid, from.tempBuff, ref num1);
            from.ToAllPlayerNear(OpCodes.SMSG_GAMEOBJECT_DESPAWN_ANIM, this.tempBuff, num1);
            from.ToAllPlayerNear(OpCodes.SMSG_DESTROY_OBJECT, this.tempBuff, num1);
            return true;
        }

        public virtual bool OnUse(Mobile from)
        {
            return true;
        }

        public static void OnUseHandler(BaseAbility ba, Mobile c, GameObject go)
        {
            go.OnUse(c);
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther)
        {
            this.PrepareUpdateData(data, ref offset, type, forOther, null);
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther, Character f)
        {
            if (GameObjectDescription.all[this.id] == null)
            {
                Console.WriteLine("Gameobject id = {0} undifined !", this.id);
            }
            else
            {
                data[offset++] = 2;
                Converter.ToBytes(base.Guid, data, ref offset);
                Converter.ToBytes((byte) 5, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(this.X, data, ref offset);
                Converter.ToBytes(this.Y, data, ref offset);
                Converter.ToBytes(this.Z, data, ref offset);
                Converter.ToBytes(base.Orientation, data, ref offset);
                Converter.ToBytes((float) 0f, data, ref offset);
                Converter.ToBytes((float) 2.5f, data, ref offset);
                Converter.ToBytes((float) 7f, data, ref offset);
                Converter.ToBytes((float) 2.5f, data, ref offset);
                Converter.ToBytes((float) 4.7222f, data, ref offset);
                Converter.ToBytes((float) 4.5f, data, ref offset);
                Converter.ToBytes((float) 3.141593f, data, ref offset);
                Converter.ToBytes((uint) 0, data, ref offset);
                Converter.ToBytes((uint) 1, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
                Converter.ToBytes(0, data, ref offset);
                base.ResetBitmap();
                base.setUpdateValue(0, base.Guid);
                base.setUpdateValue(2, 0x21);
                base.setUpdateValue(3, (uint) this.id);
                base.setUpdateValue(4, this.Size);
                base.setUpdateValue(8, this.Model);
                base.setUpdateValue(9, this.Flags);
                base.setUpdateValue(14, 1);
                base.setUpdateValue(0x10, this.X);
                base.setUpdateValue(0x11, this.Y);
                base.setUpdateValue(0x12, this.Z);
                base.setUpdateValue(0x13, base.Orientation);
                base.setUpdateValue(0x16, (GameObjectDescription.all[this.id] as GameObjectDescription).Type);
                base.FlushUpdateData(data, ref offset, 1);
            }
        }

        public override bool SeenBy(Character c)
        {
            if ((base.MapId == c.MapId) && (base.Distance(c) <= 90000f))
            {
                return true;
            }
            return false;
        }

        public override void Serialize(GenericWriter gw)
        {
            base.Serialize(gw);
            gw.Write(1);
            gw.Write(this.id);
            gw.Write(this.charge);
            if (base.SpawnerLink != null)
            {
                gw.Write(1);
                gw.Write(base.SpawnerLink.Guid);
            }
            else
            {
                gw.Write(0);
            }
        }


        // Properties
        public int Charge
        {
            get
            {
                return this.charge;
            }
            set
            {
                this.charge = value;
            }
        }

        public int DefaultModel
        {
            get
            {
                return this.defaultModel;
            }
            set
            {
                this.defaultModel = value;
            }
        }

        public int Flags
        {
            get
            {
                return (GameObjectDescription.all[this.id] as GameObjectDescription).Flags;
            }
        }

        public int Id
        {
            get
            {
                return this.id;
            }
            set
            {
                this.id = value;
            }
        }

        public BaseTreasure[] Loots
        {
            get
            {
                return this.loots;
            }
            set
            {
                this.loots = value;
            }
        }

        public int Model
        {
            get
            {
                return (GameObjectDescription.all[this.id] as GameObjectDescription).Model;
            }
        }

        public string Name
        {
            get
            {
                return (GameObjectDescription.all[this.id] as GameObjectDescription).Name;
            }
        }

        public int ObjectType
        {
            get
            {
                return (GameObjectDescription.all[this.id] as GameObjectDescription).ObjectType;
            }
        }

        public float Size
        {
            get
            {
                float single1;
                try
                {
                    single1 = (GameObjectDescription.all[this.id] as GameObjectDescription).Size;
                }
                catch (Exception)
                {
                    single1 = 0f;
                }
                return single1;
            }
        }

        public uint[] Sound
        {
            get
            {
                return (GameObjectDescription.all[this.id] as GameObjectDescription).Sound;
            }
        }


        // Fields
        private int charge;
        private int defaultModel;
        private int id;
        private BaseTreasure[] loots;
    }
}

