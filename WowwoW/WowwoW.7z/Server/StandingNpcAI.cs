namespace Server
{
    using System;

    public class StandingNpcAI : BaseAIType
    {
        // Methods
        public StandingNpcAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.Explore;
            base.CustomBehaviours.Add(CustomBehavioursTypes.Stay);
            base.CustomBehaviours.Add(CustomBehavioursTypes.KeepOrientation);
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if ((AIState != AIStates.Attack) && (AIState != AIStates.Fighting))
            {
                base.OnBeginFight(by);
                base.From.AttackTarget = by;
                return AIStates.BeingAttacked;
            }
            return AIState;
        }

        public override void OnTick()
        {
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 1800f))
            {
                base.From.AIState = AIStates.Explore;
                base.From.AttackTarget = null;
            }
            else
            {
                switch (base.AIState)
                {
                    case AIStates.DoingNothing:
                    {
                        base.AIState = AIStates.Explore;
                        return;
                    }
                    case AIStates.Explore:
                    {
                        base.AIState = AIStates.Pause1;
                        return;
                    }
                    case AIStates.Pause1:
                    {
                        return;
                    }
                }
            }
        }

    }
}

