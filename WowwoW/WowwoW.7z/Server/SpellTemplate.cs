namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;

    public class SpellTemplate : BaseAbility
    {
        // Methods
        static SpellTemplate()
        {
            SpellTemplate.SpellEffects = new Hashtable();
            SpellTemplate.arcaneSkill = new ArcaneSkill();
            SpellTemplate.fireSkill = new FireSkill();
            SpellTemplate.destructionSkill = new Destruction();
        }

        public SpellTemplate(ushort _id, int _customFlags1, int _levelMin, int _levelMax, int _bonus1, int _bonus2, int _s1, int _s2, int _s3, Resistances _res, DispelType _dis, int _manacost, int _castingtime, byte _range, int _duration, int _cooldown, int _h, int _radius1, int _radius2, int _radius3, int _classe) : base(_id, _customFlags1, _cooldown)
        {
            this.h = _h;
            this.levelMin = _levelMin;
            this.levelMax = _levelMax;
            this.resistance = _res;
            this.classe = _classe;
            this.manaCost = _manacost;
            this.castingTime = _castingtime;
            this.range = _range;
            this.duration = _duration;
            this.s1 = _s1;
            this.s2 = _s2;
            this.s3 = _s3;
            this.bonus1 = _bonus1;
            this.bonus2 = _bonus2;
            this.radius1 = _radius1;
            this.radius2 = _radius2;
            this.radius3 = _radius3;
            this.dispeltype = _dis;
        }

        public SpellTemplate(ushort _id, int _customFlags1, int _add, int _levelMin, int _levelMax, int _bonus1, int _bonus2, int _s1, int _s2, int _s3, Resistances _res, DispelType _dis, int _manacost, int _castingtime, byte _range, int _duration, int _cooldown, int _h, int _radius1, int _radius2, int _radius3, int _classe) : base(_id, _customFlags1, _cooldown)
        {
            this.h = _h;
            this.additionalSpell = _add;
            this.levelMin = _levelMin;
            this.levelMax = _levelMax;
            this.resistance = _res;
            this.classe = _classe;
            this.manaCost = _manacost;
            this.castingTime = _castingtime;
            this.range = _range;
            this.duration = _duration;
            this.s1 = _s1;
            this.s2 = _s2;
            this.s3 = _s3;
            this.bonus1 = _bonus1;
            this.bonus2 = _bonus2;
            this.dispeltype = _dis;
        }

        public SpellTemplate(ushort _id, int _customFlags1, int _levelMin, int _levelMax, int _bonus1, int _bonus2, int _s1, int _s2, int _s3, int _t1, int _t2, Resistances _res, DispelType _dis, int _manacost, int _castingtime, byte _range, int _duration, int _cooldown, int _h, int _radius1, int _radius2, int _radius3, int _classe) : base(_id, _customFlags1, _cooldown)
        {
            this.h = _h;
            this.levelMin = _levelMin;
            this.levelMax = _levelMax;
            this.resistance = _res;
            this.dispeltype = _dis;
            this.classe = _classe;
            this.manaCost = _manacost;
            this.castingTime = _castingtime;
            this.range = _range;
            this.duration = _duration;
            this.s1 = _s1;
            this.s2 = _s2;
            this.s3 = _s3;
            this.bonus1 = _bonus1;
            this.bonus2 = _bonus2;
            this.t1 = _t1;
            this.t2 = _t2;
            this.radius1 = _radius1;
            this.radius2 = _radius2;
            this.radius3 = _radius3;
        }

        public SpellTemplate(ushort _id, int _customFlags1, int _add, int _levelMin, int _levelMax, int _bonus1, int _bonus2, int _s1, int _s2, int _s3, int _t1, int _t2, Resistances _res, DispelType _dis, int _manacost, int _castingtime, byte _range, int _duration, int _cooldown, int _h, int _radius1, int _radius2, int _radius3, int _classe) : base(_id, _customFlags1, _cooldown)
        {
            this.h = _h;
            this.additionalSpell = _add;
            this.levelMin = _levelMin;
            this.levelMax = _levelMax;
            this.resistance = _res;
            this.classe = _classe;
            this.manaCost = _manacost;
            this.castingTime = _castingtime;
            this.range = _range;
            this.duration = _duration;
            this.s1 = _s1;
            this.s2 = _s2;
            this.s3 = _s3;
            this.bonus1 = _bonus1;
            this.bonus2 = _bonus2;
            this.t1 = _t1;
            this.t2 = _t2;
            this.radius1 = _radius1;
            this.radius2 = _radius2;
            this.radius3 = _radius3;
            this.dispeltype = _dis;
        }

        public void ApplyDot(Mobile c, Mobile target, int dmg, int freq, int duration)
        {
            if (!target.Dead)
            {
                AuraEffect effect1 = null;
                if (this is AuraEffect)
                {
                    effect1 = (AuraEffect) this;
                }
                else
                {
                    effect1 = new AuraEffect(this.Id, 0, this.levelMin, this.levelMax, this.bonus1, this.bonus2, this.s1, this.s2, this.s3, this.t1, this.t2, this.resistance, this.dispeltype, this.GetManaCost(c), this.CastingTime(c), this.range, duration, this.CoolDown(c), 0, 0, this.classe);
                    effect1.Applications = 0x1010101;
                }
                Aura aura1 = new DotAura(this, c, target, dmg, duration, freq);
                target.AddAura(c, effect1, aura1, true);
            }
        }

        public void ApplyDot(Mobile c, ArrayList targets, int dmg, int freq, int duration)
        {
            foreach (Mobile mobile1 in targets)
            {
                this.ApplyDot(c, mobile1, dmg, freq, duration);
            }
        }

        private float ArcaneSpellModifier(Mobile from)
        {
            return 1f;
        }

        public override int CastingTime(Mobile from)
        {
            int num1 = this.castingTime;
            AuraEffect effect1 = null;
            switch (from.Classe)
            {
                case Classes.Warrior:
                {
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x5b8]) && from.HaveTalent(Talents.ImprovedSlam))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedSlam);
                        num1 += effect1.S1;
                    }
                    break;
                }
                case Classes.Hunter:
                {
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x3d6]) && from.HaveTalent(Talents.ImprovedRevivePet))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedRevivePet);
                        num1 += effect1.S1;
                    }
                    break;
                }
                case Classes.Priest:
                {
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x1fc1]) && from.HaveTalent(Talents.ImprovedManaBurn))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedManaBurn);
                        num1 += effect1.S1;
                    }
                    if (((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x249]) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x3a42])) && from.HaveTalent(Talents.DivineFury))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.DivineFury);
                        num1 += effect1.S1;
                    }
                    if (((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x17af]) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x80c])) && from.HaveTalent(Talents.MasterHealer))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.MasterHealer);
                        num1 += effect1.S1;
                    }
                    break;
                }
                case Classes.Shaman:
                {
                    if (((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x193]) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x1a5])) && from.HaveTalent(Talents.LightningMastery))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.LightningMastery);
                        num1 += effect1.S1;
                    }
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x14b]) && from.HaveTalent(Talents.ImprovedHealingWave))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedHealingWave);
                        num1 += effect1.S1;
                    }
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0xa55]) && from.HaveTalent(Talents.ImprovedGhostWolf))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedGhostWolf);
                        num1 += effect1.S1;
                    }
                    break;
                }
                case Classes.Mage:
                {
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x85]) && from.HaveTalent(Talents.ImprovedFireball))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedFireball);
                        num1 += effect1.S1;
                    }
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x74]) && from.HaveTalent(Talents.ImprovedFrostbolt))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedFrostbolt);
                        num1 += effect1.S1;
                    }
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x5a9]) && from.HaveTalent(Talents.ImprovedArcaneExplosion))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedArcaneExplosion);
                        num1 += effect1.S1;
                    }
                    if (!from.HaveTalent(Talents.PresenceOfMind))
                    {
                        break;
                    }
                    bool flag2 = false;
                    ArrayList list2 = new ArrayList();
                    AuraEffect effect3 = (AuraEffect) from.GetTalentEffect(Talents.PresenceOfMind);
                    foreach (Mobile.AuraReleaseTimer timer3 in from.Auras)
                    {
                        if (timer3.aura.SpecialState == SpecialStates.PresenceOfMind)
                        {
                            flag2 = true;
                            list2.Add(timer3);
                        }
                    }
                    if (!flag2)
                    {
                        break;
                    }
                    foreach (Mobile.AuraReleaseTimer timer4 in list2)
                    {
                        from.ReleaseAura(timer4);
                    }
                    return 0;
                }
                case Classes.Warlock:
                {
                    if (((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2ae]) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x15c])) && from.HaveTalent(Talents.Bane))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.Bane);
                        num1 += effect1.S1;
                    }
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0xac]) && from.HaveTalent(Talents.ImprovedCorruption))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedCorruption);
                        num1 += effect1.S1;
                    }
                    if ((((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2b0]) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2c8])) || ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2b3]) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x255]))) && from.HaveTalent(Talents.MasterSummoner))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.MasterSummoner);
                        num1 += effect1.S1;
                    }
                    if (from.ShadowTrance && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2ae]))
                    {
                        from.ReleaseAura((AuraEffect) Abilities.abilities[0x4615]);
                        return 10;
                    }
                    if (from.HaveTalent(Talents.FelDomination))
                    {
                        bool flag1 = false;
                        ArrayList list1 = new ArrayList();
                        AuraEffect effect2 = (AuraEffect) from.GetTalentEffect(Talents.FelDomination);
                        foreach (Mobile.AuraReleaseTimer timer1 in from.Auras)
                        {
                            if (timer1.aura.SpecialState == SpecialStates.FelDomination)
                            {
                                flag1 = true;
                                list1.Add(timer1);
                            }
                        }
                        if (flag1)
                        {
                            num1 += effect2.S1;
                            foreach (Mobile.AuraReleaseTimer timer2 in list1)
                            {
                                from.ReleaseAura(timer2);
                            }
                        }
                    }
                    break;
                }
                case Classes.Druid:
                {
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x41ae]) && from.HaveTalent(Talents.ImprovedWrath))
                    {
                        effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedWrath);
                        num1 += effect1.S1;
                    }
                    break;
                }
            }
            if (((from.SummonedBy != null) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0xc26])) && from.SummonedBy.HaveTalent(Talents.ImprovedFirebolt))
            {
                effect1 = (AuraEffect) from.SummonedBy.GetTalentEffect(Talents.ImprovedFirebolt);
                num1 += effect1.S1;
            }
            foreach (Mobile.AuraReleaseTimer timer5 in from.Auras)
            {
                if ((timer5.aura.CastingTimeEffectedAbilityList != 0) && (from.SpecialForAuras[timer5.aura.CastingTimeEffectedAbilityList] != null))
                {
                    if ((from.SpecialForAuras[timer5.aura.CastingTimeEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[timer5.aura.CastingTimeEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num1 = (int) ((num1 + timer5.aura.CastingTimeBonusForAbility) * timer5.aura.CastingTimeModificatorForAbility);
                    }
                    if (from.SpecialForAuras[timer5.aura.CastingTimeEffectedAbilityList] is int)
                    {
                        int num2 = (int) from.SpecialForAuras[timer5.aura.CastingTimeEffectedAbilityList];
                        if (num2 == this.Id)
                        {
                            num1 = (int) ((num1 + timer5.aura.CastingTimeBonusForAbility) * timer5.aura.CastingTimeModificatorForAbility);
                        }
                    }
                }
                if ((timer5.aura.CastingTimeEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == timer5.aura.CastingTimeEffectedAbilityClass))
                {
                    num1 = (int) ((num1 + timer5.aura.CastingTimeBonusForAbility) * timer5.aura.CastingTimeModificatorForAbility);
                }
            }
            foreach (PermanentAura aura1 in from.PermanentAuras)
            {
                if ((aura1.aura.CastingTimeEffectedAbilityList != 0) && (from.SpecialForAuras[aura1.aura.CastingTimeEffectedAbilityList] != null))
                {
                    if ((from.SpecialForAuras[aura1.aura.CastingTimeEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[aura1.aura.CastingTimeEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num1 = (int) ((num1 + aura1.aura.CastingTimeBonusForAbility) * aura1.aura.CastingTimeModificatorForAbility);
                    }
                    if (from.SpecialForAuras[aura1.aura.CastingTimeEffectedAbilityList] is int)
                    {
                        int num3 = (int) from.SpecialForAuras[aura1.aura.CastingTimeEffectedAbilityList];
                        if (num3 == this.Id)
                        {
                            num1 = (int) ((num1 + aura1.aura.CastingTimeBonusForAbility) * aura1.aura.CastingTimeModificatorForAbility);
                        }
                    }
                }
                if ((aura1.aura.CastingTimeEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == aura1.aura.CastingTimeEffectedAbilityClass))
                {
                    num1 = (int) ((num1 + aura1.aura.CastingTimeBonusForAbility) * aura1.aura.CastingTimeModificatorForAbility);
                }
            }
            if (num1 > 0)
            {
                num1 = (int) (((float) num1) / ((float) from.CastingSpeed));
            }
            return num1;
        }

        public void Dispel(DispelType type, int num, Mobile from)
        {
            int num1 = num;
            foreach (Mobile.AuraReleaseTimer timer1 in from.Auras)
            {
                if (num1 < 1)
                {
                    return;
                }
                if (timer1.ae.Dispeltype == type)
                {
                    timer1.aura.Release(from);
                }
                num1--;
                if (num1 < 1)
                {
                    return;
                }
            }
        }

        public void DrainLife(Mobile src, Mobile target, SpellDamage sd)
        {
            int num1 = 1;
            int num2 = 1;
            switch (sd)
            {
                case SpellDamage.TypeS1:
                {
                    num1 = this.s1;
                    num2 = this.bonus1;
                    break;
                }
                case SpellDamage.TypeS2:
                {
                    num1 = this.s2;
                    num2 = this.bonus2;
                    break;
                }
            }
            float single1 = num1 + Utility.Random(1, num2);
            if (single1 <= 0f)
            {
                single1 = 1f;
            }
            this.DrainLife(src, target, single1);
        }

        public void DrainLife(Mobile src, Mobile target, float dmg)
        {
            if (src.HaveTalent(Talents.ImprovedHealthFunnel) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2f3]))
            {
                AuraEffect effect1 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedHealthFunnel);
                dmg += ((dmg * effect1.S1) / 100f);
            }
            int num1 = this.MakeDamage(true, src, target, dmg, true);
            if (src.HaveTalent(Talents.ImprovedDrainLife))
            {
                AuraEffect effect2 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedDrainLife);
                float single1 = num1;
                single1 += ((single1 * effect2.S1) / 100f);
                num1 = (int) single1;
            }
            src.GainHealth(target, num1);
        }

        public void DrainMana(Mobile src, Mobile target, SpellDamage sd)
        {
            int num1 = this.MakeManaDamage(src, target, sd);
            float single1 = 0f;
            if (src.HaveTalent(Talents.ImprovedDrainMana))
            {
                AuraEffect effect1 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedDrainMana);
                if (src.TalentLevel(Talents.ImprovedDrainMana) == 1)
                {
                    single1 = (float) (num1 * 0.15);
                }
                else
                {
                    single1 = (float) (num1 * 0.3);
                }
            }
            if (single1 > 0f)
            {
                this.MakeDamage(src, target, single1);
            }
            src.GainMana(target, num1);
        }

        public void DrainMana(Mobile src, Mobile target, float dmg)
        {
            int num1 = this.MakeManaDamage(src, target, dmg, true);
            float single1 = 0f;
            if (src.HaveTalent(Talents.ImprovedDrainMana))
            {
                AuraEffect effect1 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedDrainMana);
                if (src.TalentLevel(Talents.ImprovedDrainMana) == 1)
                {
                    single1 = (float) (num1 * 0.15);
                }
                else
                {
                    single1 = (float) (num1 * 0.3);
                }
            }
            if (single1 > 0f)
            {
                this.MakeDamage(src, target, single1);
            }
            src.GainMana(target, num1);
        }

        public virtual int Duration()
        {
            return this.duration;
        }

        public virtual int Duration(Mobile from)
        {
            IEnumerator enumerator1;
            int num1 = this.duration;
            Classes classes1 = from.Classe;
            if (classes1 != Classes.Warrior)
            {
                if (((classes1 != Classes.Mage) || (this.resistance != Resistances.Frost)) || (!from.HaveTalent(Talents.Permafrost) || (SpellTemplate.SpellEffects[(int) this.Id] != SpellTemplate.SpellEffects[0x30c5])))
                {
                    goto Label_0186;
                }
                AuraEffect effect1 = (AuraEffect) from.GetTalentEffect(Talents.Permafrost);
                return (this.duration + effect1.S1);
            }
            if (from.HaveTalent(Talents.ImprovedShieldBlock) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0xa05]))
            {
                AuraEffect effect2 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedShieldBlock);
                return (this.duration + effect2.S2);
            }
            if (from.HaveTalent(Talents.ImprovedDisarm) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2a4]))
            {
                AuraEffect effect3 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedDisarm);
                return (this.duration + effect3.S2);
            }
            if (from.HaveTalent(Talents.ImprovedShieldWall) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x367]))
            {
                AuraEffect effect4 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedShieldWall);
                return (this.duration + effect4.S2);
            }
        Label_0186:
            enumerator1 = from.Auras.GetEnumerator();
            try
            {
                while (enumerator1.MoveNext())
                {
                    Mobile.AuraReleaseTimer timer1 = (Mobile.AuraReleaseTimer) enumerator1.Current;
                    if ((timer1.aura.DurationEffectedAbilityList != 0) && (from.SpecialForAuras[timer1.aura.DurationEffectedAbilityList] != null))
                    {
                        if ((from.SpecialForAuras[timer1.aura.DurationEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[timer1.aura.DurationEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                        {
                            num1 = (int) ((num1 + timer1.aura.DurationBonusForAbility) * timer1.aura.DurationModificatorForAbility);
                        }
                        if (from.SpecialForAuras[timer1.aura.DurationEffectedAbilityList] is int)
                        {
                            int num2 = (int) from.SpecialForAuras[timer1.aura.DurationEffectedAbilityList];
                            if (num2 == this.Id)
                            {
                                num1 = (int) ((num1 + timer1.aura.DurationBonusForAbility) * timer1.aura.DurationModificatorForAbility);
                            }
                        }
                    }
                    if ((timer1.aura.DurationEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == timer1.aura.DurationEffectedAbilityClass))
                    {
                        num1 = (int) ((num1 + timer1.aura.DurationBonusForAbility) * timer1.aura.DurationModificatorForAbility);
                    }
                }
            }
            finally
            {
                IDisposable disposable1 = enumerator1 as IDisposable;
                if (disposable1 != null)
                {
                    disposable1.Dispose();
                }
            }
            foreach (PermanentAura aura1 in from.PermanentAuras)
            {
                if ((aura1.aura.DurationEffectedAbilityList != 0) && (from.SpecialForAuras[aura1.aura.DurationEffectedAbilityList] != null))
                {
                    if ((from.SpecialForAuras[aura1.aura.DurationEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[aura1.aura.DurationEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num1 = (int) ((num1 + aura1.aura.DurationBonusForAbility) * aura1.aura.DurationModificatorForAbility);
                    }
                    if (from.SpecialForAuras[aura1.aura.DurationEffectedAbilityList] is int)
                    {
                        int num3 = (int) from.SpecialForAuras[aura1.aura.DurationEffectedAbilityList];
                        if (num3 == this.Id)
                        {
                            num1 = (int) ((num1 + aura1.aura.DurationBonusForAbility) * aura1.aura.DurationModificatorForAbility);
                        }
                    }
                }
                if ((aura1.aura.DurationEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == aura1.aura.DurationEffectedAbilityClass))
                {
                    num1 = (int) ((num1 + aura1.aura.DurationBonusForAbility) * aura1.aura.DurationModificatorForAbility);
                }
            }
            return num1;
        }

        private float FireSpellModifier(Mobile from)
        {
            return 1f;
        }

        private float FrostSpellModifier(Mobile from)
        {
            return 1f;
        }

        public int GetManaCost(Mobile c)
        {
            int num1 = this.manaCost;
            Classes classes1 = c.Classe;
            if (classes1 != Classes.Warrior)
            {
                switch (classes1)
                {
                    case Classes.Mage:
                    {
                        if ((this.resistance == Resistances.Frost) && c.HaveTalent(Talents.FrostChanneling))
                        {
                            AuraEffect effect1 = (AuraEffect) c.GetTalentEffect(Talents.FrostChanneling);
                            num1 += ((int) (((float) effect1.S1) / 100f));
                        }
                        int num2 = 0xd45a45;
                        if (c.AdditionnalStates.Contains(num2))
                        {
                            AuraEffect effect2 = (AuraEffect) c.GetTalentEffect(Talents.ArcaneConcentration);
                            num1 += effect2.S1;
                            c.AdditionnalStates.Remove(num2);
                        }
                        if (c.HaveTalent(Talents.ArcanePower))
                        {
                            bool flag1 = false;
                            ArrayList list1 = new ArrayList();
                            AuraEffect effect3 = (AuraEffect) c.GetTalentEffect(Talents.ArcanePower);
                            foreach (Mobile.AuraReleaseTimer timer1 in c.Auras)
                            {
                                if (timer1.aura.SpecialState == SpecialStates.ArcanePower)
                                {
                                    flag1 = true;
                                    list1.Add(timer1);
                                }
                            }
                            if (flag1)
                            {
                                num1 = (int) (num1 * (1f + (((float) effect3.S1) / 100f)));
                            }
                        }
                        goto Label_0378;
                    }
                    case Classes.Warlock:
                    {
                        if ((AbilityClasses.abilityClasses[this.Id] == 0x13) && c.HaveTalent(Talents.Cataclysm))
                        {
                            AuraEffect effect8 = (AuraEffect) c.GetTalentEffect(Talents.Cataclysm);
                            num1 = (int) (num1 * (1f + (((float) effect8.S1) / 100f)));
                        }
                        if (c.HaveTalent(Talents.FelDomination))
                        {
                            bool flag2 = false;
                            ArrayList list2 = new ArrayList();
                            AuraEffect effect9 = (AuraEffect) c.GetTalentEffect(Talents.FelDomination);
                            foreach (Mobile.AuraReleaseTimer timer2 in c.Auras)
                            {
                                if (timer2.aura.SpecialState == SpecialStates.FelDomination)
                                {
                                    flag2 = true;
                                    list2.Add(timer2);
                                }
                            }
                            if (flag2)
                            {
                                num1 = (int) (num1 * 0.5);
                            }
                        }
                        goto Label_0378;
                    }
                }
            }
            else
            {
                if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x11c]) && c.HaveTalent(Talents.ImprovedHeroicStrike))
                {
                    AuraEffect effect4 = (AuraEffect) c.GetTalentEffect(Talents.ImprovedHeroicStrike);
                    num1 += effect4.S1;
                }
                if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x18c7]) && c.HaveTalent(Talents.ImprovedThunderClap))
                {
                    AuraEffect effect5 = (AuraEffect) c.GetTalentEffect(Talents.ImprovedThunderClap);
                    num1 += effect5.s1;
                }
                if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2d4d]) && c.HaveTalent(Talents.ImprovedSunderArmor))
                {
                    AuraEffect effect6 = (AuraEffect) c.GetTalentEffect(Talents.ImprovedSunderArmor);
                    num1 += effect6.s1;
                }
                if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x14bc]) && c.HaveTalent(Talents.ImprovedExecute))
                {
                    AuraEffect effect7 = (AuraEffect) c.GetTalentEffect(Talents.ImprovedExecute);
                    num1 += effect7.S1;
                }
            }
        Label_0378:
            switch (this.resistance)
            {
                case Resistances.Light:
                {
                    num1 -= c.HolyCostMalus;
                    break;
                }
                case Resistances.Fire:
                {
                    num1 -= c.FireCostMalus;
                    break;
                }
                case Resistances.Nature:
                {
                    num1 -= c.NatureCostMalus;
                    break;
                }
                case Resistances.Frost:
                {
                    num1 -= c.FrostCostMalus;
                    break;
                }
                case Resistances.Shadow:
                {
                    num1 -= c.ShadowCostMalus;
                    break;
                }
                case Resistances.Arcane:
                {
                    num1 -= c.ArcaneCostMalus;
                    break;
                }
            }
            num1 -= c.AllCostMalus;
            int num3 = 0;
            num1 -= num3;
            num1 = (int) (num1 * c.PowerCostModifier);
            foreach (Mobile.AuraReleaseTimer timer3 in c.Auras)
            {
                if ((timer3.aura.CostEffectedAbilityList != 0) && (c.SpecialForAuras[timer3.aura.CostEffectedAbilityList] != null))
                {
                    if ((c.SpecialForAuras[timer3.aura.CostEffectedAbilityList] is ArrayList) && (c.SpecialForAuras[timer3.aura.CostEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num1 = (int) ((num1 + timer3.aura.CostBonusForAbility) * timer3.aura.CostModificatorForAbility);
                    }
                    if (c.SpecialForAuras[timer3.aura.CostEffectedAbilityList] is int)
                    {
                        int num4 = (int) c.SpecialForAuras[timer3.aura.CostEffectedAbilityList];
                        if (num4 == this.Id)
                        {
                            num1 = (int) ((num1 + timer3.aura.CostBonusForAbility) * timer3.aura.CostModificatorForAbility);
                        }
                    }
                }
                if ((timer3.aura.CostEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == timer3.aura.CostEffectedAbilityClass))
                {
                    num1 = (int) ((num1 + timer3.aura.CostBonusForAbility) * timer3.aura.CostModificatorForAbility);
                }
            }
            foreach (PermanentAura aura1 in c.PermanentAuras)
            {
                if ((aura1.aura.CostEffectedAbilityList != 0) && (c.SpecialForAuras[aura1.aura.CostEffectedAbilityList] != null))
                {
                    if ((c.SpecialForAuras[aura1.aura.CostEffectedAbilityList] is ArrayList) && (c.SpecialForAuras[aura1.aura.CostEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num1 = (int) ((num1 + aura1.aura.CostBonusForAbility) * aura1.aura.CostModificatorForAbility);
                    }
                    if (c.SpecialForAuras[aura1.aura.CostEffectedAbilityList] is int)
                    {
                        int num5 = (int) c.SpecialForAuras[aura1.aura.CostEffectedAbilityList];
                        if (num5 == this.Id)
                        {
                            num1 = (int) ((num1 + aura1.aura.CostBonusForAbility) * aura1.aura.CostModificatorForAbility);
                        }
                    }
                }
                if ((aura1.aura.CostEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == aura1.aura.CostEffectedAbilityClass))
                {
                    num1 = (int) ((num1 + aura1.aura.CostBonusForAbility) * aura1.aura.CostModificatorForAbility);
                }
            }
            if (num1 <= 0)
            {
                num1 = 0;
            }
            return num1;
        }

        public int GetRadius(Mobile from, int number)
        {
            int num1 = 0;
            switch (number)
            {
                case 1:
                {
                    num1 = this.Radius1;
                    break;
                }
                case 2:
                {
                    num1 = this.Radius2;
                    break;
                }
                case 3:
                {
                    num1 = this.Radius3;
                    break;
                }
                default:
                {
                    return 0;
                }
            }
            foreach (Mobile.AuraReleaseTimer timer1 in from.Auras)
            {
                if ((timer1.aura.RadiusEffectedAbilityList != 0) && (from.SpecialForAuras[timer1.aura.RadiusEffectedAbilityList] != null))
                {
                    if ((from.SpecialForAuras[timer1.aura.RadiusEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[timer1.aura.RadiusEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num1 = (int) ((num1 + timer1.aura.RadiusBonusForAbility) * timer1.aura.RadiusModificatorForAbility);
                    }
                    if (from.SpecialForAuras[timer1.aura.RadiusEffectedAbilityList] is int)
                    {
                        int num2 = (int) from.SpecialForAuras[timer1.aura.RadiusEffectedAbilityList];
                        if (num2 == this.Id)
                        {
                            num1 = (int) ((num1 + timer1.aura.RadiusBonusForAbility) * timer1.aura.RadiusModificatorForAbility);
                        }
                    }
                }
                if ((timer1.aura.RadiusEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == timer1.aura.RadiusEffectedAbilityClass))
                {
                    num1 = (int) ((num1 + timer1.aura.RadiusBonusForAbility) * timer1.aura.RadiusModificatorForAbility);
                }
            }
            foreach (PermanentAura aura1 in from.PermanentAuras)
            {
                if ((aura1.aura.RadiusEffectedAbilityList != 0) && (from.SpecialForAuras[aura1.aura.RadiusEffectedAbilityList] != null))
                {
                    if ((from.SpecialForAuras[aura1.aura.RadiusEffectedAbilityList] is ArrayList) && (from.SpecialForAuras[aura1.aura.RadiusEffectedAbilityList] as ArrayList).Contains((int) this.Id))
                    {
                        num1 = (int) ((num1 + aura1.aura.RadiusBonusForAbility) * aura1.aura.RadiusModificatorForAbility);
                    }
                    if (from.SpecialForAuras[aura1.aura.RadiusEffectedAbilityList] is int)
                    {
                        int num3 = (int) from.SpecialForAuras[aura1.aura.RadiusEffectedAbilityList];
                        if (num3 == this.Id)
                        {
                            num1 = (int) ((num1 + aura1.aura.RadiusBonusForAbility) * aura1.aura.RadiusModificatorForAbility);
                        }
                    }
                }
                if ((aura1.aura.RadiusEffectedAbilityClass != 0) && (AbilityClasses.abilityClasses[this.Id] == aura1.aura.RadiusEffectedAbilityClass))
                {
                    num1 = (int) ((num1 + aura1.aura.RadiusBonusForAbility) * aura1.aura.RadiusModificatorForAbility);
                }
            }
            return num1;
        }

        public void Heal(Mobile src, Mobile target, SpellDamage d)
        {
            int num1 = 1;
            int num2 = 1;
            switch (d)
            {
                case SpellDamage.TypeS1:
                {
                    num1 = this.s1;
                    num2 = this.bonus1;
                    break;
                }
                case SpellDamage.TypeS2:
                {
                    num1 = this.s2;
                    num2 = this.bonus2;
                    break;
                }
            }
            float single1 = num1 + Utility.Random(1, num2);
            this.Heal(src, target, single1);
        }

        public void Heal(Mobile src, Mobile target, float dmg)
        {
            float single1 = 1f;
            dmg += (src.HealGiveIncrease - src.HealGiveDecrease);
            dmg *= src.HealGiveModifier;
            dmg += (src.HealTakeIncrease - src.HealTakeDecrease);
            dmg *= src.HealTakeModifier;
            switch (this.resistance)
            {
                case Resistances.Light:
                {
                    single1 = this.LightSpellHealModifier(src);
                    break;
                }
                case Resistances.Nature:
                {
                    single1 = this.NatureSpellHealModifier(src);
                    break;
                }
            }
            dmg *= single1;
            if (((src.Classe == Classes.Warlock) && src.HaveTalent(Talents.ImprovedHealthstone)) && (SpellTemplate.SpellEffects[0x1658] == SpellTemplate.SpellEffects[this.Id]))
            {
                AuraEffect effect1 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedHealthstone);
                dmg += ((dmg * effect1.s1) / 100f);
            }
            target.GainHealth(src, (int) dmg);
        }

        public void Heal(Mobile src, Mobile target, int basedmg, int bonus)
        {
            float single1 = basedmg + Utility.Random(1, bonus);
            this.Heal(src, target, single1);
        }

        public int HitChanceCalculation(Mobile from, Mobile target)
        {
            int num1;
            int num2 = 0;
            if ((target is Character) && (from is Character))
            {
                num1 = target.Level - from.Level;
                if (num1 <= 0)
                {
                    num2 = 0x60;
                }
                else if (num1 == 1)
                {
                    num2 = 0x5f;
                }
                else
                {
                    num2 = 0x5e - ((num1 - 2) * 7);
                }
            }
            else
            {
                num1 = target.Level - from.Level;
                if (num1 <= 0)
                {
                    num2 = 0x60;
                }
                else if (num1 == 1)
                {
                    num2 = 0x5f;
                }
                else
                {
                    num2 = 0x5e - ((num1 - 2) * 11);
                }
            }
            return (num2 + (from.SpellHitBonus - from.SpellHitMalus));
        }

        public bool ImmuneCheck(Mobile target, Aura a)
        {
            if (target.ImmuneAllSpellsAndAbilites)
            {
                return true;
            }
            if ((this.resistance == Resistances.Fire) && target.ImmuneFireSpell)
            {
                return true;
            }
            if ((this.resistance == Resistances.Frost) && target.ImmuneFrostSpell)
            {
                return true;
            }
            if ((this.resistance == Resistances.Armor) && target.ImmunePhysicalDamage)
            {
                return true;
            }
            switch (this.dispeltype)
            {
                case DispelType.Magic:
                {
                    if (target.ImmuneMagic)
                    {
                        return true;
                    }
                    break;
                }
                case DispelType.Disease:
                {
                    if (target.ImmuneDisease)
                    {
                        return true;
                    }
                    break;
                }
                case DispelType.Poison:
                {
                    if (target.ImmunePoison)
                    {
                        return true;
                    }
                    break;
                }
            }
            if (a.ForceFlee && target.ImmuneToFear)
            {
                return true;
            }
            if ((a.ForceRoot || a.ForceStun) && target.ImmuneToImmobilization)
            {
                return true;
            }
            return false;
        }

        public bool ImmuneCheck(Mobile target, SpellTemplate a)
        {
            if (target.ImmuneAllSpellsAndAbilites)
            {
                return true;
            }
            if ((this.resistance == Resistances.Fire) && target.ImmuneFireSpell)
            {
                return true;
            }
            if ((this.resistance == Resistances.Frost) && target.ImmuneFrostSpell)
            {
                return true;
            }
            if ((this.resistance == Resistances.Armor) && target.ImmunePhysicalDamage)
            {
                return true;
            }
            switch (this.dispeltype)
            {
                case DispelType.Magic:
                {
                    if (target.ImmuneMagic)
                    {
                        return true;
                    }
                    break;
                }
                case DispelType.Disease:
                {
                    if (target.ImmuneDisease)
                    {
                        return true;
                    }
                    break;
                }
                case DispelType.Poison:
                {
                    if (target.ImmunePoison)
                    {
                        return true;
                    }
                    break;
                }
            }
            return false;
        }

        public int InterruptCasting(Mobile from, Mobile target)
        {
            float single3;
            float single1 = (float) Utility.RandomDouble();
            float single2 = this.ResistCalculation(from, target);
            if (single1 < single2)
            {
                if (from is Character)
                {
                    int num1 = 4;
                    Converter.ToBytes(target.Guid, target.tempBuff, ref num1);
                    Converter.ToBytes(from.Guid, target.tempBuff, ref num1);
                    Converter.ToBytes(this.Id, target.tempBuff, ref num1);
                    Converter.ToBytes(0, target.tempBuff, ref num1);
                    Converter.ToBytes(2, target.tempBuff, ref num1);
                    Converter.ToBytes((ushort) 0x100, target.tempBuff, ref num1);
                    Converter.ToBytes(target.Guid, target.tempBuff, ref num1);
                    (from as Character).Send(OpCodes.SMSG_SPELLNONMELEEDAMAGELOG, target.tempBuff, num1);
                }
                return 0;
            }
            single3 = single3 = ((float) ((5 * from.Level) - (target.Level * 5))) / 5f;
            float single4 = 0f;
            if ((from is Character) && (target is Character))
            {
                single4 = 95f;
            }
            else
            {
                if (single3 > 0f)
                {
                    single4 = 0x5f + ((int) single3);
                }
                else if (target.Level > (from.Level + 3))
                {
                    single4 = 0x5f - (((int) single3) * 15);
                }
                else
                {
                    single4 = 0x5f - (((int) single3) * 10);
                }
                if (single4 >= 99f)
                {
                    single4 = 99f;
                }
                if (single4 <= 1f)
                {
                    single4 = 1f;
                }
            }
            int num2 = Utility.Random(100);
            if (num2 >= single4)
            {
                return 0;
            }
            return target.InterruptCasting();
        }

        public static bool IsFrozen(Mobile c)
        {
            foreach (Mobile.AuraReleaseTimer timer1 in c.Auras)
            {
                if ((timer1.ae.resistance == Resistances.Frost) && timer1.aura.ForceStun)
                {
                    return true;
                }
            }
            return false;
        }

        public void LifeTap(Mobile src, Mobile target, SpellDamage sd)
        {
            int num1 = 1;
            int num2 = 1;
            switch (sd)
            {
                case SpellDamage.TypeS1:
                {
                    num1 = this.s1;
                    num2 = this.bonus1;
                    break;
                }
                case SpellDamage.TypeS2:
                {
                    num1 = this.s2;
                    num2 = this.bonus2;
                    break;
                }
            }
            float single1 = num1 + Utility.Random(1, num2);
            if (single1 <= 0f)
            {
                single1 = 1f;
            }
            this.LifeTap(src, target, single1);
        }

        public void LifeTap(Mobile src, Mobile target, float dmg)
        {
            target.LooseHits(src, (int) dmg);
            if (src.HaveTalent(Talents.ImprovedLifeTap))
            {
                AuraEffect effect1 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedLifeTap);
                float single1 = dmg;
                single1 += ((single1 * effect1.S1) / 100f);
                target.GainMana(src, (int) single1);
            }
            src.GainMana(src, (int) dmg);
        }

        public float LightSpellHealModifier(Mobile from)
        {
            float single1 = 1f;
            AuraEffect effect1 = null;
            if (from.HaveTalent(Talents.SpiritualHealing))
            {
                effect1 = (AuraEffect) from.GetTalentEffect(Talents.SpiritualHealing);
                single1 += (((float) effect1.s1) / 100f);
            }
            if (from.HaveTalent(Talents.ImprovedHolyLight))
            {
                effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedHolyLight);
                single1 += (((float) effect1.s1) / 100f);
            }
            if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x17be]) && from.HaveTalent(Talents.ImprovedRenew))
            {
                effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedRenew);
                single1 += (((float) effect1.s1) / 100f);
            }
            return single1;
        }

        private float LightSpellModifier(Mobile from)
        {
            return 1f;
        }

        public ArrayList MakeAreaDamage(Mobile src, SpellDamage sd, float area, float X, float Y, float Z)
        {
            ArrayList list1 = new ArrayList();
            if (src is Character)
            {
                foreach (Server.Object obj1 in (src as Character).KnownObjects)
                {
                    if (!(obj1 is Mobile) || (obj1 == src))
                    {
                        continue;
                    }
                    Mobile mobile1 = obj1 as Mobile;
                    if (mobile1.Distance(X, Y, Z) < area)
                    {
                        list1.Add(mobile1);
                    }
                }
            }
            else
            {
                foreach (Mobile mobile2 in World.allMobiles)
                {
                    if (mobile2.Distance(X, Y, Z) < area)
                    {
                        list1.Add(mobile2);
                    }
                }
            }
            foreach (Mobile mobile3 in list1)
            {
                this.MakeDamage(src, mobile3, sd);
            }
            return list1;
        }

        public int MakeDamage(Mobile src, Mobile target, SpellDamage sd)
        {
            return this.MakeDamage(false, src, target, sd);
        }

        public int MakeDamage(Mobile src, Mobile target, float dmg)
        {
            return this.MakeDamage(false, src, target, dmg, true);
        }

        public int MakeDamage(Mobile src, Mobile target, float dmg, bool f)
        {
            return this.MakeDamage(false, src, target, dmg, true);
        }

        public int MakeDamage(bool forceDamage, Mobile src, Mobile target, SpellDamage sd)
        {
            int num1 = 1;
            int num2 = 1;
            switch (sd)
            {
                case SpellDamage.TypeS1:
                {
                    num1 = this.s1;
                    num2 = this.bonus1;
                    break;
                }
                case SpellDamage.TypeS2:
                {
                    num1 = this.s2;
                    num2 = this.bonus2;
                    break;
                }
            }
            float single1 = num1 + Utility.Random(1, num2);
            if (single1 <= 0f)
            {
                single1 = 1f;
            }
            return this.MakeDamage(forceDamage, src, target, single1);
        }

        public int MakeDamage(bool forceDamage, Mobile src, Mobile target, float dmg)
        {
            return this.MakeDamage(forceDamage, src, target, dmg, true);
        }

        public int MakeDamage(bool forceDamage, Mobile src, Mobile target, float dmg, bool f)
        {
            return this.MakeDamage(forceDamage, src, target, dmg, f, true);
        }

        public int MakeDamage(bool forceDamage, Mobile src, Mobile target, float dmg, bool f, bool showMSG)
        {
            int num6;
            Classes classes1;
            if (forceDamage)
            {
                target.LooseHits(src, (int) dmg, false);
                return (int) dmg;
            }
            if (target.Dead)
            {
                return 0;
            }
            if (this.ImmuneCheck(target, this))
            {
                if (src is Character)
                {
                    (src as Character).SendMessage("Target is immune agains this spell");
                }
                target.OnGetHit(src, false, 0);
                return 0;
            }
            Utility.RandomDouble();
            float single1 = this.ResistCalculation(src, target);
            int num2 = 0;
            int num3 = 0;
            int num4 = 0;
            float single2 = 1f;
            int num5 = 0;
            if (src.Level > 9)
            {
                classes1 = src.Classe;
                if (classes1 == Classes.Warrior)
                {
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x1cd8]) && src.HaveTalent(Talents.ImprovedOverpower))
                    {
                        AuraEffect effect15 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedOverpower);
                        num2 += effect15.S1;
                    }
                }
                else
                {
                    switch (classes1)
                    {
                        case Classes.Mage:
                        {
                            if (((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x85a]) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x27dd])) && src.HaveTalent(Talents.Incinerate))
                            {
                                AuraEffect effect6 = (AuraEffect) src.GetTalentEffect(Talents.Incinerate);
                                num2 += effect6.S1;
                            }
                            if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x27e7]) && src.HaveTalent(Talents.ImprovedFlamestrike))
                            {
                                AuraEffect effect7 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedFlamestrike);
                                num2 += effect7.S1;
                            }
                            if ((AbilityClasses.abilityClasses[this.Id] == 0x20) && src.HaveTalent(Talents.IceShards))
                            {
                                AuraEffect effect8 = (AuraEffect) src.GetTalentEffect(Talents.IceShards);
                                num3 += effect8.S1;
                            }
                            if ((this.resistance == Resistances.Frost) && src.HaveTalent(Talents.PiercingIce))
                            {
                                AuraEffect effect9 = (AuraEffect) src.GetTalentEffect(Talents.PiercingIce);
                                single2 *= (1f + (((float) effect9.S1) / 100f));
                            }
                            if ((this.resistance == Resistances.Fire) && src.HaveTalent(Talents.FirePower))
                            {
                                AuraEffect effect10 = (AuraEffect) src.GetTalentEffect(Talents.FirePower);
                                single2 *= (1f + (((float) effect10.S1) / 100f));
                            }
                            if (((this.resistance == Resistances.Frost) && src.HaveTalent(Talents.Shatter)) && SpellTemplate.IsFrozen(target))
                            {
                                AuraEffect effect11 = (AuraEffect) src.GetTalentEffect(Talents.Shatter);
                                ushort num13 = effect11.Id;
                                if (num13 != 0x2ba2)
                                {
                                    switch (num13)
                                    {
                                        case 0x32b6:
                                        {
                                            num3 += 20;
                                            goto Label_044D;
                                        }
                                        case 0x32b7:
                                        {
                                            num3 += 30;
                                            goto Label_044D;
                                        }
                                        case 0x32b8:
                                        {
                                            num3 += 40;
                                            goto Label_044D;
                                        }
                                        case 0x32b9:
                                        {
                                            num3 += 50;
                                            goto Label_044D;
                                        }
                                    }
                                }
                                else
                                {
                                    num3 += 10;
                                }
                            }
                            goto Label_044D;
                        }
                        case Classes.Warlock:
                        {
                            if ((this.resistance == Resistances.Fire) && src.HaveTalent(Talents.Emberstorm))
                            {
                                AuraEffect effect1 = (AuraEffect) src.GetTalentEffect(Talents.Emberstorm);
                                single2 *= (1f + (((float) effect1.S1) / 100f));
                            }
                            if (src.HaveTalent(Talents.Ruin) && (AbilityClasses.abilityClasses[this.Id] == 0x13))
                            {
                                AuraEffect effect23 = (AuraEffect) src.GetTalentEffect(Talents.Ruin);
                                num3 += 100;
                            }
                            if (src.HaveTalent(Talents.ImprovedCurseOfAgony) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[980]))
                            {
                                AuraEffect effect2 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedCurseOfAgony);
                                single2 *= (1f + (((float) effect2.S1) / 100f));
                            }
                            if ((AbilityClasses.abilityClasses[this.Id] == 0x61) && src.HaveTalent(Talents.ShadowMastery))
                            {
                                AuraEffect effect3 = (AuraEffect) src.GetTalentEffect(Talents.ShadowMastery);
                                single2 *= (1f + (((float) effect3.S1) / 100f));
                            }
                            if ((AbilityClasses.abilityClasses[this.Id] == 0x13) && src.HaveTalent(Talents.Devastation))
                            {
                                AuraEffect effect4 = (AuraEffect) src.GetTalentEffect(Talents.Devastation);
                                num2 += effect4.S1;
                            }
                            if (src.HaveTalent(Talents.ImprovedSearingPain) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x162c]))
                            {
                                AuraEffect effect5 = (AuraEffect) src.GetTalentEffect(Talents.MasterHealer);
                                num2 += effect5.S1;
                            }
                            goto Label_06AF;
                        }
                        case (Classes.Mage | Classes.Paladin):
                        case Classes.Druid:
                        {
                            goto Label_06AF;
                        }
                    }
                }
            }
            goto Label_06AF;
        Label_044D:
            if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[120]) && src.HaveTalent(Talents.ImprovedConeOfCold))
            {
                AuraEffect effect12 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedConeOfCold);
                single2 *= (1f + (((float) effect12.S1) / 100f));
            }
            if (src.HaveTalent(Talents.ArcaneInstability))
            {
                AuraEffect effect13 = (AuraEffect) src.GetTalentEffect(Talents.ArcaneInstability);
                num2 += effect13.S1;
                single2 *= (1f + (((float) effect13.S1) / 100f));
            }
            if (src.HaveTalent(Talents.Combustion) && (this.resistance == Resistances.Fire))
            {
                bool flag1 = false;
                ArrayList list1 = new ArrayList();
                AuraEffect effect24 = (AuraEffect) src.GetTalentEffect(Talents.Combustion);
                foreach (Mobile.AuraReleaseTimer timer1 in src.Auras)
                {
                    if (timer1.aura.SpecialState == SpecialStates.Combustion)
                    {
                        flag1 = true;
                        list1.Add(timer1);
                    }
                }
                if (flag1)
                {
                    num2 += 100;
                    foreach (Mobile.AuraReleaseTimer timer2 in list1)
                    {
                        src.ReleaseAura(timer2);
                    }
                }
            }
            if (src.HaveTalent(Talents.ArcanePower))
            {
                bool flag2 = false;
                ArrayList list2 = new ArrayList();
                AuraEffect effect14 = (AuraEffect) src.GetTalentEffect(Talents.ArcanePower);
                foreach (Mobile.AuraReleaseTimer timer3 in src.Auras)
                {
                    if (timer3.aura.SpecialState == SpecialStates.ArcanePower)
                    {
                        flag2 = true;
                        list2.Add(timer3);
                    }
                }
                if (flag2)
                {
                    single2 *= (1f + (((float) effect14.S1) / 100f));
                }
            }
        Label_06AF:
            dmg += num4;
            dmg *= single2;
            if (target is Character)
            {
                num6 = ((((int) (target as Character).BaseDodgeChance) + target.DodgeBonus) - target.DodgeMalus) - ((src.Level - target.Level) / 2);
            }
            else
            {
                num6 = ((5 - ((src.Level - target.Level) / 2)) + target.DodgeBonus) - target.DodgeMalus;
            }
            int num1 = Utility.Random(100);
            num6 += num5;
            if (num6 >= num1)
            {
                if (src is Character)
                {
                    (src as Character).SendMessage("Target dodge your spell");
                }
                target.OnGetHit(src, false, 0);
                return 0;
            }
            switch (this.resistance)
            {
                case Resistances.Armor:
                {
                    dmg += src.PhysicalDamageIncrease;
                    dmg *= (1f + (src.PhysicalPercentDamageIncrease / 100f));
                    break;
                }
                case Resistances.Light:
                {
                    dmg += src.HolyDamageIncrease;
                    break;
                }
                case Resistances.Fire:
                {
                    dmg += src.FireDamageIncrease;
                    dmg *= (1f + (src.FirePercentDamageIncrease / 100f));
                    break;
                }
                case Resistances.Nature:
                {
                    dmg += src.NatureDamageIncrease;
                    dmg *= (1f + (src.NaturePercentDamageIncrease / 100f));
                    break;
                }
                case Resistances.Frost:
                {
                    dmg += src.FrostDamageIncrease;
                    dmg *= (1f + (src.FrostPercentDamageIncrease / 100f));
                    break;
                }
                case Resistances.Shadow:
                {
                    dmg += src.ShadowDamageIncrease;
                    dmg *= (1f + (src.ShadowPercentDamageIncrease / 100f));
                    break;
                }
                case Resistances.Arcane:
                {
                    dmg += src.ArcaneDamageIncrease;
                    break;
                }
            }
            dmg = ((dmg + src.AllDamageDoneBonus) - src.AllDamageDoneMalus) * src.AllDamageDoneModifier;
            dmg += src.AllMagicDamageIncrease;
            int num14 = target.NpcType;
            if (num14 != 3)
            {
                if (num14 == 6)
                {
                    dmg += src.SpellDamageDoneAgainsUndeadBonus;
                }
            }
            else
            {
                dmg += src.SpellDamageDoneAgainsDemonsBonus;
            }
            if (src.SummonedBy != null)
            {
                dmg += (src.SummonedBy.PetDamageBonus - src.SummonedBy.PetDamageMalus);
            }
            num1 = Utility.Random(100);
            int num7 = 0;
            num7 = ((int) (5f + (((float) src.Iq) / 29f))) + src.MagicalCriticalBonus;
            switch (this.resistance)
            {
                case Resistances.Light:
                {
                    num7 += src.HolyCriticalBonus;
                    break;
                }
                case Resistances.Fire:
                {
                    num7 += src.FireCriticalBonus;
                    break;
                }
                case Resistances.Nature:
                {
                    num7 += src.NatureCriticalBonus;
                    break;
                }
                case Resistances.Frost:
                {
                    num7 += src.FrostCriticalBonus;
                    break;
                }
                case Resistances.Shadow:
                {
                    num7 += src.ShadowCriticalBonus;
                    break;
                }
                case Resistances.Arcane:
                {
                    num7 += src.ArcaneCriticalBonus;
                    break;
                }
            }
            num7 += num2;
            if (num7 > num1)
            {
                if (src is Character)
                {
                    (src as Character).SendMessage("you give critical hit with your spell");
                }
                float single3 = 1.5f + (((float) num3) / 100f);
                classes1 = src.Classe;
                if (classes1 != Classes.Warrior)
                {
                }
                dmg *= single3;
                if (((src.Classe == Classes.Warlock) && (((this.resistance == Resistances.Fire) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2ae])) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x45d5]))) && src.HaveTalent(Talents.Ruin))
                {
                    dmg *= 1.5f;
                }
            }
            if (target.ActiveShield != null)
            {
                if (target is Character)
                {
                    num6 = ((((int) (target as Character).BaseBlockChance) + target.BlockBonus) - target.BlockMalus) - ((src.Level - target.Level) / 2);
                }
                else
                {
                    num6 = ((5 + target.BlockBonus) - target.BlockMalus) - ((src.Level - target.Level) / 2);
                }
                num1 = Utility.Random(100);
                object[] objArray1 = new object[4] { "block test = ", num1, " ", num6 } ;
                Console.WriteLine(string.Concat(objArray1));
                if (num6 >= num1)
                {
                    int num8 = target.Block + (target.Str / 30);
                    dmg -= num8;
                    if (src is Character)
                    {
                        (src as Character).SendMessage("Target block you " + num8 + " of damage");
                    }
                    if (dmg < 0f)
                    {
                        if (src is Character)
                        {
                            (src as Character).SendMessage("All damage blocked");
                        }
                        target.OnGetHit(src, false, 0);
                        return 0;
                    }
                }
            }
            float single4 = 0f;
            float single5 = 1f;
            switch (this.resistance)
            {
                case Resistances.Armor:
                {
                    single4 = ((float) target.Armor) / ((target.Armor + 400f) + (0x55 * src.Level));
                    break;
                }
                case Resistances.Light:
                {
                    single5 = this.LightSpellModifier(src);
                    break;
                }
                case Resistances.Fire:
                {
                    single5 = this.FireSpellModifier(src);
                    break;
                }
                case Resistances.Nature:
                {
                    single5 = this.NatureSpellModifier(src);
                    break;
                }
                case Resistances.Frost:
                {
                    single5 = this.FrostSpellModifier(src);
                    break;
                }
                case Resistances.Shadow:
                {
                    single5 = this.ShadowSpellModifier(src);
                    break;
                }
                case Resistances.Arcane:
                {
                    single5 = this.ArcaneSpellModifier(src);
                    break;
                }
            }
            if (single4 == 0f)
            {
                num1 = Utility.Random(100);
                if (num1 < 5)
                {
                    single4 = single1 - ((float) 0.5);
                }
                else if (num1 < 0x19)
                {
                    single4 = single1 - ((float) 0.25);
                }
                else if (num1 < 0x4b)
                {
                    single4 = single1;
                }
                else if (num1 < 0x5f)
                {
                    single4 = single1 + ((float) 0.25);
                }
                else
                {
                    single4 = single1 + ((float) 0.5);
                }
                if (single4 < 0f)
                {
                    single4 = 0f;
                }
                if (single4 > 1f)
                {
                    single4 = 1f;
                }
                single4 = (float) (((int) (((double) single4) / 0.25)) * 0.25);
            }
            dmg *= ((1f - single4) * single5);
            int num9 = 0;
            switch (this.resistance)
            {
                case Resistances.Armor:
                {
                    num9 = target.DiminishAbsorbPhysical((int) dmg);
                    num9 = target.DiminishAbsordbAll(num9);
                    break;
                }
                case Resistances.Light:
                {
                    num9 = target.DiminishHolyAbsordb((int) dmg);
                    num9 = target.DiminishAbsordbAll(num9);
                    break;
                }
                case Resistances.Fire:
                {
                    num9 = target.DiminishFireAbsordb((int) dmg);
                    if (((dmg - num9) > 0f) && target.HaveTalent(Talents.ImprovedFireWard))
                    {
                        AuraEffect effect16 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedFireWard);
                        float single6 = ((float) effect16.S1) / 100f;
                        bool flag3 = false;
                        foreach (Mobile.AuraReleaseTimer timer4 in target.Auras)
                        {
                            if (timer4.ae == ((AuraEffect) Abilities.abilities[0x27ef]))
                            {
                                flag3 = true;
                            }
                        }
                        if (flag3)
                        {
                            this.MakeDamage(target, src, (float) ((dmg - num9) * single6));
                        }
                    }
                    num9 = target.DiminishAbsordbAll(num9);
                    break;
                }
                case Resistances.Nature:
                {
                    num9 = target.DiminishNatureAbsordb((int) dmg);
                    num9 = target.DiminishAbsordbAll(num9);
                    break;
                }
                case Resistances.Frost:
                {
                    num9 = target.DiminishFrostAbsordb((int) dmg);
                    if (((target.Classe == Classes.Mage) && target.HaveTalent(Talents.ImprovedFrostWard)) && (num9 != dmg))
                    {
                        bool flag4 = false;
                        foreach (Mobile.AuraReleaseTimer timer5 in target.Auras)
                        {
                            if (timer5.ae == ((AuraEffect) Abilities.abilities[0x17ff]))
                            {
                                flag4 = true;
                            }
                        }
                        if (flag4)
                        {
                            target.GainMana(target, (int) ((dmg - num9) / 2f));
                        }
                    }
                    num9 = target.DiminishAbsordbAll(num9);
                    break;
                }
                case Resistances.Shadow:
                {
                    num9 = target.DiminishShadowAbsordb((int) dmg);
                    num9 = target.DiminishAbsordbAll(num9);
                    break;
                }
                case Resistances.Arcane:
                {
                    num9 = target.DiminishArcaneAbsordb((int) dmg);
                    num9 = target.DiminishAbsordbAll(num9);
                    break;
                }
            }
            num9 = target.DiminishAbsorbAllDamage(num9);
            num9 += (((target.DamageTakenBonus - target.DamageTakenMalus) + target.SpellDamageTakenBonus) - target.SpellDamageTakenMalus);
            num9 = (int) (num9 * target.DamageTakenModifier);
            switch (this.resistance)
            {
                case Resistances.Armor:
                {
                    num9 += (target.PhysicalDamageTakenBonus - target.PhysicalDamageTakenMalus);
                    break;
                }
                case Resistances.Light:
                {
                    num9 += (target.HolyDamageTakenBonus - target.HolyDamageTakenMalus);
                    break;
                }
                case Resistances.Fire:
                {
                    num9 += (target.FireDamageTakenBonus - target.FireDamageTakenMalus);
                    num9 = (int) (num9 * target.FireDamageTakenModifier);
                    break;
                }
                case Resistances.Nature:
                {
                    num9 += (target.NatureDamageTakenBonus - target.NatureDamageTakenMalus);
                    break;
                }
                case Resistances.Frost:
                {
                    num9 += (target.FrostDamageTakenBonus - target.FrostDamageTakenMalus);
                    break;
                }
                case Resistances.Shadow:
                {
                    num9 += (target.ShadowDamageTakenBonus - target.ShadowDamageTakenMalus);
                    num9 = (int) (num9 * target.ShadowDamageTakenModifier);
                    break;
                }
                case Resistances.Arcane:
                {
                    num9 += (target.ArcaneDamageTakenBonus - target.ArcaneDamageTakenMalus);
                    break;
                }
            }
            num9 = target.ManaShieldLost(src, num9);
            if ((showMSG && f) && (src is Character))
            {
                int num10 = 4;
                Converter.ToBytes(target.Guid, target.tempBuff, ref num10);
                Converter.ToBytes(src.Guid, target.tempBuff, ref num10);
                Converter.ToBytes(this.Id, target.tempBuff, ref num10);
                Converter.ToBytes(num9, target.tempBuff, ref num10);
                Converter.ToBytes(2, target.tempBuff, ref num10);
                Converter.ToBytes((ushort) 0x100, target.tempBuff, ref num10);
                Converter.ToBytes(target.Guid, target.tempBuff, ref num10);
                (src as Character).Send(OpCodes.SMSG_SPELLNONMELEEDAMAGELOG, target.tempBuff, num10);
            }
            if (num9 > target.HitPoints)
            {
                num9 = target.HitPoints;
            }
            target.LooseHits(src, num9, false);
            if (target.SummonedBy != src)
            {
                target.OnGetHit(src, false, num9);
            }
            switch (src.Classe)
            {
                case Classes.Mage:
                {
                    if (num9 > 0)
                    {
                        if (src.HaveTalent(Talents.Impact) && (this.resistance == Resistances.Fire))
                        {
                            AuraEffect effect17 = (AuraEffect) src.GetTalentEffect(Talents.Impact);
                            num1 = Utility.Random(100);
                            if (num1 < effect17.S1)
                            {
                                AuraEffect effect18 = (AuraEffect) Abilities.abilities[effect17.AdditionalSpell];
                                Aura aura1 = new Aura();
                                aura1.ForceStun = true;
                                target.AddAura(src, effect18, aura1, true);
                            }
                        }
                        if (src.HaveTalent(Talents.ImprovedScorch) && (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0xb84]))
                        {
                            AuraEffect effect19 = (AuraEffect) src.GetTalentEffect(Talents.ImprovedScorch);
                            num1 = Utility.Random(100);
                            if (num1 < effect19.S1)
                            {
                                AuraEffect effect20 = (AuraEffect) Abilities.abilities[effect19.AdditionalSpell];
                                Aura aura2 = new Aura();
                                aura2.FireDamageTakenModifier = 1f + (((float) effect20.S1) / 100f);
                                target.AddAura(src, effect20, aura2, true);
                            }
                        }
                        int num11 = 0xd45a45;
                        if (src.HaveTalent(Talents.ArcaneConcentration))
                        {
                            AuraEffect effect21 = (AuraEffect) src.GetTalentEffect(Talents.ArcaneConcentration);
                            num1 = Utility.Random(100);
                            if (num1 < effect21.H)
                            {
                                src.AdditionnalStates.Add(num11);
                            }
                        }
                    }
                    return num9;
                }
                case Classes.Warlock:
                {
                    if ((AbilityClasses.abilityClasses[this.Id] == 0x13) && src.HaveTalent(Talents.Aftermath))
                    {
                        AuraEffect effect22 = (AuraEffect) src.GetTalentEffect(Talents.Aftermath);
                        if (Utility.Random(100) < effect22.H)
                        {
                            Aura aura3 = new Aura();
                            aura3.SpeedModifier = -((float) effect22.S1) / 100f;
                            aura3.OnRelease = new Aura.AuraReleaseDelegate(SpellTemplate.OnCastSpeedModEnd);
                            target.AddAura(src, effect22, aura3, true);
                            target.ChangeRunSpeed(target.RunSpeed);
                        }
                    }
                    if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x79d]) || (SpellTemplate.SpellEffects[0x166c] == SpellTemplate.SpellEffects[(int) this.Id]))
                    {
                        if (!src.HaveTalent(Talents.Pyroclasm))
                        {
                            return num9;
                        }
                        int num12 = 0;
                        if (src.TalentLevel(Talents.Pyroclasm) == 1)
                        {
                            num12 = 13;
                        }
                        else
                        {
                            num12 = 0x1a;
                        }
                        if (Utility.Random(100) < num12)
                        {
                            Aura aura4 = new Aura();
                            aura4.ForceStun = true;
                            target.AddAura((AuraEffect) Abilities.abilities[0x46ad], aura4, true);
                        }
                    }
                    return num9;
                }
            }
            return num9;
        }

        public int MakeManaDamage(Mobile src, Mobile target, SpellDamage sd)
        {
            int num1 = 1;
            int num2 = 1;
            switch (sd)
            {
                case SpellDamage.TypeS1:
                {
                    num1 = this.s1;
                    num2 = this.bonus1;
                    break;
                }
                case SpellDamage.TypeS2:
                {
                    num1 = this.s2;
                    num2 = this.bonus2;
                    break;
                }
            }
            float single1 = num1 + Utility.Random(1, num2);
            return this.MakeManaDamage(src, target, single1);
        }

        public int MakeManaDamage(Mobile src, Mobile target, float dmg)
        {
            return this.MakeManaDamage(src, target, dmg, true);
        }

        public int MakeManaDamage(Mobile src, Mobile target, float dmg, bool f)
        {
            float single3;
            if (target.Dead)
            {
                return 0;
            }
            if (this.ImmuneCheck(target, this))
            {
                return 0;
            }
            float single1 = (float) Utility.RandomDouble();
            float single2 = this.ResistCalculation(src, target);
            if (single1 < single2)
            {
                return 0;
            }
            Console.WriteLine("MAGIC HIT damage: " + dmg);
            single3 = single3 = ((float) ((5 * src.Level) - (target.Level * 5))) / 5f;
            float single4 = 0f;
            if ((src is Character) && (target is Character))
            {
                single4 = 95f;
            }
            else
            {
                if (single3 > 0f)
                {
                    single4 = 0x5f + ((int) single3);
                }
                else if (target.Level > (src.Level + 3))
                {
                    single4 = 0x5f - (((int) single3) * 15);
                }
                else
                {
                    single4 = 0x5f - (((int) single3) * 10);
                }
                if (single4 >= 99f)
                {
                    single4 = 99f;
                }
                if (single4 <= 1f)
                {
                    single4 = 1f;
                }
            }
            int num1 = Utility.Random(100);
            object[] objArray1 = new object[4] { "hit chance =", single4, " ", num1 } ;
            Console.WriteLine(string.Concat(objArray1));
            if (num1 >= single4)
            {
                return 0;
            }
            float single5 = 0f;
            float single6 = 1f;
            switch (this.resistance)
            {
                case Resistances.Armor:
                {
                    single5 = ((float) target.Armor) / 3000f;
                    break;
                }
                case Resistances.Light:
                {
                    single5 = ((float) target.ResistHoly) / 200f;
                    single6 = this.LightSpellModifier(src);
                    break;
                }
                case Resistances.Fire:
                {
                    single5 = ((float) target.ResistFire) / 200f;
                    single6 = this.FireSpellModifier(src);
                    break;
                }
                case Resistances.Nature:
                {
                    single5 = ((float) target.ResistNature) / 200f;
                    single6 = this.NatureSpellModifier(src);
                    break;
                }
                case Resistances.Frost:
                {
                    single5 = ((float) target.ResistFrost) / 200f;
                    single6 = this.FrostSpellModifier(src);
                    break;
                }
                case Resistances.Shadow:
                {
                    single5 = ((float) target.ResistShadow) / 200f;
                    single6 = this.ShadowSpellModifier(src);
                    break;
                }
                case Resistances.Arcane:
                {
                    single5 = ((float) target.ResistArcane) / 200f;
                    single6 = this.ArcaneSpellModifier(src);
                    break;
                }
            }
            if ((single5 == 0f) && (target is BaseCreature))
            {
                single5 = ((float) (target.Level * 3)) / 200f;
            }
            single5 = 1f - single5;
            dmg *= (single5 * single6);
            int num2 = 0;
            switch (this.resistance)
            {
                case Resistances.Light:
                {
                    num2 = target.DiminishHolyAbsordb((int) dmg);
                    num2 = target.DiminishAbsordbAll(num2);
                    break;
                }
                case Resistances.Fire:
                {
                    num2 = target.DiminishFireAbsordb((int) dmg);
                    num2 = target.DiminishAbsordbAll(num2);
                    break;
                }
                case Resistances.Nature:
                {
                    num2 = target.DiminishNatureAbsordb((int) dmg);
                    num2 = target.DiminishAbsordbAll(num2);
                    break;
                }
                case Resistances.Frost:
                {
                    num2 = target.DiminishFrostAbsordb((int) dmg);
                    num2 = target.DiminishAbsordbAll(num2);
                    break;
                }
                case Resistances.Shadow:
                {
                    num2 = target.DiminishShadowAbsordb((int) dmg);
                    num2 = target.DiminishAbsordbAll(num2);
                    break;
                }
                case Resistances.Arcane:
                {
                    num2 = target.DiminishArcaneAbsordb((int) dmg);
                    num2 = target.DiminishAbsordbAll(num2);
                    break;
                }
            }
            if (num2 > target.Mana)
            {
                num2 = target.Mana;
            }
            target.LooseMana(src, num2);
            return num2;
        }

        public bool MissAndRessistTest(Server.Object spellTarget, Mobile from)
        {
            float single1 = 0f;
            int num2 = this.HitChanceCalculation(from, spellTarget as Mobile);
            if (base.IsBinary())
            {
                single1 = this.ResistCalculation(from, spellTarget as Mobile);
            }
            else
            {
                single1 = 0f;
            }
            int num1 = Utility.Random(100);
            if (num1 > (num2 * (1f - single1)))
            {
                from.SpellStateMSG(0, from.cast.id, from, spellTarget as Mobile, 2);
                return true;
            }
            return false;
        }

        public float NatureSpellHealModifier(Mobile from)
        {
            float single1 = 1f;
            AuraEffect effect1 = null;
            if (from.HaveTalent(Talents.SpiritualHealing))
            {
                effect1 = (AuraEffect) from.GetTalentEffect(Talents.SpiritualHealing);
                single1 += (((float) effect1.s1) / 100f);
            }
            if (from.HaveTalent(Talents.ImprovedHolyLight))
            {
                effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedHolyLight);
                single1 += (((float) effect1.s1) / 100f);
            }
            if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x34e6]) && from.HaveTalent(Talents.ImprovedRenew))
            {
                effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedRenew);
                single1 += (((float) effect1.s1) / 100f);
            }
            return single1;
        }

        private float NatureSpellModifier(Mobile from)
        {
            float single1 = 1f;
            AuraEffect effect1 = null;
            if (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0xa2e])
            {
                if (from.HaveTalent(Talents.Concussion))
                {
                    effect1 = (AuraEffect) from.GetTalentEffect(Talents.Concussion);
                    return (single1 + (((float) effect1.s1) / 100f));
                }
                if ((SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x144]) && from.HaveTalent(Talents.ImprovedLightningShield))
                {
                    effect1 = (AuraEffect) from.GetTalentEffect(Talents.ImprovedLightningShield);
                    single1 += (((float) effect1.s1) / 100f);
                }
            }
            return single1;
        }

        public static void OnCastSpeedModEnd(Mobile m)
        {
            m.ChangeRunSpeed(m.RunSpeed);
        }

        public int Range(Mobile from)
        {
            int num1 = this.range;
            if (((from.Classe == Classes.Warlock) && (((this.resistance == Resistances.Fire) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x2ae])) || (SpellTemplate.SpellEffects[(int) this.Id] == SpellTemplate.SpellEffects[0x45d5]))) && from.HaveTalent(Talents.DestructiveReach))
            {
                AuraEffect effect1 = (AuraEffect) from.GetTalentEffect(Talents.DestructiveReach);
                float single1 = this.range;
                single1 += ((single1 * -((float) effect1.S1)) / 100f);
                num1 = (int) single1;
            }
            return num1;
        }

        public int ReflectCalculation(Mobile target)
        {
            int num1 = 0;
            switch (this.resistance)
            {
                case Resistances.Fire:
                {
                    num1 = target.ReflectFireChance;
                    break;
                }
                case Resistances.Frost:
                {
                    num1 = target.ReflectFrostChance;
                    break;
                }
                case Resistances.Shadow:
                {
                    num1 = target.ReflectShadowChance;
                    break;
                }
            }
            return (num1 + target.ReflectMagicChance);
        }

        public float ResistCalculation(Mobile src, Mobile target)
        {
            float single1 = 0f;
            switch (this.resistance)
            {
                case Resistances.Light:
                {
                    single1 = (float) ((((float) target.ResistHoly) / ((float) (src.Level * 5))) * 0.75);
                    break;
                }
                case Resistances.Fire:
                {
                    single1 = (float) ((((float) target.ResistFire) / ((float) (src.Level * 5))) * 0.75);
                    break;
                }
                case Resistances.Nature:
                {
                    single1 = (float) ((((float) target.ResistNature) / ((float) (src.Level * 5))) * 0.75);
                    break;
                }
                case Resistances.Frost:
                {
                    single1 = (float) ((((float) target.ResistFrost) / ((float) (src.Level * 5))) * 0.75);
                    break;
                }
                case Resistances.Shadow:
                {
                    single1 = (float) ((((float) target.ResistShadow) / ((float) (src.Level * 5))) * 0.75);
                    break;
                }
                case Resistances.Arcane:
                {
                    single1 = (float) ((((float) target.ResistArcane) / ((float) (src.Level * 5))) * 0.75);
                    if (src.HaveTalent(Talents.ArcaneFocus))
                    {
                        AuraEffect effect1 = (AuraEffect) src.GetTalentEffect(Talents.ArcaneFocus);
                        single1 -= effect1.S1;
                    }
                    break;
                }
            }
            if (single1 > 0.75)
            {
                single1 = 0.75f;
            }
            return single1;
        }

        public static void SetSpellEffects(int[] ids, GameObjectTargetSpellEffect st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        public static void SetSpellEffects(int[] ids, OnSelfItemSpellEffect st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        public static void SetSpellEffects(int[] ids, OnSelfSpellEffect st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        public static void SetSpellEffects(int[] ids, OnSelfSpellEffectMultiple st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        public static void SetSpellEffects(int[] ids, PermanentSpellEffect st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        public static void SetSpellEffects(int[] ids, SingleTargetSpellEffect st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        public static void SetSpellEffects(int[] ids, SingleTargetSpellEffectMultiple st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        public static void SetSpellEffects(int[] ids, TargetXYZSpellEffect st)
        {
            int[] numArray1 = ids;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                if (SpellTemplate.SpellEffects[num1] != null)
                {
                    Console.WriteLine("Spell id {0} already defined !!!", num1);
                }
                else
                {
                    SpellTemplate.SpellEffects[num1] = st;
                }
            }
        }

        private float ShadowSpellModifier(Mobile from)
        {
            return 1f;
        }

        public bool SkillCheck(Mobile.Casting cast, Mobile c)
        {
            int[] numArray1;
            object[] objArray1;
            if (!(c is Character))
            {
                c.SpellSuccess();
                return false;
            }
            if (this.resistance == Resistances.Arcane)
            {
                Skill skill1 = c.AllSkills[SpellTemplate.arcaneSkill.Id];
                if (skill1 != null)
                {
                    int num1 = skill1.Index;
                    int num2 = skill1.CurrentVal(c);
                    int num3 = skill1.IqSkillCheck(c, num2);
                    if (((c is Character) && (skill1.Current < skill1.Cap(c))) && c.SkillUp(skill1.Current, num2, 5))
                    {
                        skill1.Current = (ushort) (skill1.Current + 1);
                        numArray1 = new int[3] { num1, num1 + 1, num1 + 2 } ;
                        objArray1 = new object[4] { (int) SpellTemplate.arcaneSkill.Id, (short) SpellTemplate.arcaneSkill.CurrentVal(c), (short) SpellTemplate.arcaneSkill.Cap(c), 0 } ;
                        (c as Character).SendSmallUpdate(numArray1, objArray1);
                    }
                    if (num3 > 0x19)
                    {
                        c.SpellSuccess();
                    }
                    else
                    {
                        c.SpellFaillure(SpellFailedReason.Fizzled);
                    }
                }
            }
            else if (this.resistance == Resistances.Frost)
            {
                Skill skill2 = c.AllSkills[SpellTemplate.arcaneSkill.Id];
                if (skill2 != null)
                {
                    int num4 = skill2.Index;
                    int num5 = skill2.CurrentVal(c);
                    int num6 = skill2.IqSkillCheck(c, num5);
                    if (((c is Character) && (skill2.Current < skill2.Cap(c))) && c.SkillUp(skill2.Current, num5, 5))
                    {
                        skill2.Current = (ushort) (skill2.Current + 1);
                        numArray1 = new int[3] { num4, num4 + 1, num4 + 2 } ;
                        objArray1 = new object[4] { (int) SpellTemplate.arcaneSkill.Id, (short) SpellTemplate.arcaneSkill.CurrentVal(c), (short) SpellTemplate.arcaneSkill.Cap(c), 0 } ;
                        (c as Character).SendSmallUpdate(numArray1, objArray1);
                    }
                    numArray1 = new int[1] { 0x17 + c.ManaType } ;
                    objArray1 = new object[1] { c.Mana } ;
                    c.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    if (num6 > -25)
                    {
                        c.SpellSuccess();
                    }
                    else
                    {
                        c.SpellFaillure(SpellFailedReason.Fizzled);
                    }
                }
            }
            else if ((this.resistance == Resistances.Fire) && ((c as Character).Classe == Classes.Warlock))
            {
                Skill skill3 = c.AllSkills[(ushort) Destruction.SkillId];
                if (skill3 != null)
                {
                    int num7 = skill3.Index;
                    int num8 = skill3.CurrentVal(c);
                    int num9 = skill3.SpiritSkillCheck(c, num8);
                    if (((c is Character) && (skill3.Current < skill3.Cap(c))) && c.SkillUp(skill3.Current, num8, 5))
                    {
                        skill3.Current = (ushort) (skill3.Current + 1);
                        numArray1 = new int[3] { num7, num7 + 1, num7 + 2 } ;
                        objArray1 = new object[4] { (int) SpellTemplate.arcaneSkill.Id, (short) SpellTemplate.arcaneSkill.CurrentVal(c), (short) SpellTemplate.arcaneSkill.Cap(c), 0 } ;
                        (c as Character).SendSmallUpdate(numArray1, objArray1);
                    }
                    numArray1 = new int[1] { 0x17 + c.ManaType } ;
                    objArray1 = new object[1] { c.Mana } ;
                    c.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    if (num9 > -25)
                    {
                        c.SpellSuccess();
                    }
                    else
                    {
                        c.SpellFaillure(SpellFailedReason.Fizzled);
                    }
                }
            }
            else if (this.resistance == Resistances.Fire)
            {
                Skill skill4 = c.AllSkills[SpellTemplate.fireSkill.Id];
                if (skill4 != null)
                {
                    int num10 = skill4.Index;
                    int num11 = skill4.CurrentVal(c);
                    int num12 = skill4.IqSkillCheck(c, num11);
                    if (((c is Character) && (skill4.Current < skill4.Cap(c))) && c.SkillUp(skill4.Current, num11, 5))
                    {
                        skill4.Current = (ushort) (skill4.Current + 1);
                        numArray1 = new int[3] { num10, num10 + 1, num10 + 2 } ;
                        objArray1 = new object[4] { (int) SpellTemplate.arcaneSkill.Id, (short) SpellTemplate.arcaneSkill.CurrentVal(c), (short) SpellTemplate.arcaneSkill.Cap(c), 0 } ;
                        (c as Character).SendSmallUpdate(numArray1, objArray1);
                    }
                    numArray1 = new int[1] { 0x17 + c.ManaType } ;
                    objArray1 = new object[1] { c.Mana } ;
                    c.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    if (num12 > -25)
                    {
                        c.SpellSuccess();
                    }
                    else
                    {
                        c.SpellFaillure(SpellFailedReason.Fizzled);
                    }
                }
            }
            else if (this.resistance == Resistances.Shadow)
            {
                Skill skill5 = c.AllSkills[(ushort) Affliction.SkillId];
                if (skill5 != null)
                {
                    int num13 = skill5.Index;
                    int num14 = skill5.CurrentVal(c);
                    int num15 = skill5.SpiritSkillCheck(c, num14);
                    if (((c is Character) && (skill5.Current < skill5.Cap(c))) && c.SkillUp(skill5.Current, num14, 5))
                    {
                        skill5.Current = (ushort) (skill5.Current + 1);
                        numArray1 = new int[3] { num13, num13 + 1, num13 + 2 } ;
                        objArray1 = new object[4] { (int) SpellTemplate.arcaneSkill.Id, (short) SpellTemplate.arcaneSkill.CurrentVal(c), (short) SpellTemplate.arcaneSkill.Cap(c), 0 } ;
                        (c as Character).SendSmallUpdate(numArray1, objArray1);
                    }
                    numArray1 = new int[1] { 0x17 + c.ManaType } ;
                    objArray1 = new object[1] { c.Mana } ;
                    c.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    if (num15 > -25)
                    {
                        c.SpellSuccess();
                    }
                    else
                    {
                        c.SpellFaillure(SpellFailedReason.Fizzled);
                    }
                }
            }
            else
            {
                c.SpellSuccess();
            }
            return false;
        }

        public void SpellResult(int manacost, int id, Mobile c)
        {
            c.LooseMana(c, manacost);
        }

        public void SpellResult(int manacost, int id, Mobile c, Item i)
        {
            this.SpellResult(manacost, id, c);
        }

        public void SpellResult(int manacost, int id, Mobile c, Mobile t)
        {
            this.SpellResult(manacost, id, c);
        }


        // Properties
        public int AdditionalSpell
        {
            get
            {
                return this.additionalSpell;
            }
        }

        public int Bonus1
        {
            get
            {
                return this.bonus1;
            }
        }

        public int Bonus2
        {
            get
            {
                return this.bonus2;
            }
        }

        public DispelType Dispeltype
        {
            get
            {
                return this.dispeltype;
            }
        }

        public int H
        {
            get
            {
                return this.h;
            }
        }

        public int ManaCost
        {
            set
            {
                this.manaCost = value;
            }
        }

        public int Radius1
        {
            get
            {
                return this.radius1;
            }
        }

        public int Radius2
        {
            get
            {
                return this.radius2;
            }
        }

        public int Radius3
        {
            get
            {
                return this.radius3;
            }
        }

        public int RequieredLevel
        {
            get
            {
                return this.levelMin;
            }
        }

        public int S1
        {
            get
            {
                return this.s1;
            }
        }

        public int S2
        {
            get
            {
                return this.s2;
            }
        }

        public int S3
        {
            get
            {
                return this.s3;
            }
        }

        public int T1
        {
            get
            {
                return this.t1;
            }
        }

        public int T2
        {
            get
            {
                return this.t2;
            }
        }


        // Fields
        private int additionalSpell;
        private static ArcaneSkill arcaneSkill;
        private int bonus1;
        private int bonus2;
        private int castingTime;
        private int classe;
        private static Destruction destructionSkill;
        private DispelType dispeltype;
        private int duration;
        private static FireSkill fireSkill;
        private int h;
        private int levelMax;
        private int levelMin;
        private int manaCost;
        private int radius1;
        private int radius2;
        private int radius3;
        private byte range;
        private Resistances resistance;
        private int s1;
        private int s2;
        private int s3;
        public static Hashtable SpellEffects;
        private int t1;
        private int t2;
    }
}

