namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;

    public class SpellCasterAI : BaseAIType
    {
        // Methods
        public SpellCasterAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.LookingForPrey;
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if ((AIState != AIStates.Attack) && (AIState != AIStates.Fighting))
            {
                base.OnBeginFight(by);
                return AIStates.BeingAttacked;
            }
            return AIState;
        }

        public override void OnTick()
        {
            if (base.From.DebugSniffer != null)
            {
                base.From.DebugSniffer.SendMessage("PredatorAI::OnTick");
            }
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 1800f))
            {
                base.From.AIState = AIStates.LookingForPrey;
                base.From.AttackTarget = null;
            }
            else
            {
                if ((base.From.AttackTarget == null) || base.From.AttackTarget.Dead)
                {
                    ArrayList list1 = base.From.KnownObjects();
                    foreach (Server.Object obj1 in list1)
                    {
                        if (!(obj1 is Mobile))
                        {
                            continue;
                        }
                        Mobile mobile1 = obj1 as Mobile;
                        if ((((base.From.Distance(mobile1) < base.MaxViewDistance) && (Utility.Random4() == 0)) && (base.From.IsHostile(mobile1) && base.From.CanSee(mobile1))) && !mobile1.Dead)
                        {
                            base.From.AIState = AIStates.BeingAttacked;
                            base.From.AttackTarget = mobile1;
                            return;
                        }
                    }
                }
                AIStates states1 = base.AIState;
                if (states1 != AIStates.DoingNothing)
                {
                    if (states1 == AIStates.LookingForPrey)
                    {
                        base.From.Running = false;
                        if (Utility.Random16() < 1)
                        {
                            base.AIState = AIStates.Pause1;
                        }
                    }
                    else
                    {
                        switch (states1)
                        {
                            case AIStates.Pause1:
                            {
                                base.AIState = AIStates.Pause2;
                                return;
                            }
                            case AIStates.Pause2:
                            {
                                base.AIState = AIStates.Pause3;
                                return;
                            }
                            case AIStates.Pause3:
                            {
                                base.AIState = AIStates.LookingForPrey;
                                return;
                            }
                        }
                    }
                }
                else
                {
                    base.AIState = AIStates.LookingForPrey;
                    base.From.Running = false;
                }
            }
        }

    }
}

