namespace Server
{
    using System;

    public class OrcishSkill : Skill
    {
        // Methods
        public OrcishSkill()
        {
        }

        public OrcishSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x6d;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x6d;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x29d;
            }
        }

    }
}

