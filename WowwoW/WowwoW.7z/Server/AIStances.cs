namespace Server
{
    using System;

    public enum AIStances
    {
        // Fields
        Agressive = 2,
        Defensive = 1,
        Passive = 0
    }
}

