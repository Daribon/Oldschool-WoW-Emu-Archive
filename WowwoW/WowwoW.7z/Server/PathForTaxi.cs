namespace Server
{
    using System;
    using System.Collections;
    using System.Runtime.InteropServices;

    public class PathForTaxi
    {
        // Methods
        public PathForTaxi(int taxiPathId, Character ch)
        {
            this.mapIds = new MapIds[3];
            int num1 = ch.MapId;
            this.mapChange = 0;
            ArrayList list1 = new ArrayList();
            foreach (TaxiPathNode node1 in Taxi.TaxiPathNodesList)
            {
                if (node1.TaxiPath != taxiPathId)
                {
                    continue;
                }
                if (num1 != node1.MapId)
                {
                    this.mapIds[this.mapChange].index = node1.Index;
                    this.mapIds[this.mapChange].mapId = node1.MapId;
                    this.mapChange++;
                    num1 = node1.MapId;
                }
                list1.Add(node1);
            }
            int num2 = list1.Count;
            Coord[] coordArray1 = new Coord[num2];
            TaxiPathNode[] nodeArray1 = new TaxiPathNode[num2];
            foreach (TaxiPathNode node2 in list1)
            {
                nodeArray1[node2.Index] = node2;
            }
            for (int num3 = 0; num3 < num2; num3++)
            {
                if (num3 == 0)
                {
                    coordArray1[num3] = new Coord(nodeArray1[num3].X, nodeArray1[num3].Y, nodeArray1[num3].Z, null, null);
                }
                else
                {
                    coordArray1[num3] = new Coord(nodeArray1[num3].X, nodeArray1[num3].Y, nodeArray1[num3].Z, coordArray1[num3 - 1], null);
                }
            }
            this.t = new Trajet(coordArray1);
        }


        // Properties
        public Trajet T
        {
            get
            {
                return this.t;
            }
        }


        // Fields
        public int mapChange;
        public MapIds[] mapIds;
        private Trajet t;

        // Nested Types
        [StructLayout(LayoutKind.Sequential)]
        public struct MapIds
        {
            public int mapId;
            public int index;
        }
    }
}

