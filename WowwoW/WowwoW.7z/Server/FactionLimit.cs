namespace Server
{
    using System;

    public class FactionLimit
    {
        // Methods
        public FactionLimit(int faction, int reputation)
        {
            this._faction = faction;
            this._reputation = reputation;
        }


        // Properties
        public int Faction
        {
            get
            {
                return this._faction;
            }
        }

        public int Reputation
        {
            get
            {
                return this._reputation;
            }
        }


        // Fields
        private int _faction;
        private int _reputation;
    }
}

