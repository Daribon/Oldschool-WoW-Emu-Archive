namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class Mobile : Server.Object
    {
        // Methods
        static Mobile()
        {
            Mobile.onInitialiseTalent = new Hashtable();
            Mobile.aa = 1;
            Mobile.fa = 1;
            Mobile.viewingCone = 2.356194f;
            Mobile.xpNeeded = new int[0x3d];
            Mobile.mobXp = new int[0x3d];
            Mobile.reactions = new float[0x86, 0x86];
        }

        public Mobile() : base(Server.Object.GUID)
        {
            this.knownAbilities = new Hashtable();
            this.talentList = new Hashtable();
            this.nextAttackEffects = new ArrayList();
            this.size = 1f;
            this.str = 20;
            this.agility = 20;
            this.stamina = 20;
            this.iq = 20;
            this.spirit = 20;
            this.baseStr = 0f;
            this.baseAgility = 0f;
            this.baseStamina = 0f;
            this.baseIq = 0f;
            this.baseSpirit = 0f;
            this.speed = 8f;
            this.walkSpeed = 2.5f;
            this.runSpeed = 7f;
            this.swimSpeed = 7f;
            this.swimBackSpeed = 4.722222f;
            this.castingSpeed = 1f;
            this.allSkills = new Skills();
            this.minDamage = 1f;
            this.maxDamage = 1f;
            this.attackBoniiMin = 0;
            this.attackBoniiMax = 0;
            this.boundingRadius = 1.5f;
            this.combatReach = 1.5f;
            this.manaType = 0;
            this.viewRange = 20;
            this.visible = InvisibilityLevel.Visible;
            this.itemManaBonus = 0;
            this.itemHealthBonus = 0;
            this.deleted = false;
            this.lastHit = DateTime.Now;
            this.aura = new ArrayList();
            this.permanentAura = new ArrayList();
            this.SpecialForAuras = new Hashtable();
            this.cumulativeAuraEffects = new Hashtable();
            this.Triggers = new Hashtable();
            this.lastSeen = null;
            this.additionnalStates = new ArrayList();
            this.currs = 0;
            this.hitsUpdate = new byte[0x2f] { 
                0, 0x2d, 0xa9, 0, 1, 0, 0, 0, 0, 0, 0x94, 20, 0x21, 0, 0, 0, 
                0, 0, 6, 0, 0, 0x40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x23, 0, 0, 0
             } ;
            this.lastOffender = null;
            this.hitBuffer = new byte[0x41] { 
                0, 0x3f, 0x4a, 1, 6, 0, 0, 0, 0x9b, 0x36, 0x21, 0, 0, 0, 0, 0, 
                0x91, 20, 0x21, 0, 0, 0, 0, 0, 10, 0, 0, 0, 1, 0, 0, 0, 
                0, 0, 0, 0x20, 0x41, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 
                0, 0xe8, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0
             } ;
            this.lastHeartBeat = DateTime.Now;
            Server.Object.GUID++;
            if (this is Corps)
            {
                base.Guid += 0xe000a00000000000;
            }
            if (this is BaseCreature)
            {
                this.localTime = DateTime.Now.Ticks;
                this.moveVector = new MoveVector(this, this.X, this.Y, this.Z);
                this.aiType = AITypes.Beast;
                base.Guid += 0xf000a00000000000;
                this.movementTimer = new MovementTimer(this);
            }
            else
            {
                this.items = new Item[0x68];
            }
        }

        public Mobile(GenericReader gr)
        {
            this.knownAbilities = new Hashtable();
            this.talentList = new Hashtable();
            this.nextAttackEffects = new ArrayList();
            this.size = 1f;
            this.str = 20;
            this.agility = 20;
            this.stamina = 20;
            this.iq = 20;
            this.spirit = 20;
            this.baseStr = 0f;
            this.baseAgility = 0f;
            this.baseStamina = 0f;
            this.baseIq = 0f;
            this.baseSpirit = 0f;
            this.speed = 8f;
            this.walkSpeed = 2.5f;
            this.runSpeed = 7f;
            this.swimSpeed = 7f;
            this.swimBackSpeed = 4.722222f;
            this.castingSpeed = 1f;
            this.allSkills = new Skills();
            this.minDamage = 1f;
            this.maxDamage = 1f;
            this.attackBoniiMin = 0;
            this.attackBoniiMax = 0;
            this.boundingRadius = 1.5f;
            this.combatReach = 1.5f;
            this.manaType = 0;
            this.viewRange = 20;
            this.visible = InvisibilityLevel.Visible;
            this.itemManaBonus = 0;
            this.itemHealthBonus = 0;
            this.deleted = false;
            this.lastHit = DateTime.Now;
            this.aura = new ArrayList();
            this.permanentAura = new ArrayList();
            this.SpecialForAuras = new Hashtable();
            this.cumulativeAuraEffects = new Hashtable();
            this.Triggers = new Hashtable();
            this.lastSeen = null;
            this.additionnalStates = new ArrayList();
            this.currs = 0;
            this.hitsUpdate = new byte[0x2f] { 
                0, 0x2d, 0xa9, 0, 1, 0, 0, 0, 0, 0, 0x94, 20, 0x21, 0, 0, 0, 
                0, 0, 6, 0, 0, 0x40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x23, 0, 0, 0
             } ;
            this.lastOffender = null;
            this.hitBuffer = new byte[0x41] { 
                0, 0x3f, 0x4a, 1, 6, 0, 0, 0, 0x9b, 0x36, 0x21, 0, 0, 0, 0, 0, 
                0x91, 20, 0x21, 0, 0, 0, 0, 0, 10, 0, 0, 0, 1, 0, 0, 0, 
                0, 0, 0, 0x20, 0x41, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 
                0, 0xe8, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0
             } ;
            this.lastHeartBeat = DateTime.Now;
            this.Deserialize(gr);
        }

        public Mobile(float x, float y, float z, float orient) : base(Server.Object.GUID, x, y, z, orient)
        {
            this.knownAbilities = new Hashtable();
            this.talentList = new Hashtable();
            this.nextAttackEffects = new ArrayList();
            this.size = 1f;
            this.str = 20;
            this.agility = 20;
            this.stamina = 20;
            this.iq = 20;
            this.spirit = 20;
            this.baseStr = 0f;
            this.baseAgility = 0f;
            this.baseStamina = 0f;
            this.baseIq = 0f;
            this.baseSpirit = 0f;
            this.speed = 8f;
            this.walkSpeed = 2.5f;
            this.runSpeed = 7f;
            this.swimSpeed = 7f;
            this.swimBackSpeed = 4.722222f;
            this.castingSpeed = 1f;
            this.allSkills = new Skills();
            this.minDamage = 1f;
            this.maxDamage = 1f;
            this.attackBoniiMin = 0;
            this.attackBoniiMax = 0;
            this.boundingRadius = 1.5f;
            this.combatReach = 1.5f;
            this.manaType = 0;
            this.viewRange = 20;
            this.visible = InvisibilityLevel.Visible;
            this.itemManaBonus = 0;
            this.itemHealthBonus = 0;
            this.deleted = false;
            this.lastHit = DateTime.Now;
            this.aura = new ArrayList();
            this.permanentAura = new ArrayList();
            this.SpecialForAuras = new Hashtable();
            this.cumulativeAuraEffects = new Hashtable();
            this.Triggers = new Hashtable();
            this.lastSeen = null;
            this.additionnalStates = new ArrayList();
            this.currs = 0;
            this.hitsUpdate = new byte[0x2f] { 
                0, 0x2d, 0xa9, 0, 1, 0, 0, 0, 0, 0, 0x94, 20, 0x21, 0, 0, 0, 
                0, 0, 6, 0, 0, 0x40, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x23, 0, 0, 0
             } ;
            this.lastOffender = null;
            this.hitBuffer = new byte[0x41] { 
                0, 0x3f, 0x4a, 1, 6, 0, 0, 0, 0x9b, 0x36, 0x21, 0, 0, 0, 0, 0, 
                0x91, 20, 0x21, 0, 0, 0, 0, 0, 10, 0, 0, 0, 1, 0, 0, 0, 
                0, 0, 0, 0x20, 0x41, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 
                0, 0xe8, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0
             } ;
            this.lastHeartBeat = DateTime.Now;
            Server.Object.GUID++;
            if (!(this is Character))
            {
                base.Guid += 0xf000a00000000000;
                this.localTime = DateTime.Now.Ticks;
                this.movementTimer = new MovementTimer(this);
            }
            else
            {
                this.items = new Item[0x68];
            }
        }

        public Aura AddAura(AuraEffect ae, Aura a)
        {
            return this.AddAura(ae, a, false);
        }

        public Aura AddAura(AuraEffect ae, Aura a, bool offensive)
        {
            if (this.Dead)
            {
                return null;
            }
            if (offensive)
            {
                this.OnGetHit(this, false, 1);
            }
            if (this.aura.Count >= 50)
            {
                return null;
            }
            int num1 = -1;
            int num2 = 0;
            ArrayList list1 = new ArrayList();
            if (offensive || (a is DotAura))
            {
                list1.AddRange(new int[0x12] { 
                    0x20, 0x21, 0x22, 0x23, 0x24, 0x25, 0x26, 0x27, 40, 0x29, 0x2a, 0x2b, 0x2c, 0x2d, 0x2e, 0x2f, 
                    0x30, 0x31
                 } );
            }
            else
            {
                list1.AddRange(new int[0x20] { 
                    0, 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 
                    0x10, 0x11, 0x12, 0x13, 20, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1a, 0x1b, 0x1c, 0x1d, 30, 0x1f
                 } );
            }
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.ae == ae)
                {
                    num1 = num2;
                    break;
                }
                list1.Remove(timer1.num);
                num2++;
            }
            if (list1.Count == 0)
            {
                return null;
            }
            if (num1 == -1)
            {
                num1 = (int) list1[0];
            }
            else
            {
                int num3 = num1;
                num1 = (this.aura[num3] as AuraReleaseTimer).num;
                this.ReleaseAura(this.aura[num3] as AuraReleaseTimer);
            }
            if (ae != null)
            {
                AuraReleaseTimer timer2 = null;
                if (ae.Duration(this) == 0x100)
                {
                    timer2 = new AuraReleaseTimer(this, a, ae, num1, 0xfffffff);
                }
                else
                {
                    timer2 = new AuraReleaseTimer(this, a, ae, num1, ae.Duration(this));
                }
                this.aura.Add(timer2);
                int[] numArray1 = new int[5] { 0x2f + num1, 0x67 + (num1 >> 2), 0x71 + (num1 >> 2), 0x7b + (num1 >> 3), 130 } ;
                object[] objArray1 = new object[5] { (int) ae.Id, 0x1010101, 0, 0xdddddddd, 2 } ;
                this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                int num4 = 4;
                Converter.ToBytes((byte) num1, this.tempBuff, ref num4);
                if (ae.Duration(this) == 0x100)
                {
                    Converter.ToBytes(uint.MaxValue, this.tempBuff, ref num4);
                }
                else
                {
                    Converter.ToBytes(ae.Duration(this), this.tempBuff, ref num4);
                }
                this.ToAllPlayerNear(OpCodes.SMSG_UPDATE_AURA_DURATION, this.tempBuff, 9);
                if (this is Character)
                {
                    (this as Character).AdjustBonii();
                }
            }
            return a;
        }

        public Aura AddAura(Mobile from, AuraEffect ae, Aura a)
        {
            if (this != from)
            {
                this.OnGetHit(from, false, 1);
            }
            return this.AddAura(ae, a, false);
        }

        public Aura AddAura(Mobile from, AuraEffect ae, Aura a, bool offensive)
        {
            return this.AddAura(ae, a, offensive);
        }

        public void AddComboPoint(Mobile target)
        {
            this.comboPoints++;
            uint num1 = (uint) (target.Guid & 0xffffffff);
            uint num2 = (uint) ((target.Guid >> 0x20) & 0xffffffff);
            object[] objArray1 = new object[3] { num1, num2, this.comboPoints << 8 } ;
            this.SendSmallUpdate(new int[3] { 0x26a, 0x26b, 0x468 } , objArray1);
        }

        public virtual PermanentAura AddPermanentAura(AuraEffect ae, Aura a)
        {
            PermanentAura aura1 = new PermanentAura(a, ae.Id);
            this.permanentAura.Add(aura1);
            if (this is Character)
            {
                (this as Character).AdjustBonii();
            }
            return aura1;
        }

        public void AdjustDamage()
        {
            if (this.minDamage > 0f)
            {
                float single1 = ((float) (this.str * this.str)) / 25f;
                if (this.minDamage < single1)
                {
                    this.str = (int) Math.Sqrt((double) (this.minDamage * 25f));
                }
                this.minDamage -= (((float) (this.str * this.str)) / 25f);
                this.minDamage += 10f;
                this.maxDamage -= (((float) (this.str * this.str)) / 25f);
                this.maxDamage += 10f;
                if (this.minDamage < 0f)
                {
                    this.minDamage = 0f;
                }
                if (this.maxDamage < 0f)
                {
                    this.maxDamage = 0.1f;
                }
            }
        }

        public void AISpellAttack(int forceCastSpell)
        {
            if (this.knownAbilities.Count > 0)
            {
                SpellsTypes types1 = SpellsTypes.None;
                int num1 = 0;
                IDictionaryEnumerator enumerator1 = this.knownAbilities.GetEnumerator();
                while (enumerator1.MoveNext())
                {
                    this.cast.baseability = null;
                    this.cast.castingtime = 0;
                    this.cast.cool = 0;
                    this.cast.id = 0;
                    this.cast.manacost = 0;
                    this.cast.type = 0;
                    this.cast.duration = 0;
                    this.cast.radius = 0;
                    int num2 = (int) enumerator1.Key;
                    SpellsTypes types2 = (SpellsTypes) enumerator1.Value;
                    BaseAbility ability1 = Abilities.abilities[num2];
                    if (ability1 is SpellTemplate)
                    {
                        SpellTemplate template1 = (SpellTemplate) ability1;
                        this.cast.castingtime = template1.CastingTime(this);
                        this.cast.cool = template1.CoolDown(this);
                        this.cast.id = template1.Id;
                        this.cast.manacost = template1.GetManaCost(this);
                        this.cast.type = (ushort) types2;
                        this.cast.baseability = template1;
                        int num3 = template1.Radius1;
                        if (template1.Radius2 > num3)
                        {
                            num3 = template1.Radius2;
                        }
                        if (template1.Radius3 > num3)
                        {
                            num3 = template1.Radius3;
                        }
                        if (ability1 is AuraEffect)
                        {
                            this.cast.duration = (ability1 as AuraEffect).Duration(this);
                        }
                        else
                        {
                            this.cast.duration = 0;
                        }
                        this.cast.radius = (short) num3;
                    }
                    else
                    {
                        this.cast.castingtime = ability1.CastingTime(this);
                        this.cast.cool = ability1.CoolDown(this);
                        this.cast.id = ability1.Id;
                        this.cast.manacost = 0;
                        this.cast.type = (ushort) types2;
                        this.cast.baseability = ability1;
                        this.cast.duration = 0;
                        this.cast.radius = 0;
                    }
                    if ((types2 == SpellsTypes.Healing) && (this.HitPoints < (this.BaseHitPoints / 2)))
                    {
                        if (!(this.cast.baseability is SpellTemplate))
                        {
                            continue;
                        }
                        SpellTemplate template3 = (SpellTemplate) this.cast.baseability;
                        if (((this.cast.manacost > this.Mana) || (forceCastSpell <= 0)) || (num2 != forceCastSpell))
                        {
                            continue;
                        }
                        types1 = types2;
                        num1 = num2;
                        forceCastSpell = 0;
                        break;
                    }
                    if (types2 != SpellsTypes.Curse)
                    {
                        if (types2 == SpellsTypes.Defensive)
                        {
                            BaseAbility ability2 = Abilities.abilities[num2];
                            if (!(ability2 is AuraEffect))
                            {
                                continue;
                            }
                            AuraEffect effect1 = (AuraEffect) ability2;
                            bool flag1 = false;
                            foreach (AuraReleaseTimer timer1 in this.aura)
                            {
                                if (timer1.ae == effect1)
                                {
                                    flag1 = true;
                                    break;
                                }
                            }
                            if ((flag1 || (this.cast.manacost > this.Mana)) || ((forceCastSpell <= 0) || (num2 != forceCastSpell)))
                            {
                                continue;
                            }
                            types1 = types2;
                            num1 = num2;
                            forceCastSpell = 0;
                            break;
                        }
                        if (((types2 == SpellsTypes.Offensive) && (this.AttackTarget != null)) && !this.AttackTarget.Dead)
                        {
                            BaseAbility ability3 = Abilities.abilities[num2];
                            if (ability3 is SpellTemplate)
                            {
                                SpellTemplate template4 = (SpellTemplate) ability3;
                                if (((this.cast.manacost <= this.Mana) && (num1 == 0)) && ((forceCastSpell > 0) && (num2 == forceCastSpell)))
                                {
                                    types1 = types2;
                                    num1 = num2;
                                    forceCastSpell = 0;
                                    break;
                                }
                            }
                        }
                    }
                }
                if (num1 == 0)
                {
                    return;
                }
                SpellTemplate template2 = (SpellTemplate) Abilities.abilities[num1];
                switch (types1)
                {
                    case SpellsTypes.Offensive:
                    {
                        if (this.AttackTarget != null)
                        {
                            this.MoveTo(this.X + ((this.AttackTarget.X - this.X) * 0.02f), this.Y + ((this.AttackTarget.Y - this.Y) * 0.02f), this.AttackTarget.Z);
                            this.beingCasting = template2;
                            if (SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffect)
                            {
                                this.SingleTargetCastSpell(this.AttackTarget, this.cast.id, (ushort) 2);
                            }
                            else if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
                            {
                                this.CastOnSelf(false, this.cast.id, 0);
                            }
                            else
                            {
                                this.FakeCast(this.cast.id, this.AttackTarget, new WhenDone(this.SpellTakeEffect));
                            }
                        }
                        return;
                    }
                    case SpellsTypes.Defensive:
                    {
                        this.beingCasting = template2;
                        if (!(SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffect))
                        {
                            if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
                            {
                                this.CastOnSelf(false, this.cast.id, 0);
                            }
                            return;
                        }
                        this.SingleTargetCastSpell(this, this.cast.id, (ushort) 0x8000);
                        return;
                    }
                    case SpellsTypes.Healing:
                    {
                        this.beingCasting = template2;
                        if (!(SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffect))
                        {
                            if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
                            {
                                this.CastOnSelf(false, this.cast.id, 0);
                            }
                            return;
                        }
                        this.SingleTargetCastSpell(this, this.cast.id, (ushort) 0x8000);
                        return;
                    }
                }
            }
        }

        public bool AlreadyHaveAura(AuraEffect ae)
        {
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.ae == ae)
                {
                    return true;
                }
            }
            return false;
        }

        private void ApplyItemModifier(Item i)
        {
            if (i.ObjectClass == 2)
            {
                this.activeWeapon = i;
                this.attackSpeed = i.Delay;
                if (this.attackSpeed != 0f)
                {
                    return;
                }
                this.attackSpeed = 2000f;
            }
            else if ((i.ObjectClass == 4) && (i.SubClass == 6))
            {
                this.activeShield = i;
                this.block = i.Block;
            }
        }

        public float ArmorReductionCalculation(Mobile m)
        {
            return (((float) m.Armor) / ((float) ((m.Armor + 400) + (0x55 * this.level))));
        }

        public void AttackBonii(int min, int max)
        {
            this.attackBoniiMin = min;
            this.attackBoniiMax = max;
        }

        public void AttackeStateMSG(int degats, Mobile src, Mobile target, int amountBlocked)
        {
            int num1 = 4;
            if (degats <= 0)
            {
                Converter.ToBytes(0x22, this.tempBuff, ref num1);
            }
            else
            {
                Converter.ToBytes(0x22, this.tempBuff, ref num1);
            }
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(target.Guid, this.tempBuff, ref num1);
            if (degats < 0)
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            else
            {
                Converter.ToBytes(degats, this.tempBuff, ref num1);
            }
            Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            if (degats > 0)
            {
                Converter.ToBytes((float) degats, this.tempBuff, ref num1);
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            if (degats < 0)
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            else
            {
                Converter.ToBytes(degats, this.tempBuff, ref num1);
            }
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            if (degats >= 0)
            {
                Converter.ToBytes(1, this.tempBuff, ref num1);
            }
            else if (degats == -1)
            {
                Converter.ToBytes(2, this.tempBuff, ref num1);
            }
            else if (degats == -2)
            {
                Converter.ToBytes(9, this.tempBuff, ref num1);
            }
            else if (degats == -3)
            {
                Converter.ToBytes(4, this.tempBuff, ref num1);
            }
            else if ((degats == -4) || (amountBlocked > 0))
            {
                Converter.ToBytes(5, this.tempBuff, ref num1);
            }
            else if (degats == -5)
            {
                Converter.ToBytes(6, this.tempBuff, ref num1);
            }
            else if (degats == -6)
            {
                Converter.ToBytes(7, this.tempBuff, ref num1);
            }
            else if (degats == -7)
            {
                Converter.ToBytes(8, this.tempBuff, ref num1);
            }
            if (degats == 0)
            {
                Converter.ToBytes(uint.MaxValue, this.tempBuff, ref num1);
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_ATTACKERSTATEUPDATE, this.tempBuff, num1);
        }

        public virtual int AttackSwing(Mobile target)
        {
            return this.AttackSwing(target, false);
        }

        public virtual int AttackSwing(ulong target)
        {
            return 0;
        }

        public virtual int AttackSwing(Mobile target, bool pass)
        {
            if (this.ImmuneAttack)
            {
                this.lastAttack = AttackStatus.Immune;
                return 0;
            }
            int num1 = 0;
            int num2 = 0;
            int num3 = this.Hit(target, 0f, pass, ref num2, ref num1);
            int num4 = 4;
            if (num3 <= 0)
            {
                Converter.ToBytes(0x22, this.tempBuff, ref num4);
            }
            else
            {
                Converter.ToBytes(0x22, this.tempBuff, ref num4);
            }
            Converter.ToBytes(base.Guid, this.tempBuff, ref num4);
            Converter.ToBytes(target.Guid, this.tempBuff, ref num4);
            if (num3 < 0)
            {
                Converter.ToBytes(0, this.tempBuff, ref num4);
            }
            else
            {
                Converter.ToBytes(num3, this.tempBuff, ref num4);
            }
            Converter.ToBytes((byte) 1, this.tempBuff, ref num4);
            Converter.ToBytes(0, this.tempBuff, ref num4);
            if (num3 > 0)
            {
                Converter.ToBytes((float) num3, this.tempBuff, ref num4);
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num4);
            }
            if (num3 < 0)
            {
                Converter.ToBytes(0, this.tempBuff, ref num4);
            }
            else
            {
                Converter.ToBytes(num3, this.tempBuff, ref num4);
            }
            Converter.ToBytes(0, this.tempBuff, ref num4);
            Converter.ToBytes(0, this.tempBuff, ref num4);
            if (num3 >= 0)
            {
                Converter.ToBytes(1, this.tempBuff, ref num4);
            }
            else if (num3 == -1)
            {
                Converter.ToBytes(2, this.tempBuff, ref num4);
            }
            else if (num3 == -2)
            {
                Converter.ToBytes(9, this.tempBuff, ref num4);
            }
            else if (num3 == -3)
            {
                Converter.ToBytes(4, this.tempBuff, ref num4);
            }
            else if ((num3 == -4) || (num2 > 0))
            {
                Converter.ToBytes(5, this.tempBuff, ref num4);
            }
            else if (num3 == -5)
            {
                Converter.ToBytes(6, this.tempBuff, ref num4);
            }
            else if (num3 == -6)
            {
                Converter.ToBytes(7, this.tempBuff, ref num4);
            }
            else if (num3 == -7)
            {
                Converter.ToBytes(8, this.tempBuff, ref num4);
            }
            if (num3 == 0)
            {
                Converter.ToBytes(uint.MaxValue, this.tempBuff, ref num4);
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num4);
            }
            Converter.ToBytes(0, this.tempBuff, ref num4);
            Converter.ToBytes(0, this.tempBuff, ref num4);
            this.ToAllPlayerNear(OpCodes.SMSG_ATTACKERSTATEUPDATE, this.tempBuff, num4);
            target.LooseHits(this, num3, true);
            return num3;
        }

        public virtual void BeginCast(int spell, Server.Object target)
        {
            if ((target is Mobile) && (target as Mobile).ForceSilence)
            {
                this.SpellFaillure(SpellFailedReason.CanDoWhileSilenced);
            }
            else if ((this is Character) && this.CanCast())
            {
                this.SpellFaillure(SpellFailedReason.YouHaveToStandingToDoThat);
            }
            else
            {
                int num1 = 4;
                if (target is GameObject)
                {
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(target.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(spell, this.tempBuff, ref num1);
                    Converter.ToBytes(0x13880100, this.tempBuff, ref num1);
                    Converter.ToBytes(0x8000000, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
                }
                else
                {
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(target.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(spell, this.tempBuff, ref num1);
                    Converter.ToBytes(0x100, this.tempBuff, ref num1);
                    Converter.ToBytes(0, this.tempBuff, ref num1);
                    this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
                }
                byte[] buffer1 = new byte[0x2a] { 
                    0xd9, 0xdb, 0x74, 0, 0, 0, 0, 0, 0xd9, 0xdb, 0x74, 0, 0, 0, 0, 0, 
                    0x44, 3, 0, 0, 0, 1, 1, 0xd9, 0xdb, 0x74, 0, 0, 0, 0, 0, 0, 
                    2, 0, 0, 0, 0, 0, 0, 0, 0, 0
                 } ;
                num1 = 4;
                Converter.ToBytes(base.Guid, buffer1, ref num1);
                Converter.ToBytes(target.Guid, buffer1, ref num1);
                Converter.ToBytes(spell, buffer1, ref num1);
                this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, buffer1);
            }
        }

        public void BeginCombatWith(Mobile target)
        {
            if (this.combatTimer == null)
            {
                this.AttackTarget = target;
                this.Running = true;
                if (this.attackMode != 0)
                {
                    double num1 = (float) Math.Atan2((double) (this.AttackTarget.Y - this.Y), (double) (this.AttackTarget.X - this.X));
                    num1 += 3.1415926535897931;
                    this.MoveTo(this.AttackTarget.X + ((float) ((Math.Cos(num1) * (this.combatReach + this.AttackTarget.CombatReach)) * 1.5)), this.AttackTarget.Y + ((float) ((Math.Sin(num1) * (this.combatReach + this.AttackTarget.CombatReach)) * 1.5)), this.AttackTarget.Z);
                }
                this.ChooseAttackMode();
                this.combatTimer.OnTick();
            }
        }

        public static int BinaryNumInStrToInt(string str)
        {
            int num1 = 0;
            int num2 = str.Length;
            bool flag1 = false;
            for (int num3 = 0; num3 < num2; num3++)
            {
                if (str[num3] == '-')
                {
                    flag1 = true;
                }
                else
                {
                    int num4 = 1;
                    for (int num5 = 1; num5 <= (num2 - (num3 + 1)); num5++)
                    {
                        num4 *= 2;
                    }
                    num1 += ((str[num3] - '0') * num4);
                }
            }
            if (flag1)
            {
                num1 *= -1;
            }
            return num1;
        }

        public float BlockChanceCalculation(Mobile m, float dif)
        {
            float single1 = 0f;
            if (m.activeShield != null)
            {
                if (m is Character)
                {
                    single1 = ((((int) (m as Character).BaseBlockChance) + this.BlockBonus) - this.BlockMalus) - (((int) dif) / 2);
                }
                else
                {
                    single1 = ((5 + this.BlockBonus) - this.BlockMalus) - (((int) dif) / 2);
                }
            }
            if (m.HaveTalent(Talents.ShieldSpecialization))
            {
                AuraEffect effect1 = (AuraEffect) m.GetTalentEffect(Talents.ShieldSpecialization);
                single1 += effect1.S1;
            }
            return single1;
        }

        public bool CanCast()
        {
            int num1 = ((int) this.standState) & 0xffff;
            StandStates states1 = (StandStates) num1;
            if (states1 != StandStates.Standing)
            {
                this.SpellFaillure(SpellFailedReason.YouHaveToStandingToDoThat);
                return false;
            }
            return true;
        }

        public virtual void CancelCast()
        {
            this.SpellFaillure(SpellFailedReason.Interrupted);
            this.cast.id = 0;
            this.cast.baseability = null;
            this.cast.castingtime = 0;
            this.cast.cool = 0;
            this.cast.manacost = 0;
            this.cast.type = 0;
            if (this.spellCastTimer != null)
            {
                this.spellCastTimer.Stop();
            }
        }

        public void CancelPolymorph()
        {
            int[] numArray1 = new int[1] { 0x88 } ;
            object[] objArray1 = new object[1] { this.model } ;
            this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public virtual bool CanSee(Server.Object obj)
        {
            Mobile mobile1 = null;
            if (obj is Mobile)
            {
                mobile1 = (Mobile) obj;
            }
            if (!(mobile1 is Character) || !mobile1.Dead)
            {
                if ((mobile1 is Character) && !(mobile1 as Character).Player.Realylogged)
                {
                    return false;
                }
                if ((mobile1 != this) && (mobile1.Visible != InvisibilityLevel.Visible))
                {
                    if (mobile1.Visible == InvisibilityLevel.GM)
                    {
                        return false;
                    }
                    if (((mobile1.Visible == InvisibilityLevel.Lesser) && !this.CanSeeLesserInvisibility) && (!this.CanSeeMediumInvisibility && !this.CanSeeMediumInvisibility))
                    {
                        return false;
                    }
                    if (((mobile1.Visible == InvisibilityLevel.Medium) && !this.CanSeeMediumInvisibility) && !this.CanSeeMediumInvisibility)
                    {
                        return false;
                    }
                    if ((mobile1.Visible == InvisibilityLevel.Greater) && !this.CanSeeMediumInvisibility)
                    {
                        return false;
                    }
                }
                float single1 = base.Orientation + ((float) Math.Atan2((double) (mobile1.Y - this.Y), (double) (mobile1.X - this.X)));
                if (single1 > 3.1415926535897931)
                {
                    single1 -= 6.283185f;
                }
                else if (single1 < -3.1415926535897931)
                {
                    single1 += 6.283185f;
                }
                if ((single1 < Mobile.viewingCone) && (single1 > -Mobile.viewingCone))
                {
                    return true;
                }
            }
            return false;
        }

        public virtual void CastOnSelf(bool fromObject, int spell, ushort type)
        {
            if (this is Character)
            {
                (this as Character).StopAttacking();
                if (!fromObject && !this.cast.baseability.CheckSpell(this, this))
                {
                    return;
                }
            }
            if (fromObject || this.HaveSpell(spell))
            {
                this.spellTarget = this;
                this.targetedItem = null;
                if (this.cast.castingtime == 0)
                {
                    this.SpellStart();
                }
                else
                {
                    int num1 = 4;
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((ushort) 0x100, this.tempBuff, ref num1);
                    Converter.ToBytes((ushort) this.cast.castingtime, this.tempBuff, ref num1);
                    Converter.ToBytes(0, this.tempBuff, ref num1);
                    this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
                    this.spellCastTimer = new SpellCastTimer(new SpellStartRun(this.SpellStart), this.cast.castingtime);
                }
            }
        }

        public virtual void ChangeRunSpeed(float newspeed)
        {
            int num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(this.RunSpeed, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_FORCE_RUN_SPEED_CHANGE, this.tempBuff, num1);
        }

        public void ChannelEnd()
        {
            if (this.chan.channeling != 0)
            {
                AuraEffect effect1 = (AuraEffect) Abilities.abilities[this.chan.channeling];
                if (this.chan.channelingTarget is Mobile)
                {
                    (this.chan.channelingTarget as Mobile).ReleaseAura(effect1);
                }
                if (this is Character)
                {
                    byte[] buffer1 = new byte[0x10];
                    int num1 = 4;
                    Converter.ToBytes((ulong) 1, buffer1, ref num1);
                    (this as Character).Send(OpCodes.MSG_CHANNEL_UPDATE, buffer1, num1);
                    this.SpellFaillure(SpellFailedReason.Interrupted);
                }
                this.chan.crt.OnTick();
                this.chan.channeling = 0;
                this.chan.duration = 0;
                if (this.chan.channelingTarget is Mobile)
                {
                    (this.chan.channelingTarget as Mobile).channelTarget = false;
                }
                this.chan.channelingTarget = null;
            }
        }

        public bool ChannelEnd(int spell)
        {
            if ((this.chan.channeling == 0) || (spell != this.chan.channeling))
            {
                return false;
            }
            this.ChannelEnd();
            if (this.chan.channelingTarget is Mobile)
            {
                (this.chan.channelingTarget as Mobile).channelTarget = false;
            }
            return true;
        }

        public void ChannelObject(Server.Object m, int spell)
        {
            uint num1 = (uint) (m.Guid & 0xffffffff);
            uint num2 = (uint) ((m.Guid >> 0x20) & 0xffffffff);
            object[] objArray1 = new object[3] { num1, num2, spell } ;
            this.SendSmallUpdateToPlayerNearMe(new int[3] { 20, 0x15, 0x95 } , objArray1);
        }

        public void ChannelStart(Server.Object _target, int _spell, long _duration)
        {
            if (_spell != 0)
            {
                this.chan.channeling = _spell;
                this.chan.duration = _duration;
                this.chan.channelingTarget = _target;
            }
            if (this is Character)
            {
                byte[] buffer1 = new byte[0x10];
                int num1 = 4;
                Converter.ToBytes((uint) _spell, buffer1, ref num1);
                Converter.ToBytes((ulong) _duration, buffer1, ref num1);
                (this as Character).Send(OpCodes.MSG_CHANNEL_START, buffer1, num1);
            }
            if (_target is Mobile)
            {
                (_target as Mobile).channelTarget = true;
            }
            this.ChannelObject(_target, _spell);
            ChannelReleaseTimer timer1 = new ChannelReleaseTimer(this, _duration);
            timer1.Start();
            this.chan.crt = timer1;
        }

        public bool CharacterNear()
        {
            foreach (Character character1 in World.allConnectedChars)
            {
                if (base.Distance(character1) < 22500f)
                {
                    return true;
                }
            }
            return false;
        }

        public void ChooseAttackMode()
        {
            int num1;
            if (this.ForceFlee)
            {
                return;
            }
            if (this.ForceStun)
            {
                return;
            }
            if ((this.Dead || (this.AttackTarget == null)) || (this.AttackTarget.HitPoints <= 0))
            {
                this.AttackTarget = null;
                this.AIState = AIStates.DoingNothing;
                if (this.combatTimer != null)
                {
                    this.combatTimer.Stop();
                    this.combatTimer = null;
                }
                return;
            }
            if (this.knownAbilities.Count > 0)
            {
                SpellsTypes types1 = SpellsTypes.None;
                num1 = 0;
                IDictionaryEnumerator enumerator1 = this.knownAbilities.GetEnumerator();
                while (enumerator1.MoveNext())
                {
                    this.cast.baseability = null;
                    this.cast.castingtime = 0;
                    this.cast.cool = 0;
                    this.cast.id = 0;
                    this.cast.manacost = 0;
                    this.cast.type = 0;
                    this.cast.duration = 0;
                    this.cast.radius = 0;
                    int num2 = (int) enumerator1.Key;
                    SpellsTypes types2 = (SpellsTypes) enumerator1.Value;
                    BaseAbility ability1 = Abilities.abilities[num2];
                    if (ability1 is SpellTemplate)
                    {
                        SpellTemplate template1 = (SpellTemplate) ability1;
                        this.cast.castingtime = template1.CastingTime(this);
                        this.cast.cool = template1.CoolDown(this);
                        this.cast.id = template1.Id;
                        this.cast.manacost = template1.GetManaCost(this);
                        this.cast.type = (ushort) types2;
                        this.cast.baseability = template1;
                        int num3 = template1.Radius1;
                        if (template1.Radius2 > num3)
                        {
                            num3 = template1.Radius2;
                        }
                        if (template1.Radius3 > num3)
                        {
                            num3 = template1.Radius3;
                        }
                        if (ability1 is AuraEffect)
                        {
                            this.cast.duration = (ability1 as AuraEffect).Duration(this);
                        }
                        else
                        {
                            this.cast.duration = 0;
                        }
                        this.cast.radius = (short) num3;
                    }
                    else
                    {
                        this.cast.castingtime = ability1.CastingTime(this);
                        this.cast.cool = ability1.CoolDown(this);
                        this.cast.id = ability1.Id;
                        this.cast.manacost = 0;
                        this.cast.type = (ushort) types2;
                        this.cast.baseability = ability1;
                        this.cast.radius = 0;
                        this.cast.duration = 0;
                    }
                    if ((types2 == SpellsTypes.Healing) && (this.HitPoints < (this.BaseHitPoints / 2)))
                    {
                        if (!(this.cast.baseability is SpellTemplate))
                        {
                            continue;
                        }
                        SpellTemplate template3 = (SpellTemplate) this.cast.baseability;
                        if (this.cast.manacost > this.Mana)
                        {
                            continue;
                        }
                        types1 = types2;
                        num1 = num2;
                        break;
                    }
                    if (types2 != SpellsTypes.Curse)
                    {
                        if (types2 == SpellsTypes.Defensive)
                        {
                            BaseAbility ability2 = Abilities.abilities[num2];
                            if (!(ability2 is AuraEffect))
                            {
                                continue;
                            }
                            AuraEffect effect1 = (AuraEffect) ability2;
                            bool flag1 = false;
                            foreach (AuraReleaseTimer timer1 in this.aura)
                            {
                                if (timer1.ae == effect1)
                                {
                                    flag1 = true;
                                    break;
                                }
                            }
                            if (flag1 || (this.cast.manacost > this.Mana))
                            {
                                continue;
                            }
                            types1 = types2;
                            num1 = num2;
                            break;
                        }
                        if (((types2 == SpellsTypes.Offensive) && (this.AttackTarget != null)) && !this.AttackTarget.Dead)
                        {
                            BaseAbility ability3 = Abilities.abilities[num2];
                            if (ability3 is SpellTemplate)
                            {
                                SpellTemplate template4 = (SpellTemplate) ability3;
                                if ((this.cast.manacost <= this.Mana) && (num1 == 0))
                                {
                                    types1 = types2;
                                    num1 = num2;
                                    break;
                                }
                            }
                        }
                    }
                }
                if ((num1 != 0) && (this.cast.baseability is SpellTemplate))
                {
                    SpellTemplate template2 = (SpellTemplate) Abilities.abilities[num1];
                    switch (types1)
                    {
                        case SpellsTypes.Offensive:
                        {
                            if (this.AttackTarget == null)
                            {
                                goto Label_062E;
                            }
                            this.MoveTo(this.X + ((this.AttackTarget.X - this.X) * 0.02f), this.Y + ((this.AttackTarget.Y - this.Y) * 0.02f), this.AttackTarget.Z);
                            this.beingCasting = template2;
                            if (!(SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffect))
                            {
                                if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
                                {
                                    this.CastOnSelf(false, this.cast.id, 0);
                                }
                                else
                                {
                                    this.FakeCast(this.cast.id, this.AttackTarget, new WhenDone(this.SpellTakeEffect));
                                }
                                goto Label_0625;
                            }
                            this.SingleTargetCastSpell(this.AttackTarget, this.cast.id, (ushort) 2);
                            goto Label_0625;
                        }
                        case SpellsTypes.Defensive:
                        {
                            this.beingCasting = template2;
                            if (!(SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffect))
                            {
                                if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
                                {
                                    this.CastOnSelf(false, this.cast.id, 0);
                                }
                                goto Label_051D;
                            }
                            this.SingleTargetCastSpell(this, this.cast.id, (ushort) 0x8000);
                            goto Label_051D;
                        }
                        case SpellsTypes.Healing:
                        {
                            this.beingCasting = template2;
                            if (!(SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffect))
                            {
                                if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
                                {
                                    this.CastOnSelf(false, this.cast.id, 0);
                                }
                                else
                                {
                                    this.FakeCast(this.cast.id, this.AttackTarget, new WhenDone(this.SpellTakeEffect));
                                }
                                goto Label_0499;
                            }
                            this.SingleTargetCastSpell(this, this.cast.id, (ushort) 0x8000);
                            goto Label_0499;
                        }
                    }
                }
            }
            goto Label_062E;
        Label_0499:
            this.beingCasting = null;
            num1 = 0;
            goto Label_062E;
        Label_051D:
            this.beingCasting = null;
            num1 = 0;
            goto Label_062E;
        Label_0625:
            this.beingCasting = null;
            num1 = 0;
        Label_062E:
            this.attackMode = 0;
            this.combatTimer = new Server.Mobile.CombatTimer(this, this.AttackSpeed);
        }

        public virtual Item ChooseWeapon()
        {
            return Character.handToHand;
        }

        public virtual void CoolDownEnded()
        {
        }

        public void CooldownReset(ClassesOfSpells spellClass)
        {
            for (int num1 = 0; num1 < 0x7530; num1++)
            {
                if (((ClassesOfSpells) AbilityClasses.abilityClasses[num1]) == spellClass)
                {
                    byte[] buffer1 = new byte[0x18];
                    int num2 = 4;
                    Converter.ToBytes(num1, buffer1, ref num2);
                    Converter.ToBytes(base.Guid, buffer1, ref num2);
                    (this as Character).Send(OpCodes.SMSG_CLEAR_COOLDOWN, buffer1, num2);
                }
            }
        }

        public void CooldownReset(int spell)
        {
            byte[] buffer1 = new byte[0x18];
            int num1 = 4;
            Converter.ToBytes(spell, buffer1, ref num1);
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            (this as Character).Send(OpCodes.SMSG_CLEAR_COOLDOWN, buffer1, num1);
        }

        public float CriticalChanceCalculation(Item weapon, Mobile m)
        {
            float single1 = 5f;
            if (this is Character)
            {
                int num1 = weapon.GetSkillId();
                single1 = (this as Character).BaseCritChance;
                if (num1 != 0)
                {
                    Skill skill1 = this.AllSkills[(ushort) num1];
                    if (skill1 != null)
                    {
                        if (m is Character)
                        {
                            Skill skill2 = m.AllSkills[(ushort) DefenseSkill.SkillId];
                            single1 += (((float) (skill1.CurrentVal(this) - skill2.CurrentVal(m))) / 5f);
                        }
                        else
                        {
                            single1 += (((float) (skill1.CurrentVal(this) - (m.Level * 5))) / 5f);
                        }
                    }
                }
            }
            else
            {
                switch (this.Classe)
                {
                    case Classes.Warrior:
                    {
                        if (this.HaveTalent(Talents.AxeSpecialization) && (weapon.SubClass == 0))
                        {
                            AuraEffect effect1 = (AuraEffect) this.GetTalentEffect(Talents.AxeSpecialization);
                            single1 += effect1.S1;
                        }
                        if (this.HaveTalent(Talents.PolearmSpecialization) && (weapon.SubClass == 6))
                        {
                            AuraEffect effect2 = (AuraEffect) this.GetTalentEffect(Talents.PolearmSpecialization);
                            single1 += effect2.S1;
                        }
                        if (this.HaveTalent(Talents.Cruelty) && (weapon.ObjectClass == 2))
                        {
                            AuraEffect effect3 = (AuraEffect) this.GetTalentEffect(Talents.Cruelty);
                            single1 += effect3.S1;
                        }
                        break;
                    }
                }
                if (m is Character)
                {
                    Skill skill3 = m.AllSkills[(ushort) DefenseSkill.SkillId];
                    single1 += (((float) ((5 * this.Level) - skill3.CurrentVal(m))) / 5f);
                }
                else
                {
                    single1 += (((float) ((5 * this.Level) - (m.Level * 5))) / 5f);
                }
            }
            return (single1 + this.PhysicalCriticalBonus);
        }

        public float DamageAbsorbCombat(float deg)
        {
            deg = this.DiminishAbsorbPhysical((int) deg);
            deg = this.DiminishAbsorbAllDamage((int) deg);
            return deg;
        }

        public float DamageDoneCalculation(Mobile m, float dmgBonus, bool critical, Item weapon)
        {
            float single1 = (this.maxDamage - this.minDamage) * ((float) Utility.RandomDouble());
            int num1 = 0;
            num1 += this.AttackPower;
            switch (m.NpcType)
            {
                case 1:
                {
                    num1 += (this.AttackPowerBonusAgainsBeast - this.AttackPowerMalusAgainsBeast);
                    break;
                }
                case 3:
                {
                    num1 += (this.AttackPowerBonusAgainsDemons - this.AttackPowerMalusAgainsDemons);
                    break;
                }
                case 5:
                {
                    num1 += (this.AttackPowerBonusAgainsGiants - this.AttackPowerMalusAgainsGiants);
                    break;
                }
                case 6:
                {
                    num1 += (this.AttackPowerBonusAgainsUndead - this.AttackPowerMalusAgainsUndead);
                    break;
                }
            }
            single1 += (((float) num1) / 14f);
            single1 += (((float) (this.Str * this.Str)) / 100f);
            single1 += this.minDamage;
            single1 += this.MeleeDamageBonus;
            single1 -= this.MeleeDamageMalus;
            single1 += this.AllDamageDoneBonus;
            single1 -= this.AllDamageDoneMalus;
            single1 *= (1f - this.MeleePercentDamageMalus);
            single1 *= (1f + this.MeleePercentDamageBonus);
            int num2 = 0;
            if (this.Classe == Classes.Warrior)
            {
                if (this.HaveTalent(Talents.TwoHandedWeaponSpecialization) && (weapon.InventoryType == InventoryTypes.TwoHanded))
                {
                    AuraEffect effect1 = (AuraEffect) this.GetTalentEffect(Talents.TwoHandedWeaponSpecialization);
                    num2 += effect1.S1;
                }
                if (this.HaveTalent(Talents.OneHandedWeaponSpecialization) && (weapon.InventoryType == InventoryTypes.OneHand))
                {
                    AuraEffect effect2 = (AuraEffect) this.GetTalentEffect(Talents.OneHandedWeaponSpecialization);
                    num2 += effect2.S1;
                }
            }
            if (((this.SummonedBy != null) && (((this.Id == 0x747) || (this.Id == 0x744)) || (this.Id == 0x1a1))) && this.SummonedBy.HaveTalent(Talents.UnholyPower))
            {
                AuraEffect effect3 = (AuraEffect) this.SummonedBy.GetTalentEffect(Talents.UnholyPower);
                num2 = effect3.S1;
            }
            single1 *= (1f + (((float) num2) / 100f));
            single1 *= this.AllDamageDoneModifier;
            if (this.SummonedBy != null)
            {
                single1 += (this.SummonedBy.PetDamageBonus - this.SummonedBy.PetDamageMalus);
            }
            switch (m.NpcType)
            {
                case 1:
                {
                    single1 += this.MeleeDamageDoneAgainsBeastBonus;
                    break;
                }
                case 2:
                {
                    single1 += this.MeleeDamageDoneAgainsDragonsBonus;
                    break;
                }
                case 3:
                {
                    single1 += this.MeleeDamageDoneAgainsDemonsBonus;
                    break;
                }
                case 4:
                {
                    single1 += this.MeleeDamageDoneAgainsElementalsBonus;
                    break;
                }
                case 5:
                {
                    single1 += this.MeleeDamageDoneAgainsGiantsBonus;
                    break;
                }
                case 6:
                {
                    single1 += this.MeleeDamageDoneAgainsUndeadBonus;
                    break;
                }
            }
            if (critical)
            {
                float single2 = 0f;
                int num3 = 0;
                single2 = ((float) (num3 + 100)) / 100f;
                single1 *= (1f + single2);
            }
            return (single1 + dmgBonus);
        }

        public float DamageTakenCalculation(Mobile m, float deg)
        {
            deg += (((m.DamageTakenBonus - m.DamageTakenMalus) + m.MeleeDamageTakenBonus) - m.MeleeDamageTakenMalus);
            deg += (m.PhysicalDamageTakenBonus - m.PhysicalDamageTakenMalus);
            deg *= m.DamageTakenModifier;
            deg *= ((1f + (m.MeleePercentDamageTakenIncrease / 100f)) - (m.MeleePercentDamageTakenReduction / 100f));
            return deg;
        }

        public override void Delete()
        {
            this.deleted = true;
            if (this.decay != null)
            {
                this.decay.Stop();
            }
            if (this.movementTimer != null)
            {
                this.movementTimer.Stop();
            }
            if (this.spellCastTimer != null)
            {
                this.spellCastTimer.Stop();
            }
            if (this.onReachTimer != null)
            {
                this.onReachTimer.Stop();
            }
            if (this.combatTimer != null)
            {
                this.combatTimer.Stop();
            }
        }

        public override void Deserialize(GenericReader gr)
        {
            int num1 = gr.ReadInt();
            gr.ReadInt64();
            base.SpawnerLink = null;
            int num2 = 0;
            int num3 = 0;
            num2 = gr.ReadInt();
            num3 = gr.ReadInt();
            this.name = gr.ReadString();
            if (num1 > 0)
            {
                this.classe = (Classes) gr.ReadInt();
            }
            this.talent = gr.ReadInt();
            this.Level = gr.ReadInt();
            this.model = gr.ReadInt();
            this.exp = (uint) gr.ReadInt();
            this.guildId = (uint) gr.ReadInt();
            this.petLevel = (uint) gr.ReadInt();
            this.petCreatureFamily = (uint) gr.ReadInt();
            this.petDisplayId = (uint) gr.ReadInt();
            this.speed = gr.ReadFloat();
            this.size = gr.ReadFloat();
            this.faction = (Factions) gr.ReadInt();
            this.str = gr.ReadInt();
            this.agility = gr.ReadInt();
            this.stamina = gr.ReadInt();
            this.iq = gr.ReadInt();
            this.spirit = gr.ReadInt();
            this.baseStr = gr.ReadFloat();
            this.baseAgility = gr.ReadFloat();
            this.baseStamina = gr.ReadFloat();
            this.baseIq = gr.ReadFloat();
            this.baseSpirit = gr.ReadFloat();
            this.walkSpeed = gr.ReadFloat();
            if (this.walkSpeed == 0f)
            {
                this.walkSpeed = 4.7777f;
            }
            this.runSpeed = gr.ReadFloat();
            if (this.runSpeed == 0f)
            {
                this.runSpeed = 7f;
            }
            this.swimSpeed = gr.ReadFloat();
            if (this.swimSpeed == 0f)
            {
                this.swimSpeed = 4.72f;
            }
            this.swimBackSpeed = gr.ReadFloat();
            if (this.swimBackSpeed == 0f)
            {
                this.swimBackSpeed = 2.5f;
            }
            this.hitPoints = gr.ReadInt();
            this.mana = gr.ReadInt();
            this.energy = gr.ReadInt();
            this.rage = gr.ReadInt();
            this.focus = gr.ReadInt();
            this.baseHitPoints = gr.ReadInt();
            this.baseMana = gr.ReadInt();
            this.baseEnergy = gr.ReadInt();
            this.baseRage = gr.ReadInt();
            this.baseFocus = gr.ReadInt();
            this.block = gr.ReadInt();
            this.armor = gr.ReadInt();
            this.resistHoly = gr.ReadInt();
            this.resistFire = gr.ReadInt();
            this.resistNature = gr.ReadInt();
            this.resistFrost = gr.ReadInt();
            this.resistShadow = gr.ReadInt();
            this.resistArcane = gr.ReadInt();
            int num4 = gr.ReadInt();
            for (int num5 = 0; num5 < num4; num5++)
            {
                ushort num6 = (ushort) gr.ReadShort();
                this.allSkills[num6] = Skill.Deserialize(gr, num5);
            }
            int num7 = gr.ReadInt();
            for (int num8 = 0; num8 < num7; num8++)
            {
                ushort num9 = (ushort) gr.ReadShort();
                byte num10 = gr.ReadByte();
                this.knownAbilities[(int) num9] = num10;
            }
            int num11 = gr.ReadInt();
            for (int num12 = 0; num12 < num11; num12++)
            {
                int num13 = gr.ReadInt();
                int num14 = gr.ReadInt();
                this.talentList[num13] = num14;
            }
            if (gr.ReadInt() != 0)
            {
                this.freeze = true;
            }
            int num15 = gr.ReadInt();
            for (int num16 = 0; num16 < num15; num16++)
            {
                int num17 = gr.ReadInt();
                if (num17 == 1)
                {
                    this.items[num16] = Item.Load(gr);
                }
                else
                {
                    this.items[num16] = null;
                }
            }
            if (gr.ReadInt() != 0)
            {
                this.movementChange = true;
            }
            this.manaType = gr.ReadInt();
            this.professions = gr.ReadByte();
            this.standState = (StandStates) gr.ReadInt();
            base.Deserialize(gr);
            this.moveVector = new MoveVector(this, this.X, this.Y, this.Z);
            if (num2 != 0)
            {
                MobileList.TempSummon[base.Guid] = this;
            }
            if (num3 != 0)
            {
                MobileList.TempSummon[base.Guid] = this;
            }
        }

        public int Difficulty(int sk, int vs)
        {
            int num1 = vs - sk;
            if (num1 > 15)
            {
                num1 = 15;
            }
            if (num1 < -35)
            {
                return -1;
            }
            return (0x33 - (0x23 + num1));
        }

        public int DiminishAbsorbAllDamage(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.AllDamageAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.AllDamageAbsorb > amount)
                {
                    timer1.aura.AllDamageAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.AllDamageAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishAbsorbPhysical(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.PhysicalAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.PhysicalAbsorb > amount)
                {
                    timer1.aura.PhysicalAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.PhysicalAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishAbsordbAll(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.AbsorbAllMagic <= 0)
                {
                    continue;
                }
                if (timer1.aura.AbsorbAllMagic > amount)
                {
                    timer1.aura.AbsorbAllMagic -= amount;
                    return 0;
                }
                amount -= timer1.aura.AbsorbAllMagic;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishArcaneAbsordb(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.ArcaneAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.ArcaneAbsorb > amount)
                {
                    timer1.aura.ArcaneAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.ArcaneAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishFireAbsordb(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.FireAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.FireAbsorb > amount)
                {
                    timer1.aura.FireAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.FireAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishFrostAbsordb(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.FrostAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.FrostAbsorb > amount)
                {
                    timer1.aura.FrostAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.FrostAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishHolyAbsordb(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.HolyAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.HolyAbsorb > amount)
                {
                    timer1.aura.HolyAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.HolyAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishNatureAbsordb(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.NatureAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.NatureAbsorb > amount)
                {
                    timer1.aura.NatureAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.NatureAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public int DiminishShadowAbsordb(int amount)
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (timer1.aura.ShadowAbsorb <= 0)
                {
                    continue;
                }
                if (timer1.aura.ShadowAbsorb > amount)
                {
                    timer1.aura.ShadowAbsorb -= amount;
                    return 0;
                }
                amount -= timer1.aura.ShadowAbsorb;
                list1.Add(timer1);
            }
            foreach (AuraReleaseTimer timer2 in list1)
            {
                this.ReleaseAura(timer2);
            }
            return amount;
        }

        public float DodgeChanceCalculation(Mobile m, float dif)
        {
            float single1 = 0f;
            if (m is Character)
            {
                m.SkillUpDefense();
                return (float) (((((int) (m as Character).BaseDodgeChance) + this.DodgeBonus) - this.DodgeMalus) - (((int) dif) / 2));
            }
            return (((5 + this.DodgeBonus) - this.DodgeMalus) - (((int) dif) / 2));
        }

        public virtual uint DynFlags(Mobile m)
        {
            uint num1 = 0;
            if ((this.Freeze || this.ForceRoot) || this.ForceStun)
            {
                num1 |= 4;
            }
            if ((this.SkinLoot != null) && this.Dead)
            {
                num1 |= 0x4000000;
            }
            if (m is Character)
            {
                Character character1 = m as Character;
                if (character1.Player.AccessLevel != AccessLevels.PlayerLevel)
                {
                    num1 |= 0x10;
                }
                object obj1 = character1.CumulativeAuraEffects[EffectTypes.FindCreature];
                if ((obj1 != null) && (((TrackableCreatures) obj1) == ((TrackableCreatures) this.NpcType)))
                {
                    num1 |= 2;
                }
            }
            return num1;
        }

        public void EndCombat(Mobile m)
        {
            this.NextAttackEffects.Clear();
            if (this.AttackTarget != null)
            {
                this.AttackTarget = null;
            }
            if (this.combatTimer != null)
            {
                this.combatTimer.Stop();
                this.combatTimer = null;
            }
            this.Running = false;
            if (!(this is Character))
            {
                this.AIState = AIStates.ReturnHome;
            }
            if (m.AttackTarget != null)
            {
                m.AttackTarget = null;
            }
            if (m.combatTimer != null)
            {
                m.combatTimer.Stop();
                m.combatTimer = null;
            }
            m.Running = false;
            if (!(m is Character))
            {
                m.AIState = AIStates.ReturnHome;
            }
        }

        public void Equip(Item i)
        {
            this.items = new Item[1] { i } ;
            this.ApplyItemModifier(i);
        }

        public void Equip(Item i, Item j)
        {
            this.items = new Item[2] { i, j } ;
            this.ApplyItemModifier(i);
            this.ApplyItemModifier(j);
        }

        public void Equip(Item i, Item j, Item k)
        {
            this.items = new Item[3] { i, j, k } ;
            this.ApplyItemModifier(i);
            this.ApplyItemModifier(j);
            this.ApplyItemModifier(k);
        }

        public static bool FaceToBehind(Mobile _char, Mobile _creature)
        {
            float single1 = 0.7853982f;
            float single2 = _char.Orientation;
            float single3 = _creature.Orientation;
            float single4 = single2 + single1;
            float single5 = single2 - single1;
            if ((single4 >= single3) && (single3 >= single5))
            {
                return (Mobile.GetDirection(_char, _creature) == Server.Mobile.Pos.Behind);
            }
            return false;
        }

        public virtual void FaitFace(Mobile from)
        {
            this.UpdateXYZ();
            base.Orientation = (float) Math.Atan2((double) (from.Y - this.Y), (double) (from.X - this.X));
            base.Orientation += 3.141593f;
            float single1 = (float) (Math.Cos((double) base.Orientation) / 5);
            float single2 = (float) (Math.Sin((double) base.Orientation) / 5);
            float single3 = this.X - single1;
            float single4 = this.Y - single2;
            byte[] buffer1 = new byte[0x35];
            single1 *= single1;
            single2 *= single2;
            single1 = (float) Math.Sqrt((double) (single1 + single2));
            int num1 = (int) (single1 / (this.Speed / 1000f));
            int num2 = 4;
            uint num3 = (uint) (DateTime.Now.Ticks - this.localTime);
            Converter.ToBytes(base.Guid, buffer1, ref num2);
            Converter.ToBytes(this.X, buffer1, ref num2);
            Converter.ToBytes(this.Y, buffer1, ref num2);
            Converter.ToBytes(this.Z, buffer1, ref num2);
            Converter.ToBytes(num3, buffer1, ref num2);
            Converter.ToBytes((byte) 0, buffer1, ref num2);
            Converter.ToBytes(0, buffer1, ref num2);
            Converter.ToBytes(num1, buffer1, ref num2);
            Converter.ToBytes(1, buffer1, ref num2);
            Converter.ToBytes(single3, buffer1, ref num2);
            Converter.ToBytes(single4, buffer1, ref num2);
            Converter.ToBytes(this.Z, buffer1, ref num2);
            this.ToAllPlayerNear(OpCodes.SMSG_MONSTER_MOVE, buffer1, num2);
        }

        public void FakeCast(int spell, Mobile target)
        {
            this.FakeCast(spell, target, null);
        }

        public void FakeCast(int spell, Mobile target, WhenDone trigger)
        {
            byte[] buffer1 = new byte[0x20] { 
                0, 0, 0, 0, 0xd9, 0xdb, 0x74, 0, 0, 0, 0, 0, 0xd9, 0xdb, 0x74, 0, 
                0, 0, 0, 0, 0x44, 3, 0, 0, 2, 0, 0, 0, 0, 0, 0, 0
             } ;
            int num1 = 4;
            Converter.ToBytes(target.Guid, buffer1, ref num1);
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            Converter.ToBytes(spell, buffer1, ref num1);
            Converter.ToBytes(0x100, buffer1, ref num1);
            Converter.ToBytes(0, buffer1, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, buffer1, buffer1.Length);
            new CastFakeSpellTimer(this, target, spell, Abilities.abilities[spell].CastingTime(this), trigger);
        }

        public void FakeCast(int spell, Mobile target, float x, float y, float z)
        {
            this.FakeCast(spell, target, x, y, z, null);
        }

        public void FakeCast(int spell, Mobile target, float x, float y, float z, WhenDone trigger)
        {
            ushort num2;
            float single1;
            int num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(spell, this.tempBuff, ref num1);
            BaseAbility ability1 = Abilities.abilities[spell];
            Converter.ToBytes((ushort) 0x100, this.tempBuff, ref num1);
            Converter.ToBytes(this.cast.castingtime, this.tempBuff, ref num1);
            this.cast.type = (ushort) (num2 = 0x40);
            Converter.ToBytes(num2, this.tempBuff, ref num1);
            this.spellTargetX = single1 = x;
            Converter.ToBytes(single1, this.tempBuff, ref num1);
            this.spellTargetY = single1 = y;
            Converter.ToBytes(single1, this.tempBuff, ref num1);
            this.spellTargetZ = single1 = z;
            Converter.ToBytes(single1, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
            new CastFakeSpellTimer(this, target, spell, this.cast.castingtime, trigger);
        }

        public void FakeCastSpe(int spell, Mobile target, WhenDone trigger)
        {
            int num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(spell, this.tempBuff, ref num1);
            Converter.ToBytes(2, this.tempBuff, ref num1);
            Converter.ToBytes(0x20000, this.tempBuff, ref num1);
            Converter.ToBytes(target.Guid, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
            new CastFakeSpellTimerSpe(this, target, spell, Abilities.abilities[spell].CastingTime(this), trigger);
        }

        public void FeatherFallOn()
        {
            int num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_MOVE_FEATHER_FALL, this.tempBuff, num1);
        }

        public Item FindItemById(int id)
        {
            Item[] itemArray1;
            int num1;
            if (this.sells != null)
            {
                itemArray1 = this.sells;
                for (num1 = 0; num1 < itemArray1.Length; num1++)
                {
                    Item item1 = itemArray1[num1];
                    if ((item1 != null) && (item1.Id == id))
                    {
                        return item1;
                    }
                }
            }
            if ((base.Treasure != null) && (base.Treasure.Length > 0))
            {
                itemArray1 = base.Treasure;
                for (num1 = 0; num1 < itemArray1.Length; num1++)
                {
                    Item item2 = itemArray1[num1];
                    if ((item2 != null) && (item2.Id == id))
                    {
                        return item2;
                    }
                }
            }
            return null;
        }

        public virtual Server.Object FindObjectByGuid(ulong guid)
        {
            return World.FindMobileByGUID(guid);
        }

        public void ForcePosition(float x, float y, float z, float orientation)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            base.Orientation = orientation;
            this.moveVector = new MoveVector(this, x, y, z, x - 1f, y - 1f, z - 1f);
            this.UpdateXYZ();
        }

        public void GainHealth(Mobile from, int hp)
        {
            if (!this.Dead)
            {
                this.hitPoints += hp;
                if (this.hitPoints > this.BaseHitPoints)
                {
                    this.hitPoints = this.BaseHitPoints;
                }
                this.HitPointsUpdate(this);
            }
        }

        public void GainMana(Mobile from, int a)
        {
            if (!this.Dead)
            {
                this.Mana += a;
                if (this.Mana > this.BaseMana)
                {
                    this.Mana = this.BaseMana;
                }
                this.ManaUpdate(this);
            }
        }

        public void GenerateLoot()
        {
            if (this.loots != null)
            {
                ArrayList list1 = new ArrayList();
                BaseTreasure[] treasureArray1 = this.loots;
                for (int num1 = 0; num1 < treasureArray1.Length; num1++)
                {
                    BaseTreasure treasure1 = treasureArray1[num1];
                    if (treasure1.IsDrop())
                    {
                        ArrayList list2 = treasure1.RandomDrop(ref this.lootMoney);
                        if (list2 != null)
                        {
                            list1.AddRange(list2);
                        }
                    }
                }
                base.Treasure = (Item[]) list1.ToArray(typeof(Item));
            }
            Console.WriteLine("");
        }

        public static Server.Mobile.Pos GetDirection(Mobile from, Mobile to)
        {
            if ((to != null) && (from != null))
            {
                float single1 = to.X - from.X;
                float single2 = to.Y - from.Y;
                float single3 = (float) Math.Atan2((double) single2, (double) single1);
                float single4 = from.Orientation;
                double num1 = Math.Cos((double) single4) - Math.Cos((double) single3);
                double num2 = Math.Sin((double) single4) - Math.Sin((double) single3);
                num1 *= num1;
                num2 *= num2;
                num1 += num2;
                if (num1 < 0.77)
                {
                    return Server.Mobile.Pos.Front;
                }
            }
            return Server.Mobile.Pos.Behind;
        }

        public static float GetReaction(Factions from, Factions to)
        {
            return Mobile.reactions[(int) from, (int) to];
        }

        public BaseAbility GetTalentEffect(Talents t)
        {
            TalentDescription description1 = (TalentDescription) TalentDescription.all[(int) t];
            return Abilities.abilities[description1.AuraFXId((int) this.talentList[(int) t])];
        }

        public virtual bool HaveSkill(int id)
        {
            return true;
        }

        public virtual bool HaveSpell(BaseAbility ba)
        {
            if ((ba != null) && (this.knownAbilities[ba.Id] != null))
            {
                return true;
            }
            return false;
        }

        public virtual bool HaveSpell(int id)
        {
            if ((id != 0) && (this.knownAbilities[id] != null))
            {
                return true;
            }
            return false;
        }

        public bool HaveTalent(Talents t)
        {
            if (this.talentList[(int) t] != null)
            {
                return true;
            }
            return false;
        }

        public virtual int Hit(Mobile m)
        {
            int num1 = 0;
            int num2 = 0;
            return this.Hit(m, 0f, false, ref num1, ref num2);
        }

        public virtual int Hit(Mobile m, bool pass)
        {
            int num1 = 0;
            int num2 = 0;
            return this.Hit(m, 0f, pass, ref num1, ref num2);
        }

        public virtual int Hit(Mobile m, float dmgBonus)
        {
            int num1 = 0;
            int num2 = 0;
            return this.Hit(m, dmgBonus, false, ref num1, ref num2);
        }

        public virtual int Hit(Mobile m, ref int amountBlocked, ref int amountAbsorbed)
        {
            return this.Hit(m, 0f, false, ref amountBlocked, ref amountAbsorbed);
        }

        public virtual int Hit(Mobile m, float dmgBonus, bool pass, ref int amountBlocked, ref int amountAbsorbed)
        {
            Item item1 = this.activeWeapon;
            float single1 = this.CriticalChanceCalculation(item1, m);
            float single2 = this.SkillDifCalculation(item1, m);
            float single3 = this.HitChanceCalculation(item1, m, single2);
            bool flag1 = false;
            int num1 = Utility.Random(100);
            bool flag2 = true;
            if ((((int) single1) >= num1) || flag2)
            {
                ArrayList list1 = new ArrayList();
                ArrayList list2 = new ArrayList();
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.OnCriticalHit != -1)
                    {
                        list1.Add(timer1);
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.OnCriticalHit != -1)
                    {
                        list1.Add(aura1);
                    }
                }
                foreach (AuraReleaseTimer timer2 in list1)
                {
                    int num4 = timer2.aura.OnCriticalHit;
                    if (num4 != -1)
                    {
                        (this.Triggers[num4] as OnCriticalHitTrigger)(this, m, timer2.ae);
                    }
                }
                foreach (PermanentAura aura2 in list2)
                {
                    int num5 = aura2.aura.OnCriticalHit;
                    if (num5 != -1)
                    {
                        (this.Triggers[num5] as OnCriticalHitTrigger)(this, m, Abilities.abilities[aura2.Id]);
                    }
                }
                ArrayList list3 = new ArrayList();
                ArrayList list4 = new ArrayList();
                foreach (AuraReleaseTimer timer3 in this.aura)
                {
                    if (timer3.aura.OnCriticalHitDone != -1)
                    {
                        list3.Add(timer3);
                    }
                }
                foreach (PermanentAura aura3 in this.permanentAura)
                {
                    if (aura3.aura.OnCriticalHitDone != -1)
                    {
                        list4.Add(aura3);
                    }
                }
                foreach (AuraReleaseTimer timer4 in list3)
                {
                    int num8 = timer4.aura.OnCriticalHitDone;
                    if (num8 != -1)
                    {
                        (this.Triggers[num8] as OnCriticalHitDoneTrigger)(this, m, timer4.ae);
                    }
                }
                foreach (PermanentAura aura4 in list4)
                {
                    int num9 = aura4.aura.OnCriticalHitDone;
                    if (num9 != -1)
                    {
                        (this.Triggers[num9] as OnCriticalHitDoneTrigger)(this, m, Abilities.abilities[aura4.Id]);
                    }
                }
                this.lastAttack = AttackStatus.Critical;
                m.lastAttackToMe = AttackStatus.Critical;
                flag1 = true;
            }
            else if (((int) single3) >= num1)
            {
                this.lastAttack = AttackStatus.NormalHit;
                m.lastAttackToMe = AttackStatus.NormalHit;
            }
            else
            {
                this.lastAttack = AttackStatus.Loose;
                m.lastAttackToMe = AttackStatus.Loose;
                return 0;
            }
            if (!pass)
            {
                float single4 = this.ParryChanceCalculation(m, single2);
                num1 = Utility.Random(100);
                if (single4 >= num1)
                {
                    this.lastAttack = AttackStatus.Parry;
                    m.lastAttackToMe = AttackStatus.Parry;
                    return -2;
                }
                float single5 = this.DodgeChanceCalculation(m, single2);
                num1 = Utility.Random(100);
                if (single5 >= num1)
                {
                    this.lastAttack = AttackStatus.Dodge;
                    m.lastAttackToMe = AttackStatus.Dodge;
                    return -1;
                }
            }
            float single6 = this.DamageDoneCalculation(m, dmgBonus, flag1, item1);
            float single7 = this.BlockChanceCalculation(m, single2);
            if (!pass)
            {
                num1 = Utility.Random(100);
                if (single7 >= num1)
                {
                    this.lastAttack = AttackStatus.Block;
                    m.lastAttackToMe = AttackStatus.Block;
                    amountBlocked = m.Block + (m.Str / 30);
                    single6 -= ((float) amountBlocked);
                    if (m.HaveTalent(Talents.ShieldSpecialization))
                    {
                        AuraEffect effect1 = (AuraEffect) m.GetTalentEffect(Talents.ShieldSpecialization);
                        num1 = Utility.Random(100);
                        if (num1 < effect1.H)
                        {
                            m.GainMana(m, (Abilities.abilities[effect1.AdditionalSpell] as SpellTemplate).S1);
                        }
                    }
                }
            }
            float single8 = this.ArmorReductionCalculation(m);
            single6 *= (1f - single8);
            if (m.ImmunePhysicalDamage)
            {
                this.lastAttack = AttackStatus.Immune;
                m.lastAttackToMe = AttackStatus.Immune;
                return 0;
            }
            single6 = (int) m.DamageAbsorbCombat(single6);
            if (single6 < 0f)
            {
                this.lastAttack = AttackStatus.Absorb;
                m.lastAttackToMe = AttackStatus.Absorb;
                return 0;
            }
            single6 = this.DamageTakenCalculation(m, single6);
            single6 = m.ManaShieldLost(this, (int) single6);
            if (this.Classe == Classes.Warrior)
            {
                if ((this.lastAttack == AttackStatus.Critical) && m.HaveTalent(Talents.BloodCraze))
                {
                    AuraEffect effect2 = (AuraEffect) m.GetTalentEffect(Talents.BloodCraze);
                    SpellTemplate template1 = (SpellTemplate) Abilities.abilities[effect2.AdditionalSpell];
                    new HotAura(template1, m, m, (int) ((m.BaseHitPoints * (((float) template1.S1) / 100f)) / ((float) (template1.Duration(m) / template1.T1))), template1.Duration(m), template1.T1);
                }
                if (this.HaveTalent(Talents.UnbridledWrath))
                {
                    AuraEffect effect3 = (AuraEffect) this.GetTalentEffect(Talents.UnbridledWrath);
                    num1 = Utility.Random(100);
                    if (num1 < effect3.H)
                    {
                        this.GainMana(this, 1);
                    }
                }
            }
            if (single6 > 0f)
            {
                this.SkillUpWeapon(item1);
            }
            return (int) single6;
        }

        public float HitChanceCalculation(Item weapon, Mobile m, float dif)
        {
            float single1 = 0f;
            if (dif < 0f)
            {
                single1 = 0x5f + ((int) dif);
            }
            else if (m.Level < (this.Level + 4))
            {
                single1 = 0x5f - (((int) dif) * 15);
            }
            else
            {
                single1 = 0x5f - (((int) dif) * 10);
            }
            single1 += (((this.HitBonus + this.MeleeHitBonus) - this.HitMalus) - this.MeleeHitMalus);
            if (single1 >= 99f)
            {
                single1 = 99f;
            }
            if (single1 <= 1f)
            {
                single1 = 1f;
            }
            return single1;
        }

        public void HitPointsUpdate(Mobile from)
        {
            new DelayHitLoosed(this, from);
        }

        public void InstantMoveTo(float x, float y, float z)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            int num1 = 4;
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.PreparePartialUpdateData(this.tempBuff, ref num1);
            this.ToAllPlayerNearExceptMe(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public int InterruptCasting()
        {
            int num1 = 0;
            num1 = this.cast.id;
            if (this is Character)
            {
                this.SpellFaillure(SpellFailedReason.Interrupted);
            }
            this.CancelCast();
            if (this is BaseCreature)
            {
                this.ChooseAttackMode();
            }
            return num1;
        }

        public virtual void ItemTargetCastSpell(ulong targetGuid, int spell, ushort type)
        {
        }

        public void Kill()
        {
            this.LooseHits(this, this.baseHitPoints);
        }

        public virtual void LearnSpell(int id)
        {
            this.knownAbilities[id] = -1;
            if ((SpellTemplate.SpellEffects[id] != null) && (SpellTemplate.SpellEffects[id] is PermanentSpellEffect))
            {
                PermanentSpellEffect effect1 = (PermanentSpellEffect) SpellTemplate.SpellEffects[id];
                effect1(Abilities.abilities[id], this);
            }
        }

        public virtual void LearnSpell(int id, SpellsTypes st)
        {
            this.knownAbilities[id] = st;
            if ((SpellTemplate.SpellEffects[id] != null) && (SpellTemplate.SpellEffects[id] is PermanentSpellEffect))
            {
                PermanentSpellEffect effect1 = (PermanentSpellEffect) SpellTemplate.SpellEffects[id];
                effect1(Abilities.abilities[id], this);
            }
        }

        public virtual void LearnTalent(int num, int lev)
        {
            this.talentList[num] = lev;
        }

        public static Mobile Load(GenericReader gr)
        {
            Mobile mobile1 = null;
            int num1 = gr.ReadInt();
            if (num1 == 0x7ffffffe)
            {
                mobile1 = new Corps();
            }
            else if (num1 == 0x7fffffff)
            {
                mobile1 = new Character();
            }
            else if (num1 > 0x5e69ec0)
            {
                ConstructorInfo info1 = World.MobilePool(0x5f5e0ff);
                mobile1 = (Mobile) info1.Invoke(null);
            }
            else if (num1 < 0)
            {
                ConstructorInfo info2 = World.MobilePool(0xf423f);
                mobile1 = (Mobile) info2.Invoke(null);
            }
            else
            {
                ConstructorInfo info3 = World.MobilePool(num1);
                mobile1 = (Mobile) info3.Invoke(null);
            }
            mobile1.Deserialize(gr);
            return mobile1;
        }

        public void LooseHits(Mobile from, int hp)
        {
            this.LooseHits(from, hp, false);
        }

        public void LooseHits(Mobile from, int hp, bool s)
        {
            if (!this.GodMode)
            {
                if (hp < 0)
                {
                    this.OnGetHit(from, s, 0);
                }
                else
                {
                    if ((s && (this.Summon != null)) && this.ShareDamageWithPet)
                    {
                        int num1 = hp / 2;
                        this.Summon.LooseHits(from, num1, s);
                        hp = num1;
                    }
                    this.hitPoints -= hp;
                    int num2 = 0;
                    if ((this.ManaType == 1) && (this.BaseMana > 0))
                    {
                        num2 = (int) (((hp * 100) / this.BaseHitPoints) * this.RageGenerationModifier);
                        this.Mana += num2;
                        if (this.Mana > this.BaseMana)
                        {
                            this.Mana = this.BaseMana;
                        }
                        this.ManaUpdate(from);
                    }
                    if (((from.ManaType == 1) && s) && (from.BaseMana > 0))
                    {
                        num2 = (int) (((hp * 50) / this.BaseHitPoints) * from.RageGenerationModifier);
                        from.Mana += num2;
                        if (from.Mana > from.BaseMana)
                        {
                            from.Mana = from.BaseMana;
                        }
                        from.ManaUpdate(this);
                    }
                    this.HitPointsUpdate(this);
                    int num3 = 0x14af5e;
                    if (from.AdditionnalStates.Contains(num3))
                    {
                        from.AttackSwing(this);
                        from.AdditionnalStates.Remove(num3);
                    }
                    this.OnGetHit(from, s, hp);
                    if (this.hitPoints <= 0)
                    {
                        this.OnDeath(from);
                    }
                    if (((hp > 0) && (this.chan.channeling > 0)) && (from != this))
                    {
                        this.ChannelEnd();
                    }
                    if (((hp > 0) && (this.cast.id > 0)) && (from != this))
                    {
                        if ((this is Character) && (this.spellCastTimer != null))
                        {
                            int num4 = 4;
                            Converter.ToBytes(base.Guid, this.tempBuff, ref num4);
                            Converter.ToBytes((uint) (this.spellCastTimer.Delay * 0.2), this.tempBuff, ref num4);
                            (this as Character).Send(OpCodes.SMSG_SPELL_DELAYED, this.tempBuff, num4);
                        }
                        if (this.spellCastTimer != null)
                        {
                            this.spellCastTimer.Delay += ((int) (this.spellCastTimer.Delay * 0.2));
                        }
                    }
                }
            }
        }

        public void LooseMana(Mobile from, int a)
        {
            this.Mana -= a;
            if (this.Mana <= 0)
            {
                this.Mana = 0;
            }
            this.ManaUpdate(this);
        }

        public int ManaShieldLost(Mobile from, int hp)
        {
            if (this.ManaShield > 0)
            {
                float single1 = 1f;
                if (this.HaveTalent(Talents.ImprovedManaShield))
                {
                    AuraEffect effect1 = (AuraEffect) this.GetTalentEffect(Talents.ImprovedManaShield);
                    single1 *= (1f + (((float) effect1.S1) / 100f));
                }
                int num1 = 0;
                int num2 = (int) (((float) this.Mana) / (2f * single1));
                if (this.ManaShield > hp)
                {
                    foreach (AuraReleaseTimer timer1 in this.aura)
                    {
                        if (timer1.aura.ManaShield <= 0)
                        {
                            continue;
                        }
                        if (timer1.aura.ManaShield > hp)
                        {
                            if (num2 > hp)
                            {
                                timer1.aura.ManaShield -= hp;
                                num1 += hp;
                                hp = 0;
                                break;
                            }
                            timer1.aura.ManaShield -= num2;
                            num1 += num2;
                            hp -= num2;
                            break;
                        }
                        if (num2 > timer1.aura.ManaShield)
                        {
                            num1 += timer1.aura.ManaShield;
                            hp -= timer1.aura.ManaShield;
                            timer1.aura.ManaShield = 0;
                            break;
                        }
                        timer1.aura.ManaShield -= num2;
                        num1 += num2;
                        hp -= num2;
                        break;
                    }
                }
                this.LooseMana(from, (int) ((2f * single1) * num1));
            }
            return hp;
        }

        public void ManaUpdate(Mobile from)
        {
            int[] numArray1 = new int[1] { 0x17 + this.manaType } ;
            object[] objArray1 = new object[1] { this.Mana } ;
            this.SendSmallUpdateToPlayerNearMe(base.Guid, numArray1, objArray1);
        }

        public void MeleeCombatSlice()
        {
            this.Running = true;
            if ((this.AttackTarget != null) && this.AttackTarget.ImmuneAttack)
            {
                if (this.combatTimer != null)
                {
                    this.combatTimer.Stop();
                }
                this.combatTimer = null;
                this.lastAttack = AttackStatus.Immune;
            }
            else if (this.AttackTarget == null)
            {
                if (this.combatTimer != null)
                {
                    this.combatTimer.Stop();
                }
                this.combatTimer = null;
            }
            else
            {
                if ((this.AttackTarget.HitPoints > 0) && (this.HitPoints > 0))
                {
                    this.UpdateXYZ();
                    if (!(this.AttackTarget is Character))
                    {
                        this.AttackTarget.UpdateXYZ();
                    }
                    float single1 = base.Distance(this.AttackTarget);
                    if ((single1 > this.combatReach) && (single1 < (8f * (this.combatReach + this.AttackTarget.CombatReach))))
                    {
                        if (this.AttackTarget != null)
                        {
                            ArrayList list1 = new ArrayList();
                            foreach (NextAttackEffect effect1 in this.NextAttackEffects)
                            {
                                bool flag1 = false;
                                this.OnSpellTemplateResults(effect1.spell, this.AttackTarget);
                                this.SpellSuccess();
                                if (effect1.onEffect is NextAttackEffectDelegate)
                                {
                                    NextAttackEffectDelegate delegate1 = (NextAttackEffectDelegate) effect1.onEffect;
                                    flag1 = delegate1(effect1.spell, this, this.AttackTarget, effect1.number);
                                }
                                if (effect1.onEffect is NextAttackEffectDelegateMultiple)
                                {
                                    ArrayList list2 = new ArrayList();
                                    NextAttackEffectDelegateMultiple multiple1 = (NextAttackEffectDelegateMultiple) effect1.onEffect;
                                    flag1 = multiple1(effect1.spell, this, this.AttackTarget, list2, effect1.number);
                                }
                                if (flag1)
                                {
                                    list1.Add(effect1);
                                    continue;
                                }
                                effect1.number++;
                            }
                            foreach (NextAttackEffect effect2 in list1)
                            {
                                this.NextAttackEffects.Remove(effect2);
                            }
                            list1.Clear();
                        }
                        int num1 = 0;
                        int num2 = 0;
                        int num3 = this.Hit(this.AttackTarget, ref num1, ref num2);
                        this.AIState = AIStates.Fighting;
                        this.MoveTo(this.X + ((this.AttackTarget.X - this.X) * 0.02f), this.Y + ((this.AttackTarget.Y - this.Y) * 0.02f), this.AttackTarget.Z);
                        int num4 = 4;
                        if (num3 <= 0)
                        {
                            Converter.ToBytes(0x22, this.tempBuff, ref num4);
                        }
                        else
                        {
                            Converter.ToBytes(0x22, this.tempBuff, ref num4);
                        }
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num4);
                        Converter.ToBytes(this.AttackTarget.Guid, this.tempBuff, ref num4);
                        if (num3 < 0)
                        {
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                        }
                        else
                        {
                            Converter.ToBytes(num3, this.tempBuff, ref num4);
                        }
                        Converter.ToBytes((byte) 1, this.tempBuff, ref num4);
                        Converter.ToBytes(0, this.tempBuff, ref num4);
                        if (num3 > 0)
                        {
                            Converter.ToBytes((float) num3, this.tempBuff, ref num4);
                        }
                        else
                        {
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                        }
                        if (num3 < 0)
                        {
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                        }
                        else
                        {
                            Converter.ToBytes(num3, this.tempBuff, ref num4);
                        }
                        Converter.ToBytes(0, this.tempBuff, ref num4);
                        Converter.ToBytes(0, this.tempBuff, ref num4);
                        if (num3 >= 0)
                        {
                            Converter.ToBytes(1, this.tempBuff, ref num4);
                        }
                        else if (num3 == -1)
                        {
                            Converter.ToBytes(2, this.tempBuff, ref num4);
                        }
                        else if (num3 == -2)
                        {
                            Converter.ToBytes(9, this.tempBuff, ref num4);
                        }
                        else if (num3 == -3)
                        {
                            Converter.ToBytes(4, this.tempBuff, ref num4);
                        }
                        else if ((num3 == -4) || (num2 > 0))
                        {
                            Converter.ToBytes(5, this.tempBuff, ref num4);
                        }
                        else if (num3 == -5)
                        {
                            Converter.ToBytes(6, this.tempBuff, ref num4);
                        }
                        else if (num3 == -6)
                        {
                            Converter.ToBytes(7, this.tempBuff, ref num4);
                        }
                        else if (num3 == -7)
                        {
                            Converter.ToBytes(8, this.tempBuff, ref num4);
                        }
                        if (num3 == 0)
                        {
                            Converter.ToBytes(uint.MaxValue, this.tempBuff, ref num4);
                        }
                        else
                        {
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                        }
                        Converter.ToBytes(0, this.tempBuff, ref num4);
                        Converter.ToBytes(0, this.tempBuff, ref num4);
                        this.ToAllPlayerNear(OpCodes.SMSG_ATTACKERSTATEUPDATE, this.tempBuff, num4);
                        this.AttackTarget.LooseHits(this, num3, true);
                        if (this.AttackTarget.Dead)
                        {
                            int num5 = 4;
                            Converter.ToBytes(base.Guid, this.tempBuff, ref num5);
                            Converter.ToBytes(this.AttackTarget.Guid, this.tempBuff, ref num5);
                            this.ToAllPlayerNear(OpCodes.SMSG_ATTACKSTOP, this.tempBuff, num5);
                            if (this.combatTimer != null)
                            {
                                this.combatTimer.Stop();
                            }
                            this.AttackTarget = null;
                        }
                    }
                    else
                    {
                        float single2 = 1f;
                        if (single1 > 20f)
                        {
                            single2 = 0.5f;
                        }
                        double num6 = (float) Math.Atan2((double) (this.AttackTarget.Y - this.Y), (double) (this.AttackTarget.X - this.X));
                        num6 += 3.1415926535897931;
                        this.MoveTo(this.AttackTarget.X + ((float) (((Math.Cos(num6) * (this.combatReach + this.AttackTarget.CombatReach)) * 1.5) * single2)), this.AttackTarget.Y + ((float) (((Math.Sin(num6) * (this.combatReach + this.AttackTarget.CombatReach)) * 1.5) * single2)), this.AttackTarget.Z);
                        this.AIState = AIStates.Attack;
                    }
                }
                if ((this as BaseCreature).IsStillActive())
                {
                    this.ChooseAttackMode();
                }
            }
        }

        public void MobileCoolDownEnded()
        {
            this.ChooseAttackMode();
        }

        public virtual void Mount(Mobile m)
        {
            AuraEffect effect1;
            this.MountModel = m.Model;
            int num1 = 4;
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, true);
            this.ToAllPlayerNearExceptMe(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
            Aura aura1 = new Aura();
            aura1.OnRelease = new Aura.AuraReleaseDelegate(this.OnUnMount);
            this.mountedIdAuraEffect = effect1 = (AuraEffect) World.MountsList[m.Id];
            this.AddAura(effect1, aura1);
        }

        public virtual void MoveInterruptCast()
        {
            this.SpellFaillure(SpellFailedReason.CantDoWhileMoving);
            this.cast.id = 0;
            this.cast.baseability = null;
            this.cast.castingtime = 0;
            this.cast.cool = 0;
            this.cast.manacost = 0;
            this.cast.type = 0;
            if (this.spellCastTimer != null)
            {
                this.spellCastTimer.Stop();
            }
        }

        public void MovementHeartBeat(PlayerHandler ph, Character from)
        {
            byte[] buffer1 = new byte[0x35] { 
                0, 0, 0, 0, 0xd1, 0x1c, 0x25, 0, 0, 160, 0, 0xf0, 80, 0x45, 0xd4, 0xc3, 
                0x26, 0xde, 0x21, 0xc5, 0x79, 0xcf, 0xbf, 0x42, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 1, 0, 0, 0, 80, 0x45, 0xd4, 0xc3, 0x26, 0xde, 0x21, 
                0xc5, 0x79, 0xcf, 0xbf, 0x42
             } ;
            int num1 = 4;
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            Converter.ToBytes(from.X, buffer1, ref num1);
            Converter.ToBytes(from.Y, buffer1, ref num1);
            Converter.ToBytes(from.Z, buffer1, ref num1);
            Converter.ToBytes(0, buffer1, ref num1);
            Converter.ToBytes(0, buffer1, ref num1);
            Converter.ToBytes((byte) 0, buffer1, ref num1);
            Converter.ToBytes(0x23f, buffer1, ref num1);
            Converter.ToBytes(1, buffer1, ref num1);
            Converter.ToBytes((float) (from.X + 20f), buffer1, ref num1);
            Converter.ToBytes(from.Y, buffer1, ref num1);
            Converter.ToBytes(from.Z, buffer1, ref num1);
            ph.Send(0xdd, buffer1, num1);
        }

        public void MoveTaxiTo(Trajet t, PathForTaxi.MapIds[] mapIds, int mapChange)
        {
            if (t.Count != 0)
            {
                if (mapChange == 0)
                {
                    int num1 = 4;
                    float single1 = this.X - t[0].x;
                    float single2 = this.Y - t[0].y;
                    float single3 = this.Z - t[0].z;
                    single1 *= single1;
                    single2 *= single2;
                    single3 *= single3;
                    single1 = (float) Math.Sqrt((double) ((single1 + single2) + single3));
                    float single4 = single1;
                    for (int num2 = 0; num2 < (t.Count - 1); num2++)
                    {
                        single1 = t[num2].x - t[num2 + 1].x;
                        single2 = t[num2].y - t[num2 + 1].y;
                        single3 = t[num2].z - t[num2 + 1].z;
                        single1 *= single1;
                        single2 *= single2;
                        single3 *= single3;
                        single4 += ((float) Math.Sqrt((double) ((single1 + single2) + single3)));
                    }
                    float single5 = single4 / 0.037f;
                    int num3 = (int) single5;
                    byte[] buffer1 = new byte[60 + ((t.Count * 3) * 4)];
                    long num7 = DateTime.Now.Ticks;
                    Converter.ToBytes(base.Guid, buffer1, ref num1);
                    Converter.ToBytes(this.X, buffer1, ref num1);
                    Converter.ToBytes(this.Y, buffer1, ref num1);
                    Converter.ToBytes(this.Z, buffer1, ref num1);
                    Converter.ToBytes(base.Orientation, buffer1, ref num1);
                    Converter.ToBytes((byte) 0, buffer1, ref num1);
                    Converter.ToBytes((uint) 0x300, buffer1, ref num1);
                    Converter.ToBytes((uint) num3, buffer1, ref num1);
                    Converter.ToBytes((uint) single4, buffer1, ref num1);
                    foreach (Coord coord1 in t)
                    {
                        Converter.ToBytes(coord1.x, buffer1, ref num1);
                        Converter.ToBytes(coord1.y, buffer1, ref num1);
                        Converter.ToBytes(coord1.z, buffer1, ref num1);
                    }
                    (this as Character).ToAllPlayerNear(OpCodes.SMSG_MONSTER_MOVE, buffer1, num1);
                    new OnTaxiEndTimer(num3, this as Character, t);
                }
                else if ((mapChange == 1) && (mapIds[0].index == 0))
                {
                    Coord coord2 = new Coord(this.X, this.Y, this.Z, null, null);
                    Coord[] coordArray1 = new Coord[1] { coord2 } ;
                    Trajet trajet1 = new Trajet(coordArray1);
                    (this as Character).SendMessage("Not supported now");
                    new OnTaxiEndTimer(0, this as Character, trajet1);
                }
                else
                {
                    int num4 = 4;
                    float single6 = this.X - t[0].x;
                    float single7 = this.Y - t[0].y;
                    float single8 = this.Z - t[0].z;
                    single6 *= single6;
                    single7 *= single7;
                    single8 *= single8;
                    single6 = (float) Math.Sqrt((double) ((single6 + single7) + single8));
                    float single9 = single6;
                    for (int num5 = 0; num5 < (t.Count - 1); num5++)
                    {
                        single6 = t[num5].x - t[num5 + 1].x;
                        single7 = t[num5].y - t[num5 + 1].y;
                        single8 = t[num5].z - t[num5 + 1].z;
                        single6 *= single6;
                        single7 *= single7;
                        single8 *= single8;
                        single9 += ((float) Math.Sqrt((double) ((single6 + single7) + single8)));
                    }
                    float single10 = single9 / 0.037f;
                    int num6 = (int) single10;
                    byte[] buffer2 = new byte[60 + ((t.Count * 3) * 4)];
                    long num8 = DateTime.Now.Ticks;
                    Converter.ToBytes(base.Guid, buffer2, ref num4);
                    Converter.ToBytes(this.X, buffer2, ref num4);
                    Converter.ToBytes(this.Y, buffer2, ref num4);
                    Converter.ToBytes(this.Z, buffer2, ref num4);
                    Converter.ToBytes(base.Orientation, buffer2, ref num4);
                    Converter.ToBytes((byte) 0, buffer2, ref num4);
                    Converter.ToBytes((uint) 0x300, buffer2, ref num4);
                    Converter.ToBytes((uint) num6, buffer2, ref num4);
                    Converter.ToBytes((uint) single9, buffer2, ref num4);
                    foreach (Coord coord3 in t)
                    {
                        Converter.ToBytes(coord3.x, buffer2, ref num4);
                        Converter.ToBytes(coord3.y, buffer2, ref num4);
                        Converter.ToBytes(coord3.z, buffer2, ref num4);
                    }
                    (this as Character).ToAllPlayerNear(OpCodes.SMSG_MONSTER_MOVE, buffer2, num4);
                    new OnTaxiEndTimer(num6, this as Character, t);
                }
            }
        }

        public float MoveTo(float x, float y, float z)
        {
            float single2;
            float single3;
            float single4;
            if (this.ForceRoot || this.ForceStun)
            {
                return 1f;
            }
            byte[] buffer1 = new byte[0x35];
            int num2 = 4;
            if (this.Running)
            {
                this.Speed = this.RunSpeed;
            }
            else
            {
                this.Speed = this.WalkSpeed;
            }
            this.moveVector.Update(x, y, z, this.Speed);
            if (Math.Abs((float) (z - this.Z)) > 2f)
            {
                float single1 = Math.Abs((float) (z - this.Z)) / 2f;
                x = this.X + ((x - this.X) / single1);
                y = this.Y + ((y - this.Y) / single1);
                z = this.Z + ((z - this.Z) / single1);
            }
            this.moveVector.Get(out single2, out single3, out single4);
            this.X = single2;
            this.Y = single3;
            this.Z = single4;
            float single5 = x - this.X;
            float single6 = y - this.Y;
            float single7 = z - this.Z;
            base.Orientation = (float) Math.Atan2((double) single6, (double) single5);
            single5 *= single5;
            single6 *= single6;
            single7 *= single7;
            single5 += (single6 + single7);
            if (this.Running)
            {
                single5 = (float) (Math.Sqrt((double) single5) / ((double) (this.Speed / 1000f)));
            }
            else
            {
                single5 = (float) (Math.Sqrt((double) single5) / ((double) (this.Speed / 1000f)));
            }
            int num1 = (int) single5;
            uint num3 = (uint) (DateTime.Now.Ticks - this.localTime);
            Converter.ToBytes(base.Guid, buffer1, ref num2);
            Converter.ToBytes(this.X, buffer1, ref num2);
            Converter.ToBytes(this.Y, buffer1, ref num2);
            Converter.ToBytes(this.Z, buffer1, ref num2);
            Converter.ToBytes(num3, buffer1, ref num2);
            Converter.ToBytes((byte) 0, buffer1, ref num2);
            if (!this.Running)
            {
                Converter.ToBytes(0, buffer1, ref num2);
            }
            else
            {
                Converter.ToBytes(0x100, buffer1, ref num2);
            }
            Converter.ToBytes(num1, buffer1, ref num2);
            Converter.ToBytes(1, buffer1, ref num2);
            Converter.ToBytes(x, buffer1, ref num2);
            Converter.ToBytes(y, buffer1, ref num2);
            Converter.ToBytes(z, buffer1, ref num2);
            this.ToAllPlayerNear(OpCodes.SMSG_MONSTER_MOVE, buffer1, num2);
            return single5;
        }

        public float MoveTo(float x, float y, float z, OnReachDelegate onReach)
        {
            float single1 = this.MoveTo(x, y, z);
            this.onReachTimer = new OnReachTimer((int) single1, onReach);
            return single1;
        }

        public virtual void NextAttackSpellGo(NextAttackEffect nae)
        {
            if (this.cast.id == 0)
            {
                this.SpellFaillure(SpellFailedReason.Fizzled);
            }
            else if (!(this.primarySpellTarget is BaseSpawner))
            {
                ArrayList list1 = new ArrayList();
                ArrayList list2 = new ArrayList();
                ArrayList list3 = new ArrayList();
                if (SpellTemplate.SpellEffects[this.cast.id] != null)
                {
                    int num1 = 4;
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    if (this is Character)
                    {
                        (this as Character).Send(OpCodes.SMSG_CAST_RESULT, this.tempBuff, num1);
                    }
                    bool flag1 = true;
                    if ((SpellTemplate.SpellEffects[this.cast.id] is NextAttackEffectDelegate) && (SpellTargeting.spellTargets[this.cast.id] != null))
                    {
                        char[] chArray1 = new char[1] { '|' } ;
                        if (((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "6") && (MultipleTargets.multipleTargets[this.cast.id] == null))
                        {
                            (this.cast.baseability as SpellTemplate).MissAndRessistTest(this.primarySpellTarget as Server.Object, this);
                            (this.primarySpellTarget as Mobile).LastOffender = this;
                            this.SendSMSGSpellGo(this.cast, this, this.primarySpellTarget as Mobile, null, null);
                            NextAttackEffectDelegate delegate1 = (NextAttackEffectDelegate) SpellTemplate.SpellEffects[this.cast.id];
                            flag1 = delegate1(this.cast.baseability, this, this.primarySpellTarget as Mobile, nae.number);
                        }
                        else
                        {
                            chArray1 = new char[1] { '|' } ;
                            if (((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "6") && (MultipleTargets.multipleTargets[this.cast.id] != null))
                            {
                                (this.primarySpellTarget as Mobile).LastOffender = this;
                                (this.cast.baseability as SpellTemplate).MissAndRessistTest(this.primarySpellTarget as Server.Object, this);
                                list3 = SpellTargets.closeTargets(this.primarySpellTarget as Mobile, (float) this.cast.radius, (int) MultipleTargets.multipleTargets[this.cast.id], TargetType.Enemy);
                                foreach (Mobile mobile1 in list3)
                                {
                                    bool flag2 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile1);
                                    bool flag3 = (this.cast.baseability as SpellTemplate).MissAndRessistTest(mobile1, this);
                                    if (flag2 && !flag3)
                                    {
                                        list1.Add(mobile1);
                                    }
                                    if (flag2)
                                    {
                                        list2.Add(mobile1);
                                    }
                                }
                                this.SendSMSGSpellGo(this.cast, this, this.primarySpellTarget as Mobile, list3, list2);
                                NextAttackEffectDelegateMultiple multiple1 = (NextAttackEffectDelegateMultiple) SpellTemplate.SpellEffects[this.cast.id];
                                flag1 = multiple1(this.cast.baseability, this, this.primarySpellTarget as Mobile, list1, nae.number);
                            }
                        }
                    }
                    if (flag1)
                    {
                        this.NextAttackEffects.Remove(nae);
                    }
                    else
                    {
                        nae.number++;
                    }
                    this.primarySpellTarget = null;
                    this.cast.baseability = null;
                    this.cast.castingtime = 0;
                    this.cast.cool = 0;
                    this.cast.id = 0;
                    this.cast.manacost = 0;
                    this.cast.type = 0;
                    this.cast.duration = 0;
                    this.cast.radius = 0;
                }
            }
        }

        public virtual bool OnCastSpellCMSG(byte[] data, int after, ushort type)
        {
            BaseAbility ability1 = Abilities.abilities[BitConverter.ToInt32(data, after + 6)];
            if (ability1 is SpellTemplate)
            {
                SpellTemplate template1 = (SpellTemplate) ability1;
                this.cast.castingtime = template1.CastingTime(this);
                this.cast.cool = template1.CoolDown(this);
                this.cast.id = template1.Id;
                this.cast.manacost = template1.GetManaCost(this);
                this.cast.type = type;
                this.cast.baseability = template1;
                int num1 = template1.Radius1;
                if (template1.Radius2 > num1)
                {
                    num1 = template1.Radius2;
                }
                if (template1.Radius3 > num1)
                {
                    num1 = template1.Radius3;
                }
                if (ability1 is AuraEffect)
                {
                    this.cast.duration = (ability1 as AuraEffect).Duration(this);
                }
                else
                {
                    this.cast.duration = 0;
                }
                this.cast.radius = (short) num1;
            }
            else if (ability1 is Profession)
            {
                this.cast.castingtime = ability1.CastingTime(this);
                this.cast.cool = ability1.CoolDown(this);
                this.cast.id = (ability1 as Profession).SpellId;
                this.cast.manacost = 0;
                this.cast.type = type;
                this.cast.baseability = ability1;
                this.cast.duration = 0;
                this.cast.radius = 0;
            }
            else
            {
                this.cast.castingtime = ability1.CastingTime(this);
                this.cast.cool = ability1.CoolDown(this);
                this.cast.id = ability1.Id;
                this.cast.manacost = 0;
                this.cast.type = type;
                this.cast.duration = 0;
                this.cast.baseability = ability1;
                this.cast.radius = 0;
            }
            this.cast.baseability.SendCooldown(this.cast, this);
            if (type == 0)
            {
                this.spellTarget = this;
                this.targetedItem = null;
                this.SpellExecutionStart(this.cast, this, false);
            }
            else if ((((type & 2) != 0) || ((type & 0x800) != 0)) || ((type & 0x8000) != 0))
            {
                Server.Object obj1 = null;
                if (this is Character)
                {
                    obj1 = (this as Character).Player.FindObjectByGuid(BitConverter.ToUInt64(data, after + 12));
                }
                else
                {
                    obj1 = this.FindObjectByGuid(BitConverter.ToUInt64(data, after + 12));
                }
                if (obj1 == null)
                {
                    this.SpellFaillure(SpellFailedReason.InvalidTarget);
                    return false;
                }
                this.targetedItem = null;
                this.spellTarget = obj1;
                this.SpellExecutionStart(this.cast, obj1, false);
            }
            else if (((type & 0x10) != 0) || ((type & 0x1000) != 0))
            {
                Item item1 = null;
                if (this is Character)
                {
                    (this as Character).FindItemByGuid(BitConverter.ToUInt64(data, after + 12));
                }
                if (item1 == null)
                {
                    this.SpellFaillure(SpellFailedReason.InvalidTarget);
                    return false;
                }
                this.SpellExecutionStart(this.cast, item1, false);
            }
            else if (((type & 0x20) != 0) || ((type & 0x40) != 0))
            {
                this.spellTargetX = BitConverter.ToSingle(data, after + 12);
                this.spellTargetY = BitConverter.ToSingle(data, after + 0x10);
                this.spellTargetZ = BitConverter.ToSingle(data, after + 20);
                this.targetedItem = null;
                this.spellTarget = null;
                SpellXYZtarget ztarget1 = new SpellXYZtarget();
                ztarget1.X = BitConverter.ToSingle(data, after + 12);
                ztarget1.Y = BitConverter.ToSingle(data, after + 0x10);
                ztarget1.Z = BitConverter.ToSingle(data, after + 20);
                if ((this.cast.baseability is SpellTemplate) && (base.Distance(this.spellTargetX, this.spellTargetY, this.spellTargetZ) > Math.Pow((double) (this.cast.baseability as SpellTemplate).Range(this), 2)))
                {
                    this.SpellFaillure(SpellFailedReason.OutOfRange);
                    return false;
                }
                this.SpellExecutionStart(this.cast, ztarget1, false);
            }
            else
            {
                Console.WriteLine("Sort bizaroide {0},{1}", type, BitConverter.ToInt32(data, after + 6));
            }
            return true;
        }

        public virtual void OnDeath(Mobile by)
        {
            this.NextAttackEffects.Clear();
            by.NextAttackEffects.Clear();
            if (this.channelTarget)
            {
                by.ChannelEnd();
            }
            this.ChannelEnd();
            if (this.MountModel != 0)
            {
                World.Add((BaseCreature) this.Mounting, this.X, this.Y, this.Z, base.MapId);
            }
            this.ReleaseAllAura();
            this.UpdateXYZ();
            if (!this.moveVector.NearDestination())
            {
                this.MoveTo(this.X, this.Y, this.Z);
            }
            this.ReleaseAllAura();
            if (by is Character)
            {
                (by as Character).CheckKills(this);
            }
            else if (by.summonedBy != null)
            {
                (by.summonedBy as Character).CheckKills(this);
            }
            by.XpEarn(this);
            if (this.SummonedBy != null)
            {
                this.SummonedBy.Summon = null;
                this.decay = new DecayTimer(this, 1);
            }
            else
            {
                int[] numArray1;
                object[] objArray1;
                this.GenerateLoot();
                if (((base.Treasure != null) && (base.Treasure.Length > 0)) && (this.KnownObjects != null))
                {
                    foreach (Server.Object obj1 in this.KnownObjects)
                    {
                        if (!(obj1 is Character))
                        {
                            continue;
                        }
                        if ((obj1 as Character).SeeAnyLoot(by, base.Treasure))
                        {
                            numArray1 = new int[2] { 0x2e, 0x94 } ;
                            objArray1 = new object[2] { (int) this.Flags, this.DynFlags(by) + 1 } ;
                            this.SendSmallUpdateToPlayer(obj1 as Character, numArray1, objArray1);
                            continue;
                        }
                        numArray1 = new int[2] { 0x2e, 0x94 } ;
                        objArray1 = new object[2] { this.Flags, this.DynFlags(by) } ;
                        this.SendSmallUpdateToPlayer(obj1 as Character, numArray1, objArray1);
                    }
                }
                else
                {
                    numArray1 = new int[2] { 0x2e, 0x94 } ;
                    objArray1 = new object[2] { this.Flags, this.DynFlags(by) } ;
                    this.SendSmallUpdate(numArray1, objArray1);
                }
                this.decay = new DecayTimer(this, World.DecayTime);
            }
        }

        public void OnGetHit(Mobile by)
        {
            if (by != this)
            {
                this.lastOffender = by;
            }
            this.OnGetHit(by, true, 1);
        }

        public virtual void OnGetHit(Mobile by, bool f, int damageAmount)
        {
            try
            {
                if (by != this)
                {
                    this.lastOffender = by;
                }
                if ((this.summon != null) && (this.summon.AIState == AIStates.Follow))
                {
                    if (by != this)
                    {
                        this.summon.OnGetHit(by);
                    }
                    else
                    {
                        this.summon.OnGetHit(this.lastOffender);
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Crash OnGetHit 1");
            }
            this.lastHit = DateTime.Now;
            if (f)
            {
                try
                {
                    ArrayList list1 = new ArrayList();
                    foreach (AuraReleaseTimer timer1 in this.aura)
                    {
                        if (timer1.aura.OnMeleeHit != -1)
                        {
                            list1.Add(timer1);
                        }
                    }
                    foreach (AuraReleaseTimer timer2 in list1)
                    {
                        int num2 = timer2.aura.OnMeleeHit;
                        if ((num2 != -1) && (this.Triggers[num2] != null))
                        {
                            (this.Triggers[num2] as OnMeleeHitTrigger)(this, by, timer2.ae);
                        }
                    }
                }
                catch (Exception)
                {
                    Console.WriteLine("Crash OnGetHit 2");
                }
                try
                {
                    ArrayList list2 = new ArrayList();
                    foreach (AuraReleaseTimer timer3 in by.Auras)
                    {
                        if (timer3.aura.OnMeleeHitDone != -1)
                        {
                            list2.Add(timer3);
                        }
                    }
                    foreach (AuraReleaseTimer timer4 in list2)
                    {
                        int num4 = timer4.aura.OnMeleeHitDone;
                        if ((num4 != -1) && (by.Triggers[num4] != null))
                        {
                            (by.Triggers[num4] as OnMeleeHitDoneTrigger)(by, this, timer4.ae);
                        }
                    }
                    return;
                }
                catch (Exception)
                {
                    Console.WriteLine("Crash OnGetHit 3");
                    return;
                }
            }
            try
            {
                ArrayList list3 = new ArrayList();
                foreach (AuraReleaseTimer timer5 in this.aura)
                {
                    if (timer5.aura == null)
                    {
                        Console.WriteLine("Trigger error for Aura = null ask DrNexus");
                    }
                    if (timer5.aura.OnSpellHit != -1)
                    {
                        list3.Add(timer5);
                    }
                }
                foreach (AuraReleaseTimer timer6 in list3)
                {
                    int num6 = timer6.aura.OnSpellHit;
                    if ((num6 != -1) && (this.Triggers[num6] != null))
                    {
                        if (!(this.Triggers[num6] is OnSpellHitTrigger))
                        {
                            Console.WriteLine("Trigger error for {0} ask DrNexus", this.Triggers[num6].GetType().ToString());
                        }
                        (this.Triggers[num6] as OnSpellHitTrigger)(this, by, timer6.ae);
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Crash OnGetHit 4");
            }
            try
            {
                ArrayList list4 = new ArrayList();
                foreach (AuraReleaseTimer timer7 in this.aura)
                {
                    if (timer7.aura.OnSpellHitDone != -1)
                    {
                        list4.Add(timer7);
                    }
                }
                foreach (AuraReleaseTimer timer8 in list4)
                {
                    int num8 = timer8.aura.OnSpellHitDone;
                    if ((num8 != -1) && (this.Triggers[num8] != null))
                    {
                        (this.Triggers[num8] as OnSpellHitDoneTrigger)(this, by, timer8.ae);
                    }
                }
            }
            catch (Exception)
            {
                Console.WriteLine("Crash OnGetHit 5");
                return;
            }
        }

        public void OnMeleeTrigersCalling(Mobile m)
        {
            this.activeWeapon.TriggerOnHit(this, m);
        }

        public virtual void OnMovementHeartBeat()
        {
        }

        public virtual void OnSpellCasted(Server.Object target)
        {
            if (this.cast.baseability is CraftTemplate)
            {
                (this.cast.baseability as CraftTemplate).Create(this.cast, this);
            }
            else if (this.cast.baseability is SpellTemplate)
            {
                this.OnSpellTemplateResults(this.cast.baseability, target);
            }
            else
            {
                Console.WriteLine("Strange spell casted id: " + this.cast.id);
            }
            this.SpellSuccess();
        }

        public void OnSpellTemplateResults(BaseAbility ba, Server.Object target)
        {
            SpellTemplate template1 = (SpellTemplate) ba;
            if ((((this.cast.type & 2) != 0) || ((this.cast.type & 0x800) != 0)) || ((this.cast.type & 0x8000) != 0))
            {
                template1.SpellResult(this.cast.manacost, this.cast.id, this, target as Mobile);
            }
            else if (((this.cast.type & 0x10) != 0) || ((this.cast.type & 0x1000) != 0))
            {
                template1.SpellResult(this.cast.manacost, this.cast.id, this, target as Item);
            }
            else
            {
                template1.SpellResult(this.cast.manacost, this.cast.id, this);
            }
            int[] numArray1 = new int[1] { 0x17 + this.ManaType } ;
            object[] objArray1 = new object[1] { this.Mana } ;
            this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public virtual void OnTick()
        {
        }

        public virtual void OnUnMount(Mobile c)
        {
            int num1 = 4;
            this.MountModel = 0;
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, true);
            this.ToAllPlayerNearExceptMe(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public float ParryChanceCalculation(Mobile m, float dif)
        {
            float single1 = 0f;
            if (m.HaveSpell(0xc37))
            {
                if (m is Character)
                {
                    single1 = (int) ((((m as Character).BaseParryChance + this.ParryBonus) - this.ParryMalus) - (dif / 2f));
                }
                else
                {
                    single1 = ((5 + this.ParryBonus) - this.ParryMalus) - (((int) dif) / 2);
                }
                if (m.HaveTalent(Talents.Deflection))
                {
                    AuraEffect effect1 = (AuraEffect) m.GetTalentEffect(Talents.Deflection);
                    single1 = (single1 * 1f) + (((float) effect1.S1) / 100f);
                }
            }
            return single1;
        }

        public void Polymorph(int modelId)
        {
            int[] numArray1 = new int[1] { 0x88 } ;
            object[] objArray1 = new object[1] { modelId } ;
            this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public void PreparePartialUpdateData(byte[] data, ref int offset)
        {
            data[offset++] = 0;
            Converter.ToBytes(base.Guid, data, ref offset);
            Converter.ToBytes((byte) 3, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            this.UpdateXYZ();
            Converter.ToBytes(this.X, data, ref offset);
            Converter.ToBytes(this.Y, data, ref offset);
            Converter.ToBytes(this.Z, data, ref offset);
            Converter.ToBytes(base.Orientation, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            if (this.WalkSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.WalkSpeed, data, ref offset);
            }
            if (this.RunSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.RunSpeed, data, ref offset);
            }
            if (this.SwimSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.SwimSpeed, data, ref offset);
            }
            if (this.SwimBackSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.SwimBackSpeed, data, ref offset);
            }
            Converter.ToBytes(this.Speed, data, ref offset);
            Converter.ToBytes((float) 3.141593f, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 1, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            base.ResetBitmap();
            base.setUpdateValue(0, base.Guid);
            base.setUpdateValue(2, 9);
            base.setUpdateValue(3, this.Id);
            base.setUpdateValue(4, this.size);
            base.FlushUpdateData(data, ref offset, 1);
        }

        public virtual void PreparePartielUpdateData(byte[] data, ref int offset)
        {
            data[offset++] = 0;
            Converter.ToBytes(base.Guid, data, ref offset);
            base.ResetBitmap();
            base.setUpdateValue(2, (byte) 0);
            base.setUpdateValue(3, (byte) 0);
            base.setUpdateValue(4, (short) 0);
            base.setUpdateValue(0x1f, (short) 0);
            base.setUpdateValue(0x24, this.Mana);
            base.setUpdateValue(0x25, this.BaseHitPoints);
            base.setUpdateValue(0x8b, this.BaseMana);
            base.setUpdateValue(140, 0xb54);
            base.setUpdateValue(0x8d, 0xb54);
            base.setUpdateValue(0x93, 0);
            base.setUpdateValue(0x93, (float) 0f);
            base.setUpdateValue(0x94, (float) 9f);
            base.setUpdateValue(0xa3, this.Str);
            base.setUpdateValue(0xa4, this.Agility);
            base.setUpdateValue(0xa5, this.Stamina);
            base.setUpdateValue(0xa6, this.Iq);
            base.setUpdateValue(0xa7, this.Spirit);
            base.setUpdateValue(0xa8, this.Armor);
            base.setUpdateValue(0xa9, 1);
            base.setUpdateValue(170, 2);
            base.setUpdateValue(0xab, 3);
            base.setUpdateValue(0xac, 4);
            base.setUpdateValue(0xad, 5);
            base.setUpdateValue(0xae, 6);
            base.setUpdateValue(0xb6, 0);
            base.setUpdateValue(0xb7, 0);
            base.setUpdateValue(0x33f, 0);
            base.setUpdateValue(0x340, 0);
            base.setUpdateValue(0x341, 0);
            base.setUpdateValue(0x342, 0);
            base.setUpdateValue(0x343, (short) 0);
            base.FlushUpdateData(data, ref offset, 1, 1, 2);
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther)
        {
            this.PrepareUpdateData(data, ref offset, type, forOther, null);
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther, Character f)
        {
            data[offset++] = 2;
            Converter.ToBytes(base.Guid, data, ref offset);
            Converter.ToBytes((byte) 3, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            this.UpdateXYZ();
            Converter.ToBytes(this.X, data, ref offset);
            Converter.ToBytes(this.Y, data, ref offset);
            Converter.ToBytes(this.Z, data, ref offset);
            Converter.ToBytes(base.Orientation, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            if (this.WalkSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.WalkSpeed, data, ref offset);
            }
            if (this.RunSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.RunSpeed, data, ref offset);
            }
            if (this.SwimSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.SwimSpeed, data, ref offset);
            }
            if (this.SwimBackSpeed == 0f)
            {
                Converter.ToBytes((double) 0.01, data, ref offset);
            }
            else
            {
                Converter.ToBytes(this.SwimBackSpeed, data, ref offset);
            }
            Converter.ToBytes(this.Speed, data, ref offset);
            Converter.ToBytes((float) 3.141593f, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 1, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            base.ResetBitmap();
            base.setUpdateValue(0, base.Guid);
            base.setUpdateValue(2, 9);
            base.setUpdateValue(3, this.Id);
            base.setUpdateValue(4, this.size);
            if (this.SummonedBy != null)
            {
                base.setUpdateValue(12, this.SummonedBy.Guid);
            }
            base.setUpdateValue(0x16, this.HitPoints);
            base.setUpdateValue((int) (0x17 + this.ManaType), this.Mana);
            base.setUpdateValue(0x1c, this.BaseHitPoints);
            base.setUpdateValue((int) (0x1d + this.ManaType), this.BaseMana);
            base.setUpdateValue(0x22, this.Level);
            base.setUpdateValue(0x23, (int) this.Faction);
            //uint num1 = (uint) ((((int) this.Classe) << 8) + ((ulong) (this.manaType << 0x18)));
			uint num1 = (uint) ((((int) this.Classe) << 8) + ((int) (this.manaType << 0x18)));//fix
            base.setUpdateValue(0x24, num1);
            if ((this.items != null) && (this.items.Length < 4))
            {
                int num2 = 0;
                Item[] itemArray1 = this.items;
                int num5 = 0;
                while (num5 < itemArray1.Length)
                {
                    Item item1 = itemArray1[num5];
                    base.setUpdateValue((int) (0x25 + num2), item1.Model);
                    num2++;
                    num5++;
                }
                num2 = 0;
                itemArray1 = this.items;
                for (num5 = 0; num5 < itemArray1.Length; num5++)
                {
                    Item item2 = itemArray1[num5];
                    uint num3 = (uint) ((((((int) item2.InventoryType) << 0x18) + (item2.Quality << 0x10)) + (item2.SubClass << 8)) + item2.ObjectClass);
                    uint num4 = (uint) item2.Sheath;
                    base.setUpdateValue((int) (40 + num2), num3);
                    num2++;
                    base.setUpdateValue((int) (40 + num2), num4);
                    num2++;
                }
            }
            base.setUpdateValue(0x2e, this.Flags);
            base.setUpdateValue(0x83, this.AttackSpeed);
            base.setUpdateValue(0x84, this.AttackSpeed);
            base.setUpdateValue(0x86, this.boundingRadius);
            base.setUpdateValue(0x87, this.combatReach);
            base.setUpdateValue(0x88, this.model);
            base.setUpdateValue(0x89, this.model);
            base.setUpdateValue(0x8a, this.mountModel);
            if (this is Character)
            {
                base.setUpdateValue(0x8b, (this as Character).BaseMinDamage);
                base.setUpdateValue(140, (this as Character).BaseMaxDamage);
            }
            else
            {
                base.setUpdateValue(0x8b, this.minDamage);
                base.setUpdateValue(140, this.maxDamage);
            }
            if (f != null)
            {
                base.setUpdateValue(0x94, this.DynFlags(f));
            }
            base.setUpdateValue(0x97, 1);
            base.setUpdateValue(0x98, this.NpcFlags);
            base.setUpdateValue(160, (uint) this.Armor);
            base.setUpdateValue(0xa7, this.AttackPower);
            base.setUpdateValue(170, 1);
            base.setUpdateValue(0xab, this.RangedAttackPower);
            base.FlushUpdateData(data, ref offset, 6);
        }

        public void PrepareUpdateDataOld(byte[] data, ref int offset, UpdateType type, bool forOther)
        {
            data[offset++] = 2;
            Converter.ToBytes(base.Guid, data, ref offset);
            Converter.ToBytes((byte) 3, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(this.X, data, ref offset);
            Converter.ToBytes(this.Y, data, ref offset);
            Converter.ToBytes(this.Z, data, ref offset);
            Converter.ToBytes(base.Orientation, data, ref offset);
            Converter.ToBytes(this.RunSpeed, data, ref offset);
            Converter.ToBytes(this.WalkSpeed, data, ref offset);
            Converter.ToBytes(this.SwimSpeed, data, ref offset);
            Converter.ToBytes(this.SwimBackSpeed, data, ref offset);
            Converter.ToBytes((float) 4.7222f, data, ref offset);
            Converter.ToBytes(this.Speed, data, ref offset);
            Converter.ToBytes((float) 3.141593f, data, ref offset);
            Converter.ToBytes((uint) 0, data, ref offset);
            Converter.ToBytes((uint) 1, data, ref offset);
            offset += 12;
            base.ResetBitmap();
            base.setUpdateValue(0, base.Guid);
            base.setUpdateValue(1, 9);
            base.setUpdateValue(2, (ushort) this.Id);
            base.setUpdateValue(3, (short) 0);
            base.setUpdateValue(4, this.size);
            base.setUpdateValue(0x16, this.HitPoints);
            base.setUpdateValue(0x17, this.Mana);
            base.setUpdateValue(0x1c, this.BaseHitPoints);
            base.setUpdateValue(0x1d, this.BaseMana);
            base.setUpdateValue(0x22, this.Level);
            base.setUpdateValue(0x23, (int) this.Faction);
            base.setUpdateValue(0x24, 0);
            base.setUpdateValue(0x2e, 0x1000);
            base.setUpdateValue(0x83, this.attackBoniiMin);
            base.setUpdateValue(0x84, this.attackBoniiMax);
            base.setUpdateValue(0x86, (float) 0.389f);
            base.setUpdateValue(0x87, 0x40400000);
            base.setUpdateValue(0x88, this.model);
            base.setUpdateValue(0x89, this.model);
            base.setUpdateValue(0x8a, 0);
            base.setUpdateValue(140, this.minDamage);
            base.setUpdateValue(0x94, this.maxDamage);
            base.setUpdateValue(0x98, this.NpcFlags);
            base.setUpdateValue(0x9b, 0);
            base.setUpdateValue(0x9c, 0);
            base.setUpdateValue(0x9d, 0);
            base.setUpdateValue(0x9e, 0);
            base.setUpdateValue(0x9f, 0);
            base.setUpdateValue(160, 0);
            base.setUpdateValue(0xa1, 0);
            base.setUpdateValue(0xa2, 0);
            base.setUpdateValue(0xa3, (uint) 0);
            base.setUpdateValue(0xa4, (uint) 0);
            base.setUpdateValue(0xa5, (uint) 0);
            base.setUpdateValue(0xa6, (uint) 0);
            base.FlushUpdateData(data, ref offset, 6);
        }

        public int RandomLevel(int max)
        {
            return max;
        }

        public int RandomLevel(int min, int max)
        {
            if (min == max)
            {
                return min;
            }
            return (Utility.Random(max - min) + min);
        }

        public bool ReachDestination()
        {
            return this.moveVector.ReachDestination();
        }

        public virtual void Regeneration()
        {
            if (!this.InteruptRegeneration)
            {
                int num1 = this.Mana;
                int num2 = this.HitPoints;
                if (((!this.InCombat || (this.ManaType == 3)) || (this.ManaRegenWhileCastingPercent != 0f)) && !this.Dead)
                {
                    int[] numArray1;
                    object[] objArray1;
                    if (this.BaseMana != 0)
                    {
                        if ((this.ManaType == 1) && (this.Mana > 0))
                        {
                            TimeSpan span1 = DateTime.Now.Subtract(this.lastHeartBeat);
                            this.Mana -= (((int) span1.TotalSeconds) * 10);
                            if (this.Mana < 0)
                            {
                                this.Mana = 0;
                            }
                        }
                        else if ((this.Mana < this.BaseMana) && (this.ManaType != 1))
                        {
                            TimeSpan span2 = DateTime.Now.Subtract(this.lastHeartBeat);
                            this.Mana += ((int) (((span2.TotalSeconds * this.BaseMana) * this.ManaRegenerationModifier) / 30));
                            if (this.Mana > this.BaseMana)
                            {
                                this.Mana = this.BaseMana;
                            }
                        }
                    }
                    if ((this.HitPoints < this.BaseHitPoints) && !this.InCombat)
                    {
                        TimeSpan span3 = DateTime.Now.Subtract(this.lastHeartBeat);
                        this.HitPoints += ((int) (((span3.TotalSeconds * this.BaseHitPoints) * this.HealthRegenerationModifier) / 40));
                        if (this.HitPoints > this.BaseHitPoints)
                        {
                            this.HitPoints = this.BaseHitPoints;
                        }
                    }
                    if ((num1 != this.Mana) && (num2 != this.HitPoints))
                    {
                        numArray1 = new int[2] { 0x16, 0x17 + this.ManaType } ;
                        objArray1 = new object[2] { this.HitPoints, this.Mana } ;
                        this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    }
                    else if (num1 != this.Mana)
                    {
                        numArray1 = new int[1] { 0x17 + this.ManaType } ;
                        objArray1 = new object[1] { this.Mana } ;
                        this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    }
                    else if (num2 != this.HitPoints)
                    {
                        numArray1 = new int[1] { 0x16 } ;
                        objArray1 = new object[1] { this.HitPoints } ;
                        this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    }
                }
            }
        }

        public void ReleaseAllAura()
        {
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                timer1.Stop();
                timer1.aura.Release(this);
                int[] numArray1 = new int[5] { 0x2f + timer1.num, 0x67 + (timer1.num >> 2), 0x71 + (timer1.num >> 2), 0x7b + (timer1.num >> 3), 130 } ;
                object[] objArray1 = new object[5] { 0, 0x1010101, 0, 0xdddddddd, 2 } ;
                this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
            }
            if (this is Character)
            {
                (this as Character).AdjustBonii();
            }
            this.aura.Clear();
        }

        public void ReleaseAllItemAura()
        {
            ArrayList list1 = new ArrayList();
            foreach (AuraReleaseTimer timer1 in this.aura)
            {
                if (!(timer1.aura is ItemAura))
                {
                    list1.Add(timer1);
                }
            }
            this.aura = list1;
        }

        public void ReleaseAura(AuraEffect ae)
        {
            AuraReleaseTimer timer1 = null;
            foreach (AuraReleaseTimer timer2 in this.aura)
            {
                if (timer2.ae == ae)
                {
                    timer1 = timer2;
                    break;
                }
            }
            if (timer1 != null)
            {
                this.ReleaseAura(timer1);
            }
        }

        public void ReleaseAura(AuraReleaseTimer art)
        {
            art.Stop();
            this.aura.Remove(art);
            if (this is Character)
            {
                (this as Character).AdjustBonii();
            }
            art.aura.Release(this);
            int[] numArray1 = new int[5] { 0x2f + art.num, 0x67 + (art.num >> 2), 0x71 + (art.num >> 2), 0x7b + (art.num >> 3), 130 } ;
            object[] objArray1 = new object[5] { 0, 0x1010101, 0, 0xdddddddd, 2 } ;
            this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public void RemovePermanentAura(AuraEffect ae)
        {
            PermanentAura aura1 = null;
            foreach (PermanentAura aura2 in this.permanentAura)
            {
                if (aura2.Id == ae.Id)
                {
                    aura1 = aura2;
                    break;
                }
            }
            if (aura1 != null)
            {
                this.permanentAura.Remove(aura1);
            }
        }

        public virtual float Reputation(Mobile m)
        {
            if (m is Character)
            {
                Character character1 = (Character) m;
                if ((World.FactionAssociated[this.Faction] != null) && (character1.ReputationAdjustments[World.FactionAssociated[this.Faction]] != null))
                {
                    int num1 = (int) character1.ReputationAdjustments[World.FactionAssociated[this.Faction]];
                    float single1 = Mobile.reactions[(int) m.Faction, (int) this.Faction];
                    if (num1 >= 0)
                    {
                        single1 += (((float) num1) / 80000f);
                    }
                    else
                    {
                        single1 += (((float) num1) / 40000f);
                    }
                    if (single1 > 1f)
                    {
                        single1 = 1f;
                    }
                    if (single1 < 0f)
                    {
                        single1 = 0f;
                    }
                    return single1;
                }
            }
            return Mobile.reactions[(int) m.Faction, (int) this.Faction];
        }

        public void ResetCombo(Mobile target)
        {
            this.comboPoints = 0;
            uint num1 = (uint) (target.Guid & 0xffffffff);
            uint num2 = (uint) ((target.Guid >> 0x20) & 0xffffffff);
            object[] objArray1 = new object[3] { num1, num2, 0 } ;
            this.SendSmallUpdate(new int[3] { 0x26a, 0x26b, 0x468 } , objArray1);
        }

        public override bool SeenBy(Character c)
        {
            if (c.Dead)
            {
                if ((this.NpcFlags & 1) > 0)
                {
                    return true;
                }
                return false;
            }
            if ((this.NpcFlags & 1) > 0)
            {
                return false;
            }
            if (c.Player == null)
            {
                return false;
            }
            if (this.Visible != InvisibilityLevel.Visible)
            {
                if (this.Visible == InvisibilityLevel.True)
                {
                    return false;
                }
                if ((this.Visible == InvisibilityLevel.GM) && (c.Player.AccessLevel == AccessLevels.PlayerLevel))
                {
                    return false;
                }
                if (((this.Visible == InvisibilityLevel.Lesser) && !this.CanSeeLesserInvisibility) && (!this.CanSeeMediumInvisibility && !this.CanSeeMediumInvisibility))
                {
                    return false;
                }
                if (((this.Visible == InvisibilityLevel.Medium) && !this.CanSeeMediumInvisibility) && !this.CanSeeMediumInvisibility)
                {
                    return false;
                }
                if ((this.Visible == InvisibilityLevel.Greater) && !this.CanSeeMediumInvisibility)
                {
                    return false;
                }
            }
            if (c != this)
            {
                if ((base.MapId != c.MapId) || (base.Distance(c) > 40000f))
                {
                    return false;
                }
                if (this.Dead)
                {
                    return true;
                }
            }
            return true;
        }

        public void SendCastResult(int Id, int type)
        {
            if (this is Character)
            {
                int num1 = 4;
                Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                Converter.ToBytes((byte) type, this.tempBuff, ref num1);
                (this as Character).Send(OpCodes.SMSG_CAST_RESULT, this.tempBuff, num1);
            }
        }

        public virtual void SendSmallUpdate(int[] pos, object[] val)
        {
            int num1 = 4;
            this.tempBuff[num1++] = 1;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.tempBuff[num1++] = 0;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            int num2 = 2 + ((pos[pos.Length - 1] + 1) / 0x20);
            if (num2 > 0x21)
            {
                num2 = 0x21;
            }
            this.tempBuff[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank, 0, this.tempBuff, num1, Server.Object.Blank.Length);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer1;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer1 = this.tempBuff)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer1[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, this.tempBuff, ref num1);
            }
            this.ToAllPlayerNear(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public virtual void SendSmallUpdateToPlayer(Character ch, int[] pos, object[] val)
        {
            int num1 = 4;
            this.tempBuff[num1++] = 1;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.tempBuff[num1++] = 0;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            int num2 = 2 + ((pos[pos.Length - 1] + 1) / 0x20);
            if (num2 > 0x21)
            {
                num2 = 0x21;
            }
            this.tempBuff[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank, 0, this.tempBuff, num1, Server.Object.Blank.Length);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer1;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer1 = this.tempBuff)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer1[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, this.tempBuff, ref num1);
            }
            ch.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public virtual void SendSmallUpdateToPlayerNearMe(int[] pos, object[] val)
        {
            this.SendSmallUpdateToPlayerNearMe(base.Guid, pos, val);
        }

        public virtual void SendSmallUpdateToPlayerNearMe(ulong guid, int[] pos, object[] val)
        {
            int num1 = 4;
            this.tempBuff[num1++] = 1;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.tempBuff[num1++] = 0;
            Converter.ToBytes(guid, this.tempBuff, ref num1);
            int num2 = 2 + (pos[pos.Length - 1] / 0x20);
            if (num2 > 0x21)
            {
                num2 = 0x21;
            }
            this.tempBuff[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank, 0, this.tempBuff, num1, num2 * 4);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer1;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer1 = this.tempBuff)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer1[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, this.tempBuff, ref num1);
            }
            this.ToAllPlayerNear(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public void SendSMSGSpellGo(Casting cast, Mobile Caster, Server.Object target, ArrayList all, ArrayList executed)
        {
            int num1 = 4;
            uint num2 = 0;
            if (cast.type == 0)
            {
                num2 = 0;
            }
            else if ((cast.type & 0x800) != 0)
            {
                num2 = 0x101;
            }
            else if (((cast.type & 2) != 0) || ((cast.type & 0x8000) != 0))
            {
                num2 = 0x100;
            }
            else if (((cast.type & 0x10) != 0) || ((cast.type & 0x1000) != 0))
            {
                num2 = 0x1010;
            }
            else if (((cast.type & 0x20) != 0) || ((cast.type & 0x40) != 0))
            {
                num1 = 4;
                Converter.ToBytes((ulong) 0, this.tempBuff, ref num1);
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                Converter.ToBytes(cast.id, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes((short) 0x201, this.tempBuff, ref num1);
                Converter.ToBytes((ulong) 50, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes((ulong) 1, this.tempBuff, ref num1);
                Converter.ToBytes(cast.type, this.tempBuff, ref num1);
                SpellXYZtarget ztarget1 = (SpellXYZtarget) this.primarySpellTarget;
                Converter.ToBytes(ztarget1.X, this.tempBuff, ref num1);
                ztarget1 = (SpellXYZtarget) this.primarySpellTarget;
                Converter.ToBytes(ztarget1.Y, this.tempBuff, ref num1);
                ztarget1 = (SpellXYZtarget) this.primarySpellTarget;
                Converter.ToBytes(ztarget1.Z, this.tempBuff, ref num1);
                this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
                return;
            }
            Converter.ToBytes(Caster.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(Caster.Guid, this.tempBuff, ref num1);
            Converter.ToBytes((uint) cast.id, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) num2, this.tempBuff, ref num1);
            if (executed != null)
            {
                Converter.ToBytes((byte) executed.Count, this.tempBuff, ref num1);
                foreach (Mobile mobile1 in executed)
                {
                    Converter.ToBytes(mobile1.Guid, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                Converter.ToBytes(target.Guid, this.tempBuff, ref num1);
            }
            if ((all != null) && (executed != null))
            {
                Converter.ToBytes((int) (((byte) all.Count) - executed.Count), this.tempBuff, ref num1);
                foreach (Mobile mobile2 in all)
                {
                    if (!executed.Contains(mobile2))
                    {
                        Converter.ToBytes(mobile2.Guid, this.tempBuff, ref num1);
                    }
                }
            }
            else
            {
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            }
            Converter.ToBytes(cast.type, this.tempBuff, ref num1);
            Converter.ToBytes(target.Guid, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
        }

        public void SendSMSGSpellStart(Casting cast, Mobile Caster, object target)
        {
            int num1 = 4;
            Converter.ToBytes(Caster.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(Caster.Guid, this.tempBuff, ref num1);
            Converter.ToBytes((uint) cast.id, this.tempBuff, ref num1);
            Converter.ToBytes(cast.type, this.tempBuff, ref num1);
            Converter.ToBytes((uint) cast.castingtime, this.tempBuff, ref num1);
            Converter.ToBytes(cast.type, this.tempBuff, ref num1);
            if ((((cast.type & 0x8000) != 0) || ((cast.type & 0x800) != 0)) || ((cast.type & 2) != 0))
            {
                Converter.ToBytes((target as Server.Object).Guid, this.tempBuff, ref num1);
            }
            else if (((cast.type & 0x1000) != 0) || ((cast.type & 0x10) != 0))
            {
                Converter.ToBytes((target as Item).Guid, this.tempBuff, ref num1);
            }
            else if ((cast.type & 0x20) != 0)
            {
                Converter.ToBytes(this.X, this.tempBuff, ref num1);
                Converter.ToBytes(this.Y, this.tempBuff, ref num1);
                Converter.ToBytes(this.Z, this.tempBuff, ref num1);
            }
            else if ((cast.type & 0x40) != 0)
            {
                SpellXYZtarget ztarget1 = (SpellXYZtarget) target;
                Converter.ToBytes(ztarget1.X, this.tempBuff, ref num1);
                ztarget1 = (SpellXYZtarget) target;
                Converter.ToBytes(ztarget1.Y, this.tempBuff, ref num1);
                ztarget1 = (SpellXYZtarget) target;
                Converter.ToBytes(ztarget1.Z, this.tempBuff, ref num1);
            }
            else if ((((cast.type & 0x2000) == 0) && ((cast.type & 0x20) != 0)) && (this is Character))
            {
                Item item1 = World.CreateItemInPoolById((this as Character).AmmoType);
                if (item1 != null)
                {
                    Converter.ToBytes((uint) item1.Model, this.tempBuff, ref num1);
                    Converter.ToBytes((uint) item1.InventoryType, this.tempBuff, ref num1);
                }
            }
            this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
        }

        public void SendSpellFlatModifier(int spell)
        {
            if (((this is Character) && (Abilities.abilities[spell] != null)) && (Abilities.abilities[spell] is SpellTemplate))
            {
                SpellTemplate template1 = (SpellTemplate) Abilities.abilities[spell];
                if (ModifierSpells.modifierSpells[spell] != null)
                {
                    string text1 = (string) ModifierSpells.modifierSpells[spell];
                    char[] chArray1 = new char[1] { '|' } ;
                    string[] textArray1 = text1.Split(chArray1);
                    for (int num1 = 0; num1 < 3; num1++)
                    {
                        if (((byte) Mobile.BinaryNumInStrToInt(textArray1[num1])) == 0)
                        {
                            goto Label_0160;
                        }
                        Console.WriteLine((byte) Mobile.BinaryNumInStrToInt(textArray1[num1]));
                        Console.WriteLine((byte) Mobile.StrToInt(textArray1[num1 + 3]));
                        int num2 = 4;
                        Converter.ToBytes((byte) Mobile.BinaryNumInStrToInt(textArray1[num1]), this.tempBuff, ref num2);
                        Converter.ToBytes((byte) Mobile.StrToInt(textArray1[num1 + 3]), this.tempBuff, ref num2);
                        switch (num1)
                        {
                            case 0:
                            {
                                Converter.ToBytes((int) (((float) template1.S1) / 1000f), this.tempBuff, ref num2);
                                goto Label_0148;
                            }
                            case 1:
                            {
                                Converter.ToBytes((int) (((float) template1.S2) / 1000f), this.tempBuff, ref num2);
                                goto Label_0148;
                            }
                            case 2:
                            {
                                break;
                            }
                            default:
                            {
                                goto Label_0148;
                            }
                        }
                        Converter.ToBytes((int) (((float) template1.S3) / 1000f), this.tempBuff, ref num2);
                    Label_0148:
                        (this as Character).Send(OpCodes.SMSG_SET_FLAT_SPELL_MODIFIER, this.tempBuff, num2);
                    Label_0160:;
                    }
                }
            }
        }

        public void SendSpellLogExecute(BaseAbility ba)
        {
            int num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(ba.Id, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 1, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 30, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 1, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 90, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 1, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_SPELLLOGEXECUTE, this.tempBuff, num1);
        }

        public override void Serialize(GenericWriter gw)
        {
            if (this is Character)
            {
                gw.Write(0x7fffffff);
            }
            else if (this is Corps)
            {
                gw.Write(0x7ffffffe);
            }
            else
            {
                gw.Write(this.id);
            }
            gw.Write(1);
            if (base.SpawnerLink != null)
            {
                gw.Write(base.SpawnerLink.Guid);
            }
            else
            {
                gw.Write((ulong) 0);
            }
            if (this.summonedBy != null)
            {
                gw.Write(1);
            }
            else
            {
                gw.Write(0);
            }
            if (this.charmedBy != null)
            {
                gw.Write(1);
            }
            else
            {
                gw.Write(0);
            }
            gw.Write(this.name);
            gw.Write((int) this.classe);
            gw.Write(this.talent);
            gw.Write(this.level);
            gw.Write(this.model);
            gw.Write(this.exp);
            gw.Write(this.guildId);
            gw.Write(this.petLevel);
            gw.Write(this.petCreatureFamily);
            gw.Write(this.petDisplayId);
            gw.Write(this.speed);
            gw.Write(this.size);
            gw.Write((int) this.faction);
            gw.Write(this.str);
            gw.Write(this.agility);
            gw.Write(this.stamina);
            gw.Write(this.iq);
            gw.Write(this.spirit);
            gw.Write(this.baseStr);
            gw.Write(this.baseAgility);
            gw.Write(this.baseStamina);
            gw.Write(this.baseIq);
            gw.Write(this.baseSpirit);
            gw.Write(this.walkSpeed);
            gw.Write(this.runSpeed);
            gw.Write(this.swimSpeed);
            gw.Write(this.swimBackSpeed);
            gw.Write(this.hitPoints);
            gw.Write(this.mana);
            gw.Write(this.energy);
            gw.Write(this.rage);
            gw.Write(this.focus);
            gw.Write(this.baseHitPoints);
            gw.Write(this.baseMana);
            gw.Write(this.baseEnergy);
            gw.Write(this.baseRage);
            gw.Write(this.baseFocus);
            gw.Write(this.block);
            gw.Write(this.armor);
            gw.Write(this.resistHoly);
            gw.Write(this.resistFire);
            gw.Write(this.resistNature);
            gw.Write(this.resistFrost);
            gw.Write(this.resistShadow);
            gw.Write(this.resistArcane);
            gw.Write(this.allSkills.Count);
            IDictionaryEnumerator enumerator1 = this.allSkills.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                ushort num1 = (ushort) enumerator1.Key;
                Skill skill1 = (Skill) enumerator1.Value;
                gw.Write(num1);
                skill1.Serialize(gw);
            }
            gw.Write(this.knownAbilities.Count);
            enumerator1 = this.knownAbilities.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                int num2 = (int) enumerator1.Key;
                int num3 = (int) enumerator1.Value;
                gw.Write((short) num2);
                gw.Write((byte) num3);
            }
            gw.Write(this.talentList.Count);
            enumerator1 = this.talentList.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                int num4 = (int) enumerator1.Key;
                int num5 = (int) enumerator1.Value;
                gw.Write(num4);
                gw.Write(num5);
            }
            if (this.freeze)
            {
                gw.Write(1);
            }
            else
            {
                gw.Write(0);
            }
            if (this is Character)
            {
                gw.Write(0x68);
                for (int num6 = 0; num6 < 0x68; num6++)
                {
                    if (this.items[num6] == null)
                    {
                        gw.Write(0);
                    }
                    else
                    {
                        gw.Write(1);
                        this.items[num6].Serialize(gw);
                    }
                }
            }
            else
            {
                gw.Write(0);
            }
            if (this.movementChange)
            {
                gw.Write(1);
            }
            else
            {
                gw.Write(0);
            }
            gw.Write(this.manaType);
            gw.Write(this.professions);
            gw.Write((int) this.standState);
            base.Serialize(gw);
        }

        public virtual void SetDamage(double min, double max)
        {
            this.minDamage = (float) min;
            this.maxDamage = (float) max;
        }

        public void SetMountModel(int id)
        {
            this.mountModel = id;
            int[] numArray1 = new int[1] { 0x8a } ;
            object[] objArray1 = new object[1] { id } ;
            this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public void SetPosition(float x, float y, float z, float orientation)
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            base.Orientation = orientation;
        }

        public static void SetReaction(Factions from, Factions to, float val)
        {
            Mobile.reactions[(int) from, (int) to] = val;
            Mobile.reactions[(int) to, (int) from] = val;
        }

        public void SetTarget(ushort type, int spell, Item targ)
        {
            this.cast.type = type;
            this.cast.id = spell;
            this.targetedItem = targ;
        }

        public int ShowInventory(byte[] tempBuff, Character c)
        {
            byte num1 = 0;
            Item[] itemArray1 = this.Sells;
            for (int num4 = 0; num4 < itemArray1.Length; num4++)
            {
                Item item1 = itemArray1[num4];
                if (item1 != null)
                {
                    num1 = (byte) (num1 + 1);
                }
            }
            int num2 = 4;
            Converter.ToBytes(base.Guid, tempBuff, ref num2);
            Converter.ToBytes(num1, tempBuff, ref num2);
            for (int num3 = 0; num3 < num1; num3++)
            {
                Item item2 = this.Sells[num3];
                Converter.ToBytes((int) (num3 + 1), tempBuff, ref num2);
                Converter.ToBytes(item2.Id, tempBuff, ref num2);
                Converter.ToBytes(item2.Model, tempBuff, ref num2);
                Converter.ToBytes(item2.Stackable, tempBuff, ref num2);
                Converter.ToBytes(item2.BuyPrice, tempBuff, ref num2);
                Converter.ToBytes(0, tempBuff, ref num2);
                Converter.ToBytes(0, tempBuff, ref num2);
            }
            return num2;
        }

        public virtual void SingleTargetCastSpell(Server.Object target, int spell, ushort type)
        {
            if (!(this is Character) || this.cast.baseability.CheckSpell(this, target))
            {
                if ((SpellTemplate.SpellEffects[this.cast.id] is NextAttackEffectDelegate) && ((type & 2) != 0))
                {
                    Mobile mobile1 = (Mobile) target;
                    if (mobile1 != null)
                    {
                        NextAttackEffect effect1 = new NextAttackEffect(this.cast.baseability, (NextAttackEffectDelegate) SpellTemplate.SpellEffects[this.cast.id]);
                        this.nextAttackEffects.Add(effect1);
                        int num1 = 4;
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes((uint) this.cast.id, this.tempBuff, ref num1);
                        Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                        Converter.ToBytes((uint) this.cast.castingtime, this.tempBuff, ref num1);
                        Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                        Converter.ToBytes(target.Guid, this.tempBuff, ref num1);
                        this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
                    }
                    else
                    {
                        this.SpellFaillure(SpellFailedReason.InvalidTarget);
                    }
                }
                else
                {
                    if (this.combatTimer != null)
                    {
                        this.combatTimer.Stop();
                    }
                    if (this.HaveSpell(spell))
                    {
                        this.cast.type = type;
                        this.targetedItem = null;
                        this.spellTarget = target;
                        if (this.cast.castingtime == 0)
                        {
                            this.SpellStart();
                        }
                        else
                        {
                            int num2 = 4;
                            Converter.ToBytes(base.Guid, this.tempBuff, ref num2);
                            Converter.ToBytes(base.Guid, this.tempBuff, ref num2);
                            Converter.ToBytes((uint) this.cast.id, this.tempBuff, ref num2);
                            Converter.ToBytes((ushort) 0x100, this.tempBuff, ref num2);
                            Converter.ToBytes((uint) this.cast.castingtime, this.tempBuff, ref num2);
                            Converter.ToBytes(this.cast.type, this.tempBuff, ref num2);
                            Converter.ToBytes(target.Guid, this.tempBuff, ref num2);
                            this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num2);
                            this.spellCastTimer = new SpellCastTimer(new SpellStartRun(this.SpellStart), this.cast.castingtime);
                        }
                    }
                }
            }
        }

        public virtual void SingleTargetCastSpell(ulong targetGuid, int spell, ushort type)
        {
            Server.Object obj1 = null;
            if (this is Character)
            {
                obj1 = (this as Character).Player.FindObjectByGuid(targetGuid);
            }
            else
            {
                obj1 = this.FindObjectByGuid(targetGuid);
            }
            if (obj1 != null)
            {
                this.SingleTargetCastSpell(obj1, spell, type);
            }
        }

        public float SkillDifCalculation(Item weapon, Mobile m)
        {
            float single1 = 0f;
            if (this is Character)
            {
                int num1 = weapon.GetSkillId();
                if (num1 == 0)
                {
                    return single1;
                }
                Skill skill1 = this.AllSkills[(ushort) num1];
                if (skill1 == null)
                {
                    return single1;
                }
                if (m is Character)
                {
                    Skill skill2 = m.AllSkills[(ushort) DefenseSkill.SkillId];
                    return (((float) (skill1.CurrentVal(this) - skill2.CurrentVal(m))) / 5f);
                }
                return (((float) (skill1.CurrentVal(this) - (m.Level * 5))) / 5f);
            }
            if (m is Character)
            {
                Skill skill3 = m.AllSkills[(ushort) DefenseSkill.SkillId];
                return (((float) ((5 * this.Level) - skill3.CurrentVal(m))) / 5f);
            }
            return (((float) ((5 * this.Level) - (m.Level * 5))) / 5f);
        }

        public bool SkillUp(int sk, int diff, double factor)
        {
            if (diff <= 50)
            {
                diff *= diff;
                double num1 = 600f / ((float) diff);
                num1 *= factor;
                if (Utility.RandomDouble() < num1)
                {
                    return true;
                }
            }
            return false;
        }

        public bool SkillUpDefense()
        {
            int num1 = this.Level * 5;
            if (this.attackTarget == null)
            {
                return false;
            }
            if (this is Character)
            {
                int num2 = DefenseSkill.SkillId;
                Skill skill1 = this.allSkills[(ushort) num2];
                if (skill1.Current >= skill1.Cap(this))
                {
                    return false;
                }
                num1 = skill1.CurrentVal(this);
                int num3 = this.Difficulty(num1, this.attackTarget.Level * 5);
                if (this.SkillUp(skill1.Current, num3, 0.01))
                {
                    skill1.Current = (ushort) (skill1.Current + 1);
                    if (this is Character)
                    {
                        (this as Character).SendSkillUpdate();
                    }
                }
            }
            return true;
        }

        public bool SkillUpOld(int sk, int diff, double facteur)
        {
            if (sk <= 300)
            {
                double num1 = sk;
                num1 = 300 - num1;
                num1 /= 300;
                num1 = (num1 * num1) * num1;
                num1 /= 90;
                if (sk > 270)
                {
                    num1 *= 8;
                }
                else if (sk > 250)
                {
                    num1 *= 4;
                }
                else if (sk > 0xe1)
                {
                    num1 *= 2;
                }
                else if (sk > 200)
                {
                    num1 *= 1.3;
                }
                else if (sk > 170)
                {
                    num1 *= 1.1;
                }
                else if (sk > 140)
                {
                    num1 *= 0.95;
                }
                else if (sk > 110)
                {
                    num1 *= 0.8;
                }
                else if (sk > 110)
                {
                    num1 *= 0.6666;
                }
                else if (sk > 80)
                {
                    num1 *= 0.5;
                }
                else if (sk > 50)
                {
                    num1 *= 0.3333;
                }
                else
                {
                    num1 *= 0.25;
                }
                if (diff < -50)
                {
                    num1 *= 2;
                }
                else if (diff < -25)
                {
                    num1 *= 1.5;
                }
                else if (diff < 0x19)
                {
                    num1 *= 1;
                }
                else if (diff < 50)
                {
                    num1 *= 0.75;
                }
                else if (diff < 0x4b)
                {
                    num1 *= 0.5;
                }
                else
                {
                    num1 *= 0.1;
                }
                num1 *= facteur;
                if (num1 < 0.0001)
                {
                    num1 = 0.0001;
                }
                if (Utility.RandomDouble() < num1)
                {
                    return true;
                }
            }
            return false;
        }

        public bool SkillUpWeapon(Item weapon)
        {
            if (this.attackTarget == null)
            {
                return false;
            }
            int num1 = this.Level * 5;
            if (weapon == null)
            {
                Item item1;
                this.activeWeapon = item1 = this.ChooseWeapon();
                weapon = item1;
            }
            if (this is Character)
            {
                int num2 = weapon.GetSkillId();
                if (num2 != 0)
                {
                    Skill skill1 = this.allSkills[(ushort) num2];
                    if (skill1 == null)
                    {
                        Console.WriteLine("Unknown skill id for weapon {0} = id = {1} class {2}. Please send that to DrNexus !!!!!!!!", weapon.Name, num2, this.Classe);
                        return false;
                    }
                    if (skill1.Current >= skill1.Cap(this))
                    {
                        return false;
                    }
                    num1 = skill1.CurrentVal(this);
                    int num3 = this.Difficulty(num1, this.attackTarget.Level * 5);
                    if (this.SkillUp(skill1.Current, num3, 0.01))
                    {
                        skill1.Current = (ushort) (skill1.Current + 1);
                        if (this is Character)
                        {
                            (this as Character).SendSkillUpdate();
                        }
                    }
                }
                if (this.StatUp(this.str, num1, 1))
                {
                    this.str++;
                }
            }
            return true;
        }

        public virtual bool SpellExecutionStart(Casting cast, object target, bool fromObject)
        {
            this.primarySpellTarget = target;
            if (!fromObject)
            {
                if (!cast.baseability.CheckSpellCaster(this))
                {
                    return false;
                }
                if ((!(this.primarySpellTarget is SpellXYZtarget) || !(this.primarySpellTarget is Item)) && !cast.baseability.CheckSpellTarget(this, this.primarySpellTarget as Server.Object))
                {
                    return false;
                }
            }
            if (SpellTemplate.SpellEffects[cast.id] is NextAttackEffectDelegate)
            {
                if (target is Mobile)
                {
                    Mobile mobile1 = (Mobile) target;
                    if (mobile1 != null)
                    {
                        this.OnSpellTemplateResults(cast.baseability, mobile1);
                        NextAttackEffect effect1 = new NextAttackEffect(cast.baseability, (NextAttackEffectDelegate) SpellTemplate.SpellEffects[cast.id]);
                        this.nextAttackEffects.Add(effect1);
                        int num1 = 4;
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes((uint) cast.id, this.tempBuff, ref num1);
                        Converter.ToBytes(cast.type, this.tempBuff, ref num1);
                        Converter.ToBytes((uint) cast.castingtime, this.tempBuff, ref num1);
                        Converter.ToBytes(cast.type, this.tempBuff, ref num1);
                        Converter.ToBytes(mobile1.Guid, this.tempBuff, ref num1);
                        this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
                    }
                    else
                    {
                        this.SpellFaillure(SpellFailedReason.InvalidTarget);
                    }
                }
                else
                {
                    this.SpellFaillure(SpellFailedReason.InvalidTarget);
                }
            }
            else if (SpellTemplate.SpellEffects[cast.id] is NextAttackEffectDelegateMultiple)
            {
                if (target is Mobile)
                {
                    Mobile mobile2 = (Mobile) target;
                    if (mobile2 != null)
                    {
                        this.OnSpellTemplateResults(cast.baseability, mobile2);
                        NextAttackEffect effect2 = new NextAttackEffect(cast.baseability, (NextAttackEffectDelegateMultiple) SpellTemplate.SpellEffects[cast.id]);
                        this.nextAttackEffects.Add(effect2);
                        int num2 = 4;
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num2);
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num2);
                        Converter.ToBytes((uint) cast.id, this.tempBuff, ref num2);
                        Converter.ToBytes(cast.type, this.tempBuff, ref num2);
                        Converter.ToBytes((uint) cast.castingtime, this.tempBuff, ref num2);
                        Converter.ToBytes(cast.type, this.tempBuff, ref num2);
                        Converter.ToBytes(mobile2.Guid, this.tempBuff, ref num2);
                        this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num2);
                    }
                    else
                    {
                        this.SpellFaillure(SpellFailedReason.InvalidTarget);
                    }
                }
                else
                {
                    this.SpellFaillure(SpellFailedReason.InvalidTarget);
                }
            }
            else if (cast.castingtime <= 0)
            {
                this.SpellStart();
            }
            else
            {
                this.SendSMSGSpellStart(cast, this, this.primarySpellTarget);
                this.spellCastTimer = new SpellCastTimer(new SpellStartRun(this.SpellStart), cast.castingtime);
            }
            return true;
        }

        public virtual void SpellFaillure()
        {
            if (this is Character)
            {
                int num1 = 4;
                Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 2, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0x1a, this.tempBuff, ref num1);
                (this as Character).Send(OpCodes.SMSG_CAST_RESULT, this.tempBuff, num1);
            }
            this.primarySpellTarget = null;
            this.cast.baseability = null;
            this.cast.castingtime = 0;
            this.cast.cool = 0;
            this.cast.id = 0;
            this.cast.duration = 0;
            this.cast.radius = 0;
            this.cast.manacost = 0;
            this.cast.type = 0;
        }

        public virtual void SpellFaillure(SpellFailedReason b)
        {
            if ((this.cast.id != 0) && (b != SpellFailedReason.NotInCombat))
            {
                if (this is Character)
                {
                    int num1 = 4;
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 2, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) b, this.tempBuff, ref num1);
                    (this as Character).Send(OpCodes.SMSG_CAST_RESULT, this.tempBuff, num1);
                    num1 = 4;
                }
                this.primarySpellTarget = null;
                this.cast.baseability = null;
                this.cast.castingtime = 0;
                this.cast.cool = 0;
                this.cast.id = 0;
                this.cast.duration = 0;
                this.cast.radius = 0;
                this.cast.manacost = 0;
                this.cast.type = 0;
            }
        }

        public virtual void SpellFaillure(SpellFailedReason b, string msg)
        {
            if ((this.cast.id != 0) && (b != SpellFailedReason.NotInCombat))
            {
                if (this is Character)
                {
                    int num1 = 4;
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 2, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) b, this.tempBuff, ref num1);
                    Converter.ToBytes(msg, this.tempBuff, ref num1);
                    (this as Character).Send(OpCodes.SMSG_CAST_RESULT, this.tempBuff, num1);
                }
                this.primarySpellTarget = null;
                this.cast.baseability = null;
                this.cast.castingtime = 0;
                this.cast.cool = 0;
                this.cast.id = 0;
                this.cast.manacost = 0;
                this.cast.type = 0;
                this.cast.duration = 0;
                this.cast.radius = 0;
            }
        }

        public virtual void SpellStart()
        {
            if ((this.cast.id == 0) && (this is Character))
            {
                this.SpellFaillure(SpellFailedReason.Fizzled);
            }
            else
            {
                this.OnSpellCasted(this.spellTarget);
            }
        }

        public void SpellStateMSG(int degats, int SpellId, Mobile src, Mobile target, int type)
        {
            int num1 = 4;
            Converter.ToBytes(target.Guid, target.tempBuff, ref num1);
            Converter.ToBytes(src.Guid, target.tempBuff, ref num1);
            Converter.ToBytes(SpellId, target.tempBuff, ref num1);
            Converter.ToBytes(degats, target.tempBuff, ref num1);
            Converter.ToBytes(type, target.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0x100, target.tempBuff, ref num1);
            Converter.ToBytes(target.Guid, target.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_SPELLNONMELEEDAMAGELOG, target.tempBuff, num1);
        }

        public virtual void SpellSuccess()
        {
            char[] chArray1;
            if (this.spellTarget is BaseSpawner)
            {
                return;
            }
            bool flag1 = false;
            ArrayList list1 = new ArrayList();
            ArrayList list2 = new ArrayList();
            ArrayList list3 = new ArrayList();
            int num1 = 4;
            if (this is Character)
            {
                Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                (this as Character).Send(OpCodes.SMSG_CAST_RESULT, this.tempBuff, num1);
            }
            num1 = 4;
            if (this.cast.type != 0)
            {
                if ((this.cast.type & 0x800) != 0)
                {
                    Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes((short) 0x101, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                    this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
                    if ((SpellTemplate.SpellEffects[this.cast.id] != null) && (SpellTemplate.SpellEffects[this.cast.id] is GameObject))
                    {
                        GameObjectTargetSpellEffect effect2 = (GameObjectTargetSpellEffect) SpellTemplate.SpellEffects[this.cast.id];
                        effect2(this.cast.baseability, this, this.spellTarget as GameObject);
                    }
                }
                else if (((this.cast.type & 2) != 0) || ((this.cast.type & 0x8000) != 0))
                {
                    if (SpellTemplate.SpellEffects[this.cast.id] != null)
                    {
                        if (SpellTargeting.spellTargets[this.cast.id] != null)
                        {
                            chArray1 = new char[1] { '|' } ;
                            if (((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "6") && (MultipleTargets.multipleTargets[this.cast.id] == null))
                            {
                                flag1 = (this.cast.baseability as SpellTemplate).MissAndRessistTest(this.spellTarget, this);
                            }
                        }
                        (this.spellTarget as Mobile).LastOffender = this;
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                        Converter.ToBytes((short) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                        Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                        Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                        this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
                        if (!flag1)
                        {
                            SingleTargetSpellEffect effect3 = (SingleTargetSpellEffect) SpellTemplate.SpellEffects[this.cast.id];
                            effect3(this.cast.baseability, this, this.spellTarget as Mobile);
                        }
                    }
                    if (SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffectMultiple)
                    {
                        if (SpellTargeting.spellTargets[this.cast.id] != null)
                        {
                            chArray1 = new char[1] { '|' } ;
                            if ((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "45")
                            {
                                list3 = SpellTargets.targetsAround(this.primarySpellTarget as Mobile, (float) this.cast.radius, TargetType.Friend);
                                list3 = SpellTargets.targetsAround(this.primarySpellTarget as Mobile, (float) this.cast.radius, TargetType.Party);
                                foreach (Mobile mobile7 in list3)
                                {
                                    bool flag10 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile7);
                                    if (flag10)
                                    {
                                        list1.Add(mobile7);
                                    }
                                    if (flag10)
                                    {
                                        list2.Add(mobile7);
                                    }
                                }
                            }
                            else
                            {
                                chArray1 = new char[1] { '|' } ;
                                if ((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "37")
                                {
                                    list3 = SpellTargets.targetsAround(this.primarySpellTarget as Mobile, (float) this.cast.radius, TargetType.Party);
                                    foreach (Mobile mobile8 in list3)
                                    {
                                        bool flag11 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile8);
                                        if (flag11)
                                        {
                                            list1.Add(mobile8);
                                        }
                                        if (flag11)
                                        {
                                            list2.Add(mobile8);
                                        }
                                    }
                                }
                                else
                                {
                                    chArray1 = new char[1] { '|' } ;
                                    if (((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "6") && (MultipleTargets.multipleTargets[this.cast.id] != null))
                                    {
                                        (this.primarySpellTarget as Mobile).LastOffender = this;
                                        flag1 = (this.cast.baseability as SpellTemplate).MissAndRessistTest(this.primarySpellTarget as Server.Object, this);
                                        list3 = SpellTargets.closeTargets(this.primarySpellTarget as Mobile, (float) this.cast.radius, (int) MultipleTargets.multipleTargets[this.cast.id], TargetType.Enemy);
                                        foreach (Mobile mobile9 in list3)
                                        {
                                            bool flag12 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile9);
                                            bool flag13 = (this.cast.baseability as SpellTemplate).MissAndRessistTest(mobile9, this);
                                            if (flag12 && !flag13)
                                            {
                                                list1.Add(mobile9);
                                                flag1 = false;
                                            }
                                            if (flag12)
                                            {
                                                list2.Add(mobile9);
                                            }
                                        }
                                    }
                                }
                            }
                        }
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                        Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                        Converter.ToBytes((short) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) list2.Count, this.tempBuff, ref num1);
                        foreach (Mobile mobile10 in list2)
                        {
                            Converter.ToBytes(mobile10.Guid, this.tempBuff, ref num1);
                        }
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                        Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                        this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
                        SingleTargetSpellEffectMultiple multiple2 = (SingleTargetSpellEffectMultiple) SpellTemplate.SpellEffects[this.cast.id];
                        multiple2(this.cast.baseability, this, this.primarySpellTarget as Mobile, list1);
                    }
                }
                else if (((this.cast.type & 0x10) != 0) || ((this.cast.type & 0x1000) != 0))
                {
                    Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes((short) 0x101, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTarget.Guid, this.tempBuff, ref num1);
                    this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
                }
                else if (((this.cast.type & 0x20) != 0) || ((this.cast.type & 0x40) != 0))
                {
                    Converter.ToBytes((ulong) 0, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes((short) 0x201, this.tempBuff, ref num1);
                    Converter.ToBytes((ulong) 50, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes((ulong) 1, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTargetX, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTargetY, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTargetZ, this.tempBuff, ref num1);
                    this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
                    if (SpellTemplate.SpellEffects[this.cast.id] != null)
                    {
                        TargetXYZSpellEffect effect4 = (TargetXYZSpellEffect) SpellTemplate.SpellEffects[this.cast.id];
                        effect4(this.cast.baseability, this, this.spellTargetX, this.spellTargetY, this.spellTargetZ);
                    }
                }
                goto Label_119A;
            }
            if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
            {
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                Converter.ToBytes((uint) this.cast.id, this.tempBuff, ref num1);
                Converter.ToBytes((short) 0, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
                if (SpellTemplate.SpellEffects[this.cast.id] != null)
                {
                    OnSelfSpellEffect effect1 = (OnSelfSpellEffect) SpellTemplate.SpellEffects[this.cast.id];
                    effect1(this.cast.baseability, this);
                }
                goto Label_119A;
            }
            if (!(SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffectMultiple))
            {
                goto Label_119A;
            }
            if (SpellTargeting.spellTargets[this.cast.id] != null)
            {
                chArray1 = new char[1] { '|' } ;
                if ((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "20")
                {
                    list3 = SpellTargets.targetsAround(this, 10f, TargetType.Party);
                    foreach (Mobile mobile1 in list3)
                    {
                        bool flag2 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile1);
                        if (flag2)
                        {
                            list1.Add(mobile1);
                        }
                        if (flag2)
                        {
                            list2.Add(mobile1);
                        }
                    }
                }
                else
                {
                    chArray1 = new char[1] { '|' } ;
                    if ((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] == "24")
                    {
                        list3 = SpellTargets.targetsInConeFront(this, (float) this.cast.radius, TargetType.Enemy, 3);
                        foreach (Mobile mobile2 in list3)
                        {
                            bool flag3 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile2);
                            bool flag4 = (this.cast.baseability as SpellTemplate).MissAndRessistTest(mobile2, this);
                            if (flag3 && !flag4)
                            {
                                list1.Add(mobile2);
                                flag1 = false;
                            }
                            if (flag3)
                            {
                                list2.Add(mobile2);
                            }
                        }
                    }
                    else
                    {
                        chArray1 = new char[1] { '|' } ;
                        if ((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] != "25")
                        {
                            chArray1 = new char[1] { '|' } ;
                            if ((SpellTargeting.spellTargets[this.cast.id] as string).Split(chArray1)[0] != "22")
                            {
                                list3 = SpellTargets.targetsAround(this, (float) this.cast.radius, TargetType.Enemy);
                                ArrayList list4 = SpellTargets.targetsAround(this, (float) this.cast.radius, TargetType.Friend);
                                foreach (Mobile mobile4 in list3)
                                {
                                    bool flag7 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile4);
                                    bool flag8 = (this.cast.baseability as SpellTemplate).MissAndRessistTest(mobile4, this);
                                    if (flag7 && !flag8)
                                    {
                                        list1.Add(mobile4);
                                        flag1 = false;
                                    }
                                    if (flag7)
                                    {
                                        list2.Add(mobile4);
                                    }
                                }
                                foreach (Mobile mobile5 in list4)
                                {
                                    bool flag9 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile5);
                                    if (flag9)
                                    {
                                        list1.Add(mobile5);
                                    }
                                    if (flag9)
                                    {
                                        list2.Add(mobile5);
                                    }
                                }
                                foreach (Server.Object obj1 in list4)
                                {
                                    list3.Add(obj1);
                                }
                                goto Label_0612;
                            }
                        }
                        list3 = SpellTargets.targetsAround(this, (float) this.cast.radius, TargetType.Enemy);
                        foreach (Mobile mobile3 in list3)
                        {
                            Console.WriteLine("ok");
                            bool flag5 = this.cast.baseability.CheckSpellTargetMultiple(this, mobile3);
                            bool flag6 = (this.cast.baseability as SpellTemplate).MissAndRessistTest(mobile3, this);
                            if (flag5 && !flag6)
                            {
                                list1.Add(mobile3);
                                flag1 = false;
                            }
                            if (flag5)
                            {
                                list2.Add(mobile3);
                            }
                        }
                    }
                }
            }
        Label_0612:
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes((uint) this.cast.id, this.tempBuff, ref num1);
            Converter.ToBytes((short) 0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) list2.Count, this.tempBuff, ref num1);
            foreach (Mobile mobile6 in list2)
            {
                Converter.ToBytes(mobile6.Guid, this.tempBuff, ref num1);
            }
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes((ushort) 0, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.tempBuff, num1);
            if (!flag1)
            {
                OnSelfSpellEffectMultiple multiple1 = (OnSelfSpellEffectMultiple) SpellTemplate.SpellEffects[this.cast.id];
                multiple1(this.cast.baseability, this, list1);
            }
        Label_119A:
            if (this.combatTimer != null)
            {
                this.combatTimer.Restart();
            }
            this.cast.baseability = null;
            this.cast.castingtime = 0;
            this.cast.cool = 0;
            this.cast.id = 0;
            this.cast.manacost = 0;
            this.cast.type = 0;
            this.cast.duration = 0;
            this.cast.radius = 0;
        }

        private void SpellTakeEffect()
        {
            if (SpellTemplate.SpellEffects[this.cast.id] == null)
            {
                Console.WriteLine("{0} try to cast an invalid spell !! id={1}", this.Name, this.cast.id);
            }
            else
            {
                if (SpellTemplate.SpellEffects[this.cast.id] is SingleTargetSpellEffect)
                {
                    SingleTargetSpellEffect effect1 = (SingleTargetSpellEffect) SpellTemplate.SpellEffects[this.cast.id];
                    effect1(Abilities.abilities[this.cast.id], this, this.AttackTarget);
                }
                else if (SpellTemplate.SpellEffects[this.cast.id] is OnSelfSpellEffect)
                {
                    OnSelfSpellEffect effect2 = (OnSelfSpellEffect) SpellTemplate.SpellEffects[this.cast.id];
                    effect2(Abilities.abilities[this.cast.id], this);
                }
                this.ChooseAttackMode();
            }
        }

        public bool StatUp(int sk, int diff, double facteur)
        {
            if (sk <= 130)
            {
                double num1 = sk;
                num1 = 130 - num1;
                num1 /= 130;
                num1 = (num1 * num1) * num1;
                num1 /= 220;
                if (sk < 30)
                {
                    num1 *= 0.2;
                }
                else if (sk < 50)
                {
                    num1 *= 0.5;
                }
                else if (sk < 70)
                {
                    num1 *= 1.5;
                }
                else if (sk < 90)
                {
                    num1 *= 2;
                }
                else if (sk < 100)
                {
                    num1 *= 5;
                }
                else
                {
                    num1 *= 0.2;
                }
                if (diff < -50)
                {
                    num1 *= 2;
                }
                else if (diff < -25)
                {
                    num1 *= 1.5;
                }
                else if (diff < 0x19)
                {
                    num1 *= 1;
                }
                else if (diff < 50)
                {
                    num1 *= 0.75;
                }
                else if (diff < 0x4b)
                {
                    num1 *= 0.5;
                }
                else
                {
                    num1 *= 0.1;
                }
                num1 *= facteur;
                if (num1 < 0.0001)
                {
                    num1 = 0.0001;
                }
                if (Utility.RandomDouble() < num1)
                {
                    return true;
                }
            }
            return false;
        }

        public static int StrToInt(string str)
        {
            int num1 = 0;
            int num2 = str.Length;
            bool flag1 = false;
            for (int num3 = 0; num3 < num2; num3++)
            {
                if (str[num3] == '-')
                {
                    flag1 = true;
                }
                else
                {
                    int num4 = 1;
                    for (int num5 = 1; num5 <= (num2 - (num3 + 1)); num5++)
                    {
                        num4 *= 10;
                    }
                    num1 += ((str[num3] - '0') * num4);
                }
            }
            if (flag1)
            {
                num1 *= -1;
            }
            return num1;
        }

        public int TalentLevel(Talents t)
        {
            if (this.talentList[(int) t] != null)
            {
                return (int) this.talentList[(int) t];
            }
            return 0;
        }

        public virtual void ToAllPlayerNear(OpCodes code, byte[] data)
        {
            if ((this.lastSeen != null) && (this.lastSeen.Player != null))
            {
                this.lastSeen.Player.ToAllPlayerNear(this, code, data, data.Length);
            }
        }

        public virtual void ToAllPlayerNear(OpCodes code, byte[] data, int len)
        {
            if ((this.lastSeen != null) && (this.lastSeen.Player != null))
            {
                this.lastSeen.Player.ToAllPlayerNear(this, code, data, len);
            }
        }

        public virtual void ToAllPlayerNear(OpCodes code, byte[] data, int after, int len)
        {
            byte[] buffer1 = new byte[len];
            Buffer.BlockCopy(data, after, buffer1, 0, len);
            if ((this.lastSeen != null) && (this.lastSeen.Player != null))
            {
                this.lastSeen.Player.ToAllPlayerNear(this, code, buffer1, len);
            }
        }

        public virtual void ToAllPlayerNearExceptMe(OpCodes code, byte[] data, int len)
        {
            if ((this.lastSeen != null) && (this.lastSeen.Player != null))
            {
                this.lastSeen.Player.ToAllPlayerNear(this, code, data, len);
            }
        }

        public virtual void ToAllPlayerNearExceptMe(OpCodes code, byte[] data, int after, int len)
        {
            byte[] buffer1 = new byte[len];
            Buffer.BlockCopy(data, after, buffer1, 0, len);
            if ((this.lastSeen != null) && (this.lastSeen.Player != null))
            {
                this.lastSeen.Player.ToAllPlayerNear(this, code, buffer1, len);
            }
        }

        public void ToPlayerInRange(OpCodes op, byte[] buffer, int len)
        {
            foreach (Character character1 in World.allConnectedChars)
            {
                if (base.Distance(character1) < 180000f)
                {
                    character1.Send(op, buffer, len);
                }
            }
        }

        public void TrainAbility(int[] abs)
        {
            int[] numArray1 = abs;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                int num1 = numArray1[num2];
                this.knownAbilities[num1] = -1;
            }
        }

        public virtual void UnLearnSpell(int id)
        {
            this.knownAbilities.Remove(id);
            if (Abilities.abilities[id] is AuraEffect)
            {
                this.RemovePermanentAura((AuraEffect) Abilities.abilities[id]);
            }
        }

        public void UpdateXYZ()
        {
            float single1;
            float single2;
            float single3;
            this.moveVector.Get(out single1, out single2, out single3);
            this.X = single1;
            this.Y = single2;
            this.Z = single3;
        }

        public int XpEarn(Mobile m)
        {
            if (m.NpcType == 8)
            {
                return 0;
            }
            float single1 = 0f;
            int num1 = m.Level;
            int num2 = this.level;
            if ((num2 >= 60) || (num1 >= 60))
            {
                return 0;
            }
            if (num1 < (num2 - 6))
            {
                return 0;
            }
            if (num1 == (num2 - 6))
            {
                single1 = 0.1f;
            }
            else if (num1 == (num2 - 5))
            {
                single1 = 0.25f;
            }
            else if (num1 == (num2 - 4))
            {
                single1 = 0.3333f;
            }
            else if (num1 == (num2 - 3))
            {
                single1 = 0.5f;
            }
            else if (num1 == (num2 - 2))
            {
                single1 = 0.6666f;
            }
            else if (num1 == (num2 - 1))
            {
                single1 = 0.75f;
            }
            else if (num1 == num2)
            {
                single1 = 1f;
            }
            else
            {
                single1 = 1.1f;
            }
            int num3 = (int) (Mobile.mobXp[num1] * single1);
            Character character1 = null;
            if (this is Character)
            {
                character1 = this as Character;
            }
            else if (this.summonedBy != null)
            {
                character1 = this.summonedBy as Character;
            }
            if (character1 != null)
            {
                if ((character1.GroupMembers != null) && (character1.GroupMembers.Count > 1))
                {
                    int num4 = 0;
                    int num5 = 0;
                    foreach (Member member1 in character1.GroupMembers.Members)
                    {
                        int num6 = member1.Char.Level;
                        if (num4 < num6)
                        {
                            num4 = num6;
                        }
                        num5 += ((num6 * num6) * num6);
                    }
                    float single2 = Mobile.mobXp[num4];
                    float single3 = num5;
                    foreach (Member member2 in character1.GroupMembers.Members)
                    {
                        float single4 = (single2 * ((member2.Char.Level * member2.Char.Level) * member2.Char.Level)) / single3;
                        num3 = (int) single4;
                        int num7 = 4;
                        Converter.ToBytes(member2.Char.Guid, this.tempBuff, ref num7);
                        Converter.ToBytes(num3, this.tempBuff, ref num7);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num7);
                        Converter.ToBytes(50, this.tempBuff, ref num7);
                        Converter.ToBytes((float) 1f, this.tempBuff, ref num7);
                        member2.Char.Send(OpCodes.SMSG_LOG_XPGAIN, this.tempBuff, num7);
                        member2.Char.EarnXP(num3);
                    }
                    return num3;
                }
                int num8 = 4;
                Converter.ToBytes(m.Guid, this.tempBuff, ref num8);
                Converter.ToBytes(num3, this.tempBuff, ref num8);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num8);
                Converter.ToBytes(50, this.tempBuff, ref num8);
                Converter.ToBytes((float) 1f, this.tempBuff, ref num8);
                character1.Send(OpCodes.SMSG_LOG_XPGAIN, this.tempBuff, num8);
                character1.EarnXP(num3);
                return num3;
            }
            this.exp += ((uint) num3);
            return num3;
        }

        public virtual void ZoneCastSpell(int spell, ushort type, float x, float y, float z)
        {
            if ((!(this is Character) || this.cast.baseability.CheckSpell(this, null)) && this.HaveSpell(spell))
            {
                this.spellTargetX = x;
                this.spellTargetY = y;
                this.spellTargetZ = z;
                this.targetedItem = null;
                this.spellTarget = null;
                if (this.cast.castingtime <= 0)
                {
                    this.SpellStart();
                }
                else
                {
                    int num1 = 4;
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.id, this.tempBuff, ref num1);
                    Converter.ToBytes((ushort) 0x100, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.castingtime, this.tempBuff, ref num1);
                    Converter.ToBytes(this.cast.type, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTargetX, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTargetY, this.tempBuff, ref num1);
                    Converter.ToBytes(this.spellTargetZ, this.tempBuff, ref num1);
                    this.ToAllPlayerNear(OpCodes.SMSG_SPELL_START, this.tempBuff, num1);
                    this.spellCastTimer = new SpellCastTimer(new SpellStartRun(this.SpellStart), this.cast.castingtime);
                }
            }
        }


        // Properties
        public int AbsorbAllMagic
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AbsorbAllMagic;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AbsorbAllMagic;
                }
                return num1;
            }
        }

        public Item ActiveShield
        {
            get
            {
                return this.activeShield;
            }
        }

        public Item ActiveWeapon
        {
            get
            {
                return this.activeWeapon;
            }
        }

        public ArrayList AdditionnalStates
        {
            get
            {
                return this.additionnalStates;
            }
        }

        public int AgBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AgBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AgBonus;
                }
                return num1;
            }
        }

        public int Agility
        {
            get
            {
                return (int) (((((((this.agility + this.AgBonus) + ((int) this.baseAgility)) - this.AgMalus) + this.AllAtributesBonus) - this.AllAtributesMalus) * ((1f + (this.AgPercentBonus / 100f)) - (this.AgPercentMalus / 100f))) * ((1f + (this.AllAtributesPercentBonus / 100f)) - (this.AllAtributesPercentMalus / 100f)));
            }
            set
            {
                this.agility = value;
            }
        }

        public int AgMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AgMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AgMalus;
                }
                return num1;
            }
        }

        public float AgPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.AgPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.AgPercentBonus;
                }
                return single1;
            }
        }

        public float AgPercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.AgPercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.AgPercentMalus;
                }
                return single1;
            }
        }

        public AIStates AIState
        {
            get
            {
                return this.aiState;
            }
            set
            {
                this.aiState = value;
            }
        }

        public int AllAtributesBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllAtributesBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllAtributesBonus;
                }
                return num1;
            }
        }

        public int AllAtributesMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllAtributesMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllAtributesMalus;
                }
                return num1;
            }
        }

        public float AllAtributesPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.AllAtributesPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.AllAtributesPercentBonus;
                }
                return single1;
            }
        }

        public float AllAtributesPercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.AllAtributesPercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.AllAtributesPercentMalus;
                }
                return single1;
            }
        }

        public int AllCostMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllCostMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllCostMalus;
                }
                return num1;
            }
        }

        public int AllDamageAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllDamageAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllDamageAbsorb;
                }
                return num1;
            }
        }

        public int AllDamageDoneBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllDamageDoneBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllDamageDoneBonus;
                }
                return num1;
            }
        }

        public int AllDamageDoneMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllDamageDoneMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllDamageDoneMalus;
                }
                return num1;
            }
        }

        public float AllDamageDoneModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.AllDamageDoneModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.AllDamageDoneModifier;
                }
                return single1;
            }
        }

        public int AllMagicDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllMagicDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllMagicDamageIncrease;
                }
                return num1;
            }
        }

        public int AllResistanceBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllResistanceBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllResistanceBonus;
                }
                return num1;
            }
        }

        public int AllResistanceMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AllResistanceMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AllResistanceMalus;
                }
                return num1;
            }
        }

        public float AllResistancePercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.AllResistancePercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.AllResistancePercentBonus;
                }
                return single1;
            }
        }

        public float AllResistancePercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.AllResistancePercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.AllResistancePercentMalus;
                }
                return single1;
            }
        }

        public Skills AllSkills
        {
            get
            {
                return this.allSkills;
            }
        }

        public int ArcaneAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneAbsorb;
                }
                return num1;
            }
        }

        public int ArcaneCostMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneCostMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneCostMalus;
                }
                return num1;
            }
        }

        public int ArcaneCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneCriticalBonus;
                }
                return num1;
            }
        }

        public int ArcaneDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneDamageIncrease;
                }
                return num1;
            }
        }

        public int ArcaneDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneDamageTakenBonus;
                }
                return num1;
            }
        }

        public int ArcaneDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneDamageTakenMalus;
                }
                return num1;
            }
        }

        public int ArcaneResistanceBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneResistanceBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneResistanceBonus;
                }
                return num1;
            }
        }

        public int ArcaneResistanceBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistArcane - this.resistArcane;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int ArcaneResistanceMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArcaneResistanceMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArcaneResistanceMalus;
                }
                return num1;
            }
        }

        public int ArcaneResistanceMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistArcane - this.resistArcane;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public int Armor
        {
            get
            {
                float single1 = 1f;
                return (int) (((((this.armor + (2 * this.Agility)) + ((int) ((this.ArmorFromItems * single1) * (1f + (this.ArmorFromItemsPercentIncrease / 100f))))) + this.ArmorBonus) - this.ArmorMalus) * ((1f + (this.ArmorPercentBonus / 100f)) - (this.ArmorPercentMalus / 100f)));
            }
            set
            {
                this.armor = value;
            }
        }

        public int ArmorBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArmorBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArmorBonus;
                }
                return num1;
            }
        }

        public int ArmorBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = ((this.Armor - this.armor) - (this.Agility * 2)) - this.ArmorFromItems;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int ArmorFromItems
        {
            get
            {
                return this.armorFromItems;
            }
            set
            {
                this.armorFromItems = value;
            }
        }

        public float ArmorFromItemsPercentIncrease
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.ArmorFromItemsPercentIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.ArmorFromItemsPercentIncrease;
                }
                return single1;
            }
        }

        public int ArmorMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ArmorMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ArmorMalus;
                }
                return num1;
            }
        }

        public int ArmorMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = ((this.Armor - this.armor) - (this.Agility * 2)) - this.ArmorFromItems;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public float ArmorPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.ArmorPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.ArmorPercentBonus;
                }
                return single1;
            }
        }

        public float ArmorPercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.ArmorPercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.ArmorPercentMalus;
                }
                return single1;
            }
        }

        public int AttackPower
        {
            get
            {
                int num1 = 0;
                if (!(this is Character))
                {
                    return (int) (((this.attackPower + this.AttackPowerBonus) - this.AttackPowerMalus) * this.AttackPowerModifier);
                }
                switch (this.Classe)
                {
                    case Classes.Warrior:
                    {
                        num1 = ((((this.attackPower + (this.Level * 3)) + (2 * this.Str)) - 20) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Paladin:
                    {
                        num1 = ((((this.attackPower + (this.Level * 3)) + (2 * this.Str)) - 20) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Hunter:
                    {
                        num1 = (((((this.attackPower + (this.Level * 2)) + this.Str) + this.Agility) - 20) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Rogue:
                    {
                        num1 = (((((this.attackPower + (this.Level * 2)) + this.Str) + this.Agility) - 20) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Priest:
                    {
                        num1 = (((this.attackPower + this.Str) - 10) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Shaman:
                    {
                        num1 = ((((this.attackPower + (this.Level * 2)) + (2 * this.Str)) - 20) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Mage:
                    {
                        num1 = (((this.attackPower + this.Str) - 10) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Warlock:
                    {
                        num1 = (((this.attackPower + this.Str) - 10) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                    case Classes.Druid:
                    {
                        num1 = (((this.attackPower + (2 * this.Str)) - 20) + this.AttackPowerBonus) - this.AttackPowerMalus;
                        break;
                    }
                }
                return (int) (num1 * this.AttackPowerModifier);
            }
            set
            {
                this.attackPower = value;
            }
        }

        public int AttackPowerBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerBonus;
                }
                return num1;
            }
        }

        public int AttackPowerBonusAgainsBeast
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerBonusAgainsBeast;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerBonusAgainsBeast;
                }
                return num1;
            }
        }

        public int AttackPowerBonusAgainsDemons
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerBonusAgainsDemons;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerBonusAgainsDemons;
                }
                return num1;
            }
        }

        public int AttackPowerBonusAgainsGiants
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerBonusAgainsGiants;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerBonusAgainsGiants;
                }
                return num1;
            }
        }

        public int AttackPowerBonusAgainsUndead
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerBonusAgainsUndead;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerBonusAgainsUndead;
                }
                return num1;
            }
        }

        public int AttackPowerMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerMalus;
                }
                return num1;
            }
        }

        public int AttackPowerMalusAgainsBeast
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerMalusAgainsBeast;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerMalusAgainsBeast;
                }
                return num1;
            }
        }

        public int AttackPowerMalusAgainsDemons
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerMalusAgainsDemons;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerMalusAgainsDemons;
                }
                return num1;
            }
        }

        public int AttackPowerMalusAgainsGiants
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerMalusAgainsGiants;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerMalusAgainsGiants;
                }
                return num1;
            }
        }

        public int AttackPowerMalusAgainsUndead
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.AttackPowerMalusAgainsUndead;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.AttackPowerMalusAgainsUndead;
                }
                return num1;
            }
        }

        public float AttackPowerModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.AttackPowerModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.AttackPowerModifier;
                }
                return single1;
            }
        }

        public int AttackSpeed
        {
            get
            {
                return (int) (this.attackSpeed * this.AttackSpeedModifier);
            }
            set
            {
                this.attackSpeed = value;
            }
        }

        public float AttackSpeedModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.AttackSpeedModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.AttackSpeedModifier;
                }
                return single1;
            }
        }

        public Mobile AttackTarget
        {
            get
            {
                if ((this.attackTarget is Character) && (this.attackTarget as Character).taxiOn)
                {
                    this.attackTarget = null;
                }
                Mobile mobile1 = this.attackTarget;
                foreach (AuraReleaseTimer timer1 in this.Auras)
                {
                    if (timer1.aura.ForceAttackTo != null)
                    {
                        mobile1 = timer1.aura.ForceAttackTo;
                    }
                }
                return mobile1;
            }
            set
            {
                if (value is Character)
                {
                    if ((value as Character).taxiOn)
                    {
                        this.attackTarget = null;
                    }
                    else
                    {
                        this.attackTarget = value;
                    }
                }
                else
                {
                    this.attackTarget = value;
                }
            }
        }

        public ArrayList Auras
        {
            get
            {
                return this.aura;
            }
        }

        public int[] AvoidCast
        {
            get
            {
                int[] numArray3 = new int[5];
                int[] numArray1 = numArray3;
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (numArray1[num1] != timer1.aura.AvoidCastMagicClass)
                    {
                        continue;
                    }
                    num1++;
                    if (num1 > 4)
                    {
                        return numArray1;
                    }
                    numArray1[num1] = timer1.aura.AvoidCastMagicClass;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (numArray1[num1] == aura1.aura.AvoidCastMagicClass)
                    {
                        num1++;
                        if (num1 > 4)
                        {
                            return numArray1;
                        }
                        numArray1[num1] = aura1.aura.AvoidCastMagicClass;
                    }
                }
                return numArray1;
            }
        }

        public float BaseAgility
        {
            get
            {
                return this.baseAgility;
            }
            set
            {
                this.baseAgility = value;
            }
        }

        public int BaseEnergy
        {
            get
            {
                return this.baseEnergy;
            }
            set
            {
                this.baseEnergy = value;
            }
        }

        public int BaseFocus
        {
            get
            {
                return this.baseFocus;
            }
            set
            {
                this.baseFocus = value;
            }
        }

        public int BaseHitPoints
        {
            get
            {
                return (int) ((((this.itemHealthBonus + this.baseHitPoints) + this.HealthBonus) - this.HealthMalus) * (1f + (this.HealthPercentBonus / 100f)));
            }
            set
            {
                this.baseHitPoints = value;
            }
        }

        public float BaseIq
        {
            get
            {
                return this.baseIq;
            }
            set
            {
                this.baseIq = value;
            }
        }

        public int BaseMana
        {
            get
            {
                switch (this.ManaType)
                {
                    case 0:
                    {
                        int num1 = (int) ((((this.itemManaBonus + this.baseMana) + this.ManaBonus) - this.ManaMalus) * (1f + (this.ManaPercentBonus / 100f)));
                        if (this.HaveTalent(Talents.ArcaneMind))
                        {
                            AuraEffect effect1 = (AuraEffect) this.GetTalentEffect(Talents.ArcaneMind);
                            num1 = (int) (num1 * (1f + (((float) effect1.S1) / 100f)));
                        }
                        return num1;
                    }
                    case 1:
                    {
                        return (int) ((((this.itemManaBonus + this.baseRage) + this.ManaBonus) - this.ManaMalus) * (1f + (this.ManaPercentBonus / 100f)));
                    }
                    case 3:
                    {
                        return (int) ((((this.itemManaBonus + this.baseEnergy) + this.ManaBonus) - this.ManaMalus) * (1f + (this.ManaPercentBonus / 100f)));
                    }
                }
                return 0;
            }
            set
            {
                switch (this.ManaType)
                {
                    case 0:
                    {
                        this.baseMana = value;
                        return;
                    }
                    case 1:
                    {
                        this.baseRage = value;
                        return;
                    }
                    case 2:
                    {
                        return;
                    }
                    case 3:
                    {
                        this.baseEnergy = value;
                        return;
                    }
                }
            }
        }

        public int BaseRage
        {
            get
            {
                return this.baseRage;
            }
            set
            {
                this.baseRage = value;
            }
        }

        public float BaseSpirit
        {
            get
            {
                return this.baseSpirit;
            }
            set
            {
                this.baseSpirit = value;
            }
        }

        public float BaseStamina
        {
            get
            {
                return this.baseStamina;
            }
            set
            {
                this.baseStamina = value;
            }
        }

        public float BaseStr
        {
            get
            {
                return this.baseStr;
            }
            set
            {
                this.baseStr = value;
            }
        }

        public int Block
        {
            get
            {
                return (int) ((this.block + this.ShieldBlockBonus) * this.ShieldBlockModifier);
            }
            set
            {
                this.block = value;
            }
        }

        public int BlockBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.BlockBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.BlockBonus;
                }
                return num1;
            }
        }

        public int BlockMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.BlockMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.BlockMalus;
                }
                return num1;
            }
        }

        public float BoundingRadius
        {
            get
            {
                return this.boundingRadius;
            }
            set
            {
                this.boundingRadius = value;
            }
        }

        public bool CanSeeGreaterInvisibility
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.CanSeeGreaterInvisibility)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool CanSeeLesserInvisibility
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.CanSeeLesserInvisibility)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool CanSeeMediumInvisibility
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.CanSeeMediumInvisibility)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public int CastingSpeed
        {
            get
            {
                return (int) (this.castingSpeed * this.CastingSpeedModifier);
            }
            set
            {
                this.castingSpeed = value;
            }
        }

        public float CastingSpeedModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.CastingSpeedModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.CastingSpeedModifier;
                }
                return single1;
            }
        }

        public Channeling Chan
        {
            get
            {
                return this.chan;
            }
        }

        public Mobile Charm
        {
            get
            {
                return this.charm;
            }
            set
            {
                this.charm = value;
            }
        }

        public Mobile CharmedBy
        {
            get
            {
                return this.charmedBy;
            }
            set
            {
                this.charmedBy = value;
            }
        }

        public Classes Classe
        {
            get
            {
                return this.classe;
            }
            set
            {
                this.classe = value;
            }
        }

        public float CombatReach
        {
            get
            {
                return this.combatReach;
            }
            set
            {
                this.combatReach = value;
            }
        }

        public int ComboPoints
        {
            get
            {
                return this.comboPoints;
            }
        }

        public Hashtable CumulativeAuraEffects
        {
            get
            {
                return this.cumulativeAuraEffects;
            }
        }

        public int DamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.DamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.DamageTakenBonus;
                }
                return num1;
            }
        }

        public int DamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.DamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.DamageTakenMalus;
                }
                return num1;
            }
        }

        public float DamageTakenModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.DamageTakenModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.DamageTakenModifier;
                }
                return single1;
            }
        }

        public bool Dead
        {
            get
            {
                if (this.hitPoints <= 0)
                {
                    return true;
                }
                return false;
            }
        }

        public bool Deleted
        {
            get
            {
                return this.deleted;
            }
        }

        public bool DetectBeast
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.DetectBeast)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool DetectHumanoid
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.DetectHumanoid)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool DetectUndead
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.DetectUndead)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public int DodgeBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.DodgeBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.DodgeBonus;
                }
                return num1;
            }
        }

        public int DodgeMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.DodgeMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.DodgeMalus;
                }
                return num1;
            }
        }

        public int Elite
        {
            get
            {
                return this.unk4;
            }
            set
            {
                this.unk4 = value;
            }
        }

        public int Energy
        {
            get
            {
                return this.energy;
            }
            set
            {
                this.energy = value;
            }
        }

        public uint Exp
        {
            get
            {
                return this.exp;
            }
            set
            {
                this.exp = value;
            }
        }

        public Factions Faction
        {
            get
            {
                return this.faction;
            }
            set
            {
                this.faction = value;
            }
        }

        public int Family
        {
            get
            {
                return this.unk3;
            }
            set
            {
                this.unk3 = value;
            }
        }

        public bool FeatherFall
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.FeatherFall)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public int FireAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireAbsorb;
                }
                return num1;
            }
        }

        public int FireCostMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireCostMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireCostMalus;
                }
                return num1;
            }
        }

        public int FireCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireCriticalBonus;
                }
                return num1;
            }
        }

        public int FireDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireDamageIncrease;
                }
                return num1;
            }
        }

        public int FireDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireDamageTakenBonus;
                }
                return num1;
            }
        }

        public int FireDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireDamageTakenMalus;
                }
                return num1;
            }
        }

        public float FireDamageTakenModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.FireDamageTakenModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.FireDamageTakenModifier;
                }
                return single1;
            }
        }

        public float FirePercentDamageIncrease
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.FirePercentDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.FirePercentDamageIncrease;
                }
                return single1;
            }
        }

        public int FireResistanceBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireResistanceBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireResistanceBonus;
                }
                return num1;
            }
        }

        public int FireResistanceBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistFire - this.resistFire;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int FireResistanceMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FireResistanceMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FireResistanceMalus;
                }
                return num1;
            }
        }

        public int FireResistanceMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistFire - this.resistFire;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public virtual uint Flags
        {
            get
            {
                uint num1 = 0;
                if (this.MountModel != 0)
                {
                    num1 |= 0x3000;
                }
                if (this.Dead)
                {
                    num1 |= 0x4000;
                }
                if ((this.Freeze || this.ForceRoot) || this.ForceStun)
                {
                    num1 |= 4;
                }
                if ((this.SkinLoot != null) && this.Dead)
                {
                    num1 |= 0x4000000;
                }
                if (!(this is Character))
                {
                    return num1;
                }
                if (!(this as Character).PvpActive)
                {
                    return (num1 + 0x1000);
                }
                return (num1 + 8);
            }
        }

        public uint Flags1
        {
            get
            {
                return this.flags1;
            }
            set
            {
                this.flags1 = value;
            }
        }

        public int Focus
        {
            get
            {
                return this.focus;
            }
            set
            {
                this.focus = value;
            }
        }

        public bool ForceFlee
        {
            get
            {
                if (!this.ImmuneToFear)
                {
                    foreach (AuraReleaseTimer timer1 in this.aura)
                    {
                        if (timer1.aura.ForceFlee)
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
        }

        public bool ForceRoot
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ForceRoot)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ForceSilence
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ForceSilence)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ForceStun
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ForceStun)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool Freeze
        {
            get
            {
                return this.freeze;
            }
            set
            {
                this.freeze = value;
            }
        }

        public int FrostAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostAbsorb;
                }
                return num1;
            }
        }

        public int FrostCostMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostCostMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostCostMalus;
                }
                return num1;
            }
        }

        public int FrostCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostCriticalBonus;
                }
                return num1;
            }
        }

        public int FrostDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostDamageIncrease;
                }
                return num1;
            }
        }

        public int FrostDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostDamageTakenBonus;
                }
                return num1;
            }
        }

        public int FrostDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostDamageTakenMalus;
                }
                return num1;
            }
        }

        public float FrostPercentDamageIncrease
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.FrostPercentDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.FrostPercentDamageIncrease;
                }
                return single1;
            }
        }

        public int FrostResistanceBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostResistanceBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostResistanceBonus;
                }
                return num1;
            }
        }

        public int FrostResistanceBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistFrost - this.resistFrost;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int FrostResistanceMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.FrostResistanceMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.FrostResistanceMalus;
                }
                return num1;
            }
        }

        public int FrostResistanceMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistFrost - this.resistFrost;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public bool GodMode
        {
            get
            {
                return this.godMode;
            }
            set
            {
                this.godMode = value;
            }
        }

        public string Guild
        {
            get
            {
                return this.guild;
            }
            set
            {
                this.guild = value;
            }
        }

        public uint GuildId
        {
            get
            {
                return this.guildId;
            }
            set
            {
                this.guildId = value;
            }
        }

        public int HealGiveDecrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HealGiveDecrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HealGiveDecrease;
                }
                return num1;
            }
        }

        public int HealGiveIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HealGiveIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HealGiveIncrease;
                }
                return num1;
            }
        }

        public float HealGiveModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.HealGiveModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.HealGiveModifier;
                }
                return single1;
            }
        }

        public int HealTakeDecrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HealTakeDecrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HealTakeDecrease;
                }
                return num1;
            }
        }

        public int HealTakeIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HealTakeIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HealTakeIncrease;
                }
                return num1;
            }
        }

        public float HealTakeModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.HealTakeModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.HealTakeModifier;
                }
                return single1;
            }
        }

        public int HealthBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HealthBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HealthBonus;
                }
                return num1;
            }
        }

        public int HealthMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HealthMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HealthMalus;
                }
                return num1;
            }
        }

        public float HealthPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.HealthPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.HealthPercentBonus;
                }
                return single1;
            }
        }

        public float HealthRegenerationModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.HealthRegenerationModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.HealthRegenerationModifier;
                }
                return single1;
            }
        }

        public float HealthRegenWhileFightingPercent
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.HealthRegenWhileFightingPercent;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.HealthRegenWhileFightingPercent;
                }
                return single1;
            }
        }

        public int HitBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HitBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HitBonus;
                }
                return num1;
            }
        }

        public int HitMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HitMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HitMalus;
                }
                return num1;
            }
        }

        public int HitPoints
        {
            get
            {
                return this.hitPoints;
            }
            set
            {
                this.hitPoints = value;
            }
        }

        public int HolyAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyAbsorb;
                }
                return num1;
            }
        }

        public int HolyCostMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyCostMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyCostMalus;
                }
                return num1;
            }
        }

        public int HolyCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyCriticalBonus;
                }
                return num1;
            }
        }

        public int HolyDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyDamageIncrease;
                }
                return num1;
            }
        }

        public int HolyDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyDamageTakenBonus;
                }
                return num1;
            }
        }

        public int HolyDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyDamageTakenMalus;
                }
                return num1;
            }
        }

        public int HolyResistanceBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyResistanceBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyResistanceBonus;
                }
                return num1;
            }
        }

        public int HolyResistanceBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistHoly - this.resistHoly;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int HolyResistanceMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.HolyResistanceMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.HolyResistanceMalus;
                }
                return num1;
            }
        }

        public int HolyResistanceMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistHoly - this.resistHoly;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public int Id
        {
            get
            {
                return this.id;
            }
            set
            {
                this.id = value;
            }
        }

        public bool ImmuneAllSpellsAndAbilites
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneAllSpellsAndAbilites)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneAllSpellsAndAbilites)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneAttack
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneAttack)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneAttack)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneDisease
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneDisease)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneDisease)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneFireSpell
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneFireSpell)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneFireSpell)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneFrostSpell
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneFrostSpell)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneFrostSpell)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneMagic
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneMagic)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneMagic)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmunePhysicalDamage
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmunePhysicalDamage)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmunePhysicalDamage)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmunePoison
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmunePoison)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmunePoison)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneToDisarm
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneToDisarm)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneToDisarm)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneToFear
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneToFear)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneToFear)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneToImmobilization
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneToImmobilization)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneToImmobilization)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ImmuneToKnockBack
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ImmuneToKnockBack)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ImmuneToKnockBack)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool InCombat
        {
            get
            {
                if (((this.AIState == AIStates.BeingAttacked) || (this.AIState == AIStates.Fighting)) || (this.AIState == AIStates.Attack))
                {
                    return true;
                }
                TimeSpan span1 = DateTime.Now.Subtract(this.lastHit);
                if (span1.TotalSeconds < 10)
                {
                    return true;
                }
                return false;
            }
        }

        public bool InteruptRegeneration
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.InteruptRegeneration)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.InteruptRegeneration)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public int Iq
        {
            get
            {
                return (int) (((((((this.iq + this.IQBonus) + ((int) this.baseIq)) - this.IQMalus) + this.AllAtributesBonus) - this.AllAtributesMalus) * ((1f + (this.IQPercentBonus / 100f)) - (this.IQPercentMalus / 100f))) * ((1f + (this.AllAtributesPercentBonus / 100f)) - (this.AllAtributesPercentMalus / 100f)));
            }
            set
            {
                this.iq = value;
            }
        }

        public int IQBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.IQBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.IQBonus;
                }
                return num1;
            }
        }

        public int IQMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.IQMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.IQMalus;
                }
                return num1;
            }
        }

        public float IQPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.IQPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.IQPercentBonus;
                }
                return single1;
            }
        }

        public float IQPercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.IQPercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.IQPercentMalus;
                }
                return single1;
            }
        }

        public bool IsCasting
        {
            get
            {
                if (this.cast.id != 0)
                {
                    return true;
                }
                return false;
            }
        }

        public Item[] Items
        {
            get
            {
                return this.items;
            }
            set
            {
                this.items = value;
            }
        }

        public Hashtable KnownAbilities
        {
            get
            {
                return this.knownAbilities;
            }
        }

        public virtual ArrayList KnownObjects
        {
            get
            {
                if (this.lastSeen != null)
                {
                    return this.lastSeen.KnownObjects;
                }
                return null;
            }
        }

        public AttackStatus LastAttackStatus
        {
            get
            {
                return this.lastAttack;
            }
        }

        public AttackStatus LastAttackToMe
        {
            get
            {
                return this.lastAttackToMe;
            }
        }

        public Mobile LastOffender
        {
            get
            {
                return this.lastOffender;
            }
            set
            {
                this.lastOffender = value;
            }
        }

        public Character LastSeen
        {
            get
            {
                return this.lastSeen;
            }
            set
            {
                this.lastSeen = value;
            }
        }

        public int Level
        {
            get
            {
                return this.level;
            }
            set
            {
                this.level = value;
            }
        }

        public int LootMoney
        {
            get
            {
                return this.lootMoney;
            }
            set
            {
                this.lootMoney = value;
            }
        }

        public BaseTreasure[] Loots
        {
            get
            {
                return this.loots;
            }
            set
            {
                this.loots = value;
            }
        }

        public int MagicalCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MagicalCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MagicalCriticalBonus;
                }
                return num1;
            }
        }

        public int Mana
        {
            get
            {
                switch (this.ManaType)
                {
                    case 0:
                    {
                        return this.mana;
                    }
                    case 1:
                    {
                        return this.rage;
                    }
                    case 3:
                    {
                        return this.energy;
                    }
                }
                return 0;
            }
            set
            {
                switch (this.ManaType)
                {
                    case 0:
                    {
                        this.mana = value;
                        return;
                    }
                    case 1:
                    {
                        this.rage = value;
                        return;
                    }
                    case 2:
                    {
                        return;
                    }
                    case 3:
                    {
                        this.energy = value;
                        return;
                    }
                }
            }
        }

        public int ManaBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ManaBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ManaBonus;
                }
                return num1;
            }
        }

        public int ManaMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ManaMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ManaMalus;
                }
                return num1;
            }
        }

        public float ManaPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.ManaPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.ManaPercentBonus;
                }
                return single1;
            }
        }

        public float ManaRegenerationModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.ManaRegenerationModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.ManaRegenerationModifier;
                }
                return single1;
            }
        }

        public float ManaRegenWhileCastingPercent
        {
            get
            {
                float single1 = 0f;
                if (this.HaveTalent(Talents.ArcaneMeditation))
                {
                    AuraEffect effect1 = (AuraEffect) this.GetTalentEffect(Talents.ArcaneMeditation);
                    single1 += effect1.S1;
                }
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.ManaRegenWhileCastingPercent;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.ManaRegenWhileCastingPercent;
                }
                return single1;
            }
        }

        public int ManaShield
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ManaShield;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ManaShield;
                }
                return num1;
            }
        }

        public int ManaType
        {
            get
            {
                return this.manaType;
            }
            set
            {
                this.manaType = value;
            }
        }

        public float MaxDamage
        {
            get
            {
                return this.maxDamage;
            }
            set
            {
                this.maxDamage = value;
            }
        }

        public int MeleeDamageBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageDoneAgainsBeastBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageDoneAgainsBeastBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageDoneAgainsBeastBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageDoneAgainsDemonsBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageDoneAgainsDemonsBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageDoneAgainsDemonsBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageDoneAgainsDragonsBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageDoneAgainsDragonsBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageDoneAgainsDragonsBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageDoneAgainsElementalsBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageDoneAgainsElementalsBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageDoneAgainsElementalsBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageDoneAgainsGiantsBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageDoneAgainsGiantsBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageDoneAgainsGiantsBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageDoneAgainsUndeadBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageDoneAgainsUndeadBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageDoneAgainsUndeadBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageMalus;
                }
                return num1;
            }
        }

        public int MeleeDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageTakenBonus;
                }
                return num1;
            }
        }

        public int MeleeDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeDamageTakenMalus;
                }
                return num1;
            }
        }

        public int MeleeHitBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeHitBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeHitBonus;
                }
                return num1;
            }
        }

        public int MeleeHitMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.MeleeHitMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.MeleeHitMalus;
                }
                return num1;
            }
        }

        public float MeleePercentDamageBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.MeleePercentDamageBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.MeleePercentDamageBonus;
                }
                return single1;
            }
        }

        public float MeleePercentDamageMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.MeleePercentDamageMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.MeleePercentDamageMalus;
                }
                return single1;
            }
        }

        public float MeleePercentDamageTakenIncrease
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.MeleePercentDamageTakenIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.MeleePercentDamageTakenIncrease;
                }
                return single1;
            }
        }

        public float MeleePercentDamageTakenReduction
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.MeleePercentDamageTakenReduction;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.MeleePercentDamageTakenReduction;
                }
                return single1;
            }
        }

        public float MinDamage
        {
            get
            {
                return this.minDamage;
            }
            set
            {
                this.minDamage = value;
            }
        }

        public int Model
        {
            get
            {
                return this.model;
            }
            set
            {
                this.model = value;
            }
        }

        public Mobile Mounting
        {
            get
            {
                return this.mounting;
            }
            set
            {
                this.mounting = value;
            }
        }

        public int MountModel
        {
            get
            {
                return this.mountModel;
            }
            set
            {
                this.mountModel = value;
            }
        }

        public float MountSpeedBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.MountSpeedBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.MountSpeedBonus;
                }
                return single1;
            }
        }

        public float MountSpeedMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.MountSpeedMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.MountSpeedMalus;
                }
                return single1;
            }
        }

        public float MountSpeedModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.MountSpeedModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.MountSpeedModifier;
                }
                return single1;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
            set
            {
                this.name = value;
            }
        }

        public string Name2
        {
            get
            {
                return this.name2;
            }
            set
            {
                this.name2 = value;
            }
        }

        public int NatureAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureAbsorb;
                }
                return num1;
            }
        }

        public int NatureCostMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureCostMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureCostMalus;
                }
                return num1;
            }
        }

        public int NatureCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureCriticalBonus;
                }
                return num1;
            }
        }

        public int NatureDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureDamageIncrease;
                }
                return num1;
            }
        }

        public int NatureDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureDamageTakenBonus;
                }
                return num1;
            }
        }

        public int NatureDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureDamageTakenMalus;
                }
                return num1;
            }
        }

        public float NaturePercentDamageIncrease
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.NaturePercentDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.NaturePercentDamageIncrease;
                }
                return single1;
            }
        }

        public int NatureResistanceBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureResistanceBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureResistanceBonus;
                }
                return num1;
            }
        }

        public int NatureResistanceBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistNature - this.resistNature;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int NatureResistanceMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.NatureResistanceMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.NatureResistanceMalus;
                }
                return num1;
            }
        }

        public int NatureResistanceMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistNature - this.resistNature;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public ArrayList NextAttackEffects
        {
            get
            {
                return this.nextAttackEffects;
            }
        }

        public uint NpcFlags
        {
            get
            {
                return this.npcFlags;
            }
            set
            {
                this.npcFlags = value;
            }
        }

        public string NpcText
        {
            get
            {
                return this.npcText;
            }
            set
            {
                this.npcText = value;
            }
        }

        public int NpcType
        {
            get
            {
                return this.npcType;
            }
            set
            {
                this.npcType = value;
            }
        }

        public byte nProfessions
        {
            get
            {
                return this.professions;
            }
            set
            {
                this.professions = value;
            }
        }

        public int ParryBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ParryBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ParryBonus;
                }
                return num1;
            }
        }

        public int ParryMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ParryMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ParryMalus;
                }
                return num1;
            }
        }

        public ArrayList PermanentAuras
        {
            get
            {
                return this.permanentAura;
            }
        }

        public uint PetCreatureFamily
        {
            get
            {
                return this.petCreatureFamily;
            }
            set
            {
                this.petCreatureFamily = value;
            }
        }

        public int PetDamageBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.PetDamageBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.PetDamageBonus;
                }
                return num1;
            }
        }

        public int PetDamageMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.PetDamageMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.PetDamageMalus;
                }
                return num1;
            }
        }

        public uint PetDisplayId
        {
            get
            {
                return this.petDisplayId;
            }
            set
            {
                this.petDisplayId = value;
            }
        }

        public uint PetLevel
        {
            get
            {
                return this.petLevel;
            }
            set
            {
                this.petLevel = value;
            }
        }

        public int PhysicalAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.PhysicalAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.PhysicalAbsorb;
                }
                return num1;
            }
        }

        public int PhysicalCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.PhysicalCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.PhysicalCriticalBonus;
                }
                return num1;
            }
        }

        public int PhysicalDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.PhysicalDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.PhysicalDamageIncrease;
                }
                return num1;
            }
        }

        public int PhysicalDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.PhysicalDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.PhysicalDamageTakenBonus;
                }
                return num1;
            }
        }

        public int PhysicalDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.PhysicalDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.PhysicalDamageTakenMalus;
                }
                return num1;
            }
        }

        public float PhysicalPercentDamageIncrease
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.PhysicalPercentDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.PhysicalPercentDamageIncrease;
                }
                return single1;
            }
        }

        public float PowerCostModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.PowerCostModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.PowerCostModifier;
                }
                return single1;
            }
        }

        public int Quest
        {
            get
            {
                return this.quest;
            }
            set
            {
                this.quest = value;
            }
        }

        public int Rage
        {
            get
            {
                return this.rage;
            }
            set
            {
                this.rage = value;
            }
        }

        public float RageGenerationModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.RageGenerationModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.RageGenerationModifier;
                }
                return single1;
            }
        }

        public int RangedAttackPower
        {
            get
            {
                if (this is Character)
                {
                    return (((((this.rangedAttackPower + (this.Level * 2)) + (this.Agility * 2)) - 20) + this.RangedAttackPowerBonus) - this.RangedAttackPowerMalus);
                }
                return ((this.rangedAttackPower + this.RangedAttackPowerBonus) - this.RangedAttackPowerMalus);
            }
            set
            {
                this.rangedAttackPower = value;
            }
        }

        public int RangedAttackPowerBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.RangedAttackPowerBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.RangedAttackPowerBonus;
                }
                return num1;
            }
        }

        public int RangedAttackPowerMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.RangedAttackPowerMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.RangedAttackPowerMalus;
                }
                return num1;
            }
        }

        public int RangedAttackSpeed
        {
            get
            {
                return (int) (this.rangedAttackSpeed * this.RangedAttackSpeedModifier);
            }
            set
            {
                this.rangedAttackSpeed = value;
            }
        }

        public float RangedAttackSpeedModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.RangedAttackSpeedModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.RangedAttackSpeedModifier;
                }
                return single1;
            }
        }

        public int RangedDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.RangedDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.RangedDamageTakenBonus;
                }
                return num1;
            }
        }

        public int RangedDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.RangedDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.RangedDamageTakenMalus;
                }
                return num1;
            }
        }

        public float RangedDamageTakenModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.RangedDamageTakenModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.RangedDamageTakenModifier;
                }
                return single1;
            }
        }

        public int RangedHitBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.RangedHitBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.RangedHitBonus;
                }
                return num1;
            }
        }

        public int RangedHitMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.RangedHitMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.RangedHitMalus;
                }
                return num1;
            }
        }

        public static float[,] Reactions
        {
            get
            {
                return Mobile.reactions;
            }
        }

        public int ReflectFireChance
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ReflectFireChance;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ReflectFireChance;
                }
                return num1;
            }
        }

        public int ReflectFrostChance
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ReflectFrostChance;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ReflectFrostChance;
                }
                return num1;
            }
        }

        public int ReflectMagicChance
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ReflectMagicChance;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ReflectMagicChance;
                }
                return num1;
            }
        }

        public int ReflectShadowChance
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ReflectShadowChance;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ReflectShadowChance;
                }
                return num1;
            }
        }

        public int ResistArcane
        {
            get
            {
                return (int) (((((this.resistArcane + this.ArcaneResistanceBonus) - this.ArcaneResistanceMalus) + this.AllResistanceBonus) - this.AllResistanceMalus) * ((1f + (this.AllResistancePercentBonus / 100f)) - (this.AllResistancePercentMalus / 100f)));
            }
            set
            {
                this.resistArcane = value;
            }
        }

        public int ResistFire
        {
            get
            {
                return (int) (((((this.resistFire + this.FireResistanceBonus) - this.FireResistanceMalus) + this.AllResistanceBonus) - this.AllResistanceMalus) * ((1f + (this.AllResistancePercentBonus / 100f)) - (this.AllResistancePercentMalus / 100f)));
            }
            set
            {
                this.resistFire = value;
            }
        }

        public int ResistFrost
        {
            get
            {
                return (int) (((((this.resistFrost + this.FrostResistanceBonus) - this.FrostResistanceMalus) + this.AllResistanceBonus) - this.AllResistanceMalus) * ((1f + (this.AllResistancePercentBonus / 100f)) - (this.AllResistancePercentMalus / 100f)));
            }
            set
            {
                this.resistFrost = value;
            }
        }

        public int ResistHoly
        {
            get
            {
                return (int) (((((this.resistHoly + this.HolyResistanceBonus) - this.HolyResistanceMalus) + this.AllResistanceBonus) - this.AllResistanceMalus) * ((1f + (this.AllResistancePercentBonus / 100f)) - (this.AllResistancePercentMalus / 100f)));
            }
            set
            {
                this.resistHoly = value;
            }
        }

        public int ResistNature
        {
            get
            {
                return (int) (((((this.resistNature + this.NatureResistanceBonus) - this.NatureResistanceMalus) + this.AllResistanceBonus) - this.AllResistanceMalus) * ((1f + (this.AllResistancePercentBonus / 100f)) - (this.AllResistancePercentMalus / 100f)));
            }
            set
            {
                this.resistNature = value;
            }
        }

        public int ResistShadow
        {
            get
            {
                return (int) (((((this.resistShadow + this.ShadowResistanceBonus) - this.ShadowResistanceMalus) + this.AllResistanceBonus) - this.AllResistanceMalus) * ((1f + (this.AllResistancePercentBonus / 100f)) - (this.AllResistancePercentMalus / 100f)));
            }
            set
            {
                this.resistShadow = value;
            }
        }

        public bool Running
        {
            get
            {
                return this.running;
            }
            set
            {
                this.running = value;
            }
        }

        public float RunSpeed
        {
            get
            {
                return ((((this.runSpeed + this.RunSpeedBonus) - this.RunSpeedMalus) * this.SpeedModifier) * this.RunSpeedModifier);
            }
            set
            {
                this.runSpeed = value;
            }
        }

        public float RunSpeedBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.RunSpeedBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.RunSpeedBonus;
                }
                return single1;
            }
        }

        public float RunSpeedMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.RunSpeedMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.RunSpeedMalus;
                }
                return single1;
            }
        }

        public float RunSpeedModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.RunSpeedModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.RunSpeedModifier;
                }
                return single1;
            }
        }

        public Item[] Sells
        {
            get
            {
                return this.sells;
            }
            set
            {
                this.sells = value;
            }
        }

        public int ShadowAbsorb
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowAbsorb;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowAbsorb;
                }
                return num1;
            }
        }

        public int ShadowCostMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowCostMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowCostMalus;
                }
                return num1;
            }
        }

        public int ShadowCriticalBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowCriticalBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowCriticalBonus;
                }
                return num1;
            }
        }

        public int ShadowDamageIncrease
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowDamageIncrease;
                }
                return num1;
            }
        }

        public int ShadowDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowDamageTakenBonus;
                }
                return num1;
            }
        }

        public int ShadowDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowDamageTakenMalus;
                }
                return num1;
            }
        }

        public float ShadowDamageTakenModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.ShadowDamageTakenModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.ShadowDamageTakenModifier;
                }
                return single1;
            }
        }

        public float ShadowPercentDamageIncrease
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.ShadowPercentDamageIncrease;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.ShadowPercentDamageIncrease;
                }
                return single1;
            }
        }

        public int ShadowResistanceBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowResistanceBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowResistanceBonus;
                }
                return num1;
            }
        }

        public int ShadowResistanceBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistShadow - this.resistShadow;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int ShadowResistanceMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShadowResistanceMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShadowResistanceMalus;
                }
                return num1;
            }
        }

        public int ShadowResistanceMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = this.ResistShadow - this.resistShadow;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public bool ShadowTrance
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ShadowTrance)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool ShareDamageWithPet
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ShareDamageWithPet)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public int ShieldBlockBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.ShieldBlockBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.ShieldBlockBonus;
                }
                return num1;
            }
        }

        public float ShieldBlockModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.ShieldBlockModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.ShieldBlockModifier;
                }
                return single1;
            }
        }

        public float Size
        {
            get
            {
                return this.size;
            }
            set
            {
                this.size = value;
            }
        }

        public Loot[] SkinLoot
        {
            get
            {
                return this.skinLoot;
            }
            set
            {
                this.skinLoot = value;
            }
        }

        public bool Skinned
        {
            get
            {
                if (this.SkinLoot != null)
                {
                    return false;
                }
                return true;
            }
            set
            {
                if (value)
                {
                    this.SkinLoot = null;
                }
            }
        }

        public float Speed
        {
            get
            {
                return (((this.speed + this.SpeedBonus) - this.SpeedMalus) * this.SpeedModifier);
            }
            set
            {
                this.speed = value;
            }
        }

        public float SpeedBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.SpeedBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.SpeedBonus;
                }
                return single1;
            }
        }

        public float SpeedMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.SpeedMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.SpeedMalus;
                }
                return single1;
            }
        }

        public float SpeedModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.SpeedModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.SpeedModifier;
                }
                return single1;
            }
        }

        public int SpellDamageDoneAgainsDemonsBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpellDamageDoneAgainsDemonsBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpellDamageDoneAgainsDemonsBonus;
                }
                return num1;
            }
        }

        public int SpellDamageDoneAgainsUndeadBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpellDamageDoneAgainsUndeadBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpellDamageDoneAgainsUndeadBonus;
                }
                return num1;
            }
        }

        public int SpellDamageTakenBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpellDamageTakenBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpellDamageTakenBonus;
                }
                return num1;
            }
        }

        public int SpellDamageTakenMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpellDamageTakenMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpellDamageTakenMalus;
                }
                return num1;
            }
        }

        public int SpellHitBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpellHitBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpellHitBonus;
                }
                return num1;
            }
        }

        public int SpellHitMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpellHitMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpellHitMalus;
                }
                return num1;
            }
        }

        protected SpellCastTimer SpellTimer
        {
            get
            {
                return this.spellCastTimer;
            }
        }

        public int Spirit
        {
            get
            {
                float single1 = 1f;
                if ((this.Classe == Classes.Warlock) && this.HaveTalent(Talents.DemonicEmbrace))
                {
                    AuraEffect effect1 = (AuraEffect) this.GetTalentEffect(Talents.DemonicEmbrace);
                    single1 *= (1f + (((float) effect1.S1) / 100f));
                }
                return (int) ((((((((this.spirit + this.SpiritBonus) + ((int) this.baseSpirit)) - this.SpiritMalus) + this.AllAtributesBonus) - this.AllAtributesMalus) * ((1f + (this.SpiritPercentBonus / 100f)) - (this.SpiritPercentMalus / 100f))) * ((1f + (this.AllAtributesPercentBonus / 100f)) - (this.AllAtributesPercentMalus / 100f))) * single1);
            }
            set
            {
                this.spirit = value;
            }
        }

        public int SpiritBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpiritBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpiritBonus;
                }
                return num1;
            }
        }

        public int SpiritMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.SpiritMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.SpiritMalus;
                }
                return num1;
            }
        }

        public float SpiritPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.SpiritPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.SpiritPercentBonus;
                }
                return single1;
            }
        }

        public float SpiritPercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.SpiritPercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.SpiritPercentMalus;
                }
                return single1;
            }
        }

        public int Stamina
        {
            get
            {
                float single1 = 1f;
                if ((this.Classe == Classes.Warlock) && this.HaveTalent(Talents.DemonicEmbrace))
                {
                    AuraEffect effect1 = (AuraEffect) this.GetTalentEffect(Talents.DemonicEmbrace);
                    single1 *= (1f + (((float) effect1.S1) / 100f));
                }
                return (int) ((((((((this.stamina + this.StaminaBonus) + ((int) this.baseStamina)) - this.StaminaMalus) + this.AllAtributesBonus) - this.AllAtributesMalus) * ((1f + (this.StaminaPercentBonus / 100f)) - (this.StaminaPercentMalus / 100f))) * ((1f + (this.AllAtributesPercentBonus / 100f)) - (this.AllAtributesPercentMalus / 100f))) * single1);
            }
            set
            {
                this.stamina = value;
            }
        }

        public int StaminaBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.StaminaBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.StaminaBonus;
                }
                return num1;
            }
        }

        public int StaminaMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.StaminaMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.StaminaMalus;
                }
                return num1;
            }
        }

        public float StaminaPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.StaminaPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.StaminaPercentBonus;
                }
                return single1;
            }
        }

        public float StaminaPercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.StaminaPercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.StaminaPercentMalus;
                }
                return single1;
            }
        }

        public StandStates StandState
        {
            get
            {
                return this.standState;
            }
            set
            {
                this.standState = value;
            }
        }

        public int Str
        {
            get
            {
                return (int) (((((((this.str + this.StrBonus) + ((int) this.baseStr)) - this.StrMalus) + this.AllAtributesBonus) - this.AllAtributesMalus) * ((1f + (this.StrPercentBonus / 100f)) - (this.StrPercentMalus / 100f))) * ((1f + (this.AllAtributesPercentBonus / 100f)) - (this.AllAtributesPercentMalus / 100f)));
            }
            set
            {
                this.str = value;
            }
        }

        public int StrBonus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.StrBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.StrBonus;
                }
                return num1;
            }
        }

        public int StrMalus
        {
            get
            {
                int num1 = 0;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    num1 += timer1.aura.StrMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    num1 += aura1.aura.StrMalus;
                }
                return num1;
            }
        }

        public float StrPercentBonus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.StrPercentBonus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.StrPercentBonus;
                }
                return single1;
            }
        }

        public float StrPercentMalus
        {
            get
            {
                float single1 = 0f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 += timer1.aura.StrPercentMalus;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 += aura1.aura.StrPercentMalus;
                }
                return single1;
            }
        }

        public Mobile Summon
        {
            get
            {
                return this.summon;
            }
            set
            {
                this.summon = value;
            }
        }

        public Mobile SummonedBy
        {
            get
            {
                return this.summonedBy;
            }
            set
            {
                this.summonedBy = value;
            }
        }

        public float SwimBackSpeed
        {
            get
            {
                return ((this.swimBackSpeed * this.SpeedModifier) * this.SwimSpeedModifier);
            }
            set
            {
                this.swimBackSpeed = value;
            }
        }

        public float SwimSpeed
        {
            get
            {
                return ((this.swimSpeed * this.SpeedModifier) * this.SwimSpeedModifier);
            }
            set
            {
                this.swimSpeed = value;
            }
        }

        public float SwimSpeedModifier
        {
            get
            {
                float single1 = 1f;
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    single1 *= timer1.aura.SwimSpeedModifier;
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    single1 *= aura1.aura.SwimSpeedModifier;
                }
                return single1;
            }
        }

        public bool SwitchToRage
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.SwitchToRage)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.SwitchToRage)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public int Talent
        {
            get
            {
                return this.talent;
            }
            set
            {
                this.talent = value;
            }
        }

        public Hashtable TalentList
        {
            get
            {
                return this.talentList;
            }
        }

        public int[] Trains
        {
            get
            {
                return this.trains;
            }
            set
            {
                this.trains = value;
            }
        }

        public bool UnInteractible
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.ForceUnInteractible)
                    {
                        return true;
                    }
                }
                foreach (PermanentAura aura1 in this.permanentAura)
                {
                    if (aura1.aura.ForceUnInteractible)
                    {
                        return true;
                    }
                }
                return this.unInteractible;
            }
            set
            {
                this.unInteractible = value;
            }
        }

        public int Unk3
        {
            get
            {
                return this.unk3;
            }
            set
            {
                this.unk3 = value;
            }
        }

        public int Unk4
        {
            get
            {
                return this.unk4;
            }
            set
            {
                this.unk4 = value;
            }
        }

        public object Value
        {
            get
            {
                return this.values;
            }
            set
            {
                this.values = value;
            }
        }

        public InvisibilityLevel Visible
        {
            get
            {
                return this.visible;
            }
            set
            {
                this.visible = value;
            }
        }

        public float WalkSpeed
        {
            get
            {
                return (this.walkSpeed * this.SpeedModifier);
            }
            set
            {
                this.walkSpeed = value;
            }
        }

        public bool WaterWalking
        {
            get
            {
                foreach (AuraReleaseTimer timer1 in this.aura)
                {
                    if (timer1.aura.WaterWalking)
                    {
                        return true;
                    }
                }
                return false;
            }
        }


        // Fields
        public static uint aa;
        protected Item activeShield;
        protected Item activeWeapon;
        private ArrayList additionnalStates;
        private int agility;
        private AIStates aiState;
        protected AITypes aiType;
        private Skills allSkills;
        private int armor;
        private int armorFromItems;
        private int attackBoniiMax;
        private int attackBoniiMin;
        private int attackMode;
        private int attackPower;
        public float attackSpeed;
        private Mobile attackTarget;
        private ArrayList aura;
        private float baseAgility;
        private int baseEnergy;
        private int baseFocus;
        private int baseHitPoints;
        private float baseIq;
        private int baseMana;
        private int baseRage;
        private float baseSpirit;
        private float baseStamina;
        private float baseStr;
        public SpellTemplate beingCasting;
        private int block;
        private float boundingRadius;
        public Casting cast;
        public float castingSpeed;
        private Channeling chan;
        public bool channelTarget;
        private Mobile charm;
        private Mobile charmedBy;
        private Classes classe;
        private float combatReach;
        private Server.Mobile.CombatTimer combatTimer;
        private int comboPoints;
        private Hashtable cumulativeAuraEffects;
        public int currs;
        private DecayTimer decay;
        private bool deleted;
        private int energy;
        private uint exp;
        public static int fa;
        private Factions faction;
        private uint flags1;
        private int focus;
        private bool freeze;
        private bool godMode;
        private string guild;
        private uint guildId;
        private byte[] hitBuffer;
        private int hitPoints;
        public byte[] hitsUpdate;
        private int id;
        private int iq;
        protected int itemHealthBonus;
        protected int itemManaBonus;
        private Item[] items;
        private Hashtable knownAbilities;
        private AttackStatus lastAttack;
        private AttackStatus lastAttackToMe;
        protected DateTime lastHeartBeat;
        private DateTime lastHit;
        private Mobile lastOffender;
        private Character lastSeen;
        private int level;
        private long localTime;
        private int lootMoney;
        private BaseTreasure[] loots;
        private int mana;
        protected int manaType;
        private float maxDamage;
        private float minDamage;
        public static int[] mobXp;
        private int model;
        protected AuraEffect mountedIdAuraEffect;
        private Mobile mounting;
        private int mountModel;
        private bool movementChange;
        private MovementTimer movementTimer;
        public MoveVector moveVector;
        private string name;
        private string name2;
        private ArrayList nextAttackEffects;
        private uint npcFlags;
        private string npcText;
        private int npcType;
        protected OnCreatureTick onCreatureTick;
        public static Hashtable onInitialiseTalent;
        private OnReachTimer onReachTimer;
        public static SpellHandler onSpellCasted;
        public ArrayList permanentAura;
        private uint petCreatureFamily;
        private uint petDisplayId;
        private uint petLevel;
        private object primarySpellTarget;
        private byte professions;
        private int quest;
        private int rage;
        private int rangedAttackPower;
        public float rangedAttackSpeed;
        private static float[,] reactions;
        private int resistArcane;
        private int resistFire;
        private int resistFrost;
        private int resistHoly;
        private int resistNature;
        private int resistShadow;
        private bool running;
        private float runSpeed;
        private Item[] sells;
        private float size;
        private Loot[] skinLoot;
        public Hashtable SpecialForAuras;
        private float speed;
        private SpellCastTimer spellCastTimer;
        private Server.Object spellTarget;
        private float spellTargetX;
        private float spellTargetY;
        private float spellTargetZ;
        private int spirit;
        private int stamina;
        private StandStates standState;
        private int str;
        private Mobile summon;
        private Mobile summonedBy;
        private float swimBackSpeed;
        private float swimSpeed;
        private int talent;
        private Hashtable talentList;
        private Item targetedItem;
        private int[] trains;
        public Hashtable Triggers;
        private bool unInteractible;
        private int unk3;
        private int unk4;
        private object values;
        private static float viewingCone;
        public ushort viewRange;
        private InvisibilityLevel visible;
        private float walkSpeed;
        public static int[] xpNeeded;

        // Nested Types
        public class AuraReleaseTimer : WowTimer
        {
            // Methods
            public AuraReleaseTimer(Mobile st, Aura ar, AuraEffect a, int n, int duration) : base((double) duration)
            {
                this.aura = ar;
                this.num = n;
                this.from = st;
                this.ae = a;
                base.Start();
            }

            public override void OnTick()
            {
                this.from.ReleaseAura(this);
                base.OnTick();
            }


            // Fields
            public AuraEffect ae;
            public Aura aura;
            private Mobile from;
            public int num;
        }

        public class CastFakeSpellTimer : WowTimer
        {
            // Methods
            public CastFakeSpellTimer(Mobile src, Mobile to, int sp, int castingtime) : base((double) castingtime)
            {
                this.target = to;
                this.from = src;
                this.spell = sp;
                base.Start();
            }

            public CastFakeSpellTimer(Mobile src, Mobile to, int sp, int castingtime, Mobile.WhenDone triger) : base((double) castingtime)
            {
                this.target = to;
                this.from = src;
                this.spell = sp;
                this.trigerWhenDone = triger;
                base.Start();
            }

            public override void OnTick()
            {
                base.Stop();
                byte[] buffer3 = new byte[9];
                buffer3[4] = 0xed;
                buffer3[5] = 14;
                byte[] buffer1 = buffer3;
                int num1 = 4;
                Converter.ToBytes(this.spell, buffer1, ref num1);
                if (this.from is Character)
                {
                    (this.from as Character).Send(OpCodes.SMSG_CAST_RESULT, buffer1, buffer1.Length);
                }
                if (this.from.cast.type == 0x40)
                {
                    num1 = 4;
                    Converter.ToBytes((ulong) 0, this.from.tempBuff, ref num1);
                    Converter.ToBytes(this.from.Guid, this.from.tempBuff, ref num1);
                    Converter.ToBytes(this.spell, this.from.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.from.tempBuff, ref num1);
                    Converter.ToBytes((short) 0x201, this.from.tempBuff, ref num1);
                    Converter.ToBytes((ulong) 50, this.from.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.from.tempBuff, ref num1);
                    Converter.ToBytes((ulong) 1, this.from.tempBuff, ref num1);
                    Converter.ToBytes(this.from.cast.type, this.from.tempBuff, ref num1);
                    Converter.ToBytes(this.from.spellTargetX, this.from.tempBuff, ref num1);
                    Converter.ToBytes(this.from.spellTargetY, this.from.tempBuff, ref num1);
                    Converter.ToBytes(this.from.spellTargetZ, this.from.tempBuff, ref num1);
                    this.from.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.from.tempBuff, num1);
                }
                else
                {
                    byte[] buffer2 = new byte[0x26] { 
                        0, 0, 0, 0, 0xc2, 0x36, 0x21, 0, 0, 0, 0, 0, 0xf7, 0x36, 0x21, 0, 
                        0, 0, 0, 0, 0xed, 14, 0, 0, 0, 1, 1, 0xc2, 0x36, 0x21, 0, 0, 
                        0, 0, 0, 0, 0, 0
                     } ;
                    num1 = 4;
                    Converter.ToBytes(this.target.Guid, buffer2, ref num1);
                    Converter.ToBytes(this.from.Guid, buffer2, ref num1);
                    Converter.ToBytes(this.spell, buffer2, ref num1);
                    num1 += 4;
                    this.from.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, buffer2, buffer2.Length);
                }
                if (this.trigerWhenDone != null)
                {
                    this.trigerWhenDone();
                }
                this.from.cast.castingtime = 0;
                this.from.cast.cool = 0;
                this.from.cast.id = 0;
                this.from.cast.manacost = 0;
                this.from.cast.radius = 0;
                this.from.cast.duration = 0;
                this.from.cast.type = 0;
                this.from.cast.baseability = null;
                base.OnTick();
            }


            // Fields
            private Mobile from;
            private int spell;
            private Mobile target;
            private Mobile.WhenDone trigerWhenDone;
        }

        public class CastFakeSpellTimerSpe : WowTimer
        {
            // Methods
            public CastFakeSpellTimerSpe(Mobile src, Mobile to, int sp, int castingtime) : base((double) castingtime)
            {
                this.target = to;
                this.from = src;
                this.spell = sp;
                base.Start();
            }

            public CastFakeSpellTimerSpe(Mobile src, Mobile to, int sp, int castingtime, Mobile.WhenDone triger) : base((double) castingtime)
            {
                this.target = to;
                this.from = src;
                this.spell = sp;
                this.trigerWhenDone = triger;
                base.Start();
            }

            public override void OnTick()
            {
                base.Stop();
                byte[] buffer2 = new byte[9];
                buffer2[4] = 0xed;
                buffer2[5] = 14;
                byte[] buffer1 = buffer2;
                int num1 = 4;
                Converter.ToBytes(this.spell, buffer1, ref num1);
                if (this.from is Character)
                {
                    (this.from as Character).Send(OpCodes.SMSG_CAST_RESULT, this.from.tempBuff, num1);
                }
                num1 = 4;
                Converter.ToBytes(this.target.Guid, this.from.tempBuff, ref num1);
                Converter.ToBytes(this.target.Guid, this.from.tempBuff, ref num1);
                Converter.ToBytes(this.spell, this.from.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.from.tempBuff, ref num1);
                Converter.ToBytes((short) 0x101, this.from.tempBuff, ref num1);
                Converter.ToBytes(this.from.Guid, this.from.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.from.tempBuff, ref num1);
                Converter.ToBytes((short) 0x42, this.from.tempBuff, ref num1);
                Converter.ToBytes(this.from.Guid, this.from.tempBuff, ref num1);
                Converter.ToBytes(this.from.X, this.from.tempBuff, ref num1);
                Converter.ToBytes(this.from.Y, this.from.tempBuff, ref num1);
                Converter.ToBytes(this.from.Z, this.from.tempBuff, ref num1);
                this.from.ToAllPlayerNear(OpCodes.SMSG_SPELL_GO, this.from.tempBuff, num1);
                if (this.trigerWhenDone != null)
                {
                    this.trigerWhenDone();
                }
                this.from.cast.castingtime = 0;
                this.from.cast.cool = 0;
                this.from.cast.radius = 0;
                this.from.cast.duration = 0;
                this.from.cast.id = 0;
                this.from.cast.manacost = 0;
                this.from.cast.type = 0;
                this.from.cast.baseability = null;
                base.OnTick();
            }


            // Fields
            private Mobile from;
            private int spell;
            private Mobile target;
            private Mobile.WhenDone trigerWhenDone;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct Casting
        {
            public int cool;
            public int manacost;
            public int id;
            public int castingtime;
            public BaseAbility baseability;
            public ushort type;
            public short radius;
            public int duration;
        }

        [StructLayout(LayoutKind.Sequential)]
        public struct Channeling
        {
            public int channeling;
            public ChannelReleaseTimer crt;
            public long duration;
            public Server.Object channelingTarget;
        }

        private class CombatTimer : WowTimer
        {
            // Methods
            public CombatTimer(Mobile f, int delay) : base((double) delay)
            {
                this.from = f;
                base.Start();
            }

            public override void OnTick()
            {
                this.from.MeleeCombatSlice();
                base.Stop();
                base.OnTick();
            }


            // Fields
            private Mobile from;
        }

        private class DecayTimer : WowTimer
        {
            // Methods
            public DecayTimer(Mobile f, int delay) : base((double) delay)
            {
                this.from = f;
                base.Start();
            }

            public override void OnTick()
            {
                if (this.from.SpawnerLink != null)
                {
                    this.from.SpawnerLink.Release(this.from);
                    this.from.SpawnerLink = null;
                }
                if (World.allMobiles.Contains(this.from))
                {
                    World.Remove(this.from, this.from);
                }
                base.Stop();
                base.OnTick();
            }


            // Fields
            private Mobile from;
        }

        public class DelayHitLoosed : WowTimer
        {
            // Methods
            public DelayHitLoosed(Mobile _from, Mobile _attacker) : base(500)
            {
                this.from = _from;
                this.attacker = _attacker;
                base.Start();
            }

            public override void OnTick()
            {
                int[] numArray1;
                object[] objArray1;
                if (this.from.HitPoints > 0)
                {
                    numArray1 = new int[1] { 0x16 } ;
                    objArray1 = new object[1] { this.from.HitPoints } ;
                    this.from.SendSmallUpdateToPlayerNearMe(this.from.Guid, numArray1, objArray1);
                }
                else
                {
                    this.from.HitPoints = 0;
                    if ((this.from is Character) && ((this.from as Character).Duel != 0))
                    {
                        return;
                    }
                    numArray1 = new int[1] { 0x16 } ;
                    objArray1 = new object[1] { this.from.HitPoints } ;
                    this.from.SendSmallUpdateToPlayerNearMe(this.from.Guid, numArray1, objArray1);
                }
                base.Stop();
                base.OnTick();
            }


            // Fields
            private Mobile attacker;
            private Mobile from;
        }

        public enum Familys
        {
            // Fields
            Bat = 0x18,
            Bear = 4,
            Boar = 5,
            CarrionBird = 7,
            Cat = 2,
            Crab = 8,
            Crocilisk = 6,
            Doomguard = 0x13,
            Felhunter = 15,
            Gorilla = 9,
            Hyena = 0x19,
            Imp = 0x17,
            Owl = 0x1a,
            Raptor = 11,
            Scorpid = 20,
            Spider = 3,
            Succubus = 0x11,
            Tallstrider = 12,
            Turtle = 0x15,
            Voidwalker = 0x10,
            WindSerpent = 0x1b,
            Wolf = 1
        }

        private class MovementTimer : WowTimer
        {
            // Methods
            public MovementTimer(Mobile f) : base(WowTimer.Priorities.Second, 1000)
            {
                this.from = f;
                base.Start();
            }

            public override void OnTick()
            {
                if (!this.from.Dead && !this.from.Freeze)
                {
                    this.from.OnTick();
                }
                if (this.from.deleted)
                {
                    base.Stop();
                }
                base.OnTick();
            }


            // Fields
            private Mobile from;
        }

        public class MoveVector
        {
            // Methods
            public MoveVector(Mobile m, float x, float y, float z)
            {
                this.timestamp = DateTime.Now;
                this.destX = x;
                this.destY = y;
                this.destZ = z;
                this.fromX = m.X;
                this.fromY = m.Y;
                this.fromZ = m.Z;
                this.speed = m.Speed;
                float single1 = x - m.X;
                float single2 = y - m.Y;
                float single3 = (float) Math.Sqrt((double) ((single1 * single1) + (single2 * single2)));
                this.reach = single3 / (m.Speed / 1000f);
            }

            public MoveVector(Mobile m, float x, float y, float z, float fromx, float fromy, float fromz)
            {
                this.timestamp = DateTime.Now;
                this.destX = x;
                this.destY = y;
                this.destZ = z;
                this.fromX = fromx;
                this.fromY = fromy;
                this.fromZ = fromz;
                this.speed = m.Speed;
                float single1 = x - m.X;
                float single2 = y - m.Y;
                float single3 = (float) Math.Sqrt((double) ((single1 * single1) + (single2 * single2)));
                this.reach = single3 / (m.Speed / 1000f);
            }

            public void Get(out float x, out float y, out float z)
            {
                TimeSpan span1 = DateTime.Now.Subtract(this.timestamp);
                float single1 = ((float) span1.TotalMilliseconds) / this.reach;
                if ((this.reach == 0f) || (single1 > 1f))
                {
                    x = this.destX;
                    y = this.destY;
                    z = this.destZ;
                }
                else
                {
                    float single2 = this.destX - this.fromX;
                    float single3 = this.destY - this.fromY;
                    float single4 = this.destZ - this.fromZ;
                    single2 *= single1;
                    single3 *= single1;
                    single4 *= single1;
                    x = this.fromX + single2;
                    y = this.fromY + single3;
                    z = this.fromZ + single4;
                }
            }

            public bool NearDestination()
            {
                TimeSpan span1 = DateTime.Now.Subtract(this.timestamp);
                float single1 = ((float) span1.TotalMilliseconds) - this.reach;
                if (single1 < 1000f)
                {
                    return true;
                }
                return false;
            }

            public bool ReachDestination()
            {
                TimeSpan span1 = DateTime.Now.Subtract(this.timestamp);
                float single1 = ((float) span1.TotalMilliseconds) / this.reach;
                if ((single1 <= 1f) && (this.reach != 0f))
                {
                    return false;
                }
                return true;
            }

            public void Update(float x, float y, float z, float speed)
            {
                this.Get(out this.fromX, out this.fromY, out this.fromZ);
                this.timestamp = DateTime.Now;
                float single1 = x - this.fromX;
                float single2 = y - this.fromY;
                this.destX = x;
                this.destY = y;
                this.destZ = z;
                float single3 = (float) Math.Sqrt((double) ((single1 * single1) + (single2 * single2)));
                this.reach = single3 / (speed / 1000f);
            }


            // Fields
            private float destX;
            private float destY;
            private float destZ;
            private float fromX;
            private float fromY;
            private float fromZ;
            private float reach;
            private float speed;
            private DateTime timestamp;
        }

        public delegate bool OnCreatureTick();


        public delegate void OnCriticalHitDoneTrigger(Mobile who, Mobile target, BaseAbility ae);


        public delegate void OnCriticalHitTrigger(Mobile from, Mobile target, BaseAbility ae);


        public delegate void OnMeleeHitDoneTrigger(Mobile who, Mobile target, AuraEffect ae);


        public delegate void OnMeleeHitTrigger(Mobile from, Mobile target, AuraEffect ae);


        public delegate void OnReachDelegate();


        private class OnReachTimer : WowTimer
        {
            // Methods
            public OnReachTimer(int delay, Mobile.OnReachDelegate _onReach) : base(WowTimer.Priorities.Milisec100, (double) delay)
            {
                this.onReach = _onReach;
                base.Start();
            }

            public override void OnTick()
            {
                this.onReach();
                base.Stop();
                base.OnTick();
            }


            // Fields
            private Mobile.OnReachDelegate onReach;
        }

        public delegate void OnSpellHitDoneTrigger(Mobile who, Mobile target, AuraEffect ae);


        public delegate void OnSpellHitTrigger(Mobile from, Mobile target, AuraEffect ae);


        private class OnTaxiEndTimer : WowTimer
        {
            // Methods
            public OnTaxiEndTimer(int delay, Character _ch, Trajet _t) : base(WowTimer.Priorities.Milisec100, (double) delay)
            {
                this.ch = _ch;
                base.Start();
                this.t = _t;
            }

            public override void OnTick()
            {
                Taxi.OnUnmountTaxi(this.ch, this.t);
                base.Stop();
                base.OnTick();
            }


            // Fields
            private Character ch;
            private Trajet t;
        }

        public enum Pos
        {
            // Fields
            Behind = 1,
            Front = 0
        }

        public class SpellCastTimer : WowTimer
        {
            // Methods
            public SpellCastTimer(Mobile.SpellStartRun st, int mili) : base(WowTimer.Priorities.Milisec100, (double) mili)
            {
                this.whenReady = st;
                base.Start();
            }

            public override void OnTick()
            {
                this.whenReady();
                base.Stop();
                base.OnTick();
            }


            // Fields
            private Mobile.SpellStartRun whenReady;
        }

        private class SpellCoolDownTimer : WowTimer
        {
            // Methods
            public SpellCoolDownTimer(Mobile.SpellEndCoolDown st, int mili) : base(WowTimer.Priorities.Milisec100, (double) mili)
            {
                this.whenReady = st;
                base.Start();
            }

            public override void OnTick()
            {
                this.whenReady();
                base.Stop();
                base.OnTick();
            }


            // Fields
            private Mobile.SpellEndCoolDown whenReady;
        }

        private delegate void SpellEndCoolDown();


        public delegate void SpellStartRun();


        [StructLayout(LayoutKind.Sequential)]
        public struct SpellXYZtarget
        {
            public float X;
            public float Y;
            public float Z;
        }

        public delegate void WhenDone();

    }
}

