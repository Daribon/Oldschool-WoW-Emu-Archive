namespace Server
{
    using System;

    public class ZoneDelimiters
    {
        // Methods
        public ZoneDelimiters(int area, float xmn, float ymn, float xmx, float ymx)
        {
            this.xmin = xmn;
            this.ymin = ymn;
            this.xmax = xmx;
            this.ymax = ymx;
            this.areaId = area;
            this.cached = false;
        }


        // Properties
        public bool Loaded
        {
            get
            {
                return this.cached;
            }
            set
            {
                this.cached = value;
            }
        }

        public float Xlen
        {
            get
            {
                return ((this.xmax - this.xmin) / 4.166667f);
            }
        }

        public float Xmax
        {
            get
            {
                return this.xmax;
            }
        }

        public float Xmin
        {
            get
            {
                return this.xmin;
            }
        }

        public float Ylen
        {
            get
            {
                return (float) (((double) (this.ymax - this.ymin)) / 2.0833332538604736);
            }
        }

        public float Ymax
        {
            get
            {
                return this.ymax;
            }
        }

        public float Ymin
        {
            get
            {
                return this.ymin;
            }
        }


        // Fields
        private int areaId;
        private bool cached;
        private float xmax;
        private float xmin;
        private float ymax;
        private float ymin;
    }
}

