namespace Server
{
    using HelperTools;
    using System;
    using System.Reflection;

    public class MountAuraEffect : AuraEffect
    {
        // Methods
        public MountAuraEffect(ushort _id, int _customFlags1, int _mountid, int _levelMin, int _levelMax, int _bonus1, int _bonus2, int _s1, int _s2, int _s3, int _t1, int _t2, Resistances _res, DispelType _dis, int _manacost, int _castingtime, int _duration, int _cooldown, int _aura, int _h, int _classe) : base(_id, _customFlags1, _levelMin, _levelMax, _bonus1, _bonus2, _s1, _s2, _s3, _t1, _t2, _res, _dis, _manacost, _castingtime, 0, _duration, _cooldown, _aura, _h, _classe)
        {
            this.mountId = _mountid;
            this.speedModifier = ((float) _s2) / 100f;
            World.MountsList[this.mountId] = this;
        }

        public void Summon(Mobile c)
        {
            int num2;
            if (c.Summon != null)
            {
                c.Summon.Delete();
                if (World.allMobiles.Contains(c.Summon))
                {
                    World.Remove(c.Summon, c);
                }
            }
            ConstructorInfo info1 = World.MobilePool(this.mountId);
            BaseCreature creature1 = (BaseCreature) info1.Invoke(null);
            creature1.Faction = c.Faction;
            creature1.AIEngine = new SummonedAI(c, creature1);
            creature1.SummonedBy = c;
            c.Summon = creature1;
            creature1.Level = c.Level;
            creature1.BaseMana = num2 = 0;
            creature1.Agility = num2 = num2;
            creature1.BaseHitPoints = num2 = num2;
            creature1.HitPoints = num2 = num2;
            creature1.Spirit = num2 = num2;
            creature1.Iq = num2 = num2;
            creature1.Str = num2 = num2;
            creature1.Stamina = num2;
            creature1.InitStats();
            if (c.Classe == Classes.Warlock)
            {
                if ((((creature1.Id == 0x1a0) || (creature1.Id == 0x747)) || ((creature1.Id == 0x744) || (creature1.Id == 0x1a1))) && c.HaveTalent(Talents.FelIntellect))
                {
                    AuraEffect effect1 = (AuraEffect) c.GetTalentEffect(Talents.FelIntellect);
                    float single1 = creature1.BaseMana;
                    single1 += ((single1 * effect1.S1) / 100f);
                    creature1.Mana = num2 = (int) single1;
                    creature1.BaseMana = num2;
                }
                if ((((creature1.Id == 0x1a0) || (creature1.Id == 0x747)) || ((creature1.Id == 0x744) || (creature1.Id == 0x1a1))) && c.HaveTalent(Talents.FelStamina))
                {
                    AuraEffect effect2 = (AuraEffect) c.GetTalentEffect(Talents.FelStamina);
                    float single2 = creature1.BaseHitPoints;
                    single2 += ((single2 * effect2.S1) / 100f);
                    creature1.HitPoints = num2 = (int) single2;
                    creature1.BaseHitPoints = num2;
                }
            }
            World.Add(creature1, c.X, c.Y, c.Z, c.MapId);
            if (c is Character)
            {
                Character character1 = c as Character;
                int num1 = 4;
                Converter.ToBytes(1, c.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, c.tempBuff, ref num1);
                c.PrepareUpdateData(c.tempBuff, ref num1, UpdateType.UpdateFull, false);
                character1.Send(OpCodes.SMSG_UPDATE_OBJECT, c.tempBuff, num1);
                character1.ItemsUpdate();
                if ((((creature1.Id == 0x59) || (creature1.Id == 0x1a0)) || ((creature1.Id == 0x747) || (creature1.Id == 0x744))) || ((creature1.Id == 0x130) || (creature1.Id == 0x1a1)))
                {
                    character1.SendPetActionBar();
                }
            }
        }


        // Properties
        public int MountId
        {
            get
            {
                return this.mountId;
            }
        }

        public float SpeedModifier
        {
            get
            {
                return this.speedModifier;
            }
        }


        // Fields
        private int mountId;
        private float speedModifier;
    }
}

