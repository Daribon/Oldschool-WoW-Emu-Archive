namespace Server
{
    using System;

    public class DefenseSkill : Skill
    {
        // Methods
        public DefenseSkill()
        {
        }

        public DefenseSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x5f;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x5f;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

