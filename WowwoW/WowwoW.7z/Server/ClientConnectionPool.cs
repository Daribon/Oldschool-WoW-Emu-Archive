namespace Server
{
    using System;
    using System.Collections;

    public class ClientConnectionPool
    {
        // Methods
        public ClientConnectionPool()
        {
            this.SyncdQ = Queue.Synchronized(new Queue());
        }

        public ClientHandler Dequeue()
        {
            return (ClientHandler) this.SyncdQ.Dequeue();
        }

        public void Enqueue(ClientHandler client)
        {
            this.SyncdQ.Enqueue(client);
        }


        // Properties
        public int Count
        {
            get
            {
                return this.SyncdQ.Count;
            }
        }

        public object SyncRoot
        {
            get
            {
                return this.SyncdQ.SyncRoot;
            }
        }


        // Fields
        private Queue SyncdQ;
    }
}

