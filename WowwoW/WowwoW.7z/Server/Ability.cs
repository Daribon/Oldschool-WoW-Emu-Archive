namespace Server
{
    using System;

    public class Ability : BaseAbility
    {
        // Methods
        public Ability(ushort _id, int _customFlags1, int _degatMin, int _degatMax, Resistances _res, DispelType _dis, int _manacost, int _castingtime, byte _range, int _duration, int _cooldown, int _classe) : base(_id, _customFlags1, _cooldown)
        {
            this.degatMin = _degatMin;
            this.degatMax = _degatMax;
            this.resistance = _res;
            this.dispeltype = _dis;
            this.classe = _classe;
            this.manaCost = _manacost;
            this.castingTime = _castingtime;
            this.range = _range;
            this.duration = _duration;
        }

        public override int CastingTime(Mobile from)
        {
            return this.castingTime;
        }

        public virtual void CastSpellOn(Mobile target)
        {
        }


        // Properties
        public int Bonus1
        {
            get
            {
                return this.degatMax;
            }
        }

        public int ManaCost
        {
            get
            {
                return this.manaCost;
            }
        }

        public int S1
        {
            get
            {
                return this.degatMin;
            }
        }


        // Fields
        private int castingTime;
        private int classe;
        private int cooldown;
        private int degatMax;
        private int degatMin;
        private DispelType dispeltype;
        private int duration;
        private int manaCost;
        private byte range;
        private Resistances resistance;
    }
}

