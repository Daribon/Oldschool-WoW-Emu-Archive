namespace Server
{
    using System;

    public class ClothSkill : Skill
    {
        // Methods
        public ClothSkill()
        {
        }

        public ClothSkill(int current, int max) : base(1, 1)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x19f;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x19f;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x2376;
            }
        }

    }
}

