namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate SpellFailedReason SingleTargetSpellCheck(BaseAbility ba, Mobile c, Server.Object m);

}

