namespace Server
{
    using HelperTools;
    using System;

    public class DefensiveAnimalAI : BaseAIType
    {
        // Methods
        public DefensiveAnimalAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.Explore;
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if ((AIState == AIStates.Attack) || (AIState == AIStates.Fighting))
            {
                return AIState;
            }
            base.OnBeginFight(by);
            if (by == base.From)
            {
                base.From.AttackTarget = base.From.LastOffender;
            }
            else
            {
                base.From.AttackTarget = by;
            }
            return AIStates.BeingAttacked;
        }

        public override void OnTick()
        {
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 1800f))
            {
                base.From.AIState = AIStates.Explore;
                base.From.AttackTarget = null;
            }
            else
            {
                switch (base.AIState)
                {
                    case AIStates.DoingNothing:
                    {
                        base.AIState = AIStates.Explore;
                        return;
                    }
                    case AIStates.Explore:
                    {
                        if (Utility.Random16() >= 2)
                        {
                            if (Utility.Random16() < 4)
                            {
                                base.AIState = AIStates.Pause2;
                            }
                            return;
                        }
                        base.AIState = AIStates.Pause1;
                        return;
                    }
                    case AIStates.Pause1:
                    {
                        base.AIState = AIStates.Pause2;
                        return;
                    }
                    case AIStates.Pause2:
                    {
                        base.AIState = AIStates.Pause3;
                        return;
                    }
                    case AIStates.Pause3:
                    {
                        base.AIState = AIStates.Explore;
                        return;
                    }
                }
            }
        }

    }
}

