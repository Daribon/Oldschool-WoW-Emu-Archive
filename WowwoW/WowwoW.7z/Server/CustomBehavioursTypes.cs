namespace Server
{
    using System;

    public enum CustomBehavioursTypes
    {
        // Fields
        KeepOrientation = 2,
        None = 0,
        Stay = 1
    }
}

