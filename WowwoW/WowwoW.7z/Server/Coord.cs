namespace Server
{
    using System;

    public class Coord
    {
        // Methods
        public Coord(float a, float b, float c, Coord p, Coord n)
        {
            this.x = a;
            this.y = b;
            this.z = c;
            this.next = n;
            this.previous = p;
        }

        public void TrajetNum(ref int ntr, ref int nc)
        {
            ntr = 0;
            foreach (Trajet trajet1 in World.trajets)
            {
                nc = 0;
                Trajet.CoordEnumerator enumerator2 = trajet1.GetEnumerator();
                try
                {
                    while (enumerator2.MoveNext())
                    {
                        if (enumerator2.Current == this)
                        {
                            return;
                        }
                        nc += 1;
                    }
                }
                finally
                {
                    IDisposable disposable1 = enumerator2 as IDisposable;
                    if (disposable1 != null)
                    {
                        disposable1.Dispose();
                    }
                }
                ntr += 1;
            }
        }


        // Fields
        public Coord next;
        public BaseCreature occ;
        public Coord previous;
        public float x;
        public float y;
        public float z;
    }
}

