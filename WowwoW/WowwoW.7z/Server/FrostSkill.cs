namespace Server
{
    using System;

    public class FrostSkill : Skill
    {
        // Methods
        public FrostSkill()
        {
        }

        public FrostSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 6;
            }
        }

        public static int SkillId
        {
            get
            {
                return 6;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

