namespace Server
{
    using System;

    public class Balance : Skill
    {
        // Methods
        public Balance()
        {
        }

        public Balance(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x23e;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x23e;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

