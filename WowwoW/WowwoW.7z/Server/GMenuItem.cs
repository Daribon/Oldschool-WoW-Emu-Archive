namespace Server
{
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct GMenuItem
    {
        private uint _menuId;
        private GMenuIcons _icon;
        private bool _inputBox;
        private string _text;
        public GMenuItem(uint menuId, GMenuIcons icon, bool inputBox, string text)
        {
            this._menuId = menuId;
            this._icon = icon;
            this._inputBox = inputBox;
            this._text = text;
        }
        public uint MenuId
        {
            get
            {
                return this._menuId;
            }
        }
        public byte Icon
        {
            get
            {
                return (byte) this._icon;
            }
        }
        public byte InputBox
        {
            get
            {
                return (this._inputBox ? ((byte) 1) : ((byte) 0));
            }
        }
        public string Text
        {
            get
            {
                return this._text;
            }
        }
    }
}

