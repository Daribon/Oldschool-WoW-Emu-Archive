namespace Server
{
    using System;

    public enum QuestType : byte
    {
        // Fields
        Dungeon = 0x51,
        Elite = 1,
        Life = 0x15,
        None = 0,
        PvP = 0x29,
        Raid = 0x3e
    }
}

