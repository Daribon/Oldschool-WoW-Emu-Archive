namespace Server
{
    using System;

    public class DrainHealthAura : Aura
    {
        // Methods
        public DrainHealthAura(SpellTemplate st, Mobile c, Mobile t, int d, int dur, int freq)
        {
            if (!t.Dead)
            {
                this.spell = st;
                this.from = c;
                this.target = t;
                this.dmg = d;
                this.duration = dur;
                this.frequency = freq;
                base.PeriodicAura(new Aura.AuraPeriodicEffect(this.PeriodicDrainHealth), dur, freq);
            }
        }

        public void PeriodicDrainHealth()
        {
            this.spell.DrainLife(this.from, this.target, this.dmg);
        }


        // Fields
        private float dmg;
        private int duration;
        private int frequency;
        private Mobile from;
        private SpellTemplate spell;
        private Mobile target;
    }
}

