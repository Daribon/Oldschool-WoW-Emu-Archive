namespace Server
{
    using System;

    public class NPCObjective
    {
        // Methods
        public NPCObjective(int id, int amount)
        {
            this._descr = null;
            this._type = TypeNpcObj.Mobile;
            this._id = id;
            this._amount = amount;
        }

        public NPCObjective(int id, int amount, TypeNpcObj typeObj, string description)
        {
            this._descr = null;
            this._type = TypeNpcObj.Mobile;
            this._id = id;
            this._amount = amount;
            this._type = typeObj;
            this._descr = description;
        }


        // Properties
        public int Amount
        {
            get
            {
                return this._amount;
            }
        }

        public string Descr
        {
            get
            {
                if (this._descr == null)
                {
                    if (this._type == TypeNpcObj.Mobile)
                    {
                        Mobile mobile1 = (Mobile) World.MobilePool(this._id).Invoke(null);
                        this._descr = mobile1.Name;
                    }
                    else
                    {
                        this._descr = string.Format("gameobject:{0}", this._id);
                    }
                }
                return this._descr;
            }
        }

        public bool ExistsInWorld
        {
            get
            {
                return (World.MobilesPool[this._id] != null);
            }
        }

        public int Id
        {
            get
            {
                return this._id;
            }
        }

        public int Id2
        {
            get
            {
                return this._id;
            }
        }

        public TypeNpcObj TypeObj
        {
            get
            {
                return this._type;
            }
        }


        // Fields
        private int _amount;
        private string _descr;
        private int _id;
        private TypeNpcObj _type;
    }
}

