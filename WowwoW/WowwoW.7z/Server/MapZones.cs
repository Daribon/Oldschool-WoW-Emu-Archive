namespace Server
{
    using System;
    using System.Collections;
    using System.IO;

    public class MapZones
    {
        // Methods
        static MapZones()
        {
            MapZones.UNITSIZE = 4.166667f;
        }

        public MapZones()
        {
            this.Azeroth = new Hashtable();
            this.AzerothZones = new ArrayList();
            this.WorldDelimiters = new Hashtable();
            this.Init();
        }

        public MapZones(bool noload)
        {
            this.Azeroth = new Hashtable();
            this.AzerothZones = new ArrayList();
            this.WorldDelimiters = new Hashtable();
        }

        public Hashtable Continent(int mapId)
        {
            return (Hashtable) this.WorldDelimiters[mapId];
        }

        public ArrayList Files(string path)
        {
            DirectoryInfo info1 = new DirectoryInfo(path);
            ArrayList list1 = new ArrayList();
            DirectoryInfo[] infoArray2 = info1.GetDirectories("*");
            DirectoryInfo[] infoArray3 = infoArray2;
            int num1 = 0;
            while (num1 < infoArray3.Length)
            {
                DirectoryInfo info2 = infoArray3[num1];
                ArrayList list2 = this.Files(path + "/" + info2.Name);
                foreach (object obj1 in list2)
                {
                    list1.Add(obj1);
                }
                num1++;
            }
            FileInfo[] infoArray1 = info1.GetFiles();
            FileInfo[] infoArray4 = infoArray1;
            for (num1 = 0; num1 < infoArray4.Length; num1++)
            {
                FileInfo info3 = infoArray4[num1];
                if (info3.Extension.EndsWith(".bin"))
                {
                    list1.Add(info3.FullName);
                }
            }
            return list1;
        }

        public MapPoint Get(int pos, int zoneId, int mapId, Mobile mob, bool reenter)
        {
            float single1 = mob.X;
            float single2 = mob.Y;
            ZoneDelimiters delimiters1 = null;
            Hashtable hashtable1 = this.Continent(mapId);
            if (hashtable1 == null)
            {
                Console.WriteLine("Invalid mapId {0} -> DrNexus", mapId);
                return null;
            }
            delimiters1 = hashtable1[zoneId] as ZoneDelimiters;
            if ((((delimiters1.Xmax + MapZones.UNITSIZE) <= single1) || ((delimiters1.Xmin - MapZones.UNITSIZE) >= single1)) || (((delimiters1.Ymax + MapZones.UNITSIZE) <= single2) || ((delimiters1.Ymin - MapZones.UNITSIZE) >= single2)))
            {
                return this.NearestPoint(mapId, zoneId, single1, single2);
            }
            if (!delimiters1.Loaded)
            {
                this.Load(mapId, zoneId);
            }
            int num1 = (int) (single2 / (MapZones.UNITSIZE * 0.5f));
            if ((num1 % 2) == 1)
            {
                single1 -= (MapZones.UNITSIZE * 0.5f);
            }
            int num2 = (int) (single1 / MapZones.UNITSIZE);
            Hashtable hashtable2 = null;
            hashtable2 = (Hashtable) this.Azeroth[(mapId * 0x400) + zoneId];
            if (hashtable2 == null)
            {
                Console.WriteLine("hy map == null for {0}/{1}", mapId, zoneId);
                return null;
            }
            switch (pos)
            {
                case 0:
                {
                    num1--;
                    if ((num1 & 1) == 0)
                    {
                        num2--;
                    }
                    break;
                }
                case 1:
                {
                    num1--;
                    if ((num1 & 1) == 1)
                    {
                        num2++;
                    }
                    break;
                }
                case 2:
                {
                    num2--;
                    break;
                }
                case 3:
                {
                    num2++;
                    break;
                }
                case 4:
                {
                    num1++;
                    if ((num1 & 1) == 0)
                    {
                        num2--;
                    }
                    break;
                }
                case 5:
                {
                    num1++;
                    if ((num1 & 1) == 1)
                    {
                        num2++;
                    }
                    break;
                }
            }
            object obj1 = hashtable2[(num2 << 0x10) + num1];
            if (obj1 != null)
            {
                return new MapPoint(num2 * MapZones.UNITSIZE, (num1 * MapZones.UNITSIZE) * 0.5f, (float) obj1);
            }
            if (reenter)
            {
                return null;
            }
            this.NearestPoint(mapId, zoneId, single1, single2);
            return this.Get(pos, zoneId, mapId, mob, true);
        }

        public IDictionaryEnumerator GetEnumerator(int mapId)
        {
            return this.Continent(mapId).GetEnumerator();
        }

        public void Init()
        {
            int[] numArray1 = new int[0x11] { 
                0, 1, 0x21, 30, 0x24, 0x25, 0x2f, 0xa9, 0xd1, 0x10d, 0x121, 0x135, 0x149, 0x1c3, 0x1d5, 0x1e9, 
                0x211
             } ;
            int[] numArray2 = numArray1;
            for (int num4 = 0; num4 < numArray2.Length; num4++)
            {
                int num1 = numArray2[num4];
                FileStream stream1 = new FileStream(World.Path + "mapd" + num1.ToString() + ".bin", FileMode.Open, FileAccess.Read);
                BinaryReader reader1 = new BinaryReader(stream1);
                while (true)
                {
                    int num2 = reader1.ReadInt32();
                    if (num2 == -1)
                    {
                        break;
                    }
                    int num3 = reader1.ReadInt32();
                    float single1 = reader1.ReadSingle();
                    float single2 = reader1.ReadSingle();
                    float single3 = reader1.ReadSingle();
                    float single4 = reader1.ReadSingle();
                    if (this.WorldDelimiters[num2] == null)
                    {
                        this.WorldDelimiters[num2] = new Hashtable();
                    }
                    this.Continent(num2)[num3] = new ZoneDelimiters(num3, single1, single3, single2, single4);
                }
                reader1.Close();
            }
        }

        public void InitBrut()
        {
            float single1 = 533.3333f;
            float single2 = single1 / 16f;
            MapZones.UNITSIZE = single2 / 8f;
            FileStream stream1 = new FileStream(World.Path + "coordz.bin", FileMode.Open, FileAccess.Read);
            BinaryReader reader1 = new BinaryReader(stream1);
            ArrayList list1 = new ArrayList();
            while (true)
            {
                if (reader1.BaseStream.Position == reader1.BaseStream.Length)
                {
                    break;
                }
                int num1 = reader1.ReadInt32();
                float single3 = reader1.ReadSingle();
                float single4 = reader1.ReadSingle();
                float single5 = reader1.ReadSingle();
                float[] singleArray1 = new float[0x91];
                int num2 = 0;
                int num3 = 0;
                for (int num4 = 0; num4 < 0x11; num4++)
                {
                    int num5 = 8;
                    if ((num4 % 2) == 0)
                    {
                        num5 = 9;
                    }
                    for (int num6 = 0; num6 < num5; num6++)
                    {
                        num3++;
                        float single6 = reader1.ReadSingle();
                        if (single6 <= -10000f)
                        {
                            singleArray1[num2++] = -10000f;
                        }
                        else
                        {
                            singleArray1[num2++] = single6 + single4;
                        }
                    }
                }
                list1.Add(new Server.Zone(single3, single5, single4, num1, singleArray1));
                this.AzerothZones.Add(new Server.Zone(single3, single5, single4, num1, null));
            }
            stream1.Close();
            Hashtable hashtable1 = new Hashtable();
            foreach (Server.Zone zone1 in list1)
            {
                ArrayList list2 = hashtable1[zone1.zoneId] as ArrayList;
                if (list2 != null)
                {
                    list2.Add(zone1);
                    continue;
                }
                ArrayList list3 = new ArrayList();
                list3.Add(zone1);
                hashtable1[zone1.zoneId] = list3;
            }
            int num7 = 0;
            IDictionaryEnumerator enumerator1 = hashtable1.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                int num8 = (int) enumerator1.Key;
                if (World.map[num8] != null)
                {
                    int num9 = (int) World.map[num8];
                    this.Azeroth[(num9 * 0x400) + num8] = new Hashtable();
                    ArrayList list4 = (ArrayList) enumerator1.Value;
                    float single7 = float.MaxValue;
                    float single8 = float.MinValue;
                    float single9 = float.MaxValue;
                    float single10 = float.MinValue;
                    for (int num10 = 0; num10 < list4.Count; num10++)
                    {
                        Server.Zone zone2 = (Server.Zone) list4[num10];
                        for (int num11 = 0; num11 < 0x91; num11++)
                        {
                            float single11 = zone2.X(num11);
                            float single12 = zone2.Y(num11);
                            if (single12 < single7)
                            {
                                single7 = single12;
                            }
                            if (single12 > single8)
                            {
                                single8 = single12;
                            }
                            if (single11 < single9)
                            {
                                single9 = single11;
                            }
                            if (single11 > single10)
                            {
                                single10 = single11;
                            }
                        }
                    }
                    for (int num12 = 0; num12 < list4.Count; num12++)
                    {
                        Server.Zone zone3 = (Server.Zone) list4[num12];
                        for (int num13 = 0; num13 < 0x91; num13++)
                        {
                            float single13 = zone3.X(num13);
                            float single14 = zone3.Y(num13);
                            float single15 = zone3.Z(num13);
                            if (single15 > -100f)
                            {
                                num7++;
                                int num14 = (int) (single14 / MapZones.UNITSIZE);
                                int num15 = (int) (((double) single13) / (MapZones.UNITSIZE * 0.5));
                                Hashtable hashtable2 = (Hashtable) this.Azeroth[(num9 * 0x400) + num8];
                                Hashtable hashtable3 = hashtable2[num15] as Hashtable;
                                if (hashtable3 == null)
                                {
                                    hashtable3 = new Hashtable();
                                    hashtable2[num15] = hashtable3;
                                }
                                hashtable3[num14] = single15;
                            }
                        }
                    }
                }
            }
            list1.Clear();
            hashtable1.Clear();
            hashtable1 = null;
            GC.Collect();
        }

        public void Load(int mapId, int areaId)
        {
            string[] textArray1 = new string[5] { World.Path, "maps/map", mapId.ToString("X4"), areaId.ToString("X4"), ".bin" } ;
            FileStream stream1 = new FileStream(string.Concat(textArray1), FileMode.Open, FileAccess.Read);
            BinaryReader reader1 = new BinaryReader(stream1);
            new ArrayList();
            reader1.ReadInt64();
            int num1 = reader1.ReadInt32();
            Hashtable hashtable1 = new Hashtable();
            this.Azeroth[(mapId * 0x400) + areaId] = hashtable1;
            (this.Continent(mapId)[areaId] as ZoneDelimiters).Loaded = true;
            for (int num2 = 0; num2 < num1; num2++)
            {
                int num3 = reader1.ReadInt32();
                int num4 = reader1.ReadInt32();
                float single1 = reader1.ReadSingle();
                int num5 = (num3 << 0x10) + num4;
                hashtable1[num5] = single1;
            }
            reader1.Close();
        }

        public void LoadAll()
        {
            ArrayList list1 = this.Files(World.Path + "maps/");
            foreach (string text1 in list1)
            {
                FileStream stream1 = new FileStream(text1, FileMode.Open, FileAccess.Read);
                BinaryReader reader1 = new BinaryReader(stream1);
                new ArrayList();
                reader1.ReadInt32();
                int num1 = reader1.ReadInt32();
                int num2 = reader1.ReadInt32();
                Hashtable hashtable1 = new Hashtable();
                this.Azeroth[num1] = hashtable1;
                for (int num3 = 0; num3 < num2; num3++)
                {
                    int num4 = reader1.ReadInt32();
                    int num5 = reader1.ReadInt32();
                    float single1 = reader1.ReadSingle();
                    int num6 = (num4 << 0x10) + num5;
                    hashtable1[num6] = single1;
                }
                reader1.Close();
            }
        }

        public MapPoint NearestPoint(int mapId, int zoneId, float x, float y)
        {
            float single1 = float.MaxValue;
            ZoneDelimiters delimiters1 = null;
            Hashtable hashtable1 = null;
            delimiters1 = this.Continent(mapId)[zoneId] as ZoneDelimiters;
            if (delimiters1 == null)
            {
                Console.WriteLine("Unknown zone id {0}", zoneId);
            }
            if (!delimiters1.Loaded)
            {
                this.Load(mapId, zoneId);
            }
            hashtable1 = (Hashtable) this.Azeroth[(mapId * 0x400) + zoneId];
            if (hashtable1 == null)
            {
                Console.WriteLine("zone");
            }
            IDictionaryEnumerator enumerator1 = hashtable1.GetEnumerator();
            int num1 = 0;
            int num2 = 0;
            float single2 = 0f;
            y /= (MapZones.UNITSIZE * 0.5f);
            if ((y % 2f) == 1f)
            {
                x -= (MapZones.UNITSIZE * 0.5f);
            }
            x /= MapZones.UNITSIZE;
            while (enumerator1.MoveNext())
            {
                int num3 = (int) enumerator1.Key;
                short num4 = (short) (num3 >> 0x10);
                short num5 = (short) (num3 & 0xffff);
                float single3 = Math.Abs((float) (num4 - x));
                float single4 = Math.Abs((float) (num5 - y));
                single3 *= single3;
                single4 *= single4;
                single3 += single4;
                if (single3 < single1)
                {
                    single1 = single3;
                    num1 = num4;
                    num2 = num5;
                    single2 = (float) enumerator1.Value;
                }
            }
            if ((num2 % 2) == 1)
            {
                return new MapPoint((MapZones.UNITSIZE / 2f) + (num1 * MapZones.UNITSIZE), (num2 * MapZones.UNITSIZE) * 0.5f, single2);
            }
            return new MapPoint(num1 * MapZones.UNITSIZE, (num2 * MapZones.UNITSIZE) * 0.5f, single2);
        }

        public int NearestZoneId(Character ch)
        {
            double num1 = ch.Orientation;
            int num2 = (int) (ch.X + (Math.Cos(num1) * 50));
            int num3 = (int) (ch.Y + (Math.Sin(num1) * 50));
            int num4 = 0x7fffffff;
            int num5 = 0;
            for (int num6 = 0; num6 < World.allSpawners.Count; num6++)
            {
                BaseSpawner spawner1 = World.allSpawners[num6];
                if (spawner1.MapId == ch.MapId)
                {
                    int num7 = num2 - ((int) spawner1.X);
                    int num8 = num3 - ((int) spawner1.Y);
                    num7 = (num7 * num7) + (num8 * num8);
                    if (num7 < num4)
                    {
                        num4 = num7;
                        num5 = spawner1.ZoneId;
                    }
                }
            }
            return num5;
        }

        public int NearestZoneId(int mapId, float x, float y)
        {
            IDictionaryEnumerator enumerator1 = null;
            enumerator1 = this.Continent(mapId).GetEnumerator();
            while (enumerator1.MoveNext())
            {
                ZoneDelimiters delimiters1 = enumerator1.Value as ZoneDelimiters;
                if ((((delimiters1.Xmax + MapZones.UNITSIZE) >= x) && ((delimiters1.Xmin - MapZones.UNITSIZE) <= x)) && (((delimiters1.Ymax + (MapZones.UNITSIZE / 2f)) >= y) && ((delimiters1.Ymin - (MapZones.UNITSIZE / 2f)) <= y)))
                {
                    return (int) enumerator1.Key;
                }
            }
            return -1;
        }

        public ArrayList Zone(int mapId, int zoneId)
        {
            return (this.Continent(mapId)[zoneId] as ArrayList);
        }


        // Fields
        public Hashtable Azeroth;
        public ArrayList AzerothZones;
        public static float UNITSIZE;
        public Hashtable WorldDelimiters;
    }
}

