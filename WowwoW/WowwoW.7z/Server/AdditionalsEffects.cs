namespace Server
{
    using System;

    public enum AdditionalsEffects
    {
        // Fields
        Combustion = 0x15af54
    }
}

