namespace Server
{
    using System;
    using System.Threading;

    public class ClientService
    {
        // Methods
        public ClientService(ClientConnectionPool ConnectionPool, int nThread)
        {
            this.ContinueProcess = false;
            this.numOfThread = nThread;
            this.ThreadTask = new Thread[nThread];
            this.ConnectionPool = ConnectionPool;
        }

        private void Process()
        {
            while (this.ContinueProcess)
            {
                ClientHandler handler1 = null;
                lock (this.ConnectionPool.SyncRoot)
                {
                    if (this.ConnectionPool.Count > 0)
                    {
                        handler1 = this.ConnectionPool.Dequeue();
                    }
                }
                if (handler1 != null)
                {
                    handler1.Process();
                    if (handler1.Alive)
                    {
                        this.ConnectionPool.Enqueue(handler1);
                    }
                }
                Thread.Sleep(50);
            }
        }

        public void Start()
        {
            this.ContinueProcess = true;
            for (int num1 = 0; num1 < this.ThreadTask.Length; num1++)
            {
                this.ThreadTask[num1] = new Thread(new ThreadStart(this.Process));
                this.ThreadTask[num1].Start();
            }
        }

        public void Stop()
        {
            this.ContinueProcess = false;
            for (int num1 = 0; num1 < this.ThreadTask.Length; num1++)
            {
                if ((this.ThreadTask[num1] != null) && this.ThreadTask[num1].IsAlive)
                {
                    this.ThreadTask[num1].Join();
                }
            }
            while (this.ConnectionPool.Count > 0)
            {
                ClientHandler handler1 = this.ConnectionPool.Dequeue();
                handler1.Close();
            }
        }


        // Fields
        private ClientConnectionPool ConnectionPool;
        private bool ContinueProcess;
        private int numOfThread;
        private Thread[] ThreadTask;
    }
}

