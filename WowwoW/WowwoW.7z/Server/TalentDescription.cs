namespace Server
{
    using System;
    using System.Collections;

    public class TalentDescription
    {
        // Methods
        static TalentDescription()
        {
            TalentDescription.all = new Hashtable();
            TalentDescription.talentList = new Hashtable();
        }

        public TalentDescription(int i, int r, int[] fx, int reqfx, int reql)
        {
            this.id = i;
            this.rank = r;
            this.effects = fx;
            this.reqEffect = reqfx;
            this.reqLevel = reql;
        }

        public BaseAbility AuraFX(int l)
        {
            return Abilities.abilities[this.effects[l]];
        }

        public int AuraFXId(int l)
        {
            return this.effects[l];
        }

        public static bool IsTalent(int id)
        {
            if (TalentDescription.talentList[id] == null)
            {
                return false;
            }
            return true;
        }


        // Fields
        public static Hashtable all;
        private int[] effects;
        private int id;
        private int rank;
        private int reqEffect;
        private int reqLevel;
        public static Hashtable talentList;
    }
}

