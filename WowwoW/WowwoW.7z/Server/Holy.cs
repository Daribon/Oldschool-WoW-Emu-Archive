namespace Server
{
    using System;

    public class Holy : Skill
    {
        // Methods
        public Holy()
        {
        }

        public Holy(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x38;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x38;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

