namespace Server
{
    using System;

    public enum Resistances
    {
        // Fields
        Arcane = 6,
        Armor = 0,
        Fire = 2,
        Frost = 4,
        Light = 1,
        Nature = 3,
        Shadow = 5
    }
}

