namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool LearnProfession(Character c, ProfessionLevels level, Professions type);

}

