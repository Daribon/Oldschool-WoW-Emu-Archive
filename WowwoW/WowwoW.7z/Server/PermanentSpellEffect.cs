namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void PermanentSpellEffect(BaseAbility ba, Mobile c);

}

