namespace Server
{
    using System;

    public class SkillTemplate : BaseAbility
    {
        // Methods
        public SkillTemplate(ushort id, int typ) : base(id, 0x7d0)
        {
            this.type = typ;
        }


        // Fields
        private int type;
    }
}

