namespace Server
{
    using System;

    public class DeliveryObjective
    {
        // Methods
        public DeliveryObjective(int id, int amount)
        {
            this._id = id;
            this._amount = amount;
        }


        // Properties
        public int Amount
        {
            get
            {
                return this._amount;
            }
        }

        public bool ExistsInWorld
        {
            get
            {
                return (World.ItemsPool[this._id] != null);
            }
        }

        public int Id
        {
            get
            {
                return this._id;
            }
        }


        // Fields
        private int _amount;
        private int _id;
    }
}

