namespace Server
{
    using System;

    public class TwoHandedSwordSkill : Skill
    {
        // Methods
        public TwoHandedSwordSkill()
        {
        }

        public TwoHandedSwordSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x37;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x37;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xca;
            }
        }

    }
}

