namespace Server
{
    using System;

    public class BowsSkill : Skill
    {
        // Methods
        public BowsSkill()
        {
        }

        public BowsSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x2d;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x2d;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x108;
            }
        }

    }
}

