namespace Server
{
    using System;

    public enum qRaces
    {
        // Fields
        Alliance = 2,
        Any = 0,
        Dwarf = 4,
        Gnome = 6,
        Horde = 1,
        Human = 3,
        NightElf = 5,
        Orc = 7,
        Tauren = 9,
        Troll = 10,
        Undead = 8
    }
}

