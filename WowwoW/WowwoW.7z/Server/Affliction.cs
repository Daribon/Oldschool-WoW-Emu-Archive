namespace Server
{
    using System;

    public class Affliction : Skill
    {
        // Methods
        public Affliction()
        {
        }

        public Affliction(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x163;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x163;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

