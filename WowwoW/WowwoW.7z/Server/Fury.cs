namespace Server
{
    using System;

    public class Fury : Skill
    {
        // Methods
        public Fury()
        {
        }

        public Fury(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x100;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x100;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

