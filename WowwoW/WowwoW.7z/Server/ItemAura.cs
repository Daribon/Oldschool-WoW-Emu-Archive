namespace Server
{
    using Server.Items;
    using System;

    public class ItemAura : Aura
    {
        // Methods
        public ItemAura(Item it)
        {
            this.item = it;
        }

        public override void Release(Mobile m)
        {
            if (this.effect != EffectTypes.FireAbsorb)
            {
                m.CumulativeAuraEffects[this.effect] = null;
            }
            if (this.auraPeriodicTimer != null)
            {
                this.auraPeriodicTimer.Stop();
                this.auraPeriodicTimer = null;
            }
            if (this.OnRelease != null)
            {
                (this.OnRelease as Aura.ItemAuraReleaseDelegate)(m, this.item);
            }
        }


        // Fields
        private Item item;
    }
}

