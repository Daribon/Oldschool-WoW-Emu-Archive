namespace Server
{
    using System;

    public enum AttackStatus : byte
    {
        // Fields
        Absorb = 3,
        Block = 7,
        Critical = 4,
        Dodge = 5,
        Immune = 8,
        Loose = 2,
        None = 0,
        NormalHit = 1,
        Parry = 6
    }
}

