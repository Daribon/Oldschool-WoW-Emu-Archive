namespace Server
{
    using System;

    public class FireSkill : Skill
    {
        // Methods
        public FireSkill()
        {
        }

        public FireSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 8;
            }
        }

        public static int SkillId
        {
            get
            {
                return 8;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

