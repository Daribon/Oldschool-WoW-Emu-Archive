namespace Server
{
    using Server.Items;
    using System;

    public class BaseQuest
    {
        // Methods
        static BaseQuest()
        {
            BaseQuest.onStartQuestDefault = null;
            BaseQuest.onEndQuestDefault = null;
            BaseQuest.onQuestStatus = null;
        }

        public BaseQuest()
        {
            this.onStartQuestCustom = null;
            this.onEndQuestCustom = null;
            this.id = 0;
            this.npcId = 0;
            this.zone = 0;
            this.questFlags = 0x20;
            this.name = "";
            this.desc = "";
            this.details = "";
            this.details2 = "";
            this.progressTitle = "";
            this.progressDialog = "";
            this.finishTitle = "";
            this.finishDialog = "";
            this.rewardXp = 0;
            this.rewardGold = 0;
            this.rewardSpell = 0;
            this.reward = new RewardArray();
            this.rewardChoice = new RewardChoiceArray();
            this.npcObjectives = new NPCObjectiveArray();
            this.deliveryObjectives = new DeliveryObjectiveArray();
            this.discoverigArea = new DiscoveryAreaArray();
            this.miniMapPos = null;
            this.sourceItemId = 0;
            this.npcTargetId = 0;
            this.repeatable = false;
            this.minLevel = 0;
            this.idealLevel = 0;
            this.previousQuest = 0;
            this.nextQuest = 0;
            this.minReputation = 0.5f;
            this.skillsAllowed = new SkillsArray();
            this.classAllowed = qClasses.Any;
            this.raceAllowed = qRaces.Any;
            this.questType = Server.QuestType.None;
            this.faction1 = null;
            this.faction2 = null;
            this.questIsBugged = false;
            if (World.poolsReady)
            {
                this.InitObjectives();
            }
        }

        public virtual bool AllowedClass(Character c)
        {
            bool flag1 = true;
            if (this.classAllowed != qClasses.Any)
            {
                switch (c.Classe)
                {
                    case Classes.Warrior:
                    {
                        return (this.classAllowed == qClasses.Warrior);
                    }
                    case Classes.Paladin:
                    {
                        return (this.classAllowed == qClasses.Paladin);
                    }
                    case Classes.Hunter:
                    {
                        return (this.classAllowed == qClasses.Hunter);
                    }
                    case Classes.Rogue:
                    {
                        return (this.classAllowed == qClasses.Rogue);
                    }
                    case Classes.Priest:
                    {
                        return (this.classAllowed == qClasses.Priest);
                    }
                    case (Classes.Rogue | Classes.Paladin):
                    case (Classes.Mage | Classes.Paladin):
                    {
                        return flag1;
                    }
                    case Classes.Shaman:
                    {
                        return (this.classAllowed == qClasses.Shaman);
                    }
                    case Classes.Mage:
                    {
                        return (this.classAllowed == qClasses.Mage);
                    }
                    case Classes.Warlock:
                    {
                        return (this.classAllowed == qClasses.Warlock);
                    }
                    case Classes.Druid:
                    {
                        return (this.classAllowed == qClasses.Druid);
                    }
                }
            }
            return flag1;
        }

        public virtual bool AllowedRace(Character c)
        {
            bool flag1 = true;
            if (this.raceAllowed != qRaces.Any)
            {
                qRaces races1 = this.raceAllowed;
                switch (c.Race)
                {
                    case Races.Human:
                    {
                        return ((races1 == qRaces.Human) || (races1 == qRaces.Alliance));
                    }
                    case Races.Orc:
                    {
                        return ((races1 == qRaces.Orc) || (races1 == qRaces.Horde));
                    }
                    case Races.Dwarf:
                    {
                        return ((races1 == qRaces.Dwarf) || (races1 == qRaces.Alliance));
                    }
                    case Races.NightElf:
                    {
                        return ((races1 == qRaces.NightElf) || (races1 == qRaces.Alliance));
                    }
                    case Races.Undead:
                    {
                        return ((races1 == qRaces.Undead) || (races1 == qRaces.Horde));
                    }
                    case Races.Tauren:
                    {
                        return ((races1 == qRaces.Tauren) || (races1 == qRaces.Horde));
                    }
                    case Races.Gnome:
                    {
                        return ((races1 == qRaces.Gnome) || (races1 == qRaces.Alliance));
                    }
                    case Races.Troll:
                    {
                        return ((races1 == qRaces.Troll) || (races1 == qRaces.Horde));
                    }
                }
            }
            return flag1;
        }

        public bool AllowedSkills(Character c)
        {
            bool flag1 = true;
            qSkills[] skillsArray1 = this.skillsAllowed.Items;
            for (int num1 = 0; num1 < skillsArray1.Length; num1++)
            {
                qSkills skills1 = skillsArray1[num1];
                flag1 = flag1 && c.HaveSkill((int) skills1);
            }
            return flag1;
        }

        public int ChoiceRewardAmount(int sel)
        {
            return this.rewardChoice.RewardAmount(sel);
        }

        public Item ChoiceRewardCreate(int sel)
        {
            return this.rewardChoice.RewardItem(sel);
        }

        public bool HasReward()
        {
            return (this.reward.Count > 0);
        }

        public bool HasRewardChoice()
        {
            return (this.rewardChoice.Count > 0);
        }

        public virtual void InitObjectives()
        {
        }

        public virtual void OnAcceptQuest(Character c)
        {
        }

        public virtual DialogStatus QuestStatus(Mobile m, Character c)
        {
            if (BaseQuest.onQuestStatus != null)
            {
                return BaseQuest.onQuestStatus(m, c, this);
            }
            return DialogStatus.ChatUnAvailable;
        }


        // Properties
        public qClasses ClassAllowed
        {
            get
            {
                return this.classAllowed;
            }
        }

        public TimeSpan CompletionTime
        {
            get
            {
                return this.completionTime;
            }
        }

        public bool DeliveryNotForOwner
        {
            get
            {
                if (this.HaveNPCTargetId)
                {
                    return this.HaveDeliveryObj;
                }
                return false;
            }
        }

        public DeliveryObjectiveArray DeliveryObjectives
        {
            get
            {
                return this.deliveryObjectives;
            }
        }

        public string Desc
        {
            get
            {
                return this.desc;
            }
        }

        public string Details
        {
            get
            {
                return this.details;
            }
        }

        public string Details2
        {
            get
            {
                return this.details2;
            }
        }

        public DiscoveryAreaArray DiscoverigArea
        {
            get
            {
                return this.discoverigArea;
            }
        }

        public FactionLimit Faction1
        {
            get
            {
                return this.faction1;
            }
        }

        public FactionLimit Faction2
        {
            get
            {
                return this.faction2;
            }
        }

        public string FinishDialog
        {
            get
            {
                return this.finishDialog;
            }
        }

        public string FinishTitle
        {
            get
            {
                return this.finishTitle;
            }
        }

        public bool HaveDeliveryObj
        {
            get
            {
                return (this.deliveryObjectives.Count > 0);
            }
        }

        public bool HaveDiscoveryObj
        {
            get
            {
                return (this.discoverigArea.Count > 0);
            }
        }

        public bool HaveNPCObj
        {
            get
            {
                return (this.npcObjectives.Count > 0);
            }
        }

        public bool HaveNPCTargetId
        {
            get
            {
                return (this.npcTargetId > 0);
            }
        }

        public int Id
        {
            get
            {
                return this.id;
            }
        }

        public int IdealLevel
        {
            get
            {
                return this.idealLevel;
            }
        }

        public Position MiniMapPos
        {
            get
            {
                return this.miniMapPos;
            }
        }

        public int MinLevel
        {
            get
            {
                return this.minLevel;
            }
        }

        public float MinReputation
        {
            get
            {
                return this.minReputation;
            }
        }

        public string Name
        {
            get
            {
                return this.name;
            }
        }

        public int NextQuest
        {
            get
            {
                return this.nextQuest;
            }
        }

        public int NPCId
        {
            get
            {
                return this.npcId;
            }
        }

        public NPCObjectiveArray NPCObjectives
        {
            get
            {
                return this.npcObjectives;
            }
        }

        public int NPCTargetId
        {
            get
            {
                return this.npcTargetId;
            }
        }

        public int PreviousQuest
        {
            get
            {
                return this.previousQuest;
            }
        }

        public string ProgressDialog
        {
            get
            {
                return this.progressDialog;
            }
        }

        public string ProgressTitle
        {
            get
            {
                return this.progressTitle;
            }
        }

        public int QuestFlags
        {
            get
            {
                return this.questFlags;
            }
        }

        public bool QuestIsBugged
        {
            get
            {
                return this.questIsBugged;
            }
        }

        public Server.QuestType QuestType
        {
            get
            {
                return this.questType;
            }
        }

        public qRaces RaceAllowed
        {
            get
            {
                return this.raceAllowed;
            }
        }

        public bool Repeatable
        {
            get
            {
                return this.repeatable;
            }
        }

        public RewardArray Reward
        {
            get
            {
                return this.reward;
            }
        }

        public RewardChoiceArray RewardChoice
        {
            get
            {
                return this.rewardChoice;
            }
        }

        public int RewardGold
        {
            get
            {
                return this.rewardGold;
            }
        }

        public int RewardSpell
        {
            get
            {
                return this.rewardSpell;
            }
        }

        public int RewardXp
        {
            get
            {
                return this.rewardXp;
            }
        }

        public SkillsArray SkillsAllowed
        {
            get
            {
                return this.skillsAllowed;
            }
        }

        public int SourceItemId
        {
            get
            {
                return this.sourceItemId;
            }
        }

        public int Zone
        {
            get
            {
                return this.zone;
            }
        }


        // Fields
        protected qClasses classAllowed;
        protected TimeSpan completionTime;
        protected DeliveryObjectiveArray deliveryObjectives;
        protected string desc;
        protected string details;
        protected string details2;
        protected DiscoveryAreaArray discoverigArea;
        protected FactionLimit faction1;
        protected FactionLimit faction2;
        protected string finishDialog;
        protected string finishTitle;
        protected int id;
        protected int idealLevel;
        protected Position miniMapPos;
        protected int minLevel;
        protected float minReputation;
        protected string name;
        protected int nextQuest;
        protected int npcId;
        protected NPCObjectiveArray npcObjectives;
        protected int npcTargetId;
        public qEmote[] onEndQuestCustom;
        public static qEmote[] onEndQuestDefault;
        public static QuestDialogStatusDelegate onQuestStatus;
        public qEmote[] onStartQuestCustom;
        public static qEmote[] onStartQuestDefault;
        protected int previousQuest;
        protected string progressDialog;
        protected string progressTitle;
        protected int questFlags;
        protected bool questIsBugged;
        protected Server.QuestType questType;
        protected qRaces raceAllowed;
        protected bool repeatable;
        protected RewardArray reward;
        protected RewardChoiceArray rewardChoice;
        protected int rewardGold;
        protected int rewardSpell;
        protected int rewardXp;
        protected SkillsArray skillsAllowed;
        protected int sourceItemId;
        protected int zone;
    }
}

