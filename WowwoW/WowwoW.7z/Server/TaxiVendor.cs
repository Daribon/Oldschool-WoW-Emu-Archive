namespace Server
{
    using System;

    public class TaxiVendor : BaseCreature
    {
        // Methods
        public TaxiVendor()
        {
        }


        // Fields
        public int MountId;
    }
}

