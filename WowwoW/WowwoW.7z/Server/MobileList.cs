namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Threading;

    [Serializable]
    public class MobileList : CollectionBase
    {
        // Methods
        static MobileList()
        {
            MobileList.TempSummon = new Hashtable();
        }

        public MobileList()
        {
            this.onKalimdor = new ArrayList();
            this.onEasternKindoms = new ArrayList();
        }

        public MobileList(Mobile[] val)
        {
            this.onKalimdor = new ArrayList();
            this.onEasternKindoms = new ArrayList();
            this.AddRange(val);
        }

        public MobileList(GenericReader gr)
        {
            this.onKalimdor = new ArrayList();
            this.onEasternKindoms = new ArrayList();
            Thread.CurrentThread.Priority = ThreadPriority.Highest;
            base.List.Clear();
            if (!gr.notFound)
            {
                this.Deserialize(gr);
            }
        }

        public int Add(Mobile val)
        {
            val.moveVector = new Mobile.MoveVector(val, val.X, val.Y, val.Z);
            if (val.MapId == 0)
            {
                return this.onEasternKindoms.Add(val);
            }
            return this.onKalimdor.Add(val);
        }

        public int Add(Mobile val, bool sendToAllPlayer)
        {
            return this.Add(val);
        }

        public void AddRange(Mobile[] val)
        {
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public bool Contains(Mobile val)
        {
            if (val.MapId == 0)
            {
                return this.onEasternKindoms.Contains(val);
            }
            return this.onKalimdor.Contains(val);
        }

        public virtual void Deserialize(GenericReader gr)
        {
            gr.ReadInt();
            Server.Object.GUID = gr.ReadInt64();
            while (true)
            {
                int num1 = gr.ReadInt();
                if (num1 == 0)
                {
                    break;
                }
                this.Add(Mobile.Load(gr));
            }
            gr.Close();
        }

        public ArrayList GetContinent(ushort mapId)
        {
            if (mapId == 0)
            {
                return this.onEasternKindoms;
            }
            return this.onKalimdor;
        }

        public new MobileEnumerator GetEnumerator()
        {
            return new MobileEnumerator(this);
        }

        public void Remove(Mobile val)
        {
            if (val.MapId == 0)
            {
                this.onEasternKindoms.Remove(val);
            }
            this.onKalimdor.Remove(val);
        }

        public virtual void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            gw.Write(Server.Object.GUID);
            foreach (Mobile mobile1 in this.onEasternKindoms)
            {
                if ((mobile1 is Corps) || ((mobile1.SummonedBy == null) && (mobile1.CharmedBy == null)))
                {
                    continue;
                }
                gw.Write(1);
                mobile1.Serialize(gw);
            }
            foreach (Mobile mobile2 in this.onKalimdor)
            {
                if (!(mobile2 is Corps) && ((mobile2.SummonedBy != null) || (mobile2.CharmedBy != null)))
                {
                    gw.Write(1);
                    mobile2.Serialize(gw);
                }
            }
        }


        // Fields
        public ArrayList onEasternKindoms;
        public ArrayList onKalimdor;
        public static Hashtable TempSummon;

        // Nested Types
        public class MobileEnumerator : IEnumerator
        {
            // Methods
            public MobileEnumerator(MobileList mappings)
            {
                this.cursor = 0;
                this.mapId = 0;
                this.from = mappings;
            }

            public bool MoveNext()
            {
                if (this.mapId == 0)
                {
                    this.cursor++;
                    if (this.cursor != this.from.onEasternKindoms.Count)
                    {
                        return false;
                    }
                    if (this.from.onKalimdor.Count == 0)
                    {
                        return false;
                    }
                    this.cursor = 0;
                    this.mapId = 1;
                    return true;
                }
                this.cursor++;
                if (this.from.onKalimdor.Count <= this.cursor)
                {
                    return false;
                }
                return true;
            }

            public void Reset()
            {
                this.cursor = 0;
                this.mapId = 0;
            }

            bool IEnumerator.MoveNext()
            {
                if (this.mapId == 0)
                {
                    this.cursor++;
                    if (this.cursor != this.from.onEasternKindoms.Count)
                    {
                        return false;
                    }
                    if (this.from.onKalimdor.Count == 0)
                    {
                        return false;
                    }
                    this.cursor = 0;
                    this.mapId = 1;
                    return true;
                }
                this.cursor++;
                if (this.from.onKalimdor.Count <= this.cursor)
                {
                    return false;
                }
                return true;
            }

            void IEnumerator.Reset()
            {
                this.cursor = 0;
                this.mapId = 0;
            }


            // Properties
            public Mobile Current
            {
                get
                {
                    if (this.mapId == 0)
                    {
                        return (Mobile) this.from.onEasternKindoms[this.cursor];
                    }
                    return (Mobile) this.from.onKalimdor[this.cursor];
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    if (this.mapId == 0)
                    {
                        return (Mobile) this.from.onEasternKindoms[this.cursor];
                    }
                    return (Mobile) this.from.onKalimdor[this.cursor];
                }
            }


            // Fields
            private int cursor;
            private MobileList from;
            private int mapId;
        }
    }
}

