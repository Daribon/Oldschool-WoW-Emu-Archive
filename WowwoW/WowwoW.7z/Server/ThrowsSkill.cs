namespace Server
{
    using System;

    public class ThrowsSkill : Skill
    {
        // Methods
        public ThrowsSkill()
        {
        }

        public ThrowsSkill(int current, int max) : base(current, 0xffff)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0xb0;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0xb0;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0xa07;
            }
        }

    }
}

