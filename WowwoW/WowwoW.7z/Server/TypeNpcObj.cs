namespace Server
{
    using System;

    public enum TypeNpcObj : byte
    {
        // Fields
        GameObject = 1,
        Mobile = 0
    }
}

