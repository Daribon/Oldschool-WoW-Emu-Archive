namespace Server
{
    using Server.Items;
    using System;
    using System.Collections;

    public class BaseRewardArray
    {
        // Methods
        public BaseRewardArray(int max)
        {
            this._items = new ArrayList();
            this._max = 0;
            this._max = max;
        }

        public void Add(Reward r)
        {
            if (r.ExistsInWorld)
            {
                if (!this.CanAdd)
                {
                    return;
                }
                this._items.Add(r);
            }
            else
            {
                BadIdList.AddItemId(r.Id);
            }
        }

        public void Add(int id, int amount)
        {
            this.Add(new Reward(id, amount));
        }

        public int RewardAmount(int sel)
        {
            Reward reward1 = (Reward) this._items[sel];
            if (reward1 == null)
            {
                return 0;
            }
            return reward1.Amount;
        }

        public Item RewardItem(int sel)
        {
            Reward reward1 = (Reward) this._items[sel];
            if (reward1 == null)
            {
                return null;
            }
            return reward1.CreateItem();
        }


        // Properties
        private bool CanAdd
        {
            get
            {
                return (this.Count < this._max);
            }
        }

        public int Count
        {
            get
            {
                return this._items.Count;
            }
        }

        public Reward[] Items
        {
            get
            {
                return (Reward[]) this._items.ToArray(typeof(Reward));
            }
        }


        // Fields
        private ArrayList _items;
        private int _max;
    }
}

