namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;

    public class Group
    {
        // Methods
        public Group()
        {
            this.members = new ArrayList();
            this.members = new ArrayList();
        }

        public void Add(Character c)
        {
            this.Add(c, 1);
        }

        public void Add(Character c, ushort droit)
        {
            Member member1 = new Member(c);
            member1.Droits = droit;
            this.members.Add(member1);
            if (this.Count == 1)
            {
                this.groupLeader = member1;
            }
            else
            {
                this.UpdateList();
            }
        }

        public void PromoteLeader(Character c)
        {
            foreach (Member member1 in this.Members)
            {
                int num1 = 4;
                Converter.ToBytes(member1.Char.Name, this.groupLeader.Char.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.groupLeader.Char.tempBuff, ref num1);
                member1.Char.Send(OpCodes.SMSG_GROUP_SET_LEADER, this.groupLeader.Char.tempBuff, num1);
                if (c == member1.Char)
                {
                    this.groupLeader = member1;
                }
            }
            this.UpdateList();
        }

        public void Quit(Character c)
        {
            if (this.members != null)
            {
                ArrayList list1 = new ArrayList();
                foreach (Member member1 in this.members)
                {
                    if (member1.Char == c)
                    {
                        c.Send(OpCodes.SMSG_GROUP_DESTROYED, c.tempBuff, 4);
                        continue;
                    }
                    list1.Add(member1);
                }
                this.members = list1;
                if (this.Count > 1)
                {
                    if (this.groupLeader.Char == c)
                    {
                        this.groupLeader = (Member) list1[0];
                    }
                    this.UpdateList();
                }
                else if (this.Count == 1)
                {
                    (this.members[0] as Member).Char.Send(OpCodes.SMSG_GROUP_DESTROYED, c.tempBuff, 4);
                    (this.members[0] as Member).Char.QuitGroup();
                }
            }
        }

        private void UpdateList()
        {
            foreach (Member member1 in this.Members)
            {
                int num1 = 4;
                Converter.ToBytes((short) 0, this.groupLeader.Char.tempBuff, ref num1);
                Converter.ToBytes(this.Count, this.groupLeader.Char.tempBuff, ref num1);
                int num2 = 0;
                foreach (Member member2 in this.Members)
                {
                    Converter.ToBytes(member2.Char.Name, this.groupLeader.Char.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.groupLeader.Char.tempBuff, ref num1);
                    Converter.ToBytes(member2.Char.Guid, this.groupLeader.Char.tempBuff, ref num1);
                    if (member1 == member2)
                    {
                        Converter.ToBytes((ushort) 0x101, this.groupLeader.Char.tempBuff, ref num1);
                    }
                    else
                    {
                        Converter.ToBytes((ushort) 1, this.groupLeader.Char.tempBuff, ref num1);
                    }
                    num2++;
                }
                Converter.ToBytes(this.GroupLeader.Char.Guid, this.groupLeader.Char.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.groupLeader.Char.tempBuff, ref num1);
                Converter.ToBytes(this.GroupLeader.Char.Guid, this.groupLeader.Char.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.groupLeader.Char.tempBuff, ref num1);
                member1.Char.Send(OpCodes.SMSG_GROUP_LIST, this.groupLeader.Char.tempBuff, num1);
            }
        }


        // Properties
        public int Count
        {
            get
            {
                return this.members.Count;
            }
        }

        public Member GroupLeader
        {
            get
            {
                return this.groupLeader;
            }
        }

        public ArrayList Members
        {
            get
            {
                return this.members;
            }
        }


        // Fields
        private Member groupLeader;
        private ArrayList members;
    }
}

