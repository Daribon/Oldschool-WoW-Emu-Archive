namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;

    public class AgressiveAnimalAI : BaseAIType
    {
        // Methods
        public AgressiveAnimalAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.Explore;
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if ((AIState != AIStates.Attack) && (AIState != AIStates.Fighting))
            {
                base.OnBeginFight(by);
                return AIStates.BeingAttacked;
            }
            return AIState;
        }

        public override void OnTick()
        {
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 625f))
            {
                base.From.AIState = AIStates.Explore;
                base.From.AttackTarget = null;
            }
            else
            {
                if ((base.From.AttackTarget == null) || base.From.AttackTarget.Dead)
                {
                    ArrayList list1 = base.From.KnownObjects();
                    Utility.Random16();
                    Utility.Random16();
                    foreach (Server.Object obj1 in list1)
                    {
                        if (!(obj1 is Mobile))
                        {
                            continue;
                        }
                        Mobile mobile1 = obj1 as Mobile;
                        if ((((base.From.Distance(mobile1) < base.MaxViewDistance) && (Utility.Random4() == 0)) && (base.From.IsHostile(mobile1) && base.From.CanSee(mobile1))) && !mobile1.Dead)
                        {
                            base.OnBeginFight(mobile1);
                            base.From.AIState = AIStates.BeingAttacked;
                            base.From.AttackTarget = mobile1;
                            return;
                        }
                    }
                }
                switch (base.AIState)
                {
                    case AIStates.DoingNothing:
                    {
                        base.AIState = AIStates.Explore;
                        return;
                    }
                    case AIStates.Explore:
                    {
                        if (Utility.Random16() >= 2)
                        {
                            if (Utility.Random16() < 4)
                            {
                                base.AIState = AIStates.Pause4;
                            }
                            return;
                        }
                        base.AIState = AIStates.Pause1;
                        return;
                    }
                    case AIStates.Pause1:
                    {
                        base.AIState = AIStates.Pause2;
                        return;
                    }
                    case AIStates.Pause2:
                    {
                        base.AIState = AIStates.Pause3;
                        return;
                    }
                    case AIStates.Pause3:
                    {
                        base.AIState = AIStates.Pause4;
                        return;
                    }
                    case AIStates.Pause4:
                    {
                        base.AIState = AIStates.Pause5;
                        return;
                    }
                    case AIStates.Pause5:
                    {
                        base.AIState = AIStates.Explore;
                        return;
                    }
                }
            }
        }

    }
}

