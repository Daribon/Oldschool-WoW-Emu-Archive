namespace Server
{
    using System;

    public enum TrackableResources
    {
        // Fields
        ElvenGems = 7,
        GahzRidian = 15,
        Herbs = 2,
        Minerals = 3,
        Treasure = 6
    }
}

