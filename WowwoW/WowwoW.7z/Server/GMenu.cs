namespace Server
{
    using System;
    using System.Collections;

    public class GMenu
    {
        // Methods
        public GMenu()
        {
            this.list = new ArrayList();
        }

        public GMenu(GMenuItem item)
        {
            this.list = new ArrayList();
            this.Add(item);
        }

        public GMenu(uint menuId, GMenuIcons icon, bool inputBox, string text)
        {
            this.list = new ArrayList();
            this.Add(menuId, icon, inputBox, text);
        }

        public void Add(GMenuItem item)
        {
            this.list.Add(item);
        }

        public void Add(uint menuId, GMenuIcons icon, bool inputBox, string text)
        {
            this.list.Add(new GMenuItem(menuId, icon, inputBox, text));
        }


        // Properties
        public int Count
        {
            get
            {
                return this.list.Count;
            }
        }

        public GMenuItem[] Items
        {
            get
            {
                return (GMenuItem[]) this.list.ToArray(typeof(GMenuItem));
            }
        }


        // Fields
        private ArrayList list;
    }
}

