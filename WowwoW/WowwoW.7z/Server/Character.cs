namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;
    using System.IO;
    using System.Reflection;
	using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class Character : Mobile
    {
        // Methods
        static Character()
        {
            Character.allCharacters = new ArrayList();
            Character.decal = 0;
            Character.num = 0x16;
            Character.gmInvisibilityAura = new GMInvisibilityAura();
            Character.handToHand = new HandsFighting();
        }

        public Character()
        {
            this.reputationAdjustments = new Hashtable();
            this.friends = new ArrayList();
            this.actionBar = new ArrayList();
            this.zones = new uint[0x20];
            this.linkedSpawner = -1;
            this.logged = false;
            this.activeQuests = new ActiveQuest[20];
            this.questsDone = new Hashtable();
            this.tradeItems = new int[7];
            this.TaxiField = new uint[8];
            this.previousSpellCasted = 0;
            this._gossipOpened = false;
            this.Duel = 0;
            this.lastAreaTrigger = DateTime.Now;
            this.deadEndTeleportLoop = false;
            this.team1 = new ArrayList();
            this.team2 = new ArrayList();
            this.testCombatStarted = false;
            this.startTrajetFlag = null;
            this.ff = 1;
            this.tooFar = new byte[4] { 0, 2, 0x45, 1 } ;
            this.hitBuffer = new byte[0x41] { 
                0, 0x3f, 0x4a, 1, 6, 0, 0, 0, 0x9b, 0x36, 0x21, 0, 0, 0, 0, 0, 
                0x91, 20, 0x21, 0, 0, 0, 0, 0, 10, 0, 0, 0, 1, 0, 0, 0, 
                0, 0, 0, 0x20, 0x41, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 
                0, 0xe8, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0
             } ;
            this.last = DateTime.Now;
            this.group = new Group();
            this.pendingGroupRequest = new ArrayList();
        }

		public Character(Account acc, byte[] data) : this(-8897.5f, -173.48f, 81.5775f, 0f)
		{
			int num5;
			this.account = acc;
			base.Name = "";
			int num1 = 0;
			for (int num2 = 6; num2 < data.Length; num2++)
			{
				byte num3 = data[num2];
				if (num1 == 0)
				{
					if (num3 == 0)
					{
						num1++;
						goto Label_06AB;
					}
					if ((num3 != 0) && (num1 == 0))
					{
						base.Name = base.Name + ((char) num3);
					}
					goto Label_06AB;
				}
				if (num1 == 1)
				{
					this.race = (Races) num3;
					num1++;
					goto Label_06AB;
				}
				if (num1 != 2)
				{
					goto Label_0645;
				}
				switch (num3)
				{
					case 1:
					{
						base.Classe = Classes.Warrior;
						this.manaType = 1;
						base.AllSkills.Add(new DaggerSkill(1, 300));
						base.AllSkills.Add(new AxeSkill(1, 300));
						base.AllSkills.Add(new SwordSkill(1, 300));
						base.AllSkills.Add(new MacesSkill(1, 300));
						base.AllSkills.Add(new ShieldSkill(1, 1));
						base.AllSkills.Add(new ClothSkill(1, 1));
						base.AllSkills.Add(new LeatherSkill(1, 1));
						base.AllSkills.Add(new MailSkill(1, 1));
						if ((this.Race != Races.Orc) && (this.Race != Races.Dwarf))
						{
							break;
						}
						base.AllSkills.Add(new TwoHandedAxeSkill(1, 300));
						goto Label_01D7;
					}
					case 2:
					{
						base.Classe = Classes.Paladin;
						this.manaType = 0;
						base.AllSkills.Add(new TwoHandedMaceSkill(1, 300));
						base.AllSkills.Add(new MacesSkill(1, 300));
						base.AllSkills.Add(new ClothSkill(1, 1));
						base.AllSkills.Add(new ShieldSkill(1, 1));
						base.AllSkills.Add(new LeatherSkill(1, 1));
						base.AllSkills.Add(new MailSkill(1, 1));
						goto Label_063F;
					}
					case 3:
					{
						base.Classe = Classes.Hunter;
						this.manaType = 0;
						base.AllSkills.Add(new AxeSkill(1, 300));
						base.AllSkills.Add(new BowsSkill(1, 300));
						base.AllSkills.Add(new DaggerSkill(1, 300));
						base.AllSkills.Add(new LeatherSkill(1, 1));
						base.AllSkills.Add(new ClothSkill(1, 1));
						base.AllSkills.Add(new GunSkill(1, 300));
						goto Label_063F;
					}
					case 4:
					{
						base.Classe = Classes.Rogue;
						this.manaType = 3;
						base.AllSkills.Add(new ThrowsSkill(1, 300));
						base.AllSkills.Add(new DaggerSkill(1, 300));
						base.AllSkills.Add(new ThrowsSkill(1, 300));
						base.AllSkills.Add(new ClothSkill(1, 1));
						base.AllSkills.Add(new LeatherSkill(1, 1));
						base.AllSkills.Add(new Assassination(1, 1));
						base.AllSkills.Add(new Subtlety(1, 1));
						base.AllSkills.Add(new Combat(1, 1));
						base.BaseMana = num5 = 100;
						base.Mana = num5;
						goto Label_063F;
					}
					case 5:
					{
						base.Classe = Classes.Priest;
						this.manaType = 0;
						base.AllSkills.Add(new WandsSkill(1, 300));
						base.AllSkills.Add(new MacesSkill(1, 300));
						base.AllSkills.Add(new ClothSkill(1, 1));
						goto Label_063F;
					}
					case 6:
					case 10:
					{
						goto Label_0638;
					}
					case 7:
					{
						base.Classe = Classes.Shaman;
						this.manaType = 0;
						base.AllSkills.Add(new StavesSkill(1, 300));
						base.AllSkills.Add(new MacesSkill(1, 300));
						base.AllSkills.Add(new ClothSkill(1, 1));
						base.AllSkills.Add(new LeatherSkill(1, 1));
						goto Label_063F;
					}
					case 8:
					{
						base.Classe = Classes.Mage;
						this.manaType = 0;
						base.AllSkills.Add(new WandsSkill(1, 300));
						base.AllSkills.Add(new StavesSkill(1, 300));
						base.AllSkills.Add(new ClothSkill(1, 300));
						base.AllSkills.Add(new ArcaneSkill(1, 300));
						base.AllSkills.Add(new FireSkill(1, 300));
						base.AllSkills.Add(new FrostSkill(1, 300));
						base.BaseMana = num5 = 100;
						base.Mana = num5;
						goto Label_063F;
					}
					case 9:
					{
						base.Classe = Classes.Warlock;
						this.manaType = 0;
						base.AllSkills.Add(new WandsSkill(1, 300));
						base.AllSkills.Add(new DaggerSkill(1, 300));
						base.AllSkills.Add(new Destruction(1, 300));
						base.AllSkills.Add(new Demonology(1, 300));
						base.AllSkills.Add(new Affliction(1, 300));
						base.AllSkills.Add(new ClothSkill(1, 1));
						base.BaseMana = num5 = 100;
						base.Mana = num5;
						goto Label_063F;
					}
					case 11:
					{
						base.Classe = Classes.Druid;
						this.manaType = 0;
						base.AllSkills.Add(new StavesSkill(1, 300));
						base.AllSkills.Add(new LeatherSkill(1, 1));
						base.AllSkills.Add(new ClothSkill(1, 1));
						goto Label_063F;
					}
					default:
					{
						goto Label_0638;
					}
				}
				if (this.Race == Races.Tauren)
				{
					base.AllSkills.Add(new TwoHandedMaceSkill(1, 300));
				}
				else
				{
					base.AllSkills.Add(new TwoHandedSwordSkill(1, 300));
				}
			Label_01D7:
				base.AllSkills.Add(new Arms(1, 1));
				base.AllSkills.Add(new Protection(1, 1));
				base.BaseMana = num5 = 100;
				base.Mana = num5;
				goto Label_063F;
			Label_0638:
				this.manaType = 0;
			Label_063F:
				num1++;
				goto Label_06AB;
			Label_0645:
				if (num1 == 3)
				{
					this.gender = num3;
					num1++;
				}
				else if (num1 == 4)
				{
					this.skin = num3;
					num1++;
				}
				else if (num1 == 5)
				{
					this.face = num3;
					num1++;
				}
				else if (num1 == 6)
				{
					this.hairStyle = num3;
					num1++;
				}
				else if (num1 == 7)
				{
					this.hairColour = num3;
					num1++;
				}
				else if (num1 == 8)
				{
					this.facialHair = num3;
					num1++;
					break;
				}
			Label_06AB:;
            }
            Accounts.AccountEnumerator enumerator1 = World.allAccounts.GetEnumerator();
            try
            {
                while (enumerator1.MoveNext())
                {
                    foreach (Character character1 in enumerator1.Current.characteres)
                    {
                        if (character1.Name.ToLower() == base.Name.ToLower())
                        {
                            byte[] buffer1 = new byte[5] { 0, 3, 0x3a, 0, 0x39 } ;
                            this.Send(buffer1);
                            base.Name = null;
                            return;
                        }
                    }
                }
            }
            finally
            {
                IDisposable disposable1 = enumerator1 as IDisposable;
                if (disposable1 != null)
                {
                    disposable1.Dispose();
                }
            }
            base.MapId = 0;
            base.ZoneId = 9;
            base.HitPoints = 50;
            base.BaseHitPoints = 50;
            base.BaseRage = num5 = 350;
            base.Rage = num5;
            base.Level = 1;
            this.TrainAbility(0x194d);
            this.TrainAbility(0x194e);
            this.TrainAbility(0x1c62);
            switch (this.Race)
            {
                case Races.Human:
                {
                    base.Faction = Factions.Player_Human;
                    break;
                }
                case Races.Orc:
                {
                    base.Faction = Factions.Player_Orc;
                    break;
                }
                case Races.Dwarf:
                {
                    base.Faction = Factions.Player_Dwarf;
                    break;
                }
                case Races.NightElf:
                {
                    base.Faction = Factions.Player_Elf;
                    break;
                }
                case Races.Undead:
                {
                    base.Faction = Factions.Player_Undead;
                    break;
                }
                case Races.Tauren:
                {
                    base.Faction = Factions.Player_Tauren;
                    break;
                }
                case Races.Gnome:
                {
                    base.Faction = Factions.Player_Gnome;
                    break;
                }
                case Races.Troll:
                {
                    base.Faction = Factions.Player_Troll;
                    break;
                }
            }
            foreach (Factions factions1 in (World.FriendRaces[this.Race] as ArrayList))
            {
                this.reputationAdjustments[(int) World.FactionAssociated[factions1]] = 0;
            }
            Character.onCharacterChooseRace(this, this.race);
            this.Copper = 100;
            base.AllSkills.Add(new UnarmedSkill(1, 300));
            base.AllSkills.Add(new DefenseSkill(1, 300));
            this.OnCreateCharacter();
            byte[] buffer2 = new byte[5] { 0, 3, 0x3a, 0, 0x2d } ;
            this.Send(buffer2);
        }

        public Character(float x, float y, float z, float orient) : base(x, y, z, orient)
        {
            this.reputationAdjustments = new Hashtable();
            this.friends = new ArrayList();
            this.actionBar = new ArrayList();
            this.zones = new uint[0x20];
            this.linkedSpawner = -1;
            this.logged = false;
            this.activeQuests = new ActiveQuest[20];
            this.questsDone = new Hashtable();
            this.tradeItems = new int[7];
            this.TaxiField = new uint[8];
            this.previousSpellCasted = 0;
            this._gossipOpened = false;
            this.Duel = 0;
            this.lastAreaTrigger = DateTime.Now;
            this.deadEndTeleportLoop = false;
            this.team1 = new ArrayList();
            this.team2 = new ArrayList();
            this.testCombatStarted = false;
            this.startTrajetFlag = null;
            this.ff = 1;
            this.tooFar = new byte[4] { 0, 2, 0x45, 1 } ;
            this.hitBuffer = new byte[0x41] { 
                0, 0x3f, 0x4a, 1, 6, 0, 0, 0, 0x9b, 0x36, 0x21, 0, 0, 0, 0, 0, 
                0x91, 20, 0x21, 0, 0, 0, 0, 0, 10, 0, 0, 0, 1, 0, 0, 0, 
                0, 0, 0, 0x20, 0x41, 0, 0, 0, 0, 0, 0, 0, 0, 1, 0, 0, 
                0, 0xe8, 3, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0
             } ;
            this.last = DateTime.Now;
            this.group = new Group();
            this.pendingGroupRequest = new ArrayList();
        }

        public void AcceptQuest(ulong guid, int id)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            BaseQuest quest1 = null;
            ActiveQuest quest2 = new ActiveQuest(quest1 = World.CreateQuestById(id));
            int num1 = this.AddQuest(quest2);
            if (num1 != -1)
            {
                int num2 = (num1 * 3) + 0xbc;
                int[] numArray1 = new int[3] { num2, num2 + 1, num2 + 2 } ;
                object[] objArray1 = new object[3] { id, 0, 0 } ;
                this.SendSmallUpdate(numArray1, objArray1);
                quest1.OnAcceptQuest(this);
                (mobile1 as BaseCreature).OnAcceptQuest(this, id);
                if (quest1.HaveDeliveryObj)
                {
                    Item[] itemArray1 = base.Items;
                    for (int num3 = 0; num3 < itemArray1.Length; num3++)
                    {
                        Item item1 = itemArray1[num3];
                        if (item1 != null)
                        {
                            this.CheckDeliveries(item1);
                        }
                    }
                }
            }
        }

        public void AcceptTrade()
        {
            this.TradeState = 3;
            int num1 = 4;
            if (this.tradingWith != null)
            {
                if (this.tradingWith.TradeState == 3)
                {
                    int num2 = 0;
                    int num3 = 0;
                    for (int num4 = 0; num4 < 7; num4++)
                    {
                        if (this.tradeItems[num4] != -1)
                        {
                            num2++;
                        }
                        if (this.tradingWith.TradeItems[num4] != -1)
                        {
                            num3++;
                        }
                    }
                    if ((num3 > this.FreeSlot()) || (num2 > this.tradingWith.FreeSlot()))
                    {
                        Converter.ToBytes(this.tradeNum, this.tempBuff, ref num1);
                        this.tradingWith.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
                    }
                    else
                    {
                        for (int num5 = 0; num5 < 7; num5++)
                        {
                            if (this.tradeItems[num5] != -1)
                            {
                                this.tradingWith.PutObjectInBackpack(base.Items[this.tradeItems[num5]], true);
                                this.DestroyItem((Slots) this.tradeItems[num5], false);
                                this.tradeItems[num5] = -1;
                            }
                            if (this.tradingWith.tradeItems[num5] != -1)
                            {
                                this.PutObjectInBackpack(this.tradingWith.Items[this.tradingWith.tradeItems[num5]], true);
                                this.tradingWith.DestroyItem((Slots) this.tradingWith.tradeItems[num5], false);
                                this.tradingWith.tradeItems[num5] = -1;
                            }
                        }
                        this.Copper += ((uint) this.tradingWith.tradeGold);
                        this.Copper -= ((uint) this.tradeGold);
                        this.tradingWith.Copper += ((uint) this.tradeGold);
                        this.tradingWith.Copper -= ((uint) this.tradingWith.tradeGold);
                        num1 = 4;
                        Character character1 = this.tradingWith;
                        Converter.ToBytes(8, this.tempBuff, ref num1);
                        character1.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
                        this.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
                        this.ItemsUpdate();
                        this.tradingWith.ItemsUpdate();
                        this.tradeNum = 7;
                        this.tradingWith.TradeUpdate();
                        this.TradeUpdate();
                        this.tradingWith.ReleaseTrade();
                        this.ReleaseTrade();
                    }
                }
                else
                {
                    num1 = 4;
                    Converter.ToBytes(4, this.tempBuff, ref num1);
                    this.tradingWith.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
                }
            }
        }

        public void ActionBarAdd(int ab)
        {
            this.AddToActionBar(0, (ushort) ab, 0, 0);
        }
   
		//��������
		public void AddFriend(string fname)
		{
			int num1 = 4;
			Character character1 = null;
			FriendResults results1 = FriendResults.Friend_ADDED_ONLINE;
			//
			if (base.Name == fname)
			{
				Converter.ToBytes((byte) FriendResults.Friend_SELF, this.tempBuff, ref num1);
				Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
			}
			else
			{
				foreach (Character character2 in World.allConnectedChars)
				{
					if (character2.Name == fname)
					{
						results1 = FriendResults.Friend_ADDED_ONLINE;
						character1 = character2;
						break;
					}
				}
				if (character1 == null)//fix
				{
					IEnumerator enumerator1 = World.allAccounts.GetEnumerator();
					while (enumerator1.MoveNext())
					{
						Account account = (Account) enumerator1.Current;
						foreach (Character character3 in account.characteres)
						{
							if (character3.Name == fname)
							{
								character1 = character3;
								results1 = FriendResults.Friend_ADDED_OFFLINE;
								break;
							}
						}
					}
				}
				if (character1 != null) 
				{
					
					for (int num3=0; num3<friends.Count;num3++)
					{
						if (character1 == friends[num3])
						{
							Converter.ToBytes((byte)FriendResults.Friend_ALREADY,this.tempBuff,ref num1);
							Converter.ToBytes((ulong)character1.Guid,this.tempBuff,ref num1);
							this.Player.Handler.Send(OpCodes.SMSG_FRIEND_STATUS, this.tempBuff, num1);
							return;
						}
					}
					Converter.ToBytes((byte) results1, this.tempBuff, ref num1);
					Converter.ToBytes((ulong)character1.Guid, this.tempBuff, ref num1);
					Converter.ToBytes((int)character1.ZoneId, this.tempBuff, ref num1);
					Converter.ToBytes((int)character1.Level, this.tempBuff, ref num1);
					Converter.ToBytes((int) character1.Classe, this.tempBuff, ref num1);
					this.friends.Add(character1);
				}	
				else
				{
					Converter.ToBytes((byte) FriendResults.Friend_NOT_FOUND, this.tempBuff, ref num1);
					Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
				}
			}
			this.Send(OpCodes.SMSG_FRIEND_STATUS, this.tempBuff, num1);
		}

		//
		//ɾ������
		public void DelFriend(ulong friendguid)
		{
			byte findResult = (byte)FriendResults.Friend_REMOVED;
			int num1=4;
			Converter.ToBytes((byte)findResult,this.tempBuff,ref num1);
			Converter.ToBytes((ulong)friendguid,this.tempBuff,ref num1);
			Converter.ToBytes(0, this.tempBuff, ref num1);
			Converter.ToBytes(0, this.tempBuff, ref num1);
			Converter.ToBytes(0, this.tempBuff, ref num1);
			Character character1=Character.FindByGUID (friendguid);
			this.friends.Remove(character1);
			this.Player.Handler.Send(OpCodes.SMSG_FRIEND_STATUS, this.tempBuff, num1);
		}

		//
		public override PermanentAura AddPermanentAura(AuraEffect ae, Aura a)
		{
			PermanentAura aura1 = new PermanentAura(a, ae.Id);
			this.permanentAura.Add(aura1);
			this.AdjustBonii();
			return aura1;
		}
        public int AddQuest(ActiveQuest bq)
        {
            for (int num1 = 0; num1 < 20; num1++)
            {
                if (this.activeQuests[num1] == null)
                {
                    this.activeQuests[num1] = bq;
                    return num1;
                }
            }
            return -1;
        }

        public void AddToActionBar(byte place, ushort id, byte other, byte type)
        {
            Action action1 = null;
            foreach (Action action2 in this.actionBar)
            {
                if (action2.action == id)
                {
                    action1 = action2;
                    break;
                }
            }
            if (id == 0)
            {
                if (action1 != null)
                {
                    this.actionBar.Remove(action1);
                }
            }
            else if (action1 != null)
            {
                action1.Change(place, id, type, other);
            }
            else
            {
                this.actionBar.Add(new Action(place, id, type, other));
            }
        }

        public void AdjustBonii()
        {
			this.SendSkillUpdate();//fix add
            base.HitPoints += base.HealthBonus;
            base.Mana += base.ManaBonus;
            int[] numArray1 = new int[0x25] { 
                0x16, 0, 0x1c, 0, 0x83, 0x84, 0x9b, 0x9c, 0x9d, 0x9e, 0x9f, 160, 0xa1, 0xa2, 0xa3, 0xa4, 
                0xa5, 0xa6, 0xa7, 0xa9, 0x43b, 0x43c, 0x43d, 0x43e, 0x43f, 0x440, 0x441, 0x442, 0x443, 0x444, 0x445, 0x446, 
                0x447, 0x448, 0x449, 0x44a, 0x44b
             } ;
              object[] objArray1 = new object[0x2b] {
                base.HitPoints, base.Mana, base.BaseHitPoints, base.BaseMana, base.AttackSpeed, base.AttackSpeed, base.Str, base.Agility, base.Stamina, base.Iq, base.Spirit, base.Armor, base.ResistHoly, base.ResistFire, base.ResistNature, base.ResistFrost, 
                base.ResistShadow, base.ResistArcane, base.AttackPower, base.AttackPowerBonus, base.StrBonus, base.AgBonus, base.StaminaBonus, base.IQBonus, base.SpiritBonus, base.StrMalus, base.AgMalus, base.StaminaMalus, base.IQMalus, base.SpiritMalus, base.ArmorBonus, base.HolyResistanceBonus, 
                base.FireResistanceBonus, base.NatureResistanceBonus, base.FrostResistanceBonus, base.ShadowResistanceBonus, base.ArcaneResistanceBonus, base.HolyResistanceMalus, base.FireResistanceMalus, base.NatureResistanceMalus, base.FrostResistanceMalus, base.ShadowResistanceMalus, base.ArcaneResistanceMalus
             } ;
			numArray1[1] = 0x17 + base.ManaType;
			numArray1[3] = 0x1d + base.ManaType;
            this.SendSmallUpdate(numArray1, objArray1);
        }

        public void AreaTrigger(int areaId)
        {
            base.ZoneId = areaId;
            TimeSpan span1 = DateTime.Now.Subtract(this.lastAreaTrigger);
            if (span1.TotalSeconds > 6)
            {
                Character.onAreaTrigger(this, areaId);
            }
        }

        public override int AttackSwing(ulong target)
        {
            if (target <= 0xf100000000000000)
            {
                Mobile mobile1 = this.account.FindMobileByGuid(target);
                if (mobile1 == null)
                {
                    return 0;
                }
                int num1 = 4;
                base.AttackTarget = mobile1;
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                Converter.ToBytes(target, this.tempBuff, ref num1);
                this.account.ToAllPlayerNear(OpCodes.SMSG_ATTACKSTART, this.tempBuff, num1);
                this.activeWeapon = this.ChooseWeapon();
                this.SetDamage((double) this.activeWeapon.PhysicalMinDamage, (double) this.activeWeapon.PhysicalMaxDamage);
                if ((this.firstHitCombatTimer != null) || (this.combatTimer != null))
                {
                    return 0;
                }
                this.firstHitCombatTimer = new FirstHitCombatTimer(this);
            }
            return 0;
        }

        public void AutoEquip(Slots from)
        {
            if (base.AttackTarget != null)
            {
                this.StopAttacking();
            }
            Item item1 = base.Items[(int) from];
            if (item1 == null)
            {
                Console.WriteLine("Item in {0} missing", (int) from);
                return;
            }
            Slots slots1 = item1.CanBeEquipedIn;
            if (item1.IsContainer)
            {
                slots1 = Slots.None;
                for (int num1 = 0x13; num1 < 0x17; num1++)
                {
                    if (base.Items[num1] == null)
                    {
                        slots1 = (Slots) num1;
                        break;
                    }
                }
                if (slots1 != Slots.None)
                {
                    goto Label_009D;
                }
                this.InventoryFailed(0x11, item1.Guid);
                return;
            }
            if (((slots1 == Slots.OffHand) && item1.IsWeapon) && !this.HaveSpell(0x2a2))
            {
                this.InventoryFailed(7, item1.Guid);
                return;
            }
            if (!this.CanEquip(item1))
            {
                return;
            }
        Label_009D:
            if (slots1 != Slots.None)
            {
                this.SwapInv(from, slots1);
            }
        }

        public void Autostore(Slots from, byte s)
        {
            if (base.AttackTarget != null)
            {
                this.StopAttacking();
            }
            Slots slots1 = this.FindAFreeSlot(s);
            if (slots1 == Slots.None)
            {
                this.InventoryFailed(0x33, base.Items[(int) from].Guid);
            }
            else
            {
                this.SwapInv(from, slots1);
            }
        }

        public void AutostoreLootItem(byte from)
        {
            if (base.AttackTarget != null)
            {
                this.StopAttacking();
            }
            if (this.currentObjectLooted.Treasure.Length != 0)
            {
                Item item1 = this.currentObjectLooted.Treasure[from];
                //if ((item1 != null) && this.PutObjectInBackpack(item1, 1, true))
				if (item1 != null)
                {
                    this.tempBuff[4] = from;
                    this.account.ToAllPlayerNear(OpCodes.SMSG_LOOT_REMOVED, this.tempBuff, 5);
					this.PutObjectInBackpack(item1, 1, true);//fix
                    this.currentObjectLooted.Treasure[from] = null;
                    if (this.SeeAnyLoot(this, this.currentObjectLooted.Treasure))
                    {
                        int[] numArray1 = new int[2] { 0x2e, 0x94 } ;
                        object[] objArray1 = new object[2] { (int) this.Flags, this.DynFlags(this) } ;
                        this.SendSmallUpdate(numArray1, objArray1);
                    }
                }
            }
        }

        public void BeginTrade()
        {
            int num3;
            int num1 = 4;
            this.tradeState = num3 = 2;
            Converter.ToBytes(num3, this.tempBuff, ref num1);
            this.tradingWith.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
            this.tradingWith.TradeState = 2;
            this.tradeNum = 5;
            this.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
            for (int num2 = 0; num2 < 7; num2++)
            {
                this.tradeItems[num2] = -1;
            }
        }

        public void Buy(ulong guid, int num, Slots slot, byte n)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            if (mobile1 != null)
            {
                if (mobile1 is BaseCreature)
                {
                    (mobile1 as BaseCreature).SpeakingFrom = DateTime.Now;
                    (mobile1 as BaseCreature).AIState = AIStates.Speaking;
                }
                Item item1 = null;
                Item[] itemArray1 = mobile1.Sells;
                for (int num1 = 0; num1 < itemArray1.Length; num1++)
                {
                    Item item2 = itemArray1[num1];
                    if (item2.Id == num)
                    {
                        item1 = item2;
                        break;
                    }
                }
                if (item1 != null)
                {
                    if (((slot != Slots.None) && (slot < (Slots.Ranged | Slots.Wrists))) && (!this.CanEquip(item1) || (item1.CanBeEquipedIn != slot)))
                    {
                        this.InventoryFailed(3, item1.Guid);
                    }
                    else
                    {
                        item1 = item1.Clone();
                        if (item1.BuyPrice > this.Copper)
                        {
                            this.InventoryFailed(0x1c, item1.Guid);
                        }
                        else
                        {
                            this.Copper -= ((uint) item1.BuyPrice);
                            if ((slot != Slots.None) && (base.Items[(int) slot] != null))
                            {
                                this.PutObjectInBackpack(item1, item1.Stackable, Slots.None, true);
                            }
                            else
                            {
                                this.PutObjectInBackpack(item1, item1.Stackable, slot, true);
                            }
                        }
                    }
                }
            }
        }

        public void CancelAura(int id)
        {
            if (!base.ChannelEnd(id))
            {
                base.ReleaseAura((AuraEffect) Abilities.abilities[id]);
            }
        }

        public void CancelDuel(ulong g)
        {
            int num1 = 4;
            Converter.ToBytes(g, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_GAMEOBJECT_DESPAWN_ANIM, this.tempBuff, num1);
            this.gu.Send(OpCodes.SMSG_GAMEOBJECT_DESPAWN_ANIM, this.tempBuff, num1);
            this.Send(OpCodes.SMSG_DESTROY_OBJECT, this.tempBuff, num1);
            this.gu.Send(OpCodes.SMSG_DESTROY_OBJECT, this.tempBuff, num1);
            num1 = 4;
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_DUEL_COMPLETE, this.tempBuff, num1);
            this.gu.Send(OpCodes.SMSG_DUEL_COMPLETE, this.tempBuff, num1);
            this.guowner = null;
            this.gu.guowner = null;
            this.gu.gu = null;
            this.gu = null;
            this.dt = null;
        }

        public void CancelTrade()
        {
            if (this.tradingWith != null)
            {
                int num1 = 4;
                Converter.ToBytes(3, this.tempBuff, ref num1);
                this.tradingWith.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
                this.tradingWith = null;
            }
        }

        public bool CanEquip(Item i)
        {
            if (i.InventoryType == InventoryTypes.None)
            {
                this.InventoryFailed(3, i.ReqLevel, i.Guid);
                return false;
            }
            if (i.ReqLevel > base.Level)
            {
                this.InventoryFailed(1, i.ReqLevel, i.Guid);
                return false;
            }
            if (((base.Items[15] != null) && (base.Items[15].InventoryType == InventoryTypes.TwoHanded)) && ((i.InventoryType == InventoryTypes.Shield) || (i.InventoryType == InventoryTypes.OffHand)))
            {
                this.InventoryFailed(12, i.Guid);
                return false;
            }
            if (Item.skillIdAssoc[(i.ObjectClass * 100) + i.SubClass] != null)
            {
                if (this.HaveSkill((int) Item.skillIdAssoc[(i.ObjectClass * 100) + i.SubClass]))
                {
                    goto Label_0104;
                }
                this.InventoryFailed(7, i.Guid);
                return false;
            }
            Console.WriteLine("No skill associated to {0} {1} {2}", i.Name, i.ObjectClass, i.SubClass);
        Label_0104:
            if (((i.InventoryType == InventoryTypes.MainGauche) && (base.Items[15] != null)) && (base.Items[15].InventoryType == InventoryTypes.TwoHanded))
            {
                this.InventoryFailed(12, i.Guid);
                return false;
            }
            return true;
        }

        public bool CanEquip(Item i, Item f)
        {
            if ((i == null) || (f == null))
            {
                return false;
            }
            if (i.InventoryType == InventoryTypes.None)
            {
                this.InventoryFailed(3, i.ReqLevel, i.Guid, f.Guid);
                return false;
            }
            if (i.ReqLevel > base.Level)
            {
                this.InventoryFailed(1, i.ReqLevel, i.Guid, f.Guid);
                return false;
            }
            if (((base.Items[15] != null) && (base.Items[15].InventoryType == InventoryTypes.TwoHanded)) && ((i.InventoryType == InventoryTypes.Shield) || (i.InventoryType == InventoryTypes.OffHand)))
            {
                this.InventoryFailed(12, i.Guid, f.Guid);
                return false;
            }
            int num1 = (i.ObjectClass * 100) + i.SubClass;
            if (Item.skillIdAssoc[num1] != null)
            {
                if (this.HaveSkill((int) Item.skillIdAssoc[num1]))
                {
                    goto Label_0101;
                }
                this.InventoryFailed(7, i.Guid, f.Guid);
                return false;
            }
            Console.WriteLine("No skill associated to {0} ", i.Name);
        Label_0101:
            return true;
        }

        public override bool CanSee(Server.Object obj)
        {
            if (obj is GameObject)
            {
                return (obj as GameObject).SeenBy(this);
            }
            Mobile mobile1 = obj as Mobile;
            if (base.Dead || ((mobile1.NpcFlags & 1) <= 0))
            {
                if (mobile1 is Character)
                {
                    if (mobile1.Dead && (mobile1.Distance(this) < 900f))
                    {
                        return false;
                    }
                    if (!(mobile1 as Character).Player.Realylogged)
                    {
                        return false;
                    }
                }
                if ((mobile1 != this) && (mobile1.Visible != InvisibilityLevel.Visible))
                {
                    if (mobile1.Visible == InvisibilityLevel.GM)
                    {
                        return false;
                    }
                    if (((mobile1.Visible == InvisibilityLevel.Lesser) && !base.CanSeeLesserInvisibility) && (!base.CanSeeMediumInvisibility && !base.CanSeeMediumInvisibility))
                    {
                        return false;
                    }
                    if (((mobile1.Visible == InvisibilityLevel.Medium) && !base.CanSeeMediumInvisibility) && !base.CanSeeMediumInvisibility)
                    {
                        return false;
                    }
                    if ((mobile1.Visible == InvisibilityLevel.Greater) && !base.CanSeeMediumInvisibility)
                    {
                        return false;
                    }
                }
                if (mobile1.Distance(this) < 10000f)
                {
                    return true;
                }
            }
            return false;
        }

        public void ChangeBattleStance(StandStates st)
        {
            int num1 = ((int) base.StandState) & 0xffff;
            //num1 = (int) (((StandStates) num1) + st);
			 num1 = (int) (num1 + (int)st);	//fix
            base.StandState = (StandStates) num1;
            int[] numArray1 = new int[1] { 0x8f } ;
            object[] objArray1 = new object[1] { num1 } ;
            this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public override void ChangeRunSpeed(float newspeed)
        {
            base.ChangeRunSpeed(newspeed);
            this.UpdateRunSpeed();
        }

        public void ChangeStandState(int state)
        {
            base.StandState = (StandStates) state;
            int[] numArray1 = new int[1] { 0x8f } ;
            object[] objArray1 = new object[1] { state } ;
            this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public void CheckDeliveries(Item it)
        {
            for (int num1 = 0; num1 < 20; num1++)
            {
                if ((this.activeQuests[num1] != null) && this.activeQuests[num1].HaveDeliveryObj)
                {
                    int num2 = this.activeQuests[num1].IncreaseDelivery(it);
                    if (num2 > 0)
                    {
                        int num3 = (num1 * 3) + 0xbc;
                        int[] numArray1 = new int[1] { num3 + 1 } ;
                        object[] objArray1 = new object[1] { num2 } ;
                        this.SendSmallUpdate(numArray1, objArray1);
                        int num4 = 4;
                        Converter.ToBytes(it.Id, this.tempBuff, ref num4);
                        Converter.ToBytes(it.MaxCount, this.tempBuff, ref num4);
                        this.Send(OpCodes.SMSG_QUESTUPDATE_ADD_ITEM, this.tempBuff, num4);
                        return;
                    }
                }
            }
        }

        public void CheckKills(Mobile mob)
        {
            for (int num1 = 0; num1 < 20; num1++)
            {
                if ((this.activeQuests[num1] != null) && this.activeQuests[num1].HaveNPCObj)
                {
                    int num2 = this.activeQuests[num1].IncreaseNpcObj(mob);
                    if (num2 > 0)
                    {
                        int num3 = (num1 * 3) + 0xbc;
                        int[] numArray1 = new int[1] { num3 + 1 } ;
                        object[] objArray1 = new object[1] { num2 } ;
                        this.SendSmallUpdate(numArray1, objArray1);
                        int num4 = 4;
                        Converter.ToBytes(this.activeQuests[num1].Id, this.tempBuff, ref num4);
                        Converter.ToBytes(mob.Id, this.tempBuff, ref num4);
                        Converter.ToBytes(this.activeQuests[num1].NpcObjCurrentAmount(mob), this.tempBuff, ref num4);
                        Converter.ToBytes(this.activeQuests[num1].NpcObjAmount(mob), this.tempBuff, ref num4);
                        Converter.ToBytes(mob.Guid, this.tempBuff, ref num4);
                        this.Send(OpCodes.SMSG_QUESTUPDATE_ADD_KILL, this.tempBuff, num4);
                        return;
                    }
                }
            }
        }

        public void ChooseReward(ulong g, int id, int sel)
        {
            BaseQuest quest1 = World.CreateQuestById(id);
            if (quest1 != null)
            {
                int num2;
                if (quest1.RewardXp > 0)
                {
                    this.EarnXP(this.RealXp(quest1.RewardXp, quest1.IdealLevel));
                }
                if (quest1.RewardGold > 0)
                {
                    this.Copper += ((uint) quest1.RewardGold);
                }
                if ((quest1.RewardSpell > 0) && !this.HaveSpell(quest1.RewardSpell))
                {
                    this.LearnSpell(quest1.RewardSpell);
                }
                ArrayList list1 = new ArrayList();
                if (quest1.HasReward())
                {
                    Reward[] rewardArray1 = quest1.Reward.Items;
                    for (num2 = 0; num2 < rewardArray1.Length; num2++)
                    {
                        Reward reward1 = rewardArray1[num2];
                        Item item1 = reward1.CreateItem();
                        if (item1 != null)
                        {
                            this.PutObjectInBackpack(item1, reward1.Amount, true);
                            list1.Add(reward1);
                        }
                    }
                }
                if (quest1.HasRewardChoice())
                {
                    int num1 = quest1.ChoiceRewardAmount(sel);
                    if (num1 > 0)
                    {
                        Item item2 = quest1.ChoiceRewardCreate(sel);
                        if (item2 != null)
                        {
                            this.PutObjectInBackpack(item2, num1, true);
                            list1.Add(new Reward(item2.Id, num1));
                        }
                    }
                }
                this.SetQuestDone(quest1, (Reward[]) list1.ToArray(typeof(Reward)));
                if (quest1.HaveDeliveryObj)
                {
                    DeliveryObjective[] objectiveArray1 = quest1.DeliveryObjectives.Items;
                    for (num2 = 0; num2 < objectiveArray1.Length; num2++)
                    {
                        DeliveryObjective objective1 = objectiveArray1[num2];
                        this.ConsumeItemByIdUpTo(objective1.Id, objective1.Amount);
                    }
                }
                if (this._gossipOpened)
                {
                    this.EndGossip();
                }
            }
        }

        public override Item ChooseWeapon()
        {
            Item item1 = base.Items[15];
            if (item1 == null)
            {
                item1 = base.Items[0x10];
                if ((item1 != null) && (item1.PhysicalMinDamage != 0f))
                {
                    return Character.handToHand;
                }
                item1 = base.Items[0x11];
                if (item1 == null)
                {
                    return Character.handToHand;
                }
            }
            return item1;
        }

        public void ClearTradeItem(int num)
        {
            this.tradeItems[num] = -1;
            this.TradeUpdate();
        }

        public void ConsumeItemByIdUpTo(int id, int amount)
        {
            for (int num1 = 0; num1 < base.Items.Length; num1++)
            {
                Item item1 = base.Items[num1];
                if ((item1 != null) && (item1.Id == id))
                {
                    if (item1.MaxCount <= amount)
                    {
                        amount -= item1.MaxCount;
                        this.DestroyItem((Slots) num1, true);
                        if (amount == 0)
                        {
                            return;
                        }
                    }
                    else
                    {
                        item1.MaxCount -= amount;
                        int[] numArray1 = new int[1] { 14 } ;
                        object[] objArray1 = new object[1] { item1.MaxCount } ;
                        item1.SendTinyUpdate(numArray1, objArray1, this);
                        return;
                    }
                }
            }
        }

        public void ConsumeItemByIdUpTo(string cl, int amount)
        {
            ConstructorInfo info1 = Utility.FindConstructor(cl);
            Item item1 = (Item) info1.Invoke(null);
            this.ConsumeItemByIdUpTo(item1.Id, amount);
        }

        public void CopyAllParameters(Character from)
        {
            base.AllSkills.Clear();
            IDictionaryEnumerator enumerator1 = from.AllSkills.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                base.AllSkills.Add((ushort) enumerator1.Key, (Skill) enumerator1.Value);
            }
            base.KnownAbilities.Clear();
            enumerator1 = from.KnownAbilities.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                base.KnownAbilities.Add(enumerator1.Key, enumerator1.Value);
            }
            for (int num1 = 0; num1 < from.Items.Length; num1++)
            {
                if (from.Items[num1] != null)
                {
                    ConstructorInfo info1 = Utility.FindConstructor(from.Items[num1].GetType().Name);
                    Item item1 = (Item) info1.Invoke(null);
                    base.Items[num1] = item1;
                }
                else
                {
                    base.Items[num1] = null;
                }
            }
            base.Classe = from.Classe;
            base.ManaType = from.ManaType;
            base.BaseHitPoints = from.BaseHitPoints;
            base.HitPoints = from.HitPoints;
            base.Mana = from.Mana;
            base.BaseMana = from.BaseMana;
            base.BaseAgility = from.BaseAgility;
            base.BaseEnergy = from.BaseEnergy;
            base.BaseFocus = from.BaseFocus;
            base.BaseIq = from.BaseIq;
            base.BaseRage = from.BaseRage;
            base.BaseSpirit = from.BaseSpirit;
            base.BaseStamina = from.BaseStamina;
            base.BaseStr = from.BaseStr;
            base.Exp = from.Exp;
            base.Faction = from.Faction;
            base.Level = from.Level;
            base.Model = from.Model;
            base.Orientation = from.Orientation;
            base.RunSpeed = from.RunSpeed;
            base.WalkSpeed = from.WalkSpeed;
            base.Speed = from.Speed;
            this.gender = (byte) from.Gender;
            this.skin = (byte) from.Skin;
            this.face = (byte) from.Face;
            this.hairStyle = (byte) from.HairStyle;
            this.hairColour = (byte) from.HairColour;
            this.race = from.Race;
            this.facialHair = (byte) from.FacialHair;
        }

        public void CorpseQuery()
        {
            int num1 = 4;
            Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
            //Converter.ToBytes(this.CorpseMapId, this.tempBuff, ref num1);
			Converter.ToBytes((uint)this.CorpseMapId, this.tempBuff, ref num1);//fix
            Converter.ToBytes(this.CorpseLocationX, this.tempBuff, ref num1);
            Converter.ToBytes(this.CorpseLocationY, this.tempBuff, ref num1);
            Converter.ToBytes(this.CorpseLocationZ, this.tempBuff, ref num1);
            //Converter.ToBytes(this.CorpseMapId, this.tempBuff, ref num1);
			Converter.ToBytes((uint)this.CorpseMapId, this.tempBuff, ref num1);//fix
            this.Send(OpCodes.MSG_CORPSE_QUERY, this.tempBuff, num1);
            num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(this.CorpseLocationX, this.tempBuff, ref num1);
            Converter.ToBytes(this.CorpseLocationY, this.tempBuff, ref num1);
            this.Send(OpCodes.MSG_MINIMAP_PING, this.tempBuff, num1);
        }

        public void CreateAndAddObject(string item)
        {
            this.CreateAndAddObject(item, true);
        }

        /*public void CreateAndAddObject(string item, bool refresh)
        {
            this.CreateAndAddObject(item, 1, refresh);
        }*/
		public void CreateAndAddObject(string item, bool refresh)//fix 
		{
			Slots slots1 = this.FindAFreeSlot();
			if (slots1 == Slots.None)
			{
				this.InventoryFailed(0x30, 0);
			}
			else
			{
				ConstructorInfo info1 = Utility.FindConstructor(item, Utility.externAsm);
				Item item1 = null;
				if (info1 == null)
				{
					this.SendMessage("Unknow item " + item);
				}
				else
				{
					item1 = (Item) info1.Invoke(null);
					this.PutObjectInBackpack(item1, refresh);
				}
			}
		}
        public void CreateAndAddObject(string item, int n)
        {
            Slots slots1 = this.FindAFreeSlot();
            if (slots1 == Slots.None)
            {
                this.InventoryFailed(0x30, 0);
            }
            else
            {
                this.CreateAndAddObject(item, true);
                for (int num1 = 0; num1 < (n - 2); num1++)
                {
                    Slots slots2 = this.FindAFreeSlot();
                    if (slots2 == Slots.None)
                    {
                        this.InventoryFailed(0x30, 0);
                        return;
                    }
                    this.CreateAndAddObject(item, false);
                }
                slots1 = this.FindAFreeSlot();
                if (slots1 == Slots.None)
                {
                    this.InventoryFailed(0x30, 0);
                }
                else
                {
                    this.CreateAndAddObject(item, true);
                }
            }
        }

        public void CreateAndAddObject(string item, int n, bool refresh)//??
        {
            Slots slots1 = this.FindAFreeSlot();
            if (slots1 == Slots.None)
            {
                this.InventoryFailed(0x30, 0);
            }
            else
            {
                ConstructorInfo info1 = Utility.FindConstructor(item, Utility.externAsm);
                Item item1 = null;
                if (info1 == null)
                {
                    this.SendMessage("Unknow item " + item);
                }
                else
                {
                    item1 = (Item) info1.Invoke(null);
                    this.PutObjectInBackpack(item1, n, refresh);
                }
            }
        }

        public void CreatureQuery(ulong guid, int id)
        {
            Mobile mobile1 = null;
            if ((guid & 0xf100000000000000) == 0xf100000000000000)
            {
                this.SpawnerQuery(guid, id);
            }
            else
            {
                mobile1 = this.Player.FindMobileByGuid(guid);
            }
            if (mobile1 != null)
            {
                int num1 = 4;
                Converter.ToBytes(id, this.tempBuff, ref num1);
                Converter.ToBytes(mobile1.Name, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                if (mobile1.Name2 != null)
                {
                    Converter.ToBytes(mobile1.Name2, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                }
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                if (mobile1.Guild != null)
                {
                    Converter.ToBytes(mobile1.Guild, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                }
                Converter.ToBytes(mobile1.Flags1, this.tempBuff, ref num1);
                if ((mobile1.NpcType & 2) > 0)
                {
                    Converter.ToBytes(7, this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes(0, this.tempBuff, ref num1);
                }
                Converter.ToBytes(mobile1.NpcType, this.tempBuff, ref num1);
                Converter.ToBytes(mobile1.Unk4, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                this.Send(OpCodes.SMSG_CREATURE_QUERY_RESPONSE, this.tempBuff, num1);
            }
        }

        public override void Deserialize(GenericReader gr)
        {
            base.Deserialize(gr);
            int num1 = gr.ReadInt();
            if (num1 > 6)
            {
                int num2 = gr.ReadInt();
                for (int num3 = 0; num3 < num2; num3++)
                {
                    int num4 = gr.ReadInt();
                    int num5 = gr.ReadInt();
                    this.reputationAdjustments[num4] = num5;
                }
            }
            if (num1 > 5)
            {
                int num6 = gr.ReadInt();
                for (int num7 = 0; num7 < num6; num7++)
                {
                    this.actionBar.Add(new Action(gr));
                }
            }
            if (num1 > 4)
            {
                int num8 = gr.ReadInt();
                for (int num9 = 0; num9 < num8; num9++)
                {
                    ulong num10 = gr.ReadInt64();
                    this.friends.Add(num10);
                    string text1 = gr.ReadString();
                    this.friends.Add(text1);
                }
            }
            if (num1 > 2)
            {
                this.BindingPointX = gr.ReadFloat();
                this.BindingPointY = gr.ReadFloat();
                this.BindingPointZ = gr.ReadFloat();
                //this.BindingPointMapId = (ushort) gr.ReadInt();
				this.BindingPointMapId = (ushort) gr.ReadShort();//fix
            }
            if ((num1 > 1) && gr.ReadBool())
            {
                this.petActions = new int[11];
                for (int num11 = 0; num11 < 11; num11++)
                {
                    this.petActions[num11] = gr.ReadInt();
                }
            }
            int num12 = gr.ReadInt();
            if (num12 != 0)
            {
                ulong num13 = gr.ReadInt64();
                base.Summon = (Mobile) MobileList.TempSummon[num13];
                base.Summon.SummonedBy = this;
                (base.Summon as BaseCreature).AIEngine = new SummonedAI(this, base.Summon as BaseCreature);
            }
            num12 = gr.ReadInt();
            if (num12 != 0)
            {
                base.Charm = (Mobile) MobileList.TempSummon[gr.ReadInt64()];
                base.Charm.CharmedBy = this;
                (base.Charm as BaseCreature).AIEngine = new SummonedAI(this, base.Charm as BaseCreature);
            }
            this.CorpseLocationX = gr.ReadFloat();
            this.CorpseLocationY = gr.ReadFloat();
            this.CorpseLocationZ = gr.ReadFloat();
            if (num1 > 3)
            {
                this.CorpseMapId = (ushort) gr.ReadShort();
            }
            this.corpsGuid = gr.ReadInt64();
            this.zones = new uint[0x20];
            for (int num14 = 0; num14 < 0x20; num14++)
            {
                this.zones[num14] = (uint) gr.ReadInt();
            }
            int num15 = gr.ReadInt();
            if (num15 == 1)
            {
                this.mark = new Position(gr.ReadFloat(), gr.ReadFloat(), gr.ReadFloat(), gr.ReadInt());
            }
            this.ammoType = gr.ReadInt();
            this.race = (Races) gr.ReadByte();
            if (num1 == 0)
            {
                base.Classe = (Classes) gr.ReadByte();
            }
            this.gender = gr.ReadByte();
            this.skin = gr.ReadByte();
            this.face = gr.ReadByte();
            this.hairStyle = gr.ReadByte();
            this.hairColour = gr.ReadByte();
            this.facialHair = gr.ReadByte();
            this.copper = (uint) gr.ReadInt();
            int num16 = 20;
            for (int num17 = 0; num17 < num16; num17++)
            {
                int num18 = gr.ReadInt();
                if (num18 == 1)
                {
                    this.AddQuest(new ActiveQuest(gr));
                }
            }
            int num19 = gr.ReadInt();
            for (int num20 = 0; num20 < num19; num20++)
            {
                int num21 = gr.ReadInt();
                this.questsDone[num21] = true;
            }
            for (int num22 = 0; num22 < 8; num22++)
            {
                int num23 = gr.ReadInt();
                this.TaxiField[num22] = (uint) num23;
            }
        }

        public void DestroyItem(Slots it, bool deleteAfter)
        {
            if (base.AttackTarget != null)
            {
                this.StopAttacking();
            }
            if (deleteAfter)
            {
                this.DestroyObject(base.Items[(int) it].Guid);
            }
            if (it < ((Slots) 40))
            {
                int num1 = 4;
                Converter.ToBytes((short) 1, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                base.ResetBitmap();
                int num2 = 1;
                if (it < (Slots.OffHand | Slots.Wrists))
                {
                    //base.setUpdateValue(num2 = (int) (((Slots) 250) + (it * Slots.TrinketLeft)), 0);
					base.setUpdateValue(num2 = (int) (((Slots) 250) + ((int)it * (int)Slots.TrinketLeft)), 0);//fix
                }
                base.setUpdateValue(num2 = (int) (((Slots) 0x1dc) + ((int)Slots.Shoulders * (int)it)), (ulong) 0);//fix
                base.FlushUpdateData(this.tempBuff, ref num1, 2 + (num2 / 0x20));
                this.account.Handler.Send(0xa9, this.tempBuff, num1);
                if (it < Slots.Bag1)
                {
                    this.account.ToAllPlayerNearExceptMe(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
                }
            }
            else
            {
                int num3 = 0;
                Item item1 = this.RealSlot((int) it, ref num3);
                int num4 = 4;
                Converter.ToBytes((short) 1, this.tempBuff, ref num4);
                Converter.ToBytes(0, this.tempBuff, ref num4);
                Converter.ToBytes(item1.Guid, this.tempBuff, ref num4);
                base.ResetBitmap();
                base.setUpdateValue((int) (50 + (2 * num3)), (ulong) 0);
                base.FlushUpdateData(this.tempBuff, ref num4, 3);
                this.account.Handler.Send(0xa9, this.tempBuff, num4);
            }
            base.Items[(int) it] = null;
        }

        public void DestroyObject(ulong guid)
        {
            byte[] buffer1 = new byte[12] { 0, 10, 170, 0, 110, 0x36, 5, 0, 0, 0, 0, 0 } ;
            int num1 = 4;
            Converter.ToBytes(guid, buffer1, ref num1);
            this.Send(OpCodes.SMSG_DESTROY_OBJECT, buffer1, num1);
        }

        public void Deturn()
        {
            byte[] buffer1 = new byte[0x18];
            int num1 = 4;
            this.gu.gu = this;
            Server.Object.GUID++;
            Converter.ToBytes(Server.Object.GUID, buffer1, ref num1);
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            this.gu.Send(OpCodes.SMSG_DUEL_REQUESTED, buffer1, num1);
            this.Send(OpCodes.SMSG_DUEL_REQUESTED, buffer1, num1);
        }

        public void DismissPet(ulong guid)
        {
            if (base.Summon != null)
            {
                base.Summon.Delete();
                World.Remove(base.Summon, this);
                base.Summon = null;
                int num1 = 4;
                Converter.ToBytes(1, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                this.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, false);
                this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
                this.ItemsUpdate();
            }
        }

		public void EarnXP(int amount)
		{
			if (base.Level < 60)
			{
				int num1;
				base.Exp += ((uint) amount);
				if (base.Exp > Mobile.xpNeeded[base.Level])
				{
					while ((base.Level < 60) && (base.Exp > Mobile.xpNeeded[base.Level]))
					{
						base.Level++;
						num1 = 4;
						int num2 = 0;
						int num3 = 0;
						float single1 = 0f;
						float single2 = 0f;
						float single3 = 0f;
						float single4 = 0f;
						float single5 = 0f;
						if (Character.onLevelUp != null)
						{
							Character.onLevelUp(this, base.Level, ref num2, ref num3, ref single1, ref single2, ref single3, ref single4, ref single5);
						}
						base.BaseAgility += single2;
						base.BaseHitPoints += num2;
						base.HitPoints = base.BaseHitPoints - 1;
						base.BaseIq += single4;
						base.BaseSpirit += single5;
						base.BaseMana += num3;
						if (base.ManaType != 1)
						{
							base.Mana = base.BaseMana - 1;
						}
						base.BaseStr += single1;
						base.BaseStamina += single3;
						Converter.ToBytes(base.Level, this.tempBuff, ref num1);
						Converter.ToBytes(num2, this.tempBuff, ref num1);
						Converter.ToBytes(num3, this.tempBuff, ref num1);
						Converter.ToBytes(0, this.tempBuff, ref num1);
						Converter.ToBytes(0, this.tempBuff, ref num1);
						Converter.ToBytes(0, this.tempBuff, ref num1);
						Converter.ToBytes(0, this.tempBuff, ref num1);
						Converter.ToBytes((int) single1, this.tempBuff, ref num1);
						Converter.ToBytes((int) single2, this.tempBuff, ref num1);
						Converter.ToBytes((int) single3, this.tempBuff, ref num1);
						Converter.ToBytes((int) single4, this.tempBuff, ref num1);
						Converter.ToBytes((int) single5, this.tempBuff, ref num1);
						this.Send(OpCodes.SMSG_LEVELUP_INFO, this.tempBuff, num1);
						if (base.Level > 9)
						{
							base.Talent++;
						}
						num1 = 4;
						Converter.ToBytes(1, this.tempBuff, ref num1);
						Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
						this.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, false);
						this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
						this.ItemsUpdate();
					}
				}
				else
				{
					object[] objArray1;
					if ((base.Level > 1) && (base.Exp < Mobile.xpNeeded[base.Level - 1]))
					{
						while ((base.Level > 1) && (base.Exp < Mobile.xpNeeded[base.Level - 1]))
						{
							base.Level--;
							objArray1 = new object[3] { base.Level, base.Exp, Mobile.xpNeeded[base.Level] } ;
							this.SendSmallUpdate(new int[3] { 0x22, 0x26e, 0x26f } , objArray1);
						}
					}
					else
					{
						int[] numArray1;
						if (base.Level > 1)
						{
							uint num4 = base.Exp - ((uint) Mobile.xpNeeded[base.Level - 1]);
							uint num5 = (uint) (Mobile.xpNeeded[base.Level] - Mobile.xpNeeded[base.Level - 1]);
							numArray1 = new int[2] { 0x26e, 0x26f } ;
							objArray1 = new object[2] { num4, num5 } ;
							this.SendSmallUpdate(numArray1, objArray1);
						}
						else
						{
							numArray1 = new int[1] { 0x26e } ;
							objArray1 = new object[1] { base.Exp } ;
							this.SendSmallUpdate(numArray1, objArray1);
						}
					}
				}
				num1 = 4;
				Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
				Converter.ToBytes(amount, this.tempBuff, ref num1);
				Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
				Converter.ToBytes(50, this.tempBuff, ref num1);
				Converter.ToBytes((float) 1f, this.tempBuff, ref num1);
				this.Send(OpCodes.SMSG_LOG_XPGAIN, this.tempBuff, num1);
			}
		}

        public void EndGossip()
        {
            this._gossipOpened = false;
            this.Send(OpCodes.SMSG_GOSSIP_COMPLETE, this.tempBuff, 4);
        }

        public bool Equip(Item i, Slots s)
        {
            if (base.Items[(int) s] == null)
            {
                base.Items[(int) s] = i;
                return true;
            }
            return false;
        }

        public void ExportSpawner()
        {
            string text3;
            string[] textArray1;
            TextWriter writer1 = new StreamWriter("./exportspawners.csv");
            foreach (BaseSpawner spawner1 in World.allSpawners)
            {
                string text1 = "";
                if (spawner1.Id > 0)
                {
                    int num4 = 0x5f5e0ff - spawner1.Id;
                    text1 = text1 + num4.ToString() + ";";
                }
                else
                {
                    text1 = text1 + spawner1.Id.ToString() + ";";
                }
                text3 = text1;
                textArray1 = new string[0x1b] { 
                    text3, spawner1.MapId.ToString(), ";", spawner1.X.ToString(), ";", spawner1.Y.ToString(), ";", spawner1.Z.ToString(), ";", spawner1.Orientation.ToString(), ";", spawner1.ZoneId.ToString(), ";", spawner1.Model.ToString(), ";", spawner1.Amount.ToString(), 
                    ";", spawner1.Frequency.ToString(), ";", spawner1.RealX.ToString(), ";", spawner1.RealY.ToString(), ";", spawner1.RealZ.ToString(), ";", spawner1.TrajetGuid.ToString(), ";"
                 } ;
                text1 = string.Concat(textArray1);
                writer1.WriteLine(text1);
            }
            writer1.Close();
            foreach (Trajet trajet1 in World.trajets)
            {
                writer1 = new StreamWriter("./exports/path" + trajet1.Guid.ToString() + ".csv");
                int num1 = 0;
                foreach (Coord coord1 in trajet1)
                {
                    textArray1 = new string[8] { num1.ToString(), ";", coord1.x.ToString(), ";", coord1.y.ToString(), ";", coord1.z.ToString(), ";" } ;
                    string text2 = string.Concat(textArray1);
                    if (coord1 is Intersection)
                    {
                        int num2 = 0;
                        int num3 = 0;
                        coord1.previous.TrajetNum(ref num2, ref num3);
                        text3 = text2;
                        textArray1 = new string[5] { text3, World.trajets[num2].Guid.ToString(), ";", num3.ToString(), ";" } ;
                        text2 = string.Concat(textArray1);
                        coord1.next.TrajetNum(ref num2, ref num3);
                        text3 = text2;
                        textArray1 = new string[5] { text3, World.trajets[num2].Guid.ToString(), ";", num3.ToString(), ";" } ;
                        text2 = string.Concat(textArray1);
                    }
                    writer1.WriteLine(text2);
                }
                writer1.Close();
            }
        }

        //public void FaitFace(Mobile from)
		public override void FaitFace(Mobile from)//fix
        {
            base.Orientation = (float) Math.Atan2((double) (from.Y - this.Y), (double) (from.X - this.X));
        }

        public Slots FindAFreeSlot()
        {
            for (int num1 = 0x17; num1 < 0x27; num1++)
            {
                if (base.Items[num1] == null)
                {
                    return (Slots) num1;
                }
            }
            for (int num2 = 0x13; num2 < 0x18; num2++)
            {
                Item item1 = base.Items[num2];
                if (item1 != null)
                {
                    int num3 = 40 + ((num2 - 0x13) * 0x10);
                    for (int num4 = num3; num4 < (num3 + item1.ContainerSlots); num4++)
                    {
                        if (base.Items[num4] == null)
                        {
                            return (Slots) num4;
                        }
                    }
                }
            }
            return Slots.None;
        }

        public Slots FindAFreeSlot(byte s)
        {
            if (s == 0xff)
            {
                for (int num1 = 0x17; num1 < 0x27; num1++)
                {
                    if (base.Items[num1] == null)
                    {
                        return (Slots) num1;
                    }
                }
            }
            else
            {
                Item item1 = base.Items[s];
                if (item1 != null)
                {
                    int num2 = 40 + ((s - 0x13) * 0x10);
                    for (int num3 = num2; num3 < (num2 + item1.ContainerSlots); num3++)
                    {
                        if (base.Items[num3] == null)
                        {
                            return (Slots) num3;
                        }
                    }
                }
            }
            return Slots.None;
        }

        public int FindAmountOfItemById(int id)
        {
            int num1 = 0;
            Item[] itemArray1 = base.Items;
            for (int num2 = 0; num2 < itemArray1.Length; num2++)
            {
                Item item1 = itemArray1[num2];
                if ((item1 != null) && (item1.Id == id))
                {
                    num1 += item1.MaxCount;
                }
            }
            return num1;
        }

        public static Character FindByGUID(ulong g)
        {
            foreach (Character character1 in Character.allCharacters)
            {
                if (character1.Guid == g)
                {
                    return character1;
                }
            }
            return null;
        }

		#region 
		public Character FindByName(string g)
		{
			IEnumerator enumerator1 = World.allAccounts.GetEnumerator();
			while (enumerator1.MoveNext())
			{
				Account account = (Account) enumerator1.Current;
				try
				{
					foreach (Character character1 in account.characteres)
					{
						if (character1.Name  == g)
						{
							return character1;
						}
					}
					continue;
				}
				finally
				{
					IDisposable disposable1 = account as IDisposable;
					if (disposable1 != null)
					{
						disposable1.Dispose();
					}
				}
			}
			return null;
		}

		#endregion        
        public GameObject FindGameObjectByGuid(ulong guid)
        {
            foreach (Server.Object obj1 in this.account.KnownObjects)
            {
                if (!(obj1 is GameObject))
                {
                    continue;
                }
                GameObject obj2 = (GameObject) obj1;
                if (obj2.Guid == guid)
                {
                    return obj2;
                }
            }
            return null;
        }

        public Item FindItemByGuid(ulong guid)
        {
            Item[] itemArray1 = base.Items;
            for (int num1 = 0; num1 < itemArray1.Length; num1++)
            {
                Item item1 = itemArray1[num1];
                if ((item1 != null) && (item1.Guid == guid))
                {
                    return item1;
                }
            }
            return null;
        }

        public new Item FindItemById(int id)//fix
        {
            Item[] itemArray1 = base.Items;
            for (int num1 = 0; num1 < itemArray1.Length; num1++)
            {
                Item item1 = itemArray1[num1];
                if ((item1 != null) && (item1.Id == id))
                {
                    return item1;
                }
            }
            return null;
        }

        public Item FindItemById(int id, out Slots slot)
        {
            slot = Slots.None;
            int num1 = 0;
            Item[] itemArray1 = base.Items;
            for (int num2 = 0; num2 < itemArray1.Length; num2++)
            {
                Item item1 = itemArray1[num2];
                if ((item1 != null) && (item1.Id == id))
                {
                    slot = (Slots) num1;
                    return item1;
                }
                num1++;
            }
            return null;
        }

        public Item FindItemInGameObjectById(ulong guid, int id)
        {
            //if (((this.currentObjectLooted != null) && (this.currentObjectLooted.Treasure.Length != 0)) && (this.lootOwner == guid))
			if (this.currentObjectLooted.Treasure.Length != 0)
			{
				if (this.lootOwner != guid)
				{
					return null;
				}
				//fix
                Item[] itemArray1 = this.currentObjectLooted.Treasure;
                for (int num1 = 0; num1 < itemArray1.Length; num1++)
                {
                    Item item1 = itemArray1[num1];
                    if (item1.Id == id)
                    {
                        return item1;
                    }
                }
            }
            return null;
        }

        public override Server.Object FindObjectByGuid(ulong guid)
        {
            return this.account.FindObjectByGuid(guid);
        }

        public ActiveQuest FindPlayerQuest(BaseQuest bq)
        {
            ActiveQuest[] questArray1 = this.activeQuests;
            for (int num1 = 0; num1 < questArray1.Length; num1++)
            {
                ActiveQuest quest1 = questArray1[num1];
                if ((quest1 != null) && (quest1.Id == bq.Id))
                {
                    return quest1;
                }
            }
            return null;
        }

        public ActiveQuest FindPlayerQuest(int id)
        {
            ActiveQuest[] questArray1 = this.activeQuests;
            for (int num1 = 0; num1 < questArray1.Length; num1++)
            {
                ActiveQuest quest1 = questArray1[num1];
                if ((quest1 != null) && (quest1.Id == id))
                {
                    return quest1;
                }
            }
            return null;
        }

        public ActiveQuest FindPlayerQuest(Type type)
        {
            ActiveQuest[] questArray1 = this.activeQuests;
            for (int num1 = 0; num1 < questArray1.Length; num1++)
            {
                ActiveQuest quest1 = questArray1[num1];
                if ((quest1 != null) && (quest1.QuestType == type))
                {
                    return quest1;
                }
            }
            return null;
        }

        public int FindPosInTresorLoot(int from)
        {
            int num1 = 0;
            num1 = 0;
            while (num1 < this.currentObjectLooted.Treasure.Length)
            {
                Item item1 = this.currentObjectLooted.Treasure[num1];
                if (item1 != null)
                {
                    if (item1.IsQuestItem)
                    {
                        for (int num2 = 0; num2 < 20; num2++)
                        {
                            if (((this.activeQuests[num2] != null) && this.activeQuests[num2].HaveDeliveryObj) && this.activeQuests[num2].NeedItem(item1))
                            {
                                if (from == 0)
                                {
                                    return num1;
                                }
                                from--;
                                break;
                            }
                        }
                    }
                    else
                    {
                        if (from == 0)
                        {
                            return num1;
                        }
                        from--;
                    }
                }
                else
                {
                    if (from == 0)
                    {
                        return num1;
                    }
                    from--;
                }
                num1++;
            }
            return (num1 - 1);
        }

        public static string FirstParam(string str)
        {
            string[] textArray1 = str.Split(new char[10] { '\t', '(', ')', ' ', '\'', ':', '"', '-', '/', '\\' } );
            if (textArray1.Length >= 0)
            {
                if (textArray1[0].Length > 0)
                {
                    return textArray1[0];
                }
                if ((textArray1.Length >= 1) && (textArray1[1].Length > 0))
                {
                    return textArray1[1];
                }
                if ((textArray1.Length >= 2) && (textArray1[2].Length > 0))
                {
                    return textArray1[2];
                }
            }
            return "";
        }

        public void ForceSpeedAck()
        {
        }

        public static string FourthParam(string str)
        {
            string[] textArray1 = str.Split(new char[10] { '\t', '(', ')', ' ', '\'', ':', '"', '-', '/', '\\' } );
            if (textArray1.Length > 3)
            {
                return textArray1[3];
            }
            return "";
        }

        public int FreeSlot()
        {
            int num1 = 0;
            for (int num2 = 0x18; num2 < 40; num2++)
            {
                if (base.Items[num2] == null)
                {
                    num1++;
                }
            }
            for (int num3 = 0x13; num3 < 0x18; num3++)
            {
                Item item1 = base.Items[num3];
                if (item1 != null)
                {
                    int num4 = 40 + ((num3 - 0x13) * 0x10);
                    for (int num5 = num4; num5 < (num4 + item1.ContainerSlots); num5++)
                    {
                        if (base.Items[num5] == null)
                        {
                            num1++;
                        }
                    }
                }
            }
            return num1;
        }

        public void FullUpdate(ArrayList all)
        {
            int num1 = all.Count;
            Item[] itemArray1 = base.Items;
            int num5 = 0;
            while (num5 < itemArray1.Length)
            {
                Item item1 = itemArray1[num5];
                if (item1 != null)
                {
                    num1++;
                }
                num5++;
            }
            if (num1 == 0)
            {
                this.account.Handler.Send(new byte[15] { 0, 13, 0xf6, 1, 5, 0, 0, 0, 120, 0x5e, 0x63, 0x60, 0, 2, 0 } );
            }
            else
            {
                int num2 = 0;
                Converter.ToBytes(num1, this.tempBuff, ref num2);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num2);
                itemArray1 = base.Items;
                for (num5 = 0; num5 < itemArray1.Length; num5++)
                {
                    Item item2 = itemArray1[num5];
                    if (item2 != null)
                    {
                        item2.PrepareUpdateData(this.tempBuff, ref num2, UpdateType.UpdateFull, this);
                    }
                }
                foreach (Server.Object obj1 in all)
                {
                    if ((obj1 != this) && (obj1 is Character))
                    {
                        (obj1 as Character).PrepareUpdateDataForOther(this.tempBuff, ref num2, UpdateType.UpdateFull, this);
                        for (int num3 = 0; num3 < 0x18; num3++)
                        {
                            Item item3 = (obj1 as Character).Items[num3];
                            if (item3 != null)
                            {
                                num1++;
                                item3.PrepareUpdateData(this.tempBuff, ref num2, UpdateType.UpdateFull, obj1 as Character);
                            }
                        }
                        continue;
                    }
                    obj1.PrepareUpdateData(this.tempBuff, ref num2, UpdateType.UpdateFull, false, this);
                }
                int num4 = num1;
                num1 = 0;
                Converter.ToBytes(num4, this.tempBuff, ref num1);
                num1 = num4;
                byte[] buffer1 = Zip.Compress(this.tempBuff, 0, num2);
                byte[] buffer2 = new byte[buffer1.Length + 8];
                Buffer.BlockCopy(buffer1, 0, buffer2, 8, buffer1.Length);
                num1 = 4;
                Converter.ToBytes(num2, buffer2, ref num1);
                //this.account.Handler.Send(0x1f6, buffer2, (int) (buffer1.Length + 6));
				this.account.Handler.Send((int) OpCodes.SMSG_COMPRESSED_UPDATE_OBJECT, buffer2, (int) (buffer1.Length + 6));
            }
        }

        public void GameObjectQuery(int id, ulong guid)
        {
            int num1 = 4;
            GameObject obj1 = this.FindGameObjectByGuid(guid);
            if (obj1 != null)
            {
                Converter.ToBytes(obj1.Id, this.tempBuff, ref num1);
                Converter.ToBytes(obj1.ObjectType, this.tempBuff, ref num1);
                Converter.ToBytes(obj1.Model, this.tempBuff, ref num1);
                Converter.ToBytes(obj1.Name, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                for (int num2 = 0; num2 < obj1.Sound.Length; num2++)
                {
                    Converter.ToBytes(obj1.Sound[num2], this.tempBuff, ref num1);
                }
                for (int num3 = obj1.Sound.Length; num3 < 0x10; num3++)
                {
                    Converter.ToBytes(0, this.tempBuff, ref num1);
                }
                this.Send(OpCodes.SMSG_GAMEOBJECT_QUERY_RESPONSE, this.tempBuff, num1);
            }
        }

        public void GameObjectUse(ulong guid)
        {
            GameObject obj1 = this.FindGameObjectByGuid(guid);
            if ((obj1 != null) && !obj1.OnUse(this))
            {
            }
        }

        public static bool GetBit(byte[] ba, int t)
        {
            return ((ba[t / 8] & (1 << ((t % 8) & 0x1f))) != 0);
        }

        public static bool GetBit(BitArray ba, int t)
        {
            return ba.Get(t);
        }

        public void GossipHello(ulong guid)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            (mobile1 as BaseCreature).OnGossipHello(this);
        }

        public void GossipSelectOption(ulong guid, int num)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            (mobile1 as BaseCreature).DialogCharacterSelection(this, (mobile1 as BaseCreature).npcMenuId, num);
        }

        public void GroupAccept()
        {
            for (int num1 = 0; num1 < World.PendingGroup.Count; num1 += 2)
            {
                if (World.PendingGroup[num1] == this)
                {
                    Character character1 = (Character) World.PendingGroup[num1 + 1];
                    this.group = character1.GroupMembers;
                    this.group.Add(this);
                    World.PendingGroup.Remove(character1);
                    World.PendingGroup.Remove(this);
                }
            }
        }

        public void GroupDecline()
        {
            for (int num1 = 0; num1 < World.PendingGroup.Count; num1 += 2)
            {
                if (World.PendingGroup[num1] == this)
                {
                    int num2 = 4;
                    Converter.ToBytes(base.Name, this.tempBuff, ref num2);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num2);
                    (World.PendingGroup[num1 + 1] as Character).Send(OpCodes.SMSG_GROUP_DECLINE, this.tempBuff, num2);
                    World.PendingGroup.RemoveAt(num1);
                    World.PendingGroup.RemoveAt(num1);
                    return;
                }
            }
        }

        public void GroupInvite(string name)
        {
            foreach (Character character1 in this.account.PlayersNear)
            {
                if (character1.Name != name)
                {
                    continue;
                }
                int num1 = 4;
                Converter.ToBytes(base.Name, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                character1.Send(OpCodes.SMSG_GROUP_INVITE, this.tempBuff, num1);
                num1 = 4;
                Converter.ToBytes(1, this.tempBuff, ref num1);
                Converter.ToBytes(base.Name, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes(2, this.tempBuff, ref num1);
                Converter.ToBytes(3, this.tempBuff, ref num1);
                character1.Send(OpCodes.SMSG_PARTY_COMMAND_RESULT, this.tempBuff, num1);
                if ((this.group == null) || (this.group.Count == 0))
                {
                    this.group = new Group();
                    this.group.Add(this, 0x101);
                }
                World.PendingGroup.Add(character1);
                World.PendingGroup.Add(this);
                return;
            }
        }

        public void GroupSetLeader(string name)
        {
            foreach (Character character1 in this.account.PlayersNear)
            {
                if (character1.Name == name)
                {
                    this.group.PromoteLeader(character1);
                }
            }
        }

        public void GroupUninvite(string name)
        {
            foreach (Character character1 in this.account.PlayersNear)
            {
                if (character1.Name == name)
                {
                    character1.QuitGroup();
                }
            }
        }

        public bool HaveQuest(BaseQuest bq)
        {
            if (bq != null)
            {
                return this.HaveQuest(bq.Id);
            }
            return false;
        }

        public bool HaveQuest(int id)
        {
            bool flag1 = false;
            ActiveQuest[] questArray1 = this.activeQuests;
            for (int num1 = 0; num1 < questArray1.Length; num1++)
            {
                ActiveQuest quest1 = questArray1[num1];
                if ((quest1 != null) && (quest1.Id == id))
                {
                    flag1 = true;
                    break;
                }
            }
            return flag1;
        }

        public bool HaveQuest(Type t)
        {
            BaseQuest quest1 = World.CreateQuestByType(t);
            if (quest1 != null)
            {
                return this.HaveQuest(quest1);
            }
            return false;
        }

        public override bool HaveSkill(int id)
        {
            if (base.AllSkills[(ushort) id] == null)
            {
                return false;
            }
            return true;
        }

        public void HeartBeat()
        {
            //if (!this.account.TestIfLoggout())
			if (!this.account.TestIfLoggout() && !this.account.justLogged)
            {
                int[] numArray1;
                object[] objArray1;
                int num1 = base.Mana;
                int num2 = base.HitPoints;
                if (((Character.onHeartBeat != null) && Character.onHeartBeat(this)) && (!base.InCombat || (base.ManaType == 3)))
                {
                    if (base.Dead)
                    {
                        this.lastHeartBeat = DateTime.Now;
                        return;
                    }
					//new
                    if ((base.ManaType == 1) && (base.Mana > 0))
                    {
                        TimeSpan span1 = DateTime.Now.Subtract(this.lastHeartBeat);
                        base.Mana -= (((int) span1.TotalSeconds) * 10);
                        if (base.Mana < 0)
                        {
                            base.Mana = 0;
                        }
                    }
                    else if ((base.Mana < base.BaseMana) && (base.ManaType != 1))
                    {
                        TimeSpan span2 = DateTime.Now.Subtract(this.lastHeartBeat);
                        base.Mana += ((int) (((span2.TotalSeconds * base.BaseMana) * base.ManaRegenerationModifier) / 30));
                        if (base.Mana > base.BaseMana)
                        {
                            base.Mana = base.BaseMana;
                        }
                    }
                    if ((base.HitPoints < base.BaseHitPoints) && !base.InCombat)
                    {
                        TimeSpan span3 = DateTime.Now.Subtract(this.lastHeartBeat);
                        base.HitPoints += ((int) (((span3.TotalSeconds * base.BaseHitPoints) * base.HealthRegenerationModifier) / 40));
                        if (base.HitPoints > base.BaseHitPoints)
                        {
                            base.HitPoints = base.BaseHitPoints;
                        }
                    }
                }
                if ((num1 != base.Mana) && (num2 != base.HitPoints))
                {
                    numArray1 = new int[2] { 0x16, 0x17 + base.ManaType } ;
                    objArray1 = new object[2] { base.HitPoints, base.Mana } ;
                    this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                }
                else if (num1 != base.Mana)
                {
                    numArray1 = new int[1] { 0x17 + base.ManaType } ;
                    objArray1 = new object[1] { base.Mana } ;
                    this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                }
                else if (num2 != base.HitPoints)
                {
                    numArray1 = new int[1] { 0x16 } ;
                    objArray1 = new object[1] { base.HitPoints } ;
                    this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                }
                this.lastHeartBeat = DateTime.Now;
            }
        }

        public void ImportSpawner()
        {
            TextReader reader1 = new StreamReader("./exportspawners.csv");
            while (true)
            {
                string text1 = reader1.ReadLine();
                if (text1 == null)
                {
                    break;
                }
                char[] chArray1 = new char[1] { ';' } ;
                string[] textArray1 = text1.Split(chArray1);
                int num1 = Convert.ToInt32(textArray1[0]);
                if (num1 != 0)
                {
                    num1 = 0x98967f - num1;
                }
                ushort num2 = Convert.ToUInt16(textArray1[1]);
                float single1 = Convert.ToSingle(textArray1[2]);
                float single2 = Convert.ToSingle(textArray1[3]);
                float single3 = Convert.ToSingle(textArray1[4]);
                float single4 = Convert.ToSingle(textArray1[5]);
                Convert.ToInt32(textArray1[6]);
                int num3 = Convert.ToInt32(textArray1[7]);
                int num4 = Convert.ToInt32(textArray1[8]);
                int num5 = Convert.ToInt32(textArray1[9]);
                float single5 = Convert.ToSingle(textArray1[2]);
                float single6 = Convert.ToSingle(textArray1[3]);
                float single7 = Convert.ToSingle(textArray1[4]);
                ulong num6 = Convert.ToUInt64(textArray1[9]);
                BaseSpawner spawner1 = new BaseSpawner();
                spawner1.Id = num1;
                spawner1.X = single1;
                spawner1.Y = single2;
                spawner1.Z = single3;
                spawner1.MapId = num2;
                spawner1.Orientation = single4;
                spawner1.Amount = num4;
                spawner1.Frequency = num5;
                spawner1.Model = num3;
                spawner1.RealX = single5;
                spawner1.RealY = single6;
                spawner1.RealZ = single7;
                spawner1.TrajetGuid = num6;
                World.allSpawners.Add(spawner1);
            }
            reader1.Close();
        }

        public void ImportWad()
        {
            Console.WriteLine("Converting creature file...");
            int num1 = 0;
            int num2 = 0;
            int num3 = 0;
            int num4 = 0;
            int num5 = 0;
            int num6 = 0;
            Hashtable hashtable1 = new Hashtable();
            hashtable1["mapid"] = (ushort) 0;
            TextReader reader1 = new StreamReader("world.save");
            while (num3 < 100)
            {
                string text1 = reader1.ReadLine();
                num2++;
                if (text1 == null)
                {
                    break;
                }
                if (text1.Length != 0)
                {
                    if (text1.StartsWith("["))
                    {
                        num1 = 1;
                        if (hashtable1["type"] == null)
                        {
                            continue;
                        }
                        BaseSpawner spawner1 = new BaseSpawner();
                        if (((int) hashtable1["type"]) == 5)
                        {
                            if (GameObjectDescription.all[(int) hashtable1["entry"]] != null)
                            {
                                int num7 = (int) hashtable1["entry"];
                                hashtable1["entry"] = null;
                                if (GameObjectDescription.all[num7] == null)
                                {
                                    Console.WriteLine("Game object {0} unknown !", num7);
                                    continue;
                                }
                                spawner1.Init(-num7, 1, null);
                                World.Add(spawner1, (float) hashtable1["x"], (float) hashtable1["y"], (float) hashtable1["z"], (ushort) hashtable1["mapid"]);
                                spawner1.Orientation = (float) hashtable1["o"];
                                num5++;
                                hashtable1["mapid"] = (ushort) 0;
                                hashtable1["type"] = null;
                            }
                            else
                            {
                                Console.WriteLine("Unknown Game object {0}", (int) hashtable1["entry"]);
                            }
                            hashtable1["mapid"] = (ushort) 0;
                            continue;
                        }
                        if (hashtable1["spawngobjid"] != null)
                        {
                            int num8 = (int) hashtable1["spawngobjid"];
                            hashtable1["spawngobjid"] = null;
                            if (GameObjectDescription.all[num8] == null)
                            {
                                Console.WriteLine("Game object {0} unknown !", num8);
                                continue;
                            }
                            spawner1.Init(-num8, (int) hashtable1["spawntime"], null);
                            World.Add(spawner1, (float) hashtable1["x"], (float) hashtable1["y"], (float) hashtable1["z"], (ushort) hashtable1["mapid"]);
                            spawner1.Orientation = (float) hashtable1["o"];
                            num5++;
                            hashtable1["mapid"] = (ushort) 0;
                            continue;
                        }
                        if (hashtable1["spawnid"] == null)
                        {
                            continue;
                        }
                        ConstructorInfo info1 = World.MobilePool((int) hashtable1["spawnid"]);
                        if (info1 == null)
                        {
                            Console.WriteLine("creature id {0} unknown", (int) hashtable1["spawnid"]);
                            continue;
                        }
                        BaseCreature creature1 = (BaseCreature) info1.Invoke(null);
                        spawner1.Model = creature1.Model;
                        spawner1.Id = 0x5f5e0ff - creature1.Id;
                        if (((int) hashtable1["spawntime"]) <= 0)
                        {
                            Console.WriteLine("Invalid spawntime {0}", (int) hashtable1["spawntime"]);
                        }
                        else
                        {
                            spawner1.Init(info1, creature1.Id, (int) hashtable1["spawntime"], (int) hashtable1["spawnnumber"]);
                            World.Add(spawner1, (float) hashtable1["x"], (float) hashtable1["y"], (float) hashtable1["z"], (ushort) hashtable1["mapid"]);
                            spawner1.Orientation = (float) hashtable1["o"];
							//fix add
							for (int num7 = 0; num7 < spawner1.Amount; num7++)
							{
								spawner1.ForceRespawn();
							}
							//
                            hashtable1["spawngobjid"] = null;
                        }
                        hashtable1 = new Hashtable();
                        hashtable1["mapid"] = (ushort) 0;
                        num4++;
                        continue;
                    }
                    if ((num1 == 1) && !text1.StartsWith("//"))
                    {
                        char[] chArray1 = new char[1] { '=' } ;
                        string[] textArray1 = text1.Split(chArray1);
                        if (textArray1.Length != 2)
                        {
                            Console.WriteLine("{0} : {1}", "Syntaxe Error, line " + num2.ToString(), text1);
                            continue;
                        }
                        string text2 = textArray1[0].ToLower();
                        string text3 = textArray1[1];
                        if (text3.EndsWith(" "))
                        {
                            text3 = text3.Substring(0, text3.Length - 1);
                        }
                        try
                        {
                            string text4;
                            string text5;
                            switch (text2)
                            {
                                case "model":
                                {
                                    hashtable1["model"] = Convert.ToInt32(text3);
                                    continue;
                                }
                                case "type":
                                {
                                    hashtable1["type"] = Convert.ToInt32(text3);
                                    continue;
                                }
                                case "entry":
                                {
                                    hashtable1["entry"] = Convert.ToInt32(text3);
                                    continue;
                                }
                                case "gflag":
                                {
                                    hashtable1["gflag"] = Convert.ToInt32(text3);
                                    continue;
                                }
                                case "map":
                                {
                                    hashtable1["mapid"] = (ushort) Convert.ToInt32(text3);
                                    continue;
                                }
                                case "spawntime":
                                {
                                    goto Label_069C;
                                }
                                case "spawn":
                                {
                                    text4 = Character.SecondParam(text3);
                                    text5 = Character.FirstParam(text3);
                                    hashtable1["spawnid"] = Convert.ToInt32(text5);
                                    hashtable1["spawnnumber"] = Convert.ToInt32(text4);
                                    continue;
                                }
                                case "spawn_gobj":
                                {
                                    text4 = Character.SecondParam(text3);
                                    text5 = Character.FirstParam(text3);
                                    hashtable1["spawngobjid"] = Convert.ToInt32(text5);
                                    hashtable1["spawnnumber"] = 1;
                                    continue;
                                }
                                case "xyz":
                                {
                                    chArray1 = new char[1] { ' ' } ;
                                    string[] textArray2 = text3.Split(chArray1);
                                    hashtable1["x"] = (float) Convert.ToDouble(textArray2[0]);
                                    hashtable1["y"] = (float) Convert.ToDouble(textArray2[1]);
                                    hashtable1["z"] = (float) Convert.ToDouble(textArray2[2]);
                                    hashtable1["o"] = (float) Convert.ToDouble(textArray2[3]);
                                    continue;
                                }
                                default:
                                {
                                    continue;
                                }
                            }
                        Label_069C:
                            text4 = Character.SecondParam(text3);
                            text5 = Character.FirstParam(text3);
                            int num9 = Convert.ToInt32(text4);
                            if (num9 <= 10)
                            {
                                num9 = 20;
                            }
                            hashtable1["spawntime"] = num9;
                            continue;
                        }
                        catch (Exception exception1)
                        {
                            Console.WriteLine("Exception {0}", exception1.Message);
                            Console.WriteLine("Line {0}", num2);
                            continue;
                        }
                    }
                }
            }
            this.SendMessage(num4.ToString() + " spawn point created");
            this.SendMessage(num6.ToString() + " game objects created");
            this.SendMessage(num5.ToString() + " game objects spawn point created");
            this.SendMessage("I'm now importing the spawn points... this could take several minutes...");
            World.AdjustSpawners();
            this.SendMessage("Spawn points imported");
        }

        public void InitiateTrade(ulong guid)
        {
            Character character1 = this.account.FindPlayerNearByGuid(guid);
            if (character1 != null)
            {
                int num3;
                this.tradingWith = character1;
                character1.tradingWith = this;
                int num1 = 4;
                this.tradeNum = 1;
                this.tradeState = num3 = 1;
                Converter.ToBytes(num3, this.tempBuff, ref num1);
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                character1.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
                for (int num2 = 0; num2 < 7; num2++)
                {
                    this.tradeItems[num2] = -1;
                }
            }
        }

        public GameObject InsideFishingZone()
        {
            foreach (Server.Object obj1 in this.account.KnownObjects)
            {
                if (!(obj1 is GameObject))
                {
                    continue;
                }
                GameObject obj2 = (GameObject) obj1;
                if ((obj2.Sound[0] == 1) && (base.Distance(obj1) < 20f))
                {
                    return obj2;
                }
            }
            return null;
        }

        public void InventoryFailed(int from)
        {
            int num1 = 4;
            Converter.ToBytes((byte) from, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_INVENTORY_CHANGE_FAILURE, this.tempBuff, num1);
        }

        public void InventoryFailed(int from, int g)
        {
            int num1 = 4;
            Converter.ToBytes((byte) from, this.tempBuff, ref num1);
            Converter.ToBytes(g, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_INVENTORY_CHANGE_FAILURE, this.tempBuff, num1);
        }

        public void InventoryFailed(int from, ulong g)
        {
            int num1 = 4;
            Converter.ToBytes((byte) from, this.tempBuff, ref num1);
            Converter.ToBytes(g, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_INVENTORY_CHANGE_FAILURE, this.tempBuff, num1);
        }

        public void InventoryFailed(int from, int g, ulong f)
        {
            int num1 = 4;
            Converter.ToBytes((byte) from, this.tempBuff, ref num1);
            Converter.ToBytes(g, this.tempBuff, ref num1);
            Converter.ToBytes(f, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_INVENTORY_CHANGE_FAILURE, this.tempBuff, num1);
        }

        public void InventoryFailed(int from, ulong g, ulong f)
        {
            int num1 = 4;
            Converter.ToBytes((byte) from, this.tempBuff, ref num1);
            Converter.ToBytes(g, this.tempBuff, ref num1);
            Converter.ToBytes(f, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_INVENTORY_CHANGE_FAILURE, this.tempBuff, num1);
        }

        public void InventoryFailed(int from, int l, ulong g, ulong a)
        {
            int num1 = 4;
            Converter.ToBytes((byte) from, this.tempBuff, ref num1);
            Converter.ToBytes(l, this.tempBuff, ref num1);
            Converter.ToBytes(g, this.tempBuff, ref num1);
            Converter.ToBytes(a, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_INVENTORY_CHANGE_FAILURE, this.tempBuff, num1);
        }

        public void ItemsUpdate()
        {
            this.itemManaBonus = 0;
            this.itemHealthBonus = 0;
            int num1 = 0;
            Item[] itemArray1 = base.Items;
            int num17 = 0;
            while (num17 < itemArray1.Length)
            {
                Item item1 = itemArray1[num17];
                if (item1 != null)
                {
                    num1++;
                }
                num17++;
            }
            int num2 = 4;
            Converter.ToBytes((short) 1, this.tempBuff, ref num2);
            Converter.ToBytes(0, this.tempBuff, ref num2);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num2);
            base.ResetBitmap();
            int num3 = 0;
            int num4 = base.Armor;
            int num5 = base.ResistFire;
            int num6 = base.ResistNature;
            int num7 = base.ResistFrost;
            int num8 = base.ResistShadow;
            int num9 = base.ResistArcane;
            int num10 = base.ResistHoly;
            int num11 = 0;
            int num12 = 0;
            int num13 = 0;
            int num14 = 0;
            int num15 = 0;
            base.ReleaseAllItemAura();
            base.ArmorFromItems = 0;
            num3 = 0;
            while (num3 < 0x13)
            {
                Item item2 = base.Items[num3];
                if (item2 != null)
                {
                    item2.SetSpecialEffect(this);
                    if (item2.Block > 0)
                    {
                        base.Block += item2.Block;
                    }
                    if (item2.Resistance[0] > 0)
                    {
                        base.ArmorFromItems += item2.Resistance[0];
                    }
                    if (item2.Resistance[2] > 0)
                    {
                        base.ResistFire += item2.Resistance[2];
                    }
                    if (item2.Resistance[3] > 0)
                    {
                        base.ResistNature += item2.Resistance[3];
                    }
                    if (item2.Resistance[4] > 0)
                    {
                        base.ResistFrost += item2.Resistance[4];
                    }
                    if (item2.Resistance[5] > 0)
                    {
                        base.ResistShadow += item2.Resistance[5];
                    }
                    if (item2.Resistance[6] > 0)
                    {
                        base.ResistArcane += item2.Resistance[6];
                    }
                    if (item2.Resistance[1] > 0)
                    {
                        base.ResistHoly += item2.Resistance[1];
                    }
                    if (item2.StrBonus != 0)
                    {
                        num11 += item2.StrBonus;
                    }
                    if (item2.StaminaBonus != 0)
                    {
                        num13 += item2.StaminaBonus;
                    }
                    if (item2.IqBonus != 0)
                    {
                        num12 += item2.IqBonus;
                    }
                    if (item2.SpiritBonus != 0)
                    {
                        num15 += item2.SpiritBonus;
                    }
                    if (item2.AgilityBonus != 0)
                    {
                        num14 += item2.AgilityBonus;
                    }
                    if (item2.ManaBonus != 0)
                    {
                        this.itemManaBonus += item2.ManaBonus;
                    }
                    if (item2.HealthBonus != 0)
                    {
                        this.itemHealthBonus += item2.HealthBonus;
                    }
                }
                num3++;
            }
            if (this.itemHealthBonus != 0)
            {
                base.setUpdateValue(0x1c, base.BaseHitPoints);
            }
            if (this.itemManaBonus != 0)
            {
                base.setUpdateValue((int) (0x1d + base.ManaType), base.BaseMana);
            }
            base.setUpdateValue(0x9a, base.Talent);
            base.setUpdateValue(0x9b, (int) (base.Str + num11));
            base.setUpdateValue(0x9c, (int) (base.Agility + num14));
            base.setUpdateValue(0x9d, (int) (base.Stamina + num13));
            base.setUpdateValue(0x9e, (int) (base.Iq + num12));
            base.setUpdateValue(0x9f, (int) (base.Spirit + num15));
            if (num4 != base.Armor)
            {
                base.setUpdateValue(160, base.Armor);
            }
            if (num10 != base.ResistHoly)
            {
                base.setUpdateValue(0xa1, base.ResistHoly);
            }
            if (num5 != base.ResistFire)
            {
                base.setUpdateValue(0xa2, base.ResistFire);
            }
            if (num6 != base.ResistNature)
            {
                base.setUpdateValue(0xa3, base.ResistNature);
            }
            if (num7 != base.ResistFrost)
            {
                base.setUpdateValue(0xa4, base.ResistFrost);
            }
            if (num8 != base.ResistShadow)
            {
                base.setUpdateValue(0xa5, base.ResistShadow);
            }
            if (num9 != base.ResistArcane)
            {
                base.setUpdateValue(0xa6, base.ResistArcane);
            }
            num3 = 0;
            while (num3 < 0x13)
            {
                Item item3 = base.Items[num3];
                if (item3 != null)
                {
                    base.setUpdateValue((int) (250 + (num3 * 12)), item3.Id);
                }
                else
                {
                    base.setUpdateValue((int) (250 + (num3 * 12)), 0);
                }
                num3++;
            }
            num3 = 0;
            int num16 = 0;
            itemArray1 = base.Items;
            for (num17 = 0; num17 < itemArray1.Length; num17++)
            {
                Item item4 = itemArray1[num17];
                if (item4 != null)
                {
                    base.setUpdateValue(num16 = 0x1dc + (2 * num3), item4.Guid);
                }
                num3++;
                if (num3 >= 40)
                {
                    break;
                }
            }
            base.setUpdateValue(num16 = 0x43a, this.copper);
            base.setUpdateValue(num16 = 0x43b, num11);
            base.setUpdateValue(num16 = 0x43c, num14);
            base.setUpdateValue(num16 = 0x43d, num13);
            base.setUpdateValue(num16 = 0x43e, num12);
            base.setUpdateValue(num16 = 0x43f, num15);
            base.setUpdateValue(num16 = 0x440, num11);
            base.setUpdateValue(num16 = 0x441, num14);
            base.setUpdateValue(num16 = 0x442, num13);
            base.setUpdateValue(num16 = 0x443, num12);
            base.setUpdateValue(num16 = 0x444, num15);
            base.FlushUpdateData(this.tempBuff, ref num2, 1 + (num16 / 0x20));
            this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num2);
        }

        public void ItemsUpdate(int[] slots)
        {
            bool flag1 = false;
            int[] numArray1 = slots;
            for (int num4 = 0; num4 < numArray1.Length; num4++)
            {
                int num1 = numArray1[num4];
                if (num1 > 0x27)
                {
                    int num2 = 0;
                    Item item1 = this.RealSlot(num1, ref num2);
                    int num3 = 4;
                    Converter.ToBytes((short) 1, this.tempBuff, ref num3);
                    Converter.ToBytes(0, this.tempBuff, ref num3);
                    Converter.ToBytes(item1.Guid, this.tempBuff, ref num3);
                    base.ResetBitmap();
                    if (base.Items[num1] == null)
                    {
                        base.setUpdateValue((int) (50 + (2 * num2)), (ulong) 0);
                    }
                    else
                    {
                        base.setUpdateValue((int) (50 + (2 * num2)), base.Items[num1].Guid);
                    }
                    base.FlushUpdateData(this.tempBuff, ref num3, 3);
                    this.account.Handler.Send(0xa9, this.tempBuff, num3);
                }
                else
                {
                    flag1 = true;
                }
            }
            if (flag1)
            {
                this.ItemsUpdate();
            }
        }

        public void ItemsUpdate(byte[] data, ref int offset)
        {
            Converter.ToBytes((byte) 0, data, ref offset);
            Converter.ToBytes(base.Guid, this.tempBuff, ref offset);
            base.ResetBitmap();
            int num1 = 0;
            int num2 = 1;
            num1 = 0;
            while (num1 < 0x18)
            {
                Item item1 = base.Items[num1];
                if (item1 != null)
                {
                    base.setUpdateValue((int) (250 + (num1 * 12)), item1.Id);
                }
                else
                {
                    base.setUpdateValue((int) (250 + (num1 * 12)), 0);
                }
                num1++;
            }
            num1 = 0;
            Item[] itemArray1 = base.Items;
            for (int num3 = 0; num3 < itemArray1.Length; num3++)
            {
                Item item2 = itemArray1[num3];
                if ((item2 != null) && (num1 < 40))
                {
                    base.setUpdateValue(num2 = 0x1dc + (2 * num1), item2.Guid);
                }
                num1++;
            }
            base.setUpdateValue(num2 = 0x43a, this.copper);
            base.FlushUpdateData(this.tempBuff, ref offset, 1 + (num2 / 0x20));
        }

        public void ItemsUpdateForOther(Account acc)
        {
            this.ItemsUpdateForOther(acc.Handler);
        }

        public void ItemsUpdateForOther(PlayerHandler ph)
        {
            int num1 = 0;
            Item[] itemArray1 = base.Items;
            for (int num6 = 0; num6 < itemArray1.Length; num6++)
            {
                Item item1 = itemArray1[num6];
                if (item1 != null)
                {
                    num1++;
                }
            }
            int num2 = 4;
            Converter.ToBytes((short) 1, this.tempBuff, ref num2);
            Converter.ToBytes(0, this.tempBuff, ref num2);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num2);
            base.ResetBitmap();
            int num3 = 0;
            int num4 = 1;
            num3 = 0;
            while (num3 < 0x13)
            {
                Item item2 = base.Items[num3];
                if (item2 != null)
                {
                    base.setUpdateValue((int) (250 + (num3 * 12)), item2.Id);
                }
                else
                {
                    base.setUpdateValue((int) (250 + (num3 * 12)), 0);
                }
                num3++;
            }
            num3 = 0;
            for (int num5 = 0; num5 < 0x13; num5++)
            {
                Item item3 = base.Items[num5];
                if (item3 != null)
                {
                    base.setUpdateValue(num4 = 0x1dc + (2 * num3), item3.Guid);
                }
                num3++;
            }
            base.FlushUpdateData(this.tempBuff, ref num2, 1 + (num4 / 0x20));
            ph.Send(0xa9, this.tempBuff, num2);
        }

        public void ItemsUpdateForOther(byte[] data, ref int offset)
        {
            Converter.ToBytes((byte) 0, data, ref offset);
            Converter.ToBytes(base.Guid, this.tempBuff, ref offset);
            base.ResetBitmap();
            int num1 = 0;
            int num2 = 1;
            num1 = 0;
            while (num1 < 0x13)
            {
                Item item1 = base.Items[num1];
                if (item1 != null)
                {
                    base.setUpdateValue((int) (250 + (num1 * 12)), item1.Id);
                }
                else
                {
                    base.setUpdateValue((int) (250 + (num1 * 12)), 0);
                }
                num1++;
            }
            num1 = 0;
            for (int num3 = 0; num3 < 0x13; num3++)
            {
                Item item2 = base.Items[num3];
                if (item2 != null)
                {
                    base.setUpdateValue(num2 = 0x1dc + (2 * num1), item2.Guid);
                }
                num1++;
            }
            base.FlushUpdateData(this.tempBuff, ref offset, 1 + (num2 / 0x20));
        }

        public override void ItemTargetCastSpell(ulong targetGuid, int spell, ushort type)
        {
            BaseAbility ability1;
            this.StopAttacking();
            Item item1 = this.FindItemByGuid(targetGuid);
            if (item1 == null)
            {
                return;
            }
            if (!this.HaveSpell(spell))
            {
                return;
            }
            try
            {
                ability1 = Abilities.abilities[spell];
            }
            catch
            {
                if (spell == 0)
                {
                    Console.WriteLine("SpellError 0001: Not id given by CMSG_SPELL_CAST");
                    return;
                }
                Console.WriteLine("SpellError 0002: Not able to create BaseAbilityID:" + spell);
                return;
            }
            if (ability1 is SpellTemplate)
            {
                SpellTemplate template1;
                try
                {
                    template1 = (SpellTemplate) ability1;
                }
                catch
                {
                    Console.WriteLine("SpellError 0003: Not able to cast BaseAbility to SpellTemplateID:" + spell);
                    return;
                }
                try
                {
                    this.cast.castingtime = template1.CastingTime(this);
                    this.cast.cool = template1.CoolDown(this);
                    this.cast.id = template1.Id;
                    this.cast.manacost = template1.GetManaCost(this);
                    this.cast.type = type;
                    this.cast.baseability = template1;
                    goto Label_0170;
                }
                catch
                {
                    Console.WriteLine("SpellError 0004: Error in Mobile.cast assigment for SpellTemplateID:" + spell);
                    return;
                }
            }
            try
            {
                this.cast.castingtime = ability1.CastingTime(this);
                this.cast.cool = ability1.CoolDown(this);
                this.cast.id = ability1.Id;
                this.cast.manacost = 0;
                this.cast.type = type;
                this.cast.baseability = ability1;
            }
            catch
            {
                Console.WriteLine("SpellError 0005: Error in Mobile.cast assigment for BaseAbilityID:" + spell);
                return;
            }
        Label_0170:
            base.SetTarget(type, spell, item1);
        }

        public void JoinChannel(byte[] from, int off)
        {
            string text1 = "";
            for (int num1 = off; from[num1] != 0; num1++)
            {
                text1 = text1 + "" + ((char) from[num1]);
            }
            byte[] buffer1 = new byte[11 + text1.Length];
            int num2 = 4;
            Converter.ToBytes((byte) 2, buffer1, ref num2);
            Converter.ToBytes(text1, buffer1, ref num2);
            Converter.ToBytes((byte) 0, buffer1, ref num2);
            Converter.ToBytes(1, buffer1, ref num2);
            this.Player.Handler.Send(OpCodes.SMSG_CHANNEL_NOTIFY, buffer1);
        }

        public void JustLittleUpdate(int pos, uint val, byte[] data, ref int offset)
        {
            data[offset++] = 0;
            Converter.ToBytes(base.Guid, data, ref offset);
            data[offset++] = 0x1c;
            pos -= 8;
            int num1 = pos >> 3;
            int num2 = pos % 8;
            num2 = 1 << (num2 & 0x1f);
            Buffer.BlockCopy(Server.Object.Blank, 0, data, offset, Server.Object.Blank.Length);
            offset += num1;
            data[offset++] = (byte) num2;
            offset += (0x6f - num1);
            Converter.ToBytes(val, data, ref offset);
        }

        public void Kick()
        {
            int num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes("bye", this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_GOSSIP_MESSAGE, this.tempBuff, num1);
        }

        public override void LearnSpell(int id)
        {
            int num1 = 4;
            Converter.ToBytes(id, this.tempBuff, ref num1);
            this.account.Handler.Send(OpCodes.SMSG_LEARNED_SPELL, this.tempBuff, num1);
            base.LearnSpell(id);
        }

        public override void LearnTalent(int num, int lev)
        {
            if (base.Talent > 0)
            {
                if (TalentDescription.all[num] != null)
                {
                    base.LearnTalent(num, lev);
                    TalentDescription description1 = (TalentDescription) TalentDescription.all[num];
                    if (lev > 0)
                    {
                        this.UnLearnSpell(description1.AuraFXId(lev - 1));
                    }
                    base.Talent--;
                    this.LearnSpell(description1.AuraFXId(lev));
                    int[] numArray1 = new int[1] { 0x3f0 } ;
                    object[] objArray1 = new object[1] { base.Talent } ;
                    this.SendSmallUpdate(numArray1, objArray1);
                }
                else
                {
                    Console.WriteLine("{0} learn {1} at level {2}", base.Name, num, lev);
                }
            }
        }

        public void Loggout()
        {
            this.account = null;
        }

        public void Login(Account acc)
        {
            this.account = acc;
            this.guowner = null;
            this.gu = null;
            base.ZoneId = World.mapZones.NearestZoneId(this);
        }

        public void LootCreature(ulong guid)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            if (mobile1 != null)
            {
                new ArrayList();
                int num1 = 4;
                this.lootOwner = base.Guid;
                if (mobile1.Treasure.Length > 0)
                {
                    this.LootOwner = guid;
                    this.currentObjectLooted = mobile1;
                    int num2 = this.currentObjectLooted.Treasure.Length;
                    Converter.ToBytes(guid, this.tempBuff, ref num1);
                    int num3 = 0;
                    if ((num2 == 0) && (mobile1.LootMoney <= 0))
                    {
                        Converter.ToBytes(2, this.tempBuff, ref num1);
                        Converter.ToBytes((short) 0, this.tempBuff, ref num1);
                        this.Send(OpCodes.SMSG_LOOT_RESPONSE, this.tempBuff, num1);
                    }
                    else
                    {
                        if (mobile1.LootMoney > 0)
                        {
                            Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                            Converter.ToBytes(mobile1.LootMoney, this.tempBuff, ref num1);
                        }
                        else
                        {
                            Converter.ToBytes((byte) 2, this.tempBuff, ref num1);
                            Converter.ToBytes(0, this.tempBuff, ref num1);
                        }
                        Converter.ToBytes((byte) num2, this.tempBuff, ref num1);
                        Item[] itemArray1 = this.currentObjectLooted.Treasure;
                        for (int num5 = 0; num5 < itemArray1.Length; num5++)
                        {
                            Item item1 = itemArray1[num5];
                            if (item1 != null)
                            {
                                if (item1.IsQuestItem)
                                {
                                    bool flag1 = false;
                                    for (int num4 = 0; num4 < 20; num4++)
                                    {
                                        if (((this.activeQuests[num4] != null) && this.activeQuests[num4].HaveDeliveryObj) && this.activeQuests[num4].NeedItem(item1))
                                        {
                                            flag1 = true;
                                            break;
                                        }
                                    }
                                    if (flag1)
                                    {
                                        Converter.ToBytes((byte) num3++, this.tempBuff, ref num1);
                                        Converter.ToBytes(item1.Id, this.tempBuff, ref num1);
                                        Converter.ToBytes(item1.MaxCount, this.tempBuff, ref num1);
                                        Converter.ToBytes(item1.Model, this.tempBuff, ref num1);
                                        Converter.ToBytes(0, this.tempBuff, ref num1);
                                        Converter.ToBytes(0, this.tempBuff, ref num1);
                                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                                    }
                                    else
                                    {
                                        num3++;
                                    }
                                }
                                else
                                {
                                    Converter.ToBytes((byte) num3++, this.tempBuff, ref num1);
                                    Converter.ToBytes(item1.Id, this.tempBuff, ref num1);
                                    Converter.ToBytes(item1.MaxCount, this.tempBuff, ref num1);
                                    Converter.ToBytes(item1.Model, this.tempBuff, ref num1);
                                    Converter.ToBytes(0, this.tempBuff, ref num1);
                                    Converter.ToBytes(0, this.tempBuff, ref num1);
                                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                                }
                            }
                            else
                            {
                                Converter.ToBytes((byte) num3++, this.tempBuff, ref num1);
                                Converter.ToBytes(0, this.tempBuff, ref num1);
                                Converter.ToBytes(0, this.tempBuff, ref num1);
                                Converter.ToBytes(0, this.tempBuff, ref num1);
                                Converter.ToBytes(0, this.tempBuff, ref num1);
                                Converter.ToBytes(0, this.tempBuff, ref num1);
                                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                            }
                        }
                        this.Send(OpCodes.SMSG_LOOT_RESPONSE, this.tempBuff, num1);
                    }
                }
                else
                {
                    Converter.ToBytes(guid, this.tempBuff, ref num1);
                    Converter.ToBytes(2, this.tempBuff, ref num1);
                    Converter.ToBytes((short) 0, this.tempBuff, ref num1);
                    this.Send(OpCodes.SMSG_LOOT_RESPONSE, this.tempBuff, num1);
                }
            }
        }

        public void MakeThePacket(ulong g, Character with, Character from)
        {
            byte[] buffer1 = new byte[0x1e4] { 
                3, 0, 0, 0, 0, 2, 0x1f, 0x68, 0x29, 0, 0, 0x10, 0, 0xf0, 5, 0, 
                0, 0, 0, 0, 0, 0, 0, 0x3e, 0x54, 11, 0xc6, 4, 0x71, 0xde, 0xc2, 0x1d, 
                0x3d, 0xa5, 0x42, 0xbc, 0x69, 0x99, 0x3f, 0, 0, 0, 0, 0x66, 0xd1, 8, 0, 0x68, 
                9, 0x43, 0x35, 0, 0x10, 0, 0xf0, 0x1c, 100, 0x5e, 0x62, 0x38, 0xc3, 20, 8, 1, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x9c, 100, 0x5e, 0x62, 0x7c, 
                0xa1, 20, 8, 1, 0, 0, 0, 1, 0x5f, 0x71, 0xef, 0, 0x1f, 0x68, 0x29, 0, 
                0, 0x10, 0, 0xf0, 0x21, 0, 0, 0, 0xb0, 0x54, 0, 0, 0, 0, 0x80, 0x3f, 
                0x65, 0x77, 0xe4, 0, 0x13, 3, 0, 0, 0xe5, 100, 0x10, 0x3f, 0x35, 100, 0x53, 0x3f, 
                1, 0, 0, 0, 0x3e, 0x54, 11, 0xc6, 4, 0x71, 0xde, 0xc2, 0x1d, 0x3d, 0xa5, 0x42, 
                0xbc, 0x69, 0x99, 0x3f, 1, 0, 0, 0, 0x10, 0, 0, 0, 4, 0, 0, 0, 
                0, 0x65, 0x77, 0xe4, 0, 0, 0, 0, 0, 0x24, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x1f, 0x68, 0x29, 0, 0, 0x10, 
                0, 0xf0, 0, 0x36, 0xb7, 0xe3, 0, 0, 0, 0, 0, 0x24, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 12, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 
                0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x1f, 0x68, 0x29, 0, 
                0, 0x10, 0, 0xf0
             } ;
            int num1 = 6;
            Converter.ToBytes(g, buffer1, ref num1);
            num1 = 0x5c;
            Converter.ToBytes(g, buffer1, ref num1);
            num1 = 0x70;
            Converter.ToBytes((uint) (from.Guid & 0xffffffff), buffer1, ref num1);
            num1 = 0xa1;
            Converter.ToBytes(with.Guid, buffer1, ref num1);
            num1 = 0x13a;
            Converter.ToBytes(g, buffer1, ref num1);
            num1++;
            Converter.ToBytes(base.Guid, buffer1, ref num1);
            num1 = buffer1.Length - 8;
            Converter.ToBytes(g, buffer1, ref num1);
            num1 = 0x17;
            Converter.ToBytes((float) (this.X + 1f), buffer1, ref num1);
            Converter.ToBytes((float) (this.Y + 1f), buffer1, ref num1);
            Converter.ToBytes(this.Z, buffer1, ref num1);
            byte[] buffer2 = Zip.Compress(buffer1, 0, buffer1.Length);
            byte[] buffer3 = new byte[buffer2.Length + 8];
            int num2 = 4;
            Buffer.BlockCopy(buffer2, 0, buffer3, 8, buffer2.Length);
            Converter.ToBytes(buffer1.Length, buffer3, ref num2);
            this.account.Handler.Send(0x1f6, buffer3, (int) (buffer2.Length + 6));
        }

        public void MeetingStoneInfo()
        {
            int num1 = 4;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_MEETING_STONE_INFO, this.tempBuff, num1);
        }

        public void MessageHandler(string txt, ChatMsgType chat, int langue)
        {
            if (txt.StartsWith("."))
            {
                this.OnCommand(txt);
            }
            else
            {
                switch (chat)
                {
                    case ChatMsgType.CHAT_MSG_SAY:
                    {
                        this.SendMessageTo(this, chat, txt, langue);
                        if (this.account.PlayersNear.Count != 0)
                        {
                            foreach (Character character1 in this.account.PlayersNear)
                            {
                                if (character1.Player.PlayersNear.Contains(this))
                                {
                                    this.SendMessageTo(character1, txt, langue);
                                }
                            }
                        }
                        return;
                    }
                    case ChatMsgType.CHAT_MSG_PARTY:
                    {
                        break;
                    }
                    default:
                    {
                        return;
                    }
                }
                foreach (Member member1 in this.GroupMembers.Members)
                {
                    this.SendMessageTo(member1.Char, chat, txt, langue);
                }
            }
        }
        public override void Mount(Mobile m)
        {
            AuraEffect effect1;
            if (m == base.Summon)
            {
                base.Summon.Visible = InvisibilityLevel.True;
                this.DestroyObject(base.Summon.Guid);
                this.Player.KnownObjects.Remove(base.Summon);
                base.MountModel = base.Summon.Model;
            }
            else
            {
                base.MountModel = m.Model;
            }
            int num1 = 4;
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, false);
            this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
            this.ItemsUpdate();
            Aura aura1 = new Aura();
            aura1.OnRelease = new Aura.AuraReleaseDelegate(this.OnUnMount);
            this.mountedIdAuraEffect = effect1 = (AuraEffect) World.MountsList[m.Id];
            base.AddAura(effect1, aura1);
        }

        public void MoveHandler(float x, float y, float z, float orientation)
        {
            if ((this.gu != null) && (this.dt != null))
            {
                this.CancelDuel(this.Duel);
            }
            base.SetPosition(x, y, z, orientation);
        }

        public void NpcTextQuery(int id, ulong guid)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            string text1 = "";
            if ((mobile1.NpcFlags & 1) != 0)
            {
                text1 = "Return me to life";
            }
            else
            {
                text1 = (mobile1 as BaseCreature).QueryNpcText(id);
            }
            int num1 = 4;
            Converter.ToBytes(id, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(text1, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_NPC_TEXT_UPDATE, this.tempBuff, num1);
        }

        public void OfferReward(Mobile m, int questId, string title, string text)
        {
            this.OfferReward(m, questId, title, text, null);
        }

        public void OfferReward(Mobile m, int questId, string title, string text, qEmote[] emoteList)
        {
            BaseQuest quest1 = World.CreateQuestById(questId);
            int num1 = 4;
            Converter.ToBytes(m.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(questId, this.tempBuff, ref num1);
            Converter.ToBytes(title, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(text, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(1, this.tempBuff, ref num1);
            if (emoteList != null)
            {
                Converter.ToBytes(emoteList.Length, this.tempBuff, ref num1);
                for (int num2 = 0; num2 < emoteList.Length; num2++)
                {
                    qEmote emote1 = emoteList[num2];
                    Converter.ToBytes(emote1.Delay, this.tempBuff, ref num1);
                    Converter.ToBytes((int) emote1.emote, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            if (quest1.HasRewardChoice())
            {
                Reward[] rewardArray1 = quest1.RewardChoice.Items;
                Converter.ToBytes(rewardArray1.Length, this.tempBuff, ref num1);
                for (int num3 = 0; num3 < rewardArray1.Length; num3++)
                {
                    Reward reward1 = rewardArray1[num3];
                    Converter.ToBytes(reward1.Id, this.tempBuff, ref num1);
                    Converter.ToBytes(reward1.Amount, this.tempBuff, ref num1);
                    Converter.ToBytes(reward1.Model, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            if (quest1.HasReward())
            {
                Reward[] rewardArray2 = quest1.Reward.Items;
                Converter.ToBytes(rewardArray2.Length, this.tempBuff, ref num1);
                for (int num4 = 0; num4 < rewardArray2.Length; num4++)
                {
                    Reward reward2 = rewardArray2[num4];
                    Converter.ToBytes(reward2.Id, this.tempBuff, ref num1);
                    Converter.ToBytes(reward2.Amount, this.tempBuff, ref num1);
                    Converter.ToBytes(reward2.Model, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            Converter.ToBytes(quest1.RewardGold, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(quest1.RewardSpell, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_QUESTGIVER_OFFER_REWARD, this.tempBuff, num1);
        }

        public static void OnCastInvisibility(BaseAbility ba, Mobile c, Mobile m)
        {
        }

        public override bool OnCastSpellCMSG(byte[] data, int after, ushort type)
        {
            if ((this.firstHitCombatTimer != null) || (this.combatTimer != null))
            {
                this.StopAttacking();
            }
            return base.OnCastSpellCMSG(data, after, type);
        }

        public void OnCombatTick(Server.Character.CombatTimer from)
        {
            this.combatTimer.Delay = this.activeWeapon.Delay;
            if ((base.AttackTarget == null) || (from.target != base.AttackTarget.Guid))
            {
                this.StopAttacking();
                from.Stop();
            }
            else
            {
                DateTime.Now.Subtract(this.last);
                if (base.AttackTarget == null)
                {
                    this.StopAttacking();
                }
                else
                {
                    if (base.AttackTarget.Dead)
                    {
                        this.StopAttacking();
                        base.AttackTarget = null;
                    }
                    if (base.AttackTarget is BaseCreature)
                    {
                        base.AttackTarget.UpdateXYZ();
                    }
                    if (Mobile.GetDirection(this, base.AttackTarget) != Mobile.Pos.Front)
                    {
                        this.account.ToAllPlayerNear(OpCodes.SMSG_ATTACKSWING_BADFACING, this.tempBuff, 4);
                    }
                    else
                    {
                        float single1 = base.Distance(base.AttackTarget);
                        this.lastDistance = single1;
                        if (single1 < (8f * (base.AttackTarget.CombatReach + base.CombatReach)))
                        {
                            if (base.AttackTarget != null)
                            {
                                ArrayList list1 = new ArrayList();
                                foreach (NextAttackEffect effect1 in base.NextAttackEffects)
                                {
                                    bool flag1 = false;
                                    base.OnSpellTemplateResults(effect1.spell, base.AttackTarget);
                                    this.NextAttackSpellGo(effect1);
                                    this.SpellSuccess();
                                    if (effect1.onEffect is NextAttackEffectDelegate)
                                    {
                                        NextAttackEffectDelegate delegate1 = (NextAttackEffectDelegate) effect1.onEffect;
                                        flag1 = delegate1(effect1.spell, this, base.AttackTarget, effect1.number);
                                    }
                                    if (effect1.onEffect is NextAttackEffectDelegateMultiple)
                                    {
                                        ArrayList list2 = new ArrayList();
                                        NextAttackEffectDelegateMultiple multiple1 = (NextAttackEffectDelegateMultiple) effect1.onEffect;
                                        flag1 = multiple1(effect1.spell, this, base.AttackTarget, list2, effect1.number);
                                    }
                                    if (flag1)
                                    {
                                        list1.Add(effect1);
                                        continue;
                                    }
                                    effect1.number++;
                                }
                                foreach (NextAttackEffect effect2 in list1)
                                {
                                    base.NextAttackEffects.Remove(effect2);
                                }
                                list1.Clear();
                            }
                            this.FaitFace(base.AttackTarget);
                            int num1 = 0;
                            int num2 = 0;
                            int num3 = this.Hit(base.AttackTarget, ref num1, ref num2);
                            int num4 = 4;
                            if (num3 <= 0)
                            {
                                Converter.ToBytes(1, this.tempBuff, ref num4);
                            }
                            else if (((base.Items[0x10] == null) || base.Items[0x10].IsShield) || (Utility.Random(2) == 0))
                            {
                                Converter.ToBytes(0xe2, this.tempBuff, ref num4);
                            }
                            else
                            {
                                Converter.ToBytes(0x2e2, this.tempBuff, ref num4);
                            }
                            Converter.ToBytes(base.Guid, this.tempBuff, ref num4);
                            Converter.ToBytes(base.AttackTarget.Guid, this.tempBuff, ref num4);
                            if (num3 < 0)
                            {
                                Converter.ToBytes(0, this.tempBuff, ref num4);
                            }
                            else
                            {
                                Converter.ToBytes(num3, this.tempBuff, ref num4);
                            }
                            Converter.ToBytes((byte) 1, this.tempBuff, ref num4);
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                            if (num3 > 0)
                            {
                                Converter.ToBytes((float) num3, this.tempBuff, ref num4);
                            }
                            else
                            {
                                Converter.ToBytes(0, this.tempBuff, ref num4);
                            }
                            if (num3 < 0)
                            {
                                Converter.ToBytes(0, this.tempBuff, ref num4);
                            }
                            else
                            {
                                Converter.ToBytes(num3, this.tempBuff, ref num4);
                            }
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                            if (num3 >= 0)
                            {
                                Converter.ToBytes(1, this.tempBuff, ref num4);
                            }
                            else if (num3 == -1)
                            {
                                Converter.ToBytes(2, this.tempBuff, ref num4);
                            }
                            else if (num3 == -2)
                            {
                                Converter.ToBytes(9, this.tempBuff, ref num4);
                            }
                            else if (num3 == -3)
                            {
                                Converter.ToBytes(4, this.tempBuff, ref num4);
                            }
                            else if ((num3 == -4) || (num1 > 0))
                            {
                                Converter.ToBytes(5, this.tempBuff, ref num4);
                            }
                            else if (num3 == -5)
                            {
                                Converter.ToBytes(6, this.tempBuff, ref num4);
                            }
                            else if (num3 == -6)
                            {
                                Converter.ToBytes(7, this.tempBuff, ref num4);
                            }
                            else if (num3 == -7)
                            {
                                Converter.ToBytes(8, this.tempBuff, ref num4);
                            }
                            if (num3 == 0)
                            {
                                Converter.ToBytes(uint.MaxValue, this.tempBuff, ref num4);
                            }
                            else
                            {
                                Converter.ToBytes(0, this.tempBuff, ref num4);
                            }
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                            Converter.ToBytes(0, this.tempBuff, ref num4);
                            this.ToAllPlayerNear(OpCodes.SMSG_ATTACKERSTATEUPDATE, this.tempBuff, num4);
                            base.AttackTarget.LooseHits(this, num3, true);
                        }
                        else
                        {
                            this.account.ToAllPlayerNear(OpCodes.SMSG_ATTACKSWING_NOTINRANGE, this.tooFar, 4);
                        }
                        if (base.AttackTarget.Dead)
                        {
                            int num5 = 4;
                            Converter.ToBytes(base.Guid, this.tempBuff, ref num5);
                            Converter.ToBytes(base.AttackTarget.Guid, this.tempBuff, ref num5);
                            this.account.ToAllPlayerNear(OpCodes.SMSG_ATTACKSTOP, this.tempBuff, num5);
                            this.StopAttacking();
                            base.AttackTarget = null;
                        }
                    }
                }
            }
        }

        public void OnCommand(string cmd)
        {
            BaseSpawner spawner1;
            string[] textArray20;
            char[] chArray1;
            int[] numArray1;
            object[] objArray1;
            if (this.Player.AccessLevel == AccessLevels.PlayerLevel)
            {
                string text1 = cmd.ToLower();
                if (text1.StartsWith(".help"))
                {
                    this.SendMessage("Command lists");
                    this.SendMessage(".whois");
                    this.SendMessage(".mount");
                    this.SendMessage(".unmount");
                    return;
                }
                if (text1.StartsWith(".whois"))
                {
                    foreach (Account account1 in World.allConnectedAccounts)
                    {
                        if (account1.SelectedChar != null)
                        {
                            textArray20 = new string[8] { account1.SelectedChar.Name, " is online at ( ", account1.SelectedChar.X.ToString(), "; ", account1.SelectedChar.Y.ToString(), "; ", account1.SelectedChar.Z.ToString(), ") " } ;
                            this.SendMessage(string.Concat(textArray20));
                        }
                    }
                    this.SendMessage("User online : " + World.allConnectedAccounts.Count.ToString());
                    return;
                }
                if (text1.StartsWith(".mount"))
                {
                    if (((this.selection != null) && (this.selection is Mobile)) && (World.MountsList[(this.selection as Mobile).Id] != null))
                    {
                        this.Mount(this.selection as Mobile);
                    }
                    return;
                }
                if (text1.StartsWith(".unmount") && (base.MountModel != 0))
                {
                    this.UnMount();
                }
                return;
            }
            if (this.Player.AccessLevel != AccessLevels.Admin)
            {
                return;
            }
            string text2 = cmd.ToLower();
            if (text2.StartsWith(".importspawner"))
            {
                this.ImportSpawner();
                return;
            }
            if (text2.StartsWith(".exportspawner"))
            {
                this.ExportSpawner();
                return;
            }
            if (text2.StartsWith(".import"))
            {
                this.ImportWad();
                return;
            }
            if (text2.StartsWith(".help"))
            {
                this.SendMessage("==�����б�==");
                this.SendMessage(".help ����");
                this.SendMessage(".Addnpc [MobName|MobId] [amount] [faction] ��NPC");
                this.SendMessage(".AddItem ItemName [amount] ������Ʒ");
                this.SendMessage(".Addgo GameObjectNumber ����GameObject");
                this.SendMessage(".AddSpawner [MobName|MobId] amount frequency ����ˢ�ֵ�");
                this.SendMessage(".AddGoSpawner GameObjectId frequency [classname] ����ˢ��Ʒ��");
                this.SendMessage(".kill ɱ��");
                this.SendMessage(".nuke");
                this.SendMessage(".info");
                this.SendMessage(".where ѯ������");
                this.SendMessage(".remove �ƶ�");
                this.SendMessage(".set xp Amount");
                this.SendMessage(".set faction FactionNumber");
                this.SendMessage(".set godmode [on/off]");
                this.SendMessage(".set turbo [on/off]");
                this.SendMessage(".password NewPassword ��������");
                this.SendMessage(".grant [account|selected char] AccessLevel");
                this.SendMessage(".go LocationName | [ X Y Z MapId ]");
                this.SendMessage(".addlocation LocationName");
                this.SendMessage(".restart XMinutes");
                this.SendMessage(".whois");
                this.SendMessage(".broadcast Message");
                this.SendMessage(".hide");
                this.SendMessage(".unhide");
                this.SendMessage(".docgen");
                this.SendMessage(".removego");
                this.SendMessage(".armagedon");
                this.SendMessage(".mount");
                this.SendMessage(".unmount");
                return;
            }
            if (text2.StartsWith(".mount"))
            {
                if (((this.selection != null) && (this.selection is Mobile)) && (World.MountsList[(this.selection as Mobile).Id] != null))
                {
                    this.Mount(this.selection as Mobile);
                }
                return;
            }
            if (text2.StartsWith(".test"))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray1 = cmd.Split(chArray1);
                if (textArray1.Length != 3)
                {
                    this.SendMessage("Usage : .test MobName1 MobName2");
                    return;
                }
                if (this.testCombatStarted)
                {
                    this.SendMessage("A fight test is not finished yet !!");
                    return;
                }
                ConstructorInfo info1 = Utility.FindConstructor(textArray1[1], Utility.externAsm);
                ConstructorInfo info2 = Utility.FindConstructor(textArray1[2], Utility.externAsm);
                this.testCombatStarted = true;
                for (int num1 = 0; num1 < 50; num1++)
                {
                    BaseCreature creature1 = (BaseCreature) info1.Invoke(null);
                    creature1.Faction = Factions.Alliance;
                    World.Add(creature1, (float) (-13210f + (Utility.Random(50) - 0x19)), (float) (267.6f + (Utility.Random(50) - 0x19)), (float) 22f, (ushort) 0);
                    this.team1.Add(creature1);
                    creature1 = (BaseCreature) info2.Invoke(null);
                    creature1.Faction = Factions.Player_Tauren;
                    World.Add(creature1, (float) (-13210f + (Utility.Random(50) - 0x19)), (float) (287.6f + (Utility.Random(50) - 0x19)), (float) 22f, (ushort) 0);
                    this.team2.Add(creature1);
                }
                new MobBalance(this);
                return;
            }
            if (text2.StartsWith(".mark"))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray2 = text2.Split(chArray1);
                this.ff = (uint) Convert.ToInt32(textArray2[1]);
                this.SendMessage("num = " + this.ff.ToString("X8"));
                numArray1 = new int[1] { 0x23 } ;
                objArray1 = new object[1] { this.ff } ;
                this.SendSmallUpdate(numArray1, objArray1);
				return;
            }
            if (text2.StartsWith(".mars"))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray3 = text2.Split(chArray1);
                uint num2 = Convert.ToUInt32(textArray3[1]);
                this.cast.id = 0x21a5;
                this.cast.type = 2;
                this.SpellFaillure((SpellFailedReason) num2);
                return;
            }
            if (text2.StartsWith(".mare"))
            {
                return;
            }
            if (text2.StartsWith(".marb"))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray4 = text2.Split(chArray1);
                this.ff = (uint) Convert.ToInt32(textArray4[1]);
                this.SendMessage("num = " + this.ff.ToString("X8"));
                if (this.selection is Mobile)
                {
                    numArray1 = new int[1] { 0x468 } ;
                    objArray1 = new object[1] { this.ff } ;
                    (this.selection as Mobile).SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                }
                return;
            }
            if (text2.StartsWith(".marf"))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray5 = text2.Split(chArray1);
                this.ff = (uint) Convert.ToInt32(textArray5[1]);
                this.SendMessage("num = " + this.ff.ToString("X8"));
                if (this.selection is Mobile)
                {
                    numArray1 = new int[1] { 0x98 } ;
                    objArray1 = new object[1] { this.ff } ;
                    (this.selection as Mobile).SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                }
                return;
            }
            if (text2.StartsWith(".unmount"))
            {
                if (base.MountModel != 0)
                {
                    this.UnMount();
                }
                return;
            }
            if (text2.StartsWith(".set faction"))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray6 = cmd.Split(chArray1);
                if (this.selection is Mobile)
                {
                    if (textArray6.Length == 3)
                    {
                        int num3 = Convert.ToInt32(textArray6[2]);
                        numArray1 = new int[1] { 0x23 } ;
                        objArray1 = new object[1] { num3 } ;
                        (this.selection as Mobile).SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                        return;
                    }
                    this.SendMessage("Usage : .set faction FACTION_NUMBER");
                    return;
                }
                this.SendMessage("You must select a mobile first !");
                return;
            }
            if (text2.StartsWith(".removego"))
            {
                Server.Object obj1 = null;
                float single1 = float.MaxValue;
                foreach (Server.Object obj2 in World.allGameObjects)
                {
                    float single2 = base.Distance(obj2);
                    if (single2 < single1)
                    {
                        single1 = single2;
                        obj1 = obj2;
                    }
                }
                if (obj1 != null)
                {
                    World.Remove(obj1, this);
                }
                return;
            }
            if (text2.StartsWith(".docgen"))
            {
                this.SendMessage("Documentation is being generated, please wait.");
                Console.WriteLine("Documentation is being generated, please wait.");
                DateTime time1 = DateTime.Now;
                Docs.Document();
                DateTime time2 = DateTime.Now;
                TimeSpan span1 = (TimeSpan) (time2 - time1);
                Console.WriteLine("Documentation has been completed. The entire process took {0:F1} seconds.", span1.TotalSeconds);
                span1 = (TimeSpan) (time2 - time1);
                this.SendMessage("Documentation has been completed. The entire process took " + span1.TotalSeconds.ToString("F1") + " seconds.");
                return;
            }
            if (text2 == ".hide")
            {
                base.Visible = InvisibilityLevel.GM;
                AuraEffect effect1 = Character.gmInvisibilityAura;
                Aura aura1 = new Aura();
                aura1.OnRelease = new Aura.AuraReleaseDelegate(Character.OnGMInvisibilityEnded);
                base.AddAura(effect1, aura1);
                return;
            }
            if (text2.StartsWith(".unhide"))
            {
                base.Visible = InvisibilityLevel.Visible;
                base.ReleaseAura(Character.gmInvisibilityAura);
                return;
            }
            if (text2.StartsWith(".whois"))
            {
                foreach (Account account2 in World.allConnectedAccounts)
                {
                    if (account2.SelectedChar != null)
                    {
                        textArray20 = new string[10] { account2.Username.ToString(), " : ", account2.SelectedChar.Name, " is online at ( ", account2.SelectedChar.X.ToString(), "; ", account2.SelectedChar.Y.ToString(), "; ", account2.SelectedChar.Z.ToString(), ") " } ;
                        this.SendMessage(string.Concat(textArray20));
                        continue;
                    }
                    this.SendMessage(account2.Username.ToString() + " : [loggout]");
                }
                this.SendMessage("User online : " + World.allConnectedAccounts.Count.ToString());
                return;
            }
            if (text2.StartsWith(".broadcast "))
            {
                string text3 = cmd.Remove(0, 11);
                foreach (Account account3 in World.allConnectedAccounts)
                {
                    if (account3.SelectedChar != null)
                    {
                        this.SendMessage(account3.Username.ToString() + ", " + text3);
                    }
                }
                return;
            }
            if (text2.StartsWith(".restart "))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray7 = cmd.Split(chArray1);
                if (textArray7.Length == 2)
                {
                    World.Restart(Convert.ToInt32(textArray7[1]));
                    return;
                }
                this.SendMessage("Usage : .restart minutes");
                return;
            }
            if (text2.StartsWith(".addlocation "))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray8 = cmd.Split(chArray1);
                if (textArray8.Length == 2)
                {
                    TextReader reader1 = new StreamReader("./scripts/Globals/Locations.cs");
                    string text4 = reader1.ReadToEnd();
                    reader1.Close();
                    TextWriter writer1 = new StreamWriter("./scripts/Globals/Locations.cs");
                    int num4 = text4.IndexOf("#region Locations");
                    textArray20 = new string[10] { "\t\t\tWorld.Locations[ \"", textArray8[1], "\" ] = new Position( ", this.X.ToString(), "f, ", this.Y.ToString(), "f, ", this.Z.ToString(), "f, 0 );", writer1.NewLine } ;
                    string text5 = string.Concat(textArray20);
                    writer1.Write(text4.Substring(0, num4 + "#region Locations".Length));
                    writer1.Write(writer1.NewLine + text5);
                    writer1.Write(text4.Substring(num4 + "#region Locations".Length));
                    writer1.Close();
                    this.SendMessage("Done : " + text5);
                    return;
                }
                this.SendMessage("Usage : .addlocation LocationName");
                return;
            }
            if (text2.StartsWith(".zone"))
            {
                chArray1 = new char[1] { ' ' } ;
                string[] textArray9 = cmd.Split(chArray1);
                this.ZoneUpdateRequested(Convert.ToInt32(textArray9[1]));
                return;
            }
            if (!text2.StartsWith(".grant "))
            {
                if (text2.StartsWith(".password "))
                {
                    chArray1 = new char[1] { ' ' } ;
                    string[] textArray11 = cmd.Split(chArray1);
                    if (textArray11.Length < 2)
                    {
                        this.SendMessage("Usage : .password NewPassword");
                        return;
                    }
                    this.Player.Password = textArray11[1];
                    this.SendMessage("Your new password is : " + textArray11[1]);
                    this.SendMessage("Don't forget it !");
                    return;
                }
                if (text2.StartsWith(".info"))
                {
                    if (this.selection != null)
                    {
                        string text7 = "";
                        if (this.selection is BaseSpawner)
                        {
                            (this.selection as BaseSpawner).DisplayInfo(this);
                            return;
                        }
                        if (this.selection is Character)
                        {
                            text7 = text7 + "Player : ";
                        }
                        else if ((this.selection as Mobile).SummonedBy != null)
                        {
                            text7 = text7 + "Summoned creature : ";
                        }
                        else
                        {
                            text7 = text7 + "Creature : ";
                        }
                        Mobile mobile1 = this.selection as Mobile;
                        text7 = text7 + mobile1.Name + " Faction : " + mobile1.Faction.ToString();
                        this.SendMessage(text7);
                        textArray20 = new string[8] { "Pos : ", mobile1.X.ToString(), ", ", mobile1.Y.ToString(), ", ", this.selection.Z.ToString(), ", ", this.selection.MapId.ToString() } ;
                        text7 = string.Concat(textArray20);
                        this.SendMessage(text7);
                        text7 = "HitPoints : " + mobile1.HitPoints.ToString() + " / " + mobile1.BaseHitPoints.ToString();
                        this.SendMessage(text7);
                        text7 = "Mana : " + mobile1.Mana.ToString() + " / " + mobile1.BaseMana.ToString();
                        this.SendMessage(text7);
                        textArray20 = new string[5] { "Level : ", mobile1.Level.ToString(), " / ", mobile1.Exp.ToString(), " Xp" } ;
                        text7 = string.Concat(textArray20);
                        this.SendMessage(text7);
                        return;
                    }
                    this.SendMessage("You must select a mobile before");
                    return;
                }
                if (text2.StartsWith(".kill"))
                {
                    if ((this.selection != null) && (this.selection is Mobile))
                    {
                        (this.selection as Mobile).LooseHits(this, (this.selection as Mobile).HitPoints, true);
                    }
                    return;
                }
                if (!text2.StartsWith(".addgospawner"))
                {
                    if (text2.StartsWith(".armagedon"))
                    {
                        MobileList list2 = new MobileList();
                        int num10 = 0;
                        foreach (Mobile mobile2 in World.allMobiles)
                        {
                            if (mobile2 is Character)
                            {
                                list2.Add(mobile2);
                                continue;
                            }
                            num10++;
                        }
                        num10 += World.allSpawners.Count;
                        this.LinkedSpawner = -1;
                        World.allSpawners.Clear();
                        World.allMobiles = list2;
                        this.Player.RefreshMobileList(true);
                        this.SendMessage(num10.ToString() + " mobs/spawners removed !");
                    }
                    else if (text2.StartsWith(".nuke"))
                    {
                        MobileList list3 = new MobileList();
                        int num11 = 0;
                        foreach (Mobile mobile3 in World.allMobiles)
                        {
                            if (mobile3 is Character)
                            {
                                list3.Add(mobile3);
                                continue;
                            }
                            num11++;
                        }
                        World.allSpawners.Clear();
                        World.allMobiles = list3;
                        this.SendMessage(num11.ToString() + " mobs removed !");
                    }
                    else if (text2.StartsWith(".set godmode on"))
                    {
                        if ((this.selection != null) && (this.selection is Mobile))
                        {
                            (this.selection as Mobile).GodMode = true;
                        }
                        else
                        {
                            base.GodMode = true;
                        }
                    }
                    else if (text2.StartsWith(".set godmode off"))
                    {
                        if ((this.selection != null) && (this.selection is Mobile))
                        {
                            (this.selection as Mobile).GodMode = false;
                        }
                        else
                        {
                            base.GodMode = false;
                        }
                    }
                    else if (text2.StartsWith(".set turbo on"))
                    {
                        base.RunSpeed = 40f;
                        this.ChangeRunSpeed(40f);
                    }
                    else if (text2.StartsWith(".set turbo off"))
                    {
                        base.RunSpeed = 7f;
                        this.ChangeRunSpeed(7f);
                    }
                    else if (text2.StartsWith(".guid"))
                    {
                        if (this.selection == null)
                        {
                            this.SendMessage("Guid : " + base.Guid.ToString("X16"));
                        }
                        else
                        {
                            this.SendMessage("Guid : " + this.selection.Guid.ToString("X16"));
                        }
                    }
                    else if (text2.StartsWith(".addspawner"))
                    {
                        chArray1 = new char[1] { ' ' } ;
                        string[] textArray13 = cmd.Split(chArray1);
                        if (textArray13.Length == 4)
                        {
                            ConstructorInfo info4 = null;
                            try
                            {
                                BaseSpawner spawner3 = new BaseSpawner();
                                try
                                {
                                    int num12 = Convert.ToInt32(textArray13[1]);
                                    info4 = World.MobilePool(num12);
                                }
                                catch (Exception)
                                {
                                    info4 = Utility.FindConstructor(textArray13[1], Utility.externAsm);
                                    if (info4 == null)
                                    {
                                        info4 = Utility.FindConstructor(textArray13[1]);
                                    }
                                }
                                BaseCreature creature2 = (BaseCreature) info4.Invoke(null);
                                float single3 = float.MaxValue;
                                foreach (BaseSpawner spawner4 in World.allSpawners)
                                {
                                    float single4 = this.X - spawner4.X;
                                    float single5 = this.Y - spawner4.Y;
                                    single4 *= single4;
                                    single5 *= single5;
                                    single4 += single4;
                                    if ((single4 < single3) && (spawner4.MapId == base.MapId))
                                    {
                                        single3 = single4;
                                        spawner3.ZoneId = spawner4.ZoneId;
                                        spawner3.MapId = spawner4.MapId;
                                    }
                                }
                                spawner3.RealX = this.X;
                                spawner3.RealY = this.Y;
                                spawner3.RealZ = this.Z;
                                spawner3.Model = creature2.Model;
                                spawner3.Id = 0x5f5e0ff - creature2.Id;
                                spawner3.Orientation = base.Orientation;
                                spawner3.Init(info4, creature2.Id, Convert.ToInt32(textArray13[3]), Convert.ToInt32(textArray13[2]));
                                World.Add(spawner3, this.X, this.Y, this.Z, base.MapId);
                                if (this.linkedSpawner != -1)
                                {
                                    int num13 = World.allSpawners.Count - 1;
                                    ArrayList list4 = new ArrayList();
                                    World.regSpawners[num13] = list4;
                                    for (int num14 = 0; num14 < num13; num14++)
                                    {
                                        BaseSpawner spawner5 = World.allSpawners[num14];
                                        if ((spawner3.MapId == spawner5.MapId) && (spawner3.QuickDistance(spawner5) < 0x57e4))
                                        {
                                            list4.Add(num14);
                                        }
                                    }
                                    foreach (int num15 in list4)
                                    {
                                        (World.regSpawners[num15] as ArrayList).Add(num13);
                                    }
                                }
                                spawner3.ForceRespawn();
                                this.Player.RefreshMobileList(true);
                                return;
                            }
                            catch (Exception)
                            {
                                return;
                            }
                        }
                        this.SendMessage("usage : .addspawner mobname amount frequency");
                    }
                    else
                    {
                        if (text2.StartsWith(".set xp"))
                        {
                            chArray1 = new char[1] { ' ' } ;
                            string[] textArray14 = cmd.Split(chArray1);
                            if (textArray14.Length != 3)
                            {
                                return;
                            }
                            Character character1 = this.selection as Character;
                            if (character1 == null)
                            {
                                character1 = this;
                            }
                            try
                            {
                                uint num16 = Convert.ToUInt32(textArray14[2]) - character1.Exp;
                                character1.EarnXP((int) num16);
                                return;
                            }
                            catch (Exception)
                            {
                                this.SendMessage("usage : .set xp amount");
                                return;
                            }
                        }
                        if (text2.StartsWith(".debug"))
                        {
                            if ((this.selection != null) && (this.selection is BaseCreature))
                            {
                                BaseCreature creature3 = this.selection as BaseCreature;
                                if (creature3.DebugSniffer != null)
                                {
                                    creature3.DebugSniffer = null;
                                    this.SendMessage("Debug Off");
                                }
                                else
                                {
                                    creature3.DebugSniffer = this;
                                    this.SendMessage("Debug On");
                                }
                            }
                        }
                        else if (text2.StartsWith(".hidepath"))
                        {
                            ArrayList list5 = new ArrayList();
                            foreach (GameObject obj4 in World.allGameObjects)
                            {
                                if ((obj4.Id >= 0x97c70) && (obj4.Id <= 0x97c73))
                                {
                                    list5.Add(obj4);
                                }
                            }
                            foreach (GameObject obj5 in list5)
                            {
                                World.allGameObjects.Remove(obj5);
                            }
                            this.account.RefreshMobileList(true);
                        }
                        else if (text2.StartsWith(".showpath"))
                        {
                            foreach (Trajet trajet1 in World.trajets)
                            {
                                bool flag1 = true;
                                foreach (Coord coord1 in trajet1)
                                {
                                    if (base.Distance(coord1.x, coord1.y, coord1.z) < 160000f)
                                    {
                                        if (coord1 is Intersection)
                                        {
                                            World.Add(0x97c72, coord1.x, coord1.y, coord1.z, base.MapId);
                                        }
                                        else if (flag1)
                                        {
                                            World.Add(0x97c71, coord1.x, coord1.y, coord1.z, base.MapId);
                                        }
                                        else
                                        {
                                            World.Add(0x97c70, coord1.x, coord1.y, coord1.z, base.MapId);
                                        }
                                    }
                                    flag1 = false;
                                }
                            }
                            this.account.RefreshMobileList(true);
                        }
                        else if (text2.StartsWith(".delpath"))
                        {
                            if (this.startTrajetFlag != null)
                            {
                                this.DestroyObject(this.startTrajetFlag.Guid);
                            }
                            World.RemoveTrajet(this.path);
                            this.path.Clear();
                            this.path = null;
                            this.SendMessage("Path is removed");
                        }
                        else if (text2.StartsWith(".startpath"))
                        {
                            if (this.selection is BaseSpawner)
                            {
                                World.trajets.Dirty = true;
                                if (this.startTrajetFlag != null)
                                {
                                    this.DestroyObject(this.startTrajetFlag.Guid);
                                }
                                this.path = World.AllocateTrajet();
                                (this.selection as BaseSpawner).TrajetGuid = this.path.Guid;
                                this.startTrajetFlag = World.Add(0x97c71, this.X, this.Y, this.Z, base.MapId);
                                foreach (Server.Object obj6 in this.KnownObjects)
                                {
                                    if ((obj6 is BaseCreature) && ((obj6 as BaseCreature).SpawnerLink == this.selection))
                                    {
                                        (obj6 as BaseCreature).Freeze = true;
                                    }
                                }
                                this.SendMessage("Start a new path for the spawner");
                            }
                            else
                            {
                                this.SendMessage("You must select a spawner before starting a new path");
                            }
                        }
                        else if (text2.StartsWith(".endpath"))
                        {
                            if (this.startTrajetFlag != null)
                            {
                                World.Remove(this.startTrajetFlag, this);
                            }
                            if ((this.path != null) && (this.path.Count > 1))
                            {
                                this.path[0].previous = this.path[this.path.Count - 1];
                                this.path[this.path.Count - 1].next = this.path[0];
                            }
                            foreach (Server.Object obj7 in this.KnownObjects)
                            {
                                if ((obj7 is BaseCreature) && ((obj7 as BaseCreature).SpawnerLink == this.selection))
                                {
                                    (obj7 as BaseCreature).Freeze = true;
                                }
                            }
                            this.path = null;
                            this.SendMessage("Path loop completed");
                        }
                        else if (text2.StartsWith(".cast "))
                        {
                            chArray1 = new char[1] { ' ' } ;
                            string[] textArray15 = cmd.Split(chArray1);
                            if ((this.selection != null) && (this.selection is Mobile))
                            {
                                try
                                {
                                    int num17 = Convert.ToInt32(textArray15[1]);
                                    (this.selection as Mobile).FakeCast(num17, this);
                                    return;
                                }
                                catch (Exception)
                                {
                                    this.SendMessage("Invalid spell id !");
                                    return;
                                }
                            }
                            this.SendMessage("You must target a mobile !");
                        }
                        else if (text2.StartsWith(".additem "))
                        {
                            chArray1 = new char[1] { ' ' } ;
                            string[] textArray16 = cmd.Split(chArray1);
                            if (textArray16.Length == 3)
                            {
                                try
                                {
                                    this.CreateAndAddObject(textArray16[1], Convert.ToInt32(textArray16[2]));
                                    return;
                                }
                                catch (Exception)
                                {
                                    this.SendMessage("usage : .additem ItemName [number]");
                                    return;
                                }
                            }
                            if (textArray16.Length == 2)
                            {
                                this.CreateAndAddObject(textArray16[1]);
                            }
                            else
                            {
                                this.SendMessage("usage : .additem ItemName [number]");
                            }
                        }
                        else
                        {
                            if (text2.StartsWith(".addgo "))
                            {
                                try
                                {
                                    cmd = cmd.Remove(0, 7);
                                    chArray1 = new char[1] { ' ' } ;
                                    string[] textArray17 = cmd.Split(chArray1);
                                    int num18 = Convert.ToInt32(textArray17[0]);
                                    if (GameObjectDescription.all[num18] == null)
                                    {
                                        this.SendMessage("Unknow Game object " + num18.ToString());
                                        return;
                                    }
                                    GameObject obj8 = null;
                                    if (World.GameObjectsAssociated.Exist(num18))
                                    {
                                        obj8 = World.Add(num18, Utility.ClassName(World.GameObjectsAssociated[num18].ToString()), this.X, this.Y, this.Z, base.MapId);
                                        obj8.Id = num18;
                                    }
                                    else
                                    {
                                        obj8 = World.Add(num18, this.X, this.Y, this.Z, base.MapId);
                                    }
                                    if (this.linkedSpawner == -1)
                                    {
                                        this.SendMessage("You cannot place a game object here, first place a spawner !");
                                        return;
                                    }
                                    World.allSpawners[this.linkedSpawner].Bind(obj8);
                                    this.account.RefreshMobileList(true);
                                    return;
                                }
                                catch (Exception)
                                {
                                    return;
                                }
                            }
                            if (text2.StartsWith(".where"))
                            {
                                textArray20 = new string[8] { "X = ", this.X.ToString(), ", Y = ", this.Y.ToString(), ", Z = ", this.Z.ToString(), " mapId = ", base.MapId.ToString() } ;
                                this.SendMessage(string.Concat(textArray20));
                            }
                            else if (text2 == ".remove")
                            {
                                if (this.selection != null)
                                {
                                    this.selection.Delete();
                                    if (this.selection.Guid > 0xf100000000000000)
                                    {
                                        World.allSpawners.Remove(this.selection as BaseSpawner);
                                        this.SendMessage("Spawnpoint deleted");
                                        this.linkedSpawner = -1;
                                    }
                                    else
                                    {
                                        World.allMobiles.Remove(this.selection as Mobile);
                                        this.SendMessage((this.selection as Mobile).Name + " deleted");
                                    }
                                    this.account.HeartBeat();
                                }
                            }
                            else if (text2.StartsWith(".addnpc "))
                            {
                                chArray1 = new char[1] { ' ' } ;
                                string[] textArray18 = cmd.Split(chArray1);
                                if (textArray18.Length < 2)
                                {
                                    this.SendMessage("Usage : .addnpc NpcName [howmany]");
                                }
                                else
                                {
                                    Factions factions1 = Factions.NoFaction;
                                    int num19 = 1;
                                    if (textArray18.Length == 3)
                                    {
                                        try
                                        {
                                            num19 = Convert.ToInt32(textArray18[2]);
                                        }
                                        catch (Exception)
                                        {
                                        }
                                    }
                                    if (textArray18.Length == 4)
                                    {
                                        try
                                        {
                                            factions1 = (Factions) Convert.ToInt32(textArray18[3]);
                                        }
                                        catch (Exception)
                                        {
                                        }
                                    }
                                    for (int num20 = 0; num20 < num19; num20++)
                                    {
                                        ConstructorInfo info5 = null;
                                        try
                                        {
                                            int num21 = Convert.ToInt32(textArray18[1]);
                                            info5 = World.MobilePool(num21);
                                        }
                                        catch (Exception)
                                        {
                                            info5 = Utility.FindConstructor(textArray18[1], Utility.externAsm);
                                            if (info5 == null)
                                            {
                                                info5 = Utility.FindConstructor(textArray18[1]);
                                            }
                                        }
                                        if (info5 == null)
                                        {
                                            this.SendMessage(textArray18[1] + " is not a valid Npc !!!");
                                            return;
                                        }
                                        BaseCreature creature4 = null;
                                        try
                                        {
                                            creature4 = (BaseCreature) info5.Invoke(null);
                                        }
                                        catch (Exception exception1)
                                        {
                                            this.SendMessage(exception1.Message);
                                            this.SendMessage(exception1.Source);
                                            this.SendMessage(exception1.StackTrace);
                                            return;
                                        }
                                        creature4.X = this.X;
                                        creature4.Y = this.Y;
                                        creature4.Z = this.Z;
                                        creature4.ZoneId = base.ZoneId;
                                        creature4.MapId = base.MapId;
                                        creature4.InitStats();
                                        float single6 = float.MaxValue;
                                        BaseSpawner spawner6 = null;
                                        foreach (BaseSpawner spawner7 in World.allSpawners)
                                        {
                                            if (spawner7.Distance(this) < single6)
                                            {
                                                single6 = spawner7.Distance(this);
                                                spawner6 = spawner7;
                                            }
                                        }
                                        if (spawner6 != null)
                                        {
                                            spawner6.Bind(creature4);
                                        }
                                        World.allMobiles.Add(creature4, true);
                                        if (factions1 != Factions.NoFaction)
                                        {
                                            creature4.Faction = factions1;
                                        }
                                        this.Player.RefreshMobileList(true);
                                    }
                                }
                            }
                            else if (text2.StartsWith(".move"))
                            {
                                byte[] buffer1 = new byte[0x33] { 
                                    0, 0x31, 150, 0, 10, 0, 0, 0, 0, 50, 0x36, 0x21, 0, 0, 0, 0, 
                                    0, 0x1d, 0, 0, 0, 0x57, 0x65, 0x6c, 0x63, 0x6f, 0x6d, 0x65, 0x20, 0x74, 0x6f, 0x20, 
                                    0x57, 0x6f, 0x72, 0x6c, 100, 0x20, 0x6f, 0x66, 0x20, 0x57, 0x61, 0x72, 0x63, 0x72, 0x61, 0x66, 
                                    0x74, 0, 0
                                 } ;
                                int num22 = 9;
                                Converter.ToBytes(base.Guid, buffer1, ref num22);
                                this.Player.Handler.Send(150, buffer1);
                                foreach (Mobile mobile4 in World.allMobiles)
                                {
                                    if (!(mobile4 is Character))
                                    {
                                        mobile4.MovementHeartBeat(this.account.Handler, this);
                                    }
                                }
                            }
                            else if (text2.StartsWith(".save"))
                            {
                                MainConsole.world.SaveGame();
                            }
                            else if (!text2.StartsWith(".load"))
                            {
                                if (text2.StartsWith(".stest"))
                                {
                                    ConstructorInfo info6 = Utility.FindConstructor("RazorHillGrunt", Utility.externAsm);
                                    for (int num23 = 0; num23 < 400; num23 += 30)
                                    {
                                        for (int num24 = num23; num24 < (num23 + 30); num24++)
                                        {
                                            BaseCreature creature5 = (BaseCreature) info6.Invoke(null);
                                            creature5.Faction = (Factions) num24;
                                            creature5.Name = "Faction " + num24.ToString();
                                            creature5.Id = num24 + 0xfde8;
                                            World.Add(creature5, (float) (-13234f + ((num24 / 30) * 2f)), (float) (238f + ((num24 % 30) * 2f)), (float) 22f, (ushort) 0);
                                            creature5.Freeze = true;
                                        }
                                    }
                                }
                                else if (text2.StartsWith(".mark"))
                                {
                                    this.mark = new Position(this.X, this.Y, this.Z, base.MapId);
                                    textArray20 = new string[8] { "Mark at ", this.X.ToString(), ", ", this.Y.ToString(), ", ", this.Z.ToString(), ", ", base.MapId.ToString() } ;
                                    this.SendMessage(string.Concat(textArray20));
                                }
                                else if (text2.StartsWith(".recall"))
                                {
                                    if (this.mark == null)
                                    {
                                        this.SendMessage("You must mark a location first !");
                                    }
                                    else
                                    {
                                        this.Teleport(this.mark.X, this.mark.Y, this.mark.Z, this.mark.MapId);
                                    }
                                }
                                else if (text2.StartsWith(".go "))
                                {
                                    cmd = cmd.Remove(0, 4);
                                    chArray1 = new char[1] { ' ' } ;
                                    string[] textArray19 = cmd.Split(chArray1);
                                    if ((textArray19.Length == 4) && (textArray19.Length == 2))
                                    {
                                        this.SendMessage("Need at 1 or 4 parameters !");
                                        this.SendMessage("usage : .go X Y Z MapId or .go Location");
                                    }
                                    else if ((textArray19.Length == 1) && (World.Locations[textArray19[0]] == null))
                                    {
                                        this.SendMessage(textArray19[0] + " is an unknown location");
                                    }
                                    else if (textArray19.Length == 1)
                                    {
                                        Position position1 = (Position) World.Locations[textArray19[0]];
                                        this.Teleport(position1.X, position1.Y, position1.Z, position1.MapId);
                                    }
                                    else
                                    {
                                        this.Teleport(Convert.ToSingle(textArray19[0]), Convert.ToSingle(textArray19[1]), Convert.ToSingle(textArray19[2]), Convert.ToInt32(textArray19[3]));
                                    }
                                }
                                else if ((Character.onCommand == null) || Character.onCommand(this, cmd))
                                {
                                    this.SendMessage("Unknown command !");
                                }
                            }
                        }
                    }
                    return;
                }
                spawner1 = null;
                chArray1 = new char[1] { ' ' } ;
                string[] textArray12 = cmd.Split(chArray1);
                if (textArray12.Length == 3)
                {
                    try
                    {
                        if (Utility.FindConstructor(textArray12[1]) != null)
                        {
                            ConstructorInfo info3 = Utility.FindConstructor(textArray12[1]);
                            GameObject obj3 = (GameObject) info3.Invoke(null);
                            if (obj3.DefaultModel == 0)
                            {
                                this.SendMessage("This class does not implement the DefaultModel property !");
                                return;
                            }
                            spawner1 = new BaseSpawner();
                            spawner1.Init(textArray12[1], Convert.ToInt32(textArray12[2]));
                            World.Add(spawner1, this.X, this.Y, this.Z, base.MapId);
                            goto Label_12B9;
                        }
                        spawner1 = new BaseSpawner();
                        int num5 = -Convert.ToInt32(textArray12[1]);
                        spawner1.Init(num5, Convert.ToInt32(textArray12[2]));
                        World.Add(spawner1, this.X, this.Y, this.Z, base.MapId);
                        goto Label_12B9;
                    }
                    catch (Exception)
                    {
                        goto Label_12B9;
                    }
                }
                if (textArray12.Length == 4)
                {
                    try
                    {
                        spawner1 = new BaseSpawner();
                        int num6 = -Convert.ToInt32(textArray12[1]);
                        spawner1.Init(num6, Convert.ToInt32(textArray12[2]), textArray12[3]);
                        World.Add(spawner1, this.X, this.Y, this.Z, base.MapId);
                        goto Label_12B9;
                    }
                    catch (Exception)
                    {
                        goto Label_12B9;
                    }
                }
                this.SendMessage("usage : .addgospawner gameobjectname frequency [gameobjectclass]");
                goto Label_12B9;
            }
            string text6 = text2.Remove(0, 7);
            chArray1 = new char[1] { ' ' } ;
            string[] textArray10 = text6.Split(chArray1);
            Account account4 = null;
            if (textArray10.Length == 1)
            {
                if (this.selection is Character)
                {
                    text6 = textArray10[0];
                    account4 = (this.selection as Character).Player;
                    goto Label_0DCB;
                }
                this.SendMessage("Can only be used on character");
                return;
            }
            if ((textArray10.Length > 2) || (textArray10.Length == 0))
            {
                this.SendMessage("Usage : .grant [Account] AccessLevel");
                return;
            }
            text6 = textArray10[1];
            account4 = World.allAccounts.FindByUserName(textArray10[0].ToUpper());
            if (account4 == null)
            {
                this.SendMessage(textArray10[0] + " account not found !");
                return;
            }
        Label_0DCB:
            if (text6 == "admin")
            {
                this.SendMessage("The account " + account4.Username + " is now an administrator");
                account4.AccessLevel = AccessLevels.Admin;
                return;
            }
            if (text6 == "gm")
            {
                this.SendMessage("The account " + account4.Username + " is now a game master");
                account4.AccessLevel = AccessLevels.GM;
                return;
            }
            if (text6 == "player")
            {
                this.SendMessage("The account " + account4.Username + " have now player access level");
                account4.AccessLevel = AccessLevels.PlayerLevel;
                return;
            }
            this.SendMessage(text6 + " is not a valid access level !");
            return;
        Label_12B9:
            if (spawner1 != null)
            {
                if (this.linkedSpawner == -1)
                {
                    return;
                }
                int num7 = World.allSpawners.Count - 1;
                ArrayList list1 = new ArrayList();
                World.regSpawners[num7] = list1;
                for (int num8 = 0; num8 < num7; num8++)
                {
                    BaseSpawner spawner2 = World.allSpawners[num8];
                    if ((spawner1.MapId == spawner2.MapId) && (spawner1.QuickDistance(spawner2) < 0x57e4))
                    {
                        list1.Add(num8);
                    }
                }
                foreach (int num9 in list1)
                {
                    (World.regSpawners[num9] as ArrayList).Add(num7);
                }
            }
        }

        public void OnCreateCharacter()
        {
            if (Character.onCreateCharacter != null)
            {
                Character.onCreateCharacter(this);
            }
        }

        public override void OnDeath(Mobile by)
        {
            object[] objArray1;
            if (this.Duel != 0)
            {
                base.ReleaseAllAura();
                int num1 = 4;
                if (this.gu != null)
                {
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes(this.gu.Name, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Name, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                    this.Send(OpCodes.SMSG_DUEL_WINNER, this.tempBuff, num1);
                    this.gu.Send(OpCodes.SMSG_DUEL_WINNER, this.tempBuff, num1);
                    num1 = 4;
                    Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                    this.Send(OpCodes.SMSG_DUEL_COMPLETE, this.tempBuff, num1);
                    this.gu.Send(OpCodes.SMSG_DUEL_COMPLETE, this.tempBuff, num1);
                    num1 = 4;
                    Converter.ToBytes(this.Duel, this.tempBuff, ref num1);
                    this.Send(OpCodes.SMSG_GAMEOBJECT_DESPAWN_ANIM, this.tempBuff, num1);
                    this.gu.Send(OpCodes.SMSG_GAMEOBJECT_DESPAWN_ANIM, this.tempBuff, num1);
                    this.Send(OpCodes.SMSG_DESTROY_OBJECT, this.tempBuff, num1);
                    this.gu.Send(OpCodes.SMSG_DESTROY_OBJECT, this.tempBuff, num1);
                    base.HitPoints = base.BaseHitPoints / 4;
                    objArray1 = new object[4] { 0, 0, 0, 0 } ;
                    this.SendSmallUpdateToPlayerNearMe(new int[4] { 0x94, 0xb2, 0xb3, 0xba } , objArray1);
                    objArray1 = new object[4] { 0, 0, 0, 0 } ;
                    this.gu.SendSmallUpdateToPlayerNearMe(new int[4] { 0x94, 0xb2, 0xb3, 0xba } , objArray1);
                    Aura aura1 = new Aura();
                    base.AddAura(Abilities.abilities[0x1c63] as AuraEffect, aura1, true);
                    num1 = 4;
                    this.gu.Send(OpCodes.SMSG_CANCEL_COMBAT, this.tempBuff, num1);
                    this.Send(OpCodes.SMSG_CANCEL_COMBAT, this.tempBuff, num1);
                    this.gu.Duel = 0;
                    this.gu.guowner = null;
                    this.gu.gu = null;
                }
                this.Duel = 0;
                this.guowner = null;
                this.gu = null;
                this.dt.Stop();
                this.dt = null;
            }
            else
            {
                base.NextAttackEffects.Clear();
                by.NextAttackEffects.Clear();
                if (base.Summon != null)
                {
                    this.DismissPet(base.Summon.Guid);
                }
                base.ReleaseAllAura();
                this.corpsGuid = 0;
                this.CorpseLocationX = this.X;
                this.CorpseLocationY = this.Y;
                this.CorpseLocationZ = this.Z;
                this.CorpseMapId = base.MapId;
                if (by != null)
                {
                    by.XpEarn(this);
                }
                int[] numArray1 = new int[2] { 0x16, 0x2e } ;
                objArray1 = new object[2] { 0, 0x4008 } ;
                this.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
            }
        }

        public void OnFirstHit()
        {
            if (base.AttackTarget == null)
            {
                this.StopAttacking();
            }
            else
            {
                if (base.AttackTarget is BaseCreature)
                {
                    base.AttackTarget.UpdateXYZ();
                }
                if (Mobile.GetDirection(this, base.AttackTarget) != Mobile.Pos.Front)
                {
                    this.account.ToAllPlayerNear(OpCodes.SMSG_ATTACKSWING_BADFACING, this.tempBuff, 4);
                }
                else
                {
                    float single1 = base.Distance(base.AttackTarget);
                    if (single1 < (9.5 * (base.AttackTarget.CombatReach + base.CombatReach)))
                    {
                        this.lastDistance = single1;
                        if (this.firstHitCombatTimer != null)
                        {
                            this.firstHitCombatTimer.Stop();
                        }
                        this.firstHitCombatTimer = null;
                        this.FaitFace(base.AttackTarget);
                        int num1 = 0;
                        int num2 = 0;
                        this.Hit(base.AttackTarget, ref num1, ref num2);
                        this.combatTimer = new Server.Character.CombatTimer(base.AttackTarget.Guid, this, this.activeWeapon.Delay / 3);
                    }
                    else
                    {
                        this.compteur++;
                        if ((this.compteur % 10) == 1)
                        {
                            this.account.ToAllPlayerNear(OpCodes.SMSG_ATTACKSWING_NOTINRANGE, this.tooFar, 4);
                        }
                    }
                }
            }
        }

        public override void OnGetHit(Mobile by, bool sp, int damageAmount)
        {
            base.OnGetHit(by, sp, damageAmount);
        }

        public static void OnGMInvisibilityEnded(Mobile c)
        {
            c.Visible = InvisibilityLevel.Visible;
        }

        public void OnLogin()
        {
            if (base.Dead)
            {
                this.X = this.CorpseLocationX;
                this.Y = this.CorpseLocationY;
                this.Z = this.CorpseLocationZ;
                base.MapId = this.CorpseMapId;
                this.OnDeath(this);
            }
            if (base.Summon != null)
            {
                base.Summon.X = this.X;
                base.Summon.Y = this.Y;
                base.Summon.Z = this.Z;
                base.Summon.MapId = base.MapId;
                base.Summon.Freeze = false;
                this.Player.RefreshMobileList(true);
            }
            this.internalTimer = new InternalHeartBeatTimer(this);
            this.internalTimer.Start();
            if (Character.onLogin != null)
            {
                Character.onLogin(this);
            }
            this.logged = true;
            ICollection collection1 = base.KnownAbilities.Keys;
            foreach (int num1 in base.TalentList.Keys)
            {
                if (((base.KnownAbilities[num1] != null) && (SpellTemplate.SpellEffects[num1] != null)) && (SpellTemplate.SpellEffects[num1] is PermanentSpellEffect))
                {
                    PermanentSpellEffect effect1 = (PermanentSpellEffect) SpellTemplate.SpellEffects[num1];
                    effect1(Abilities.abilities[num1], this);
                }
            }
        }

        public void OnLogout()
        {
            if (base.Summon != null)
            {
                base.Summon.X = -2000f;
                base.Summon.Y = -2000f;
                base.Summon.Z = 1000f;
                base.Summon.MapId = 2;
                base.Summon.Freeze = true;
            }
            if (this.combatTimer != null)
            {
                this.combatTimer.Stop();
            }
            if (base.SpellTimer != null)
            {
                base.SpellTimer.Stop();
            }
            if (this.internalTimer != null)
            {
                this.internalTimer.Stop();
            }
            if (Character.onLogout != null)
            {
                Character.onLogout(this);
            }
        }

        public void OnLootMoney()
        {
            if (this.currentObjectLooted != null)
            {
                int num1 = 0;
                Item[] itemArray1 = this.currentObjectLooted.Treasure;
                for (int num3 = 0; num3 < itemArray1.Length; num3++)
                {
                    Item item1 = itemArray1[num3];
                    if (item1 is Money)
                    {
                        int[] numArray1;
                        object[] objArray1;
                        if ((this.GroupMembers != null) && (this.GroupMembers.Count > 0))
                        {
                            int num2 = item1.MaxCount / this.GroupMembers.Members.Count;
                            foreach (Member member1 in this.GroupMembers.Members)
                            {
                                Character character1 = member1.Char;
                                character1.Copper += ((uint) num2);
                                numArray1 = new int[1] { 0x43a } ;
                                objArray1 = new object[1] { member1.Char.Copper } ;
                                member1.Char.SendSmallUpdate(numArray1, objArray1);
                            }
                        }
                        else
                        {
                            this.Copper += ((uint) item1.MaxCount);
                            numArray1 = new int[1] { 0x43a } ;
                            objArray1 = new object[1] { this.Copper } ;
                            this.SendSmallUpdate(numArray1, objArray1);
                        }
                        item1.MaxCount = 0;
                        this.currentObjectLooted.Treasure[num1] = null;
                        Server.Object obj1 = this.account.FindObjectByGuid(this.LootOwner);
                        if (obj1 != null)
                        {
                            if (obj1 is Mobile)
                            {
                                (obj1 as Mobile).LootMoney = 0;
                                return;
                            }
                            if (!(obj1 is BaseChest))
                            {
                                return;
                            }
                            (obj1 as BaseChest).LootMoney = 0;
                        }
                        return;
                    }
                    num1++;
                }
            }
        }

		//�ͷ����
        public void OnRepop()
        {
            Character.onCharacterRepop(this);
            if (this.corpsGuid == 0)
            {
                object[] objArray1;
                ArrayList list1 = new ArrayList();
                foreach (Server.Object obj1 in this.Player.KnownObjects)
                {
                    if (((obj1 is Mobile) && (obj1 != this)) && !(obj1 as Mobile).Dead)
                    {
                        list1.Add(obj1);
                    }
                }
                foreach (Mobile mobile1 in list1)
                {
                    if (mobile1.LastSeen == this)
                    {
                        mobile1.LastSeen = null;
                    }
                    this.DestroyObject(mobile1.Guid);
                    this.Player.KnownObjects.Remove(mobile1);
                }
                Corps corps1 = World.Add(this, this.X, this.Y, this.Z, base.MapId);
                this.corpsGuid = corps1.Guid;
                float single1 = float.MaxValue;
                Position position1 = null;
                foreach (Position position2 in World.Cemetery)
                {
                    float single2 = base.QuickDistance(position2);
                    if (single2 < single1)
                    {
                        single1 = single2;
                        position1 = position2;
                    }
                }
                if (position1 != null)
                {
                    this.Teleport(position1.X, position1.Y, position1.Z);
                    this.account.RefreshMobileList(true);
                }
                if (this.Race == Races.NightElf)
                {
                    objArray1 = new object[7] { 1, 0x5069, 0, 0, 0xdddddddd, 2, 0x10 } ;
                    this.SendSmallUpdateToPlayerNearMe(new int[7] { 0x16, 0x4f, 0x6f, 0x79, 0x7f, 130, 180 } , objArray1);
                }
                else
                {
                    objArray1 = new object[7] { 1, 0x2086, 0, 0, 0xdddddddd, 2, 0x10 } ;
                    this.SendSmallUpdateToPlayerNearMe(new int[7] { 0x16, 0x4f, 0x6f, 0x79, 0x7f, 130, 180 } , objArray1);
                }
                this.account.ToAllPlayerNear(OpCodes.SMSG_UPDATE_AURA_DURATION, new byte[9] { 0, 0, 0, 0, 0x20, 0xff, 0xff, 0xff, 0xff } , 9);
                this.ItemsUpdate();
            }
        }

		public override void OnSpellCasted(Server.Object target)
		{
			if ((Mobile.onSpellCasted != null) && Mobile.onSpellCasted(this, this.cast.id, target))
			{
				return;
			}
			Profession profession1 = null;
			BaseAbility ability1 = Abilities.abilities[this.cast.id];
			if (ability1 is CraftTemplate)
			{
				(ability1 as CraftTemplate).Create(this.cast, this);
				return;
			}
			int num1 = this.cast.id;
			if (num1 <= 0x1dc4)
			{
				if (num1 <= 0xa13)
				{
					if (num1 == 0x189)
					{
						goto Label_01C2;
					}
					switch (num1)
					{
						case 0x93e:
						case 0x940:
						{
							goto Label_0198;
						}
						case 0x93f:
						{
							goto Label_0209;
						}
						case 0xa0f:
						case 0xa10:
						case 0xa11:
						case 0xa12:
						case 0xa13:
						{
							goto Label_016E;
						}
					}
					goto Label_0209;
				}
				if (num1 == 0xa61)
				{
					(Abilities.abilities[0xa61] as CraftTemplate).Create(this.cast, this);
					return;
				}
				if (num1 == 0xdf2)
				{
					goto Label_0198;
				}
				if (num1 == 0x1dc4)
				{
					goto Label_014A;
				}
				goto Label_0209;
			}
			if (num1 <= 0x21aa)
			{
				switch (num1)
				{
					case 0x1e33:
					case 0x1e34:
					{
						goto Label_014A;
					}
					case 0x21a5:
					case 0x21a9:
					case 0x21aa:
					{
						goto Label_01C2;
					}
				}
				goto Label_0209;
			}
			if (num1 <= 0x2ed9)
			{
				if (num1 == 0x2a10)
				{
					goto Label_01C2;
				}
				if (num1 == 0x2ed9)
				{
					goto Label_0198;
				}
				goto Label_0209;
			}
			if (num1 == 0x352b)
			{
				goto Label_016E;
			}
			if (num1 != 0x4748)
			{
				goto Label_0209;
			}
			Label_014A:
				profession1 = (Profession) base.AllSkills[0x164];
			profession1.UseFishing(this.cast, this);
			return;
			Label_016E:
				profession1 = (Profession) base.AllSkills[0xba];
			profession1.UseMining(this.cast, this, (GameObject) target);
			return;
			Label_0198:
				profession1 = (Profession) base.AllSkills[0xb6];
			profession1.UseHerbalist(this.cast, this, (GameObject) target);
			return;
			Label_01C2:
				profession1 = (Profession) base.AllSkills[0x189];
			profession1.UseSkinning(this.cast, this, (Mobile) target);
			return;
			Label_0209:
				if (ability1 is SpellTemplate)
				{
					base.OnSpellTemplateResults(ability1, target);
					this.SpellSuccess();
				}
				else
				{
					this.SpellSuccess();
				}
		}

        public void OnTextEmote(int n, ulong guid)
        {
            Character character1 = null;
            if ((guid == 0) || (guid == base.Guid))
            {
                character1 = this;
            }
            else
            {
                character1 = this.account.FindPlayerNearByGuid(guid);
            }
            if (character1 != null)
            {
                int num1 = 4;
                if (World.Emote[n] != null)
                {
                    Converter.ToBytes(World.Emote[n], this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes(1, this.tempBuff, ref num1);
                }
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                this.account.ToAllPlayerNearExceptMe(OpCodes.SMSG_EMOTE, this.tempBuff, num1);
            }
        }

        public bool OnTrainningAck()
        {
            if (Character.onTrainningAck != null)
            {
                return Character.onTrainningAck(this);
            }
            return true;
        }

        public override void OnUnMount(Mobile c)
        {
            int num1 = 4;
            if (base.Summon != null)
            {
                base.Summon.Visible = InvisibilityLevel.Visible;
                base.Summon.X = this.X;
                base.Summon.Y = this.Y;
                base.Summon.Z = this.Z;
                base.Summon.Orientation = base.Orientation;
                this.Player.RefreshMobileList(true);
            }
            base.MountModel = 0;
            num1 = 4;
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, false);
            this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
            this.ItemsUpdate();
            base.ReleaseAura(this.mountedIdAuraEffect);
        }

        public void PartialUpdate(ArrayList all)
        {
            int num1 = all.Count;
            if (num1 != 0)
            {
                int num2 = 0;
                Converter.ToBytes(num1, this.tempBuff, ref num2);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num2);
                foreach (Server.Object obj1 in all)
                {
                    if ((obj1 == this) || !(obj1 is Character))
                    {
                        obj1.PrepareUpdateData(this.tempBuff, ref num2, UpdateType.UpdateFull, false, this);
                        continue;
                    }
                    (obj1 as Character).PrepareUpdateDataForOther(this.tempBuff, ref num2, UpdateType.UpdateFull, this);
                    for (int num3 = 0; num3 < 0x18; num3++)
                    {
                        Item item1 = (obj1 as Character).Items[num3];
                        if (item1 != null)
                        {
                            num1++;
                            item1.PrepareUpdateData(this.tempBuff, ref num2, UpdateType.UpdateFull, obj1 as Character);
                        }
                    }
                }
                int num4 = num1;
                num1 = 0;
                Converter.ToBytes(num4, this.tempBuff, ref num1);
                num1 = num4;
                byte[] buffer1 = Zip.Compress(this.tempBuff, 0, num2);
                byte[] buffer2 = new byte[buffer1.Length + 8];
                Buffer.BlockCopy(buffer1, 0, buffer2, 8, buffer1.Length);
                num1 = 4;
                Converter.ToBytes(num2, buffer2, ref num1);
                this.account.Handler.Send(0x1f6, buffer2, (int) (buffer1.Length + 6));
            }
        }

        public void PetAction(ushort ability, byte b, ulong g)
        {
            if (base.Summon != null)
            {
                if (b < 10)
                {
                    byte num2;
                    byte num1 = (byte) ability;
                    if (b == 6)
                    {
                        num2 = num1;
                        switch (num2)
                        {
                            case 0:
                            {
                                (base.Summon as BaseCreature).AIStance = AIStances.Passive;
                                return;
                            }
                            case 1:
                            {
                                (base.Summon as BaseCreature).AIStance = AIStances.Defensive;
                                return;
                            }
                            case 2:
                            {
                                (base.Summon as BaseCreature).AIStance = AIStances.Agressive;
                                return;
                            }
                        }
                    }
                    else if (b == 7)
                    {
                        num2 = num1;
                        switch (num2)
                        {
                            case 0:
                            {
                                (base.Summon as BaseCreature).AIState = AIStates.Pause1;
                                return;
                            }
                            case 1:
                            {
                                (base.Summon as BaseCreature).AIState = AIStates.Follow;
                                return;
                            }
                            case 2:
                            {
                                (base.Summon as BaseCreature).OnGetHit(this.Player.FindMobileByGuid(g));
                                return;
                            }
                            case 3:
                            {
                                this.DismissPet(base.Summon.Guid);
                                return;
                            }
                        }
                    }
                }
                else
                {
                    Mobile mobile1 = base.Summon.AttackTarget;
                    if ((base.Summon.AttackTarget == null) && (this.Selection is Mobile))
                    {
                        base.Summon.AttackTarget = this.Selection as Mobile;
                    }
                    if (base.Summon.AttackTarget == null)
                    {
                        base.Summon.AttackTarget = base.Summon;
                    }
                    base.Summon.AISpellAttack(ability);
                    base.Summon.AttackTarget = mobile1;
                }
            }
        }

        public void PrepareInv(byte[] data, int off)
        {
            if (this.guowner != null)
            {
                this.SendMessage("You have already requested a duel !");
            }
            else
            {
                ulong num1 = BitConverter.ToUInt64(data, off + 12);
                this.gu = (Character) this.Player.FindMobileByGuid(num1);
                if (this.gu.guowner != null)
                {
                    this.SendMessage("The target have already requested a duel !");
                }
                else
                {
                    this.guowner = this;
                    this.gu.guowner = this;
                    this.Deturn();
                }
            }
        }

        public void PreparePartielUpdateDataHeader(byte[] data, ref int offset)
        {
            Converter.ToBytes(1, data, ref offset);
            data[offset++] = 0;
            data[offset++] = 0;
            Converter.ToBytes(base.Guid, data, ref offset);
            base.ResetBitmap();
            data[offset++] = 0x1c;
        }

        public void PrepareTrainerListTeach(int t, ref int offset, Teach teach)
        {
            if (teach != null)
            {
                if (Abilities.abilities[teach.TeachId] is Profession)
                {
                    this.PrepareTrainerListTeachProfession(t, ref offset, teach);
                }
                else if (Abilities.abilities[teach.TeachId] is CraftTemplate)
                {
                    this.PrepareTrainerListTeachCraftTemplate(t, ref offset, teach);
                }
                else if (Abilities.abilities[teach.TeachId] is SpellTemplate)
                {
                    this.PrepareTrainerListTeachSpellTemplate(t, ref offset, teach);
                }
            }
        }

        public void PrepareTrainerListTeachCraftTemplate(int t, ref int offset, Teach teach)
        {
            int num1 = 0;
            if (Character.onSpellPrice != null)
            {
                num1 = Character.onSpellPrice(this, teach.Id);
            }
            if (num1 == 0)
            {
                num1 = CustomSpellHandlers.SpellCost(teach.TeachId);
            }
            int num2 = CustomSpellHandlers.SpellPrerequisites(teach.TeachId);
            if (Abilities.abilities[teach.TeachId] is CraftTemplate)
            {
                Converter.ToBytes(t, this.tempBuff, ref offset);
                CraftTemplate template1 = (CraftTemplate) Abilities.abilities[teach.TeachId];
                if (template1 == null)
                {
                    return;
                }
                if (!this.HaveSpell(template1))
                {
                    if (this.HaveSkill(num2))
                    {
                        if (this.Copper >= num1)
                        {
                            Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
                        }
                        else
                        {
                            Converter.ToBytes((byte) 1, this.tempBuff, ref offset);
                        }
                    }
                    else
                    {
                        Converter.ToBytes((byte) 1, this.tempBuff, ref offset);
                    }
                }
                else
                {
                    Converter.ToBytes((byte) 2, this.tempBuff, ref offset);
                }
            }
            Converter.ToBytes(num1, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(num2, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
        }

        public void PrepareTrainerListTeachProfession(int t, ref int offset, Teach teach)
        {
            Profession profession1 = (Profession) Abilities.abilities[teach.TeachId];
            int num1 = 0;
            if (Character.onSpellPrice != null)
            {
                num1 = Character.onSpellPrice(this, teach.Id);
            }
            if (num1 == 0)
            {
                num1 = CustomSpellHandlers.SpellCost(teach.TeachId);
            }
            int num2 = CustomSpellHandlers.SpellPrerequisites(teach.TeachId);
            Converter.ToBytes(t, this.tempBuff, ref offset);
            if ((base.nProfessions == 0) && (profession1.Level == ProfessionLevels.Apprentice))
            {
                Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
            }
            else if ((num2 != 0) && !this.HaveSpell(num2))
            {
                Converter.ToBytes((byte) 1, this.tempBuff, ref offset);
            }
            else if (((base.nProfessions == 0) && (profession1.Level == ProfessionLevels.Apprentice)) && (base.AllSkills[profession1.Id] == null))
            {
                Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
            }
            else if (base.AllSkills[profession1.Id] != null)
            {
                Profession profession2 = (Profession) base.AllSkills[profession1.Id];
                if (profession2.Level >= profession1.Level)
                {
                    Converter.ToBytes((byte) 2, this.tempBuff, ref offset);
                }
                //else if ((profession2.Level + ProfessionLevels.Journeyman) == profession1.Level)
				 else if (((int)profession2.Level + (int)ProfessionLevels.Journeyman) == (int)profession1.Level)//fix
                {
                    Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
                }
                else
                {
                    Converter.ToBytes((byte) 1, this.tempBuff, ref offset);
                }
            }
            else if (base.nProfessions == 2)
            {
                Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
            }
            else if ((base.nProfessions == 1) && (profession1.Level == ProfessionLevels.Apprentice))
            {
                Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
            }
            else
            {
                Converter.ToBytes((byte) 1, this.tempBuff, ref offset);
            }
            Converter.ToBytes(num1, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(num2, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
            Converter.ToBytes(0, this.tempBuff, ref offset);
        }

        public void PrepareTrainerListTeachSpellTemplate(int t, ref int offset, Teach teach)
        {
            SpellTemplate template1 = (SpellTemplate) Abilities.abilities[teach.TeachId];
            if (template1 != null)
            {
                Converter.ToBytes(t, this.tempBuff, ref offset);
                int num1 = template1.RequieredLevel;
                int num2 = 0;
                if (Character.onSpellPrice != null)
                {
                    num2 = Character.onSpellPrice(this, teach.TeachId);
                }
                if (num2 == 0)
                {
                    num2 = CustomSpellHandlers.SpellCost(teach.TeachId);
                }
                if (!this.HaveSpell(teach.TeachId))
                {
                    if (base.Level >= num1)
                    {
                        if (this.Copper >= num2)
                        {
                            Converter.ToBytes((byte) 0, this.tempBuff, ref offset);
                        }
                        else
                        {
                            Converter.ToBytes((byte) 1, this.tempBuff, ref offset);
                        }
                    }
                    else
                    {
                        Converter.ToBytes((byte) 1, this.tempBuff, ref offset);
                    }
                }
                else
                {
                    Converter.ToBytes((byte) 2, this.tempBuff, ref offset);
                }
                Converter.ToBytes(num2, this.tempBuff, ref offset);
                Converter.ToBytes(0, this.tempBuff, ref offset);
                Converter.ToBytes(0, this.tempBuff, ref offset);
                Converter.ToBytes((byte) num1, this.tempBuff, ref offset);
                Converter.ToBytes(0, this.tempBuff, ref offset);
                Converter.ToBytes(0, this.tempBuff, ref offset);
                Converter.ToBytes(0, this.tempBuff, ref offset);
                Converter.ToBytes(0, this.tempBuff, ref offset);
                Converter.ToBytes(0, this.tempBuff, ref offset);
            }
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther)
        {
            this.PrepareUpdateData(data, ref offset, type, false, this);
        }

        public override void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther, Character f)
        {
            if (type == UpdateType.UpdateFull)
            {
                data[offset++] = 2;
            }
            else
            {
                this.PreparePartielUpdateData(data, ref offset);
                return;
            }
            Converter.ToBytes(base.Guid, data, ref offset);
            base.ResetBitmap();
            Converter.ToBytes((byte) 4, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(this.X, data, ref offset);
            Converter.ToBytes(this.Y, data, ref offset);
            Converter.ToBytes(this.Z, data, ref offset);
            Converter.ToBytes(base.Orientation, data, ref offset);
            Converter.ToBytes((float) 0f, data, ref offset);
            Converter.ToBytes(base.WalkSpeed, data, ref offset);
            Converter.ToBytes(base.RunSpeed, data, ref offset);
            Converter.ToBytes(base.SwimBackSpeed, data, ref offset);
            Converter.ToBytes(base.SwimSpeed, data, ref offset);
            Converter.ToBytes((float) 4.5f, data, ref offset);
            Converter.ToBytes((float) 3.141593f, data, ref offset);
            if (forOther)
            {
                Converter.ToBytes((uint) 0, data, ref offset);
            }
            else
            {
                Converter.ToBytes((uint) 1, data, ref offset);
            }
            Converter.ToBytes((uint) 1, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            Converter.ToBytes(0, data, ref offset);
            base.setUpdateValue(Const.OBJECT_FIELD_GUID, base.Guid);
            base.setUpdateValue(Const.OBJECT_FIELD_TYPE, 0x19);
            base.setUpdateValue(Const.OBJECT_FIELD_ENTRY, 0);
            base.setUpdateValue(Const.OBJECT_FIELD_SCALE_X, (float) 1f);
            if (base.Summon != null)
            {
                base.setUpdateValue(8, base.Summon.Guid);
            }
            base.setUpdateValue(0x16, base.HitPoints);
            base.setUpdateValue((int) (0x17 + base.ManaType), base.Mana);
            base.setUpdateValue(0x1c, base.BaseHitPoints);
            base.setUpdateValue((int) (0x1d + base.ManaType), base.BaseMana);
            base.setUpdateValue(0x22, base.Level);
            base.setUpdateValue(0x23, (int) base.Faction);
			//uint num1 = (uint) (((((ulong) this.race) + (((int) base.Classe) << 8)) + (this.gender << 0x10)) + ((ulong) (this.manaType << 0x18)));
            uint num1 = (uint) (((((int) this.race) + (((int) base.Classe) << 8)) + (this.gender << 0x10)) + ((int) (this.manaType << 0x18)));//fix
            base.setUpdateValue(0x24, num1);
            if (!forOther)
            {
                base.setUpdateValue(0x2e, this.Flags);
            }
            else
            {
                base.setUpdateValue(0x2e, this.Flags);
            }
            foreach (Mobile.AuraReleaseTimer timer1 in base.Auras)
            {
                base.setUpdateValue((int) (0x2f + timer1.num), timer1.ae.Id);
            }
            base.setUpdateValue(0x67, 0);
            base.setUpdateValue(0x71, 0);
            base.setUpdateValue(0x7b, (uint) 0xdddddddd);
            base.setUpdateValue(130, 2);
            base.setUpdateValue(0x83, 0x7d0);
            base.setUpdateValue(0x84, 0x7d0);
            base.setUpdateValue(0x86, (float) 0.389f);
            base.setUpdateValue(0x87, (float) 0.389f);
            base.setUpdateValue(0x88, base.Model);
            base.setUpdateValue(0x89, base.Model);
            base.setUpdateValue(0x8a, base.MountModel);
            if (this.activeWeapon == null)
            {
                this.activeWeapon = this.ChooseWeapon();
            }
            base.setUpdateValue(0x8b, this.BaseMinDamage);
            base.setUpdateValue(140, this.BaseMaxDamage);
            base.setUpdateValue(0x8f, (int) base.StandState);
            if (!forOther)
            {
                base.setUpdateValue(0x94, this.DynFlags(f));
            }
            if (!forOther)
            {
                base.setUpdateValue(0x9b, (uint) base.Str);
                base.setUpdateValue(0x9c, (uint) base.Agility);
                base.setUpdateValue(0x9d, (uint) base.Stamina);
                base.setUpdateValue(0x9e, (uint) base.Iq);
                base.setUpdateValue(0x9f, (uint) base.Spirit);
                base.setUpdateValue(160, (uint) base.Armor);
                base.setUpdateValue(0xa1, (uint) base.ResistHoly);
                base.setUpdateValue(0xa2, (uint) base.ResistFire);
                base.setUpdateValue(0xa3, (uint) base.ResistNature);
                base.setUpdateValue(0xa4, (uint) base.ResistFrost);
                base.setUpdateValue(0xa5, (uint) base.ResistShadow);
                base.setUpdateValue(0xa6, (uint) base.ResistArcane);
            }
            base.setUpdateValue(0xa7, base.AttackPower);
            base.setUpdateValue(0xab, base.RangedAttackPower);
			//Gm��־
            if (this.Player.AccessLevel == AccessLevels.PlayerLevel)
            {
                base.setUpdateValue(180, 0);
            }
            else
            {
                base.setUpdateValue(180, 8);
            }
            uint num2 = (uint) (((this.skin | (this.face << 8)) | (this.hairStyle << 0x10)) | (this.hairColour << 0x18));
            uint num3 = (uint) (0x101ee00 + this.facialHair);
            base.setUpdateValue(0xb7, num2);
            base.setUpdateValue(0xb8, num3);
            if (!forOther)
            {
                int num4 = 0xbc;
                for (int num5 = 0; num5 < 20; num5++)
                {
                    if (this.activeQuests[num5] != null)
                    {
                        base.setUpdateValue((int) (num4 + (num5 * 3)), (uint) this.activeQuests[num5].Id);
                        if (this.activeQuests[num5].HaveDeliveryObj)
                        {
                            base.setUpdateValue((int) ((num4 + 1) + (num5 * 3)), (uint) this.activeQuests[num5].DeliveryCurrentAmount());
                        }
                        else
                        {
                            base.setUpdateValue((int) ((num4 + 1) + (num5 * 3)), (uint) 0);
                        }
                        base.setUpdateValue((int) ((num4 + 2) + (num5 * 3)), (uint) 0);
                    }
                    else
                    {
                        base.setUpdateValue((int) (num4 + (num5 * 3)), (uint) 0);
                        base.setUpdateValue((int) ((num4 + 1) + (num5 * 3)), (uint) 0);
                        base.setUpdateValue((int) ((num4 + 2) + (num5 * 3)), (uint) 0);
                    }
                }
                int num6 = Mobile.xpNeeded[base.Level];
                if (base.Level > 1)
                {
                    uint num7 = base.Exp - ((uint) Mobile.xpNeeded[base.Level - 1]);
                    num6 = Mobile.xpNeeded[base.Level] - Mobile.xpNeeded[base.Level - 1];
                    base.setUpdateValue(0x26e, num7);
                }
                else
                {
                    base.setUpdateValue(0x26e, base.Exp);
                }
                base.setUpdateValue(0x26f, num6);
                int num8 = 0x270;
                IDictionaryEnumerator enumerator1 = base.AllSkills.GetEnumerator();
                while (enumerator1.MoveNext())
                {
                    ushort num11 = (ushort) enumerator1.Key;
                    Skill skill1 = (Skill) enumerator1.Value;
                    base.setUpdateValue(num8, skill1.Id);
                    base.setUpdateValue((int) (num8 + 1), (short) skill1.CurrentVal(this));
                    base.setUpdateValue((int) (num8 + 1), (short) skill1.Cap(this));
                    base.setUpdateValue((int) (num8 + 2), 0);
                    num8 += 3;
                }
                base.setUpdateValue(0x3f0, base.Talent);
                if (base.CumulativeAuraEffects[EffectTypes.FindMineral] != null)
                {
                    base.setUpdateValue(0x3f3, (int) base.CumulativeAuraEffects[EffectTypes.FindMineral]);
                }
                base.setUpdateValue(0x3f4, this.BaseBlockChance);
                base.setUpdateValue(0x3f5, this.BaseDodgeChance);
                base.setUpdateValue(0x3f6, this.BaseParryChance);
                base.setUpdateValue(0x3f7, this.BaseCritChance);
                for (int num9 = 0; num9 < 0x20; num9++)
                {
                    base.setUpdateValue((int) (0x3f9 + num9), this.zones[num9]);
                }
                base.setUpdateValue(0x439, 1);
                base.setUpdateValue(0x43a, this.copper);
                base.setUpdateValue(0x43b, this.StrBonusUpdate);
                base.setUpdateValue(0x43c, this.AgBonusUpdate);
                base.setUpdateValue(0x43d, this.StaminaBonusUpdate);
                base.setUpdateValue(0x43e, this.IqBonusUpdate);
                base.setUpdateValue(0x43f, this.SpiritBonusUpdate);
                base.setUpdateValue(0x440, this.StrMalusUpdate);
                base.setUpdateValue(0x441, this.AgMalusUpdate);
                base.setUpdateValue(0x442, this.StaminaMalusUpdate);
                base.setUpdateValue(0x443, this.IqMalusUpdate);
                base.setUpdateValue(0x444, this.SpiritMalusUpdate);
                base.setUpdateValue(0x445, base.ArmorBonusUpdate);
                base.setUpdateValue(0x446, base.ArmorBonusUpdate);
                base.setUpdateValue(0x447, base.HolyResistanceBonusUpdate);
                base.setUpdateValue(0x448, base.FireResistanceBonusUpdate);
                base.setUpdateValue(0x449, base.NatureResistanceBonusUpdate);
                base.setUpdateValue(0x44a, base.FrostResistanceBonusUpdate);
                base.setUpdateValue(0x44b, base.ShadowResistanceBonusUpdate);
                base.setUpdateValue(0x44c, base.ArcaneResistanceBonusUpdate);
                base.setUpdateValue(0x44c, base.ArmorMalusUpdate);
                base.setUpdateValue(0x44d, base.ArmorMalusUpdate);
                base.setUpdateValue(0x44e, base.HolyResistanceMalusUpdate);
                base.setUpdateValue(0x44f, base.FireResistanceMalusUpdate);
                base.setUpdateValue(0x450, base.NatureResistanceMalusUpdate);
                base.setUpdateValue(0x451, base.FrostResistanceMalusUpdate);
                base.setUpdateValue(0x452, base.ShadowResistanceMalusUpdate);
                base.setUpdateValue(0x453, base.ArcaneResistanceMalusUpdate);
                base.setUpdateValue(0x461, (float) 1f);
                base.setUpdateValue(0x469, this.ammoType);
                base.FlushUpdateData(data, ref offset, 0x22);
            }
            else
            {
                base.FlushUpdateData(data, ref offset, 0x22);
            }
        }

        public void PrepareUpdateDataForOther(byte[] data, ref int offset, UpdateType type)
        {
            this.PrepareUpdateData(data, ref offset, type, true, this);
        }

        public void PrepareUpdateDataForOther(byte[] data, ref int offset, UpdateType type, Character f)
        {
            this.PrepareUpdateData(data, ref offset, type, true, f);
        }

        public bool PutObjectInBackpack(Item it)
        {
            return this.PutObjectInBackpack(it, 0, Slots.None, false);
        }

        public bool PutObjectInBackpack(Item it, bool refresh)
        {
            return this.PutObjectInBackpack(it, 0, Slots.None, refresh);
        }

        public bool PutObjectInBackpack(Item it, int n, bool refresh)
        {
            return this.PutObjectInBackpack(it, n, Slots.None, refresh);
        }

        public bool PutObjectInBackpack(Item it, int n, Slots at, bool refresh)
        {
            int[] numArray1;
            bool flag1 = false;
            if ((at == Slots.None) || (base.Items[(int) at] != null))
            {
                flag1 = true;
                at = this.FindAFreeSlot();
            }
            if (at == Slots.None)
            {
                this.InventoryFailed(0x1b);
                return false;
            }
            if ((n == 0) && (it.Stackable > 1))
            {
                it.MaxCount = it.Stackable;
            }
            else
            {
                it.MaxCount = n;
            }
            this.CheckDeliveries(it);
            if (flag1)
            {
                Item[] itemArray1 = base.Items;
                for (int num3 = 0; num3 < itemArray1.Length; num3++)
                {
                    Item item1 = itemArray1[num3];
                    if (((item1 != null) && (item1.Id == it.Id)) && ((item1.MaxCount + it.MaxCount) <= item1.Stackable))
                    {
                        item1.MaxCount += n;
                        if (refresh && (this.account != null))
                        {
                            numArray1 = new int[1] { 14 } ;
                            object[] objArray1 = new object[1] { item1.MaxCount } ;
                            item1.SendTinyUpdate(numArray1, objArray1, this);
                        }
                        return true;
                    }
                }
            }
            base.Items[(int) at] = it;
            if (refresh && (this.account != null))
            {
                int num1 = 0;
                Converter.ToBytes(1, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                it.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, this);
                byte[] buffer1 = Zip.Compress(this.tempBuff, 0, num1);
                byte[] buffer2 = new byte[buffer1.Length + 8];
                Buffer.BlockCopy(buffer1, 0, buffer2, 8, buffer1.Length);
                int num2 = 4;
                Converter.ToBytes(num1, buffer2, ref num2);
                this.account.Handler.Send(0x1f6, buffer2, (int) (buffer1.Length + 6));
                numArray1 = new int[1] { (int) at } ;
                this.ItemsUpdate(numArray1);
            }
            return true;
        }

        public bool QuestCompleted(BaseQuest bq)
        {
            bool flag1 = false;
            if (bq != null)
            {
                ActiveQuest[] questArray1 = this.activeQuests;
                for (int num1 = 0; num1 < questArray1.Length; num1++)
                {
                    ActiveQuest quest1 = questArray1[num1];
                    if ((quest1 != null) && (bq.Id == quest1.Id))
                    {
                        flag1 = quest1.Completed;
                        break;
                    }
                }
            }
            return flag1;
        }

        public bool QuestCompleted(Type t)
        {
            if (t == typeof(BaseQuest))
            {
                return this.QuestCompleted(World.CreateQuestByType(t));
            }
            return false;
        }

        public bool QuestDone(BaseQuest bq)
        {
            //return (this.questsDone[bq.Id] != null);
			if (this.questsDone[bq.Id] == null)
			{
				return false;
			}
			return true;
			//fix
        }

        public bool QuestDone(int id)
        {
            return (this.questsDone[id] != null);
        }

        public bool QuestDone(Type t)
        {
            BaseQuest quest1 = World.CreateQuestByType(t);
			//fix add
			if (quest1 == null)
			{
				Console.WriteLine("Quest {0} is not define as a BaseQuest !", t.Name);
			}
			//
            if (quest1 != null)
            {
                //return this.QuestDone(quest1);
				return (this.questsDone[quest1.Id] != null);
            }
            return false;
        }

        public void QuestFailed(qFailedReason reason)
        {
            int num1 = 4;
            Converter.ToBytes((int) reason, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_QUESTGIVER_QUEST_FAILED, this.tempBuff, num1);
        }

        public void QuestGiverCompleteQuest(ulong guid, int id)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            if (mobile1 != null)
            {
                (mobile1 as BaseCreature).OnChooseQuest(this, id);
            }
        }

        public void QuestGiverHello(ulong guid)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            if (mobile1 == null)
            {
                this.SendMessage("Missing quest giver hello command !!!");
            }
            else
            {
                (mobile1 as BaseCreature).OnHello(this);
            }
        }

        public void QuestInvalid(qInvalidReason reason)
        {
            int num1 = 4;
            Converter.ToBytes((int) reason, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_QUESTGIVER_QUEST_INVALID, this.tempBuff, num1);
        }

        public void QuestList(Mobile m, int id, NpcQuestMenu menu)
        {
            int num1 = 4;
            Converter.ToBytes(m.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(menu.Title, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) menu.Menu.Count, this.tempBuff, ref num1);
            for (int num2 = 0; num2 < menu.Menu.Count; num2++)
            {
                Converter.ToBytes((menu.Quests[num2] as BaseQuest).Id, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(menu.Menu[num2] as string, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_QUESTGIVER_QUEST_LIST, this.tempBuff, num1);
        }

        public void QuestList(Mobile from, string text, qEmote e, BaseQuest[] quests)
        {
            int num1 = 4;
            Converter.ToBytes(from.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(text, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(e.Delay, this.tempBuff, ref num1);
            Converter.ToBytes((int) e.emote, this.tempBuff, ref num1);
            Converter.ToBytes((byte) quests.Length, this.tempBuff, ref num1);
            BaseQuest[] questArray1 = quests;
            for (int num3 = 0; num3 < questArray1.Length; num3++)
            {
                BaseQuest quest1 = questArray1[num3];
                Converter.ToBytes(quest1.Id, this.tempBuff, ref num1);
                int num2 = this.HaveQuest(quest1) ? 3 : 5;
                Converter.ToBytes(num2, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.Name, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_QUESTGIVER_QUEST_LIST, this.tempBuff, num1);
        }

        public void QuestLogIsFull()
        {
            this.Send(OpCodes.SMSG_QUESTLOG_FULL, this.tempBuff, 4);
        }

        public void QuestQuery(int id)
        {
            int num1 = 4;
            BaseQuest quest1 = World.CreateQuestById(id);
            if (quest1 != null)
            {
                Converter.ToBytes(quest1.Id, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.MinLevel, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.IdealLevel, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.Zone, this.tempBuff, ref num1);
                Converter.ToBytes((int) quest1.QuestType, this.tempBuff, ref num1);
                if (quest1.Faction1 != null)
                {
                    FactionLimit limit1 = quest1.Faction1;
                    Converter.ToBytes(limit1.Faction, this.tempBuff, ref num1);
                    Converter.ToBytes(limit1.Reputation, this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes((uint) 0, this.tempBuff, ref num1);
                    Converter.ToBytes((uint) 0, this.tempBuff, ref num1);
                }
                if (quest1.Faction2 != null)
                {
                    FactionLimit limit2 = quest1.Faction2;
                    Converter.ToBytes(limit2.Faction, this.tempBuff, ref num1);
                    Converter.ToBytes(limit2.Reputation, this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes((uint) 0, this.tempBuff, ref num1);
                    Converter.ToBytes((uint) 0, this.tempBuff, ref num1);
                }
                Converter.ToBytes(quest1.NextQuest, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.RewardGold, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.RewardSpell, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.SourceItemId, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.QuestFlags, this.tempBuff, ref num1);
                Reward[] rewardArray1 = quest1.Reward.Items;
                for (int num2 = 0; num2 < 4; num2++)
                {
                    if (quest1.HasReward() && (rewardArray1.Length > num2))
                    {
                        Reward reward1 = rewardArray1[num2];
                        Converter.ToBytes(reward1.Id, this.tempBuff, ref num1);
                        Converter.ToBytes(reward1.Amount, this.tempBuff, ref num1);
                    }
                    else
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                    }
                }
                Reward[] rewardArray2 = quest1.RewardChoice.Items;
                for (int num3 = 0; num3 < 6; num3++)
                {
                    if (quest1.HasRewardChoice() && (rewardArray2.Length > num3))
                    {
                        Reward reward2 = rewardArray2[num3];
                        Converter.ToBytes(reward2.Id, this.tempBuff, ref num1);
                        Converter.ToBytes(reward2.Amount, this.tempBuff, ref num1);
                    }
                    else
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                    }
                }
                if (quest1.MiniMapPos != null)
                {
                    Position position1 = quest1.MiniMapPos;
                    Converter.ToBytes(position1.MapId, this.tempBuff, ref num1);
                    Converter.ToBytes(position1.X, this.tempBuff, ref num1);
                    Converter.ToBytes(position1.Y, this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes(0, this.tempBuff, ref num1);
                    Converter.ToBytes((float) 0f, this.tempBuff, ref num1);
                    Converter.ToBytes((float) 0f, this.tempBuff, ref num1);
                }
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.Name, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.Desc, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.Details, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                Converter.ToBytes(quest1.Details2, this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                string[] textArray2 = new string[4] { "", "", "", "" } ;
                string[] textArray1 = textArray2;
                NPCObjective[] objectiveArray1 = quest1.NPCObjectives.Items;
                DeliveryObjective[] objectiveArray2 = quest1.DeliveryObjectives.Items;
                for (int num4 = 0; num4 < 4; num4++)
                {
                    if (quest1.HaveNPCObj && (objectiveArray1.Length > num4))
                    {
                        NPCObjective objective1 = objectiveArray1[num4];
                        textArray1[num4] = objective1.Descr;
                        Converter.ToBytes(objective1.Id, this.tempBuff, ref num1);
                        Converter.ToBytes(objective1.Amount, this.tempBuff, ref num1);
                    }
                    else
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                    }
                    if (quest1.HaveDeliveryObj && (objectiveArray2.Length > num4))
                    {
                        DeliveryObjective objective2 = objectiveArray2[num4];
                        Converter.ToBytes(objective2.Id, this.tempBuff, ref num1);
                        Converter.ToBytes(objective2.Amount, this.tempBuff, ref num1);
                    }
                    else
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                    }
                }
                if (textArray1[0].Length > 0)
                {
                    Converter.ToBytes(textArray1[0], this.tempBuff, ref num1);
                }
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                if (textArray1[1].Length > 0)
                {
                    Converter.ToBytes(textArray1[1], this.tempBuff, ref num1);
                }
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                if (textArray1[2].Length > 0)
                {
                    Converter.ToBytes(textArray1[2], this.tempBuff, ref num1);
                }
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                if (textArray1[3].Length > 0)
                {
                    Converter.ToBytes(textArray1[3], this.tempBuff, ref num1);
                }
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                this.Send(OpCodes.SMSG_QUEST_QUERY_RESPONSE, this.tempBuff, num1);
            }
        }

        public void QuestQueryForCreature(ulong guidFrom, int questId)
        {
            Mobile mobile1 = this.Player.FindMobileByGuid(guidFrom);
            if ((mobile1 != null) && (mobile1 is BaseCreature))
            {
                (mobile1 as BaseCreature).OnChooseQuest(this, questId);
            }
        }

        public void QuestStatus(ulong guid)
        {
            int num1 = 4;
            Converter.ToBytes(guid, this.tempBuff, ref num1);
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            if ((mobile1 != null) && (mobile1 is BaseCreature))
            {
                BaseCreature creature1 = (BaseCreature) mobile1;
                DialogStatus status1 = creature1.OnDialogStatus(this);
                Converter.ToBytes((int) status1, this.tempBuff, ref num1);
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_QUESTGIVER_STATUS, this.tempBuff, num1);
        }

        public void QuestUpdateComplete(BaseQuest bq)
        {
            int num1 = 4;
            Converter.ToBytes(bq.Id, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_QUESTUPDATE_COMPLETE, this.tempBuff, num1);
        }

        public void QuestUpdateFailed(BaseQuest bq)
        {
            int num1 = 4;
            Converter.ToBytes(bq.Id, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_QUESTUPDATE_FAILED, this.tempBuff, num1);
        }

        public void QuestUpdateFailedTimer(BaseQuest bq)
        {
            int num1 = 4;
            Converter.ToBytes(bq.Id, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_QUESTUPDATE_FAILEDTIMER, this.tempBuff, num1);
        }

        public void QuitGroup()
        {
            if (this.group != null)
            {
                this.group.Quit(this);
                this.group = null;
            }
        }

        private Item RealSlot(int from, ref int ex)
        {
            if (from >= 40)
            {
                ex = (from - 40) % 0x10;
                return base.Items[0x13 + ((from - 40) / 0x10)];
            }
            return null;
        }

        public int RealXp(int amount, int qlevel)
        {
            float single1 = 0f;
            int num1 = qlevel;
            int num2 = base.Level;
            if (num1 < (num2 - 6))
            {
                single1 = 0.05f;
            }
            else if (num1 == (num2 - 6))
            {
                single1 = 0.1f;
            }
            else if (num1 == (num2 - 5))
            {
                single1 = 0.25f;
            }
            else if (num1 == (num2 - 4))
            {
                single1 = 0.3333f;
            }
            else if (num1 == (num2 - 3))
            {
                single1 = 0.5f;
            }
            else if (num1 == (num2 - 2))
            {
                single1 = 0.6666f;
            }
            else if (num1 == (num2 - 1))
            {
                single1 = 0.75f;
            }
            else if (num1 == num2)
            {
                single1 = 1f;
            }
            else
            {
                single1 = 1.1f;
            }
            return (int) (amount * single1);
        }

        public void ReclaimCorps()
        {
            Character.onCharacterReclaimCorps(this);
            Mobile mobile1 = this.account.FindMobileByGuid(this.corpsGuid);
            base.HitPoints = base.BaseHitPoints / 10;
            base.Mana = base.BaseHitPoints / 10;
            if (mobile1 != null)
            {
                mobile1.Delete();
                World.allMobiles.Remove(mobile1);
                this.account.HeartBeat();
            }
            object[] objArray1 = new object[9] { base.BaseHitPoints / 10, 0, 0x1008, 0, 0, 0, 0xdddddddd, 2, 0 } ;
            this.SendSmallUpdateToPlayerNearMe(new int[9] { 0x16, 0x17, 0x2e, 0x4f, 0x6f, 0x79, 0x7f, 0x83, 180 } , objArray1);
            byte[] buffer1 = new byte[11];
            this.Send(OpCodes.CMSG_CHANNEL_SET_OWNER, buffer1, 11);
        }

        public void ReleaseLoot()
        {
            Server.Object obj1 = this.FindObjectByGuid(this.lootOwner);
            if (obj1 is GameObject)
            {
                GameObject obj2 = obj1 as GameObject;
                if (obj2.OnRelease(this) && (obj2.SpawnerLink != null))
                {
                    obj2.SpawnerLink.Release(obj2);
                }
            }
            this.lootOwner = 0;
            if (this.previousSpellCasted != 0)
            {
                this.cast.id = this.previousSpellCasted;
                this.SpellFaillure(SpellFailedReason.Failed);
                this.previousSpellCasted = 0;
            }
        }

        public void ReleaseTrade()
        {
            this.TradeState = 0;
            for (int num1 = 0; num1 < this.tradeItems.Length; num1++)
            {
                this.tradeItems[num1] = -1;
            }
            this.tradingWith = null;
        }

        public void RemoveQuest(byte i)
        {
            int num1 = (i * 3) + 0xbc;
            this.activeQuests[i] = null;
            int[] numArray1 = new int[3] { num1, num1 + 1, num1 + 2 } ;
            object[] objArray1 = new object[3] { 0, 0, 0 } ;
            this.SendSmallUpdate(numArray1, objArray1);
        }

        public void ResponseMessage(Mobile m, int id)
        {
            if (this._gossipOpened)
            {
                this.EndGossip();
            }
            int num1 = 4;
            Converter.ToBytes(m.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(id, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_GOSSIP_MESSAGE, this.tempBuff, num1);
            (m as BaseCreature).npcMenuId = id;
        }

        public void ResponseMessage(Mobile m, int id, NpcMenu menu)
        {
            if (this._gossipOpened)
            {
                this.EndGossip();
            }
            int num1 = 4;
            Converter.ToBytes(m.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(id, this.tempBuff, ref num1);
            Converter.ToBytes(menu.Menu.Count, this.tempBuff, ref num1);
            for (int num2 = 0; num2 < menu.Menu.Count; num2++)
            {
                Converter.ToBytes(num2, this.tempBuff, ref num1);
                Converter.ToBytes((short) menu.Icon[num2], this.tempBuff, ref num1);
                Converter.ToBytes(menu.Menu[num2], this.tempBuff, ref num1);
                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            }
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_GOSSIP_MESSAGE, this.tempBuff, num1);
            (m as BaseCreature).npcMenuId = id;
        }

        public void ResponseMessage(Mobile m, int id, string str)
        {
            this.ResponseMessage(m, id, 0, str);
        }

        public void ResponseMessage(Mobile m, int id, int icon, string str)
        {
            if (this._gossipOpened)
            {
                this.EndGossip();
            }
            (m as BaseCreature).npcMenuId = id;
            int num1 = 4;
            Converter.ToBytes(m.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(id, this.tempBuff, ref num1);
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes((short) icon, this.tempBuff, ref num1);
            Converter.ToBytes(str, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_GOSSIP_MESSAGE, this.tempBuff, num1);
        }

        public void ResponseQuestComplete(Mobile m, int id, string title, string text)
        {
            int num1 = 4;
            Converter.ToBytes(m.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(text, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(id, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(title, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_QUESTGIVER_QUEST_DETAILS, this.tempBuff, num1);
        }

        public void ResponseQuestDetails(Mobile m, int questId, string title, string desc, string details)
        {
            this.ResponseQuestDetails(m, questId, title, desc, details, null);
        }

        public void ResponseQuestDetails(Mobile m, int questId, string title, string desc, string details, qEmote[] emoteList)
        {
            BaseQuest quest1 = World.CreateQuestById(questId);
            int num1 = 4;
            Converter.ToBytes(m.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(questId, this.tempBuff, ref num1);
            Converter.ToBytes(title, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(desc, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(details, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(1, this.tempBuff, ref num1);
            if (quest1.HasRewardChoice())
            {
                Reward[] rewardArray1 = quest1.RewardChoice.Items;
                Converter.ToBytes(rewardArray1.Length, this.tempBuff, ref num1);
                for (int num2 = 0; num2 < rewardArray1.Length; num2++)
                {
                    Reward reward1 = rewardArray1[num2];
                    Converter.ToBytes(reward1.Id, this.tempBuff, ref num1);
                    Converter.ToBytes(reward1.Amount, this.tempBuff, ref num1);
                    Converter.ToBytes(reward1.Model, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            if (quest1.HasReward())
            {
                Reward[] rewardArray2 = quest1.Reward.Items;
                Converter.ToBytes(rewardArray2.Length, this.tempBuff, ref num1);
                for (int num3 = 0; num3 < rewardArray2.Length; num3++)
                {
                    Reward reward2 = rewardArray2[num3];
                    Converter.ToBytes(reward2.Id, this.tempBuff, ref num1);
                    Converter.ToBytes(reward2.Amount, this.tempBuff, ref num1);
                    Converter.ToBytes(reward2.Model, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            Converter.ToBytes(quest1.RewardGold, this.tempBuff, ref num1);
            Converter.ToBytes(quest1.RewardSpell, this.tempBuff, ref num1);
            if (emoteList != null)
            {
                Converter.ToBytes(emoteList.Length, this.tempBuff, ref num1);
                for (int num4 = 0; num4 < emoteList.Length; num4++)
                {
                    qEmote emote1 = emoteList[num4];
                    Converter.ToBytes(emote1.Delay, this.tempBuff, ref num1);
                    Converter.ToBytes((int) emote1.emote, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_QUESTGIVER_QUEST_DETAILS, this.tempBuff, num1);
        }

        public static string SecondParam(string str)
        {
            string[] textArray1 = str.Split(new char[10] { '\t', '(', ')', ' ', '\'', ':', '"', '-', '/', '\\' } );
            if (textArray1.Length > 1)
            {
                return textArray1[1];
            }
            return "";
        }

        public bool SeeAnyLoot(Mobile killedBy, Item[] treasure)
        {
            if (killedBy == this)
            {
                if (killedBy.LootMoney > 0)
                {
                    return true;
                }
                Item[] itemArray1 = treasure;
                for (int num2 = 0; num2 < itemArray1.Length; num2++)
                {
                    Item item1 = itemArray1[num2];
                    if ((item1 != null) && item1.IsQuestItem)
                    {
                        bool flag1 = false;
                        for (int num1 = 0; num1 < 20; num1++)
                        {
                            if (((this.activeQuests[num1] != null) && this.activeQuests[num1].HaveDeliveryObj) && this.activeQuests[num1].NeedItem(item1))
                            {
                                return true;
                            }
                        }
                        if (!flag1)
                        {
                        }
                    }
                    else
                    {
                        return true;
                    }
                }
            }
            return false;
        }

        public void Sell(ulong to, ulong obj)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(to);
            if (mobile1 != null)
            {
                if (mobile1 is BaseCreature)
                {
                    (mobile1 as BaseCreature).SpeakingFrom = DateTime.Now;
                    (mobile1 as BaseCreature).AIState = AIStates.Speaking;
                }
                for (int num1 = 0; num1 < base.Items.Length; num1++)
                {
                    Item item1 = base.Items[num1];
                    if ((item1 != null) && (item1.Guid == obj))
                    {
                        if (item1.IsQuestItem)
                        {
                            this.InventoryFailed(0x23, obj);
                            return;
                        }
                        this.Copper += ((uint) (item1.SellPrice * item1.MaxCount));
                        this.DestroyItem((Slots) num1, true);
                        int[] numArray1 = new int[1] { 0x43a } ;
                        object[] objArray1 = new object[1] { this.Copper } ;
                        this.SendSmallUpdate(numArray1, objArray1);
                        return;
                    }
                }
            }
        }

        public void Send(byte[] b)
        {
            this.account.Handler.Send(b);
        }

        public void Send(OpCodes op, byte[] b)
        {
            this.account.Handler.Send(op, b, b.Length);
        }

        public void Send(OpCodes op, byte[] b, int len)
        {
            this.account.Handler.Send(op, b, len);
        }

        public void SendAllActionButtons()
        {
            int num1 = 4;
            foreach (Action action1 in this.actionBar)
            {
                Converter.ToBytes(action1.action, this.tempBuff, ref num1);
                Converter.ToBytes(action1.type, this.tempBuff, ref num1);
                Converter.ToBytes(action1.other, this.tempBuff, ref num1);
            }
            //this.account.Handler.Send(OpCodes.SMSG_ACTION_BUTTONS, this.tempBuff, 0x1e4);
			this.account.Handler.Send(OpCodes.SMSG_ACTION_BUTTONS, this.tempBuff,num1);//fix ����������޸�
        }
		
        public void SendAllItems()
        {
            Item[] itemArray1 = base.Items;
            for (int num2 = 0; num2 < itemArray1.Length; num2++)
            {
                Item item1 = itemArray1[num2];
                if (item1 != null)
                {
                    int num1 = 4;
                    item1.PrepareData(this.tempBuff, ref num1);
                    this.Player.Handler.Send(0x58, this.tempBuff, num1);
                }
            }
        }

        public void SendAllSpells()
        {
            int num1 = 4;
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes((short) base.KnownAbilities.Count, this.tempBuff, ref num1);
            IDictionaryEnumerator enumerator1 = base.KnownAbilities.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                int num2 = (int) enumerator1.Key;
                Converter.ToBytes(num2, this.tempBuff, ref num1);
            }
            this.account.Handler.Send(OpCodes.SMSG_INITIAL_SPELLS, this.tempBuff, num1);
        }

        public void SendDuelArbitrer(ulong g)
        {
            int num1 = 4;
            if (this.guowner == this)
            {
                this.MakeThePacket(g, this.gu, this.guowner);
                Converter.ToBytes(g, this.tempBuff, ref num1);
                this.Send(OpCodes.SMSG_GAMEOBJECT_SPAWN_ANIM, this.tempBuff, num1);
                this.gu.MakeThePacket(g, this.guowner, this.gu);
                num1 = 4;
                Converter.ToBytes(g, this.tempBuff, ref num1);
                this.gu.Send(OpCodes.SMSG_GAMEOBJECT_SPAWN_ANIM, this.tempBuff, num1);
            }
            if (this.guowner != this)
            {
                num1 = 4;
                Converter.ToBytes(0xbb8, this.tempBuff, ref num1);
                this.Send(OpCodes.SMSG_PET_BROKEN | OpCodes.CMSG_LEARN_SPELL, this.tempBuff, num1);
                this.guowner.Send(OpCodes.SMSG_PET_BROKEN | OpCodes.CMSG_LEARN_SPELL, this.tempBuff, num1);
                this.dt = new DuelTimer(this.guowner, this, g);
            }
        }

        public void SendFriendList()
        {
            int num1 = 4;
            Converter.ToBytes(this.friends.Count, this.tempBuff, ref num1);
            foreach (Character character1 in this.friends)
            {
                Converter.ToBytes(character1.Guid, this.tempBuff, ref num1);
                if ((character1.Player != null) && character1.Player.realylogged)
                {
                    Converter.ToBytes((byte) 2, this.tempBuff, ref num1);
                    Converter.ToBytes(character1.ZoneId, this.tempBuff, ref num1);
                    Converter.ToBytes(character1.Level, this.tempBuff, ref num1);
                    Converter.ToBytes((int) character1.Classe, this.tempBuff, ref num1);
                    continue;
                }
                Converter.ToBytes((byte) 3, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_FRIEND_LIST, this.tempBuff, num1);
        }

        public void SendGossip(Mobile from, int textId, GMenu gMenu, GQMenu gqMenu)
        {
            if (this._gossipOpened)
            {
                this.EndGossip();
            }
            int num1 = 4;
            Converter.ToBytes(from.Guid, this.tempBuff, ref num1);
            Converter.ToBytes((uint) textId, this.tempBuff, ref num1);
            if ((gMenu != null) && (gMenu.Count > 0))
            {
                Converter.ToBytes(gMenu.Count, this.tempBuff, ref num1);
                GMenuItem[] itemArray1 = gMenu.Items;
                for (int num2 = 0; num2 < itemArray1.Length; num2++)
                {
                    GMenuItem item1 = itemArray1[num2];
                    Converter.ToBytes(item1.MenuId, this.tempBuff, ref num1);
                    Converter.ToBytes(item1.Icon, this.tempBuff, ref num1);
                    Converter.ToBytes(item1.InputBox, this.tempBuff, ref num1);
                    Converter.ToBytes(item1.Text, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            if ((gqMenu != null) && (gqMenu.Count > 0))
            {
                Converter.ToBytes(gqMenu.Count, this.tempBuff, ref num1);
                GQMenuItem[] itemArray2 = gqMenu.Items;
                for (int num3 = 0; num3 < itemArray2.Length; num3++)
                {
                    GQMenuItem item2 = itemArray2[num3];
                    Converter.ToBytes(item2.MenuId, this.tempBuff, ref num1);
                    Converter.ToBytes(item2.Icon, this.tempBuff, ref num1);
                    Converter.ToBytes((uint) 0, this.tempBuff, ref num1);
                    Converter.ToBytes(item2.Text, this.tempBuff, ref num1);
                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                }
            }
            else
            {
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_GOSSIP_MESSAGE, this.tempBuff, num1);
            (from as BaseCreature).npcMenuId = textId;
        }

        public void SendItem(int id, ulong guid)
        {
            int num1 = 4;
            Item item1 = null;
            if (guid > 0xf000000000000000)
            {
                Mobile mobile1 = this.account.FindMobileByGuid(guid);
                item1 = mobile1.FindItemById(id);
            }
            else if ((guid & 0x4000000000000000) != 0)
            {
                item1 = this.FindItemByGuid(guid);
                if (item1 == null)
                {
                    foreach (Character character1 in this.Player.PlayersNear)
                    {
                        item1 = character1.FindItemByGuid(guid);
                        if (item1 != null)
                        {
                            break;
                        }
                    }
                }
            }
            else if ((guid & 0xb000000000000000) == 0xb000000000000000)
            {
                item1 = World.CreateItemInPoolById(id);
            }
            else if ((guid & 0xa000000000000000) != 0)
            {
                item1 = this.FindItemInGameObjectById(guid, id);
            }
            else
            {
                item1 = this.FindItemById(id);
            }
            if (item1 == null)
            {
                if (id == 0x1fe4)
                {
                    item1 = new TestStationeryFake();
                    item1.Guid = 0;
                }
                else if (id == 0x245f)
                {
                    item1 = new DefaultStationeryFake();
                    item1.Guid = 0;
                }
                else if (id == 0x46ea)
                {
                    item1 = new BlizzardStationeryFake();
                    item1.Guid = 0;
                }
                else
                {
                    item1 = World.CreateItemInPoolById(id);
                }
            }
            if (item1 == null)
            {
                item1 = new BlizzardStationeryFake();
                item1.Guid = 0;
            }
            item1.PrepareData(this.tempBuff, ref num1);
            this.Player.Handler.Send(0x58, this.tempBuff, num1);
        }

        public void SendLootDetails(ulong gu, Server.Object lootTarget, int lootMoney)
        {
            this.currentObjectLooted = lootTarget;
            int num1 = 4;
            Converter.ToBytes(gu, this.tempBuff, ref num1);
            if ((this.currentObjectLooted.Treasure.Length == 0) && (lootMoney <= 0))
            {
                Converter.ToBytes(2, this.tempBuff, ref num1);
                Converter.ToBytes((short) 0, this.tempBuff, ref num1);
                this.Send(OpCodes.SMSG_LOOT_RESPONSE, this.tempBuff, num1);
            }
            else
            {
                if (lootMoney > 0)
                {
                    Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                    Converter.ToBytes(lootMoney, this.tempBuff, ref num1);
                }
                else
                {
                    Converter.ToBytes((byte) 2, this.tempBuff, ref num1);
                    Converter.ToBytes(0, this.tempBuff, ref num1);
                }
                if (this.currentObjectLooted.Treasure.Length > 0)
                {
                    Converter.ToBytes((byte) this.currentObjectLooted.Treasure.Length, this.tempBuff, ref num1);
                    int num2 = 0;
                    Item[] itemArray1 = this.currentObjectLooted.Treasure;
                    for (int num4 = 0; num4 < itemArray1.Length; num4++)
                    {
                        Item item1 = itemArray1[num4];
                        if (item1 != null)
                        {
                            if (item1.IsQuestItem)
                            {
                                bool flag1 = false;
                                for (int num3 = 0; num3 < 20; num3++)
                                {
                                    if (((this.activeQuests[num3] != null) && this.activeQuests[num3].HaveDeliveryObj) && this.activeQuests[num3].NeedItem(item1))
                                    {
                                        flag1 = true;
                                        break;
                                    }
                                }
                                if (flag1)
                                {
                                    Converter.ToBytes((byte) num2++, this.tempBuff, ref num1);
                                    Converter.ToBytes(item1.Id, this.tempBuff, ref num1);
                                    Converter.ToBytes(item1.MaxCount, this.tempBuff, ref num1);
                                    Converter.ToBytes(item1.Model, this.tempBuff, ref num1);
                                    Converter.ToBytes(0, this.tempBuff, ref num1);
                                    Converter.ToBytes(0, this.tempBuff, ref num1);
                                    Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                                }
                                else
                                {
                                    num2++;
                                }
                            }
                            else
                            {
                                Converter.ToBytes((byte) num2++, this.tempBuff, ref num1);
                                Converter.ToBytes(item1.Id, this.tempBuff, ref num1);
                                Converter.ToBytes(item1.MaxCount, this.tempBuff, ref num1);
                                Converter.ToBytes(item1.Model, this.tempBuff, ref num1);
                                Converter.ToBytes(0, this.tempBuff, ref num1);
                                Converter.ToBytes(0, this.tempBuff, ref num1);
                                Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                            }
                        }
                        else
                        {
                            Converter.ToBytes((byte) num2++, this.tempBuff, ref num1);
                            Converter.ToBytes(0, this.tempBuff, ref num1);
                            Converter.ToBytes(0, this.tempBuff, ref num1);
                            Converter.ToBytes(0, this.tempBuff, ref num1);
                            Converter.ToBytes(0, this.tempBuff, ref num1);
                            Converter.ToBytes(0, this.tempBuff, ref num1);
                            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        }
                    }
                }
                this.Send(OpCodes.SMSG_LOOT_RESPONSE, this.tempBuff, num1);
            }
        }

        public void SendMessage(string cmd)
        {
            int num1 = 4;
            Converter.ToBytes(10, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes((int) (cmd.Length + 1), this.tempBuff, ref num1);
            Converter.ToBytes(cmd, this.tempBuff, ref num1);
            Converter.ToBytes((short) 0, this.tempBuff, ref num1);
            this.Player.Handler.Send(150, this.tempBuff, num1);
        }

        private void SendMessageTo(Character c, string txt, int langue)
        {
            this.SendMessageTo(c, ChatMsgType.CHAT_MSG_SAY, txt, langue);
        }

        private void SendMessageTo(Character c, ChatMsgType chat, string txt, int langue)
        {
            int num1 = 4;
            bool flag1 = false;
            switch (langue)
            {
                case 1:
                {
                    if (c.HaveSkill(0x6d))
                    {
                        flag1 = true;
                    }
                    break;
                }
                case 2:
                {
                    if (c.HaveSkill(0x71))
                    {
                        flag1 = true;
                    }
                    break;
                }
                case 3:
                {
                    if (c.HaveSkill(0x73))
                    {
                        flag1 = true;
                    }
                    break;
                }
                case 6:
                {
                    if (c.HaveSkill(0x6f))
                    {
                        flag1 = true;
                    }
                    break;
                }
                case 7:
                {
                    if (c.HaveSkill(0x62))
                    {
                        flag1 = true;
                    }
                    break;
                }
                case 13:
                {
                    if (c.HaveSkill(0x139))
                    {
                        flag1 = true;
                    }
                    break;
                }
                case 14:
                {
                    if (c.HaveSkill(0x13b))
                    {
                        flag1 = true;
                    }
                    break;
                }
                case 0x21:
                {
                    if (c.HaveSkill(0x2a1))
                    {
                        flag1 = true;
                    }
                    break;
                }
            }
            if (flag1)
            {
                this.tempBuff[num1++] = (byte) chat;
                Converter.ToBytes(langue, this.tempBuff, ref num1);
            }
            else
            {
                this.tempBuff[num1++] = (byte) chat;
                Converter.ToBytes(langue, this.tempBuff, ref num1);
            }
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes((int) (txt.Length + 1), this.tempBuff, ref num1);
            Converter.ToBytes(txt, this.tempBuff, ref num1);
            Converter.ToBytes((short) 1, this.tempBuff, ref num1);
            int num2 = num1;
            c.Send(OpCodes.SMSG_MESSAGECHAT, this.tempBuff, num2);
        }

        public void SendName(ulong guid)
        {
            Character character1 = null;
            if (guid == base.Guid)
            {
                character1 = this;
            }
            else
            {
                character1 = this.account.FindPlayerNearByGuid(guid);
            }
            if (character1 != null)
            {
                byte[] buffer1 = new byte[((12 + character1.Name.Length) + 1) + 12];
                int num1 = 4;
                Converter.ToBytes(character1.Guid, buffer1, ref num1);
                Converter.ToBytes(character1.Name, buffer1, ref num1);
                Converter.ToBytes((byte) 0, buffer1, ref num1);
                Converter.ToBytes((int) character1.Race, buffer1, ref num1);
                Converter.ToBytes(character1.Gender, buffer1, ref num1);
                Converter.ToBytes((int) character1.Classe, buffer1, ref num1);
                this.Send(OpCodes.SMSG_NAME_QUERY_RESPONSE, buffer1);
            }
        }

        public void SendPetActionBar()
        {
            if (this.petActions == null)
            {
                this.petActions = new int[11] { 0, 0x2000000, 0x3000000, 0x4000000, 0x5000000, 0x6000000, 0x6000001, 0x6000002, 0x7000000, 0x7000001, 0x7000002 } ;
            }
            int num1 = 4;
            Converter.ToBytes(base.Summon.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(0x257, this.tempBuff, ref num1);
            int[] numArray1 = this.petActions;
            for (int num4 = 0; num4 < numArray1.Length; num4++)
            {
                int num2 = numArray1[num4];
                Converter.ToBytes(num2, this.tempBuff, ref num1);
            }
            Converter.ToBytes((byte) base.Summon.KnownAbilities.Count, this.tempBuff, ref num1);
            IDictionaryEnumerator enumerator1 = base.Summon.KnownAbilities.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                int num3 = (int) enumerator1.Key;
                Converter.ToBytes((ushort) num3, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_PET_SPELLS, this.tempBuff, num1);
        }

        public void SendSkillUpdate()//����������������������л����ħ�������з�С���Ա����o���ֵ���㡣
        {
            int[] numArray1 = new int[base.AllSkills.Count * 3];
            object[] objArray1 = new object[base.AllSkills.Count * 3];
            int num1 = 0x270;
            int num2 = 0;
            IDictionaryEnumerator enumerator1 = base.AllSkills.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                ushort num3 = (ushort) enumerator1.Key;
                Skill skill1 = (Skill) enumerator1.Value;
                numArray1[num2] = num1;
                //objArray1[num2] = skill1.Id;
				objArray1[num2] = (int)skill1.Id;
                num1++;
                num2++;
                numArray1[num2] = num1;
                //objArray1[num2] = skill1.CurrentVal(this) + (skill1.Cap(this) << 0x10);
				objArray1[num2] = skill1.CurrentVal(this) + ((skill1.Cap(this)+skill1.CurrentBonus(this)) << 0x10);
                num1++;
                num2++;
                numArray1[num2] = num1;
                objArray1[num2] = 0;
                num1++;
                num2++;
            }
            this.SendSmallUpdate(numArray1, objArray1);
        }

        public override void SendSmallUpdate(int[] pos, object[] val)
        {
            int num1 = 4;
            this.tempBuff[num1++] = 1;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.tempBuff[num1++] = 0;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            int num2 = 2 + ((pos[pos.Length - 1] + 1) / 0x20);
            if (num2 > 0x24)
            {
                num2 = 0x24;
            }
            this.tempBuff[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank, 0, this.tempBuff, num1, Server.Object.Blank.Length);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer1;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer1 = this.tempBuff)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer1[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public void SendSmallUpdateFor(ulong g, int[] pos, object[] val)
        {
            int num1 = 4;
            this.tempBuff[num1++] = 1;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.tempBuff[num1++] = 0;
            Converter.ToBytes(g, this.tempBuff, ref num1);
            int num2 = 2 + ((pos[pos.Length - 1] + 1) / 0x20);
            if (num2 > 0x24)
            {
                num2 = 0x24;
            }
            this.tempBuff[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank, 0, this.tempBuff, num1, Server.Object.Blank.Length);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer1;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer1 = this.tempBuff)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer1[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public override void SendSmallUpdateToPlayerNearMe(int[] pos, object[] val)
        {
            this.SendSmallUpdateToPlayerNearMe(base.Guid, pos, val);
        }

        public override void SendSmallUpdateToPlayerNearMe(ulong guid, int[] pos, object[] val)
        {
            int num1 = 4;
            this.tempBuff[num1++] = 1;
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.tempBuff[num1++] = 0;
            Converter.ToBytes(guid, this.tempBuff, ref num1);
            int num2 = 2 + (pos[pos.Length - 1] / 0x20);
            if (num2 > 0x24)
            {
                num2 = 0x24;
            }
            this.tempBuff[num1++] = (byte) num2;
            Buffer.BlockCopy(Server.Object.Blank, 0, this.tempBuff, num1, num2 * 4);
            int[] numArray1 = pos;
            int num7 = 0;
            while (num7 < numArray1.Length)
            {
                byte[] buffer1;
                IntPtr ptr1;
                int num3 = numArray1[num7];
                int num4 = num3;
                int num5 = num4 >> 3;
                int num6 = num4 & 7;
                num6 = 1 << (num6 & 0x1f);
                (buffer1 = this.tempBuff)[(int) (ptr1 = (IntPtr) (num1 + num5))] = (byte) (buffer1[(int) ptr1] + ((byte) num6));
                num7++;
            }
            num1 += (num2 * 4);
            object[] objArray1 = val;
            for (num7 = 0; num7 < objArray1.Length; num7++)
            {
                object obj1 = objArray1[num7];
                Converter.ToBytes(obj1, this.tempBuff, ref num1);
            }
            this.account.ToAllPlayerNear(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
        }

        public override void Serialize(GenericWriter gw)
        {
            base.Serialize(gw);
            //gw.Write(7);
			gw.Write(6);
            /*gw.Write(this.reputationAdjustments.Count);
            IDictionaryEnumerator enumerator1 = this.reputationAdjustments.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                gw.Write((int) enumerator1.Key);
                gw.Write((int) enumerator1.Value);
            }*/
            gw.Write(this.actionBar.Count);
            foreach (Action action1 in this.actionBar)
            {
                action1.Serialize(gw);
            }
            gw.Write(this.friends.Count);
            foreach (Character character1 in this.friends)
            {
                gw.Write(character1.Guid);
                if (character1.Player == null)
                {
                    Account account1 = World.FindPlayerAccountByCharacterGUID(character1.Guid);
                    if (account1 == null)
                    {
                        gw.Write("Unknown");
                        continue;
                    }
                    gw.Write(account1.Username);
                    continue;
                }
                gw.Write(character1.Player.Username);
            }
            gw.Write(this.BindingPointX);
            gw.Write(this.BindingPointY);
            gw.Write(this.BindingPointZ);
            gw.Write(this.BindingPointMapId);
            if (this.petActions != null)
            {
                gw.Write(true);
                for (int num1 = 0; num1 < 11; num1++)
                {
                    gw.Write(this.petActions[num1]);
                }
            }
            else
            {
                gw.Write(false);
            }
            if (base.Summon != null)
            {
                gw.Write(1);
                gw.Write(base.Summon.Guid);
            }
            else
            {
                gw.Write(0);
            }
            if (base.Charm != null)
            {
                gw.Write(1);
                gw.Write(base.Charm.Guid);
            }
            else
            {
                gw.Write(0);
            }
            gw.Write(this.CorpseLocationX);
            gw.Write(this.CorpseLocationY);
            gw.Write(this.CorpseLocationZ);
            gw.Write(this.CorpseMapId);
            gw.Write(this.corpsGuid);
            for (int num2 = 0; num2 < 0x20; num2++)
            {
                gw.Write(this.zones[num2]);
            }
            if (this.mark == null)
            {
                gw.Write(0);
            }
            else
            {
                gw.Write(1);
                gw.Write(this.mark.X);
                gw.Write(this.mark.Y);
                gw.Write(this.mark.Z);
                gw.Write(this.mark.MapId);
            }
            gw.Write(this.ammoType);
            gw.Write((byte) this.race);
            gw.Write(this.gender);
            gw.Write(this.skin);
            gw.Write(this.face);
            gw.Write(this.hairStyle);
            gw.Write(this.hairColour);
            gw.Write(this.facialHair);
            gw.Write(this.copper);
            ActiveQuest[] questArray1 = this.activeQuests;
            for (int num5 = 0; num5 < questArray1.Length; num5++)
            {
                ActiveQuest quest1 = questArray1[num5];
                if (quest1 == null)
                {
                    gw.Write(0);
                }
                else
                {
                    gw.Write(1);
                    quest1.Serialisation(gw);
                }
            }
            gw.Write(this.questsDone.Count);
            IDictionaryEnumerator enumerator2 = this.questsDone.GetEnumerator();
            while (enumerator2.MoveNext())
            {
                int num3 = (int) enumerator2.Key;
                gw.Write(num3);
            }
            for (int num4 = 0; num4 < 8; num4++)
            {
                gw.Write(this.TaxiField[num4]);
            }
        }

        public void SetAmmo(int id)
        {
            int[] numArray1;
            object[] objArray1;
            if (id == 0)
            {
                if (this.ammoType != 0)
                {
                    this.ammoType = id;
                    numArray1 = new int[1] { 0x469 } ;
                    objArray1 = new object[1] { 0 } ;
                    this.SendSmallUpdate(numArray1, objArray1);
                }
            }
            else
            {
                Item item1 = World.CreateItemInPoolById(id);
                if (item1.ReqLevel > base.Level)
                {
                    this.InventoryFailed(1, (ulong) item1.ReqLevel);
                }
                else
                {
                    this.ammoType = id;
                    numArray1 = new int[1] { 0x469 } ;
                    objArray1 = new object[1] { id } ;
                    this.SendSmallUpdate(numArray1, objArray1);
                }
            }
        }

        public void SetLootMethod(int method)
        {
        }

        public void SetPetAction(ulong guid, int pos, uint id)
        {
            this.petActions[pos] = (int) id;
        }

        public void SetPetAction(ulong guid, uint a, uint b, uint c, uint d)
        {
            this.petActions[(int) ((IntPtr) a)] = (int) b;
            this.petActions[(int) ((IntPtr) c)] = (int) d;
        }

        public void SetQuestDone(BaseQuest bq)
        {
            this.SetQuestDone(bq, null);
        }

        public void SetQuestDone(Type t)
        {
            if (t == typeof(BaseQuest))
            {
                BaseQuest quest1 = World.CreateQuestByType(t);
                if (quest1 != null)
                {
                    this.SetQuestDone(quest1);
                }
            }
        }

        public void SetQuestDone(BaseQuest bq, Reward[] rewards)
        {
            int num1 = 0;
            ActiveQuest[] questArray1 = this.activeQuests;
            for (int num4 = 0; num4 < questArray1.Length; num4++)
            {
                ActiveQuest quest1 = questArray1[num4];
                if ((quest1 != null) && (bq.Id == quest1.Id))
                {
                    quest1.Done = true;
                    if (bq.Repeatable)
                    {
                        this.questsDone[quest1.Id] = null;
                    }
                    else
                    {
                        this.questsDone[quest1.Id] = true;
                    }
                    this.QuestUpdateComplete(bq);
                    int num2 = 4;
                    Converter.ToBytes(quest1.Id, this.tempBuff, ref num2);
                    Converter.ToBytes(0, this.tempBuff, ref num2);
                    Converter.ToBytes(bq.RewardXp, this.tempBuff, ref num2);
                    Converter.ToBytes(bq.RewardGold, this.tempBuff, ref num2);
                    if (rewards != null)
                    {
                        Converter.ToBytes(rewards.Length, this.tempBuff, ref num2);
                        for (int num3 = 0; num3 < rewards.Length; num3++)
                        {
                            Reward reward1 = rewards[num3];
                            Converter.ToBytes(reward1.Id, this.tempBuff, ref num2);
                            Converter.ToBytes(reward1.Amount, this.tempBuff, ref num2);
                        }
                    }
                    else
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num2);
                    }
                    this.Send(OpCodes.SMSG_QUESTGIVER_QUEST_COMPLETE, this.tempBuff, num2);
                    this.RemoveQuest((byte) num1);
                    return;
                }
                num1++;
            }
        }

        public void SetSelection(ulong guid)
        {
            if (guid < 0xf100000000000000)
            {
                this.selection = this.account.FindMobileByGuid(guid);
            }
            this.selection = this.account.FindObjectByGuid(guid);
        }

        public void ShowMobileInventory(ulong guid)
        {
            foreach (Server.Object obj1 in this.account.KnownObjects)
            {
                if (!(obj1 is Mobile))
                {
                    continue;
                }
                Mobile mobile1 = obj1 as Mobile;
                if (mobile1.Guid == guid)
                {
                    if (mobile1 is BaseCreature)
                    {
                        (mobile1 as BaseCreature).SpeakingFrom = DateTime.Now;
                        (mobile1 as BaseCreature).AIState = AIStates.Speaking;
                    }
                    int num1 = mobile1.ShowInventory(this.tempBuff, this);
                    this.account.Handler.Send(OpCodes.SMSG_LIST_INVENTORY, this.tempBuff, num1);
                    return;
                }
            }
        }

        public void SpawnerQuery(ulong guid, int id)
        {
            int num1 = 4;
            Converter.ToBytes(id, this.tempBuff, ref num1);
            Converter.ToBytes("Spawner", this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_CREATURE_QUERY_RESPONSE, this.tempBuff, num1);
        }

        public void SpiritHealerResurect(ulong guid)
        {
            int num1 = 4;
            Converter.ToBytes(guid, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_SPIRIT_HEALER_CONFIRM, this.tempBuff, num1);
        }

        public void StopAttacking()
        {
            if (this.firstHitCombatTimer != null)
            {
                this.firstHitCombatTimer.Stop();
                this.firstHitCombatTimer = null;
            }
            if (this.combatTimer != null)
            {
                this.combatTimer.Stop();
                this.combatTimer = null;
            }
            if (base.AttackTarget != null)
            {
                int num1 = 4;
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                Converter.ToBytes(base.AttackTarget.Guid, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                this.account.ToAllPlayerNear(OpCodes.SMSG_ATTACKSTOP, this.tempBuff, num1);
                base.AttackTarget = null;
            }
        }

        public void SwapInv(Slots from, Slots to)
        {
            if (base.AttackTarget != null)
            {
                this.StopAttacking();
            }
            if (base.Dead)
            {
                if ((to != Slots.None) && (from != Slots.None))
                {
                    Item item1 = base.Items[(int) to];
                    Item item2 = base.Items[(int) from];
                    if ((item1 != null) && (item2 != null))
                    {
                        this.InventoryFailed(0x24, item1.Guid, item2.Guid);
                    }
                    else if (item1 != null)
                    {
                        this.InventoryFailed(0x24, item1.Guid);
                    }
                    else
                    {
                        this.InventoryFailed(0x24, item2.Guid);
                    }
                }
                else if ((to != Slots.None) && (from == Slots.None))
                {
                    Item item3 = base.Items[(int) to];
                    if (item3 != null)
                    {
                        this.InventoryFailed(0x24, item3.Guid);
                    }
                }
                else if ((to == Slots.None) && (from != Slots.None))
                {
                    Item item4 = base.Items[(int) from];
                    if (item4 != null)
                    {
                        this.InventoryFailed(0x24, item4.Guid);
                    }
                }
            }
            else
            {
                int[] numArray1;
                if (base.Items[(int) to] != null)
                {
                    Item item5 = base.Items[(int) to];
                    Item item6 = base.Items[(int) from];
                    if ((to > Slots.Tabard) && (to < Slots.Bag5))
                    {
                        //int num1 = (int) (((Slots) 40) + ((to - Slots.Bag1) * Slots.OffHand));
						int num1 = (int) (((Slots) 40) + ((to - Slots.Bag1) * (int)Slots.OffHand));//fix
                        for (int num2 = num1; num2 < (num1 + 0x10); num2++)
                        {
                            if (base.Items[num2] != null)
                            {
                                this.InventoryFailed(30, item5.Guid, item6.Guid);
                                return;
                            }
                        }
                    }
                    if ((from > Slots.Tabard) && (from < Slots.Bag5))
                    {
                        //int num3 = (int) (((Slots) 40) + ((from - Slots.Bag1) * Slots.OffHand));
						int num3 = (int) (((Slots) 40) + ((from - Slots.Bag1) * (int)Slots.OffHand));
                        for (int num4 = num3; num4 < (num3 + 0x10); num4++)
                        {
                            if (base.Items[num4] != null)
                            {
                                this.InventoryFailed(30, item5.Guid, item6.Guid);
                                return;
                            }
                        }
                    }
                    if ((to >= Slots.Bag1) || this.CanEquip(item6, item5))
                    {
                        if ((from < Slots.Bag1) && !this.CanEquip(item5, item6))
                        {
                            return;
                        }
                        if (item5.Id == item6.Id)
                        {
                            object[] objArray1;
                            if ((item5.MaxCount + item6.MaxCount) <= item5.Stackable)
                            {
                                item5.MaxCount += item6.MaxCount;
                                numArray1 = new int[1] { 14 } ;
                                objArray1 = new object[1] { item5.MaxCount } ;
                                item5.SendTinyUpdate(numArray1, objArray1, this);
                                this.DestroyItem(from, true);
                                return;
                            }
                            if (item5.MaxCount < item5.Stackable)
                            {
                                int num5 = item5.Stackable - item5.MaxCount;
                                item5.MaxCount = item5.Stackable;
                                item6.MaxCount -= num5;
                                numArray1 = new int[1] { 14 } ;
                                objArray1 = new object[1] { item5.MaxCount } ;
                                item5.SendTinyUpdate(numArray1, objArray1, this);
                                numArray1 = new int[1] { 14 } ;
                                objArray1 = new object[1] { item6.MaxCount } ;
                                item6.SendTinyUpdate(numArray1, objArray1, this);
                            }
                            else
                            {
                                base.Items[(int) to] = item6;
                                base.Items[(int) from] = item5;
                            }
                        }
                        else
                        {
                            base.Items[(int) to] = item6;
                            base.Items[(int) from] = item5;
                        }
                        numArray1 = new int[2] { (int) from, (int) to } ;
                        this.ItemsUpdate(numArray1);
                        if ((to < Slots.Bag1) || (from < Slots.Bag1))
                        {
                            foreach (Character character1 in this.account.PlayersNear)
                            {
                                if (character1.Player.PlayersNear.Contains(this))
                                {
                                    this.ItemsUpdateForOther(character1.Player.Handler);
                                }
                            }
                        }
                    }
                }
                else
                {
                    if ((from > Slots.Tabard) && (from < Slots.Bag5))
                    {
                        //int num6 = (int) (((Slots) 40) + ((from - Slots.Bag1) * Slots.OffHand));
						int num6 = (int) (((Slots) 40) + ((from - Slots.Bag1) * (int)Slots.OffHand));//fix
                        for (int num7 = num6; num7 < (num6 + 0x10); num7++)
                        {
                            if (base.Items[num7] != null)
                            {
                                this.InventoryFailed(30, base.Items[(int) from].Guid);
                                return;
                            }
                        }
                    }
                    if ((from >= Slots.Bag1) || this.CanEquip(base.Items[(int) from]))
                    {
                        if (to < Slots.Bag1)
                        {
                            Item item7 = base.Items[(int) from];
                            if (((to == Slots.OffHand) && item7.IsWeapon) && !this.HaveSpell(0x2a2))
                            {
                                this.InventoryFailed(7, item7.Guid);
                                return;
                            }
                            if (item7 != null)
                            {
                                if (((to == Slots.OffHand) && item7.IsWeapon) && !this.HaveSpell(0x2a2))
                                {
                                    this.InventoryFailed(7, item7.Guid);
                                    return;
                                }
                                if (!this.CanEquip(item7))
                                {
                                    return;
                                }
                            }
                        }
                        base.Items[(int) to] = base.Items[(int) from];
                        this.DestroyItem(from, false);
                        numArray1 = new int[2] { (int) from, (int) to } ;
                        this.ItemsUpdate(numArray1);
                        if ((to < Slots.Bag1) || (from < Slots.Bag1))
                        {
                            foreach (Character character2 in this.account.PlayersNear)
                            {
                                if (character2.Player.PlayersNear.Contains(this))
                                {
                                    this.ItemsUpdateForOther(character2.Player.Handler);
                                }
                            }
                        }
                    }
                }
            }
        }

        public void SwapItem(byte to1, byte to2, byte from1, byte from2)
        {
            Slots slots1;
            Slots slots2;
            if (to1 == 0xff)
            {
                slots1 = (Slots) to2;
            }
            else
            {
                slots1 = (Slots) (((to2 + 0x18) + 0x10) + ((to1 - 0x13) * 0x10));
            }
            if (from1 == 0xff)
            {
                slots2 = (Slots) from2;
            }
            else
            {
                slots2 = (Slots) (((from2 + 0x18) + 0x10) + ((from1 - 0x13) * 0x10));
            }
            this.SwapInv(slots2, slots1);
        }

        public void SwitchManatypeToEnergy()
        {
            base.ManaType = 3;
            int[] numArray1 = new int[3] { 0x1a, 0x20, 0x24 } ;
            object[] objArray2 = new object[3] { base.Energy, base.BaseEnergy, (((int) (this.Race | ((Races) (((int) base.Classe) << 8)))) | (this.Gender << 0x10)) | 0x3000000 } ;
            object[] objArray1 = objArray2;
            base.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public void SwitchManatypeToMana()
        {
            base.ManaType = 0;
            int[] numArray1 = new int[3] { 0x17, 0x1d, 0x24 } ;
            object[] objArray2 = new object[3] { base.Mana, base.BaseMana, ((int) (this.Race | ((Races) (((int) base.Classe) << 8)))) | (this.Gender << 0x10) } ;
            object[] objArray1 = objArray2;
            base.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public void SwitchManatypeToRage()
        {
            base.ManaType = 1;
            int[] numArray1 = new int[3] { 0x18, 30, 0x24 } ;
            object[] objArray2 = new object[3] { base.Rage, base.BaseRage, (((int) (this.Race | ((Races) (((int) base.Classe) << 8)))) | (this.Gender << 0x10)) | 0x1000000 } ;
            object[] objArray1 = objArray2;
            base.SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
        }

        public void Teleport(float x, float y, float z)
        {
            if (!this.deadEndTeleportLoop)
            {
                this.deadEndTeleportLoop = true;
                this.X = x;
                this.Y = y;
                this.Z = z;
                int num1 = 4;
                Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
                Converter.ToBytes((ulong) 0, this.tempBuff, ref num1);
                Converter.ToBytes(this.X, this.tempBuff, ref num1);
                Converter.ToBytes(this.Y, this.tempBuff, ref num1);
                Converter.ToBytes(this.Z, this.tempBuff, ref num1);
                Converter.ToBytes(base.Orientation, this.tempBuff, ref num1);
                this.account.ToAllPlayerNear(OpCodes.MSG_MOVE_TELEPORT, this.tempBuff, num1);
                base.ForcePosition(x, y, z, base.Orientation);
            }
        }

        public void Teleport(float x, float y, float z, int mapid)
        {
            if (!this.deadEndTeleportLoop)
            {
                if (base.MapId == mapid)
                {
                    this.Teleport(x, y, z);
                }
                else
                {
                    this.deadEndTeleportLoop = true;
                    this.pendingTeleportX = x;
                    this.pendingTeleportY = y;
                    this.pendingTeleportZ = z;
                    this.pendingTeleportO = base.Orientation;
                    this.pendingTeleportMapId = mapid;
                    int num1 = 4;
                    Converter.ToBytes((uint) 0, this.tempBuff, ref num1);
                    this.Send(OpCodes.SMSG_TRANSFER_PENDING, this.tempBuff, num1);
                    num1 = 4;
                    Converter.ToBytes(mapid, this.tempBuff, ref num1);
                    Converter.ToBytes(x, this.tempBuff, ref num1);
                    Converter.ToBytes(y, this.tempBuff, ref num1);
                    Converter.ToBytes(z, this.tempBuff, ref num1);
                    Converter.ToBytes(base.Orientation, this.tempBuff, ref num1);
                    this.Send(OpCodes.SMSG_NEW_WORLD, this.tempBuff, num1);
                }
            }
        }

        public void TeleportAck()
        {
            this.Player.justLogged = true;
            base.MapId = (ushort) this.pendingTeleportMapId;
            this.X = this.pendingTeleportX;
            this.Y = this.pendingTeleportY;
            this.Z = this.pendingTeleportZ;
            base.Orientation = this.pendingTeleportO;
            int num1 = 4;
            Converter.ToBytes(1, this.tempBuff, ref num1);
            Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
            this.PrepareUpdateData(this.tempBuff, ref num1, UpdateType.UpdateFull, false);
            this.Send(OpCodes.SMSG_UPDATE_OBJECT, this.tempBuff, num1);
            this.ItemsUpdate();
            this.lastAreaTrigger = DateTime.Now;
        }

        public static string ThirdParam(string str)
        {
            string[] textArray1 = str.Split(new char[10] { '\t', '(', ')', ' ', '\'', ':', '"', '-', '/', '\\' } );
            if (textArray1.Length > 2)
            {
                return textArray1[2];
            }
            return "";
        }

        public override void ToAllPlayerNear(OpCodes code, byte[] data)
        {
            this.account.ToAllPlayerNear(code, data);
        }

        public override void ToAllPlayerNear(OpCodes code, byte[] data, int len)
        {
            this.account.ToAllPlayerNear(code, data, len);
        }

        public override void ToAllPlayerNear(OpCodes code, byte[] data, int after, int len)
        {
            this.account.ToAllPlayerNear(code, data, after, len);
        }

        public override void ToAllPlayerNearExceptMe(OpCodes code, byte[] data, int len)
        {
            this.account.ToAllPlayerNearExceptMe(code, data, len);
        }

        public override void ToAllPlayerNearExceptMe(OpCodes code, byte[] data, int after, int len)
        {
            this.account.ToAllPlayerNearExceptMe(code, data, after, len);
        }

        public void toData(ref byte[] data, ref int t)
        {
            uint num16;
            char[] chArray1 = base.Name.ToCharArray();
            byte[] buffer1 = BitConverter.GetBytes(base.Guid);
            byte[] buffer2 = buffer1;
            int num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num1 = buffer2[num14];
                data[t++] = num1;
                num14++;
            }
            char[] chArray2 = chArray1;
            num14 = 0;
            while (num14 < chArray2.Length)
            {
                char ch1 = chArray2[num14];
                data[t++] = (byte) ch1;
                num14++;
            }
            data[t++] = 0;
            data[t++] = (byte) this.race;
            data[t++] = (byte) base.Classe;
            data[t++] = this.gender;
            data[t++] = this.skin;
            data[t++] = this.face;
            data[t++] = this.hairStyle;
            data[t++] = this.hairColour;
            data[t++] = this.facialHair;
            data[t++] = (byte) base.Level;
           // buffer1 = BitConverter.GetBytes((uint) base.ZoneId);
			buffer1 = BitConverter.GetBytes((int) base.ZoneId);//fix ����ѡ��
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num2 = buffer2[num14];
                data[t++] = num2;
                num14++;
            }
            //buffer1 = BitConverter.GetBytes(base.MapId);
			buffer1 = BitConverter.GetBytes((int)base.MapId);//fix ����ѡ��
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num3 = buffer2[num14];
                data[t++] = num3;
                num14++;
            }
            buffer1 = BitConverter.GetBytes(this.X);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num4 = buffer2[num14];
                data[t++] = num4;
                num14++;
            }
            buffer1 = BitConverter.GetBytes(this.Y);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num5 = buffer2[num14];
                data[t++] = num5;
                num14++;
            }
            buffer1 = BitConverter.GetBytes(this.Z);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num6 = buffer2[num14];
                data[t++] = num6;
                num14++;
            }
            buffer1 = BitConverter.GetBytes(base.GuildId);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num7 = buffer2[num14];
                data[t++] = num7;
                num14++;
            }
            data[t++] = 2;
            base.PetDisplayId = num16 = 1;
            buffer1 = BitConverter.GetBytes(num16);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num8 = buffer2[num14];
                data[t++] = num8;
                num14++;
            }
            buffer1 = BitConverter.GetBytes(base.PetLevel);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num9 = buffer2[num14];
                data[t++] = num9;
                num14++;
            }
            buffer1 = BitConverter.GetBytes(base.PetCreatureFamily);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num10 = buffer2[num14];
                data[t++] = num10;
                num14++;
            }
            buffer1 = BitConverter.GetBytes(0);
            buffer2 = buffer1;
            num14 = 0;
            while (num14 < buffer2.Length)
            {
                byte num11 = buffer2[num14];
                data[t++] = num11;
                num14++;
            }
            for (int num12 = 0; num12 < 20; num12++)
            {
                if (base.Items[num12] != null)
                {
                    buffer1 = BitConverter.GetBytes(base.Items[num12].Model);
                    buffer2 = buffer1;
                    for (num14 = 0; num14 < buffer2.Length; num14++)
                    {
                        byte num13 = buffer2[num14];
                        data[t++] = num13;
                    }
                    data[t++] = (byte) base.Items[num12].InventoryType;
                }
                else
                {
                    data[t++] = 0;
                    data[t++] = 0;
                    data[t++] = 0;
                    data[t++] = 0;
                    data[t++] = 0;
                }
            }
        }

        public void TradeGold(int amount)
        {
            if (this.tradingWith == null)
            {
                this.CancelTrade();
            }
            else
            {
                this.tradeGold = amount;
                this.TradeUpdate();
            }
        }

        public void TradeItem(int num, Slots from)
        {
            this.tradeItems[num] = (int) from;
            this.TradeUpdate();
        }

        private void TradeUpdate()
        {
            if (this.tradingWith != null)
            {
                int num1 = 4;
                Converter.ToBytes((byte) 1, this.tempBuff, ref num1);
                Converter.ToBytes(this.tradeNum, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(this.tradeGold, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                for (int num2 = 0; num2 < 7; num2++)
                {
                    Converter.ToBytes((byte) num2, this.tempBuff, ref num1);
                    int num3 = this.tradeItems[num2];
                    if (num3 == -1)
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                    }
                    else
                    {
                        Converter.ToBytes(base.Items[num3].Id, this.tempBuff, ref num1);
                    }
                    Converter.ToBytes(0, this.tempBuff, ref num1);
                    if (num3 == -1)
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                    }
                    else
                    {
                        Converter.ToBytes(base.Items[num3].MaxCount, this.tempBuff, ref num1);
                    }
                    for (int num4 = 0; num4 < 12; num4++)
                    {
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                    }
                }
                this.tradingWith.Send(OpCodes.SMSG_TRADE_STATUS_EXTENDED, this.tempBuff, num1);
            }
        }

        public void TrainAbility(int ab)
        {
            int[] numArray1 = new int[1] { ab } ;
            base.TrainAbility(numArray1);
        }

        public void TrainerBuy(ulong guid, int id)
        {
            if (this.castTrainerSpell == null)
            {
                Mobile mobile1 = this.account.FindMobileByGuid(guid);
                if (mobile1 != null)
                {
                    if (mobile1 is BaseCreature)
                    {
                        (mobile1 as BaseCreature).SpeakingFrom = DateTime.Now;
                        (mobile1 as BaseCreature).AIState = AIStates.Speaking;
                    }
                    int[] numArray1 = mobile1.Trains;
                    for (int num2 = 0; num2 < numArray1.Length; num2++)
                    {
                        int num1 = numArray1[num2];
                        if (num1 == id)
                        {
                            BaseAbility ability1 = Abilities.abilities[id];
                            if (ability1 is Teach)
                            {
                                Teach teach1 = (Teach) Abilities.abilities[id];
                                if (teach1 != null)
                                {
                                    this.castTrainerSpell = new CastTrainerSpell(teach1, this, mobile1);
                                }
                            }
                            else if (ability1 is Ability)
                            {
                                this.castTrainerSpell = new CastTrainerSpell(ability1, this, mobile1);
                            }
                        }
                    }
                }
            }
        }

        public void TrainerBuyAck(BaseAbility teach)
        {
            if (this.OnTrainningAck())
            {
                int[] numArray1;
                object[] objArray1;
                int num1 = 0;
                if (teach is Teach)
                {
                    this.LearnSpell(num1 = (teach as Teach).TeachId);
                }
                else
                {
                    this.LearnSpell(num1 = teach.Id);
                }
                this.castTrainerSpell = null;
                BaseAbility ability1 = null;
                if (teach is Teach)
                {
                    ability1 = Abilities.abilities[(teach as Teach).TeachId];
                }
                else
                {
                    ability1 = teach;
                }
                ArrayList list1 = (ArrayList) CustomSpellHandlers.spellAddons[num1];
                if ((list1 != null) && (list1.Count > 0))
                {
                    foreach (int num2 in list1)
                    {
                        this.LearnSpell(num2);
                    }
                }
                int num3 = 0;
                if (Character.onSpellPrice != null)
                {
                    num3 = Character.onSpellPrice(this, num1);
                }
                if (num3 == 0)
                {
                    num3 = CustomSpellHandlers.SpellCost(num1);
                }
                this.Copper -= ((uint) num3);
                if (ability1 is Profession)
                {
                    Profession profession1 = (Profession) ability1;
                    if (Character.onLearn != null)
                    {
                        if (Character.onLearn(this, profession1.Level, profession1.ProfessionType))
                        {
                            profession1.OnLearn(this);
                        }
                    }
                    else
                    {
                        profession1.OnLearn(this);
                    }
                    Skill skill1 = base.AllSkills[profession1.Id];
                    if (skill1 != null)
                    {
                        int num4 = skill1.Index;
                        skill1 = profession1.Clone(skill1.Current, (ushort) num4);
                        base.AllSkills[profession1.Id] = skill1;
                        numArray1 = new int[4] { num4, num4 + 1, num4 + 2, 0x43a } ;
                        objArray1 = new object[5] { (int) skill1.Id, (short) skill1.CurrentVal(this), (short) skill1.Cap(this), 0, this.Copper } ;
                        this.SendSmallUpdate(numArray1, objArray1);
                    }
                    else
                    {
                        int num5 = Profession.Slots(base.nProfessions);
                        base.nProfessions = (byte) (base.nProfessions + 1);
                        base.AllSkills[profession1.Id] = skill1 = profession1.Clone(1, (ushort) num5);
                        numArray1 = new int[4] { num5, num5 + 1, num5 + 2, 0x43a } ;
                        objArray1 = new object[5] { (int) skill1.Id, (short) skill1.CurrentVal(this), (short) skill1.Cap(this), 0, this.Copper } ;
                        this.SendSmallUpdate(numArray1, objArray1);
                    }
                }
                else
                {
                    numArray1 = new int[1] { 0x43a } ;
                    objArray1 = new object[1] { this.Copper } ;
                    this.SendSmallUpdate(numArray1, objArray1);
                }
            }
        }

        public void TrainerList(ulong guid)
        {
            Mobile mobile1 = this.account.FindMobileByGuid(guid);
            if ((mobile1 != null) && (mobile1.Trains != null))
            {
                if (mobile1 is BaseCreature)
                {
                    (mobile1 as BaseCreature).SpeakingFrom = DateTime.Now;
                    (mobile1 as BaseCreature).AIState = AIStates.Speaking;
                }
                int num1 = 4;
                Converter.ToBytes(guid, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
                Converter.ToBytes(mobile1.Trains.Length, this.tempBuff, ref num1);
                int num2 = 0;
                int[] numArray1 = mobile1.Trains;
                for (int num5 = 0; num5 < numArray1.Length; num5++)
                {
                    int num3 = numArray1[num5];
                    if (Abilities.abilities[num3] is Teach)
                    {
                        this.PrepareTrainerListTeach(num3, ref num1, Abilities.abilities[num3] as Teach);
                        num2++;
                    }
                    else if (Abilities.abilities[num3] is CraftTemplate)
                    {
                        CraftTemplate template1 = (CraftTemplate) Abilities.abilities[num3];
                        Converter.ToBytes((ushort) num3, this.tempBuff, ref num1);
                        Converter.ToBytes(0x1000000, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        num2++;
                    }
                    else if (Abilities.abilities[num3] is Ability)
                    {
                        Ability ability1 = (Ability) Abilities.abilities[num3];
                        Converter.ToBytes((ushort) num3, this.tempBuff, ref num1);
                        Converter.ToBytes(0x1000000, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes((byte) 0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        Converter.ToBytes(0, this.tempBuff, ref num1);
                        num2++;
                    }
                }
                int num4 = num1;
                num1 = 0x10;
                Converter.ToBytes(num2, this.tempBuff, ref num1);
                this.account.Handler.Send(OpCodes.SMSG_TRAINER_LIST, this.tempBuff, num4);
            }
        }

        public void UnacceptTrade()
        {
            this.TradeState = 9;
            if (this.tradingWith != null)
            {
                int num1 = 4;
                if (this.tradingWith.TradeState == 9)
                {
                    this.tradingWith.ReleaseTrade();
                    this.ReleaseTrade();
                }
                num1 = 4;
                Converter.ToBytes(4, this.tempBuff, ref num1);
                this.tradingWith.Send(OpCodes.SMSG_TRADE_STATUS, this.tempBuff, num1);
            }
        }

        public override void UnLearnSpell(int id)
        {
            int num1 = 4;
            Converter.ToBytes((ushort) id, this.tempBuff, ref num1);
            this.Send(OpCodes.SMSG_REMOVED_SPELL, this.tempBuff, num1);
            base.UnLearnSpell(id);
        }

        public void UnMount()
        {
            this.OnUnMount(null);
        }

        public void UpdateRunSpeed()
        {
            int num1 = 4;
            Converter.ToBytes(base.Guid, this.tempBuff, ref num1);
            Converter.ToBytes(base.RunSpeed, this.tempBuff, ref num1);
            this.ToAllPlayerNear(OpCodes.SMSG_FORCE_RUN_SPEED_CHANGE, this.tempBuff, num1);
        }

        public void UseItem(byte a, int slot)
        {
            if (slot <= base.Items.Length)
            {
                Item item1 = base.Items[slot];
                if (item1 != null)
                {
                    for (int num1 = 0; num1 < 5; num1++)
                    {
                        Item.SpecialAbility ability1 = item1.Spells(num1);
                        if (ability1 != null)
                        {
                            if (ability1.Trigger == 0)
                            {
                                BaseAbility ability2 = Abilities.abilities[ability1.Spell.Id];
                                if (ability2 is SpellTemplate)
                                {
                                    SpellTemplate template1 = (SpellTemplate) ability2;
                                    this.cast.castingtime = template1.CastingTime(this);
                                    this.cast.cool = template1.CoolDown(this);
                                    this.cast.id = template1.Id;
                                    this.cast.manacost = template1.GetManaCost(this);
                                    this.cast.type = 0;
                                    this.cast.baseability = template1;
                                }
                                else
                                {
                                    this.cast.castingtime = ability2.CastingTime(this);
                                    this.cast.cool = ability2.CoolDown(this);
                                    this.cast.id = ability2.Id;
                                    this.cast.manacost = 0;
                                    this.cast.type = 0;
                                    this.cast.baseability = ability2;
                                }
                            }
                            int num2 = 4;
                            Converter.ToBytes(Server.Object.GUID, this.tempBuff, ref num2);
                            Converter.ToBytes(this.cast.id, this.tempBuff, ref num2);
                            this.Send(OpCodes.SMSG_ITEM_COOLDOWN, this.tempBuff, num2);
                            this.SpellExecutionStart(this.cast, this, true);
                            if ((item1.ObjectClass == 0) && (item1.SubClass == 0))
                            {
                                this.ConsumeItemByIdUpTo(item1.Id, 1);
                            }
                        }
                    }
                }
            }
        }

        public void WhoIsRequest()
        {
            int num1 = 4;
            Converter.ToBytes(World.allConnectedChars.Count, this.tempBuff, ref num1);
            Converter.ToBytes(0, this.tempBuff, ref num1);
            foreach (Character character1 in World.allConnectedChars)
            {
                Converter.ToBytes(character1.Name, this.tempBuff, ref num1);
                Converter.ToBytes((short) 0, this.tempBuff, ref num1);
                Converter.ToBytes(character1.Level, this.tempBuff, ref num1);
                Converter.ToBytes((int) character1.Classe, this.tempBuff, ref num1);
                Converter.ToBytes((int) character1.Race, this.tempBuff, ref num1);
                Converter.ToBytes(character1.ZoneId, this.tempBuff, ref num1);
                Converter.ToBytes(0, this.tempBuff, ref num1);
            }
            this.Send(OpCodes.SMSG_WHO, this.tempBuff, num1);
        }

        public void ZoneUpdateRequested(int z)
        {
            int num1 = base.ZoneId;
            base.ZoneId = World.mapZones.NearestZoneId(this);
            if (base.ZoneId != num1)
            {
                this.Player.RefreshMobileList(true);
            }
            if (base.ZoneId != 0)
            {
                z = (int) World.zoneIds[base.ZoneId];
                int num2 = z % 0x20;
                int num3 = z / 0x20;
                if (num3 > 0x1f)
                {
                    Console.WriteLine("Strange zone {0}", z);
                }
                else if ((this.zones[num3] & (1 << (num2 & 0x1f))) == 0)
                {
                    uint[] numArray1;
                    IntPtr ptr1;
                    if (base.ZoneId != ((int) World.zones[base.ZoneId]))
                    {
                        int num4 = 4;
                        Converter.ToBytes(base.ZoneId, this.tempBuff, ref num4);
                        Converter.ToBytes(100, this.tempBuff, ref num4);
                        this.Send(OpCodes.SMSG_EXPLORATION_EXPERIENCE, this.tempBuff, num4);
                        this.EarnXP(100);
                    }
                    (numArray1 = this.zones)[(int) (ptr1 = (IntPtr) num3)] = numArray1[(int) ptr1] | ((uint) (1 << (num2 & 0x1f)));
                    int[] numArray2 = new int[1] { 0x3f9 + num3 } ;
                    object[] objArray1 = new object[1] { this.zones[num3] } ;
                    this.SendSmallUpdate(numArray2, objArray1);
                }
            }
        }


        // Properties
        public AccessLevels AccountLevel
        {
            get
            {
                return this.account.AccessLevel;
            }
        }

        public ArrayList ActionBar
        {
            get
            {
                return this.actionBar;
            }
        }

        public int AgBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Agility - ((int) base.BaseAgility);
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int AgMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Agility - ((int) base.BaseAgility);
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public int AmmoType
        {
            get
            {
                return this.ammoType;
            }
        }

        public uint Appearance
        {
            get
            {
                int num1 = ((this.skin << ((0x18 + this.face) & 0x1f)) << ((0x10 + this.hairStyle) & 0x1f)) << ((8 + this.hairColour) & 0x1f);
                return (uint) num1;
            }
        }

        public float BaseBlockChance
        {
            get
            {
                //float single1 = 0f; //fix del
                Skill skill1 = base.AllSkills[(ushort) DefenseSkill.SkillId];
                return (float) (5 - (((base.Level * 5) - skill1.CurrentVal(this)) * 0.04));
            }
        }

        public float BaseCritChance
        {
            get
            {
                float single2;
                try
                {
                    float single1 = 0f;
                    Item item1 = this.activeWeapon;
                    if (item1 == null)
                    {
                        Item item2;
                        this.activeWeapon = item2 = this.ChooseWeapon();
                        item1 = item2;
                    }
                    if (base.Classe == Classes.Warrior)
                    {
                        single1 = 5f;
                        if (base.Level > 9)
                        {
                            if (base.HaveTalent(Talents.PolearmSpecialization) && (item1.SubClass == 6))
                            {
                                AuraEffect effect1 = (AuraEffect) base.GetTalentEffect(Talents.PolearmSpecialization);
                                single1 += effect1.S1;
                            }
                            if (base.HaveTalent(Talents.Cruelty) && (item1.ObjectClass == 2))
                            {
                                AuraEffect effect2 = (AuraEffect) base.GetTalentEffect(Talents.Cruelty);
                                single1 += effect2.S1;
                            }
                        }
                    }
                    else
                    {
                        single1 = 5f;
                    }
                    int num1 = item1.GetSkillId();
                    Skill skill1 = base.AllSkills[(ushort) num1];
                    single2 = single1 -= (float) (0.04 * (skill1.Cap(this) - skill1.CurrentVal(this)));
                }
                catch
                {
                    single2 = 0f;
                }
                return single2;
            }
        }

        public float BaseDodgeChance
        {
            get
            {
                //float single1 = 5f; //fix del
                Skill skill1 = base.AllSkills[(ushort) DefenseSkill.SkillId];
                if (base.Classe == Classes.Rogue)
                {
                    return (float) ((((double) base.Agility) / (1.15 + (base.BaseAgility / 20f))) - (((base.Level * 5) - skill1.CurrentVal(this)) * 0.04));
                }
                return (float) (5 - (((base.Level * 5) - skill1.CurrentVal(this)) * 0.04));
            }
        }

        public float BaseMaxDamage
        {
            get
            {
                int num1 = 0;
                float single1 = 0f;
                if (this.activeWeapon != null)
                {
                    single1 += (((this.activeWeapon.PhysicalMaxDamage + (((((float) base.AttackPower) / 14f) * base.AttackSpeed) / 1000f)) + base.MeleeDamageBonus) - base.MeleeDamageMalus);
                }
                single1 *= (1f + ((base.MeleePercentDamageBonus - base.MeleePercentDamageMalus) / 100f));
                return (single1 * (1f + (((float) num1) / 100f)));
            }
        }

        public float BaseMinDamage
        {
            get
            {
                int num1 = 0;
                float single1 = 0f;
                if (this.activeWeapon != null)
                {
                    single1 += (((((this.activeWeapon.PhysicalMinDamage + (((((float) base.AttackPower) / 14f) * base.AttackSpeed) / 1000f)) + base.MeleeDamageBonus) - base.MeleeDamageMalus) + base.AllDamageDoneBonus) - base.AllDamageDoneMalus);
                }
                single1 *= (1f + ((base.MeleePercentDamageBonus - base.MeleePercentDamageMalus) / 100f));
                return (single1 * (1f + (((float) num1) / 100f)));
            }
        }

        public float BaseModDamage
        {
            get
            {
                int num1 = 0;
                float single1 = 1f;
                if (this.activeWeapon != null)
                {
                    single1 *= (((1f + ((base.MeleePercentDamageBonus - base.MeleePercentDamageMalus) / 100f)) + base.AllDamageDoneBonus) - base.AllDamageDoneMalus);
                }
                return (single1 * ((1f + (((float) num1) / 100f)) * base.AllDamageDoneModifier));
            }
        }

        public float BaseParryChance
        {
            get
            {
                //float single1 = 0f;//fix del
                Skill skill1 = base.AllSkills[(ushort) DefenseSkill.SkillId];
                return (float) (5 - (((base.Level * 5) - skill1.CurrentVal(this)) * 0.04));
            }
        }

        public ushort BindingPointMapId
        {
            get
            {
                return this.bindingPointMapId;
            }
            set
            {
                this.bindingPointMapId = value;
            }
        }

        public float BindingPointX
        {
            get
            {
                return this.bindingPointX;
            }
            set
            {
                this.bindingPointX = value;
            }
        }

        public float BindingPointY
        {
            get
            {
                return this.bindingPointY;
            }
            set
            {
                this.bindingPointY = value;
            }
        }

        public float BindingPointZ
        {
            get
            {
                return this.bindingPointZ;
            }
            set
            {
                this.bindingPointZ = value;
            }
        }

        public uint Copper
        {
            get
            {
                return this.copper;
            }
            set
            {
                this.copper = value;
            }
        }

        public Server.Object CurrentObjectLooted
        {
            get
            {
                return this.currentObjectLooted;
            }
            set
            {
                this.currentObjectLooted = value;
            }
        }

        public int Face
        {
            get
            {
                return this.face;
            }
        }

        public int FacialHair
        {
            get
            {
                return this.facialHair;
            }
        }

        public override uint Flags
        {
            get
            {
                uint num1 = 0;
                if (base.MountModel != 0)
                {
                    num1 |= 0x3000;
                }
                if (base.Dead)
                {
                    num1 |= 0x4000;
                }
                if ((base.Freeze || base.ForceRoot) || base.ForceStun)
                {
                    num1 |= 4;
                }
                if (!this.pvpActive)
                {
                    num1 |= 8;
                }
                else
                {
                    num1 |= 0x1000;
                }
                if (this.taxiOn)
                {
                    num1 |= 4;
                    num1 |= 0x2000;
                }
                return num1;
            }
        }

        public ArrayList Friends
        {
            get
            {
                return this.friends;
            }
            set
            {
                this.friends = value;
            }
        }

        public int Gender
        {
            get
            {
                return this.gender;
            }
        }

        public ActiveQuest[] GetActiveQuests
        {
            get
            {
                return this.activeQuests;
            }
        }

        public bool GossipOpened
        {
            get
            {
                return this._gossipOpened;
            }
        }

        public Group GroupMembers
        {
            get
            {
                return this.group;
            }
        }

        public uint GuildID
        {
            get
            {
                return 0;
            }
        }

        public uint GuildRank
        {
            get
            {
                return 0;
            }
        }

        public uint GuildTimestamp
        {
            get
            {
                return 0;
            }
        }

        public int HairColour
        {
            get
            {
                return this.hairColour;
            }
        }

        public int HairStyle
        {
            get
            {
                return this.hairStyle;
            }
        }

        public int IqBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Iq - ((int) base.BaseIq);
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int IqMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Iq - ((int) base.BaseIq);
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public bool IsInDuel
        {
            get
            {
                if (this.gu != null)
                {
                    return true;
                }
                return false;
            }
        }

        public override ArrayList KnownObjects
        {
            get
            {
                return this.Player.KnownObjects;
            }
        }

        public int LinkedSpawner
        {
            get
            {
                return this.linkedSpawner;
            }
            set
            {
                this.linkedSpawner = value;
            }
        }

        public bool Logged
        {
            get
            {
                if (this.account != null)
                {
                    return true;
                }
                return false;
            }
        }

        public ulong LootOwner
        {
            get
            {
                return this.lootOwner;
            }
            set
            {
                this.lootOwner = value;
            }
        }

        public uint NextLevelExp
        {
            get
            {
                return 0x3e8;
            }
        }

        public Account Player
        {
            get
            {
                return this.account;
            }
            set
            {
                this.account = value;
            }
        }

        public bool PvpActive
        {
            get
            {
                return this.pvpActive;
            }
            set
            {
                this.pvpActive = value;
            }
        }

        public Races Race
        {
            get
            {
                return this.race;
            }
        }

        public Hashtable ReputationAdjustments
        {
            get
            {
                return this.reputationAdjustments;
            }
        }

        public Server.Object Selection
        {
            get
            {
                return this.selection;
            }
        }

        public int Sheathed
        {
            get
            {
                return this.sheathed;
            }
            set
            {
                this.sheathed = value;
            }
        }

        public int Skin
        {
            get
            {
                return this.skin;
            }
        }

        public int SpiritBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Spirit - ((int) base.BaseSpirit);
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int SpiritMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Spirit - ((int) base.BaseSpirit);
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public int StaminaBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Stamina - base.StaminaBonus;
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int StaminaMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Stamina - base.StaminaBonus;
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public byte StatusFlags
        {
            get
            {
                return 0;
            }
        }

        public int StrBonusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Str - ((int) base.BaseStr);
                if (num1 > 0)
                {
                    return num1;
                }
                return 0;
            }
        }

        public int StrMalusUpdate
        {
            get
            {
                int num1 = 0;
                num1 = base.Str - ((int) base.BaseStr);
                if (num1 < 0)
                {
                    return (-1 * num1);
                }
                return 0;
            }
        }

        public ulong Target
        {
            get
            {
                return this.target;
            }
            set
            {
                this.target = value;
            }
        }

        public override byte[] tempBuff
        {
            get
            {
                return World.tempBuff;
            }
        }

        public int[] TradeItems
        {
            get
            {
                return this.tradeItems;
            }
        }

        public int TradeState
        {
            get
            {
                return this.tradeState;
            }
            set
            {
                this.tradeState = value;
            }
        }

        public uint WeaponMode
        {
            get
            {
                return 0;
            }
        }


        // Fields
        private bool _gossipOpened;
        private Account account;
        private ArrayList actionBar;
        private ActiveQuest[] activeQuests;
        public static ArrayList allCharacters;
        private int ammoType;
        private ushort bindingPointMapId;
        private float bindingPointX;
        private float bindingPointY;
        private float bindingPointZ;
        private CastTrainerSpell castTrainerSpell;
        private Server.Character.CombatTimer combatTimer;
        private int compteur;
        private uint copper;
        private float CorpseLocationX;
        private float CorpseLocationY;
        private float CorpseLocationZ;
        private ushort CorpseMapId;
        private ulong corpsGuid;
        private Server.Object currentObjectLooted;
        public bool deadEndTeleportLoop;
        public static int decal;
        private DuelTimer dt;
        public ulong Duel;
        private byte face;
        private byte facialHair;
        private uint ff;
        private FirstHitCombatTimer firstHitCombatTimer;
        public ArrayList friends;
        private byte gender;
        private static AuraEffect gmInvisibilityAura;
        private Group group;
        public Character gu;
        public Character guowner;
        private byte hairColour;
        private byte hairStyle;
        public static HandsFighting handToHand;
        private byte[] hitBuffer;
        private InternalHeartBeatTimer internalTimer;
        private DateTime last;
        private DateTime lastAreaTrigger;
        public float lastDistance;
        private int linkedSpawner;
        public bool logged;
        private ulong lootOwner;
        private Position mark;
        public static int num;
        public static Server.AreaTrigger onAreaTrigger;
        public static CharacterChooseRace onCharacterChooseRace;
        public static CharacterReclaimCorps onCharacterReclaimCorps;
        public static CharacterReclaimCorps onCharacterRepop;
        public static CharacterCommandHandler onCommand;
        public static CraftLevelRequesite onCraftLevelRequesite;
        public static CraftSkillPrerequesite onCraftSkillPrerequesite;
        public static CharacterHandler onCreateCharacter;
        public static EveryHeartBeat onHeartBeat;
        public static LearnProfession onLearn;
        public static LevelUp onLevelUp;
        public static CharacterHandler onLogin;
        public static CharacterHandler onLogout;
        public static SkillProgressFactorHandler onSkillProgressFactor;
        public static SpellPrice onSpellPrice;
        public static CharacterHandler onTrainningAck;
        public Trajet path;
        public ArrayList pendingGroupRequest;
        private int pendingTeleportMapId;
        private float pendingTeleportO;
        private float pendingTeleportX;
        private float pendingTeleportY;
        private float pendingTeleportZ;
        private int[] petActions;
        public int previousSpellCasted;
        private bool pvpActive;
        private Hashtable questsDone;
        private Races race;
        private Hashtable reputationAdjustments;
        private Server.Object selection;
        private int sheathed;
        private byte skin;
        private GameObject startTrajetFlag;
        private ulong target;
        public uint[] TaxiField;
        public bool taxiOn;
        public int TaxiPrice;
        public ArrayList team1;
        public ArrayList team2;
        public bool testCombatStarted;
        public TaxiNode to;
        private byte[] tooFar;
        private int tradeGold;
        private int[] tradeItems;
        private int tradeNum;
        private int tradeState;
        private Character tradingWith;
        private uint[] zones;

        // Nested Types
        public class Action
        {
            // Methods
            public Action(GenericReader gr)
            {
                this.Deserialize(gr);
            }

            public Action(byte p, ushort a, byte t, byte o)
            {
                this.place = p;
                this.action = a;
                this.type = t;
                this.other = o;
            }

            public void Change(byte p, ushort a, byte t, byte o)
            {
                this.place = p;
                this.action = a;
                this.type = t;
                this.other = o;
            }

            public void Deserialize(GenericReader gr)
            {
                this.place = gr.ReadByte();
                this.action = (ushort) gr.ReadShort();
                this.type = gr.ReadByte();
                this.other = gr.ReadByte();
            }

            public void Serialize(GenericWriter gw)
            {
                gw.Write(this.place);
                gw.Write(this.action);
                gw.Write(this.type);
                gw.Write(this.other);
            }


            // Fields
            public ushort action;
            public byte other;
            public byte place;
            public byte type;
        }

        public class CastTrainerSpell : WowTimer
        {
            // Methods
            public CastTrainerSpell(BaseAbility i, Character t, Mobile teachr) : base(WowTimer.Priorities.Milisec100, 500)
            {
                this.to = t;
                this.teach = i;
                this.teacher = teachr;
                int num1 = 0;
                if (i is Teach)
                {
                    num1 = (i as Teach).TeachId;
                }
                else
                {
                    num1 = i.Id;
                }
                this.teacher.FakeCast(num1, t);
                base.Start();
            }

            public override void OnTick()
            {
                if (this.teach is Teach)
                {
                    int num1 = (this.teach as Teach).TeachId;
                }
                else
                {
                    ushort num2 = this.teach.Id;
                }
                this.to.TrainerBuyAck(this.teach);
                base.Stop();
                base.OnTick();
            }


            // Fields
            private BaseAbility teach;
            private Mobile teacher;
            private Character to;
        }

        public enum ChatMsgType
        {
            // Fields
			CHAT_MSG_AFK = 20,
			CHAT_MSG_CHANNEL = 14,
			CHAT_MSG_CHANNEL_JOIN = 15,
			CHAT_MSG_CHANNEL_LEAVE = 0x10,
			CHAT_MSG_CHANNEL_LIST = 0x11,
			CHAT_MSG_CHANNEL_NOTICE = 0x12,
			CHAT_MSG_CHANNEL_NOTICE_USER = 0x13,
			CHAT_MSG_COMBAT_LOG = 0x16,
			CHAT_MSG_DND = 0x15,
			CHAT_MSG_EMOTE = 8,
			CHAT_MSG_GUILD = 3,
			CHAT_MSG_IGNORED = 0x17,
			CHAT_MSG_LOOT = 0x19,
			CHAT_MSG_MONSTER_EMOTE = 13,
			CHAT_MSG_MONSTER_SAY = 11,
			CHAT_MSG_MONSTER_YELL = 12,
			CHAT_MSG_OFFICER = 4,
			CHAT_MSG_PARTY = 1,
			CHAT_MSG_SAY = 0,
			CHAT_MSG_SKILL = 0x18,
			CHAT_MSG_SYSTEM = 10,
			CHAT_MSG_TEXT_EMOTE = 9,
			CHAT_MSG_WHISPER = 6,
			CHAT_MSG_WHISPER_INFORM = 7,
			CHAT_MSG_YELL = 5
        }

        public class CombatTimer : WowTimer
        {
            // Methods
            public CombatTimer(ulong targ, Character c, int delay) : base(WowTimer.Priorities.Milisec100, (double) delay)
            {
                this.target = targ;
                this.from = c;
                base.Start();
            }

            public override void OnTick()
            {
                this.from.OnCombatTick(this);
                base.OnTick();
            }


            // Fields
            private Character from;
            public ulong target;
        }

        private class DuelTimer : WowTimer
        {
            // Methods
            public DuelTimer(Character c1, Character c2, ulong f) : base(WowTimer.Priorities.Milisec100, 3000)
            {
                this.combatStarted = false;
                this.from = c1;
                this.vs = c2;
                this.flag = f;
                this.x = c1.X;
                this.y = c1.Y;
                this.z = c1.Z;
                base.Start();
            }

            public override void OnTick()
            {
                if (!this.combatStarted)
                {
                    object[] objArray1 = new object[3] { 0, 0, 1 } ;
                    this.from.SendSmallUpdate(new int[3] { 0xb0, 0xb1, 0xba } , objArray1);
                    objArray1 = new object[3] { 0, 0, 2 } ;
                    this.from.SendSmallUpdateFor(this.vs.Guid, new int[3] { 0xb0, 0xb1, 0xba } , objArray1);
                    objArray1 = new object[3] { 0, 0, 2 } ;
                    this.vs.SendSmallUpdate(new int[3] { 0xb0, 0xb1, 0xba } , objArray1);
                    objArray1 = new object[3] { 0, 0, 1 } ;
                    this.vs.SendSmallUpdateFor(this.from.Guid, new int[3] { 0xb0, 0xb1, 0xba } , objArray1);
                    this.vs.Duel = this.flag;
                    this.from.Duel = this.flag;
                    this.combatStarted = true;
                }
                else if ((this.from.gu == null) || (this.vs.gu == null))
                {
                    base.Stop();
                }
                else
                {
                    if ((this.from.Player == null) || (this.from.Distance(this.x, this.y, this.z) > 3600f))
                    {
                        this.from.OnDeath(this.vs);
                        base.Stop();
                        return;
                    }
                    if ((this.vs.Player == null) || (this.vs.Distance(this.x, this.y, this.z) > 3600f))
                    {
                        this.vs.OnDeath(this.from);
                        base.Stop();
                        return;
                    }
                }
                base.OnTick();
            }


            // Fields
            private bool combatStarted;
            private ulong flag;
            private Character from;
            private Character vs;
            private float x;
            private float y;
            private float z;
        }

        private class FirstHitCombatTimer : WowTimer
        {
            // Methods
            public FirstHitCombatTimer(Character c) : base(WowTimer.Priorities.Milisec100, 100)
            {
                this.from = c;
                base.Start();
            }

            public override void OnTick()
            {
                this.from.OnFirstHit();
                base.OnTick();
            }


            // Fields
            private Character from;
        }

        private enum FriendResults
        {
            // Fields
            Friend_ADDED_OFFLINE = 7,
            Friend_ADDED_ONLINE = 6,
            Friend_ALREADY = 8,
            Friend_DB_ERROR = 0,
            Friend_ENEMY = 10,
            Friend_IGNORE_ADDED = 15,
            Friend_IGNORE_ALREADY = 14,
            Friend_IGNORE_FULL = 11,
            Friend_IGNORE_NOT_FOUND = 13,
            Friend_IGNORE_REMOVED = 0x10,
            Friend_IGNORE_SELF = 12,
            Friend_LIST_FULL = 1,
            Friend_NOT_FOUND = 4,
            Friend_OFFLINE = 3,
            Friend_ONLINE = 2,
            Friend_REMOVED = 5,
            Friend_SELF = 9
        }

        public class GMInvisibilityAura : AuraEffect
        {
            // Methods
            public GMInvisibilityAura() : base(0x375, 0, 0x26, 0x63, 1, 0, 200, 0, 0, 0, 0, Resistances.Arcane, DispelType.None, 200, 0xbb8, 100, 0xffffff, 0, 0x12, 0x65, 3)
            {
            }

        }

        public class HandsFighting : Item
        {
            // Methods
            public HandsFighting()
            {
                base.SetDamage(1f, 2f, Resistances.Armor);
                base.Delay = 0x5dc;
            }

        }

        private class InternalHeartBeatTimer : WowTimer
        {
            // Methods
            public InternalHeartBeatTimer(Character c) : base(WowTimer.Priorities.Second, 1000)
            {
                this.from = c;
                base.Start();
            }

            public override void OnTick()
            {
                this.from.HeartBeat();
                base.OnTick();
            }


            // Fields
            private Character from;
        }

        public class MobBalance : WowTimer
        {
            // Methods
            public MobBalance(Character from) : base(WowTimer.Priorities.Milisec100, 1000)
            {
                this.to = from;
                base.Start();
            }

            public override void OnTick()
            {
                for (int num1 = 0; num1 < 4; num1++)
                {
                    for (int num2 = 0; num2 < this.to.team1.Count; num2++)
                    {
                        if ((this.to.team1[num2] as BaseCreature).Dead)
                        {
                            this.to.team1.RemoveAt(num2);
                            break;
                        }
                    }
                    for (int num3 = 0; num3 < this.to.team2.Count; num3++)
                    {
                        if ((this.to.team2[num3] as BaseCreature).Dead)
                        {
                            this.to.team2.RemoveAt(num3);
                            break;
                        }
                    }
                }
                this.to.SendMessage("Team1 alive : " + this.to.team1.Count);
                this.to.SendMessage("Team2 alive : " + this.to.team2.Count);
                if (this.to.team1.Count == 0)
                {
                    this.to.SendMessage("Team1 loose, team2 alive : " + this.to.team2.Count);
                    this.to.testCombatStarted = false;
                    base.Stop();
                    foreach (Mobile mobile1 in this.to.team2)
                    {
                        mobile1.Kill();
                    }
                    this.to.team2.Clear();
                }
                if (this.to.team2.Count == 0)
                {
                    this.to.SendMessage("Team2 loose, team1 alive : " + this.to.team1.Count);
                    this.to.testCombatStarted = false;
                    base.Stop();
                    foreach (Mobile mobile2 in this.to.team1)
                    {
                        mobile2.Kill();
                    }
                    this.to.team1.Clear();
                }
                base.OnTick();
            }


            // Fields
            private Character to;
        }
		public delegate void onDebugEvent(Character c, int id);

        private class TestTimer : WowTimer
        {
            // Methods
            public TestTimer(Character c, Mobile f) : base(WowTimer.Priorities.Milisec100, 1000)
            {
                this.c = 0;
                this.from = c;
                this.to = f;
                float single1 = c.X - this.to.X;
                float single2 = c.Y - this.to.Y;
                float single3 = c.Z - this.to.Z;
                float single4 = (float) Math.Sqrt((double) (((single1 * single1) + (single2 * single2)) + (single3 * single3)));
                this.from.SendMessage("dist = " + single4.ToString());
                base.Start();
            }

            public override void OnTick()
            {
                float single1;
                float single2;
                float single3;
                this.to.moveVector.Get(out single1, out single2, out single3);
                string[] textArray1 = new string[6] { "X = ", single1.ToString(), ", Y = ", single2.ToString(), ", Z = ", single3.ToString() } ;
                this.from.SendMessage(string.Concat(textArray1));
                this.c++;
                base.OnTick();
            }


            // Fields
            private int c;
            private Character from;
            private Mobile to;
        }
    }
}

