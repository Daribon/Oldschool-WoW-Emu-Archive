namespace Server
{
    using HelperTools;
    using System;
    using System.Collections;
    using System.Reflection;

    [Serializable]
    public class Trajet : CollectionBase
    {
        // Methods
        static Trajet()
        {
            Trajet.allLinks = new ArrayList();
        }

        public Trajet()
        {
            Server.Object.GUID++;
            this.guid = Server.Object.GUID;
        }

        public Trajet(GenericReader gr)
        {
            base.List.Clear();
            if (!gr.notFound)
            {
                this.Deserialize(gr);
            }
        }

        public Trajet(Trajet val)
        {
            this.AddRange(val);
        }

        public Trajet(Coord[] val)
        {
            this.AddRange(val);
        }

        public int Add(Coord val)
        {
            return base.List.Add(val);
        }

        public int Add(Coord val, Coord previous)
        {
            Coord coord1 = null;
            Coord coord2 = null;
            Trajet trajet1 = null;
            float single1 = 0f;
            float single2 = 0f;
            float single3 = 0f;
            if (previous != null)
            {
                foreach (Trajet trajet2 in World.trajets)
                {
                    try
                    {
                        Coord coord3 = trajet2[0];
                        bool flag1 = true;
                        while ((flag1 || (coord3 != trajet2[0])) && (coord3.next != null))
                        {
                            flag1 = false;
                            float single4 = coord3.x;
                            float single5 = coord3.y;
                            float single6 = coord3.next.x;
                            float single7 = coord3.next.y;
                            float single8 = val.x;
                            float single9 = val.y;
                            float single10 = previous.x;
                            float single11 = previous.y;
                            if (single4 == single6)
                            {
                                coord3 = coord3.next;
                                continue;
                            }
                            float single12 = ((single5 - single7) * (single8 - single10)) - ((single9 - single11) * (single4 - single6));
                            if (single12 == 0f)
                            {
                                coord3 = coord3.next;
                                continue;
                            }
                            single1 = ((((single8 * single11) - (single10 * single9)) * (single4 - single6)) - (((single4 * single7) - (single6 * single5)) * (single8 - single10))) / single12;
                            single2 = (single1 * ((single5 - single7) / (single4 - single6))) + (((single4 * single7) - (single6 * single5)) / (single4 - single6));
                            float single13 = single4 - single6;
                            float single14 = single5 - single7;
                            float single15 = (single13 * single13) + (single14 * single14);
                            float single16 = single4 - single1;
                            float single17 = single6 - single1;
                            float single18 = single5 - single2;
                            float single19 = single7 - single2;
                            if (((single16 == 0f) && (single18 == 0f)) || ((single17 == 0f) && (single19 == 0f)))
                            {
                                coord3 = coord3.next;
                                continue;
                            }
                            single16 *= single16;
                            single18 *= single18;
                            single17 *= single17;
                            single19 *= single19;
                            if ((single16 + single18) > single15)
                            {
                                coord3 = coord3.next;
                                continue;
                            }
                            if ((single17 + single19) > single15)
                            {
                                coord3 = coord3.next;
                                continue;
                            }
                            float single20 = single8 - single10;
                            float single21 = single9 - single11;
                            single15 = (single20 * single20) + (single21 * single21);
                            float single22 = single8 - single1;
                            float single23 = single10 - single1;
                            float single24 = single9 - single2;
                            float single25 = single11 - single2;
                            if (((single22 == 0f) && (single24 == 0f)) || ((single23 == 0f) && (single25 == 0f)))
                            {
                                coord3 = coord3.next;
                                continue;
                            }
                            single22 *= single22;
                            single24 *= single24;
                            single23 *= single23;
                            single25 *= single25;
                            if ((single22 + single24) > single15)
                            {
                                coord3 = coord3.next;
                            }
                            else if ((single23 + single25) > single15)
                            {
                                coord3 = coord3.next;
                            }
                            else
                            {
                                float single26 = coord3.z;
                                float single27 = coord3.next.z;
                                float single28 = val.z;
                                float single29 = previous.z;
                                single3 = (single1 * ((single26 - single27) / (single4 - single6))) + (((single4 * single27) - (single6 * single26)) / (single4 - single6));
                                coord1 = coord3;
                                coord2 = coord3.next;
                                trajet1 = trajet2;
                                goto Label_030E;
                            }
                        }
                    }
                    catch (Exception exception1)
                    {
                        Console.WriteLine("{0}", exception1.Message);
                    }
                Label_030E:
                    if (trajet1 != null)
                    {
                        break;
                    }
                }
                if (trajet1 != null)
                {
                    Intersection intersection1 = new Intersection(coord1, coord2, previous, val, single1, single2, single3);
                    val.previous = intersection1;
                    previous.next = intersection1;
                    base.List.Add(intersection1);
                    Intersection intersection2 = new Intersection(previous, val, coord1, coord2, single1, single2, single3);
                    coord1.next = intersection2;
                    coord2.previous = intersection2;
                    trajet1.Add(intersection2);
                }
            }
            return base.List.Add(val);
        }

        public void AddRange(Coord[] val)
        {
            for (int num1 = 0; num1 < val.Length; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public void AddRange(Trajet val)
        {
            for (int num1 = 0; num1 < val.Count; num1++)
            {
                this.Add(val[num1]);
            }
        }

        public bool Contains(Coord val)
        {
            return base.List.Contains(val);
        }

        public void CopyTo(Coord[] array, int index)
        {
            base.List.CopyTo(array, index);
        }

        public virtual void Deserialize(GenericReader gr)
        {
            gr.ReadInt();
            int num1 = gr.ReadInt();
            this.guid = gr.ReadInt64();
            this.longueur = 0f;
            for (int num2 = 0; num2 < num1; num2++)
            {
                byte num3 = gr.ReadByte();
                if (num3 == 0)
                {
                    float single1 = gr.ReadFloat();
                    float single2 = gr.ReadFloat();
                    float single3 = gr.ReadFloat();
                    int num4 = gr.ReadInt();
                    int num5 = gr.ReadInt();
                    int num6 = gr.ReadInt();
                    int num7 = gr.ReadInt();
                    Coord coord1 = new Coord(single1, single2, single3, null, null);
                    Trajet.allLinks.Add(coord1);
                    Trajet.allLinks.Add(num4);
                    Trajet.allLinks.Add(num5);
                    Trajet.allLinks.Add(num6);
                    Trajet.allLinks.Add(num7);
                    this.Add(coord1);
                }
                else
                {
                    float single4 = gr.ReadFloat();
                    float single5 = gr.ReadFloat();
                    float single6 = gr.ReadFloat();
                    int num8 = gr.ReadInt();
                    int num9 = gr.ReadInt();
                    int num10 = gr.ReadInt();
                    int num11 = gr.ReadInt();
                    Intersection intersection1 = new Intersection(null, null, null, null, single4, single5, single6);
                    Trajet.allLinks.Add(intersection1);
                    Trajet.allLinks.Add(num8);
                    Trajet.allLinks.Add(num9);
                    Trajet.allLinks.Add(num10);
                    Trajet.allLinks.Add(num11);
                    num8 = gr.ReadInt();
                    num9 = gr.ReadInt();
                    num10 = gr.ReadInt();
                    num11 = gr.ReadInt();
                    Trajet.allLinks.Add(num8);
                    Trajet.allLinks.Add(num9);
                    Trajet.allLinks.Add(num10);
                    Trajet.allLinks.Add(num11);
                    this.Add(intersection1);
                }
            }
        }

        public new CoordEnumerator GetEnumerator()
        {
            return new CoordEnumerator(this);
        }

        public int IndexOf(Coord val)
        {
            return base.List.IndexOf(val);
        }

        public void Insert(int index, Coord val)
        {
            base.List.Insert(index, val);
        }

        public void Remove(Coord val)
        {
            base.List.Remove(val);
        }

        public virtual void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            gw.Write(base.List.Count);
            gw.Write(this.guid);
            foreach (Coord coord1 in this)
            {
                if (coord1 is Intersection)
                {
                    gw.Write((byte) 1);
                }
                else
                {
                    gw.Write((byte) 0);
                }
                gw.Write(coord1.x);
                gw.Write(coord1.y);
                gw.Write(coord1.z);
                int num1 = 0;
                int num2 = 0;
                coord1.previous.TrajetNum(ref num1, ref num2);
                gw.Write(num1);
                gw.Write(num2);
                coord1.next.TrajetNum(ref num1, ref num2);
                gw.Write(num1);
                gw.Write(num2);
                if (coord1 is Intersection)
                {
                    Intersection intersection1 = (Intersection) coord1;
                    intersection1.left.TrajetNum(ref num1, ref num2);
                    gw.Write(num1);
                    gw.Write(num2);
                    intersection1.right.TrajetNum(ref num1, ref num2);
                    gw.Write(num1);
                    gw.Write(num2);
                }
            }
        }


        // Properties
        public ulong Guid
        {
            get
            {
                return this.guid;
            }
        }

        public Coord this[int index]
        {
            get
            {
                return (Coord) base.List[index];
            }
            set
            {
                base.List[index] = value;
            }
        }


        // Fields
        public static ArrayList allLinks;
        public ulong guid;
        public float longueur;

        // Nested Types
        public class CoordEnumerator : IEnumerator
        {
            // Methods
            public CoordEnumerator(Trajet mappings)
            {
                this.temp = mappings;
                this.baseEnumerator = this.temp.GetEnumerator();
            }

            public bool MoveNext()
            {
                return this.baseEnumerator.MoveNext();
            }

            public void Reset()
            {
                this.baseEnumerator.Reset();
            }


            // Properties
            public Coord Current
            {
                get
                {
                    return (Coord) this.baseEnumerator.Current;
                }
            }

            object IEnumerator.Current
            {
                get
                {
                    return this.baseEnumerator.Current;
                }
            }


            // Fields
            private IEnumerator baseEnumerator;
            private IEnumerable temp;
        }
    }
}

