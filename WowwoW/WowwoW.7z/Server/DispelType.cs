namespace Server
{
    using System;

    public enum DispelType
    {
        // Fields
        All = 7,
        Curse = 2,
        Disease = 3,
        Frenzy = 9,
        Invisibility = 6,
        Magic = 1,
        None = 0,
        Poison = 4,
        Special = 8,
        Stealth = 5
    }
}

