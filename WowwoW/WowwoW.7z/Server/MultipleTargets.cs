namespace Server
{
    using System;
    using System.Collections;

    public class MultipleTargets
    {
        // Methods
        static MultipleTargets()
        {
            MultipleTargets.multipleTargets = new Hashtable();
            MultipleTargets.temp = new MultipleTargets();
        }

        public MultipleTargets()
        {
            MultipleTargets.multipleTargets[0x2d58] = 2;
            MultipleTargets.multipleTargets[0x2d59] = 2;
            MultipleTargets.multipleTargets[0x3c88] = 2;
            MultipleTargets.multipleTargets[0x3cfd] = 2;
            MultipleTargets.multipleTargets[0x3d06] = 2;
            MultipleTargets.multipleTargets[0x3d07] = 2;
            MultipleTargets.multipleTargets[0x4b77] = 2;
            MultipleTargets.multipleTargets[0x5059] = 2;
            MultipleTargets.multipleTargets[0x5740] = 2;
            MultipleTargets.multipleTargets[0x580c] = 2;
            MultipleTargets.multipleTargets[0x10b9] = 2;
            MultipleTargets.multipleTargets[0x159c] = 2;
            MultipleTargets.multipleTargets[0x1c7a] = 2;
            MultipleTargets.multipleTargets[0x1cc9] = 2;
            MultipleTargets.multipleTargets[0x34d] = 2;
            MultipleTargets.multipleTargets[0x249d] = 2;
            MultipleTargets.multipleTargets[0x25b6] = 2;
            MultipleTargets.multipleTargets[0x296d] = 3;
            MultipleTargets.multipleTargets[0x297e] = 3;
            MultipleTargets.multipleTargets[0x297f] = 3;
            MultipleTargets.multipleTargets[0x428] = 3;
            MultipleTargets.multipleTargets[0x2b4d] = 3;
            MultipleTargets.multipleTargets[0x2ca3] = 3;
            MultipleTargets.multipleTargets[0x2f1a] = 3;
            MultipleTargets.multipleTargets[0x3720] = 3;
            MultipleTargets.multipleTargets[0x3778] = 3;
            MultipleTargets.multipleTargets[0x37d0] = 3;
            MultipleTargets.multipleTargets[0x37d1] = 3;
            MultipleTargets.multipleTargets[0x37d2] = 3;
            MultipleTargets.multipleTargets[0x386b] = 3;
            MultipleTargets.multipleTargets[0x3a34] = 3;
            MultipleTargets.multipleTargets[0x3b0d] = 3;
            MultipleTargets.multipleTargets[0x3bb4] = 3;
            MultipleTargets.multipleTargets[0x3cbd] = 3;
            MultipleTargets.multipleTargets[0x3cdb] = 3;
            MultipleTargets.multipleTargets[0x3ce0] = 3;
            MultipleTargets.multipleTargets[0x3d2b] = 3;
            MultipleTargets.multipleTargets[0x3d2f] = 3;
            MultipleTargets.multipleTargets[0x3d8a] = 3;
            MultipleTargets.multipleTargets[0x3db7] = 3;
            MultipleTargets.multipleTargets[0x3e86] = 3;
            MultipleTargets.multipleTargets[0x3fef] = 3;
            MultipleTargets.multipleTargets[0x4219] = 3;
            MultipleTargets.multipleTargets[0x4515] = 3;
            MultipleTargets.multipleTargets[0x462b] = 3;
            MultipleTargets.multipleTargets[0x48db] = 3;
            MultipleTargets.multipleTargets[0x4983] = 3;
            MultipleTargets.multipleTargets[0x5037] = 3;
            MultipleTargets.multipleTargets[0x507d] = 3;
            MultipleTargets.multipleTargets[0x5093] = 3;
            MultipleTargets.multipleTargets[0x50c5] = 3;
            MultipleTargets.multipleTargets[0x515f] = 3;
            MultipleTargets.multipleTargets[0x52bb] = 3;
            MultipleTargets.multipleTargets[0x5753] = 3;
            MultipleTargets.multipleTargets[0x59a3] = 3;
            MultipleTargets.multipleTargets[0x5a42] = 3;
            MultipleTargets.multipleTargets[0x5aa6] = 3;
            MultipleTargets.multipleTargets[0xa53] = 3;
            MultipleTargets.multipleTargets[0xb2c] = 3;
            MultipleTargets.multipleTargets[0x1a5] = 3;
            MultipleTargets.multipleTargets[0x186e] = 3;
            MultipleTargets.multipleTargets[0x1be9] = 3;
            MultipleTargets.multipleTargets[0x301] = 3;
            MultipleTargets.multipleTargets[0x30b] = 3;
            MultipleTargets.multipleTargets[780] = 3;
            MultipleTargets.multipleTargets[0x2013] = 3;
            MultipleTargets.multipleTargets[0x2064] = 3;
            MultipleTargets.multipleTargets[930] = 3;
            MultipleTargets.multipleTargets[0x261a] = 3;
            MultipleTargets.multipleTargets[0x26b4] = 3;
            MultipleTargets.multipleTargets[0x4196] = 3;
            MultipleTargets.multipleTargets[0x5987] = 3;
            MultipleTargets.multipleTargets[0x50cc] = 4;
            MultipleTargets.multipleTargets[0x3bc9] = 5;
            MultipleTargets.multipleTargets[0x4cba] = 5;
            MultipleTargets.multipleTargets[0x50d3] = 5;
            MultipleTargets.multipleTargets[0x538e] = 5;
            MultipleTargets.multipleTargets[0x55e8] = 5;
            MultipleTargets.multipleTargets[0x5d91] = 5;
            MultipleTargets.multipleTargets[0x4ab8] = 5;
            MultipleTargets.multipleTargets[0x4f34] = 5;
            MultipleTargets.multipleTargets[0x50ba] = 5;
            MultipleTargets.multipleTargets[0x1c7f] = 5;
            MultipleTargets.multipleTargets[0x203f] = 5;
            MultipleTargets.multipleTargets[0x503f] = 8;
            MultipleTargets.multipleTargets[0x3ea1] = 10;
            MultipleTargets.multipleTargets[0x3eac] = 10;
            MultipleTargets.multipleTargets[0x4cb0] = 10;
            MultipleTargets.multipleTargets[0x4e0f] = 10;
            MultipleTargets.multipleTargets[0x50ff] = 10;
            MultipleTargets.multipleTargets[0x3c26] = 1;
            MultipleTargets.multipleTargets[0x1fba] = 2;
            MultipleTargets.multipleTargets[0x2e0e] = 3;
            MultipleTargets.multipleTargets[0x1fbc] = 3;
            MultipleTargets.multipleTargets[0x2a88] = 4;
            MultipleTargets.multipleTargets[0x2d3c] = 4;
            MultipleTargets.multipleTargets[0x2d3d] = 4;
            MultipleTargets.multipleTargets[0x34dc] = 4;
            MultipleTargets.multipleTargets[0x690] = 4;
            MultipleTargets.multipleTargets[0x59ef] = 4;
            MultipleTargets.multipleTargets[0x18c7] = 4;
            MultipleTargets.multipleTargets[0x2006] = 4;
            MultipleTargets.multipleTargets[0x200c] = 4;
            MultipleTargets.multipleTargets[0x200d] = 4;
            MultipleTargets.multipleTargets[0x2a8a] = 5;
            MultipleTargets.multipleTargets[0x3588] = 5;
            MultipleTargets.multipleTargets[0x4608] = 5;
            MultipleTargets.multipleTargets[0x4c1a] = 5;
            MultipleTargets.multipleTargets[0x5045] = 5;
            MultipleTargets.multipleTargets[0x5964] = 5;
            MultipleTargets.multipleTargets[0x156c] = 5;
            MultipleTargets.multipleTargets[0x3656] = 10;
            MultipleTargets.multipleTargets[0x55fc] = 10;
        }


        // Fields
        public static Hashtable multipleTargets;
        private static MultipleTargets temp;
    }
}

