namespace Server
{
    using HelperTools;
    using Microsoft.CSharp;
    using System;
    using System.CodeDom.Compiler;
    using System.Collections;
    using System.Diagnostics;
    using System.IO;
    using System.Reflection;
    using System.Threading;
	using System.Text;

    public class MainConsole
    {
        // Methods
        static MainConsole()
        {
            MainConsole.sw1 = null;
            MainConsole.end = false;
        }

        public MainConsole()
        {
        }

        public static bool BuildExternalEnvironements()
        {
            CSharpCodeProvider provider1 = new CSharpCodeProvider();
            ICodeCompiler compiler1 = provider1.CreateCompiler();
            CompilerParameters parameters1 = new CompilerParameters();
            parameters1.GenerateExecutable = false;
            parameters1.GenerateInMemory = true;
            parameters1.MainClass = "";
            Assembly[] assemblyArray1 = AppDomain.CurrentDomain.GetAssemblies();
            for (int num5 = 0; num5 < assemblyArray1.Length; num5++)
            {
                Assembly assembly1 = assemblyArray1[num5];
                parameters1.ReferencedAssemblies.Add(assembly1.Location);
            }
            parameters1.IncludeDebugInformation = false;
            World.Path = AppDomain.CurrentDomain.BaseDirectory;
            parameters1.OutputAssembly = World.Path + "res1.dll";
            parameters1.WarningLevel = 4;
            MainConsole.sourcesCodeDirty = false;
            if (File.Exists(parameters1.OutputAssembly) && File.Exists(World.Path + "res2.dll"))
            {
                MainConsole.sourcesCodeCRC = File.GetLastWriteTime(parameters1.OutputAssembly);
            }
            else
            {
                MainConsole.sourcesCodeDirty = true;
            }
            ArrayList list1 = MainConsole.BuildSources(World.Path + "Scripts/");
            if (!MainConsole.sourcesCodeDirty)
            {
                Utility.externAsmItem = Assembly.LoadFile(AppDomain.CurrentDomain.BaseDirectory + "res1.dll");
                Utility.externAsm = Assembly.LoadFile(AppDomain.CurrentDomain.BaseDirectory + "res2.dll");
                return true;
            }
            if (File.Exists(World.Path + "res2.dll"))
            {
                File.Delete(World.Path + "res2.dll");
            }
            int num1 = 0;
            int num2 = 0;
            for (int num3 = 0; num3 < list1.Count; num3++)
            {
                if (((list1[num3] as string).ToLower().IndexOf("scripts/items/") >= 0) || ((list1[num3] as string).ToLower().IndexOf(@"scripts\items\") >= 0))
                {
                    num2++;
                }
                else
                {
                    num1++;
                }
            }
			//
            /*MainConsole.fileNames = new string[num1];
            num1 = 0;
            MainConsole.fileNamesItems = new string[num2];
            num2 = 0;
            for (int num4 = 0; num4 < list1.Count; num4++)
            {
                if (((list1[num4] as string).ToLower().IndexOf("scripts/items/") >= 0) || ((list1[num4] as string).ToLower().IndexOf(@"scripts\items\") >= 0))
                {
                    MainConsole.fileNamesItems[num2++] = (string) list1[num4];
                }
                else
                {
                    MainConsole.fileNames[num1++] = (string) list1[num4];
                }
            }
            CompilerResults results1 = compiler1.CompileAssemblyFromFileBatch(parameters1, MainConsole.fileNamesItems);*/
			//
			//�޸�֧�ֺ���,������ħ�������з�С���Ա---��.firework �ṩ���ش�������
			MainConsole.batchSources = new string [num1];//-->��ʼ
			MainConsole.BatchSources = new string [num1];
			num1 = 0;
			MainConsole.batchitemsSources = new string [num2];
			MainConsole.BatchItemsSources = new string [num2];
			num2 = 0;
			for (int num4 = 0; num4 < list1.Count; num4++)
			{
				if (((list1[num4] as string).ToLower().IndexOf("scripts/items/") >= 0) || ((list1[num4] as string).ToLower().IndexOf(@"scripts\items\") >= 0))
				{
					StreamReader reader1 = File.OpenText(Convert.ToString(list1[num4]));
					MainConsole.batchitemsSources[num2] = reader1.ReadToEnd();
					byte[] itemsUTF8sources = Encoding.UTF8.GetBytes(MainConsole.batchitemsSources[num2]);
					char[] itemsCodenew= new char [itemsUTF8sources.Length];
					string itemscodenew="";
					for(int i=0; i < itemsUTF8sources.Length; i++) 					{						itemsCodenew[i]=(char)itemsUTF8sources[i];					}
					itemscodenew=new string (itemsCodenew);
					MainConsole.BatchItemsSources[num2]=itemscodenew ;
					reader1.Close();
					num2++;
				}
				else
				{
					StreamReader reader2 = File.OpenText(Convert.ToString(list1[num4]));
					MainConsole.batchSources[num1] = reader2.ReadToEnd();
					byte[] UTF8sources = Encoding.UTF8.GetBytes(MainConsole.batchSources[num1]);
					char[] Codenew= new char [UTF8sources.Length];
					string codenew="";
					for(int n=0; n < UTF8sources.Length; n++) 					{						Codenew[n]=(char)UTF8sources[n];					}
					codenew=new string (Codenew);
					MainConsole.BatchSources[num1]=codenew ;
					reader2.Close();
					num1++;
				}
			}
			CompilerResults results1 = compiler1.CompileAssemblyFromSourceBatch(parameters1, MainConsole.BatchItemsSources);//<--����
            if (results1.Errors.Count > 0)
            {
                string text1 = "Compilation failed:\n";
                foreach (CompilerError error1 in results1.Errors)
                {
                    text1 = text1 + error1.ToString() + "\n";
                }
                Console.WriteLine(text1);
                throw new Exception(text1);
            }
            Utility.externAsmItem = results1.CompiledAssembly;
            if (File.Exists(AppDomain.CurrentDomain.BaseDirectory + "res2.dll"))
            {
                Utility.externAsm = Assembly.LoadFile(AppDomain.CurrentDomain.BaseDirectory + "res2.dll");
                return true;
            }
            parameters1.ReferencedAssemblies.Add(World.Path + "res1.dll");
            parameters1.OutputAssembly = World.Path + "res2.dll";
            //results1 = compiler1.CompileAssemblyFromFileBatch(parameters1, MainConsole.fileNames);
            results1 = compiler1.CompileAssemblyFromSourceBatch(parameters1, MainConsole.BatchSources);//fix ��������֧�ֺ����޸ĵ������޸�
			if (results1.Errors.Count > 0)
            {
                string text2 = "Compilation failed:\n";
                foreach (CompilerError error2 in results1.Errors)
                {
                    text2 = text2 + error2.ToString() + "\n";
                }
                Console.WriteLine(text2);
                throw new Exception(text2);
            }
            //Console.WriteLine("{0} scripts compiled.", MainConsole.fileNames.Length);
            Console.WriteLine("{0} scripts compiled.", MainConsole.batchSources.Length);//fix ��������֧�ֺ����޸ĵ������޸�
			Utility.externAsm = results1.CompiledAssembly;
            return true;
        }

        public static ArrayList BuildSources(string path)
        {
            DirectoryInfo info1 = new DirectoryInfo(path);
            ArrayList list1 = new ArrayList();
            DirectoryInfo[] infoArray2 = info1.GetDirectories("*");
            DirectoryInfo[] infoArray3 = infoArray2;
            int num1 = 0;
            while (num1 < infoArray3.Length)
            {
                DirectoryInfo info2 = infoArray3[num1];
                ArrayList list2 = MainConsole.BuildSources(path + "/" + info2.Name);
                foreach (object obj1 in list2)
                {
                    if (info2.LastWriteTime > MainConsole.sourcesCodeCRC)
                    {
                        MainConsole.sourcesCodeDirty = true;
                        MainConsole.sourcesCodeCRC = info2.LastWriteTime;
                    }
                    list1.Add(obj1);
                }
                num1++;
            }
            FileInfo[] infoArray1 = info1.GetFiles();
            FileInfo[] infoArray4 = infoArray1;
            for (num1 = 0; num1 < infoArray4.Length; num1++)
            {
                FileInfo info3 = infoArray4[num1];
                if (info3.Extension.EndsWith(".cs"))
                {
                    list1.Add(info3.FullName);
                }
                else
                {
                    info3.Extension.EndsWith(".cod");
                }
            }
            return list1;
        }

        private void captureStdout(object sender, EventArgs e)
        {
            if (MainConsole.sw1 != null)
            {
                MainConsole.sw1.Close();
            }
        }

        public static void Listen3724()
        {
          MainConsole.authServer = new AuthServer(World.ServerIP, 0xe8c);	
        }

		public static void Listen80()
		{
			//MainConsole.httpServer = new HttpServer(World.ServerIP, World.HttpServerPort);	
			MainConsole.listen80 = new SynchronousSocketListener(2, World.HttpServerPort, "HttpConnection");//fix
			MainConsole.listen80.StartListening();//fix
		}

		public static void Listen8085()
		{
			MainConsole.realmServer = new RealmServer(World.ServerIP, World.ServerPort);
		}

		[STAThread]
		private static void Main(string[] args)
		{
			try
			{
				if ((args.Length > 0) && (args[0] == "outfile"))
				{
					int num1 = Utility.Random1024();
					FileStream stream1 = new FileStream("log" + num1.ToString() + ".txt", FileMode.Create);
					MainConsole.sw1 = new StreamWriter(stream1);
					Console.SetOut(MainConsole.sw1);
				}
				new MainConsole();
				Process[] processArray1 = Process.GetProcessesByName("WowwoW.exe");
				if (processArray1.Length > 0)
				{
					processArray1[0].WaitForExit();
				}
				Console.WriteLine("WowwoW version {0} (c) 2005 DrNexus ==>KissNext�������", World.Version);
				if (!MainConsole.BuildExternalEnvironements())
				{
					return;
				}
				Utility.FillConstructorList();
				ConstructorInfo info1 = Utility.FindConstructor("CustomHandlers", Utility.externAsm);
				info1.Invoke(null);
				MainConsole.world = new World();
				MainConsole.worldThread1ms = new Thread(new ThreadStart(MainConsole.world.Slice1ms));
				MainConsole.worldThread1ms.Start();
				MainConsole.th = new Thread[1];
				MainConsole.Listen3724();
				MainConsole.Listen8085();
				//MainConsole.Listen80();
				MainConsole.th[0] = new Thread(new ThreadStart(MainConsole.Listen80));//fix
				MainConsole.th[0].Start();//fix
				MainConsole.th[0].Priority = ThreadPriority.Lowest;//fix
				MainConsole.worldThread1ms.Priority = ThreadPriority.AboveNormal;
				new Area();
				if (MainConsole.sw1 != null)
				{
					MainConsole.sw1.Flush();
				}
				while (!MainConsole.end)
				{
					Thread.Sleep(0x7530);
				}
			}
			catch (Exception exception1)
			{
				Console.WriteLine("Error in main console !");
				Console.WriteLine(exception1.Message);
				Console.WriteLine(exception1.Source);
				Console.WriteLine(exception1.StackTrace);
			}
		}

		public static void Restart()
		{
			Thread.CurrentThread.Priority = ThreadPriority.Highest;
			if (File.Exists("./wow_start.sh"))
			{
				Process.Start("./wow_start.sh");
			}
			else
			{
				Process.Start("Wowwow.exe");
			}
			Process process1 = Process.GetCurrentProcess();
			if (MainConsole.sw1 != null)
			{
				MainConsole.sw1.Flush();
			}
			Console.WriteLine("Terminating..");
			process1.Kill();
		}

		public static void StopAllThread()
		{
			MainConsole.end = true;
			MainConsole.realmServer.Dispose();
			MainConsole.authServer.Dispose();
			//MainConsole.httpServer.Dispose();//fix del
			Process process1 = Process.GetCurrentProcess();
			ProcessThreadCollection collection1 = process1.Threads;
			World.notEnded = false;
			foreach (ProcessThread thread1 in collection1)
			{
				Console.WriteLine("thread id {0} CPU {1}", thread1.Id, thread1.TotalProcessorTime.TotalMilliseconds);
			}
			process1.Close();
		}


		// Fields
		public static AuthServer authServer;
		public static bool end;
		private static string[] batchSources;
		private static string[] BatchSources;//fix add
		private static string[] batchitemsSources;
		private static string[] BatchItemsSources;//fix add
		//public static HttpServer httpServer;//fix del
		//private static SynchronousSocketListener listen3724;//fix del
		private static SynchronousSocketListener listen80;
		public static RealmServer realmServer;
		private static DateTime sourcesCodeCRC;
		private static bool sourcesCodeDirty;
		public static StreamWriter sw1;
		private static Thread[] th;
		public static World world;
		private static Thread worldThread1ms;

		// Nested Types
		private class TestTimer : WowTimer
		{
			// Methods
			public TestTimer(int time) : base((double) time)
			{
				base.Start();
			}

			public override void OnTick()
			{
				Console.WriteLine("Tick test1");
				base.OnTick();
			}

		}
	}
}


