namespace Server
{
    using System;

    public class MailSkill : Skill
    {
        // Methods
        public MailSkill()
        {
        }

        public MailSkill(int current, int max) : base(1, 1)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x19d;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x19d;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x2221;
            }
        }

    }
}

