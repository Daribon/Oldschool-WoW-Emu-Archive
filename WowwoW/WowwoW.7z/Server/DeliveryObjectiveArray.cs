namespace Server
{
    using System;
    using System.Collections;

    public class DeliveryObjectiveArray
    {
        // Methods
        static DeliveryObjectiveArray()
        {
            DeliveryObjectiveArray._max = 4;
        }

        public DeliveryObjectiveArray()
        {
            this._items = new ArrayList();
        }

        public void Add(DeliveryObjective d)
        {
            if (d.ExistsInWorld)
            {
                if (!this.CanAdd)
                {
                    return;
                }
                this._items.Add(d);
            }
            else
            {
                BadIdList.AddItemId(d.Id);
            }
        }

        public void Add(int id, int amount)
        {
            this.Add(new DeliveryObjective(id, amount));
        }

        public DeliveryObjective GetById(int id)
        {
            DeliveryObjective objective1 = null;
            foreach (DeliveryObjective objective2 in this._items)
            {
                if (objective2.Id == id)
                {
                    return objective2;
                }
            }
            return objective1;
        }


        // Properties
        private bool CanAdd
        {
            get
            {
                return (this.Count < DeliveryObjectiveArray._max);
            }
        }

        public int Count
        {
            get
            {
                return this._items.Count;
            }
        }

        public DeliveryObjective[] Items
        {
            get
            {
                return (DeliveryObjective[]) this._items.ToArray(typeof(DeliveryObjective));
            }
        }


        // Fields
        private ArrayList _items;
        private static int _max;
    }
}

