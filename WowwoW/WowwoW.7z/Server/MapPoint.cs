namespace Server
{
    using System;

    public class MapPoint
    {
        // Methods
        public MapPoint(float _x, float _y, float _z)
        {
            this.x = _x;
            this.y = _y;
            this.z = _z;
        }


        // Fields
        public float x;
        public float y;
        public float z;
    }
}

