namespace Server
{
    using System;

    public enum Races
    {
        // Fields
        Dwarf = 3,
        Gnome = 7,
        Human = 1,
        NightElf = 4,
        Orc = 2,
        Tauren = 6,
        Troll = 8,
        Undead = 5
    }
}

