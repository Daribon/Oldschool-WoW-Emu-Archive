namespace Server
{
    public interface IInitialize
    {
    }
}

