namespace Server
{
    using System;

    public class FrostArmorAura : Aura
    {
        // Methods
        public FrostArmorAura()
        {
        }


        // Properties
        public override int ArmorBonus
        {
            get
            {
                return this.armorBonus;
            }
            set
            {
                this.armorBonus = value;
            }
        }

        public AuraEffect Effect
        {
            get
            {
                return this.auraEffect;
            }
            set
            {
                this.auraEffect = value;
            }
        }

        public override int OnMeleeHit
        {
            get
            {
                return this.onMeleeHit;
            }
            set
            {
                this.onMeleeHit = value;
            }
        }


        // Fields
        private int armorBonus;
        private AuraEffect auraEffect;
        private int onMeleeHit;
    }
}

