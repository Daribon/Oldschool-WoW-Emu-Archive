namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;
    using System.Runtime.CompilerServices;

    public class Aura
    {
        // Methods
        public Aura()
        {
        }

        public Aura(EffectTypes et)
        {
        }

        public virtual void HaveSpecialState(Mobile who, SpecialStates state)
        {
            IEnumerator enumerator1 = who.Auras.GetEnumerator();
            try
            {
                while (enumerator1.MoveNext())
                {
                    Mobile.AuraReleaseTimer timer1 = (Mobile.AuraReleaseTimer) enumerator1.Current;
                }
            }
            finally
            {
                IDisposable disposable1 = enumerator1 as IDisposable;
                if (disposable1 != null)
                {
                    disposable1.Dispose();
                }
            }
        }

        public void PeriodicAura(AuraPeriodicEffect ape, int duration, int frequency)
        {
            this.auraPeriodicTimer = new AuraPeriodicTimer(ape, duration, frequency);
        }

        public virtual void Release(Mobile m)
        {
            if (this.effect != EffectTypes.FireAbsorb)
            {
                m.CumulativeAuraEffects[this.effect] = null;
            }
            if (this.auraPeriodicTimer != null)
            {
                this.auraPeriodicTimer.Stop();
                this.auraPeriodicTimer = null;
            }
            this.effect = EffectTypes.FireAbsorb;
            this.val = 0;
            if (this.OnRelease != null)
            {
                (this.OnRelease as AuraReleaseDelegate)(m);
            }
        }

        public static void SetDetectCreature(TrackableCreatures res, Mobile who)
        {
            int[] numArray1;
            object[] objArray1;
            if (who.CumulativeAuraEffects[EffectTypes.FindCreature] != null)
            {
                who.CumulativeAuraEffects.Remove(EffectTypes.FindCreature);
            }
            who.CumulativeAuraEffects.Add(EffectTypes.FindCreature, (int) res);
            if ((who is Character) && (res == TrackableCreatures.All))
            {
                numArray1 = new int[1] { 0x3f2 } ;
                objArray1 = new object[1] { 0x40 } ;
                (who as Character).SendSmallUpdate(numArray1, objArray1);
            }
            else
            {
                foreach (Server.Object obj1 in (who as Character).KnownObjects)
                {
                    if ((obj1 is Mobile) && (((TrackableCreatures) (obj1 as Mobile).NpcType) == res))
                    {
                        numArray1 = new int[1] { 0x94 } ;
                        objArray1 = new object[1] { (obj1 as Mobile).DynFlags(who) } ;
                        (obj1 as Mobile).SendSmallUpdateToPlayerNearMe(numArray1, objArray1);
                    }
                }
            }
        }

        public static void SetDetectMineral(TrackableResources res, Mobile who)
        {
            if (who.CumulativeAuraEffects[EffectTypes.FindMineral] != null)
            {
                who.CumulativeAuraEffects.Remove(EffectTypes.FindMineral);
            }
            who.CumulativeAuraEffects.Add(EffectTypes.FindMineral, (int) res);
            if (who is Character)
            {
                int[] numArray1;
                object[] objArray1;
                switch (res)
                {
                    case TrackableResources.Herbs:
                    {
                        numArray1 = new int[1] { 0x3f3 } ;
                        objArray1 = new object[1] { 2 } ;
                        (who as Character).SendSmallUpdate(numArray1, objArray1);
                        return;
                    }
                    case TrackableResources.Minerals:
                    {
                        numArray1 = new int[1] { 0x3f3 } ;
                        objArray1 = new object[1] { 4 } ;
                        (who as Character).SendSmallUpdate(numArray1, objArray1);
                        return;
                    }
                    case ((TrackableResources) 4):
                    case ((TrackableResources) 5):
                    {
                        return;
                    }
                    case TrackableResources.Treasure:
                    {
                        numArray1 = new int[1] { 0x3f3 } ;
                        objArray1 = new object[1] { 0x1000 } ;
                        (who as Character).SendSmallUpdate(numArray1, objArray1);
                        return;
                    }
                }
            }
        }


        // Properties
        public virtual int AbsorbAllMagic
        {
            get
            {
                if (this.effect == EffectTypes.AbsorbAllMagic)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AbsorbAllMagic;
                this.val = value;
            }
        }

        public virtual int AgBonus
        {
            get
            {
                if (this.effect == EffectTypes.AgBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AgBonus;
                this.val = value;
            }
        }

        public virtual int AgMalus
        {
            get
            {
                if (this.effect == EffectTypes.AgMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AgMalus;
                this.val = value;
            }
        }

        public virtual float AgPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.AgPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.AgPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float AgPercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.AgPercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.AgPercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int AllAtributesBonus
        {
            get
            {
                if (this.effect == EffectTypes.AllAtributesBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllAtributesBonus;
                this.val = value;
            }
        }

        public virtual int AllAtributesMalus
        {
            get
            {
                if (this.effect == EffectTypes.AllAtributesMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllAtributesMalus;
                this.val = value;
            }
        }

        public virtual float AllAtributesPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.AllAtributesPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.AllAtributesPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float AllAtributesPercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.AllAtributesPercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.AllAtributesPercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int AllCostMalus
        {
            get
            {
                if (this.effect == EffectTypes.AllCostMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllCostMalus;
                this.val = value;
            }
        }

        public virtual int AllDamageAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.AllDamageAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllDamageAbsorb;
                this.val = value;
            }
        }

        public virtual int AllDamageDoneBonus
        {
            get
            {
                if (this.effect == EffectTypes.AllDamageDoneBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllDamageDoneBonus;
                this.val = value;
            }
        }

        public virtual int AllDamageDoneMalus
        {
            get
            {
                if (this.effect == EffectTypes.AllDamageDoneMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllDamageDoneMalus;
                this.val = value;
            }
        }

        public virtual float AllDamageDoneModifier
        {
            get
            {
                if (this.effect == EffectTypes.AllDamageDoneModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.AllDamageDoneModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int AllMagicDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.AllMagicDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllMagicDamageIncrease;
                this.val = value;
            }
        }

        public virtual int AllResistanceBonus
        {
            get
            {
                if (this.effect == EffectTypes.AllResistanceBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllResistanceBonus;
                this.val = value;
            }
        }

        public virtual int AllResistanceMalus
        {
            get
            {
                if (this.effect == EffectTypes.AllResistanceMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AllResistanceMalus;
                this.val = value;
            }
        }

        public virtual float AllResistancePercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.AllResistancePercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.AllResistancePercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float AllResistancePercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.AllResistancePercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.AllResistancePercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int ArcaneAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneAbsorb;
                this.val = value;
            }
        }

        public virtual int ArcaneCostMalus
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneCostMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneCostMalus;
                this.val = value;
            }
        }

        public virtual int ArcaneCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneCriticalBonus;
                this.val = value;
            }
        }

        public virtual int ArcaneDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneDamageIncrease;
                this.val = value;
            }
        }

        public virtual int ArcaneDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int ArcaneDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual int ArcaneResistanceBonus
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneResistanceBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneResistanceBonus;
                this.val = value;
            }
        }

        public virtual int ArcaneResistanceMalus
        {
            get
            {
                if (this.effect == EffectTypes.ArcaneResistanceMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArcaneResistanceMalus;
                this.val = value;
            }
        }

        public virtual int ArmorBonus
        {
            get
            {
                if (this.effect == EffectTypes.ArmorBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArmorBonus;
                this.val = value;
            }
        }

        public virtual float ArmorFromItemsPercentIncrease
        {
            get
            {
                if (this.effect == EffectTypes.ArmorFromItemsPercentIncrease)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.ArmorFromItemsPercentIncrease;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int ArmorMalus
        {
            get
            {
                if (this.effect == EffectTypes.ArmorMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ArmorMalus;
                this.val = value;
            }
        }

        public virtual float ArmorPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.ArmorPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.ArmorPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float ArmorPercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.ArmorPercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.ArmorPercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int AttackPowerBonus
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerBonus;
                this.val = value;
            }
        }

        public virtual int AttackPowerBonusAgainsBeast
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerBonusAgainsBeast)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerBonusAgainsBeast;
                this.val = value;
            }
        }

        public virtual int AttackPowerBonusAgainsDemons
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerBonusAgainsDemons)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerBonusAgainsDemons;
                this.val = value;
            }
        }

        public virtual int AttackPowerBonusAgainsGiants
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerBonusAgainsGiants)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerBonusAgainsGiants;
                this.val = value;
            }
        }

        public virtual int AttackPowerBonusAgainsUndead
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerBonusAgainsUndead)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerBonusAgainsUndead;
                this.val = value;
            }
        }

        public virtual int AttackPowerMalus
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerMalus;
                this.val = value;
            }
        }

        public virtual int AttackPowerMalusAgainsBeast
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerMalusAgainsBeast)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerMalusAgainsBeast;
                this.val = value;
            }
        }

        public virtual int AttackPowerMalusAgainsDemons
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerMalusAgainsDemons)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerMalusAgainsDemons;
                this.val = value;
            }
        }

        public virtual int AttackPowerMalusAgainsGiants
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerMalusAgainsGiants)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerMalusAgainsGiants;
                this.val = value;
            }
        }

        public virtual int AttackPowerMalusAgainsUndead
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerMalusAgainsUndead)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerMalusAgainsUndead;
                this.val = value;
            }
        }

        public virtual float AttackPowerModifier
        {
            get
            {
                if (this.effect == EffectTypes.AttackPowerModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.AttackPowerModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float AttackSpeedModifier
        {
            get
            {
                if (this.effect == EffectTypes.AttackSpeedModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.AttackSpeedModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int AvoidCastMagicClass
        {
            get
            {
                if (this.effect == EffectTypes.AvoidCastMagicClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.AvoidCastMagicClass;
                this.val = value;
            }
        }

        public virtual int BlockBonus
        {
            get
            {
                if (this.effect == EffectTypes.BlockBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.BlockBonus;
                this.val = value;
            }
        }

        public virtual int BlockMalus
        {
            get
            {
                if (this.effect == EffectTypes.BlockMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.BlockMalus;
                this.val = value;
            }
        }

        public virtual int Bonus1BonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.Bonus1BonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.Bonus1BonusForAbility;
                this.val = value;
            }
        }

        public virtual int Bonus1EffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.Bonus1EffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.Bonus1EffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int Bonus1EffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.Bonus1EffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.Bonus1EffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float Bonus1ModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.Bonus1ModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.Bonus1ModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual bool CanSeeGreaterInvisibility
        {
            get
            {
                if (this.effect == EffectTypes.CanSeeGreaterInvisibility)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.CanSeeGreaterInvisibility;
            }
        }

        public virtual bool CanSeeLesserInvisibility
        {
            get
            {
                if (this.effect == EffectTypes.CanSeeLesserInvisibility)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.CanSeeLesserInvisibility;
            }
        }

        public virtual bool CanSeeMediumInvisibility
        {
            get
            {
                if (this.effect == EffectTypes.CanSeeMediumInvisibility)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.CanSeeMediumInvisibility;
            }
        }

        public virtual float CastingSpeedModifier
        {
            get
            {
                if (this.effect == EffectTypes.CastingSpeedModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.CastingSpeedModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int CastingTimeBonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.CastingTimeBonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CastingTimeBonusForAbility;
                this.val = value;
            }
        }

        public virtual int CastingTimeEffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.CastingTimeEffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CastingTimeEffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int CastingTimeEffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.CastingTimeEffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CastingTimeEffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float CastingTimeModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.CastingTimeModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.CastingTimeModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int CooldownBonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.CooldownBonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CooldownBonusForAbility;
                this.val = value;
            }
        }

        public virtual int CooldownEffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.CooldownEffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CooldownEffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int CooldownEffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.CooldownEffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CooldownEffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float CooldownModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.CooldownModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.CooldownModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int CostBonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.CostBonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CostBonusForAbility;
                this.val = value;
            }
        }

        public virtual int CostEffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.CostEffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CostEffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int CostEffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.CostEffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.CostEffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float CostModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.CostModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.CostModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int DamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.DamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.DamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int DamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.DamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.DamageTakenMalus;
                this.val = value;
            }
        }

        public virtual float DamageTakenModifier
        {
            get
            {
                if (this.effect == EffectTypes.DamageTakenModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.DamageTakenModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual bool DetectBeast
        {
            get
            {
                if (this.effect == EffectTypes.DetectBeast)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.DetectBeast;
            }
        }

        public virtual bool DetectHumanoid
        {
            get
            {
                if (this.effect == EffectTypes.DetectHumanoid)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.DetectHumanoid;
            }
        }

        public virtual bool DetectUndead
        {
            get
            {
                if (this.effect == EffectTypes.DetectUndead)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.DetectUndead;
            }
        }

        public virtual int DodgeBonus
        {
            get
            {
                if (this.effect == EffectTypes.DodgeBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.DodgeBonus;
                this.val = value;
            }
        }

        public virtual int DodgeMalus
        {
            get
            {
                if (this.effect == EffectTypes.DodgeMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.DodgeMalus;
                this.val = value;
            }
        }

        public virtual int DurationBonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.DurationBonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.DurationBonusForAbility;
                this.val = value;
            }
        }

        public virtual int DurationEffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.DurationEffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.DurationEffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int DurationEffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.DurationEffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.DurationEffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float DurationModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.DurationModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.DurationModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public bool FeatherFall
        {
            get
            {
                if (this.effect == EffectTypes.FeatherFall)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.FeatherFall;
            }
        }

        public virtual int FireAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.FireAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireAbsorb;
                this.val = value;
            }
        }

        public virtual int FireCostMalus
        {
            get
            {
                if (this.effect == EffectTypes.FireCostMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireCostMalus;
                this.val = value;
            }
        }

        public virtual int FireCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.FireCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireCriticalBonus;
                this.val = value;
            }
        }

        public virtual int FireDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.FireDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireDamageIncrease;
                this.val = value;
            }
        }

        public virtual int FireDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.FireDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int FireDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.FireDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual float FireDamageTakenModifier
        {
            get
            {
                if (this.effect == EffectTypes.FireDamageTakenModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.FireDamageTakenModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float FirePercentDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.FirePercentDamageIncrease)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.FirePercentDamageIncrease;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int FireResistanceBonus
        {
            get
            {
                if (this.effect == EffectTypes.FireResistanceBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireResistanceBonus;
                this.val = value;
            }
        }

        public virtual int FireResistanceMalus
        {
            get
            {
                if (this.effect == EffectTypes.FireResistanceMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FireResistanceMalus;
                this.val = value;
            }
        }

        public virtual Mobile ForceAttackTo
        {
            get
            {
                if (this.effect == EffectTypes.ForceAttackTo)
                {
                    return World.FindMobileByGUID((ulong) this.val);
                }
                return null;
            }
            set
            {
                foreach (Mobile.AuraReleaseTimer timer1 in value.Auras)
                {
                    if (timer1.aura.ForceAttackTo != null)
                    {
                        timer1.aura.Release(value);
                    }
                }
                this.effect = EffectTypes.ForceAttackTo;
                this.val = (int) value.Guid;
            }
        }

        public virtual bool ForceFlee
        {
            get
            {
                if ((this.effect == EffectTypes.ForceFlee) && (this.val == 1))
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ForceFlee;
                if (value)
                {
                    this.val = 1;
                }
                else
                {
                    this.val = 0;
                }
            }
        }

        public virtual bool ForceRoot
        {
            get
            {
                if (this.effect == EffectTypes.ForceRoot)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ForceRoot;
            }
        }

        public virtual bool ForceSilence
        {
            get
            {
                if (this.effect == EffectTypes.ForceSilence)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ForceSilence;
            }
        }

        public virtual bool ForceStun
        {
            get
            {
                if ((this.effect == EffectTypes.ForceStun) && (this.val == 1))
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ForceStun;
                if (value)
                {
                    this.val = 1;
                }
                else
                {
                    this.val = 0;
                }
            }
        }

        public virtual bool ForceUnInteractible
        {
            get
            {
                if (this.effect == EffectTypes.ForceUnInteractible)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ForceUnInteractible;
            }
        }

        public virtual int FrostAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.FrostAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostAbsorb;
                this.val = value;
            }
        }

        public virtual int FrostCostMalus
        {
            get
            {
                if (this.effect == EffectTypes.FrostCostMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostCostMalus;
                this.val = value;
            }
        }

        public virtual int FrostCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.FrostCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostCriticalBonus;
                this.val = value;
            }
        }

        public virtual int FrostDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.FrostDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostDamageIncrease;
                this.val = value;
            }
        }

        public virtual int FrostDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.FrostDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int FrostDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.FrostDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual float FrostPercentDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.FrostPercentDamageIncrease)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.FrostPercentDamageIncrease;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int FrostResistanceBonus
        {
            get
            {
                if (this.effect == EffectTypes.FrostResistanceBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostResistanceBonus;
                this.val = value;
            }
        }

        public virtual int FrostResistanceMalus
        {
            get
            {
                if (this.effect == EffectTypes.FrostResistanceMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.FrostResistanceMalus;
                this.val = value;
            }
        }

        public virtual int HealGiveDecrease
        {
            get
            {
                if (this.effect == EffectTypes.HealGiveDecrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HealGiveDecrease;
                this.val = value;
            }
        }

        public virtual int HealGiveIncrease
        {
            get
            {
                if (this.effect == EffectTypes.HealGiveIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HealGiveIncrease;
                this.val = value;
            }
        }

        public virtual float HealGiveModifier
        {
            get
            {
                if (this.effect == EffectTypes.HealGiveModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.HealGiveModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int HealTakeDecrease
        {
            get
            {
                if (this.effect == EffectTypes.HealTakeDecrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HealTakeDecrease;
                this.val = value;
            }
        }

        public virtual int HealTakeIncrease
        {
            get
            {
                if (this.effect == EffectTypes.HealTakeIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HealTakeIncrease;
                this.val = value;
            }
        }

        public virtual float HealTakeModifier
        {
            get
            {
                if (this.effect == EffectTypes.HealTakeModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.HealTakeModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int HealthBonus
        {
            get
            {
                if (this.effect == EffectTypes.HealthBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HealthBonus;
                this.val = value;
            }
        }

        public virtual int HealthMalus
        {
            get
            {
                if (this.effect == EffectTypes.HealthMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HealthMalus;
                this.val = value;
            }
        }

        public virtual float HealthPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.HealthPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.HealthPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float HealthRegenerationModifier
        {
            get
            {
                if (this.effect == EffectTypes.HealthRegenerationModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.HealthRegenerationModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float HealthRegenWhileFightingPercent
        {
            get
            {
                if (this.effect == EffectTypes.HealthRegenWhileFightingPercent)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.HealthRegenWhileFightingPercent;
                this.val = (int) (value * 1000f);
            }
        }

        public int HitBonus
        {
            get
            {
                if (this.effect == EffectTypes.HitBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HitBonus;
                this.val = value;
            }
        }

        public int HitMalus
        {
            get
            {
                if (this.effect == EffectTypes.HitMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HitMalus;
                this.val = value;
            }
        }

        public virtual int HolyAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.HolyAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyAbsorb;
                this.val = value;
            }
        }

        public virtual int HolyCostMalus
        {
            get
            {
                if (this.effect == EffectTypes.HolyCostMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyCostMalus;
                this.val = value;
            }
        }

        public virtual int HolyCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.HolyCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyCriticalBonus;
                this.val = value;
            }
        }

        public virtual int HolyDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.HolyDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyDamageIncrease;
                this.val = value;
            }
        }

        public virtual int HolyDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.HolyDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int HolyDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.HolyDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual int HolyResistanceBonus
        {
            get
            {
                if (this.effect == EffectTypes.HolyResistanceBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyResistanceBonus;
                this.val = value;
            }
        }

        public virtual int HolyResistanceMalus
        {
            get
            {
                if (this.effect == EffectTypes.HolyResistanceMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.HolyResistanceMalus;
                this.val = value;
            }
        }

        public virtual bool ImmuneAllSpellsAndAbilites
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneAllSpellsAndAbilites)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneAllSpellsAndAbilites;
            }
        }

        public virtual bool ImmuneAttack
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneAttack)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneAttack;
            }
        }

        public virtual bool ImmuneDisease
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneDisease)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneDisease;
            }
        }

        public virtual bool ImmuneFireSpell
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneFireSpell)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneFireSpell;
            }
        }

        public virtual bool ImmuneFrostSpell
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneFrostSpell)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneFrostSpell;
            }
        }

        public virtual bool ImmuneMagic
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneMagic)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneMagic;
            }
        }

        public virtual bool ImmunePhysicalDamage
        {
            get
            {
                if (this.effect == EffectTypes.ImmunePhysicalDamage)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmunePhysicalDamage;
            }
        }

        public virtual bool ImmunePoison
        {
            get
            {
                if (this.effect == EffectTypes.ImmunePoison)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmunePoison;
            }
        }

        public virtual bool ImmuneToDisarm
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneToDisarm)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneToDisarm;
            }
        }

        public virtual bool ImmuneToFear
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneToFear)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneToFear;
            }
        }

        public virtual bool ImmuneToImmobilization
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneToImmobilization)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneToImmobilization;
            }
        }

        public virtual bool ImmuneToKnockBack
        {
            get
            {
                if (this.effect == EffectTypes.ImmuneToKnockBack)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ImmuneToKnockBack;
            }
        }

        public virtual bool InteruptRegeneration
        {
            get
            {
                if ((this.effect == EffectTypes.InteruptRegeneration) && (this.val == 1))
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.InteruptRegeneration;
                if (value)
                {
                    this.val = 1;
                }
                else
                {
                    this.val = 0;
                }
            }
        }

        public virtual int IQBonus
        {
            get
            {
                if (this.effect == EffectTypes.IQBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.IQBonus;
                this.val = value;
            }
        }

        public virtual int IQMalus
        {
            get
            {
                if (this.effect == EffectTypes.IQMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.IQMalus;
                this.val = value;
            }
        }

        public virtual float IQPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.IQPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.IQPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float IQPercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.IQPercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.IQPercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int MagicalCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.MagicalCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MagicalCriticalBonus;
                this.val = value;
            }
        }

        public virtual int ManaBonus
        {
            get
            {
                if (this.effect == EffectTypes.ManaBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ManaBonus;
                this.val = value;
            }
        }

        public virtual int ManaMalus
        {
            get
            {
                if (this.effect == EffectTypes.ManaMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ManaMalus;
                this.val = value;
            }
        }

        public virtual float ManaPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.ManaPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.ManaPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float ManaRegenerationModifier
        {
            get
            {
                if (this.effect == EffectTypes.ManaRegenerationModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.ManaRegenerationModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float ManaRegenWhileCastingPercent
        {
            get
            {
                if (this.effect == EffectTypes.ManaRegenWhileCastingPercent)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.ManaRegenWhileCastingPercent;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int ManaShield
        {
            get
            {
                if (this.effect == EffectTypes.ManaShield)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ManaShield;
                this.val = value;
            }
        }

        public virtual int MeleeDamageBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageDoneAgainsBeastBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageDoneAgainsBeastBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageDoneAgainsBeastBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageDoneAgainsDemonsBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageDoneAgainsDemonsBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageDoneAgainsDemonsBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageDoneAgainsDragonsBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageDoneAgainsDragonsBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageDoneAgainsDragonsBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageDoneAgainsElementalsBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageDoneAgainsElementalsBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageDoneAgainsElementalsBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageDoneAgainsGiantsBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageDoneAgainsGiantsBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageDoneAgainsGiantsBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageDoneAgainsUndeadBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageDoneAgainsUndeadBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageDoneAgainsUndeadBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageMalus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageMalus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int MeleeDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeDamageTakenMalus;
                this.val = value;
            }
        }

        public int MeleeHitBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeHitBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeHitBonus;
                this.val = value;
            }
        }

        public int MeleeHitMalus
        {
            get
            {
                if (this.effect == EffectTypes.MeleeHitMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.MeleeHitMalus;
                this.val = value;
            }
        }

        public virtual float MeleePercentDamageBonus
        {
            get
            {
                if (this.effect == EffectTypes.MeleePercentDamageBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.MeleePercentDamageBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float MeleePercentDamageMalus
        {
            get
            {
                if (this.effect == EffectTypes.MeleePercentDamageMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.MeleePercentDamageMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float MeleePercentDamageTakenIncrease
        {
            get
            {
                if (this.effect == EffectTypes.MeleePercentDamageTakenIncrease)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.MeleePercentDamageTakenIncrease;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float MeleePercentDamageTakenReduction
        {
            get
            {
                if (this.effect == EffectTypes.MeleePercentDamageTakenReduction)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.MeleePercentDamageTakenReduction;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float MountSpeedBonus
        {
            get
            {
                if (this.effect == EffectTypes.MountSpeedBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.MountSpeedBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float MountSpeedMalus
        {
            get
            {
                if (this.effect == EffectTypes.MountSpeedMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.MountSpeedMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float MountSpeedModifier
        {
            get
            {
                if (this.effect == EffectTypes.MountSpeedModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.MountSpeedModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int NatureAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.NatureAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureAbsorb;
                this.val = value;
            }
        }

        public virtual int NatureCostMalus
        {
            get
            {
                if (this.effect == EffectTypes.NatureCostMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureCostMalus;
                this.val = value;
            }
        }

        public virtual int NatureCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.NatureCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureCriticalBonus;
                this.val = value;
            }
        }

        public virtual int NatureDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.NatureDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureDamageIncrease;
                this.val = value;
            }
        }

        public virtual int NatureDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.NatureDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int NatureDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.NatureDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual float NaturePercentDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.NaturePercentDamageIncrease)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.NaturePercentDamageIncrease;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int NatureResistanceBonus
        {
            get
            {
                if (this.effect == EffectTypes.NatureResistanceBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureResistanceBonus;
                this.val = value;
            }
        }

        public virtual int NatureResistanceMalus
        {
            get
            {
                if (this.effect == EffectTypes.NatureResistanceMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.NatureResistanceMalus;
                this.val = value;
            }
        }

        public virtual int OnCriticalHit
        {
            get
            {
                if (this.effect == EffectTypes.OnCriticalHit)
                {
                    return this.val;
                }
                return -1;
            }
            set
            {
                this.effect = EffectTypes.OnCriticalHit;
                this.val = value;
            }
        }

        public virtual int OnCriticalHitDone
        {
            get
            {
                if (this.effect == EffectTypes.OnCriticalHitDone)
                {
                    return this.val;
                }
                return -1;
            }
            set
            {
                this.effect = EffectTypes.OnCriticalHitDone;
                this.val = value;
            }
        }

        public virtual int OnMeleeHit
        {
            get
            {
                if (this.effect == EffectTypes.OnMeleeHit)
                {
                    return this.val;
                }
                return -1;
            }
            set
            {
                this.effect = EffectTypes.OnMeleeHit;
                this.val = value;
            }
        }

        public virtual int OnMeleeHitDone
        {
            get
            {
                if (this.effect == EffectTypes.OnMeleeHitDone)
                {
                    return this.val;
                }
                return -1;
            }
            set
            {
                this.effect = EffectTypes.OnMeleeHitDone;
                this.val = value;
            }
        }

        public virtual int OnSpellHit
        {
            get
            {
                if (this.effect == EffectTypes.OnSpellHit)
                {
                    return this.val;
                }
                return -1;
            }
            set
            {
                this.effect = EffectTypes.OnSpellHit;
                this.val = value;
            }
        }

        public virtual int OnSpellHitDone
        {
            get
            {
                if (this.effect == EffectTypes.OnSpellHitDone)
                {
                    return this.val;
                }
                return -1;
            }
            set
            {
                this.effect = EffectTypes.OnSpellHitDone;
                this.val = value;
            }
        }

        public virtual int ParryBonus
        {
            get
            {
                if (this.effect == EffectTypes.ParryBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ParryBonus;
                this.val = value;
            }
        }

        public virtual int ParryMalus
        {
            get
            {
                if (this.effect == EffectTypes.ParryMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ParryMalus;
                this.val = value;
            }
        }

        public virtual int PetDamageBonus
        {
            get
            {
                if (this.effect == EffectTypes.PetDamageBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.PetDamageBonus;
                this.val = value;
            }
        }

        public virtual int PetDamageMalus
        {
            get
            {
                if (this.effect == EffectTypes.PetDamageMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.PetDamageMalus;
                this.val = value;
            }
        }

        public virtual int PhysicalAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.PhysicalAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.PhysicalAbsorb;
                this.val = value;
            }
        }

        public virtual int PhysicalCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.PhysicalCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.PhysicalCriticalBonus;
                this.val = value;
            }
        }

        public virtual int PhysicalDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.PhysicalDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.PhysicalDamageIncrease;
                this.val = value;
            }
        }

        public virtual int PhysicalDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.PhysicalDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.PhysicalDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int PhysicalDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.PhysicalDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.PhysicalDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual float PhysicalPercentDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.PhysicalPercentDamageIncrease)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.PhysicalPercentDamageIncrease;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float PowerCostModifier
        {
            get
            {
                if (this.effect == EffectTypes.PowerCostModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.PowerCostModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int RadiusBonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.RadiusBonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RadiusBonusForAbility;
                this.val = value;
            }
        }

        public virtual int RadiusEffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.RadiusEffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RadiusEffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int RadiusEffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.RadiusEffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RadiusEffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float RadiusModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.RadiusModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.RadiusModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float RageGenerationModifier
        {
            get
            {
                if (this.effect == EffectTypes.RageGenerationModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.RageGenerationModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int RangeBonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.RangeBonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangeBonusForAbility;
                this.val = value;
            }
        }

        public virtual int RangedAttackPowerBonus
        {
            get
            {
                if (this.effect == EffectTypes.RangedAttackPowerBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangedAttackPowerBonus;
                this.val = value;
            }
        }

        public virtual int RangedAttackPowerMalus
        {
            get
            {
                if (this.effect == EffectTypes.RangedAttackPowerMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangedAttackPowerMalus;
                this.val = value;
            }
        }

        public virtual float RangedAttackSpeedModifier
        {
            get
            {
                if (this.effect == EffectTypes.RangedAttackSpeedModifier)
                {
                    return (float) (this.val / 0x3e8);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.RangedAttackSpeedModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int RangedDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.RangedDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangedDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int RangedDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.RangedDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangedDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual float RangedDamageTakenModifier
        {
            get
            {
                if (this.effect == EffectTypes.RangedDamageTakenModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.RangedDamageTakenModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public int RangedHitBonus
        {
            get
            {
                if (this.effect == EffectTypes.RangedHitBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangedHitBonus;
                this.val = value;
            }
        }

        public int RangedHitMalus
        {
            get
            {
                if (this.effect == EffectTypes.RangedHitMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangedHitMalus;
                this.val = value;
            }
        }

        public virtual int RangeEffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.RangeEffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangeEffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int RangeEffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.RangeEffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.RangeEffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float RangeModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.RangeModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.RangeModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int ReflectFireChance
        {
            get
            {
                if (this.effect == EffectTypes.ReflectFireChance)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ReflectFireChance;
                this.val = value;
            }
        }

        public virtual int ReflectFrostChance
        {
            get
            {
                if (this.effect == EffectTypes.ReflectFrostChance)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ReflectFrostChance;
                this.val = value;
            }
        }

        public virtual int ReflectMagicChance
        {
            get
            {
                if (this.effect == EffectTypes.ReflectMagicChance)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ReflectMagicChance;
                this.val = value;
            }
        }

        public virtual int ReflectShadowChance
        {
            get
            {
                if (this.effect == EffectTypes.ReflectShadowChance)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ReflectShadowChance;
                this.val = value;
            }
        }

        public virtual float RunSpeedBonus
        {
            get
            {
                if (this.effect == EffectTypes.RunSpeedBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.RunSpeedBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float RunSpeedMalus
        {
            get
            {
                if (this.effect == EffectTypes.RunSpeedMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.RunSpeedMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float RunSpeedModifier
        {
            get
            {
                if (this.effect == EffectTypes.RunSpeedModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.RunSpeedModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int S1BonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.S1BonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S1BonusForAbility;
                this.val = value;
            }
        }

        public virtual int S1EffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.S1EffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S1EffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int S1EffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.S1EffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S1EffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float S1ModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.S1ModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.S1ModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int S2BonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.S2BonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S2BonusForAbility;
                this.val = value;
            }
        }

        public virtual int S2EffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.S2EffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S2EffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int S2EffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.S2EffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S2EffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float S2ModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.S2ModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.S2ModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int S3BonusForAbility
        {
            get
            {
                if (this.effect == EffectTypes.S3BonusForAbility)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S3BonusForAbility;
                this.val = value;
            }
        }

        public virtual int S3EffectedAbilityClass
        {
            get
            {
                if (this.effect == EffectTypes.S3EffectedAbilityClass)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S3EffectedAbilityClass;
                this.val = value;
            }
        }

        public virtual int S3EffectedAbilityList
        {
            get
            {
                if (this.effect == EffectTypes.S3EffectedAbilityList)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.S3EffectedAbilityList;
                this.val = value;
            }
        }

        public virtual float S3ModificatorForAbility
        {
            get
            {
                if (this.effect == EffectTypes.S3ModificatorForAbility)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.S3ModificatorForAbility;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int ShadowAbsorb
        {
            get
            {
                if (this.effect == EffectTypes.ShadowAbsorb)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowAbsorb;
                this.val = value;
            }
        }

        public virtual int ShadowCostMalus
        {
            get
            {
                if (this.effect == EffectTypes.ShadowCostMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowCostMalus;
                this.val = value;
            }
        }

        public virtual int ShadowCriticalBonus
        {
            get
            {
                if (this.effect == EffectTypes.ShadowCriticalBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowCriticalBonus;
                this.val = value;
            }
        }

        public virtual int ShadowDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.ShadowDamageIncrease)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowDamageIncrease;
                this.val = value;
            }
        }

        public virtual int ShadowDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.ShadowDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int ShadowDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.ShadowDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowDamageTakenMalus;
                this.val = value;
            }
        }

        public virtual float ShadowDamageTakenModifier
        {
            get
            {
                if (this.effect == EffectTypes.ShadowDamageTakenModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.ShadowDamageTakenModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float ShadowPercentDamageIncrease
        {
            get
            {
                if (this.effect == EffectTypes.ShadowPercentDamageIncrease)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.ShadowPercentDamageIncrease;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int ShadowResistanceBonus
        {
            get
            {
                if (this.effect == EffectTypes.ShadowResistanceBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowResistanceBonus;
                this.val = value;
            }
        }

        public virtual int ShadowResistanceMalus
        {
            get
            {
                if (this.effect == EffectTypes.ShadowResistanceMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShadowResistanceMalus;
                this.val = value;
            }
        }

        public bool ShadowTrance
        {
            get
            {
                if (this.effect == EffectTypes.ShadowTrance)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ShadowTrance;
            }
        }

        public virtual bool ShareDamageWithPet
        {
            get
            {
                if (this.effect == EffectTypes.ShareDamageWithPet)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.ShareDamageWithPet;
            }
        }

        public virtual int ShieldBlockBonus
        {
            get
            {
                if (this.effect == EffectTypes.ShieldBlockBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.ShieldBlockBonus;
                this.val = value;
            }
        }

        public virtual float ShieldBlockModifier
        {
            get
            {
                if (this.effect == EffectTypes.ShieldBlockModifier)
                {
                    return (float) this.val;
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.ShieldBlockModifier;
                this.val = ((int) value) * 0x3e8;
            }
        }

        public virtual int SkillBonus
        {
            get
            {
                if (this.effect == EffectTypes.SkillBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SkillBonus;
                this.val = value;
            }
        }

        public virtual int SkillId
        {
            get
            {
                if (this.effect == EffectTypes.SkillId)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SkillId;
                this.val = value;
            }
        }

        public virtual int SkillMalus
        {
            get
            {
                if (this.effect == EffectTypes.SkillMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SkillMalus;
                this.val = value;
            }
        }

        public virtual SpecialStates SpecialState
        {
            get
            {
                if (this.effect == EffectTypes.SpecialState)
                {
                    return (SpecialStates) this.val;
                }
                return SpecialStates.None;
            }
            set
            {
                this.effect = EffectTypes.SpecialState;
                this.val = (int) value;
            }
        }

        public virtual int SpecialStateFrom
        {
            get
            {
                if (this.effect == EffectTypes.SpecialStateFrom)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpecialStateFrom;
                this.val = value;
            }
        }

        public virtual float SpeedBonus
        {
            get
            {
                if (this.effect == EffectTypes.SpeedBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.SpeedBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float SpeedMalus
        {
            get
            {
                if (this.effect == EffectTypes.SpeedMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.SpeedMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float SpeedModifier
        {
            get
            {
                if (this.effect == EffectTypes.SpeedModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.SpeedModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int SpellDamageDoneAgainsDemonsBonus
        {
            get
            {
                if (this.effect == EffectTypes.SpellDamageDoneAgainsDemonsBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpellDamageDoneAgainsDemonsBonus;
                this.val = value;
            }
        }

        public virtual int SpellDamageDoneAgainsUndeadBonus
        {
            get
            {
                if (this.effect == EffectTypes.SpellDamageDoneAgainsUndeadBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpellDamageDoneAgainsUndeadBonus;
                this.val = value;
            }
        }

        public virtual int SpellDamageTakenBonus
        {
            get
            {
                if (this.effect == EffectTypes.SpellDamageTakenBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpellDamageTakenBonus;
                this.val = value;
            }
        }

        public virtual int SpellDamageTakenMalus
        {
            get
            {
                if (this.effect == EffectTypes.SpellDamageTakenMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpellDamageTakenMalus;
                this.val = value;
            }
        }

        public int SpellHitBonus
        {
            get
            {
                if (this.effect == EffectTypes.SpellHitBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpellHitBonus;
                this.val = value;
            }
        }

        public int SpellHitMalus
        {
            get
            {
                if (this.effect == EffectTypes.SpellHitMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpellHitMalus;
                this.val = value;
            }
        }

        public virtual int SpiritBonus
        {
            get
            {
                if (this.effect == EffectTypes.SpiritBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpiritBonus;
                this.val = value;
            }
        }

        public virtual int SpiritMalus
        {
            get
            {
                if (this.effect == EffectTypes.SpiritMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.SpiritMalus;
                this.val = value;
            }
        }

        public virtual float SpiritPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.SpiritPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.SpiritPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float SpiritPercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.SpiritPercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.SpiritPercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int StaminaBonus
        {
            get
            {
                if (this.effect == EffectTypes.StaminaBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.StaminaBonus;
                this.val = value;
            }
        }

        public virtual int StaminaMalus
        {
            get
            {
                if (this.effect == EffectTypes.StaminaMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.StaminaMalus;
                this.val = value;
            }
        }

        public virtual float StaminaPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.StaminaPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.StaminaPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float StaminaPercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.StaminaPercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.StaminaPercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual int StrBonus
        {
            get
            {
                if (this.effect == EffectTypes.StrBonus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.StrBonus;
                this.val = value;
            }
        }

        public virtual int StrMalus
        {
            get
            {
                if (this.effect == EffectTypes.StrMalus)
                {
                    return this.val;
                }
                return 0;
            }
            set
            {
                this.effect = EffectTypes.StrMalus;
                this.val = value;
            }
        }

        public virtual float StrPercentBonus
        {
            get
            {
                if (this.effect == EffectTypes.StrPercentBonus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.StrPercentBonus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float StrPercentMalus
        {
            get
            {
                if (this.effect == EffectTypes.StrPercentMalus)
                {
                    return (((float) this.val) / 1000f);
                }
                return 0f;
            }
            set
            {
                this.effect = EffectTypes.StrPercentMalus;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual float SwimSpeedModifier
        {
            get
            {
                if (this.effect == EffectTypes.SwimSpeedModifier)
                {
                    return (((float) this.val) / 1000f);
                }
                return 1f;
            }
            set
            {
                this.effect = EffectTypes.SwimSpeedModifier;
                this.val = (int) (value * 1000f);
            }
        }

        public virtual bool SwitchToRage
        {
            get
            {
                if (this.effect == EffectTypes.SwitchToRage)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.SwitchToRage;
            }
        }

        public bool WaterWalking
        {
            get
            {
                if (this.effect == EffectTypes.WaterWalking)
                {
                    return true;
                }
                return false;
            }
            set
            {
                this.effect = EffectTypes.WaterWalking;
            }
        }


        // Fields
        public AuraPeriodicTimer auraPeriodicTimer;
        protected EffectTypes effect;
        public object OnRelease;
        private int val;

        // Nested Types
        public delegate void AuraPeriodicEffect();


        public class AuraPeriodicTimer : WowTimer
        {
            // Methods
            public AuraPeriodicTimer(Aura.AuraPeriodicEffect ape, int dur, int freq) : base((double) freq)
            {
                this.duration = dur;
                this.frequency = freq;
                this.auraPeriodicEffect = ape;
                base.Start();
            }

            public override void OnTick()
            {
                this.auraPeriodicEffect();
                this.duration -= this.frequency;
                if (this.duration <= 0)
                {
                    base.Stop();
                }
                base.OnTick();
            }


            // Fields
            private Aura.AuraPeriodicEffect auraPeriodicEffect;
            private int duration;
            private int frequency;
        }

        public delegate void AuraReleaseDelegate(Mobile m);


        public delegate void ItemAuraReleaseDelegate(Mobile m, Item i);

    }
}

