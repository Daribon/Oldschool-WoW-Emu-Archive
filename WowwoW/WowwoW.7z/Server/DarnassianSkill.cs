namespace Server
{
    using System;

    public class DarnassianSkill : Skill
    {
        // Methods
        public DarnassianSkill()
        {
        }

        public DarnassianSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x71;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x71;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0x29f;
            }
        }

    }
}

