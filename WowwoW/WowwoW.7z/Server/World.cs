namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;
    using System.IO;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Threading;

    public class World
    {
        // Methods
        static World()
        {
            World.allConnectedChars = new ArrayList();
            World.allConnectedAccounts = new Accounts();
            World.allSpawners = new SpawnerList();
            World.itemPool = new Hashtable();
            World.mobilePool = new Hashtable();
            World.questPool = new Hashtable();
            World.questPoolType = new Hashtable();
            World.timers = new Queue[9];
            World.notEnded = true;
            World.tempMobileCts = new Hashtable();
            World.zoneIds = new Hashtable();
            World.zones = new Hashtable();
            World.map = new Hashtable();
            World.FishZones = new FishingZones();
            World.tempBuff = new byte[0x100000];
            World.ServerIP = "127.0.0.1";
            World.AllowHttpFrom = "0.0.0.0";
            World.ServerName = "-=Dune=-";
            World.ServerPort = 0x1f95;
            World.HttpServerPort = 0x1f98;
            World.Cemetery = new ArrayList();
            World.Emote = new Hashtable();
            World.DecayTime = 0x1d4c0;
            World.Locations = new Hashtable();
            World.Version = "Alpha 7.4";
            World.MountsList = new Hashtable();
            World.continent = new Hashtable();
            World.continentZones = new Hashtable();
            World.PendingGroup = new ArrayList();
            World.loading = true;
            World.poolsReady = false;
            World.Path = "./";
            World.DropMultiplier = 1f;
            World.DropGoldMultiplier = 1;
            World.FreeForAll = true;
            World.FriendRaces = new Hashtable();
            World.ViewingDistance = new int[0x3d];
            World.regSpawners = new Hashtable();
            World.GameObjectsAssociated = new GameObjectsList();
            World.factionsAssociated = new Hashtable();
            World.allMobs = new ArrayList();
            World.startingTime = DateTime.Now;
            World.total = 0;
            World.localTime = new long[4];
            World.datetime = DateTime.Now;
        }

        public World()
        {
            this.lastCall = new long[9];
            this.itemsHash = new Hashtable();
            World.map[0x144] = 0;
            World.zones[0x144] = 0x2d;
            World.zoneIds[0x144] = 0x38;
            World.map[0x147] = 0;
            World.zones[0x147] = 0x2d;
            World.zoneIds[0x147] = 0x3b;
            World.map[330] = 0;
            World.zones[330] = 330;
            World.zoneIds[330] = 60;
            World.map[0x14c] = 1;
            World.zones[0x14c] = 0x14c;
            World.zoneIds[0x14c] = 0x3e;
            World.map[0x14f] = 0;
            World.zones[0x14f] = 0x2d;
            World.zoneIds[0x14f] = 0x41;
            World.map[0x155] = 0;
            World.zones[0x155] = 3;
            World.zoneIds[0x155] = 0x45;
            World.map[0x156] = 0;
            World.zones[0x156] = 3;
            World.zoneIds[0x156] = 70;
            World.map[0x157] = 0;
            World.zones[0x157] = 3;
            World.zoneIds[0x157] = 0x47;
            World.map[0x159] = 0;
            World.zones[0x159] = 3;
            World.zoneIds[0x159] = 0x49;
            World.map[0x15a] = 0;
            World.zones[0x15a] = 3;
            World.zoneIds[0x15a] = 0x4a;
            World.map[0x15d] = 0;
            World.zones[0x15d] = 0x2f;
            World.zoneIds[0x15d] = 0x4d;
            World.map[0x15f] = 0;
            World.zones[0x15f] = 0x2f;
            World.zoneIds[0x15f] = 0x4f;
            World.map[0x160] = 0;
            World.zones[0x160] = 0x2f;
            World.zoneIds[0x160] = 80;
            World.map[0x161] = 0;
            World.zones[0x161] = 0x2f;
            World.zoneIds[0x161] = 0x51;
            World.map[0x164] = 0;
            World.zones[0x164] = 0x2f;
            World.zoneIds[0x164] = 0x52;
            World.map[0x167] = 1;
            World.zones[0x167] = 0x11;
            World.zoneIds[0x167] = 0x55;
            World.map[360] = 1;
            World.zones[360] = 0xd7;
            World.zoneIds[360] = 0x56;
            World.map[0x169] = 1;
            World.zones[0x169] = 0x169;
            World.zoneIds[0x169] = 0x57;
            World.map[0x16b] = 1;
            World.zones[0x16b] = 14;
            World.zoneIds[0x16b] = 0x59;
            World.map[0x16f] = 1;
            World.zones[0x16f] = 14;
            World.zoneIds[0x16f] = 0x5d;
            World.map[0x171] = 1;
            World.zones[0x171] = 14;
            World.zoneIds[0x171] = 0x5f;
            World.map[0x174] = 1;
            World.zones[0x174] = 14;
            World.zoneIds[0x174] = 0x61;
            World.map[0x176] = 1;
            World.zones[0x176] = 14;
            World.zoneIds[0x176] = 0x63;
            World.map[0x177] = 1;
            World.zones[0x177] = 14;
            World.zoneIds[0x177] = 100;
            World.map[0x17a] = 1;
            World.zones[0x17a] = 0x11;
            World.zoneIds[0x17a] = 0x66;
            World.map[380] = 1;
            World.zones[380] = 0x11;
            World.zoneIds[380] = 0x68;
            World.map[0x180] = 1;
            World.zones[0x180] = 0x11;
            World.zoneIds[0x180] = 0x6b;
            World.map[0x181] = 1;
            World.zones[0x181] = 0x11;
            World.zoneIds[0x181] = 0x6c;
            World.map[0x182] = 1;
            World.zones[0x182] = 0x11;
            World.zoneIds[0x182] = 0x6d;
            World.map[0x184] = 1;
            World.zones[0x184] = 0x11;
            World.zoneIds[0x184] = 110;
            World.map[0x187] = 1;
            World.zones[0x187] = 0x11;
            World.zoneIds[0x187] = 0x70;
            World.map[0x18a] = 0;
            World.zones[0x18a] = 0x18a;
            World.zoneIds[0x18a] = 0x73;
            World.map[0x18d] = 1;
            World.zones[0x18d] = 0xd7;
            World.zoneIds[0x18d] = 0x76;
            World.map[1] = 0;
            World.zones[1] = 1;
            World.zoneIds[1] = 0x77;
            World.map[4] = 0;
            World.zones[4] = 4;
            World.zoneIds[4] = 0x7a;
            World.map[8] = 0;
            World.zones[8] = 8;
            World.zoneIds[8] = 0x7c;
            World.map[15] = 1;
            World.zones[15] = 15;
            World.zoneIds[15] = 0x80;
            World.map[0x12] = 0;
            World.zones[0x12] = 12;
            World.zoneIds[0x12] = 0x83;
            World.map[20] = 0;
            World.zones[20] = 40;
            World.zoneIds[20] = 0x84;
            World.map[0x15] = 0;
            World.zones[0x15] = 0x15;
            World.zoneIds[0x15] = 0x85;
            World.map[30] = 0;
            World.zones[30] = 30;
            World.zoneIds[30] = 0x8a;
            World.map[0x20] = 0;
            World.zones[0x20] = 10;
            World.zoneIds[0x20] = 0x8b;
            World.map[0x21] = 0;
            World.zones[0x21] = 0x21;
            World.zoneIds[0x21] = 140;
            World.map[0x23] = 0;
            World.zones[0x23] = 0x21;
            World.zoneIds[0x23] = 0x8e;
            World.map[0x25] = 0;
            World.zones[0x25] = 0x21;
            World.zoneIds[0x25] = 0x90;
            World.map[0x26] = 0;
            World.zones[0x26] = 0x26;
            World.zoneIds[0x26] = 0x91;
            World.map[40] = 0;
            World.zones[40] = 40;
            World.zoneIds[40] = 0x92;
            World.map[0x2a] = 0;
            World.zones[0x2a] = 10;
            World.zoneIds[0x2a] = 0x93;
            World.map[0x2b] = 0;
            World.zones[0x2b] = 0x21;
            World.zoneIds[0x2b] = 0x94;
            World.map[0x2f] = 0;
            World.zones[0x2f] = 0x2f;
            World.zoneIds[0x2f] = 0x98;
            World.map[0x31] = 0;
            World.zones[0x31] = 0x16;
            World.zoneIds[0x31] = 0x99;
            World.map[0x33] = 0;
            World.zones[0x33] = 0x33;
            World.zoneIds[0x33] = 0x9a;
            World.map[0x35] = 0;
            World.zones[0x35] = 12;
            World.zoneIds[0x35] = 0x9b;
            World.map[0x37] = 0;
            World.zones[0x37] = 12;
            World.zoneIds[0x37] = 0x9c;
            World.map[0x38] = 0;
            World.zones[0x38] = 12;
            World.zoneIds[0x38] = 0x9d;
            World.map[0x3d] = 0;
            World.zones[0x3d] = 12;
            World.zoneIds[0x3d] = 160;
            World.map[0x3f] = 0;
            World.zones[0x3f] = 12;
            World.zoneIds[0x3f] = 0xa2;
            World.map[0x42] = 1;
            World.zones[0x42] = 0x42;
            World.zoneIds[0x42] = 0xa5;
            World.map[0x45] = 0;
            World.zones[0x45] = 0x2c;
            World.zoneIds[0x45] = 0xa7;
            World.map[70] = 0;
            World.zones[70] = 0x2c;
            World.zoneIds[70] = 0xa8;
            World.map[0x4a] = 0;
            World.zones[0x4a] = 8;
            World.zoneIds[0x4a] = 0xab;
            World.map[0x4c] = 0;
            World.zones[0x4c] = 8;
            World.zoneIds[0x4c] = 0xad;
            World.map[80] = 0;
            World.zones[80] = 12;
            World.zoneIds[80] = 0xaf;
            World.map[0x52] = 0x1c3;
            World.zones[0x52] = 0x16;
            World.zoneIds[0x52] = 0xb0;
            World.map[0x55] = 0;
            World.zones[0x55] = 0x55;
            World.zoneIds[0x55] = 0xb3;
            World.map[0x56] = 0;
            World.zones[0x56] = 12;
            World.zoneIds[0x56] = 180;
            World.map[0x58] = 0;
            World.zones[0x58] = 12;
            World.zoneIds[0x58] = 0xb5;
            World.map[0x59] = 0;
            World.zones[0x59] = 12;
            World.zoneIds[0x59] = 0xb6;
            World.map[0x5e] = 0;
            World.zones[0x5e] = 10;
            World.zoneIds[0x5e] = 0xb8;
            World.map[0x60] = 0;
            World.zones[0x60] = 0x2c;
            World.zoneIds[0x60] = 0xba;
            World.map[0x61] = 0;
            World.zones[0x61] = 0x2c;
            World.zoneIds[0x61] = 0xbb;
            World.map[0x65] = 0;
            World.zones[0x65] = 0x21;
            World.zoneIds[0x65] = 190;
            World.map[0x67] = 0;
            World.zones[0x67] = 0x21;
            World.zoneIds[0x67] = 0xbf;
            World.map[0x6a] = 0;
            World.zones[0x6a] = 0x21;
            World.zoneIds[0x6a] = 0xc2;
            World.map[0x6b] = 0;
            World.zones[0x6b] = 40;
            World.zoneIds[0x6b] = 0xc3;
            World.map[0x73] = 0;
            World.zones[0x73] = 40;
            World.zoneIds[0x73] = 0xc7;
            World.map[0x74] = 0;
            World.zones[0x74] = 8;
            World.zoneIds[0x74] = 200;
            World.map[0x76] = 0;
            World.zones[0x76] = 11;
            World.zoneIds[0x76] = 0xc9;
            World.map[0x7b] = 0;
            World.zones[0x7b] = 0x21;
            World.zoneIds[0x7b] = 0xcc;
            World.map[0x7e] = 0;
            World.zones[0x7e] = 0x21;
            World.zoneIds[0x7e] = 0xce;
            World.map[0x7f] = 0;
            World.zones[0x7f] = 0x21;
            World.zoneIds[0x7f] = 0xcf;
            World.map[0x80] = 0;
            World.zones[0x80] = 0x21;
            World.zoneIds[0x80] = 0xd0;
            World.map[0x81] = 0;
            World.zones[0x81] = 0x21;
            World.zoneIds[0x81] = 0xd1;
            World.map[0x84] = 0;
            World.zones[0x84] = 1;
            World.zoneIds[0x84] = 0xd4;
            World.map[0x85] = 0;
            World.zones[0x85] = 1;
            World.zoneIds[0x85] = 0xd5;
            World.map[0x87] = 0;
            World.zones[0x87] = 1;
            World.zoneIds[0x87] = 0xd7;
            World.map[0x89] = 0;
            World.zones[0x89] = 1;
            World.zoneIds[0x89] = 0xd9;
            World.map[0x8e] = 0;
            World.zones[0x8e] = 0x26;
            World.zoneIds[0x8e] = 0xdd;
            World.map[0x8f] = 0;
            World.zones[0x8f] = 0x26;
            World.zoneIds[0x8f] = 0xde;
            World.map[0x90] = 0;
            World.zones[0x90] = 0x26;
            World.zoneIds[0x90] = 0xdf;
            World.map[0x91] = 0;
            World.zones[0x91] = 0x26;
            World.zoneIds[0x91] = 0xe0;
            World.map[0x93] = 0;
            World.zones[0x93] = 0x26;
            World.zoneIds[0x93] = 0xe2;
            World.map[0x9a] = 0;
            World.zones[0x9a] = 0x55;
            World.zoneIds[0x9a] = 0xe7;
            World.map[0x9b] = 0;
            World.zones[0x9b] = 0x55;
            World.zoneIds[0x9b] = 0xe8;
            World.map[0x9e] = 0;
            World.zones[0x9e] = 0x55;
            World.zoneIds[0x9e] = 0xeb;
            World.map[160] = 0;
            World.zones[160] = 0x55;
            World.zoneIds[160] = 0xed;
            World.map[0xa1] = 0;
            World.zones[0xa1] = 0x55;
            World.zoneIds[0xa1] = 0xee;
            World.map[0xa8] = 0;
            World.zones[0xa8] = 0x55;
            World.zoneIds[0xa8] = 0xf5;
            World.map[170] = 0;
            World.zones[170] = 170;
            World.zoneIds[170] = 0xf6;
            World.map[0xac] = 0;
            World.zones[0xac] = 130;
            World.zoneIds[0xac] = 0xf7;
            World.map[0xbd] = 0;
            World.zones[0xbd] = 1;
            World.zoneIds[0xbd] = 0xf9;
            World.map[190] = 0;
            World.zones[190] = 0x1c;
            World.zoneIds[190] = 250;
            World.map[0xc6] = 0;
            World.zones[0xc6] = 0x1c;
            World.zoneIds[0xc6] = 0xff;
            World.map[0xc7] = 0;
            World.zones[0xc7] = 0x1c;
            World.zoneIds[0xc7] = 0x100;
            World.map[200] = 0;
            World.zones[200] = 0x1c;
            World.zoneIds[200] = 0x101;
            World.map[0xca] = 0;
            World.zones[0xca] = 0x1c;
            World.zoneIds[0xca] = 0x103;
            World.map[0xcb] = 0;
            World.zones[0xcb] = 0x1c;
            World.zoneIds[0xcb] = 260;
            World.map[0xcf] = 0x24;
            World.zones[0xcf] = 0xcf;
            World.zoneIds[0xcf] = 0x108;
            World.map[0xd0] = 0x24;
            World.zones[0xd0] = 0xd0;
            World.zoneIds[0xd0] = 0x109;
            World.map[210] = 0x24;
            World.zones[210] = 210;
            World.zoneIds[210] = 0x10b;
            World.map[0xd5] = 0;
            World.zones[0xd5] = 130;
            World.zoneIds[0xd5] = 270;
            World.map[0xd6] = 0;
            World.zones[0xd6] = 0xd6;
            World.zoneIds[0xd6] = 0x10f;
            World.map[0xd7] = 1;
            World.zones[0xd7] = 0xd7;
            World.zoneIds[0xd7] = 0x110;
            World.map[0xde] = 1;
            World.zones[0xde] = 0xd7;
            World.zoneIds[0xde] = 0x113;
            World.map[0xfb] = 0;
            World.zones[0xfb] = 0x2e;
            World.zoneIds[0xfb] = 2;
            World.map[0xfc] = 0;
            World.zones[0xfc] = 0x2e;
            World.zoneIds[0xfc] = 3;
            World.map[0x100] = 1;
            World.zones[0x100] = 0x8d;
            World.zoneIds[0x100] = 6;
            World.map[0x102] = 1;
            World.zones[0x102] = 0x8d;
            World.zoneIds[0x102] = 8;
            World.map[0x103] = 1;
            World.zones[0x103] = 0x8d;
            World.zoneIds[0x103] = 9;
            World.map[260] = 1;
            World.zones[260] = 0x8d;
            World.zoneIds[260] = 10;
            World.map[0x106] = 1;
            World.zones[0x106] = 0x8d;
            World.zoneIds[0x106] = 12;
            World.map[0x10a] = 1;
            World.zones[0x10a] = 0x8d;
            World.zoneIds[0x10a] = 0x10;
            World.map[0x10b] = 0;
            World.zones[0x10b] = 0x10b;
            World.zoneIds[0x10b] = 0x11;
            World.map[0x10d] = 0;
            World.zones[0x10d] = 0x10d;
            World.zoneIds[0x10d] = 0x12;
            World.map[0x113] = 0;
            World.zones[0x113] = 0x10b;
            World.zoneIds[0x113] = 20;
            World.map[0x117] = 0;
            World.zones[0x117] = 0x24;
            World.zoneIds[0x117] = 0x17;
            World.map[0x119] = 0;
            World.zones[0x119] = 0x24;
            World.zoneIds[0x119] = 0x19;
            World.map[0x11b] = 0;
            World.zones[0x11b] = 0x24;
            World.zoneIds[0x11b] = 0x1b;
            World.map[0x11d] = 0;
            World.zones[0x11d] = 0x10b;
            World.zoneIds[0x11d] = 0x1d;
            World.map[0x11e] = 0;
            World.zones[0x11e] = 0x10b;
            World.zoneIds[0x11e] = 30;
            World.map[0x11f] = 0;
            World.zones[0x11f] = 0x10b;
            World.zoneIds[0x11f] = 0x1f;
            World.map[0x120] = 0;
            World.zones[0x120] = 0x10b;
            World.zoneIds[0x120] = 0x20;
            World.map[290] = 0;
            World.zones[290] = 0x10b;
            World.zoneIds[290] = 0x22;
            World.map[0x129] = 0;
            World.zones[0x129] = 0x21;
            World.zoneIds[0x129] = 0x26;
            World.map[0x12b] = 0;
            World.zones[0x12b] = 11;
            World.zoneIds[0x12b] = 40;
            World.map[300] = 0;
            World.zones[300] = 8;
            World.zoneIds[300] = 0x29;
            World.map[0x12d] = 0;
            World.zones[0x12d] = 0x21;
            World.zoneIds[0x12d] = 0x2a;
            World.map[0x12f] = 0;
            World.zones[0x12f] = 0x21;
            World.zoneIds[0x12f] = 0x2b;
            World.map[0x138] = 0;
            World.zones[0x138] = 0x21;
            World.zoneIds[0x138] = 0x31;
            World.map[0x13a] = 0;
            World.zones[0x13a] = 0x2d;
            World.zoneIds[0x13a] = 50;
            World.map[0x13c] = 0;
            World.zones[0x13c] = 0x2d;
            World.zoneIds[0x13c] = 0x33;
            World.map[0x13e] = 0;
            World.zones[0x13e] = 0x2d;
            World.zoneIds[0x13e] = 0x34;
            World.map[320] = 0;
            World.zones[320] = 0x2d;
            World.zoneIds[320] = 0x35;
            World.map[0x8b] = 0;
            World.zones[0x8b] = 0x8b;
            World.zoneIds[0x8b] = 0xdb;
            World.map[0x94] = 1;
            World.zones[0x94] = 0x94;
            World.zoneIds[0x94] = 0xe3;
            World.map[0xd3] = 0;
            World.zones[0xd3] = 1;
            World.zoneIds[0xd3] = 0x10c;
            World.map[0xe8] = 0;
            World.zones[0xe8] = 130;
            World.zoneIds[0xe8] = 0x11c;
            World.map[0xf4] = 0;
            World.zones[0xf4] = 10;
            World.zoneIds[0xf4] = 0x124;
            World.map[0x19] = 0;
            World.zones[0x19] = 0x19;
            World.zoneIds[0x19] = 0x88;
            World.map[0x1c] = 0;
            World.zones[0x1c] = 0x1c;
            World.zoneIds[0x1c] = 0x89;
            World.map[0x54] = 0x1c3;
            World.zones[0x54] = 0x16;
            World.zoneIds[0x54] = 0xb2;
            World.map[0x3e5] = 0;
            World.zones[0x3e5] = 0x2c;
            World.zoneIds[0x3e5] = 0x199;
            World.map[0x3e6] = 0;
            World.zones[0x3e6] = 0x2c;
            World.zoneIds[0x3e6] = 410;
            World.map[0x3e7] = 0;
            World.zones[0x3e7] = 0x2c;
            World.zoneIds[0x3e7] = 0x19b;
            World.map[0x3e8] = 0;
            World.zones[0x3e8] = 0x2c;
            World.zoneIds[0x3e8] = 0x19c;
            World.map[0x460] = 1;
            World.zones[0x460] = 0x165;
            World.zoneIds[0x460] = 0x19d;
            World.map[0x4c5] = 1;
            World.zones[0x4c5] = 0x10;
            World.zoneIds[0x4c5] = 0x1a0;
            World.map[0x4c8] = 1;
            World.zones[0x4c8] = 0x10;
            World.zoneIds[0x4c8] = 0x1a3;
            World.map[0x4ca] = 1;
            World.zones[0x4ca] = 0x10;
            World.zoneIds[0x4ca] = 0x1a5;
            World.map[0x4cb] = 1;
            World.zones[0x4cb] = 0x10;
            World.zoneIds[0x4cb] = 0x1a6;
            World.map[0x4cd] = 1;
            World.zones[0x4cd] = 0x10;
            World.zoneIds[0x4cd] = 0x1a8;
            World.map[0x4cf] = 1;
            World.zones[0x4cf] = 0x10;
            World.zoneIds[0x4cf] = 0x1aa;
            World.map[0x4d1] = 1;
            World.zones[0x4d1] = 0x10;
            World.zoneIds[0x4d1] = 0x1ac;
            World.map[0x4d3] = 1;
            World.zones[0x4d3] = 0x10;
            World.zoneIds[0x4d3] = 430;
            World.map[0x4d5] = 1;
            World.zones[0x4d5] = 0x10;
            World.zoneIds[0x4d5] = 0x1b0;
            World.map[0x4e8] = 1;
            World.zones[0x4e8] = 0x10;
            World.zoneIds[0x4e8] = 0x1b1;
            World.map[0x4fd] = 1;
            World.zones[0x4fd] = 0x196;
            World.zoneIds[0x4fd] = 0x1b3;
            World.map[0x539] = 70;
            World.zones[0x539] = 0x539;
            World.zoneIds[0x539] = 0x1b5;
            World.map[0x53a] = 0;
            World.zones[0x53a] = 130;
            World.zoneIds[0x53a] = 0x1b6;
            World.map[0x62] = 0;
            World.zones[0x62] = 0x2c;
            World.zoneIds[0x62] = 0xbc;
            World.map[0x83] = 0;
            World.zones[0x83] = 1;
            World.zoneIds[0x83] = 0xd3;
            World.map[0x8a] = 0;
            World.zones[0x8a] = 1;
            World.zoneIds[0x8a] = 0xda;
            World.map[0x2bb] = 1;
            World.zones[0x2bb] = 0x8d;
            World.zoneIds[0x2bb] = 0x12d;
            World.map[0x1b4] = 1;
            World.zones[0x1b4] = 0x14b;
            World.zoneIds[0x1b4] = 0x1d5;
            World.map[0x1c1] = 1;
            World.zones[0x1c1] = 0x94;
            World.zoneIds[0x1c1] = 0x1e1;
            World.map[0x1d4] = 1;
            World.zones[0x1d4] = 0x196;
            World.zoneIds[0x1d4] = 0x1ee;
            World.map[480] = 1;
            World.zones[480] = 400;
            World.zoneIds[480] = 0x1f9;
            World.map[0x18e] = 1;
            World.zones[0x18e] = 0xd7;
            World.zoneIds[0x18e] = 0x1b9;
            World.map[0x191] = 1;
            World.zones[0x191] = 0x11;
            World.zoneIds[0x191] = 0x1bb;
            World.map[0x194] = 1;
            World.zones[0x194] = 0xd7;
            World.zoneIds[0x194] = 0x1bc;
            World.map[0x195] = 1;
            World.zones[0x195] = 0x195;
            World.zoneIds[0x195] = 0x1bd;
            World.map[410] = 1;
            World.zones[410] = 14;
            World.zoneIds[410] = 450;
            World.map[0x19e] = 1;
            World.zones[0x19e] = 0x14b;
            World.zoneIds[0x19e] = 0x1c5;
            World.map[0x19f] = 1;
            World.zones[0x19f] = 0x14b;
            World.zoneIds[0x19f] = 0x1c6;
            World.map[0x1a0] = 1;
            World.zones[0x1a0] = 0x14b;
            World.zoneIds[0x1a0] = 0x1c7;
            World.map[0x1a1] = 1;
            World.zones[0x1a1] = 0x14b;
            World.zoneIds[0x1a1] = 0x1c8;
            World.map[0x1a3] = 1;
            World.zones[0x1a3] = 0x14b;
            World.zoneIds[0x1a3] = 0x1ca;
            World.map[0x1a5] = 1;
            World.zones[0x1a5] = 0x14b;
            World.zoneIds[0x1a5] = 460;
            World.map[0x1a6] = 1;
            World.zones[0x1a6] = 0x14b;
            World.zoneIds[0x1a6] = 0x1cd;
            World.map[0x1ab] = 1;
            World.zones[0x1ab] = 0x14b;
            World.zoneIds[0x1ab] = 0x1d0;
            World.map[430] = 1;
            World.zones[430] = 0x14b;
            World.zoneIds[430] = 0x1d1;
            World.map[0x1b1] = 1;
            World.zones[0x1b1] = 0x14b;
            World.zoneIds[0x1b1] = 0x1d3;
            World.map[0x1b6] = 1;
            World.zones[0x1b6] = 0x14b;
            World.zoneIds[0x1b6] = 470;
            World.map[440] = 1;
            World.zones[440] = 440;
            World.zoneIds[440] = 0x1d8;
            World.map[0x1ba] = 1;
            World.zones[0x1ba] = 0x94;
            World.zoneIds[0x1ba] = 0x1da;
            World.map[0x1bb] = 1;
            World.zones[0x1bb] = 0x94;
            World.zoneIds[0x1bb] = 0x1db;
            World.map[0x1be] = 1;
            World.zones[0x1be] = 0x94;
            World.zoneIds[0x1be] = 0x1de;
            World.map[0x1c4] = 1;
            World.zones[0x1c4] = 0x94;
            World.zoneIds[0x1c4] = 0x1e3;
            World.map[0x1c6] = 1;
            World.zones[0x1c6] = 0x94;
            World.zoneIds[0x1c6] = 0x1e4;
            World.map[0x1c8] = 1;
            World.zones[0x1c8] = 0x94;
            World.zoneIds[0x1c8] = 0x1e6;
            World.map[0x1ca] = 1;
            World.zones[0x1ca] = 0x11;
            World.zoneIds[0x1ca] = 0x1e7;
            World.map[460] = 1;
            World.zones[460] = 0x196;
            World.zoneIds[460] = 0x1e8;
            World.map[0x1cd] = 1;
            World.zones[0x1cd] = 0x196;
            World.zoneIds[0x1cd] = 0x1e9;
            World.map[0x1d1] = 1;
            World.zones[0x1d1] = 0x196;
            World.zoneIds[0x1d1] = 0x1ec;
            World.map[0x1d5] = 1;
            World.zones[0x1d5] = 0x196;
            World.zoneIds[0x1d5] = 0x1ef;
            World.map[470] = 1;
            World.zones[470] = 0xd7;
            World.zoneIds[470] = 0x1f0;
            World.map[0x1d7] = 1;
            World.zones[0x1d7] = 0xd7;
            World.zoneIds[0x1d7] = 0x1f1;
            World.map[0x1d8] = 1;
            World.zones[0x1d8] = 0xd7;
            World.zoneIds[0x1d8] = 0x1f2;
            World.map[0x1da] = 1;
            World.zones[0x1da] = 0xd7;
            World.zoneIds[0x1da] = 0x1f3;
            World.map[0x1dc] = 1;
            World.zones[0x1dc] = 0xd7;
            World.zoneIds[0x1dc] = 0x1f5;
            World.map[0x1de] = 1;
            World.zones[0x1de] = 0x8d;
            World.zoneIds[0x1de] = 0x1f7;
            World.map[0x1df] = 1;
            World.zones[0x1df] = 400;
            World.zoneIds[0x1df] = 0x1f8;
            World.map[0x1e2] = 1;
            World.zones[0x1e2] = 400;
            World.zoneIds[0x1e2] = 0x1fa;
            World.map[0x1e5] = 1;
            World.zones[0x1e5] = 400;
            World.zoneIds[0x1e5] = 0x1fd;
            World.map[0x1e6] = 1;
            World.zones[0x1e6] = 400;
            World.zoneIds[0x1e6] = 510;
            World.map[0x1e7] = 1;
            World.zones[0x1e7] = 400;
            World.zoneIds[0x1e7] = 0x1ff;
            World.map[490] = 1;
            World.zones[490] = 490;
            World.zoneIds[490] = 0x202;
            World.map[0x1ec] = 0;
            World.zones[0x1ec] = 10;
            World.zoneIds[0x1ec] = 0x204;
            World.map[0x1ed] = 1;
            World.zones[0x1ed] = 0x1ed;
            World.zoneIds[0x1ed] = 0x205;
            World.map[0x1ef] = 0;
            World.zones[0x1ef] = 0x1ef;
            World.zoneIds[0x1ef] = 0x207;
            World.map[0x1f8] = 1;
            World.zones[0x1f8] = 15;
            World.zoneIds[0x1f8] = 0x20b;
            World.map[0x1f9] = 1;
            World.zones[0x1f9] = 15;
            World.zoneIds[0x1f9] = 0x20c;
            World.map[0x1fb] = 1;
            World.zones[0x1fb] = 15;
            World.zoneIds[0x1fb] = 0x20e;
            World.map[0x1fc] = 1;
            World.zones[0x1fc] = 15;
            World.zoneIds[0x1fc] = 0x20f;
            World.map[0x200] = 1;
            World.zones[0x200] = 15;
            World.zoneIds[0x200] = 530;
            World.map[0x201] = 1;
            World.zones[0x201] = 15;
            World.zoneIds[0x201] = 0x213;
            World.map[0x202] = 1;
            World.zones[0x202] = 15;
            World.zoneIds[0x202] = 0x214;
            World.map[0x205] = 1;
            World.zones[0x205] = 15;
            World.zoneIds[0x205] = 0x217;
            World.map[0x219] = 1;
            World.zones[0x219] = 490;
            World.zoneIds[0x219] = 0x21a;
            World.map[0x21b] = 1;
            World.zones[0x21b] = 490;
            World.zoneIds[0x21b] = 540;
            World.map[0x21d] = 1;
            World.zones[0x21d] = 490;
            World.zoneIds[0x21d] = 0x21e;
            World.map[0x21e] = 1;
            World.zones[0x21e] = 490;
            World.zoneIds[0x21e] = 0x21f;
            World.map[0x22c] = 0;
            World.zones[0x22c] = 0x26;
            World.zoneIds[0x22c] = 0x221;
            World.map[0x57] = 0;
            World.zones[0x57] = 12;
            World.zoneIds[0x57] = 0x224;
            World.map[0x1a9] = 1;
            World.zones[0x1a9] = 0x14b;
            World.zoneIds[0x1a9] = 0x225;
            World.map[0xe2] = 0;
            World.zones[0xe2] = 130;
            World.zoneIds[0xe2] = 0x227;
            World.map[0x1d9] = 1;
            World.zones[0x1d9] = 0xd7;
            World.zoneIds[0x1d9] = 0x22a;
            World.map[0x29] = 0;
            World.zones[0x29] = 0x29;
            World.zoneIds[0x29] = 0x22c;
            World.map[0x97] = 0x1c3;
            World.zones[0x97] = 0x97;
            World.zoneIds[0x97] = 560;
            World.map[0xbc] = 1;
            World.zones[0xbc] = 0x8d;
            World.zoneIds[0xbc] = 0x231;
            World.map[220] = 1;
            World.zones[220] = 0xd7;
            World.zoneIds[220] = 0x232;
            World.map[0x114] = 0;
            World.zones[0x114] = 0x114;
            World.zoneIds[0x114] = 0x234;
            World.map[0x12e] = 0;
            World.zones[0x12e] = 0x21;
            World.zoneIds[0x12e] = 0x235;
            World.map[0x193] = 1;
            World.zones[0x193] = 15;
            World.zoneIds[0x193] = 0x238;
            World.map[0x1b2] = 1;
            World.zones[0x1b2] = 0x14b;
            World.zoneIds[0x1b2] = 570;
            World.map[0x1e1] = 1;
            World.zones[0x1e1] = 400;
            World.zoneIds[0x1e1] = 0x23c;
            World.map[0x71] = 0;
            World.zones[0x71] = 40;
            World.zoneIds[0x71] = 0x240;
            World.map[0xa9] = 0;
            World.zones[0xa9] = 0x55;
            World.zoneIds[0xa9] = 0x241;
            World.map[0x10c] = 0x25;
            World.zones[0x10c] = 0x10c;
            World.zoneIds[0x10c] = 580;
            World.map[0x183] = 1;
            World.zones[0x183] = 0x11;
            World.zoneIds[0x183] = 0x246;
            World.map[0x1c5] = 1;
            World.zones[0x1c5] = 0x94;
            World.zoneIds[0x1c5] = 0x247;
            World.map[0xee] = 0;
            World.zones[0xee] = 130;
            World.zoneIds[0xee] = 0x24b;
            World.map[0xef] = 0;
            World.zones[0xef] = 130;
            World.zoneIds[0xef] = 0x24c;
            World.map[0x137] = 0;
            World.zones[0x137] = 0x21;
            World.zoneIds[0x137] = 0x24d;
            World.map[0x13b] = 0;
            World.zones[0x13b] = 0x2d;
            World.zoneIds[0x13b] = 590;
            World.map[0x162] = 0;
            World.zones[0x162] = 0x2f;
            World.zoneIds[0x162] = 0x24f;
            World.map[0x255] = 1;
            World.zones[0x255] = 0x195;
            World.zoneIds[0x255] = 0x252;
            World.map[0x261] = 1;
            World.zones[0x261] = 0x195;
            World.zoneIds[0x261] = 0x256;
            World.map[0x25b] = 1;
            World.zones[0x25b] = 0x195;
            World.zoneIds[0x25b] = 600;
            World.map[0x25c] = 1;
            World.zones[0x25c] = 0x195;
            World.zoneIds[0x25c] = 0x259;
            World.map[0x1a] = 0;
            World.zones[0x1a] = 40;
            World.zoneIds[0x1a] = 0x25a;
            World.map[60] = 0;
            World.zones[60] = 12;
            World.zoneIds[60] = 0x25e;
            World.map[0xeb] = 0;
            World.zones[0xeb] = 130;
            World.zoneIds[0xeb] = 0x260;
            World.map[0x13d] = 0;
            World.zones[0x13d] = 0x2d;
            World.zoneIds[0x13d] = 0x261;
            World.map[0x1ad] = 1;
            World.zones[0x1ad] = 0x14b;
            World.zoneIds[0x1ad] = 0x263;
            World.map[0x1b5] = 1;
            World.zones[0x1b5] = 0x14b;
            World.zoneIds[0x1b5] = 0x264;
            World.map[0x1d3] = 1;
            World.zones[0x1d3] = 0x196;
            World.zoneIds[0x1d3] = 0x265;
            World.map[10] = 0;
            World.zones[10] = 10;
            World.zoneIds[10] = 0x269;
            World.map[11] = 0;
            World.zones[11] = 11;
            World.zoneIds[11] = 0x26a;
            World.map[0x268] = 1;
            World.zones[0x268] = 0x268;
            World.zoneIds[0x268] = 0x26b;
            World.map[0x1f6] = 1;
            World.zones[0x1f6] = 15;
            World.zoneIds[0x1f6] = 0x270;
            World.map[0x19c] = 1;
            World.zones[0x19c] = 0x14b;
            World.zoneIds[0x19c] = 0x271;
            World.map[0x27c] = 1;
            World.zones[0x27c] = 0x196;
            World.zoneIds[0x27c] = 0x272;
            World.map[0x47] = 0;
            World.zones[0x47] = 0x2c;
            World.zoneIds[0x47] = 0x273;
            World.map[0x134] = 0;
            World.zones[0x134] = 0x134;
            World.zoneIds[0x134] = 0x277;
            World.map[0x152] = 0;
            World.zones[0x152] = 3;
            World.zoneIds[0x152] = 0x279;
            World.map[0x27d] = 1;
            World.zones[0x27d] = 0xd7;
            World.zoneIds[0x27d] = 0x27b;
            World.map[0x27e] = 1;
            World.zones[0x27e] = 14;
            World.zoneIds[0x27e] = 0x27c;
            World.map[0x27f] = 1;
            World.zones[0x27f] = 14;
            World.zoneIds[0x27f] = 0x27d;
            World.map[0x2cc] = 0;
            World.zones[0x2cc] = 1;
            World.zoneIds[0x2cc] = 0x27f;
            World.map[0x2cd] = 0x22;
            World.zones[0x2cd] = 0x2cd;
            World.zoneIds[0x2cd] = 640;
            World.map[720] = 1;
            World.zones[720] = 0x11;
            World.zoneIds[720] = 0x283;
            World.map[0x2d2] = 0x81;
            World.zones[0x2d2] = 0x2d2;
            World.zoneIds[0x2d2] = 0x284;
            World.map[0x31c] = 0xbd;
            World.zones[0x31c] = 0x31c;
            World.zoneIds[0x31c] = 0x286;
            World.map[0x31d] = 0;
            World.zones[0x31d] = 12;
            World.zoneIds[0x31d] = 0x287;
            World.map[0x31e] = 0;
            World.zones[0x31e] = 12;
            World.zoneIds[0x31e] = 0x288;
            World.map[0xe3] = 0;
            World.zones[0xe3] = 130;
            World.zoneIds[0xe3] = 0x117;
            World.map[0xe4] = 0;
            World.zones[0xe4] = 130;
            World.zoneIds[0xe4] = 280;
            World.map[0xe5] = 0;
            World.zones[0xe5] = 130;
            World.zoneIds[0xe5] = 0x119;
            World.map[230] = 0;
            World.zones[230] = 130;
            World.zoneIds[230] = 0x11a;
            World.map[0xe7] = 0;
            World.zones[0xe7] = 130;
            World.zoneIds[0xe7] = 0x11b;
            World.map[240] = 0;
            World.zones[240] = 130;
            World.zoneIds[240] = 0x120;
            World.map[0xf1] = 0;
            World.zones[0xf1] = 10;
            World.zoneIds[0xf1] = 0x121;
            World.map[0xf2] = 0;
            World.zones[0xf2] = 10;
            World.zoneIds[0xf2] = 290;
            World.map[0xf3] = 0;
            World.zones[0xf3] = 10;
            World.zoneIds[0xf3] = 0x123;
            World.map[0xf7] = 0;
            World.zones[0xf7] = 0x33;
            World.zoneIds[0xf7] = 0x126;
            World.map[0x2b9] = 1;
            World.zones[0x2b9] = 0x8d;
            World.zoneIds[0x2b9] = 0x12b;
            World.map[0x2ba] = 1;
            World.zones[0x2ba] = 0x8d;
            World.zoneIds[0x2ba] = 300;
            World.map[0x2d1] = 90;
            World.zones[0x2d1] = 0x2d1;
            World.zoneIds[0x2d1] = 0x131;
            World.map[0x346] = 0;
            World.zones[0x346] = 0x26;
            World.zoneIds[0x346] = 0x132;
            World.map[0x347] = 0;
            World.zones[0x347] = 0x26;
            World.zoneIds[0x347] = 0x133;
            World.map[0x39a] = 0;
            World.zones[0x39a] = 40;
            World.zoneIds[0x39a] = 0x137;
            World.map[0x3a8] = 0;
            World.zones[0x3a8] = 0x26;
            World.zoneIds[0x3a8] = 0x13e;
            World.map[0x3bc] = 0xa9;
            World.zones[0x3bc] = 0x3bc;
            World.zoneIds[0x3bc] = 0x13f;
            World.map[0x3d2] = 1;
            World.zones[0x3d2] = 440;
            World.zoneIds[0x3d2] = 0x141;
            World.map[980] = 1;
            World.zones[980] = 440;
            World.zoneIds[980] = 0x143;
            World.map[0x3d7] = 1;
            World.zones[0x3d7] = 440;
            World.zoneIds[0x3d7] = 0x146;
            World.map[0x3d9] = 1;
            World.zones[0x3d9] = 440;
            World.zoneIds[0x3d9] = 0x148;
            World.map[0x3dc] = 1;
            World.zones[0x3dc] = 440;
            World.zoneIds[0x3dc] = 0x14b;
            World.map[0x3dd] = 1;
            World.zones[0x3dd] = 440;
            World.zoneIds[0x3dd] = 0x14c;
            World.map[0x3e0] = 1;
            World.zones[0x3e0] = 440;
            World.zoneIds[0x3e0] = 0x14f;
            World.map[0x3e9] = 0;
            World.zones[0x3e9] = 0x2c;
            World.zoneIds[0x3e9] = 0x150;
            World.map[0x3fa] = 0;
            World.zones[0x3fa] = 11;
            World.zoneIds[0x3fa] = 340;
            World.map[0x3fc] = 0;
            World.zones[0x3fc] = 11;
            World.zoneIds[0x3fc] = 0x156;
            World.map[0x3fe] = 0;
            World.zones[0x3fe] = 11;
            World.zoneIds[0x3fe] = 0x158;
            World.map[0x3ff] = 0;
            World.zones[0x3ff] = 11;
            World.zoneIds[0x3ff] = 0x159;
            World.map[0x421] = 0;
            World.zones[0x421] = 0x10b;
            World.zoneIds[0x421] = 0x15d;
            World.map[0x44a] = 0;
            World.zones[0x44a] = 10;
            World.zoneIds[0x44a] = 0x160;
            World.map[0x44b] = 1;
            World.zones[0x44b] = 0x165;
            World.zoneIds[0x44b] = 0x161;
            World.map[0x451] = 1;
            World.zones[0x451] = 0x165;
            World.zoneIds[0x451] = 0x162;
            World.map[0x45b] = 1;
            World.zones[0x45b] = 0x165;
            World.zoneIds[0x45b] = 0x165;
            World.map[0x484] = 1;
            World.zones[0x484] = 0x11;
            World.zoneIds[0x484] = 0x16a;
            World.map[0x4c0] = 1;
            World.zones[0x4c0] = 0x10;
            World.zoneIds[0x4c0] = 0x16c;
            World.map[0x4c1] = 1;
            World.zones[0x4c1] = 0x10;
            World.zoneIds[0x4c1] = 0x16d;
            World.map[0x4c2] = 1;
            World.zones[0x4c2] = 0x10;
            World.zoneIds[0x4c2] = 0x16e;
            World.map[0x4c3] = 1;
            World.zones[0x4c3] = 0x10;
            World.zoneIds[0x4c3] = 0x16f;
            World.map[0x45f] = 1;
            World.zones[0x45f] = 0x165;
            World.zoneIds[0x45f] = 0x171;
            World.map[0x471] = 1;
            World.zones[0x471] = 0x165;
            World.zoneIds[0x471] = 370;
            World.map[0x510] = 1;
            World.zones[0x510] = 14;
            World.zoneIds[0x510] = 0x174;
            World.map[0x538] = 1;
            World.zones[0x538] = 440;
            World.zoneIds[0x538] = 0x175;
            World.map[0x561] = 1;
            World.zones[0x561] = 0x561;
            World.zoneIds[0x561] = 0x176;
            World.map[0x575] = 0xa9;
            World.zones[0x575] = 0x575;
            World.zoneIds[0x575] = 0x178;
            World.map[0x59e] = 0;
            World.zones[0x59e] = 4;
            World.zoneIds[0x59e] = 0x17b;
            World.map[0x5a1] = 0;
            World.zones[0x5a1] = 4;
            World.zoneIds[0x5a1] = 0x17e;
            World.map[0x5a2] = 0;
            World.zones[0x5a2] = 0x33;
            World.zoneIds[0x5a2] = 0x17f;
            World.map[0x5a3] = 0;
            World.zones[0x5a3] = 0x33;
            World.zoneIds[0x5a3] = 0x180;
            World.map[0x5a4] = 0;
            World.zones[0x5a4] = 0x33;
            World.zoneIds[0x5a4] = 0x181;
            World.map[0x5ed] = 0;
            World.zones[0x5ed] = 3;
            World.zoneIds[0x5ed] = 0x2ae;
            World.map[0x601] = 0;
            World.zones[0x601] = 0x601;
            World.zoneIds[0x601] = 0x2b1;
            World.map[0x62b] = 0;
            World.zones[0x62b] = 0x62b;
            World.zoneIds[0x62b] = 0x2b5;
            World.map[0x62d] = 0x24;
            World.zones[0x62d] = 0x62d;
            World.zoneIds[0x62d] = 0x2b7;
            World.map[0x204] = 1;
            World.zones[0x204] = 15;
            World.zoneIds[0x204] = 0x216;
            World.map[540] = 1;
            World.zones[540] = 490;
            World.zoneIds[540] = 0x21d;
            World.map[0x36] = 0;
            World.zones[0x36] = 12;
            World.zoneIds[0x36] = 550;
            World.map[0x257] = 1;
            World.zones[0x257] = 0x195;
            World.zoneIds[0x257] = 0x254;
            World.map[0x99] = 0;
            World.zones[0x99] = 0x55;
            World.zoneIds[0x99] = 0x25f;
            World.map[0x127] = 0;
            World.zones[0x127] = 0x10b;
            World.zoneIds[0x127] = 0x268;
            World.map[0x326] = 0;
            World.zones[0x326] = 1;
            World.zoneIds[0x326] = 0x290;
            World.map[0x32f] = 1;
            World.zones[0x32f] = 0x11;
            World.zoneIds[0x32f] = 0x299;
            World.map[0x345] = 0;
            World.zones[0x345] = 0x26;
            World.zoneIds[0x345] = 0x2a1;
            World.map[0xf9] = 0;
            World.zones[0xf9] = 0x2e;
            World.zoneIds[0xf9] = 1;
            World.map[0x121] = 0;
            World.zones[0x121] = 0x10b;
            World.zoneIds[0x121] = 0x21;
            World.map[0x143] = 0;
            World.zones[0x143] = 0x2d;
            World.zoneIds[0x143] = 0x37;
            World.map[0x14b] = 1;
            World.zones[0x14b] = 0x14b;
            World.zoneIds[0x14b] = 0x3d;
            World.map[0x150] = 0;
            World.zones[0x150] = 0x2d;
            World.zoneIds[0x150] = 0x42;
            World.map[0x3d1] = 1;
            World.zones[0x3d1] = 440;
            World.zoneIds[0x3d1] = 390;
            World.map[0x40c] = 0;
            World.zones[0x40c] = 11;
            World.zoneIds[0x40c] = 0x187;
            World.map[0x40d] = 0;
            World.zones[0x40d] = 11;
            World.zoneIds[0x40d] = 0x188;
            World.map[0x40e] = 0;
            World.zones[0x40e] = 11;
            World.zoneIds[0x40e] = 0x189;
            World.map[0x40f] = 0;
            World.zones[0x40f] = 11;
            World.zoneIds[0x40f] = 0x18a;
            World.map[0x44d] = 1;
            World.zones[0x44d] = 0x165;
            World.zoneIds[0x44d] = 0x18c;
            World.map[0x452] = 1;
            World.zones[0x452] = 0x165;
            World.zoneIds[0x452] = 0x18f;
            World.map[0x453] = 1;
            World.zones[0x453] = 0x165;
            World.zoneIds[0x453] = 400;
            World.map[0x455] = 1;
            World.zones[0x455] = 0x165;
            World.zoneIds[0x455] = 0x191;
            World.map[0x456] = 1;
            World.zones[0x456] = 0x165;
            World.zoneIds[0x456] = 0x192;
            World.map[0x457] = 1;
            World.zones[0x457] = 0x165;
            World.zoneIds[0x457] = 0x193;
            World.map[0x459] = 1;
            World.zones[0x459] = 0x165;
            World.zoneIds[0x459] = 0x195;
            World.map[0x485] = 1;
            World.zones[0x485] = 0x11;
            World.zoneIds[0x485] = 0x196;
            World.map[0x5ee] = 0;
            World.zones[0x5ee] = 40;
            World.zoneIds[0x5ee] = 0x2af;
            World.map[0x5ef] = 0;
            World.zones[0x5ef] = 0x5ef;
            World.zoneIds[0x5ef] = 0x2b0;
            World.map[0x133] = 0;
            World.zones[0x133] = 0x2f;
            World.zoneIds[0x133] = 0x2e;
            World.map[0x4d] = 0;
            World.zones[0x4d] = 1;
            World.zoneIds[0x4d] = 0xae;
            World.map[0x836] = 0;
            World.zones[0x836] = 1;
            World.zoneIds[0x836] = 0x326;
            World.map[0x837] = 0;
            World.zones[0x837] = 11;
            World.zoneIds[0x837] = 0x327;
            World.map[0x838] = 0;
            World.zones[0x838] = 11;
            World.zoneIds[0x838] = 0x328;
            World.map[0x86d] = 1;
            World.zones[0x86d] = 0x11;
            World.zoneIds[0x86d] = 0x32e;
            World.map[0x1e8] = 1;
            World.zones[0x1e8] = 400;
            World.zoneIds[0x1e8] = 0x200;
            World.map[810] = 0;
            World.zones[810] = 0x55;
            World.zoneIds[810] = 660;
            World.map[0x45e] = 1;
            World.zones[0x45e] = 0x165;
            World.zoneIds[0x45e] = 360;
            World.map[0x4cc] = 1;
            World.zones[0x4cc] = 0x10;
            World.zoneIds[0x4cc] = 0x1a7;
            World.map[0x8c0] = 1;
            World.zones[0x8c0] = 400;
            World.zoneIds[0x8c0] = 0x33a;
            World.map[0x8c3] = 1;
            World.zones[0x8c3] = 0x26a;
            World.zoneIds[0x8c3] = 0x33d;
            World.map[0x8c5] = 1;
            World.zones[0x8c5] = 0x26a;
            World.zoneIds[0x8c5] = 0x33f;
            World.map[0x8c7] = 1;
            World.zones[0x8c7] = 0x26a;
            World.zoneIds[0x8c7] = 0x341;
            World.map[0x1eb] = 0x2f;
            World.zones[0x1eb] = 0x1eb;
            World.zoneIds[0x1eb] = 0x203;
            World.map[0x1fa] = 1;
            World.zones[0x1fa] = 15;
            World.zoneIds[0x1fa] = 0x20d;
            World.map[0x6e9] = 1;
            World.zones[0x6e9] = 0x169;
            World.zoneIds[0x6e9] = 0x2f2;
            World.map[0x148] = 0;
            World.zones[0x148] = 0x2d;
            World.zoneIds[0x148] = 0x236;
            World.map[0x163] = 0;
            World.zones[0x163] = 0x2f;
            World.zoneIds[0x163] = 0x250;
            World.map[0x67a] = 1;
            World.zones[0x67a] = 0x679;
            World.zoneIds[0x67a] = 0x2c9;
            World.map[0x7ce] = 1;
            World.zones[0x7ce] = 0x169;
            World.zoneIds[0x7ce] = 0x31a;
            World.map[0x8c9] = 1;
            World.zones[0x8c9] = 0x26a;
            World.zoneIds[0x8c9] = 0x343;
            World.map[0x8cb] = 1;
            World.zones[0x8cb] = 0x26a;
            World.zoneIds[0x8cb] = 0x345;
            World.map[0x8ce] = 1;
            World.zones[0x8ce] = 0x26a;
            World.zoneIds[0x8ce] = 840;
            World.map[0x8d4] = 0;
            World.zones[0x8d4] = 0x8b;
            World.zoneIds[0x8d4] = 0x34e;
            World.map[0x8d6] = 0;
            World.zones[0x8d6] = 0x8b;
            World.zoneIds[0x8d6] = 0x350;
            World.map[0x8d7] = 0;
            World.zones[0x8d7] = 0x8b;
            World.zoneIds[0x8d7] = 0x351;
            World.map[0x8d8] = 0;
            World.zones[0x8d8] = 0x8b;
            World.zoneIds[0x8d8] = 850;
            World.map[0x8da] = 0;
            World.zones[0x8da] = 0x8b;
            World.zoneIds[0x8da] = 0x354;
            World.map[0x8de] = 0;
            World.zones[0x8de] = 0x8b;
            World.zoneIds[0x8de] = 0x358;
            World.map[800] = 0;
            World.zones[800] = 1;
            World.zoneIds[800] = 650;
            World.map[0x325] = 0;
            World.zones[0x325] = 1;
            World.zoneIds[0x325] = 0x28f;
            World.map[0x327] = 0;
            World.zones[0x327] = 1;
            World.zoneIds[0x327] = 0x291;
            World.map[0x328] = 0;
            World.zones[0x328] = 1;
            World.zoneIds[0x328] = 0x292;
            World.map[0x32b] = 0;
            World.zones[0x32b] = 0x55;
            World.zoneIds[0x32b] = 0x295;
            World.map[0x32c] = 0;
            World.zones[0x32c] = 0x55;
            World.zoneIds[0x32c] = 0x296;
            World.map[0x32e] = 1;
            World.zones[0x32e] = 14;
            World.zoneIds[0x32e] = 0x298;
            World.map[0x331] = 1;
            World.zones[0x331] = 14;
            World.zoneIds[0x331] = 0x29b;
            World.map[0x333] = 1;
            World.zones[0x333] = 0xd7;
            World.zoneIds[0x333] = 0x29d;
            World.map[0x344] = 0;
            World.zones[0x344] = 11;
            World.zoneIds[0x344] = 0x2a0;
            World.map[0x358] = 0;
            World.zones[0x358] = 10;
            World.zoneIds[0x358] = 0x2a2;
            World.map[0x36c] = 1;
            World.zones[0x36c] = 0x36c;
            World.zoneIds[0x36c] = 0x2a3;
            World.map[0x36d] = 1;
            World.zones[0x36d] = 0x11;
            World.zoneIds[0x36d] = 0x2a4;
            World.map[0x36f] = 1;
            World.zones[0x36f] = 0x14b;
            World.zoneIds[0x36f] = 0x2a6;
            World.map[0x395] = 0;
            World.zones[0x395] = 40;
            World.zoneIds[0x395] = 0x2aa;
            World.map[0x742] = 0;
            World.zones[0x742] = 0x2d;
            World.zoneIds[0x742] = 0x2fe;
            World.map[0x8d3] = 0;
            World.zones[0x8d3] = 0x8b;
            World.zoneIds[0x8d3] = 0x34d;
            World.map[0x8ff] = 1;
            World.zones[0x8ff] = 400;
            World.zoneIds[0x8ff] = 0x369;
            World.map[0x90f] = 1;
            World.zones[0x90f] = 0x11;
            World.zoneIds[0x90f] = 0x36c;
            World.map[0x910] = 1;
            World.zones[0x910] = 14;
            World.zoneIds[0x910] = 0x36d;
            World.map[0x913] = 1;
            World.zones[0x913] = 0x165;
            World.zoneIds[0x913] = 880;
            World.map[0x916] = 1;
            World.zones[0x916] = 0x94;
            World.zoneIds[0x916] = 0x373;
            World.map[0x18b] = 0;
            World.zones[0x18b] = 0x18a;
            World.zoneIds[0x18b] = 0x74;
            World.map[0x93a] = 1;
            World.zones[0x93a] = 0x1ed;
            World.zoneIds[0x93a] = 0x37c;
            World.map[0x93c] = 0;
            World.zones[0x93c] = 40;
            World.zoneIds[0x93c] = 0x37e;
            World.map[0x940] = 0x10d;
            World.zones[0x940] = 0x93f;
            World.zoneIds[0x940] = 0x382;
            World.map[0x941] = 0x10d;
            World.zones[0x941] = 0x93f;
            World.zoneIds[0x941] = 0x383;
            World.map[0x942] = 0x10d;
            World.zones[0x942] = 0x93f;
            World.zoneIds[0x942] = 900;
            World.map[0x943] = 0x10d;
            World.zones[0x943] = 0x93f;
            World.zoneIds[0x943] = 0x385;
            World.map[0x948] = 0x10d;
            World.zones[0x948] = 0x93f;
            World.zoneIds[0x948] = 0x38a;
            World.map[0x95d] = 0;
            World.zones[0x95d] = 0x10b;
            World.zoneIds[0x95d] = 910;
            World.map[0x95e] = 0;
            World.zones[0x95e] = 130;
            World.zoneIds[0x95e] = 0x38f;
            World.map[0x95f] = 0;
            World.zones[0x95f] = 0x55;
            World.zoneIds[0x95f] = 0x390;
            World.map[0x962] = 0;
            World.zones[0x962] = 11;
            World.zoneIds[0x962] = 0x393;
            World.map[0x963] = 0;
            World.zones[0x963] = 8;
            World.zoneIds[0x963] = 0x394;
            World.map[0x968] = 1;
            World.zones[0x968] = 0x195;
            World.zoneIds[0x968] = 0x399;
            World.map[0x971] = 0;
            World.zones[0x971] = 0x2e;
            World.zoneIds[0x971] = 0x39a;
            World.map[0x975] = 0;
            World.zones[0x975] = 0x2e;
            World.zoneIds[0x975] = 0x39e;
            World.map[0x985] = 0x185;
            World.zones[0x985] = 0x985;
            World.zoneIds[0x985] = 0x39f;
            World.map[0x999] = 1;
            World.zones[0x999] = 0x14b;
            World.zoneIds[0x999] = 0x3a0;
            World.map[0x9c1] = 1;
            World.zones[0x9c1] = 0x10;
            World.zoneIds[0x9c1] = 0x3a6;
            World.map[0x9d5] = 0;
            World.zones[0x9d5] = 4;
            World.zoneIds[0x9d5] = 0x3a7;
            World.map[0x9d7] = 1;
            World.zones[0x9d7] = 0x165;
            World.zoneIds[0x9d7] = 0x3a9;
            World.map[0x9d8] = 1;
            World.zones[0x9d8] = 0x165;
            World.zoneIds[0x9d8] = 0x3aa;
            World.map[0x9ea] = 1;
            World.zones[0x9ea] = 0x196;
            World.zoneIds[0x9ea] = 0x3ae;
            World.map[0x9eb] = 1;
            World.zones[0x9eb] = 0x196;
            World.zoneIds[0x9eb] = 0x3af;
            World.map[0x9ed] = 1;
            World.zones[0x9ed] = 0x196;
            World.zoneIds[0x9ed] = 0x3b1;
            World.map[0x9fd] = 0x1ad;
            World.zones[0x9fd] = 0x9fd;
            World.zoneIds[0x9fd] = 0x3b2;
            World.map[0x9ff] = 0;
            World.zones[0x9ff] = 0x29;
            World.zoneIds[0x9ff] = 0x3b4;
            World.map[0xa02] = 0;
            World.zones[0xa02] = 0x29;
            World.zoneIds[0xa02] = 0x3b7;
            World.map[0xa03] = 0;
            World.zones[0xa03] = 0x29;
            World.zoneIds[0xa03] = 0x3b8;
            World.map[0xa39] = 1;
            World.zones[0xa39] = 0x195;
            World.zoneIds[0xa39] = 0x3bb;
            World.map[0xa3c] = 0;
            World.zones[0xa3c] = 0x1c;
            World.zoneIds[0xa3c] = 0x3be;
            World.map[0xa3d] = 0;
            World.zones[0xa3d] = 0x8b;
            World.zoneIds[0xa3d] = 0x3bf;
            World.map[0xa3f] = 0;
            World.zones[0xa3f] = 0x8b;
            World.zoneIds[0xa3f] = 0x3c1;
            World.map[0xa40] = 0;
            World.zones[0xa40] = 0x8b;
            World.zoneIds[0xa40] = 0x3c2;
            World.map[0xa41] = 0;
            World.zones[0xa41] = 0x8b;
            World.zoneIds[0xa41] = 0x3c3;
            World.map[0xa4d] = 1;
            World.zones[0xa4d] = 0x14b;
            World.zoneIds[0xa4d] = 0x3c6;
            World.map[0x5d9] = 0;
            World.zones[0x5d9] = 0x5d9;
            World.zoneIds[0x5d9] = 0x2ad;
            World.map[0x629] = 0;
            World.zones[0x629] = 0x21;
            World.zoneIds[0x629] = 0x2b3;
            World.map[0xa89] = 0;
            World.zones[0xa89] = 0x29;
            World.zoneIds[0xa89] = 0x3c9;
            World.map[0xa9d] = 0x199;
            World.zones[0xa9d] = 0xa9d;
            World.zoneIds[0xa9d] = 970;
            World.map[0xab2] = 1;
            World.zones[0xab2] = 0x561;
            World.zoneIds[0xab2] = 0x3cc;
            World.map[0xab6] = 1;
            World.zones[0xab6] = 0x561;
            World.zoneIds[0xab6] = 0x3d0;
            World.map[0xab8] = 1;
            World.zones[0xab8] = 0x561;
            World.zoneIds[0xab8] = 0x3d2;
            World.map[0x7a5] = 0;
            World.zones[0x7a5] = 0x33;
            World.zoneIds[0x7a5] = 0x314;
            World.map[0x847] = 0;
            World.zones[0x847] = 0x55;
            World.zoneIds[0x847] = 0x32b;
            World.map[0xac5] = 1;
            World.zones[0xac5] = 0x11;
            World.zoneIds[0xac5] = 0x3d3;
            World.map[0x75a] = 0;
            World.zones[0x75a] = 0x2f;
            World.zoneIds[0x75a] = 0x304;
            World.map[0x833] = 0;
            World.zones[0x833] = 0x2c;
            World.zoneIds[0x833] = 0x323;
            World.map[0x792] = 1;
            World.zones[0x792] = 440;
            World.zoneIds[0x792] = 0x30e;
            World.map[0xad9] = 0;
            World.zones[0xad9] = 0x10b;
            World.zoneIds[0xad9] = 980;
            World.map[0xb01] = 30;
            World.zones[0xb01] = 0xb01;
            World.zoneIds[0xb01] = 0;
            World.map[0x859] = 1;
            World.zones[0x859] = 0xd7;
            World.zoneIds[0x859] = 0x32c;
            World.map[0x63d] = 1;
            World.zones[0x63d] = 0x11;
            World.zoneIds[0x63d] = 0x2bb;
            World.map[0x63f] = 1;
            World.zones[0x63f] = 0x11;
            World.zoneIds[0x63f] = 0x2bd;
            World.map[0x640] = 1;
            World.zones[0x640] = 0x11;
            World.zoneIds[0x640] = 0x2be;
            World.map[0x641] = 1;
            World.zones[0x641] = 0x11;
            World.zoneIds[0x641] = 0x2bf;
            World.map[0x642] = 1;
            World.zones[0x642] = 0x11;
            World.zoneIds[0x642] = 0x2c0;
            World.map[0x669] = 1;
            World.zones[0x669] = 0x666;
            World.zoneIds[0x669] = 0x2c7;
            World.map[0x679] = 1;
            World.zones[0x679] = 0x679;
            World.zoneIds[0x679] = 0x2c8;
            World.map[700] = 1;
            World.zones[700] = 0x8d;
            World.zoneIds[700] = 0x12e;
            World.map[0x67c] = 1;
            World.zones[0x67c] = 0x679;
            World.zoneIds[0x67c] = 0x2cb;
            World.map[0x67d] = 1;
            World.zones[0x67d] = 0x679;
            World.zoneIds[0x67d] = 0x2cc;
            World.map[0x67e] = 1;
            World.zones[0x67e] = 0x679;
            World.zoneIds[0x67e] = 0x2cd;
            World.map[0x690] = 0;
            World.zones[0x690] = 0x24;
            World.zoneIds[0x690] = 0x2d1;
            World.map[0x691] = 0;
            World.zones[0x691] = 0x24;
            World.zoneIds[0x691] = 0x2d2;
            World.map[0xbb] = 1;
            World.zones[0xbb] = 0x8d;
            World.zoneIds[0xbb] = 0xf8;
            World.map[0x3d8] = 1;
            World.zones[0x3d8] = 440;
            World.zoneIds[0x3d8] = 0x147;
            World.map[0x6b5] = 1;
            World.zones[0x6b5] = 0x11;
            World.zoneIds[0x6b5] = 0x2de;
            World.map[0x6cc] = 0;
            World.zones[0x6cc] = 0x21;
            World.zoneIds[0x6cc] = 0x2e3;
            World.map[0x75b] = 0;
            World.zones[0x75b] = 0x2f;
            World.zoneIds[0x75b] = 0x305;
            World.map[0x75d] = 0;
            World.zones[0x75d] = 0x2f;
            World.zoneIds[0x75d] = 0x307;
            World.map[0x769] = 0;
            World.zones[0x769] = 3;
            World.zoneIds[0x769] = 0x30a;
            World.map[0x77d] = 0;
            World.zones[0x77d] = 0x2f;
            World.zoneIds[0x77d] = 780;
            World.map[0x7a7] = 0;
            World.zones[0x7a7] = 0x33;
            World.zoneIds[0x7a7] = 790;
            World.map[0x81e] = 1;
            World.zones[0x81e] = 0x94;
            World.zoneIds[0x81e] = 0x31f;
            World.map[0x81f] = 1;
            World.zones[0x81f] = 15;
            World.zoneIds[0x81f] = 800;
            World.map[0x845] = 0;
            World.zones[0x845] = 0x55;
            World.zoneIds[0x845] = 0x329;
            World.map[0x870] = 1;
            World.zones[0x870] = 0x196;
            World.zoneIds[0x870] = 0x331;
            World.map[0x923] = 0;
            World.zones[0x923] = 0x21;
            World.zoneIds[0x923] = 0x376;
            World.map[0x936] = 1;
            World.zones[0x936] = 0x14b;
            World.zoneIds[0x936] = 0x378;
            World.map[0x937] = 1;
            World.zones[0x937] = 0x14b;
            World.zoneIds[0x937] = 0x379;
            World.map[0x947] = 0x10d;
            World.zones[0x947] = 0x93f;
            World.zoneIds[0x947] = 0x389;
            World.map[0x651] = 0;
            World.zones[0x651] = 0x5ef;
            World.zoneIds[0x651] = 0x2c2;
            World.map[0x665] = 1;
            World.zones[0x665] = 0x665;
            World.zoneIds[0x665] = 0x2c3;
            World.map[0x666] = 1;
            World.zones[0x666] = 0x666;
            World.zoneIds[0x666] = 0x2c4;
            World.map[0x668] = 1;
            World.zones[0x668] = 0x666;
            World.zoneIds[0x668] = 710;
            World.map[280] = 0;
            World.zones[280] = 0x24;
            World.zoneIds[280] = 0x18;
            World.map[0x6f] = 0;
            World.zones[0x6f] = 40;
            World.zoneIds[0x6f] = 0xc6;
            World.map[0xa7] = 0;
            World.zones[0xa7] = 0x55;
            World.zoneIds[0xa7] = 0xf4;
            World.map[0x3ea] = 0;
            World.zones[0x3ea] = 0x2c;
            World.zoneIds[0x3ea] = 0x151;
            World.map[0x19b] = 1;
            World.zones[0x19b] = 0x14b;
            World.zoneIds[0x19b] = 0x1c3;
            World.map[0x1af] = 1;
            World.zones[0x1af] = 0x14b;
            World.zoneIds[0x1af] = 0x229;
            World.map[100] = 0;
            World.zones[100] = 0x21;
            World.zoneIds[100] = 0x249;
            World.map[0x128] = 0;
            World.zones[0x128] = 0x128;
            World.zoneIds[0x128] = 0x25;
            World.map[0x198] = 0;
            World.zones[0x198] = 0x198;
            World.zoneIds[0x198] = 0x1c0;
            World.map[0x6dd] = 0;
            World.zones[0x6dd] = 0x21;
            World.zoneIds[0x6dd] = 0x2e6;
            World.map[0x6de] = 0;
            World.zones[0x6de] = 0x21;
            World.zoneIds[0x6de] = 0x2e7;
            World.map[0x6e1] = 1;
            World.zones[0x6e1] = 0x169;
            World.zoneIds[0x6e1] = 0x2ea;
            World.map[0x6e2] = 1;
            World.zones[0x6e2] = 0x169;
            World.zoneIds[0x6e2] = 0x2eb;
            World.map[0x6e6] = 1;
            World.zones[0x6e6] = 0x169;
            World.zoneIds[0x6e6] = 0x2ef;
            World.map[0x6e7] = 1;
            World.zones[0x6e7] = 0x169;
            World.zoneIds[0x6e7] = 0x2f0;
            World.map[0x6ea] = 1;
            World.zones[0x6ea] = 0x169;
            World.zoneIds[0x6ea] = 0x2f3;
            World.map[0x6f3] = 0;
            World.zones[0x6f3] = 8;
            World.zoneIds[0x6f3] = 0x2f7;
            World.map[0x4c4] = 1;
            World.zones[0x4c4] = 0x10;
            World.zoneIds[0x4c4] = 0x19f;
            World.map[0x4ce] = 1;
            World.zones[0x4ce] = 0x10;
            World.zoneIds[0x4ce] = 0x1a9;
            World.map[0x75f] = 0;
            World.zones[0x75f] = 0x2f;
            World.zoneIds[0x75f] = 0x309;
            World.map[0x791] = 1;
            World.zones[0x791] = 440;
            World.zoneIds[0x791] = 0x30d;
            World.map[0x2bd] = 1;
            World.zones[0x2bd] = 0x8d;
            World.zoneIds[0x2bd] = 0x12f;
            World.map[0x693] = 0;
            World.zones[0x693] = 0x24;
            World.zoneIds[0x693] = 0x2d4;
            World.map[0x6a1] = 1;
            World.zones[0x6a1] = 0x11;
            World.zoneIds[0x6a1] = 0x2d6;
            World.map[0x6a2] = 1;
            World.zones[0x6a2] = 0x11;
            World.zoneIds[0x6a2] = 0x2d7;
            World.map[0x6a3] = 1;
            World.zones[0x6a3] = 0x11;
            World.zoneIds[0x6a3] = 0x2d8;
            World.map[0x6a4] = 1;
            World.zones[0x6a4] = 0x11;
            World.zoneIds[0x6a4] = 0x2d9;
            World.map[0x6a6] = 1;
            World.zones[0x6a6] = 0x11;
            World.zoneIds[0x6a6] = 0x2db;
            World.map[0x6cb] = 0;
            World.zones[0x6cb] = 0x21;
            World.zoneIds[0x6cb] = 0x2e2;
            World.map[0x6cd] = 0;
            World.zones[0x6cd] = 0x21;
            World.zoneIds[0x6cd] = 740;
            World.map[0x6df] = 0;
            World.zones[0x6df] = 0x21;
            World.zoneIds[0x6df] = 0x2e8;
            World.map[0x6f1] = 0;
            World.zones[0x6f1] = 8;
            World.zoneIds[0x6f1] = 0x2f5;
            World.map[0x705] = 0;
            World.zones[0x705] = 8;
            World.zoneIds[0x705] = 0x2f9;
            World.map[990] = 1;
            World.zones[990] = 440;
            World.zoneIds[990] = 0x14d;
            World.map[0x3fd] = 0;
            World.zones[0x3fd] = 11;
            World.zoneIds[0x3fd] = 0x157;
            World.map[0x449] = 0;
            World.zones[0x449] = 10;
            World.zoneIds[0x449] = 0x15f;
            World.map[0x470] = 1;
            World.zones[0x470] = 0x165;
            World.zoneIds[0x470] = 0x169;
            World.map[0x589] = 0x6d;
            World.zones[0x589] = 0x589;
            World.zoneIds[0x589] = 0x179;
            World.map[0x396] = 0;
            World.zones[0x396] = 40;
            World.zoneIds[0x396] = 0x2ab;
            World.map[0x3d0] = 1;
            World.zones[0x3d0] = 440;
            World.zoneIds[0x3d0] = 320;
            World.map[0x1db] = 1;
            World.zones[0x1db] = 0xd7;
            World.zoneIds[0x1db] = 500;
            World.map[0x75e] = 0;
            World.zones[0x75e] = 0x2f;
            World.zoneIds[0x75e] = 0x308;
            World.map[0x795] = 1;
            World.zones[0x795] = 0x795;
            World.zoneIds[0x795] = 0x311;
            World.map[0x2a4] = 150;
            World.zones[0x2a4] = 0x2a4;
            World.zoneIds[0x2a4] = 0x129;
            World.map[0x2b8] = 1;
            World.zones[0x2b8] = 0x8d;
            World.zoneIds[0x2b8] = 0x12a;
            World.map[0x1d2] = 1;
            World.zones[0x1d2] = 0x196;
            World.zoneIds[0x1d2] = 0x1ed;
            World.map[0x17d] = 1;
            World.zones[0x17d] = 0x11;
            World.zoneIds[0x17d] = 0x69;
            World.map[0x14d] = 0;
            World.zones[0x14d] = 0x2d;
            World.zoneIds[0x14d] = 0x3f;
            World.map[0x39b] = 0;
            World.zones[0x39b] = 0x26;
            World.zoneIds[0x39b] = 0x138;
            World.map[0x3df] = 1;
            World.zones[0x3df] = 440;
            World.zoneIds[0x3df] = 0x14e;
            World.map[0x420] = 0;
            World.zones[0x420] = 0x10b;
            World.zoneIds[0x420] = 0x15c;
            World.map[0x454] = 1;
            World.zones[0x454] = 0x165;
            World.zoneIds[0x454] = 0x163;
            World.map[0x380] = 0;
            World.zones[0x380] = 0x10b;
            World.zoneIds[0x380] = 0x134;
            World.map[0x3da] = 1;
            World.zones[0x3da] = 440;
            World.zoneIds[0x3da] = 0x149;
            World.map[0x59d] = 0;
            World.zones[0x59d] = 4;
            World.zoneIds[0x59d] = 0x17a;
            World.map[0x44f] = 1;
            World.zones[0x44f] = 0x165;
            World.zoneIds[0x44f] = 0x18d;
            World.map[0x18c] = 1;
            World.zones[0x18c] = 0xd7;
            World.zoneIds[0x18c] = 0x75;
            World.map[7] = 0;
            World.zones[7] = 0x21;
            World.zoneIds[7] = 0x7b;
            World.map[0x7e1] = 0x149;
            World.zones[0x7e1] = 0x7e1;
            World.zoneIds[0x7e1] = 0x31b;
            World.map[0x7f5] = 0;
            World.zones[0x7f5] = 0x7f5;
            World.zoneIds[0x7f5] = 0x31c;
            World.map[0x131] = 0;
            World.zones[0x131] = 130;
            World.zoneIds[0x131] = 0x2c;
            World.map[0x81d] = 1;
            World.zones[0x81d] = 0x94;
            World.zoneIds[0x81d] = 0x31e;
            World.map[0x835] = 0;
            World.zones[0x835] = 0x26;
            World.zoneIds[0x835] = 0x325;
            World.map[0x86] = 0;
            World.zones[0x86] = 1;
            World.zoneIds[0x86] = 0xd6;
            World.map[0x4c9] = 1;
            World.zones[0x4c9] = 0x10;
            World.zoneIds[0x4c9] = 420;
            World.map[0xd59] = 0x211;
            World.zones[0xd59] = 0xd1e;
            World.zoneIds[0xd59] = 0x41f;
            World.map[0xb29] = 1;
            World.zones[0xb29] = 440;
            World.zoneIds[0xb29] = 0x3d9;
            World.map[0x946] = 0x10d;
            World.zones[0x946] = 0x93f;
            World.zoneIds[0x946] = 0x388;
            World.map[0xba3] = 1;
            World.zones[0xba3] = 14;
            World.zoneIds[0xba3] = 0x3ea;
            World.map[0x92] = 0;
            World.zones[0x92] = 0x26;
            World.zoneIds[0x92] = 0xe1;
            World.map[0x9f] = 0;
            World.zones[0x9f] = 0x55;
            World.zoneIds[0x9f] = 0xec;
            World.map[0xd5a] = 0x211;
            World.zones[0xd5a] = 0xd1e;
            World.zoneIds[0xd5a] = 0x420;
            World.map[0xc5] = 0;
            World.zones[0xc5] = 0x1c;
            World.zoneIds[0xc5] = 0xfe;
            World.map[0xcd] = 0;
            World.zones[0xcd] = 11;
            World.zoneIds[0xcd] = 0x106;
            World.map[0xd4] = 0;
            World.zones[0xd4] = 1;
            World.zoneIds[0xd4] = 0x10d;
            World.map[0xe1] = 1;
            World.zones[0xe1] = 0xd7;
            World.zoneIds[0xe1] = 0x116;
            World.map[0xed] = 0;
            World.zones[0xed] = 130;
            World.zoneIds[0xed] = 0x11f;
            World.map[0xd5b] = 0x135;
            World.zones[0xd5b] = 0x7b9;
            World.zoneIds[0xd5b] = 0x421;
            World.map[0x3f8] = 0;
            World.zones[0x3f8] = 11;
            World.zoneIds[0x3f8] = 0x152;
            World.map[0x401] = 0;
            World.zones[0x401] = 11;
            World.zoneIds[0x401] = 0x15b;
            World.map[0x45c] = 1;
            World.zones[0x45c] = 0x165;
            World.zoneIds[0x45c] = 0x166;
            World.map[0x434] = 1;
            World.zones[0x434] = 0x196;
            World.zoneIds[0x434] = 0x170;
            World.map[0x62f] = 0;
            World.zones[0x62f] = 0x62f;
            World.zoneIds[0x62f] = 0x2b9;
            World.map[0x115] = 0;
            World.zones[0x115] = 0x24;
            World.zoneIds[0x115] = 0x15;
            World.map[0x4c6] = 1;
            World.zones[0x4c6] = 0x10;
            World.zoneIds[0x4c6] = 0x1a1;
            World.map[0x4d2] = 1;
            World.zones[0x4d2] = 0x10;
            World.zoneIds[0x4d2] = 0x1ad;
            World.map[0x524] = 1;
            World.zones[0x524] = 0x11;
            World.zoneIds[0x524] = 0x1b4;
            World.map[0x1a8] = 1;
            World.zones[0x1a8] = 0x14b;
            World.zoneIds[0x1a8] = 0x1ce;
            World.map[0x199] = 0;
            World.zones[0x199] = 0x199;
            World.zoneIds[0x199] = 0x1c1;
            World.map[600] = 1;
            World.zones[600] = 0x195;
            World.zoneIds[600] = 0x255;
            World.map[0x3db] = 1;
            World.zones[0x3db] = 440;
            World.zoneIds[0x3db] = 330;
            World.map[0x62c] = 0x24;
            World.zones[0x62c] = 0x62b;
            World.zoneIds[0x62c] = 0x2b6;
            World.map[0x68d] = 0;
            World.zones[0x68d] = 0x24;
            World.zoneIds[0x68d] = 0x2ce;
            World.map[0x6ce] = 0;
            World.zones[0x6ce] = 0x21;
            World.zoneIds[0x6ce] = 0x2e5;
            World.map[0x759] = 0;
            World.zones[0x759] = 0x2f;
            World.zoneIds[0x759] = 0x303;
            World.map[0x974] = 0;
            World.zones[0x974] = 0x2e;
            World.zoneIds[0x974] = 0x39d;
            World.map[0x9d6] = 1;
            World.zones[0x9d6] = 0x165;
            World.zoneIds[0x9d6] = 0x3a8;
            World.map[0x1c0] = 1;
            World.zones[0x1c0] = 0x94;
            World.zoneIds[0x1c0] = 480;
            World.map[0x1d0] = 1;
            World.zones[0x1d0] = 0x196;
            World.zoneIds[0x1d0] = 0x1eb;
            World.map[0x1dd] = 0;
            World.zones[0x1dd] = 0x21;
            World.zoneIds[0x1dd] = 0x1f6;
            World.map[0x1e9] = 1;
            World.zones[0x1e9] = 0x165;
            World.zoneIds[0x1e9] = 0x201;
            World.map[0x1f1] = 1;
            World.zones[0x1f1] = 15;
            World.zoneIds[0x1f1] = 520;
            World.map[0x218] = 0;
            World.zones[0x218] = 10;
            World.zoneIds[0x218] = 0x219;
            World.map[0x5c] = 0;
            World.zones[0x5c] = 12;
            World.zoneIds[0x5c] = 0x22e;
            World.map[0x173] = 1;
            World.zones[0x173] = 14;
            World.zoneIds[0x173] = 0x237;
            World.map[0x13] = 0;
            World.zones[0x13] = 0x21;
            World.zoneIds[0x13] = 0x23e;
            World.map[0x254] = 1;
            World.zones[0x254] = 0x195;
            World.zoneIds[0x254] = 0x251;
            World.map[0x25f] = 1;
            World.zones[0x25f] = 0x195;
            World.zoneIds[0x25f] = 0x25c;
            World.map[0x1f5] = 1;
            World.zones[0x1f5] = 15;
            World.zoneIds[0x1f5] = 0x266;
            World.map[500] = 1;
            World.zones[500] = 15;
            World.zoneIds[500] = 0x26f;
            World.map[0xfe] = 0;
            World.zones[0xfe] = 0x2e;
            World.zoneIds[0xfe] = 630;
            World.map[0x2ce] = 0x2b;
            World.zones[0x2ce] = 0x2ce;
            World.zoneIds[0x2ce] = 0x281;
            World.map[0x31f] = 0;
            World.zones[0x31f] = 10;
            World.zoneIds[0x31f] = 0x289;
            World.map[0x329] = 0;
            World.zones[0x329] = 1;
            World.zoneIds[0x329] = 0x293;
            World.map[0x397] = 0;
            World.zones[0x397] = 40;
            World.zoneIds[0x397] = 0x2ac;
            World.map[0x8fe] = 1;
            World.zones[0x8fe] = 15;
            World.zoneIds[0x8fe] = 0x368;
            World.map[0x914] = 1;
            World.zones[0x914] = 0x195;
            World.zoneIds[0x914] = 0x371;
            World.map[0x93e] = 0x10d;
            World.zones[0x93e] = 0x93e;
            World.zoneIds[0x93e] = 0x380;
            World.map[0x945] = 0x10d;
            World.zones[0x945] = 0x93f;
            World.zoneIds[0x945] = 0x387;
            World.map[0x961] = 0;
            World.zones[0x961] = 0x2d;
            World.zoneIds[0x961] = 0x392;
            World.map[0x6e8] = 1;
            World.zones[0x6e8] = 0x169;
            World.zoneIds[0x6e8] = 0x2f1;
            World.map[0xab7] = 1;
            World.zones[0xab7] = 0x561;
            World.zoneIds[0xab7] = 0x3d1;
            World.map[0xaed] = 1;
            World.zones[0xaed] = 0x14b;
            World.zoneIds[0xaed] = 0x3d5;
            World.map[0x63e] = 1;
            World.zones[0x63e] = 0x11;
            World.zoneIds[0x63e] = 700;
            World.map[0x67b] = 1;
            World.zones[0x67b] = 0x679;
            World.zoneIds[0x67b] = 0x2ca;
            World.map[0x694] = 0;
            World.zones[0x694] = 0x24;
            World.zoneIds[0x694] = 0x2d5;
            World.map[0x72d] = 0;
            World.zones[0x72d] = 0x2d;
            World.zoneIds[0x72d] = 0x2fc;
            World.map[0x7a6] = 0;
            World.zones[0x7a6] = 0x33;
            World.zoneIds[0x7a6] = 0x315;
            World.map[0x871] = 0;
            World.zones[0x871] = 10;
            World.zoneIds[0x871] = 0x332;
            World.map[0x43] = 0x11;
            World.zones[0x43] = 0x43;
            World.zoneIds[0x43] = 0xa6;
            World.map[880] = 0;
            World.zones[880] = 0x2d;
            World.zoneIds[880] = 0x2a7;
            World.map[0x6e3] = 1;
            World.zones[0x6e3] = 0x169;
            World.zoneIds[0x6e3] = 0x2ec;
            World.map[0x3fb] = 0;
            World.zones[0x3fb] = 0x8b;
            World.zoneIds[0x3fb] = 0x155;
            World.map[0x793] = 1;
            World.zones[0x793] = 440;
            World.zoneIds[0x793] = 0x30f;
            World.map[0x3d5] = 1;
            World.zones[0x3d5] = 440;
            World.zoneIds[0x3d5] = 0x144;
            World.map[0x4fc] = 1;
            World.zones[0x4fc] = 0x14b;
            World.zoneIds[0x4fc] = 0x1b2;
            World.map[0x797] = 1;
            World.zones[0x797] = 490;
            World.zoneIds[0x797] = 0x313;
            World.map[0x16d] = 1;
            World.zones[0x16d] = 14;
            World.zoneIds[0x16d] = 0x5b;
            World.map[0x68e] = 0;
            World.zones[0x68e] = 0x24;
            World.zoneIds[0x68e] = 0x2cf;
            World.map[0x260] = 1;
            World.zones[0x260] = 0x195;
            World.zoneIds[0x260] = 0x25d;
            World.map[0x7ba] = 0;
            World.zones[0x7ba] = 8;
            World.zoneIds[0x7ba] = 0x318;
            World.map[0x831] = 1;
            World.zones[0x831] = 400;
            World.zoneIds[0x831] = 0x321;
            World.map[0x85a] = 1;
            World.zones[0x85a] = 0x11;
            World.zoneIds[0x85a] = 0x32d;
            World.map[0x8bd] = 1;
            World.zones[0x8bd] = 400;
            World.zoneIds[0x8bd] = 0x337;
            World.map[0x8c6] = 1;
            World.zones[0x8c6] = 0x26a;
            World.zoneIds[0x8c6] = 0x340;
            World.map[0x203] = 1;
            World.zones[0x203] = 15;
            World.zoneIds[0x203] = 0x215;
            World.map[0x10f] = 0;
            World.zones[0x10f] = 0x10b;
            World.zoneIds[0x10f] = 0x267;
            World.map[0x6eb] = 1;
            World.zones[0x6eb] = 0x169;
            World.zoneIds[0x6eb] = 0x2f4;
            World.map[0x8d1] = 0x171;
            World.zones[0x8d1] = 0x8d1;
            World.zoneIds[0x8d1] = 0x34b;
            World.map[0x8dd] = 0;
            World.zones[0x8dd] = 0x8b;
            World.zoneIds[0x8dd] = 0x357;
            World.map[0x8e3] = 0;
            World.zones[0x8e3] = 0x8b;
            World.zoneIds[0x8e3] = 0x35d;
            World.map[0x8fd] = 1;
            World.zones[0x8fd] = 0x14b;
            World.zoneIds[0x8fd] = 0x367;
            World.map[0x1c7] = 1;
            World.zones[0x1c7] = 0x94;
            World.zoneIds[0x1c7] = 0x1e5;
            World.map[0x116] = 0;
            World.zones[0x116] = 0x24;
            World.zoneIds[0x116] = 0x16;
            World.map[0x158] = 0;
            World.zones[0x158] = 3;
            World.zoneIds[0x158] = 0x48;
            World.map[0x175] = 1;
            World.zones[0x175] = 14;
            World.zoneIds[0x175] = 0x62;
            World.map[14] = 1;
            World.zones[14] = 14;
            World.zoneIds[14] = 0x7f;
            World.map[0x2c] = 0;
            World.zones[0x2c] = 0x2c;
            World.zoneIds[0x2c] = 0x95;
            World.map[0x8d] = 1;
            World.zones[0x8d] = 0x8d;
            World.zoneIds[0x8d] = 220;
            World.map[0xa4] = 0;
            World.zones[0xa4] = 0x55;
            World.zoneIds[0xa4] = 0xf1;
            World.map[0x399] = 0;
            World.zones[0x399] = 40;
            World.zoneIds[0x399] = 310;
            World.map[0x400] = 0;
            World.zones[0x400] = 11;
            World.zoneIds[0x400] = 0x15a;
            World.map[0x5a0] = 0;
            World.zones[0x5a0] = 4;
            World.zoneIds[0x5a0] = 0x17d;
            World.map[0x371] = 0;
            World.zones[0x371] = 11;
            World.zoneIds[0x371] = 680;
            World.map[0x461] = 1;
            World.zones[0x461] = 0x165;
            World.zoneIds[0x461] = 0x19e;
            World.map[0xec] = 0;
            World.zones[0xec] = 130;
            World.zoneIds[0xec] = 0x11e;
            World.map[0x1ac] = 1;
            World.zones[0x1ac] = 0x14b;
            World.zoneIds[0x1ac] = 0x239;
            World.map[0x25a] = 1;
            World.zones[0x25a] = 0x195;
            World.zoneIds[0x25a] = 0x257;
            World.map[0x94a] = 0x10d;
            World.zones[0x94a] = 0x93f;
            World.zoneIds[0x94a] = 0x38c;
            World.map[0x9e9] = 1;
            World.zones[0x9e9] = 0x196;
            World.zoneIds[0x9e9] = 0x3ad;
            World.map[0xa11] = 1;
            World.zones[0xa11] = 0x165;
            World.zoneIds[0xa11] = 0x3b9;
            World.map[0x45a] = 1;
            World.zones[0x45a] = 0x165;
            World.zoneIds[0x45a] = 0x164;
            World.map[0x809] = 0x121;
            World.zones[0x809] = 0x809;
            World.zoneIds[0x809] = 0x31d;
            World.map[0x8c8] = 1;
            World.zones[0x8c8] = 0x26a;
            World.zoneIds[0x8c8] = 0x342;
            World.map[0x8d0] = 1;
            World.zones[0x8d0] = 0x26a;
            World.zoneIds[0x8d0] = 0x34a;
            World.map[0x9d9] = 1;
            World.zones[0x9d9] = 0x165;
            World.zoneIds[0x9d9] = 0x3ab;
            World.map[0x8db] = 0;
            World.zones[0x8db] = 0x8b;
            World.zoneIds[0x8db] = 0x355;
            World.map[0xa75] = 0x1d5;
            World.zones[0xa75] = 0xa75;
            World.zoneIds[0xa75] = 0x3c8;
            World.map[0x332] = 1;
            World.zones[0x332] = 0xd7;
            World.zoneIds[0x332] = 0x29c;
            World.map[0xba2] = 30;
            World.zones[0xba2] = 0xa25;
            World.zoneIds[0xba2] = 0x3e9;
            World.map[0xb8e] = 30;
            World.zones[0xb8e] = 0xa25;
            World.zoneIds[0xb8e] = 0x3e1;
            World.map[0xb7a] = 0;
            World.zones[0xb7a] = 0x29;
            World.zoneIds[0xb7a] = 0x3df;
            World.map[0xbc9] = 30;
            World.zones[0xbc9] = 0xa25;
            World.zoneIds[0xbc9] = 0x3eb;
            World.map[0xbdd] = 1;
            World.zones[0xbdd] = 400;
            World.zoneIds[0xbdd] = 0x3ec;
            World.map[0xbde] = 1;
            World.zones[0xbde] = 400;
            World.zoneIds[0xbde] = 0x3ed;
            World.map[0xbdf] = 1;
            World.zones[0xbdf] = 400;
            World.zoneIds[0xbdf] = 0x3ee;
            World.map[0xbf2] = 30;
            World.zones[0xbf2] = 0xa25;
            World.zoneIds[0xbf2] = 0x3f0;
            World.map[0xc19] = 1;
            World.zones[0xc19] = 0x561;
            World.zoneIds[0xc19] = 0x3f2;
            World.map[0xc1a] = 1;
            World.zones[0xc1a] = 0x561;
            World.zoneIds[0xc1a] = 0x3f3;
            World.map[0xc1b] = 1;
            World.zones[0xc1b] = 0x561;
            World.zoneIds[0xc1b] = 0x3f4;
            World.map[0xc1c] = 1;
            World.zones[0xc1c] = 0x561;
            World.zoneIds[0xc1c] = 0x3f5;
            World.map[0xc2d] = 1;
            World.zones[0xc2d] = 0x165;
            World.zoneIds[0xc2d] = 0x3f6;
            World.map[0x967] = 1;
            World.zones[0x967] = 0x195;
            World.zoneIds[0x967] = 920;
            World.map[0x8fc] = 1;
            World.zones[0x8fc] = 440;
            World.zoneIds[0x8fc] = 870;
            World.map[0x93f] = 0x10d;
            World.zones[0x93f] = 0x93f;
            World.zoneIds[0x93f] = 0x381;
            World.map[0x8c2] = 1;
            World.zones[0x8c2] = 0x26a;
            World.zoneIds[0x8c2] = 0x33c;
            World.map[0x9ae] = 1;
            World.zones[0x9ae] = 0x169;
            World.zoneIds[0x9ae] = 930;
            World.map[0x8cc] = 1;
            World.zones[0x8cc] = 0x26a;
            World.zoneIds[0x8cc] = 0x346;
            World.map[0xb17] = 0;
            World.zones[0xb17] = 0x24;
            World.zoneIds[0xb17] = 0x3d8;
            World.map[0xb91] = 30;
            World.zones[0xb91] = 0xa25;
            World.zoneIds[0xb91] = 0x3e4;
            World.map[0x110] = 0;
            World.zones[0x110] = 0x10b;
            World.zoneIds[0x110] = 0x13;
            World.map[0x166] = 1;
            World.zones[0x166] = 0xd7;
            World.zoneIds[0x166] = 0x54;
            World.map[0x3b] = 0;
            World.zones[0x3b] = 12;
            World.zoneIds[0x3b] = 0x9f;
            World.map[0xa6] = 0;
            World.zones[0xa6] = 0x55;
            World.zoneIds[0xa6] = 0xf3;
            World.map[0x39e] = 0;
            World.zones[0x39e] = 130;
            World.zoneIds[0x39e] = 0x13b;
            World.map[0x8e0] = 0;
            World.zones[0x8e0] = 0x8b;
            World.zoneIds[0x8e0] = 0x35a;
            World.map[0x8e1] = 0;
            World.zones[0x8e1] = 0x8b;
            World.zoneIds[0x8e1] = 0x35b;
            World.map[0x8e2] = 0;
            World.zones[0x8e2] = 0x8b;
            World.zoneIds[0x8e2] = 860;
            World.map[0x8e5] = 0;
            World.zones[0x8e5] = 0x8b;
            World.zoneIds[0x8e5] = 0x35f;
            World.map[0x8e6] = 0;
            World.zones[0x8e6] = 0x8b;
            World.zoneIds[0x8e6] = 0x360;
            World.map[0x8e8] = 0;
            World.zones[0x8e8] = 0x8e8;
            World.zoneIds[0x8e8] = 0x362;
            World.map[0x8fa] = 0;
            World.zones[0x8fa] = 0x1c;
            World.zoneIds[0x8fa] = 0x364;
            World.map[0x8fb] = 0;
            World.zones[0x8fb] = 0x8b;
            World.zoneIds[0x8fb] = 0x365;
            World.map[0xc41] = 1;
            World.zones[0xc41] = 0x10;
            World.zoneIds[0xc41] = 0x3f7;
            World.map[0xc42] = 1;
            World.zones[0xc42] = 0x10;
            World.zoneIds[0xc42] = 0x3f8;
            World.map[0xc44] = 1;
            World.zones[0xc44] = 0x10;
            World.zoneIds[0xc44] = 0x3fa;
            World.map[0xc69] = 1;
            World.zones[0xc69] = 0x14b;
            World.zoneIds[0xc69] = 0x3fc;
            World.map[0x62e] = 0x24;
            World.zones[0x62e] = 0x62d;
            World.zoneIds[0x62e] = 0x2b8;
            World.map[0xc7d] = 0;
            World.zones[0xc7d] = 0x1c;
            World.zoneIds[0xc7d] = 0x3fd;
            World.map[0x6a8] = 1;
            World.zones[0x6a8] = 0x11;
            World.zoneIds[0x6a8] = 0x2dd;
            World.map[0x8be] = 1;
            World.zones[0x8be] = 400;
            World.zoneIds[0x8be] = 0x338;
            World.map[0x964] = 1;
            World.zones[0x964] = 0x195;
            World.zoneIds[0x964] = 0x395;
            World.map[0xb15] = 1;
            World.zones[0xb15] = 0x29;
            World.zoneIds[0xb15] = 0x3d6;
            World.map[0xb79] = 0;
            World.zones[0xb79] = 0x29;
            World.zoneIds[0xb79] = 990;
            World.map[0xc91] = 1;
            World.zones[0xc91] = 0x9fd;
            World.zoneIds[0xc91] = 0x3fe;
            World.map[0x53b] = 0;
            World.zones[0x53b] = 0x24;
            World.zoneIds[0x53b] = 0x1b7;
            World.map[0x108] = 1;
            World.zones[0x108] = 0x8d;
            World.zoneIds[0x108] = 14;
            World.map[0x16a] = 1;
            World.zones[0x16a] = 14;
            World.zoneIds[0x16a] = 0x58;
            World.map[0x7a] = 0;
            World.zones[0x7a] = 0x21;
            World.zoneIds[0x7a] = 0xcb;
            World.map[0x291] = 0;
            World.zones[0x291] = 8;
            World.zoneIds[0x291] = 0x128;
            World.map[0x5a6] = 0;
            World.zones[0x5a6] = 0x33;
            World.zoneIds[0x5a6] = 0x183;
            World.map[130] = 0;
            World.zones[130] = 130;
            World.zoneIds[130] = 210;
            World.map[0x1bd] = 1;
            World.zones[0x1bd] = 0x94;
            World.zoneIds[0x1bd] = 0x1dd;
            World.map[0x240] = 0;
            World.zones[0x240] = 10;
            World.zoneIds[0x240] = 0x222;
            World.map[250] = 0;
            World.zones[250] = 0x2e;
            World.zoneIds[250] = 0x243;
            World.map[0xab1] = 1;
            World.zones[0xab1] = 0x561;
            World.zoneIds[0xab1] = 0x3cb;
            World.map[0x922] = 0;
            World.zones[0x922] = 0x21;
            World.zoneIds[0x922] = 0x375;
            World.map[0x54d] = 0;
            World.zones[0x54d] = 0x24;
            World.zoneIds[0x54d] = 440;
            World.map[0x846] = 0;
            World.zones[0x846] = 0x55;
            World.zoneIds[0x846] = 810;
            World.map[0x881] = 0;
            World.zones[0x881] = 0x21;
            World.zoneIds[0x881] = 0x333;
            World.map[0x8cf] = 1;
            World.zones[0x8cf] = 0x26a;
            World.zoneIds[0x8cf] = 0x349;
            World.map[0xb51] = 1;
            World.zones[0xb51] = 0x14b;
            World.zoneIds[0xb51] = 0x3db;
            World.map[0xb65] = 1;
            World.zones[0xb65] = 0xb65;
            World.zoneIds[0xb65] = 0x3dc;
            World.map[0xba1] = 30;
            World.zones[0xba1] = 0xa25;
            World.zoneIds[0xba1] = 0x3e8;
            World.map[12] = 0;
            World.zones[12] = 12;
            World.zoneIds[12] = 0x7e;
            World.map[0x911] = 1;
            World.zones[0x911] = 0x10;
            World.zoneIds[0x911] = 0x36e;
            World.map[0x939] = 1;
            World.zones[0x939] = 0x1ed;
            World.zoneIds[0x939] = 0x37b;
            World.map[0x960] = 0;
            World.zones[0x960] = 0x2f;
            World.zoneIds[0x960] = 0x391;
            World.map[0x972] = 0;
            World.zones[0x972] = 0x2e;
            World.zoneIds[0x972] = 0x39b;
            World.map[0x9b0] = 1;
            World.zones[0x9b0] = 0x169;
            World.zoneIds[0x9b0] = 0x3a4;
            World.map[0x9da] = 1;
            World.zones[0x9da] = 0x165;
            World.zoneIds[0x9da] = 940;
            World.map[0xa61] = 1;
            World.zones[0xa61] = 0x195;
            World.zoneIds[0xa61] = 0x3c7;
            World.map[0xab4] = 1;
            World.zones[0xab4] = 0x561;
            World.zoneIds[0xab4] = 0x3ce;
            World.map[0x912] = 1;
            World.zones[0x912] = 0x8d;
            World.zoneIds[0x912] = 0x36f;
            World.map[0x6e5] = 1;
            World.zones[0x6e5] = 0x169;
            World.zoneIds[0x6e5] = 750;
            World.map[0x8d5] = 0;
            World.zones[0x8d5] = 0x8b;
            World.zoneIds[0x8d5] = 0x34f;
            World.map[0x8e7] = 0;
            World.zones[0x8e7] = 0x8b;
            World.zoneIds[0x8e7] = 0x361;
            World.map[0x90e] = 1;
            World.zones[0x90e] = 15;
            World.zoneIds[0x90e] = 0x36b;
            World.map[0x93b] = 1;
            World.zones[0x93b] = 0x1ed;
            World.zoneIds[0x93b] = 0x37d;
            World.map[0x949] = 0x10d;
            World.zones[0x949] = 0x93f;
            World.zoneIds[0x949] = 0x38b;
            World.map[0x966] = 1;
            World.zones[0x966] = 0x195;
            World.zoneIds[0x966] = 0x397;
            World.map[0x9fe] = 0;
            World.zones[0x9fe] = 0x29;
            World.zoneIds[0x9fe] = 0x3b3;
            World.map[0xa3a] = 1;
            World.zones[0xa3a] = 0x169;
            World.zoneIds[0xa3a] = 0x3bc;
            World.map[0xab3] = 1;
            World.zones[0xab3] = 0x561;
            World.zoneIds[0xab3] = 0x3cd;
            World.map[0x921] = 1;
            World.zones[0x921] = 14;
            World.zoneIds[0x921] = 0x374;
            World.map[0x8bf] = 1;
            World.zones[0x8bf] = 400;
            World.zoneIds[0x8bf] = 0x339;
            World.map[0x8d9] = 0;
            World.zones[0x8d9] = 0x8b;
            World.zoneIds[0x8d9] = 0x353;
            World.map[0xb16] = 0;
            World.zones[0xb16] = 0x33;
            World.zoneIds[0xb16] = 0x3d7;
            World.map[0x8cd] = 1;
            World.zones[0x8cd] = 0x26a;
            World.zoneIds[0x8cd] = 0x347;
            World.map[0xb3d] = 0x1c3;
            World.zones[0xb3d] = 0x16;
            World.zoneIds[0xb3d] = 0x3da;
            World.map[0x1a2] = 1;
            World.zones[0x1a2] = 0x14b;
            World.zoneIds[0x1a2] = 0x1c9;
            World.map[0xb8d] = 30;
            World.zones[0xb8d] = 0xa25;
            World.zoneIds[0xb8d] = 0x3e0;
            World.map[0xb8f] = 30;
            World.zones[0xb8f] = 0xa25;
            World.zoneIds[0xb8f] = 0x3e2;
            World.map[0xb90] = 30;
            World.zones[0xb90] = 0xa25;
            World.zoneIds[0xb90] = 0x3e3;
            World.map[0xb92] = 30;
            World.zones[0xb92] = 0xa25;
            World.zoneIds[0xb92] = 0x3e5;
            World.map[0xb93] = 30;
            World.zones[0xb93] = 0xa25;
            World.zoneIds[0xb93] = 0x3e6;
            World.map[0xb94] = 30;
            World.zones[0xb94] = 0xa25;
            World.zoneIds[0xb94] = 0x3e7;
            World.map[0x8e4] = 0;
            World.zones[0x8e4] = 0x8b;
            World.zoneIds[0x8e4] = 0x35e;
            World.map[0xfd] = 0;
            World.zones[0xfd] = 0x2e;
            World.zoneIds[0xfd] = 4;
            World.map[0x107] = 1;
            World.zones[0x107] = 0x8d;
            World.zoneIds[0x107] = 13;
            World.map[0x11c] = 0;
            World.zones[0x11c] = 0x24;
            World.zoneIds[0x11c] = 0x1c;
            World.map[0x125] = 0;
            World.zones[0x125] = 0x125;
            World.zoneIds[0x125] = 0x23;
            World.map[0x135] = 0;
            World.zones[0x135] = 11;
            World.zoneIds[0x135] = 0x2f;
            World.map[0x179] = 1;
            World.zones[0x179] = 0x179;
            World.zoneIds[0x179] = 0x65;
            World.map[390] = 1;
            World.zones[390] = 0x11;
            World.zoneIds[390] = 0x6f;
            World.map[9] = 0;
            World.zones[9] = 12;
            World.zoneIds[9] = 0x7d;
            World.map[0x17] = 0;
            World.zones[0x17] = 12;
            World.zoneIds[0x17] = 0x86;
            World.map[0x2e] = 0;
            World.zones[0x2e] = 0x2e;
            World.zoneIds[0x2e] = 0x97;
            World.map[0x4b] = 0;
            World.zones[0x4b] = 8;
            World.zoneIds[0x4b] = 0xac;
            World.map[0x63] = 0;
            World.zones[0x63] = 0x21;
            World.zoneIds[0x63] = 0xbd;
            World.map[0x6c] = 0;
            World.zones[0x6c] = 40;
            World.zoneIds[0x6c] = 0xc4;
            World.map[0x7d] = 0;
            World.zones[0x7d] = 0x21;
            World.zoneIds[0x7d] = 0xcd;
            World.map[0x86f] = 1;
            World.zones[0x86f] = 0x86f;
            World.zoneIds[0x86f] = 0x330;
            World.map[0x8c4] = 1;
            World.zones[0x8c4] = 0x26a;
            World.zoneIds[0x8c4] = 830;
            World.map[0x44] = 0;
            World.zones[0x44] = 0x2c;
            World.zoneIds[0x44] = 0x22d;
            World.map[640] = 1;
            World.zones[640] = 14;
            World.zoneIds[640] = 0x27e;
            World.map[0x8d2] = 0;
            World.zones[0x8d2] = 0x8b;
            World.zoneIds[0x8d2] = 0x34c;
            World.map[0x8df] = 0;
            World.zones[0x8df] = 0x8b;
            World.zoneIds[0x8df] = 0x359;
            World.map[0x8f9] = 0;
            World.zones[0x8f9] = 0x1c;
            World.zoneIds[0x8f9] = 0x363;
            World.map[0x18] = 0;
            World.zones[0x18] = 12;
            World.zoneIds[0x18] = 0x87;
            World.map[0x98] = 0;
            World.zones[0x98] = 0x55;
            World.zoneIds[0x98] = 230;
            World.map[0x9c] = 0;
            World.zones[0x9c] = 0x55;
            World.zoneIds[0x9c] = 0xe9;
            World.map[0x9d] = 0;
            World.zones[0x9d] = 0x55;
            World.zoneIds[0x9d] = 0xea;
            World.map[0xa3] = 0;
            World.zones[0xa3] = 0x55;
            World.zoneIds[0xa3] = 240;
            World.map[0x6b6] = 1;
            World.zones[0x6b6] = 0x11;
            World.zoneIds[0x6b6] = 0x2df;
            World.map[0x6e0] = 0;
            World.zones[0x6e0] = 0x21;
            World.zoneIds[0x6e0] = 0x2e9;
            World.map[0x6f4] = 0;
            World.zones[0x6f4] = 8;
            World.zoneIds[0x6f4] = 760;
            World.map[0xba] = 1;
            World.zones[0xba] = 0x8d;
            World.zoneIds[0xba] = 0x26e;
            World.map[0x755] = 0;
            World.zones[0x755] = 3;
            World.zoneIds[0x755] = 0x2ff;
            World.map[0x756] = 0;
            World.zones[0x756] = 3;
            World.zoneIds[0x756] = 0x300;
            World.map[0x757] = 0;
            World.zones[0x757] = 3;
            World.zoneIds[0x757] = 0x301;
            World.map[0x75c] = 0;
            World.zones[0x75c] = 0x2f;
            World.zoneIds[0x75c] = 0x306;
            World.map[0xc3] = 0;
            World.zones[0xc3] = 0x1c;
            World.zoneIds[0xc3] = 0xfd;
            World.map[0xc4] = 0;
            World.zones[0xc4] = 0x1c;
            World.zoneIds[0xc4] = 0x242;
            World.map[0xc9] = 0;
            World.zones[0xc9] = 0x1c;
            World.zoneIds[0xc9] = 0x102;
            World.map[0xcc] = 0;
            World.zones[0xcc] = 130;
            World.zoneIds[0xcc] = 0x105;
            World.map[0xd1] = 0x21;
            World.zones[0xd1] = 0xd1;
            World.zoneIds[0xd1] = 0x10a;
            World.map[0x832] = 0;
            World.zones[0x832] = 10;
            World.zoneIds[0x832] = 0x322;
            World.map[0x895] = 1;
            World.zones[0x895] = 0x666;
            World.zoneIds[0x895] = 820;
            World.map[0x5b1] = 0;
            World.zones[0x5b1] = 4;
            World.zoneIds[0x5b1] = 0x184;
            World.map[0x95] = 0;
            World.zones[0x95] = 0x26;
            World.zoneIds[0x95] = 0xe4;
            World.map[0x3a0] = 0;
            World.zones[0x3a0] = 130;
            World.zoneIds[0x3a0] = 0x13d;
            World.map[0x8ca] = 1;
            World.zones[0x8ca] = 0x26a;
            World.zoneIds[0x8ca] = 0x344;
            World.map[0x1ff] = 1;
            World.zones[0x1ff] = 15;
            World.zoneIds[0x1ff] = 0x211;
            World.map[0x142] = 0;
            World.zones[0x142] = 0x2d;
            World.zoneIds[0x142] = 0x245;
            World.map[820] = 1;
            World.zones[820] = 0xd7;
            World.zoneIds[820] = 670;
            World.map[0xa01] = 0;
            World.zones[0xa01] = 0x29;
            World.zoneIds[0xa01] = 950;
            World.map[0x741] = 0;
            World.zones[0x741] = 0x2d;
            World.zoneIds[0x741] = 0x2fd;
            World.map[0x94b] = 0x10d;
            World.zones[0x94b] = 0x93f;
            World.zoneIds[0x94b] = 0x38d;
            World.map[0x6a7] = 1;
            World.zones[0x6a7] = 0x11;
            World.zoneIds[0x6a7] = 0x2dc;
            World.map[0xa42] = 0;
            World.zones[0xa42] = 0x8b;
            World.zoneIds[0xa42] = 0x3c4;
            World.map[0x5f] = 0;
            World.zones[0x5f] = 0x2c;
            World.zoneIds[0x5f] = 0xb9;
            World.map[0x188] = 1;
            World.zones[0x188] = 0x11;
            World.zoneIds[0x188] = 0x71;
            World.map[0x1f2] = 1;
            World.zones[0x1f2] = 15;
            World.zoneIds[0x1f2] = 0x209;
            World.map[0xab5] = 1;
            World.zones[0xab5] = 0x561;
            World.zoneIds[0xab5] = 0x3cf;
            World.map[0x896] = 1;
            World.zones[0x896] = 0x195;
            World.zoneIds[0x896] = 0x335;
            World.map[0xb66] = 0x1c1;
            World.zones[0xb66] = 0xb66;
            World.zoneIds[0xb66] = 0x3dd;
            World.map[0xc05] = 1;
            World.zones[0xc05] = 0x561;
            World.zoneIds[0xc05] = 0x3f1;
            World.map[0xc55] = 1;
            World.zones[0xc55] = 0x196;
            World.zoneIds[0xc55] = 0x3fb;
            World.map[0xa5] = 0;
            World.zones[0xa5] = 0x55;
            World.zoneIds[0xa5] = 0xf2;
            World.map[0x132] = 0;
            World.zones[0x132] = 130;
            World.zoneIds[0x132] = 0x2d;
            World.map[0x1b0] = 1;
            World.zones[0x1b0] = 0x14b;
            World.zoneIds[0x1b0] = 0x1d2;
            World.map[0x93d] = 0;
            World.zones[0x93d] = 11;
            World.zoneIds[0x93d] = 0x37f;
            World.map[0x2e0] = 1;
            World.zones[0x2e0] = 0x8d;
            World.zoneIds[0x2e0] = 0x285;
            World.map[0x196] = 1;
            World.zones[0x196] = 0x196;
            World.zoneIds[0x196] = 0x1be;
            World.map[0x10] = 1;
            World.zones[0x10] = 0x10;
            World.zoneIds[0x10] = 0x81;
            World.map[0x39d] = 0;
            World.zones[0x39d] = 0x26;
            World.zoneIds[0x39d] = 0x13a;
            World.map[0x39f] = 0;
            World.zones[0x39f] = 130;
            World.zoneIds[0x39f] = 0x13c;
            World.map[0xa25] = 30;
            World.zones[0xa25] = 0xa25;
            World.zoneIds[0xa25] = 0x3ba;
            World.map[0x4d0] = 1;
            World.zones[0x4d0] = 0x10;
            World.zoneIds[0x4d0] = 0x1ab;
            World.map[0x692] = 0;
            World.zones[0x692] = 0x24;
            World.zoneIds[0x692] = 0x2d3;
            World.map[0x6ca] = 0;
            World.zones[0x6ca] = 0x21;
            World.zoneIds[0x6ca] = 0x2e1;
            World.map[0x6f2] = 0;
            World.zones[0x6f2] = 8;
            World.zoneIds[0x6f2] = 0x2f6;
            World.map[0x794] = 1;
            World.zones[0x794] = 440;
            World.zoneIds[0x794] = 0x310;
            World.map[0xc43] = 1;
            World.zones[0xc43] = 0x26a;
            World.zoneIds[0xc43] = 0x3f9;
            World.map[0x151] = 0;
            World.zones[0x151] = 3;
            World.zoneIds[0x151] = 0x43;
            World.map[0xcb9] = 1;
            World.zones[0xcb9] = 0x561;
            World.zoneIds[0xcb9] = 0x400;
            World.map[400] = 1;
            World.zones[400] = 400;
            World.zoneIds[400] = 0x1ba;
            World.map[0xccd] = 0x1e9;
            World.zones[0xccd] = 0xccd;
            World.zoneIds[0xccd] = 0x401;
            World.map[0x335] = 1;
            World.zones[0x335] = 0xd7;
            World.zoneIds[0x335] = 0x29f;
            World.map[0xbf1] = 30;
            World.zones[0xbf1] = 0xa25;
            World.zoneIds[0xbf1] = 0x3ef;
            World.map[0xca5] = 1;
            World.zones[0xca5] = 0x9fd;
            World.zoneIds[0xca5] = 0x3ff;
            World.map[0xce1] = 30;
            World.zones[0xce1] = 0xa25;
            World.zoneIds[0xce1] = 0x402;
            World.map[0xce2] = 30;
            World.zones[0xce2] = 0xa25;
            World.zoneIds[0xce2] = 0x403;
            World.map[0xce3] = 30;
            World.zones[0xce3] = 0xa25;
            World.zoneIds[0xce3] = 0x404;
            World.map[0xce4] = 30;
            World.zones[0xce4] = 0xa25;
            World.zoneIds[0xce4] = 0x405;
            World.map[0xce5] = 30;
            World.zones[0xce5] = 0xa25;
            World.zoneIds[0xce5] = 0x406;
            World.map[0xce6] = 30;
            World.zones[0xce6] = 0xa25;
            World.zoneIds[0xce6] = 0x407;
            World.map[0xce7] = 30;
            World.zones[0xce7] = 0xa25;
            World.zoneIds[0xce7] = 0x408;
            World.map[0xce8] = 30;
            World.zones[0xce8] = 0xa25;
            World.zoneIds[0xce8] = 0x409;
            World.map[0xce9] = 30;
            World.zones[0xce9] = 0xa25;
            World.zoneIds[0xce9] = 0x40a;
            World.map[0xcea] = 30;
            World.zones[0xcea] = 0xa25;
            World.zoneIds[0xcea] = 0x40b;
            World.map[0xcf5] = 0;
            World.zones[0xcf5] = 0x2f;
            World.zoneIds[0xcf5] = 0x40c;
            World.map[0xcf6] = 30;
            World.zones[0xcf6] = 0xa25;
            World.zoneIds[0xcf6] = 0x40d;
            World.map[0xcf7] = 1;
            World.zones[0xcf7] = 0x14b;
            World.zoneIds[0xcf7] = 0x40e;
            World.map[0xcf8] = 0x1e9;
            World.zones[0xcf8] = 0xccd;
            World.zoneIds[0xcf8] = 0x40f;
            World.map[0xcf9] = 0x1e9;
            World.zones[0xcf9] = 0xccd;
            World.zoneIds[0xcf9] = 0x410;
            World.map[0x206] = 1;
            World.zones[0x206] = 15;
            World.zoneIds[0x206] = 0x218;
            World.map[0xd09] = 30;
            World.zones[0xd09] = 0xa25;
            World.zoneIds[0xd09] = 0x411;
            World.map[0xd0a] = 30;
            World.zones[0xd0a] = 0xa25;
            World.zoneIds[0xd0a] = 0x412;
            World.map[0x7cd] = 1;
            World.zones[0x7cd] = 0x169;
            World.zoneIds[0x7cd] = 0x319;
            World.map[0x69] = 0;
            World.zones[0x69] = 0x21;
            World.zoneIds[0x69] = 0xc1;
            World.map[0x450] = 1;
            World.zones[0x450] = 0x165;
            World.zoneIds[0x450] = 0x18e;
            World.map[0x45d] = 1;
            World.zones[0x45d] = 0x165;
            World.zoneIds[0x45d] = 0x167;
            World.map[13] = 0;
            World.zones[13] = 10;
            World.zoneIds[13] = 0x22b;
            World.map[0x5a5] = 0;
            World.zones[0x5a5] = 0x33;
            World.zoneIds[0x5a5] = 0x182;
            World.map[0x5c5] = 0;
            World.zones[0x5c5] = 0x5c5;
            World.zoneIds[0x5c5] = 0x185;
            World.map[0xff] = 0;
            World.zones[0xff] = 0x2e;
            World.zoneIds[0xff] = 5;
            World.map[0x109] = 1;
            World.zones[0x109] = 0x8d;
            World.zoneIds[0x109] = 15;
            World.map[0x11a] = 0;
            World.zones[0x11a] = 0x24;
            World.zoneIds[0x11a] = 0x1a;
            World.map[0x126] = 0;
            World.zones[0x126] = 0x10b;
            World.zoneIds[0x126] = 0x24;
            World.map[310] = 0;
            World.zones[310] = 0x21;
            World.zoneIds[310] = 0x30;
            World.map[0x146] = 0;
            World.zones[0x146] = 0x2d;
            World.zoneIds[0x146] = 0x3a;
            World.map[0x14e] = 0;
            World.zones[0x14e] = 0x2d;
            World.zoneIds[0x14e] = 0x40;
            World.map[0x15c] = 0;
            World.zones[0x15c] = 0x2f;
            World.zoneIds[0x15c] = 0x4c;
            World.map[0x165] = 1;
            World.zones[0x165] = 0x165;
            World.zoneIds[0x165] = 0x53;
            World.map[0x16e] = 1;
            World.zones[0x16e] = 14;
            World.zoneIds[0x16e] = 0x5c;
            World.map[0x17b] = 1;
            World.zones[0x17b] = 0x11;
            World.zoneIds[0x17b] = 0x67;
            World.map[0x189] = 1;
            World.zones[0x189] = 14;
            World.zoneIds[0x189] = 0x72;
            World.map[2] = 0;
            World.zones[2] = 40;
            World.zoneIds[2] = 120;
            World.map[0x11] = 1;
            World.zones[0x11] = 0x11;
            World.zoneIds[0x11] = 130;
            World.map[0x22] = 0;
            World.zones[0x22] = 12;
            World.zoneIds[0x22] = 0x8d;
            World.map[0x2d] = 0;
            World.zones[0x2d] = 0x2d;
            World.zoneIds[0x2d] = 150;
            World.map[0x39] = 0;
            World.zones[0x39] = 12;
            World.zoneIds[0x39] = 0x9e;
            World.map[0x48] = 0;
            World.zones[0x48] = 4;
            World.zoneIds[0x48] = 0xa9;
            World.map[0x5b] = 0;
            World.zones[0x5b] = 12;
            World.zoneIds[0x5b] = 0xb7;
            World.map[0x68] = 0;
            World.zones[0x68] = 0x21;
            World.zoneIds[0x68] = 0xc0;
            World.map[0x79] = 0;
            World.zones[0x79] = 10;
            World.zoneIds[0x79] = 0xca;
            World.map[0x88] = 0;
            World.zones[0x88] = 1;
            World.zoneIds[0x88] = 0xd8;
            World.map[150] = 0;
            World.zones[150] = 11;
            World.zoneIds[150] = 0xe5;
            World.map[0xa2] = 0;
            World.zones[0xa2] = 0x55;
            World.zoneIds[0xa2] = 0xef;
            World.map[0xc1] = 0;
            World.zones[0xc1] = 0x1c;
            World.zoneIds[0xc1] = 0xfc;
            World.map[0xce] = 0x24;
            World.zones[0xce] = 0xce;
            World.zoneIds[0xce] = 0x107;
            World.map[0xdb] = 0;
            World.zones[0xdb] = 40;
            World.zoneIds[0xdb] = 0x111;
            World.map[0xe9] = 0;
            World.zones[0xe9] = 130;
            World.zoneIds[0xe9] = 0x11d;
            World.map[0x290] = 1;
            World.zones[0x290] = 0x1ed;
            World.zoneIds[0x290] = 0x127;
            World.map[0x39c] = 0;
            World.zones[0x39c] = 0x26;
            World.zoneIds[0x39c] = 0x139;
            World.map[0x3d3] = 1;
            World.zones[0x3d3] = 440;
            World.zoneIds[0x3d3] = 0x142;
            World.map[0x3f9] = 0;
            World.zones[0x3f9] = 11;
            World.zoneIds[0x3f9] = 0x153;
            World.map[0x44e] = 1;
            World.zones[0x44e] = 0x165;
            World.zoneIds[0x44e] = 350;
            World.map[0x4ac] = 1;
            World.zones[0x4ac] = 0x4ac;
            World.zoneIds[0x4ac] = 0x16b;
            World.map[0x498] = 0xd1;
            World.zones[0x498] = 0x498;
            World.zoneIds[0x498] = 0x173;
            World.map[0x59f] = 0;
            World.zones[0x59f] = 4;
            World.zoneIds[0x59f] = 380;
            World.map[0x615] = 1;
            World.zones[0x615] = 400;
            World.zoneIds[0x615] = 690;
            World.map[120] = 0;
            World.zones[120] = 12;
            World.zoneIds[120] = 0x22f;
            World.map[0x105] = 1;
            World.zones[0x105] = 0x8d;
            World.zoneIds[0x105] = 11;
            World.map[0x44c] = 1;
            World.zones[0x44c] = 0x165;
            World.zoneIds[0x44c] = 0x18b;
            World.map[0x458] = 1;
            World.zones[0x458] = 0x165;
            World.zoneIds[0x458] = 0x194;
            World.map[0x141] = 0;
            World.zones[0x141] = 0x2d;
            World.zoneIds[0x141] = 0x36;
            World.map[0xdf] = 1;
            World.zones[0xdf] = 0xd7;
            World.zoneIds[0xdf] = 0x114;
            World.map[0x53] = 0x1c3;
            World.zones[0x53] = 0x16;
            World.zoneIds[0x53] = 0xb1;
            World.map[0x3e4] = 0;
            World.zones[0x3e4] = 0x2c;
            World.zoneIds[0x3e4] = 0x198;
            World.map[0x4c7] = 1;
            World.zones[0x4c7] = 0x10;
            World.zoneIds[0x4c7] = 0x1a2;
            World.map[0x4d4] = 1;
            World.zones[0x4d4] = 0x10;
            World.zoneIds[0x4d4] = 0x1af;
            World.map[0x6d] = 0;
            World.zones[0x6d] = 40;
            World.zoneIds[0x6d] = 0xc5;
            World.map[0x19d] = 1;
            World.zones[0x19d] = 0x14b;
            World.zoneIds[0x19d] = 0x1c4;
            World.map[0x197] = 1;
            World.zones[0x197] = 14;
            World.zoneIds[0x197] = 0x1bf;
            World.map[420] = 1;
            World.zones[420] = 0x14b;
            World.zoneIds[420] = 0x1cb;
            World.map[0x1b3] = 1;
            World.zones[0x1b3] = 0x14b;
            World.zoneIds[0x1b3] = 0x1d4;
            World.map[0x1bf] = 1;
            World.zones[0x1bf] = 0x94;
            World.zoneIds[0x1bf] = 0x1df;
            World.map[0x1cf] = 1;
            World.zones[0x1cf] = 0x196;
            World.zoneIds[0x1cf] = 490;
            World.map[0x1e3] = 1;
            World.zones[0x1e3] = 400;
            World.zoneIds[0x1e3] = 0x1fb;
            World.map[0x1f0] = 1;
            World.zones[0x1f0] = 15;
            World.zoneIds[0x1f0] = 0x206;
            World.map[0x1fd] = 1;
            World.zones[0x1fd] = 15;
            World.zoneIds[0x1fd] = 0x210;
            World.map[0x21a] = 1;
            World.zones[0x21a] = 490;
            World.zoneIds[0x21a] = 0x21b;
            World.map[0x17e] = 1;
            World.zones[0x17e] = 0x11;
            World.zoneIds[0x17e] = 0x228;
            World.map[0xf5] = 0;
            World.zones[0xf5] = 10;
            World.zoneIds[0xf5] = 0x233;
            World.map[0x1f7] = 1;
            World.zones[0x1f7] = 15;
            World.zoneIds[0x1f7] = 0x23d;
            World.map[0x66] = 0;
            World.zones[0x66] = 0x21;
            World.zoneIds[0x66] = 0x24a;
            World.map[0x256] = 1;
            World.zones[0x256] = 0x195;
            World.zoneIds[0x256] = 0x253;
            World.map[0x18f] = 1;
            World.zones[0x18f] = 0xd7;
            World.zoneIds[0x18f] = 610;
            World.map[0xad] = 0;
            World.zones[0xad] = 0x55;
            World.zoneIds[0xad] = 620;
            World.map[0x26a] = 1;
            World.zones[0x26a] = 0x26a;
            World.zoneIds[0x26a] = 0x26d;
            World.map[0x75] = 0;
            World.zones[0x75] = 0x21;
            World.zoneIds[0x75] = 0x275;
            World.map[0x2cf] = 0x30;
            World.zones[0x2cf] = 0x2cf;
            World.zoneIds[0x2cf] = 0x282;
            World.map[0x324] = 0;
            World.zones[0x324] = 1;
            World.zoneIds[0x324] = 0x28e;
            World.map[0x330] = 1;
            World.zones[0x330] = 14;
            World.zoneIds[0x330] = 0x29a;
            World.map[0x36e] = 1;
            World.zones[0x36e] = 0x10;
            World.zoneIds[0x36e] = 0x2a5;
            World.map[0x90d] = 1;
            World.zones[0x90d] = 440;
            World.zoneIds[0x90d] = 0x36a;
            World.map[0x938] = 1;
            World.zones[0x938] = 0x14b;
            World.zoneIds[0x938] = 890;
            World.map[0x944] = 0x10d;
            World.zones[0x944] = 0x93f;
            World.zoneIds[0x944] = 0x386;
            World.map[0x965] = 1;
            World.zones[0x965] = 0x195;
            World.zoneIds[0x965] = 0x396;
            World.map[0x9af] = 1;
            World.zones[0x9af] = 0x169;
            World.zoneIds[0x9af] = 0x3a3;
            World.map[0xa00] = 0;
            World.zones[0xa00] = 0x29;
            World.zoneIds[0xa00] = 0x3b5;
            World.map[0xa3e] = 0;
            World.zones[0xa3e] = 0x8b;
            World.zoneIds[0xa3e] = 960;
            World.map[0x630] = 0;
            World.zones[0x630] = 0x630;
            World.zoneIds[0x630] = 0x2ba;
            World.map[0x758] = 0;
            World.zones[0x758] = 0x2f;
            World.zoneIds[0x758] = 770;
            World.map[0x86e] = 1;
            World.zones[0x86e] = 15;
            World.zoneIds[0x86e] = 0x32f;
            World.map[0x643] = 1;
            World.zones[0x643] = 0x11;
            World.zoneIds[0x643] = 0x2c1;
            World.map[0x68f] = 0;
            World.zones[0x68f] = 0x24;
            World.zoneIds[0x68f] = 720;
            World.map[0x6c9] = 0;
            World.zones[0x6c9] = 0x21;
            World.zoneIds[0x6c9] = 0x2e0;
            World.map[0x394] = 0;
            World.zones[0x394] = 40;
            World.zoneIds[0x394] = 0x2a9;
            World.map[0x935] = 1;
            World.zones[0x935] = 0x14b;
            World.zoneIds[0x935] = 0x377;
            World.map[370] = 1;
            World.zones[370] = 14;
            World.zoneIds[370] = 0x60;
            World.map[0x153] = 0;
            World.zones[0x153] = 3;
            World.zoneIds[0x153] = 0x27a;
            World.map[0x6e4] = 1;
            World.zones[0x6e4] = 0x169;
            World.zoneIds[0x6e4] = 0x2ed;
            World.map[0x719] = 0;
            World.zones[0x719] = 8;
            World.zoneIds[0x719] = 0x2fb;
            World.map[0x76a] = 0;
            World.zones[0x76a] = 3;
            World.zoneIds[0x76a] = 0x30b;
            World.map[0x667] = 1;
            World.zones[0x667] = 0x666;
            World.zoneIds[0x667] = 0x2c5;
            World.map[0x6a5] = 1;
            World.zones[0x6a5] = 0x11;
            World.zoneIds[0x6a5] = 730;
            World.map[0x706] = 0;
            World.zones[0x706] = 8;
            World.zoneIds[0x706] = 0x2fa;
            World.map[0x511] = 1;
            World.zones[0x511] = 14;
            World.zoneIds[0x511] = 0x197;
            World.map[0x796] = 1;
            World.zones[0x796] = 490;
            World.zoneIds[0x796] = 0x312;
            World.map[350] = 0;
            World.zones[350] = 0x2f;
            World.zoneIds[350] = 0x4e;
            World.map[0x139] = 0;
            World.zones[0x139] = 0x2d;
            World.zoneIds[0x139] = 0x278;
            World.map[0x7b9] = 0x135;
            World.zones[0x7b9] = 0x7b9;
            World.zoneIds[0x7b9] = 0x317;
            World.map[0x834] = 0x15d;
            World.zones[0x834] = 0x834;
            World.zoneIds[0x834] = 0x324;
            World.map[0xd60] = 0x211;
            World.zones[0xd60] = 0xd1e;
            World.zoneIds[0xd60] = 0x426;
            World.map[0xd5c] = 0x211;
            World.zones[0xd5c] = 0xd1e;
            World.zoneIds[0xd5c] = 0x422;
            World.map[0xd5d] = 0x211;
            World.zones[0xd5d] = 0xd1e;
            World.zoneIds[0xd5d] = 0x423;
            World.map[0xd5e] = 0x211;
            World.zones[0xd5e] = 0xd1e;
            World.zoneIds[0xd5e] = 0x424;
            World.map[0xd5f] = 0x211;
            World.zones[0xd5f] = 0xd1e;
            World.zoneIds[0xd5f] = 0x425;
            World.map[0x16] = 0x1c3;
            World.zones[0x16] = 0x16;
            World.zoneIds[0x16] = 0x223;
            World.map[0xdd] = 1;
            World.zones[0xdd] = 0xd7;
            World.zoneIds[0xdd] = 0x112;
            World.map[0x8a9] = 1;
            World.zones[0x8a9] = 0x195;
            World.zoneIds[0x8a9] = 0x336;
            World.map[0xe0] = 1;
            World.zones[0xe0] = 0xd7;
            World.zoneIds[0xe0] = 0x115;
            World.map[0x8c1] = 1;
            World.zones[0x8c1] = 0x26a;
            World.zoneIds[0x8c1] = 0x33b;
            World.map[0x8dc] = 0;
            World.zones[0x8dc] = 0x8b;
            World.zoneIds[0x8dc] = 0x356;
            World.map[0x915] = 1;
            World.zones[0x915] = 0x14b;
            World.zoneIds[0x915] = 0x372;
            World.map[0x973] = 0;
            World.zones[0x973] = 0x2e;
            World.zoneIds[0x973] = 0x39c;
            World.map[0xf6] = 0;
            World.zones[0xf6] = 0x33;
            World.zoneIds[0xf6] = 0x125;
            World.map[0x9ad] = 1;
            World.zones[0x9ad] = 0x561;
            World.zoneIds[0x9ad] = 0x3a1;
            World.map[0x9b1] = 1;
            World.zones[0x9b1] = 0x169;
            World.zoneIds[0x9b1] = 0x3a5;
            World.map[0x9ec] = 1;
            World.zones[0x9ec] = 0x196;
            World.zoneIds[0x9ec] = 0x3b0;
            World.map[0x101] = 1;
            World.zones[0x101] = 0x8d;
            World.zoneIds[0x101] = 7;
            World.map[0xa3b] = 0;
            World.zones[0xa3b] = 0x8b;
            World.zoneIds[0xa3b] = 0x3bd;
            World.map[0xa43] = 0;
            World.zones[0xa43] = 0x8b;
            World.zoneIds[0xa43] = 0x3c5;
            World.map[0x12a] = 0;
            World.zones[0x12a] = 11;
            World.zoneIds[0x12a] = 0x27;
            World.map[3] = 0;
            World.zones[3] = 3;
            World.zoneIds[3] = 0x79;
            World.map[0x145] = 0;
            World.zones[0x145] = 0x2d;
            World.zoneIds[0x145] = 0x39;
            World.map[340] = 0;
            World.zones[340] = 3;
            World.zoneIds[340] = 0x44;
            World.map[0x15b] = 0;
            World.zones[0x15b] = 3;
            World.zoneIds[0x15b] = 0x4b;
            World.map[0x24] = 0;
            World.zones[0x24] = 0x24;
            World.zoneIds[0x24] = 0x8f;
            World.map[0x16c] = 1;
            World.zones[0x16c] = 14;
            World.zoneIds[0x16c] = 90;
            World.map[0x170] = 1;
            World.zones[0x170] = 14;
            World.zoneIds[0x170] = 0x5e;
            World.map[0x17f] = 1;
            World.zones[0x17f] = 0x11;
            World.zoneIds[0x17f] = 0x6a;
            World.map[0x1aa] = 1;
            World.zones[0x1aa] = 0x14b;
            World.zoneIds[0x1aa] = 0x1cf;
            World.map[0x1b7] = 1;
            World.zones[0x1b7] = 400;
            World.zoneIds[0x1b7] = 0x1d7;
            World.map[0x1b9] = 1;
            World.zones[0x1b9] = 0x14b;
            World.zoneIds[0x1b9] = 0x1d9;
            World.map[0x1bc] = 1;
            World.zones[0x1bc] = 0x94;
            World.zoneIds[0x1bc] = 0x1dc;
            World.map[450] = 1;
            World.zones[450] = 0x94;
            World.zoneIds[450] = 0x1e2;
            World.map[0x1c9] = 1;
            World.zones[0x1c9] = 0x1c9;
            World.zoneIds[0x1c9] = 0x23b;
            World.map[0x1cb] = 0;
            World.zones[0x1cb] = 0x55;
            World.zoneIds[0x1cb] = 0x177;
            World.map[0x1e4] = 1;
            World.zones[0x1e4] = 400;
            World.zoneIds[0x1e4] = 0x1fc;
            World.map[0x1f3] = 1;
            World.zones[0x1f3] = 15;
            World.zoneIds[0x1f3] = 0x20a;
            World.map[510] = 1;
            World.zones[510] = 15;
            World.zoneIds[510] = 0x248;
            World.map[0x21f] = 1;
            World.zones[0x21f] = 490;
            World.zoneIds[0x21f] = 0x220;
            World.map[0x25e] = 1;
            World.zones[0x25e] = 0x195;
            World.zoneIds[0x25e] = 0x25b;
            World.map[0x3e] = 0;
            World.zones[0x3e] = 12;
            World.zoneIds[0x3e] = 0xa1;
            World.map[0x40] = 0;
            World.zones[0x40] = 12;
            World.zoneIds[0x40] = 0xa3;
            World.map[0x41] = 0;
            World.zones[0x41] = 0x41;
            World.zoneIds[0x41] = 0xa4;
            World.map[0x2be] = 1;
            World.zones[0x2be] = 0x8d;
            World.zoneIds[0x2be] = 0x130;
            World.map[0x49] = 0;
            World.zones[0x49] = 4;
            World.zoneIds[0x49] = 170;
            World.map[0x321] = 0;
            World.zones[0x321] = 1;
            World.zoneIds[0x321] = 0x28b;
            World.map[0x322] = 0;
            World.zones[0x322] = 1;
            World.zoneIds[0x322] = 0x28c;
            World.map[0x323] = 0;
            World.zones[0x323] = 1;
            World.zoneIds[0x323] = 0x28d;
            World.map[0x51] = 0x1c3;
            World.zones[0x51] = 0x16;
            World.zoneIds[0x51] = 0x23f;
            World.map[0x32d] = 0;
            World.zones[0x32d] = 0x1c;
            World.zoneIds[0x32d] = 0x297;
            World.map[920] = 0;
            World.zones[920] = 40;
            World.zoneIds[920] = 0x135;
            World.map[0x5d] = 0;
            World.zones[0x5d] = 10;
            World.zoneIds[0x5d] = 0x274;
            World.map[0x3d6] = 1;
            World.zones[0x3d6] = 440;
            World.zoneIds[0x3d6] = 0x145;
            World.map[0xd1d] = 0;
            World.zones[0xd1d] = 0x21;
            World.zoneIds[0xd1d] = 0x413;
            World.map[0xd1e] = 0x211;
            World.zones[0xd1e] = 0xd1e;
            World.zoneIds[0xd1e] = 0x414;
            World.map[0xd31] = 0x135;
            World.zones[0xd31] = 0x7b9;
            World.zoneIds[0xd31] = 0x415;
            World.map[0xd32] = 0x135;
            World.zones[0xd32] = 0x7b9;
            World.zoneIds[0xd32] = 0x416;
            World.map[0xd33] = 0x135;
            World.zones[0xd33] = 0x7b9;
            World.zoneIds[0xd33] = 0x417;
            World.map[0xd34] = 0x135;
            World.zones[0xd34] = 0x7b9;
            World.zoneIds[0xd34] = 0x418;
            World.map[0xd35] = 0x135;
            World.zones[0xd35] = 0x7b9;
            World.zoneIds[0xd35] = 0x419;
            World.map[0xd36] = 0x135;
            World.zones[0xd36] = 0x7b9;
            World.zoneIds[0xd36] = 0x41a;
            World.map[0xd37] = 0x135;
            World.zones[0xd37] = 0x7b9;
            World.zoneIds[0xd37] = 0x41b;
            World.map[0x62a] = 0;
            World.zones[0x62a] = 0x21;
            World.zoneIds[0x62a] = 0x2b4;
            World.map[0xc0] = 0;
            World.zones[0xc0] = 0x1c;
            World.zoneIds[0xc0] = 0xfb;
            World.map[0xd38] = 0x135;
            World.zones[0xd38] = 0x7b9;
            World.zoneIds[0xd38] = 0x41c;
            World.map[0xd45] = 0x135;
            World.zones[0xd45] = 0x7b9;
            World.zoneIds[0xd45] = 0x41d;
            World.map[0xd46] = 0x135;
            World.zones[0xd46] = 0x7b9;
            World.zoneIds[0xd46] = 0x41e;
            World.GameObjectsAssociated[0x652] = typeof(BaseHerb);
            World.GameObjectsAssociated[0xe8d] = typeof(BaseHerb);
            World.GameObjectsAssociated[0xe8e] = typeof(BaseHerb);
            World.GameObjectsAssociated[0xe8f] = typeof(BaseHerb);
            World.GameObjectsAssociated[0xe91] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x7fd] = typeof(BaseHerb);
            World.GameObjectsAssociated[0xe92] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x657] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x65c] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x658] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x7f9] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x7fa] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x7fe] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x7fb] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x7fc] = typeof(BaseHerb);
            World.GameObjectsAssociated[0xb32] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x22b3c] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x22b3d] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x22b3e] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x22b3f] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x22b40] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x22b41] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x2b1c7] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x2b1c8] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x2b1ca] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x2b1cb] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x2b1cc] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x2b1cd] = typeof(BaseHerb);
            World.GameObjectsAssociated[0x6c3] = typeof(BaseMine);
            World.GameObjectsAssociated[0x6c4] = typeof(BaseMine);
            World.GameObjectsAssociated[0x6c5] = typeof(BaseMine);
            World.GameObjectsAssociated[0x6c7] = typeof(BaseMine);
            World.GameObjectsAssociated[0x6c6] = typeof(BaseMine);
            World.GameObjectsAssociated[0x7f8] = typeof(BaseMine);
            World.GameObjectsAssociated[0x2403c] = typeof(BaseMine);
            World.GameObjectsAssociated[0x7ff] = typeof(BaseMine);
            World.GameObjectsAssociated[0x144] = typeof(BaseMine);
            World.GameObjectsAssociated[0x2ad2c] = typeof(BaseMine);
            Hashtable hashtable1 = new Hashtable();
            for (int num1 = 0; num1 < World.timers.Length; num1++)
            {
                World.timers[num1] = new Queue();
                this.lastCall[num1] = DateTime.Now.Ticks;
            }
            new CustomSpellHandlers();
            Type[] typeArray1 = Utility.externAsmItem.GetTypes();
            new Hashtable();
            TextReader reader1 = new StreamReader(World.Path + "items.txt");
            while (true)
            {
                string text1 = reader1.ReadLine();
                if (text1 == null)
                {
                    break;
                }
                int num2 = Convert.ToInt32(reader1.ReadLine());
                this.itemsHash[text1] = num2;
            }
            Type[] typeArray2 = typeArray1;
            int num14 = 0;
            while (num14 < typeArray2.Length)
            {
                Type type1 = typeArray2[num14];
                if (type1.IsSubclassOf(typeof(Item)))
                {
                    this.AddItem(type1);
                }
                num14++;
            }
            this.itemsHash.Clear();
            typeArray1 = null;
            GC.Collect();
            TextWriter writer1 = new StreamWriter("mob.txt");
            typeArray1 = Utility.externAsm.GetTypes();
            typeArray2 = typeArray1;
            for (num14 = 0; num14 < typeArray2.Length; num14++)
            {
                Type type2 = typeArray2[num14];
                if (type2.IsSubclassOf(typeof(BaseQuest)))
                {
                    ConstructorInfo[] infoArray1 = type2.GetConstructors();
                    hashtable1[type2] = infoArray1[0];
                }
                else if (type2.IsSubclassOf(typeof(BaseCreature)))
                {
                    try
                    {
                        ConstructorInfo[] infoArray2 = type2.GetConstructors();
                        BaseCreature creature1 = (BaseCreature) infoArray2[0].Invoke(null);
                        int num3 = creature1.Id;
                        World.mobilePool[num3] = infoArray2[0];
                        writer1.WriteLine("{0}\t{1}\t{2}", creature1.Name, creature1.Id, creature1.Level);
                        World.allMobs.Add(creature1);
                    }
                    catch (Exception)
                    {
                        Console.WriteLine("Error in the constructor of {0}", type2.ToString());
                    }
                }
            }
            World.poolsReady = true;
            IDictionaryEnumerator enumerator1 = hashtable1.GetEnumerator();
            while (enumerator1.MoveNext())
            {
                ConstructorInfo info1 = null;
                Type type3 = null;
                try
                {
                    type3 = (Type) enumerator1.Key;
                    info1 = (ConstructorInfo) enumerator1.Value;
                    BaseQuest quest1 = (BaseQuest) info1.Invoke(null);
                    World.questPool[quest1.Id] = quest1;
                    World.questPoolType[type3] = quest1;
                    continue;
                }
                catch (Exception exception1)
                {
                    Console.WriteLine("Error in the quest constructor of {0}", type3.ToString());
                    Console.WriteLine("{0}", exception1.Message.ToString());
                    Console.WriteLine("{0}", exception1.StackTrace.ToString());
                    continue;
                }
            }
            hashtable1.Clear();
            GC.Collect();
            writer1.Close();
            new TalentList();
            DateTime time1 = DateTime.Now;
            World.allSpawners = new SpawnerList(new GenericReader(World.Path + "spawnpoints.bin"));
            World.allMobiles = new MobileList(new GenericReader(World.Path + "savegame.bin"));
            DateTime.Now.Subtract(time1);
            World.allGameObjects = new GameObjects(new GenericReader(World.Path + "objects.bin"));
            World.allAccounts = new Accounts(World.Path + "accounts.xml");
            World.trajets = new Trajets(new GenericReader(World.Path + "coord.bin"));
            ConstructorInfo info2 = Utility.FindConstructor("GameObjectList", Utility.externAsm);
            info2.Invoke(null);
            Item.skillIdAssoc[0x191] = ClothSkill.SkillId;
            Item.skillIdAssoc[0x192] = LeatherSkill.SkillId;
            Item.skillIdAssoc[0x193] = MailSkill.SkillId;
            Item.skillIdAssoc[0x194] = PlateMailSkill.SkillId;
            Item.skillIdAssoc[0x196] = ShieldSkill.SkillId;
            Item.skillIdAssoc[200] = AxeSkill.SkillId;
            Item.skillIdAssoc[0xca] = BowsSkill.SkillId;
            Item.skillIdAssoc[0xd7] = DaggerSkill.SkillId;
            Item.skillIdAssoc[0xcc] = MacesSkill.SkillId;
            Item.skillIdAssoc[0xcb] = GunSkill.SkillId;
            Item.skillIdAssoc[210] = StavesSkill.SkillId;
            Item.skillIdAssoc[0xcf] = SwordSkill.SkillId;
            Item.skillIdAssoc[0xd8] = ThrowsSkill.SkillId;
            Item.skillIdAssoc[0xc9] = TwoHandedAxeSkill.SkillId;
            Item.skillIdAssoc[0xcd] = TwoHandedMaceSkill.SkillId;
            Item.skillIdAssoc[0xd0] = TwoHandedSwordSkill.SkillId;
            Item.skillIdAssoc[0xdb] = WandsSkill.SkillId;
            World.factionsAssociated[Factions.GnomereganExiles] = 0x12;
            World.factionsAssociated[Factions.Stormwind] = 0x13;
            World.factionsAssociated[Factions.IronForge] = 20;
            World.factionsAssociated[Factions.Darnasus] = 0x15;
            World.factionsAssociated[Factions.Ogrimmar] = 14;
            World.factionsAssociated[Factions.Undercity] = 0x11;
            World.factionsAssociated[Factions.ThunderBluff] = 0x10;
            World.factionsAssociated[Factions.DarkspearTrolls] = 15;
            World.factionsAssociated[Factions.Player_Tauren] = 0x30;
            World.factionsAssociated[Factions.Alliance] = 0x2f;
            World.FriendRaces[Races.Human] = new ArrayList();
            World.FriendRaces[Races.Orc] = new ArrayList();
            World.FriendRaces[Races.Gnome] = new ArrayList();
            World.FriendRaces[Races.Dwarf] = new ArrayList();
            World.FriendRaces[Races.Troll] = new ArrayList();
            World.FriendRaces[Races.Tauren] = new ArrayList();
            World.FriendRaces[Races.Undead] = new ArrayList();
            World.FriendRaces[Races.NightElf] = new ArrayList();
            (World.FriendRaces[Races.Human] as ArrayList).Add(Factions.Stormwind);
            (World.FriendRaces[Races.Human] as ArrayList).Add(Factions.GnomereganExiles);
            (World.FriendRaces[Races.Human] as ArrayList).Add(Factions.Alliance);
            (World.FriendRaces[Races.Human] as ArrayList).Add(Factions.Darnasus);
            (World.FriendRaces[Races.Human] as ArrayList).Add(Factions.IronForge);
            (World.FriendRaces[Races.Dwarf] as ArrayList).Add(Factions.Stormwind);
            (World.FriendRaces[Races.Dwarf] as ArrayList).Add(Factions.GnomereganExiles);
            (World.FriendRaces[Races.Dwarf] as ArrayList).Add(Factions.Alliance);
            (World.FriendRaces[Races.Dwarf] as ArrayList).Add(Factions.Darnasus);
            (World.FriendRaces[Races.Dwarf] as ArrayList).Add(Factions.IronForge);
            (World.FriendRaces[Races.NightElf] as ArrayList).Add(Factions.Stormwind);
            (World.FriendRaces[Races.NightElf] as ArrayList).Add(Factions.GnomereganExiles);
            (World.FriendRaces[Races.NightElf] as ArrayList).Add(Factions.Alliance);
            (World.FriendRaces[Races.NightElf] as ArrayList).Add(Factions.Darnasus);
            (World.FriendRaces[Races.NightElf] as ArrayList).Add(Factions.IronForge);
            (World.FriendRaces[Races.Gnome] as ArrayList).Add(Factions.Stormwind);
            (World.FriendRaces[Races.Gnome] as ArrayList).Add(Factions.GnomereganExiles);
            (World.FriendRaces[Races.Gnome] as ArrayList).Add(Factions.Alliance);
            (World.FriendRaces[Races.Gnome] as ArrayList).Add(Factions.Darnasus);
            (World.FriendRaces[Races.Gnome] as ArrayList).Add(Factions.IronForge);
            (World.FriendRaces[Races.Orc] as ArrayList).Add(Factions.Ogrimmar);
            (World.FriendRaces[Races.Orc] as ArrayList).Add(Factions.ThunderBluff);
            (World.FriendRaces[Races.Orc] as ArrayList).Add(Factions.DarkspearTrolls);
            (World.FriendRaces[Races.Orc] as ArrayList).Add(Factions.Undercity);
            (World.FriendRaces[Races.Orc] as ArrayList).Add(Factions.Player_Tauren);
            (World.FriendRaces[Races.Undead] as ArrayList).Add(Factions.Ogrimmar);
            (World.FriendRaces[Races.Undead] as ArrayList).Add(Factions.ThunderBluff);
            (World.FriendRaces[Races.Undead] as ArrayList).Add(Factions.DarkspearTrolls);
            (World.FriendRaces[Races.Undead] as ArrayList).Add(Factions.Undercity);
            (World.FriendRaces[Races.Undead] as ArrayList).Add(Factions.Player_Tauren);
            (World.FriendRaces[Races.Tauren] as ArrayList).Add(Factions.Ogrimmar);
            (World.FriendRaces[Races.Tauren] as ArrayList).Add(Factions.ThunderBluff);
            (World.FriendRaces[Races.Tauren] as ArrayList).Add(Factions.DarkspearTrolls);
            (World.FriendRaces[Races.Tauren] as ArrayList).Add(Factions.Undercity);
            (World.FriendRaces[Races.Tauren] as ArrayList).Add(Factions.Player_Tauren);
            (World.FriendRaces[Races.Troll] as ArrayList).Add(Factions.Ogrimmar);
            (World.FriendRaces[Races.Troll] as ArrayList).Add(Factions.ThunderBluff);
            (World.FriendRaces[Races.Troll] as ArrayList).Add(Factions.DarkspearTrolls);
            (World.FriendRaces[Races.Troll] as ArrayList).Add(Factions.Undercity);
            (World.FriendRaces[Races.Troll] as ArrayList).Add(Factions.Player_Tauren);
			SpellTemplate.SpellEffects[0x1c62] = new SingleTargetSpellEffect(Character.OnCastInvisibility);
            SpellTemplate.SpellEffects[0xa14] = new OnSelfSpellEffect(Profession.OnFindMineral);
            SpellTemplate.SpellEffects[0x194e] = new GameObjectTargetSpellEffect(GameObject.OnUseHandler);
			Assembly assembly1 = Assembly.GetAssembly(typeof(Utility));
            typeArray1 = assembly1.GetTypes();
            for (int num4 = 0; num4 < typeArray1.Length; num4++)
            {
                if (typeArray1[num4].GetInterface("IInitialize", true) != null)
                {
                    MethodInfo info3 = typeArray1[num4].GetMethod("Initialize", BindingFlags.Public | BindingFlags.Static);
                    if (info3 != null)
                    {
                        info3.Invoke(null, null);
                    }
                }
            }
            ConstructorInfo info4 = Utility.FindConstructor("Globals", Utility.externAsm);
            info4.Invoke(null);
            ushort num15 = Abilities.abilities[4].Id;
            this.worldSaveTimer = new WorldSave(World.WorldSavingTimer);
            float single1 = 533.3333f;
            float single2 = single1 / 16f;
            float single3 = single2 / 8f;
            int num5 = 0;
            int num6 = 0;
            for (int num7 = 0; num7 < 0x11; num7++)
            {
                int num8 = 8;
                if ((num7 % 2) == 0)
                {
                    num8 = 9;
                }
                for (int num9 = 0; num9 < num8; num9++)
                {
                    num5++;
                    float single4 = num9 * single3;
                    float single5 = (num7 * 0.5f) * single3;
                    if ((num7 % 2) == 1)
                    {
                        single4 += (single3 * 0.5f);
                    }
                    Zone.quickX[num6] = single4;
                    Zone.quickY[num6++] = single5;
                }
            }
            Console.Write("Loading maps...");
            World.mapZones = new MapZones();
            Console.WriteLine("[Done]");
            int num10 = 0;
            int num11 = 0;
            foreach (Account account1 in World.allAccounts)
            {
                num10++;
                foreach (Character character1 in account1.characteres)
                {
                    num11++;
                    if (character1.Friends != null)
                    {
                        ArrayList list1 = new ArrayList();
                        for (int num12 = 0; num12 < character1.Friends.Count; num12 += 2)
                        {
                            ulong num13 = (ulong) character1.Friends[num12];
                            string text2 = (string) character1.Friends[num12 + 1];
                            Account account2 = null;
                            foreach (Account account3 in World.allAccounts)
                            {
                                if (text2 == account3.Username)
                                {
                                    account2 = account3;
                                    break;
                                }
                            }
                            if (account2 != null)
                            {
                                foreach (Character character2 in account2.characteres)
                                {
                                    if (character2.Guid == num13)
                                    {
                                        list1.Add(character2);
                                        break;
                                    }
                                }
                            }
                        }
                        character1.Friends = list1;
                    }
                }
            }
            Console.WriteLine("{0} accounts, {1} characters", num10, num11);
            World.loading = false;
        }

        public static void Add(BaseCreature bc, float X, float Y, float Z, ushort MapId)
        {
            bc.X = X;
            bc.Y = Y;
            bc.Z = Z;
            bc.MapId = MapId;
            if (!World.Loading)
            {
                World.allMobiles.Add(bc, true);
            }
        }

        public static void Add(BaseSpawner bs, float X, float Y, float Z, ushort MapId)
        {
            World.allSpawners.Add(bs);
            bs.X = X;
            bs.Y = Y;
            bs.Z = Z;
            bs.MapId = MapId;
        }

        public static Corps Add(Character c, float X, float Y, float Z, ushort MapId)
        {
            Corps corps1 = new Corps(c.Guid);
            corps1.X = X;
            corps1.Y = Y;
            corps1.Z = Z;
            corps1.MapId = MapId;
            corps1.Name = c.Name;
            corps1.Model = c.Model;
            corps1.Faction = c.Faction;
            corps1.Bytes3 = (uint) ((((c.FacialHair << 0x18) | (c.Face << 0x10)) | (c.HairStyle << 8)) | c.HairColour);
            corps1.Bytes2 = (uint) (((c.Skin << 0x18) + (c.Gender << 0x10)) + (((int) c.Race) << 8));
            World.allMobiles.Add(corps1, false);
            return corps1;
        }

        public static GameObject Add(int gameObjectId, float X, float Y, float Z, ushort MapId)
        {
            GameObject obj1 = new GameObject(gameObjectId, X, Y, Z, MapId);
            World.allGameObjects.Add(obj1);
            return obj1;
        }

        public static BaseCreature Add(ConstructorInfo ct, float X, float Y, float Z, ushort MapId)
        {
            BaseCreature creature1 = null;
            creature1 = (BaseCreature) ct.Invoke(null);
            creature1.X = X;
            creature1.Y = Y;
            creature1.Z = Z;
            creature1.MapId = MapId;
            World.allMobiles.Add(creature1, true);
            return creature1;
        }

        public static BaseCreature Add(string mob, float X, float Y, float Z, ushort MapId)
        {
            ConstructorInfo info1 = Utility.FindConstructor(mob, Utility.externAsm);
            BaseCreature creature1 = null;
            creature1 = (BaseCreature) info1.Invoke(null);
            creature1.X = X;
            creature1.Y = Y;
            creature1.Z = Z;
            creature1.MapId = MapId;
            World.allMobiles.Add(creature1, true);
            return creature1;
        }

        public static GameObject Add(int fake, string customgameobject, float X, float Y, float Z, ushort MapId)
        {
			ConstructorInfo info1 = Utility.FindConstructor(customgameobject, Utility.externAsm);//fix add
            if (customgameobject == null)
            {
                return World.Add(fake, X, Y, Z, MapId);
            }
            //ConstructorInfo info1 = Utility.FindConstructor(customgameobject, Utility.externAsm);
            if (info1 == null)
            {
                info1 = Utility.FindConstructor(customgameobject);
            }
            GameObject obj1 = (GameObject) info1.Invoke(null);
            obj1.X = X;
            obj1.Y = Y;
            obj1.Z = Z;
            obj1.MapId = MapId;
			World.allGameObjects.Add(obj1);//fix add
            return obj1;
        }

        public void AddItem(Type t)
        {
            ConstructorInfo[] infoArray1 = t.GetConstructors();
            World.itemPool[this.itemsHash[t.ToString()]] = infoArray1[0];
        }

        public void AddMob(Type t)
        {
        }

        public static void AdjustSpawners()
        {
            int num1 = 0;
            FileStream stream1 = new FileStream("coordk.bin", FileMode.Open, FileAccess.Read);
            BinaryReader reader1 = new BinaryReader(stream1);
            ArrayList[] listArray1 = new ArrayList[0x2000];
        Label_0021:
            if (reader1.BaseStream.Position != reader1.BaseStream.Length)
            {
                int num2 = reader1.ReadInt32();
                float single1 = reader1.ReadSingle();
                float single2 = reader1.ReadSingle();
                float single3 = reader1.ReadSingle();
                float[] singleArray1 = new float[0x91];
                int num3 = 0;
                int num4 = 0;
                for (int num5 = 0; num5 < 0x11; num5++)
                {
                    int num6 = 8;
                    if ((num5 % 2) == 0)
                    {
                        num6 = 9;
                    }
                    for (int num7 = 0; num7 < num6; num7++)
                    {
                        num4++;
                        float single4 = reader1.ReadSingle();
                        if (single4 <= -10000f)
                        {
                            singleArray1[num3++] = -10000f;
                        }
                        else
                        {
                            singleArray1[num3++] = single4 + single2;
                        }
                    }
                }
                if (World.map[num2] == null)
                {
                    num1++;
                    goto Label_0021;
                }
                int num8 = (int) World.map[num2];
                if (listArray1[num8] == null)
                {
                    listArray1[num8] = new ArrayList();
                }
                listArray1[num8].Add(new Zone(single1, single3, single2, num2, singleArray1));
                goto Label_0021;
            }
            stream1.Close();
            int num9 = 0;
            foreach (BaseSpawner spawner1 in World.allSpawners)
            {
                float single5 = float.MaxValue;
                int num10 = 0;
                Zone zone1 = null;
                if (listArray1[spawner1.MapId] == null)
                {
                    Console.WriteLine("Unknow map id {0}", spawner1.MapId);
                    continue;
                }
                num9++;
                foreach (Zone zone2 in listArray1[spawner1.MapId])
                {
                    float single6 = Math.Abs((float) (zone2.y - spawner1.X));
                    float single7 = Math.Abs((float) (zone2.x - spawner1.Y));
                    single6 *= single6;
                    single7 *= single7;
                    single6 += single7;
                    if (single6 < single5)
                    {
                        single5 = single6;
                        num10 = zone2.zoneId;
                        zone1 = zone2;
                    }
                }
                if (num10 == 0)
                {
                    Console.WriteLine("");
                }
                spawner1.ZoneId = (ushort) num10;
                spawner1.RealX = zone1.y;
                spawner1.RealY = zone1.x;
                spawner1.RealZ = zone1.z;
                if ((num9 % 500) == 0)
                {
                    Console.WriteLine("Completed {0}", ((float) num9) / ((float) World.allSpawners.Count));
                }
            }
            /*int num11 = 0;
            for (int num12 = 0; num12 < World.allSpawners.Count; num12++)
            {
                BaseSpawner spawner2 = World.allSpawners[num12];
                for (int num13 = 0; num13 < World.allSpawners.Count; num13++)
                {
                    BaseSpawner spawner3 = World.allSpawners[num13];
                    if (((num13 != num12) && (spawner2.MapId == spawner3.MapId)) && (spawner2.QuickDistance(spawner3) < 0x57e4))
                    {
                        if (World.regSpawners[num12] == null)
                        {
                            World.regSpawners[num12] = new ArrayList();
                        }
                        (World.regSpawners[num12] as ArrayList).Add(num13);
                        num11++;
                    }
                }
            }*/
        }

        public static void AdjustSpawnersNew()
        {
            int num1 = 0;
            SpawnerList list1 = new SpawnerList();
            foreach (BaseSpawner spawner1 in World.allSpawners)
            {
                object[] objArray1;
                if (spawner1.MapId > 1)
                {
                    objArray1 = new object[4] { spawner1.X, spawner1.Y, spawner1.Z, spawner1.MapId } ;
                    Console.WriteLine("Invalid spawner at {0} {1} {2} continent {3}", objArray1);
                }
                else
                {
                    spawner1.ZoneId = World.mapZones.NearestZoneId(spawner1.MapId, spawner1.X, spawner1.Y);
                    if (spawner1.ZoneId == -1)
                    {
                        objArray1 = new object[4] { spawner1.X, spawner1.Y, spawner1.Z, spawner1.MapId } ;
                        Console.WriteLine("Invalid spawner at {0} {1} {2} continent {3}", objArray1);
                    }
                    else
                    {
                        MapPoint point1 = World.mapZones.NearestPoint(spawner1.MapId, spawner1.ZoneId, spawner1.X, spawner1.Y);
                        spawner1.RealX = point1.x;
                        spawner1.RealY = point1.y;
                        spawner1.RealZ = point1.z;
                        list1.Add(spawner1);
                    }
                }
                num1++;
                if ((num1 % 500) == 0)
                {
                    Console.WriteLine("Completed {0} %", (((float) num1) / ((float) World.allSpawners.Count)) * 100f);
                }
            }
            World.allSpawners = list1;
        }

        public static Trajet AllocateTrajet()
        {
            Trajet trajet1 = new Trajet();
            World.trajets.Add(trajet1);
            return trajet1;
        }

        public static Item CreateItem(string item)
        {
            ConstructorInfo info1 = Utility.FindConstructor(item, Utility.externAsm);
            return (Item) info1.Invoke(null);
        }

        public static Item CreateItemInPoolById(int id)
        {
            if (World.itemPool[id] == null)
            {
                return null;
            }
            return (Item) (World.itemPool[id] as ConstructorInfo).Invoke(null);
        }

        public static BaseQuest CreateQuestById(int id)
        {
            return (BaseQuest) World.questPool[id];
        }

        public static BaseQuest CreateQuestByType(Type typ)
        {
            return (BaseQuest) World.questPoolType[typ];
        }

        public static Mobile FindMobileByGUID(ulong guid)
        {
            if (World.allMobiles != null)
            {
                foreach (Mobile mobile1 in World.allMobiles.onEasternKindoms)
                {
                    if (mobile1.Guid == guid)
                    {
                        return mobile1;
                    }
                }
                foreach (Mobile mobile2 in World.allMobiles.onKalimdor)
                {
                    if (mobile2.Guid == guid)
                    {
                        return mobile2;
                    }
                }
            }
            return null;
        }

        public static Account FindPlayerAccountByCharacterGUID(ulong guid)
        {
            foreach (Account account1 in World.allAccounts)
            {
                foreach (Character character1 in account1.characteres)
                {
                    if (character1.Guid == guid)
                    {
                        return account1;
                    }
                }
            }
            return null;
        }

        public static uint GetActualTime()
        {
            DateTime time1 = DateTime.Now;
            int num1 = time1.Year - 0x7d0;
            int num2 = time1.Month - 1;
            int num3 = time1.Day - 1;
            int num4 = (int) time1.DayOfWeek;
            int num5 = time1.Hour;
            int num6 = time1.Minute;
            if (World.onGetActualTime != null)
            {
                World.onGetActualTime(ref num1, ref num2, ref num3, ref num4, ref num5, ref num6);
            }
            return (uint) (((((num6 | (num5 << 6)) | (num4 << 11)) | (num3 << 14)) | (num1 << 0x12)) | (num2 << 20));
        }

        public static Type ItemTypeById(int id)
        {
            return (World.itemPool[id] as ConstructorInfo).ReflectedType;
        }

        public static ConstructorInfo MobilePool(int id)
        {
            return (ConstructorInfo) World.mobilePool[id];
        }

        public static Type MobileTypeById(int id)
        {
            ConstructorInfo info1 = World.mobilePool[id] as ConstructorInfo;
            if (info1 == null)
            {
                Console.WriteLine("Unknow mobile id {0} !!!", id);
            }
            return info1.DeclaringType;
        }

        public static void Remove(Server.Object o, Mobile from)
        {
            if (World.allMobiles != null)
            {
                if ((from.LastSeen != null) && from.LastSeen.Player.KnownObjects.Contains(o))
                {
                    World.Remove(o, from.LastSeen);
                }
                else if (o is Mobile)
                {
                    World.allMobiles.Remove(o as Mobile);
                }
                else if (o is GameObject)
                {
                    World.allGameObjects.Remove(o as GameObject);
                }
            }
        }

        public static void RemoveTrajet(Trajet t)
        {
            World.trajets.Remove(t);
        }

		public static void Restart(int minutes)
		{
			if (minutes == 0)
			{
				string text1 = "Server is restarting now !!! ";
				World.allConnectedAccounts.BroadCastMessage(text1);
				MainConsole.world.SaveGame();
				MainConsole.Restart();
			}
			else
			{
				new WorldRestart(minutes);
				string text2 = "Server will restart in " + minutes.ToString() + " minutes ...";
				World.allConnectedAccounts.BroadCastMessage(text2);
			}
		}

		public static void Save()
		{
			MainConsole.world.SaveGame();
		}

		public void SaveGame()
		{
			this.worldSaveTimer.Save();
		}

		public void Slice1ms()
		{
			try
			{
				int[] numArray1 = new int[9] { 1, 10, 100, 500, 0x3e8, 0x1388, 0x7530, 0xea60, 0x36ee80 } ;
				while (World.notEnded)
				{
					int num1 = 0;
					World.datetime = DateTime.Now;
					Queue[] queueArray1 = World.timers;
					for (int num5 = 0; num5 < queueArray1.Length; num5++)
					{
						Queue queue1 = queueArray1[num5];
						long num2 = DateTime.Now.Ticks;
						int num3 = (int) ((num2 - this.lastCall[num1]) / ((long) 0x2710));
						if (num3 >= numArray1[num1])
						{
							for (int num4 = 0; num4 < queue1.Count; num4++)
							{
								WowTimer timer1 = (WowTimer) queue1.Dequeue();
								if (timer1.Slice(num2))
								{
									queue1.Enqueue(timer1);
								}
							}
							this.lastCall[num1] = DateTime.Now.Ticks;
						}
						num1++;
					}
					TimeSpan span1 = DateTime.Now.Subtract(World.datetime);
					World.total += span1.Ticks;
					Thread.Sleep(2);
				}
			}
			catch (Exception exception1)
			{
				Console.WriteLine("Timer exception !");
				Console.WriteLine(exception1.Message);
				Console.WriteLine(exception1.Source);
				Console.WriteLine(exception1.StackTrace);
				this.Slice1ms();
			}
		}

		public void TimerReport()
		{
			int num1 = 0;
			Queue[] queueArray1 = World.timers;
			for (int num2 = 0; num2 < queueArray1.Length; num2++)
			{
				Queue queue1 = queueArray1[num2];
				Console.WriteLine("Timer queue {0} = {1}", num1++, queue1.Count);
			}
		}


		// Properties
		public static Hashtable FactionAssociated
		{
			get
			{
				return World.factionsAssociated;
			}
		}

		public static Hashtable ItemsPool
		{
			get
			{
				return World.itemPool;
			}
		}

		public static bool Loading
		{
			get
			{
				return World.loading;
			}
		}

		public static Hashtable MobilesPool
		{
			get
			{
				return World.mobilePool;
			}
		}

		public static Hashtable QuestPool
		{
			get
			{
				return World.questPool;
			}
		}

		// Fields
		public static Accounts allAccounts;
		public static Accounts allConnectedAccounts;
		public static ArrayList allConnectedChars;
		public static GameObjects allGameObjects;
		public static MobileList allMobiles;
		public static ArrayList allMobs;
		public static string AllowHttpFrom;
		public static SpawnerList allSpawners;
		public static ArrayList Cemetery;
		public static Hashtable continent;
		public static Hashtable continentZones;
		private static DateTime datetime;
		public static int DecayTime;
		public static int DropGoldMultiplier;
		public static float DropMultiplier;
		public static Hashtable Emote;
		private static Hashtable factionsAssociated;
		public static Loot[] FishLoot;
		public static FishingZones FishZones;
		public static bool FreeForAll;
		public static Hashtable FriendRaces;
		public static GameObjectsList GameObjectsAssociated;
		public static int HttpServerPort;
		private static Hashtable itemPool;
		private Hashtable itemsHash;
		private long[] lastCall;
		private static bool loading;
		public static long[] localTime;
		public static Hashtable Locations;
		public static Hashtable map;
		public static MapZones mapZones;
		private static Hashtable mobilePool;
		public static Hashtable MountsList;
		public static bool nixSystem;
		public static bool notEnded;
		public static OnGetActualTime onGetActualTime;
		public static OnHttpDataReceived onHttpDataReceived;
		public static OnSaveDelegate onSave;
		public static string Path;
		public static ArrayList PendingGroup;
		public static bool poolsReady;
		private static Hashtable questPool;
		private static Hashtable questPoolType;
		public static Hashtable regSpawners;
		public static string ServerIP;
		public static string ServerName;
		public static int ServerPort;
		public static DateTime startingTime;
		public static byte[] tempBuff;
		public static Hashtable tempMobileCts;
		public static Queue[] timers;
		public static long total;
		public static Trajets trajets;
		public static string Version;
		public static int[] ViewingDistance;
		private WorldSave worldSaveTimer;
		public static int WorldSavingTimer;
		public static Hashtable zoneIds;
		public static Hashtable zones;

		// Nested Types
		public delegate void OnGetActualTime(ref int year, ref int month, ref int day, ref int dayOfTheWeek, ref int hour, ref int minute);


		public delegate bool OnHttpDataReceived(HttpConnection ch, byte[] data, int lenght);


		public delegate void OnSaveDelegate();


		private class WorldRestart : WowTimer
		{
			// Methods
			public WorldRestart(int time) : base(WowTimer.Priorities.Minute, 60000)
			{
				this.last = 0;
				this.inMinute = 0;
				this.inMinute = time;
				base.Start();
			}

			public override void OnTick()
			{
				this.last++;
				if (this.last > this.inMinute)
				{
					string text1 = "Server is restarting now !!! ";
					World.allConnectedAccounts.BroadCastMessage(text1);
					MainConsole.world.SaveGame();
					MainConsole.Restart();
					base.Stop();
				}
				else
				{
					if ((this.last != this.inMinute) && (this.inMinute != 0))
					{
						int num1 = this.inMinute - this.last;
						string text2 = "Server will restart in " + num1.ToString() + " minutes ...";
						World.allConnectedAccounts.BroadCastMessage(text2);
					}
					base.OnTick();
				}
			}


			// Fields
			private int inMinute;
			private int last;
		}

		private class WorldSave : WowTimer
		{
			// Methods
			public WorldSave(int time) : base(WowTimer.Priorities.Minute, 60000)
			{
				this.every = time;
				base.Start();
			}

			public override void OnTick()
			{
				this.timer++;
				if (this.every == this.timer)
				{
					this.Save();
					this.timer = 0;
				}
				base.OnTick();
			}

			public void Save()
			{
				
				string text1 = "Saving game...";
				World.allConnectedAccounts.BroadCastMessage(text1);
				DateTime time1 = DateTime.Now;
				World.allAccounts.Save(@".\accounts.xml");
				if (World.allGameObjects.Dirty)
				{
					World.allGameObjects.Serialize(new GenericWriter(@".\objects.bin"));
				}
				if (World.trajets.Dirty)
				{
					World.trajets.Serialize(new GenericWriter(@".\coord.bin"));
				}
				if (World.allSpawners.Dirty)
				{
					World.allSpawners.Serialize(new GenericWriter(@".\spawnpoints.bin"));
				}
				GenericWriter writer1 = new GenericWriter(@".\savegame.bin");
				World.allMobiles.Serialize(writer1);
				IEnumerator enumerator1 = World.allAccounts.GetEnumerator();
				while (enumerator1.MoveNext())
				{
					Account account = (Account) enumerator1.Current;
					try
					{
						foreach (Character character1 in account.characteres)
						{
							writer1.Write(1);
							character1.Serialize(writer1);
						}
						continue;
					}
					finally
					{
						IDisposable disposable1 = account as IDisposable;
						if (disposable1 != null)
						{
							disposable1.Dispose();
						}
					}
				}
				writer1.Write(0);
				writer1.Close();
				if (World.onSave != null)
				{
					World.onSave();
				}
				GC.Collect();
				TimeSpan span1 = DateTime.Now.Subtract(time1);
				text1 = "Game saved in " + span1.TotalSeconds.ToString() + " sec";
				World.allConnectedAccounts.BroadCastMessage(text1);
			}


			// Fields
			private int every;
			private int timer;
		}
	}
}
