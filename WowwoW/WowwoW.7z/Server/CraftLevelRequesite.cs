namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int CraftLevelRequesite(Character c, int id);

}

