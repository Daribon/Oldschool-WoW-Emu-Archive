namespace Server
{
    using System;
    using System.Collections;
    using System.Runtime.CompilerServices;

    public delegate bool NextAttackEffectDelegateMultiple(BaseAbility ba, Mobile c, Mobile target, ArrayList add, int num);

}

