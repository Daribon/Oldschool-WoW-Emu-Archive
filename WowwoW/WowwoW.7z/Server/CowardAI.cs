namespace Server
{
    using HelperTools;
    using System;

    public class CowardAI : BaseAIType
    {
        // Methods
        public CowardAI(BaseCreature bc) : base(AITypes.NonAgressiveAnimalAI, bc)
        {
            base.From.AIState = AIStates.LookingForPrey;
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if ((AIState != AIStates.Attack) && (AIState != AIStates.Fighting))
            {
                base.OnBeginFight(by);
                return AIStates.BeingAttacked;
            }
            return AIState;
        }

        public override void OnTick()
        {
            if (base.From.DebugSniffer != null)
            {
                base.From.DebugSniffer.SendMessage("PredatorAI::OnTick");
            }
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 1800f))
            {
                base.From.AIState = AIStates.LookingForPrey;
                base.From.AttackTarget = null;
            }
            else
            {
                if ((base.From.AttackTarget == null) || base.From.AttackTarget.Dead)
                {
                    foreach (Character character1 in World.allConnectedChars)
                    {
                        if ((((base.From.Distance(character1) < base.MaxViewDistance) && (Utility.Random4() == 0)) && (base.From.IsHostile(character1) && base.From.CanSee(character1))) && !character1.Dead)
                        {
                            base.OnBeginFight(character1);
                            base.From.AIState = AIStates.BeingAttacked;
                            base.From.AttackTarget = character1;
                            if (base.From.DebugSniffer != null)
                            {
                                base.From.DebugSniffer.SendMessage("PredatorAI::OnTick::SeePrey");
                            }
                            return;
                        }
                    }
                }
                AIStates states1 = base.AIState;
                if (states1 != AIStates.DoingNothing)
                {
                    if (states1 == AIStates.LookingForPrey)
                    {
                        base.From.Running = false;
                        if (Utility.Random16() < 1)
                        {
                            base.AIState = AIStates.Pause1;
                        }
                    }
                    else
                    {
                        switch (states1)
                        {
                            case AIStates.Pause1:
                            {
                                base.AIState = AIStates.Pause2;
                                return;
                            }
                            case AIStates.Pause2:
                            {
                                base.AIState = AIStates.Pause3;
                                return;
                            }
                            case AIStates.Pause3:
                            {
                                base.AIState = AIStates.LookingForPrey;
                                return;
                            }
                        }
                    }
                }
                else
                {
                    base.AIState = AIStates.LookingForPrey;
                    base.From.Running = false;
                }
            }
        }

    }
}

