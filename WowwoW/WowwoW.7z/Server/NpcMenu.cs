namespace Server
{
    using System;
    using System.Collections;

    public class NpcMenu
    {
        // Methods
        public NpcMenu()
        {
            this.menus = new ArrayList();
            this.icons = new ArrayList();
        }

        public void AddMenu(string menu)
        {
            this.menus.Add(menu);
            this.icons.Add(0);
        }

        public void AddMenu(int icon, string menu)
        {
            this.menus.Add(menu);
            this.icons.Add((short) icon);
        }


        // Properties
        public ArrayList Icon
        {
            get
            {
                return this.icons;
            }
        }

        public ArrayList Menu
        {
            get
            {
                return this.menus;
            }
        }


        // Fields
        private ArrayList icons;
        private ArrayList menus;
    }
}

