namespace Server
{
    using HelperTools;
    using Server.Items;
    using System;
    using System.Collections;

    public class Object
    {
        // Methods
        static Object()
        {
            Server.Object.GUID = 0x213632;
            Server.Object.Blank = new byte[0x98];
            Server.Object.Blank26 = new byte[0x1a];
            Server.Object.updateValues = new ArrayList();
        }

        public Object()
        {
            this.treasure = null;
        }

        public Object(int type) : this()
        {
            this.X = 0f;
            this.Y = 0f;
            this.Z = 0f;
            this.Orientation = 0f;
            this.zoneId = 0;
            this.mapId = 0;
            this.guid = 0;
        }

        public Object(ulong _guid) : this()
        {
            this.guid = _guid;
        }

        public Object(ulong _guid, float x, float y, float z, float orient) : this()
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            this.Orientation = orient;
            this.zoneId = 0;
            this.mapId = 0;
            this.guid = _guid;
        }

        public Object(ulong _guid, float x, float y, float z, float orient, ushort mapid) : this()
        {
            this.X = x;
            this.Y = y;
            this.Z = z;
            this.Orientation = orient;
            this.zoneId = 0;
            this.mapId = mapid;
            this.guid = _guid;
        }

        public virtual void Delete()
        {
        }

        public virtual void Deserialize(GenericReader gr)
        {
            gr.ReadInt();
            this.guid = gr.ReadInt64();
            this.X = gr.ReadFloat();
            this.Y = gr.ReadFloat();
            this.Z = gr.ReadFloat();
            this.Orientation = gr.ReadFloat();
            this.MapId = (ushort) gr.ReadShort();
            this.ZoneId = gr.ReadInt();
        }

        public float Distance(Server.Object m)
        {
            if (m.MapId != this.mapId)
            {
                return float.MaxValue;
            }
            float single1 = m.X - this.X;
            float single2 = m.Y - this.Y;
            float single3 = m.Z - this.Z;
            return (((single1 * single1) + (single2 * single2)) + (single3 * single3));
        }

        public float Distance(float x, float y, float z)
        {
            float single1 = x - this.X;
            float single2 = y - this.Y;
            float single3 = z - this.Z;
            return (((single1 * single1) + (single2 * single2)) + (single3 * single3));
        }

        public void FlushUpdateData(byte[] data, ref int offset, int s)
        {
            int num1 = s * 4;
            Converter.ToBytes((byte) s, data, ref offset);
            Converter.ToBytes(Server.Object.updateMask, data, ref offset, num1);
            foreach (object obj1 in Server.Object.updateValues)
            {
                if (obj1 is int)
                {
                    Converter.ToBytes((int) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is byte)
                {
                    Converter.ToBytes((byte) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is short)
                {
                    Converter.ToBytes((short) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is ushort)
                {
                    Converter.ToBytes((ushort) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is uint)
                {
                    Converter.ToBytes((uint) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is float)
                {
                    Converter.ToBytes((float) obj1, data, ref offset);
                    continue;
                }
                Converter.ToBytes((int) obj1, data, ref offset);
            }
            Server.Object.updateValues.Clear();
        }

        public void FlushUpdateData(byte[] data, ref int offset, int type2, int type3, int typeA9)
        {
            int num1 = 0x6d;
            if (((type2 == 0) && (type3 == 1)) && (typeA9 == 1))
            {
                num1 = 5;
            }
            if (((type2 == 0) && (type3 == 1)) && (typeA9 == 2))
            {
                num1 = 8;
            }
            if (((type2 == 0) && (type3 == 1)) && (typeA9 == 3))
            {
                num1 = 0x18;
            }
            if (((type2 == 0) && (type3 == 1)) && (typeA9 == 4))
            {
                num1 = 0x18;
            }
            if (((type2 == 0) && (type3 == 1)) && (typeA9 == 5))
            {
                num1 = 4;
            }
            if (((type2 == 0) && (type3 == 0)) && (typeA9 == 0))
            {
                num1 = 0x70;
            }
            Converter.ToBytes((byte) (num1 / 4), data, ref offset);
            Converter.ToBytes(Server.Object.updateMask, data, ref offset, num1 - 1);
            foreach (object obj1 in Server.Object.updateValues)
            {
                if (obj1 is int)
                {
                    Converter.ToBytes((int) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is byte)
                {
                    Converter.ToBytes((byte) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is short)
                {
                    Converter.ToBytes((short) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is ushort)
                {
                    Converter.ToBytes((ushort) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is uint)
                {
                    Converter.ToBytes((uint) obj1, data, ref offset);
                    continue;
                }
                if (obj1 is float)
                {
                    Converter.ToBytes((float) obj1, data, ref offset);
                    continue;
                }
                Converter.ToBytes((int) obj1, data, ref offset);
            }
            Server.Object.updateValues.Clear();
        }

        public virtual void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther)
        {
        }

        public virtual void PrepareUpdateData(byte[] data, ref int offset, UpdateType type, bool forOther, Character f)
        {
        }

        public int QuickDistance(Server.Object m)
        {
            if (m.MapId != this.mapId)
            {
                return 0x7fffffff;
            }
            int num1 = ((int) m.X) - ((int) this.X);
            int num2 = ((int) m.Y) - ((int) this.Y);
            return ((num1 * num1) + (num2 * num2));
        }

        public float QuickDistance(Position p)
        {
            if (p.MapId != this.mapId)
            {
                return float.MaxValue;
            }
            float single1 = p.X - this.X;
            float single2 = p.Y - this.Y;
            return ((single1 * single1) + (single2 * single2));
        }

        public int QuickDistance(int px, int py)
        {
            int num1 = px - ((int) this.X);
            int num2 = py - ((int) this.Y);
            return ((num1 * num1) + (num2 * num2));
        }

        public void ResetBitmap()
        {
            Server.Object.updateMask = new BitArray(Const.PlayerMaxBits);
            Server.Object.updateValues.Clear();
        }

        public virtual bool SeenBy(Character c)
        {
            return true;
        }

        public virtual void Serialize(GenericWriter gw)
        {
            gw.Write(0);
            gw.Write(this.guid);
            gw.Write(this.X);
            gw.Write(this.Y);
            gw.Write(this.Z);
            gw.Write(this.Orientation);
            gw.Write(this.MapId);
            gw.Write(this.ZoneId);
        }

        private void setUpdateFloatValue(int index, float val)
        {
            Server.Object.updateValues.Add(val);
            Server.Object.updateMask.Set(index, true);
        }

        protected void setUpdateValue(int index, byte val)
        {
            Server.Object.updateValues.Add(val);
            Server.Object.updateMask.Set(index, true);
        }

        protected void setUpdateValue(int index, short val)
        {
            Server.Object.updateValues.Add(val);
            Server.Object.updateMask.Set(index, true);
        }

        protected void setUpdateValue(int index, int val)
        {
            Server.Object.updateValues.Add((uint) val);
            Server.Object.updateMask.Set(index, true);
        }

        protected void setUpdateValue(int index, float val)
        {
            byte[] buffer1 = BitConverter.GetBytes(val);
            int num1 = BitConverter.ToInt32(buffer1, 0);
            this.setUpdateValue(index, num1);
        }

        protected void setUpdateValue(int index, ushort val)
        {
            Server.Object.updateValues.Add(val);
            Server.Object.updateMask.Set(index, true);
        }

        protected void setUpdateValue(int index, uint val)
        {
            Server.Object.updateValues.Add(val);
            Server.Object.updateMask.Set(index, true);
        }

        protected void setUpdateValue(int index, ulong val)
        {
            Server.Object.updateValues.Add((uint) (val & 0xffffffff));
            Server.Object.updateValues.Add((uint) ((val >> 0x20) & 0xffffffff));
            Server.Object.updateMask.Set(index, true);
            Server.Object.updateMask.Set(index + 1, true);
        }


        // Properties
        public ulong Guid
        {
            get
            {
                return this.guid;
            }
            set
            {
                this.guid = value;
            }
        }

        public ushort MapId
        {
            get
            {
                return this.mapId;
            }
            set
            {
                this.mapId = value;
            }
        }

        public float Orientation
        {
            get
            {
                return this.orientation;
            }
            set
            {
                this.orientation = value;
            }
        }

        public BaseSpawner SpawnerLink
        {
            get
            {
                return this.spawnerLink;
            }
            set
            {
                this.spawnerLink = value;
            }
        }

        public virtual byte[] tempBuff
        {
            get
            {
                return World.tempBuff;
            }
        }

        public Item[] Treasure
        {
            get
            {
                return this.treasure;
            }
            set
            {
                this.treasure = value;
            }
        }

        public virtual float X
        {
            get
            {
                return this.positionX;
            }
            set
            {
                this.positionX = value;
            }
        }

        public virtual float Y
        {
            get
            {
                return this.positionY;
            }
            set
            {
                this.positionY = value;
            }
        }

        public virtual float Z
        {
            get
            {
                return this.positionZ;
            }
            set
            {
                this.positionZ = value;
            }
        }

        public int ZoneId
        {
            get
            {
                return this.zoneId;
            }
            set
            {
                this.zoneId = value;
            }
        }


        // Fields
        public static byte[] Blank;
        public static byte[] Blank26;
        private ulong guid;
        public static ulong GUID;
        private ushort mapId;
        private float orientation;
        private float positionX;
        private float positionY;
        private float positionZ;
        private BaseSpawner spawnerLink;
        private Item[] treasure;
        private static BitArray updateMask;
        private static ArrayList updateValues;
        private int zoneId;
    }
}

