namespace Server
{
    using System;

    public enum ProfessionLevels
    {
        // Fields
        Apprentice = 0,
        Artisan = 3,
        Expert = 2,
        Journeyman = 1
    }
}

