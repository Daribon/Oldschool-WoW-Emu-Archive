namespace Server
{
    using System;

    public class TauraneSkill : Skill
    {
        // Methods
        public TauraneSkill()
        {
        }

        public TauraneSkill(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x73;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x73;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 670;
            }
        }

    }
}

