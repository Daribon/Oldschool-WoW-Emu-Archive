namespace Server
{
    using Server.Items;
    using System;
    using System.Runtime.CompilerServices;

    public delegate void OnSelfItemSpellEffect(BaseAbility ba, Mobile c, Item.SpecialAbility sa, Item it);

}

