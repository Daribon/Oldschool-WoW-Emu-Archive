namespace Server
{
    using System;

    public class Survival : Skill
    {
        // Methods
        public Survival()
        {
        }

        public Survival(int current, int max) : base(current, max)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x33;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x33;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 0;
            }
        }

    }
}

