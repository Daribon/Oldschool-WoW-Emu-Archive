namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool CharacterChooseRace(Character c, Races r);

}

