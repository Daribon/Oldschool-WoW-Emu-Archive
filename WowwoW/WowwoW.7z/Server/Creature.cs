namespace Server
{
    using System;

    public class Creature : Mobile
    {
        // Methods
        public Creature()
        {
        }

    }
}

