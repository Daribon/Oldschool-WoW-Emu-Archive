namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void TargetXYZSpellEffect(BaseAbility ba, Mobile c, float X, float Y, float Z);

}

