namespace Server
{
    using System;

    public class SummonedAI : BaseAIType
    {
        // Methods
        public SummonedAI(Mobile s, BaseCreature bc) : base(AITypes.Custom, bc)
        {
            this.summonedFrom = s;
            base.From.AIState = AIStates.Follow;
            base.From.AIStance = AIStances.Defensive;
        }

        public override AIStates OnGetHit(Mobile by, AIStates AIState, int dmg)
        {
            if (((by != this.summonedFrom) && (AIState != AIStates.Attack)) && (AIState != AIStates.Fighting))
            {
                return AIStates.BeingAttacked;
            }
            return AIState;
        }

        public override void OnTick()
        {
            if (base.From.DebugSniffer != null)
            {
                base.From.DebugSniffer.SendMessage("SummonedAI::OnTick");
            }
            if (((base.From.AIState == AIStates.Attack) && (base.From.AttackTarget != null)) && (base.From.Distance(base.From.AttackTarget) > 1800f))
            {
                base.From.AIState = AIStates.Follow;
                base.From.AttackTarget = null;
            }
            else
            {
                if (((base.From.AttackTarget == null) || base.From.AttackTarget.Dead) && (base.From.AIStance != AIStances.Passive))
                {
                    if (this.summonedFrom == null)
                    {
                        Console.WriteLine("Stage summonedFrom NULL");
                        return;
                    }
                    if ((this.summonedFrom as Character).Player == null)
                    {
                        base.From.X = -2000f;
                        base.From.Y = -2000f;
                        base.From.Z = 1000f;
                        base.From.MapId = 2;
                        return;
                    }
                    foreach (Server.Object obj1 in (this.summonedFrom as Character).Player.KnownObjects)
                    {
                        if (!(obj1 is Mobile))
                        {
                            continue;
                        }
                        Mobile mobile1 = obj1 as Mobile;
                        if ((((mobile1 != this.summonedFrom) && (base.From.AIStance == AIStances.Agressive)) && ((this.summonedFrom.Reputation(mobile1) < 0.3f) && base.From.CanSee(mobile1))) && (!mobile1.Dead && (base.From.Distance(mobile1) < base.MaxViewDistance)))
                        {
                            base.OnBeginFight(mobile1);
                            base.From.AIState = AIStates.BeingAttacked;
                            base.From.AttackTarget = mobile1;
                            if (base.From.DebugSniffer != null)
                            {
                                base.From.DebugSniffer.SendMessage("SummonedAI::OnTick::SeePrey");
                            }
                            return;
                        }
                    }
                }
                AIStates states1 = base.AIState;
                if (states1 != AIStates.DoingNothing)
                {
                    if (states1 == AIStates.Pause1)
                    {
                        return;
                    }
                    if (states1 != AIStates.Follow)
                    {
                        return;
                    }
                }
                else
                {
                    base.From.AIState = AIStates.Follow;
                    return;
                }
                float single1 = this.summonedFrom.Distance(base.From);
                float single2 = base.From.CombatReach + this.summonedFrom.CombatReach;
                if (single1 > 5f)
                {
                    if (single1 > single2)
                    {
                        base.From.Running = true;
                    }
                    else
                    {
                        base.From.Running = false;
                    }
                    double num1 = (float) Math.Atan2((double) (this.summonedFrom.Y - base.From.Y), (double) (this.summonedFrom.X - base.From.X));
                    num1 += 3.1415926535897931;
                    base.From.MoveTo(this.summonedFrom.X + ((float) ((Math.Cos(num1) * single2) * 1.5)), this.summonedFrom.Y + ((float) ((Math.Sin(num1) * single2) * 1.5)), this.summonedFrom.Z);
                }
            }
        }


        // Fields
        private Mobile summonedFrom;
    }
}

