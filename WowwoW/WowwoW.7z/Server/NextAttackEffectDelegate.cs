namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool NextAttackEffectDelegate(BaseAbility ba, Mobile c, Mobile target, int num);

}

