namespace Server
{
    using System;
    using System.Collections;

    public class GameObjectsListEnumerator : IDictionaryEnumerator, IEnumerator
    {
        // Methods
        internal GameObjectsListEnumerator(GameObjectsList enumerable)
        {
            this.innerEnumerator = enumerable.InnerHash.GetEnumerator();
        }

        public bool MoveNext()
        {
            return this.innerEnumerator.MoveNext();
        }

        public void Reset()
        {
            this.innerEnumerator.Reset();
        }


        // Properties
        public object Current
        {
            get
            {
                return this.innerEnumerator.Current;
            }
        }

        public DictionaryEntry Entry
        {
            get
            {
                return this.innerEnumerator.Entry;
            }
        }

        public int Key
        {
            get
            {
                return (int) this.innerEnumerator.Key;
            }
        }

        object IDictionaryEnumerator.Key
        {
            get
            {
                return this.Key;
            }
        }

        object IDictionaryEnumerator.Value
        {
            get
            {
                return this.Value;
            }
        }

        public Type Value
        {
            get
            {
                return (Type) this.innerEnumerator.Value;
            }
        }


        // Fields
        private IDictionaryEnumerator innerEnumerator;
    }
}

