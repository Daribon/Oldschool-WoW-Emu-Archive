namespace Server
{
    using System;

    public class PlateMailSkill : Skill
    {
        // Methods
        public PlateMailSkill()
        {
        }

        public PlateMailSkill(int current, int max) : base(1, 1)
        {
        }


        // Properties
        public override ushort Id
        {
            get
            {
                return 0x125;
            }
        }

        public static int SkillId
        {
            get
            {
                return 0x125;
            }
        }

        public override ushort SpellId
        {
            get
            {
                return 750;
            }
        }

    }
}

