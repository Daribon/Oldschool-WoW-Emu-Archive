namespace Server
{
    using System;

    public class Packet
    {
        // Methods
        public Packet(byte[] d, int l)
        {
            byte[] buffer1 = new byte[l];
            Buffer.BlockCopy(d, 0, buffer1, 0, l);
            this.data = buffer1;
            this.len = l;
        }


        // Fields
        public byte[] data;
        public int len;
    }
}

