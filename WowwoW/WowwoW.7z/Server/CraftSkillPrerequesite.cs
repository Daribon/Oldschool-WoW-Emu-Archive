namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate int CraftSkillPrerequesite(Character c, int id);

}

