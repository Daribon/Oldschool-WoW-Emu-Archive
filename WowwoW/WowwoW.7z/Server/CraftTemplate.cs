namespace Server
{
    using Server.Items;
    using System;
    using System.Collections;

    public class CraftTemplate : BaseAbility
    {
        // Methods
        public CraftTemplate(int ob, ushort i, int t1, int t2, int[] mat, short[] nmat) : base(i, 0x7d0)
        {
            this.objectCraft = ob;
            this.tool1 = t1;
            this.tool2 = t2;
            this.materials = mat;
            this.nMaterials = nmat;
        }

        public override int CastingTime(Mobile from)
        {
            return 0x9c4;
        }

        public void Create(Mobile.Casting cast, Mobile c)
        {
            Skill skill1;
            bool flag1 = true;
            if ((c as Character).FindAFreeSlot() != Slots.None)
            {
                new ArrayList();
                for (int num1 = 0; num1 < this.nMaterials.Length; num1++)
                {
                    if (this.nMaterials[num1] <= 0)
                    {
                        break;
                    }
                    int num2 = this.nMaterials[num1];
                    if (c is Character)
                    {
                        int num3 = (c as Character).FindAmountOfItemById(this.materials[num1]);
                        if (num2 > num3)
                        {
                            flag1 = false;
                            c.SpellFaillure(SpellFailedReason.Required, World.CreateItemInPoolById(this.materials[num1]).Name);
                            break;
                        }
                    }
                }
                if (flag1)
                {
                    for (int num4 = 0; num4 < this.nMaterials.Length; num4++)
                    {
                        if ((this.nMaterials[num4] > 0) && (c is Character))
                        {
                            (c as Character).ConsumeItemByIdUpTo(this.materials[num4], this.nMaterials[num4]);
                        }
                    }
                }
            }
            if (!flag1)
            {
                return;
            }
            int num5 = c.cast.id;
            c.SpellSuccess();
            Item item1 = World.CreateItemInPoolById(this.objectCraft);
            if (item1.MaxCount == 0)
            {
                item1.MaxCount = 1;
            }
            if (!(c is Character))
            {
                return;
            }
            c.cast.id = num5;
            (c as Character).PutObjectInBackpack(item1, 1, true);
            object obj1 = AbilityClasses.abilityClasses[num5];
            if (obj1 == null)
            {
                return;
            }
            int num6 = 0;
            int num7 = (int) obj1;
            if (num7 <= 0x1a)
            {
                if (num7 == 10)
                {
                    num6 = 0xa4;
                }
                else if (num7 == 14)
                {
                    num6 = 0xb9;
                }
                else
                {
                    switch (num7)
                    {
                        case 0x18:
                        {
                            num6 = 0xca;
                            goto Label_01C6;
                        }
                        case 0x19:
                        {
                            goto Label_01C6;
                        }
                        case 0x1a:
                        {
                            num6 = 0x14d;
                            goto Label_01C6;
                        }
                    }
                }
            }
            else if (num7 != 0x36)
            {
                if (num7 == 60)
                {
                    num6 = 0xba;
                }
                else if (num7 == 0x68)
                {
                    num6 = 0xc5;
                }
            }
            else
            {
                num6 = LeatherSkill.SkillId;
            }
        Label_01C6:
            skill1 = c.AllSkills[(ushort) num6];
            if (((skill1 != null) && (skill1.Current < skill1.Cap(c))) && c.SkillUp(skill1.Current, 30, 1))
            {
                skill1.Current = (ushort) (skill1.Current + 1);
                (c as Character).SendSkillUpdate();
            }
        }


        // Fields
        private int[] materials;
        private short[] nMaterials;
        private int objectCraft;
        private int tool1;
        private int tool2;
    }
}

