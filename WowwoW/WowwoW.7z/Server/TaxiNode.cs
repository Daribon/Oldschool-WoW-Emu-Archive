namespace Server
{
    using System;

    public class TaxiNode
    {
        // Methods
        public TaxiNode(int _id, short _mapId, double _x, double _y, double _z)
        {
            this.mountId = 0;
            this.id = _id;
            this.mapId = _mapId;
            this.x = (float) _x;
            this.y = (float) _y;
            this.z = (float) _z;
        }

        public TaxiNode(int _id, short _mapId, double _x, double _y, double _z, int _mountId)
        {
            this.mountId = 0;
            this.id = _id;
            this.mapId = _mapId;
            this.x = (float) _x;
            this.y = (float) _y;
            this.z = (float) _z;
            this.mountId = _mountId;
        }


        // Fields
        public int id;
        public short mapId;
        public int mountId;
        public float x;
        public float y;
        public float z;
    }
}

