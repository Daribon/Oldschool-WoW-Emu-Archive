namespace Server
{
    using System;
    using System.Collections;
    using System.Net;
    using System.Net.Sockets;

    public class RealmServer : IDisposable
    {
        // Methods
        static RealmServer()
        {
            RealmServer.clients = new ArrayList();
        }

        public RealmServer(string i, int pt)
        {
            this.totalSend = 0;
            this.totalReceive = 0;
            this.ip = i;
            this.port = pt;
            IPHostEntry entry1 = Dns.Resolve(i);
            IPEndPoint point1 = new IPEndPoint(entry1.AddressList[0], this.port);
            this.addressFamily = point1.Address.AddressFamily;
            this.address = point1.Address;
            this.Start();
        }

        public void Dispose()
        {
            while (RealmServer.clients.Count > 0)
            {
                ((SockClient) RealmServer.clients[0]).Dispose();
            }
            try
            {
                this.listenSocket.Shutdown(SocketShutdown.Both);
            }
            catch
            {
            }
            if (this.listenSocket != null)
            {
                this.listenSocket.Close();
            }
        }

        public virtual void OnAccept(IAsyncResult ar)
        {
            try
            {
                Socket socket1 = this.listenSocket.EndAccept(ar);
                if (socket1 != null)
                {
                    PlayerHandler handler1 = new PlayerHandler(socket1, new RemoveClientDelegate(this.RemoveClient));
                    RealmServer.clients.Add(handler1);
                    handler1.Start();
                }
            }
            catch
            {
            }
            try
            {
                this.listenSocket.BeginAccept(new AsyncCallback(this.OnAccept), this.listenSocket);
            }
            catch
            {
                this.Dispose();
                return;
            }
        }

        public void RemoveClient(SockClient client)
        {
            (client as PlayerHandler).Logout();
            RealmServer.clients.Remove(client);
        }

        public bool Start()
        {
            try
            {
                this.listenSocket = new Socket(this.addressFamily, SocketType.Stream, ProtocolType.Tcp);
                this.listenSocket.Bind(new IPEndPoint(IPAddress.Any, this.port));
                Console.WriteLine("Listen on port {0}, IP {1}", this.port, this.address.ToString());
                this.listenSocket.Listen(0x3e8);
                this.listenSocket.BeginAccept(new AsyncCallback(this.OnAccept), this.listenSocket);
            }
            catch (Exception exception1)
            {
                Console.WriteLine("Failled to list on port {0}\n{1}", this.port, exception1.Message);
                this.listenSocket = null;
                return false;
            }
            return true;
        }


        // Fields
        private IPAddress address;
        private AddressFamily addressFamily;
        public static ArrayList clients;
        private string ip;
        private Socket listenSocket;
        private int port;
        public int totalReceive;
        public int totalSend;
    }
}

