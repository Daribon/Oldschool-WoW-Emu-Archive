// Assembly WowwoW, Version 0.7.4.39636

[assembly: System.Reflection.AssemblyVersion("0.7.4.39636")]
[assembly: System.Reflection.AssemblyDescription("")]
[assembly: System.Reflection.AssemblyTitle("")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyTrademark("")]
[assembly: System.Reflection.AssemblyCopyright("")]
[assembly: System.Reflection.AssemblyProduct("")]
[assembly: System.Reflection.AssemblyCompany("")]
// Module WowwoW.exe
// Assembly Reference mscorlib
// Assembly Reference System.Xml
// Assembly Reference System
// Assembly Reference ICSharpCode.SharpZipLib

