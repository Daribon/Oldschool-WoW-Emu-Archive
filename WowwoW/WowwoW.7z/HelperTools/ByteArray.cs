namespace HelperTools
{
    using System;
    using System.Reflection;

    public class ByteArray : ByteArrayBase
    {
        // Methods
        public ByteArray(byte[] d)
        {
            this.data = d;
        }

        public ByteArray(byte[] d, bool le) : base(le)
        {
            this.data = d;
        }

        public override ByteArrayBase Add(byte b)
        {
            this.data[this.pos++] = b;
            return this;
        }

        public override byte[] GetArray(int start, int count)
        {
            byte[] buffer1 = new byte[count];
            for (int num1 = 0; num1 < count; num1++)
            {
                buffer1[num1] = this.data[num1 + start];
            }
            return buffer1;
        }

        public static byte[] GetByteArray(byte[] b, int pos, int len)
        {
            byte[] buffer1 = new byte[len];
            for (int num1 = 0; num1 < len; num1++)
            {
                buffer1[num1] = b[pos + num1];
            }
            return buffer1;
        }

        public static uint GetDWord(byte[] b, int pos)
        {
            return (uint) ((((b[pos] << 0x18) + (b[pos + 1] << 0x10)) + (b[pos + 2] << 8)) + b[pos + 3]);
        }

        public static ushort GetWord(byte[] b, int pos)
        {
            return (ushort) ((b[pos] << 8) + b[pos + 1]);
        }

        public override void Insert(int pos, byte b)
        {
        }

        public static bool Same(byte[] m1, byte[] m2)
        {
            if (m1.Length != m2.Length)
            {
                return false;
            }
            for (int num1 = 0; num1 < m1.Length; num1++)
            {
                if (m1[num1] != m2[num1])
                {
                    return false;
                }
            }
            return true;
        }

        public static void SetDWord(byte[] b, int pos, uint v)
        {
            b[pos] = (byte) (v >> 0x18);
            b[pos + 1] = (byte) (v >> 0x10);
            b[pos + 2] = (byte) (v >> 8);
            b[pos + 3] = (byte) v;
        }

        public static void SetWord(byte[] b, int pos, ushort v)
        {
            b[pos] = (byte) (v >> 8);
            b[pos + 1] = (byte) v;
        }


        // Properties
        public override byte this[int idx]
        {
            get
            {
                return this.data[idx];
            }
            set
            {
                this.data[idx] = value;
            }
        }

        public override int Length
        {
            get
            {
                return this.data.Length;
            }
            set
            {
            }
        }


        // Fields
        private byte[] data;
    }
}

