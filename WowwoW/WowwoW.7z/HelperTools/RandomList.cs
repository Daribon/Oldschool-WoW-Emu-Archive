namespace HelperTools
{
    using System;

    public class RandomList
    {
        // Methods
        public RandomList()
        {
            this.val = new int[0x100000];
            for (int num1 = 0; num1 < this.val.Length; num1++)
            {
                this.val[num1] = Utility2.Random(0x7fffffff);
            }
        }


        // Fields
        public int[] val;
    }
}

