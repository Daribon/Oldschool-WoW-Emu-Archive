namespace HelperTools
{
    using System;
    using System.Collections;
    using System.Reflection;

    public class ByteArrayBuilder : ByteArrayBase
    {
        // Methods
        public ByteArrayBuilder()
        {
            this.data = new ArrayList();
        }

        public ByteArrayBuilder(bool le) : base(le)
        {
            this.data = new ArrayList();
        }

        public override ByteArrayBase Add(byte b)
        {
            this.data.Add(b);
            return this;
        }

        public override byte[] GetArray(int start, int count)
        {
            byte[] buffer1 = new byte[count];
            this.data.CopyTo(start, buffer1, 0, count);
            return buffer1;
        }

        public override void Insert(int pos, byte b)
        {
            this.data.Insert(pos, b);
        }

        public static implicit operator ByteArrayBuilder(byte[] m)
        {
            ByteArrayBuilder builder1 = new ByteArrayBuilder();
            builder1.Add(m);
            return builder1;
        }

        public static implicit operator byte[](ByteArrayBuilder m)
        {
            return m.GetArray(0, m.Length);
        }

        public void Remove(int idx)
        {
            this.data.RemoveAt(idx);
        }

        public void Remove(int start, int count)
        {
            this.data.RemoveRange(start, count);
        }

        public override ByteArrayBase Seek(int len)
        {
            this.Length += len;
            return this;
        }


        // Properties
        public override byte this[int i]
        {
            get
            {
                return (byte) this.data[i];
            }
            set
            {
                this.data[i] = value;
            }
        }

        public override int Length
        {
            get
            {
                return this.data.Count;
            }
            set
            {
                while (value > this.data.Count)
                {
                    this.data.Add((byte) 0);
                }
                if (value < this.data.Count)
                {
                    this.data.RemoveRange(value, this.data.Count - value);
                }
            }
        }


        // Fields
        private ArrayList data;
    }
}

