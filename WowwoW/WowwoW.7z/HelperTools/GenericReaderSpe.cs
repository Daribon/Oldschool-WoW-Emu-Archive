namespace HelperTools
{
    using System;

    public class GenericReaderSpe
    {
        // Methods
        public GenericReaderSpe()
        {
        }

    }
}

