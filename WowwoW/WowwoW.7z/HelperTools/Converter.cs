namespace HelperTools
{
    using System;
    using System.Collections;
	using System.Text;

    public class Converter
    {
        // Methods
        public Converter()
        {
        }

        public static byte ToByte(byte[] d, ref int offset)
        {
            return d[offset++];
        }

        public static void ToBytes(byte a, byte[] b, ref int t)
        {
            b[t++] = a;
        }

        public static void ToBytes(BitArray a, byte[] b, ref int t)
        {
            a.CopyTo(b, t);
            t += (a.Length / 8);
        }

        public static void ToBytes(double a, byte[] b, ref int t)
        {
            byte[] buffer1 = BitConverter.GetBytes(a);
            Buffer.BlockCopy(buffer1, 0, b, t, buffer1.Length);
            t += buffer1.Length;
        }

        public static void ToBytes(short a, byte[] b, ref int t)
        {
            b[t++] = (byte) (a & 0xff);
            b[t++] = (byte) ((a >> 8) & 0xff);
        }

        public static void ToBytes(int a, byte[] b, ref int t)
        {
            b[t++] = (byte) (a & 0xff);
            b[t++] = (byte) ((a >> 8) & 0xff);
            b[t++] = (byte) ((a >> 0x10) & 0xff);
            b[t++] = (byte) ((a >> 0x18) & 0xff);
        }

        public static void ToBytes(object a, byte[] b, ref int t)
        {
            if (a is int)
            {
                Converter.ToBytes((int) a, b, ref t);
            }
            if (a is uint)
            {
                Converter.ToBytes((uint) a, b, ref t);
            }
            else if (a is ulong)
            {
                Converter.ToBytes((ulong) a, b, ref t);
            }
            else if (a is long)
            {
                Converter.ToBytes((float) ((long) a), b, ref t);
            }
            else if (a is ushort)
            {
                Converter.ToBytes((ushort) a, b, ref t);
            }
            else if (a is short)
            {
                Converter.ToBytes((short) a, b, ref t);
            }
            else if (a is byte)
            {
                Converter.ToBytes((byte) a, b, ref t);
            }
            else if (a is string)
            {
                Converter.ToBytes((string) a, b, ref t);
            }
        }

        public static void ToBytes(float a, byte[] b, ref int t)
        {
            byte[] buffer1 = BitConverter.GetBytes(a);
            Buffer.BlockCopy(buffer1, 0, b, t, buffer1.Length);
            t += buffer1.Length;
        }

        public static void ToBytes(string a, byte[] b, ref int t)
        {
            char[] chArray1 = a.ToCharArray();
            char[] chArray2 = chArray1;
            for (int num1 = 0; num1 < chArray2.Length; num1++)
            {
                char ch1 = chArray2[num1];
                b[t++] = (byte) ch1;
            }
        }
        public static void ToBytes(ushort a, byte[] b, ref int t)
        {
            b[t++] = (byte) (a & 0xff);
            b[t++] = (byte) ((a >> 8) & 0xff);
        }

        public static void ToBytes(uint a, byte[] b, ref int t)
        {
            b[t++] = (byte) (a & 0xff);
            b[t++] = (byte) ((a >> 8) & 0xff);
            b[t++] = (byte) ((a >> 0x10) & 0xff);
            b[t++] = (byte) ((a >> 0x18) & 0xff);
        }

        public static void ToBytes(ulong a, byte[] b, ref int t)
        {
            b[t++] = (byte) (a & 0xff);
            b[t++] = (byte) ((a >> 8) & 0xff);
            b[t++] = (byte) ((a >> 0x10) & 0xff);
            b[t++] = (byte) ((a >> 0x18) & 0xff);
            b[t++] = (byte) ((a >> 0x20) & 0xff);
            b[t++] = (byte) ((a >> 40) & 0xff);
            b[t++] = (byte) ((a >> 0x30) & 0xff);
            b[t++] = (byte) ((a >> 0x38) & 0xff);
        }

        public static void ToBytes(BitArray a, byte[] b, ref int t, int len)
        {
            a.CopyTo(b, t);
            t += len;
        }

        public static double ToDouble(byte[] d, ref int offset)
        {
            double num1 = BitConverter.ToDouble(d, offset);
            offset += 8;
            return num1;
        }

        public static float ToFloat(byte[] d, ref int offset)
        {
            float single1 = BitConverter.ToSingle(d, offset);
            offset += 4;
            return single1;
        }

        public static short ToInt16(byte[] d, ref int offset)
        {
            short num1 = BitConverter.ToInt16(d, offset);
            offset += 2;
            return num1;
        }

        public static int ToInt32(byte[] d, ref int offset)
        {
            int num1 = BitConverter.ToInt32(d, offset);
            offset += 4;
            return num1;
        }

        public static long ToInt64(byte[] d, ref int offset)
        {
            long num1 = BitConverter.ToInt64(d, offset);
            offset += 8;
            return num1;
        }

        public static ushort ToUInt16(byte[] d, ref int offset)
        {
            ushort num1 = BitConverter.ToUInt16(d, offset);
            offset += 2;
            return num1;
        }

        public static uint ToUInt32(byte[] d, ref int offset)
        {
            uint num1 = BitConverter.ToUInt32(d, offset);
            offset += 4;
            return num1;
        }

        public static ulong ToUInt64(byte[] d, ref int offset)
        {
            ulong num1 = BitConverter.ToUInt64(d, offset);
            offset += 8;
            return num1;
        }

    }
}

