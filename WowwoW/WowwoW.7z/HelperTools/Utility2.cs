namespace HelperTools
{
    using System;

    public class Utility2
    {
        // Methods
        static Utility2()
        {
            Utility2.seed = new System.Random();
        }

        public Utility2()
        {
        }

        public static int Random(int max)
        {
            return Utility2.seed.Next(max);
        }

        public static double RandomDouble()
        {
            return Utility2.seed.NextDouble();
        }

        public static void Seed(int s)
        {
            Utility2.seed = new System.Random(s);
        }


        // Fields
        public static System.Random seed;
    }
}

