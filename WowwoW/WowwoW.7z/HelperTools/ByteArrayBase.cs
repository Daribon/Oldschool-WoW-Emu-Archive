namespace HelperTools
{
    using System;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Text;

    public abstract class ByteArrayBase
    {
        // Methods
        public ByteArrayBase()
        {
            this.le = true;
            this.pos = 0;
        }

        public ByteArrayBase(bool le)
        {
            this.le = true;
            this.pos = 0;
            this.le = le;
        }

        public abstract ByteArrayBase Add(byte b);

        public ByteArrayBase Add(double f)
        {
            return this.Add((float) f);
        }

        public ByteArrayBase Add(float f)
        {
            return this.Add(BitConverter.ToUInt32(BitConverter.GetBytes(f), 0));
        }

        public ByteArrayBase Add(string s)
        {
            byte[] buffer1 = Encoding.UTF7.GetBytes(s);
            byte[] buffer2 = new byte[buffer1.Length + 1];
            buffer1.CopyTo(buffer2, 0);
            return this.Add(buffer2);
        }

        public ByteArrayBase Add(params byte[] bs)
        {
            byte[] buffer1 = bs;
            for (int num2 = 0; num2 < buffer1.Length; num2++)
            {
                byte num1 = buffer1[num2];
                this.Add(num1);
            }
            return this;
        }

        public ByteArrayBase Add(params float[] bs)
        {
            float[] singleArray1 = bs;
            for (int num1 = 0; num1 < singleArray1.Length; num1++)
            {
                float single1 = singleArray1[num1];
                this.Add(single1);
            }
            return this;
        }

        public ByteArrayBase Add(params ushort[] bs)
        {
            ushort[] numArray1 = bs;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                ushort num1 = numArray1[num2];
                this.Add(num1);
            }
            return this;
        }

        public ByteArrayBase Add(params uint[] bs)
        {
            uint[] numArray1 = bs;
            for (int num2 = 0; num2 < numArray1.Length; num2++)
            {
                uint num1 = numArray1[num2];
                this.Add(num1);
            }
            return this;
        }

        public ByteArrayBase Add(ushort b)
        {
            if (this.le)
            {
                this.Add((byte) (b >> 8));
                this.Add((byte) b);
            }
            else
            {
                this.Add((byte) b);
                this.Add((byte) (b >> 8));
            }
            return this;
        }

        public ByteArrayBase Add(uint b)
        {
            if (this.le)
            {
                this.Add((byte) (b >> 0x18));
                this.Add((byte) (b >> 0x10));
                this.Add((byte) (b >> 8));
                this.Add((byte) b);
            }
            else
            {
                this.Add((byte) b);
                this.Add((byte) (b >> 8));
                this.Add((byte) (b >> 0x10));
                this.Add((byte) (b >> 0x18));
            }
            return this;
        }

        public ByteArrayBase Add(ulong u)
        {
            if (this.le)
            {
                this.Add((uint) (u >> 0x20));
                this.Add((uint) u);
            }
            else
            {
                this.Add((uint) u);
                this.Add((uint) (u >> 0x20));
            }
            return this;
        }

        public ByteArrayBase Get(out byte b)
        {
            b = this.GetByte();
            return this;
        }

        public ByteArrayBase Get(out float b)
        {
            b = this.GetFloat();
            return this;
        }

        public ByteArrayBase Get(out string b)
        {
            b = this.GetString();
            return this;
        }

        public ByteArrayBase Get(out ushort b)
        {
            b = this.GetWord();
            return this;
        }

        public ByteArrayBase Get(out uint b)
        {
            b = this.GetDWord();
            return this;
        }

        public ByteArrayBase Get(out ulong b)
        {
            b = this.GetULong();
            return this;
        }

        public byte[] GetArray(int count)
        {
            int num1 = this.pos;
            this.pos += count;
            return this.GetArray(num1, count);
        }

        public abstract byte[] GetArray(int start, int count);

        public byte GetByte()
        {
            return this[this.pos++];
        }

        public uint GetDWord()
        {
            int num1 = this.pos;
            this.pos += 4;
            if (this.le)
            {
                return (uint) ((((this[num1] << 0x18) + (this[num1 + 1] << 0x10)) + (this[num1 + 2] << 8)) + this[num1 + 3]);
            }
            return (uint) ((((this[num1 + 3] << 0x18) + (this[num1 + 2] << 0x10)) + (this[num1 + 1] << 8)) + this[num1]);
        }

        public float GetFloat()
        {
            uint num1 = this.GetDWord();
            return BitConverter.ToSingle(BitConverter.GetBytes(num1), 0);
        }

        public string GetString()
        {
            int num1 = this.pos;
            while (num1 < this.Length)
            {
                if (this[num1] == 0)
                {
                    break;
                }
                num1++;
            }
            byte[] buffer1 = this.GetArray(this.pos, num1 - this.pos);
            this.pos = num1 + 1;
            return Encoding.UTF7.GetString(buffer1);
        }

        public ulong GetULong()
        {
            if (this.le)
            {
                return ((this.GetDWord() << 0x20) + this.GetDWord());
            }
            return (this.GetDWord() + (this.GetDWord() << 0x20));
        }

        public ushort GetWord()
        {
            int num1 = this.pos;
            this.pos += 2;
            if (this.le)
            {
                return (ushort) ((this[num1] << 8) + this[num1 + 1]);
            }
            return (ushort) ((this[num1 + 1] << 8) + this[num1]);
        }

        public void Insert(int pos, ushort b)
        {
            if (this.le)
            {
                this.Insert(pos, (byte) (b >> 8));
                this.Insert((int) (pos + 1), (byte) b);
            }
            else
            {
                this.Insert((int) (pos + 1), (byte) (b >> 8));
                this.Insert(pos, (byte) b);
            }
        }

        public void Insert(int pos, uint b)
        {
            if (this.le)
            {
                this.Insert(pos++, (byte) (b >> 0x18));
                this.Insert(pos++, (byte) (b >> 0x10));
                this.Insert(pos++, (byte) (b >> 8));
                this.Insert(pos++, (byte) b);
            }
            else
            {
                this.Insert(pos++, (byte) b);
                this.Insert(pos++, (byte) (b >> 8));
                this.Insert(pos++, (byte) (b >> 0x10));
                this.Insert(pos++, (byte) (b >> 0x18));
            }
        }

        public abstract void Insert(int pos, byte b);

        public void Insert(int pos, params byte[] bs)
        {
            byte[] buffer1 = bs;
            for (int num2 = 0; num2 < buffer1.Length; num2++)
            {
                byte num1 = buffer1[num2];
                this.Insert(pos++, num1);
            }
        }

        public virtual ByteArrayBase Seek(int len)
        {
            this.pos += len;
            return this;
        }

        public void Set(int pos, params byte[] bs)
        {
            byte[] buffer1 = bs;
            for (int num2 = 0; num2 < buffer1.Length; num2++)
            {
                byte num1 = buffer1[num2];
                this[pos++] = num1;
            }
        }

        public void Set(int pos, ushort b)
        {
            if (this.le)
            {
                this[pos] = (byte) (b >> 8);
                this[pos + 1] = (byte) b;
            }
            else
            {
                this[pos + 1] = (byte) (b >> 8);
                this[pos] = (byte) b;
            }
        }

        public void Set(int pos, uint b)
        {
            if (this.le)
            {
                this[pos] = (byte) (b >> 0x18);
                this[pos + 1] = (byte) (b >> 0x10);
                this[pos + 2] = (byte) (b >> 8);
                this[pos + 3] = (byte) b;
            }
            else
            {
                this[pos + 3] = (byte) (b >> 0x18);
                this[pos + 2] = (byte) (b >> 0x10);
                this[pos + 1] = (byte) (b >> 8);
                this[pos] = (byte) b;
            }
        }


        // Properties
        public abstract byte this[int idx] { get; set; }

        public abstract int Length { get; set; }


        // Fields
        protected bool le;
        public int pos;
    }
}

