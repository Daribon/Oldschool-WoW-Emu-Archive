namespace HelperTools
{
    using System;

    public class GenericWriterSpe
    {
        // Methods
        public GenericWriterSpe()
        {
        }

    }
}

