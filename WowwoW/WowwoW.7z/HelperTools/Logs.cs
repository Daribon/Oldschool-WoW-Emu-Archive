namespace HelperTools
{
    using System;
    using System.IO;

    public class Logs
    {
        // Methods
        public Logs()
        {
        }

        public static void DBS(string s, params object[] arg)
        {
            StreamWriter writer1 = File.AppendText("log.txt");
            writer1.WriteLine(s, arg);
            writer1.Close();
        }

    }
}

