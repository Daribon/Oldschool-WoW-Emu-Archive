namespace HelperTools
{
    using System;

    public class Base64Encoder
    {
        // Methods
        public Base64Encoder(byte[] input)
        {
            this.source = input;
            this.length = input.Length;
            if ((this.length % 3) == 0)
            {
                this.paddingCount = 0;
                this.blockCount = this.length / 3;
            }
            else
            {
                this.paddingCount = 3 - (this.length % 3);
                this.blockCount = (this.length + this.paddingCount) / 3;
            }
            this.length2 = this.length + this.paddingCount;
        }

        public char[] GetEncoded()
        {
            byte[] buffer1 = new byte[this.length2];
            for (int num1 = 0; num1 < this.length2; num1++)
            {
                if (num1 < this.length)
                {
                    buffer1[num1] = this.source[num1];
                }
                else
                {
                    buffer1[num1] = 0;
                }
            }
            byte[] buffer2 = new byte[this.blockCount * 4];
            char[] chArray1 = new char[this.blockCount * 4];
            for (int num10 = 0; num10 < this.blockCount; num10++)
            {
                byte num2 = buffer1[num10 * 3];
                byte num3 = buffer1[(num10 * 3) + 1];
                byte num4 = buffer1[(num10 * 3) + 2];
                byte num6 = (byte) ((num2 & 0xfc) >> 2);
                byte num5 = (byte) ((num2 & 3) << 4);
                byte num7 = (byte) ((num3 & 240) >> 4);
                num7 = (byte) (num7 + num5);
                num5 = (byte) ((num3 & 15) << 2);
                byte num8 = (byte) ((num4 & 0xc0) >> 6);
                num8 = (byte) (num8 + num5);
                byte num9 = (byte) (num4 & 0x3f);
                buffer2[num10 * 4] = num6;
                buffer2[(num10 * 4) + 1] = num7;
                buffer2[(num10 * 4) + 2] = num8;
                buffer2[(num10 * 4) + 3] = num9;
            }
            for (int num11 = 0; num11 < (this.blockCount * 4); num11++)
            {
                chArray1[num11] = this.sixbit2char(buffer2[num11]);
            }
            switch (this.paddingCount)
            {
                case 0:
                {
                    return chArray1;
                }
                case 1:
                {
                    chArray1[(this.blockCount * 4) - 1] = '=';
                    return chArray1;
                }
                case 2:
                {
                    chArray1[(this.blockCount * 4) - 1] = '=';
                    chArray1[(this.blockCount * 4) - 2] = '=';
                    return chArray1;
                }
            }
            return chArray1;
        }

        private char sixbit2char(byte b)
        {
            char[] chArray1 = new char[0x40] { 
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
                'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
                'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
             } ;
            if ((b >= 0) && (b <= 0x3f))
            {
                return chArray1[b];
            }
            return ' ';
        }


        // Fields
        private int blockCount;
        private int length;
        private int length2;
        private int paddingCount;
        private byte[] source;
    }
}

