namespace HelperTools
{
    using System;

    public class Base64Decoder
    {
        // Methods
        public Base64Decoder(char[] input)
        {
            int num1 = 0;
            this.source = input;
            this.length = input.Length;
            for (int num2 = 0; num2 < 2; num2++)
            {
                if (input[(this.length - num2) - 1] == '=')
                {
                    num1++;
                }
            }
            this.paddingCount = num1;
            this.blockCount = this.length / 4;
            this.length2 = this.blockCount * 3;
        }

        private byte char2sixbit(char c)
        {
            char[] chArray1 = new char[0x40] { 
                'A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 
                'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z', 'a', 'b', 'c', 'd', 'e', 'f', 
                'g', 'h', 'i', 'j', 'k', 'l', 'm', 'n', 'o', 'p', 'q', 'r', 's', 't', 'u', 'v', 
                'w', 'x', 'y', 'z', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '+', '/'
             } ;
            if (c != '=')
            {
                for (int num1 = 0; num1 < 0x40; num1++)
                {
                    if (chArray1[num1] == c)
                    {
                        return (byte) num1;
                    }
                }
            }
            return 0;
        }

        public byte[] GetDecoded()
        {
            byte[] buffer1 = new byte[this.length];
            byte[] buffer2 = new byte[this.length2];
            for (int num1 = 0; num1 < this.length; num1++)
            {
                buffer1[num1] = this.char2sixbit(this.source[num1]);
            }
            for (int num10 = 0; num10 < this.blockCount; num10++)
            {
                byte num6 = buffer1[num10 * 4];
                byte num7 = buffer1[(num10 * 4) + 1];
                byte num8 = buffer1[(num10 * 4) + 2];
                byte num9 = buffer1[(num10 * 4) + 3];
                byte num2 = (byte) (num6 << 2);
                byte num3 = (byte) ((num7 & 0x30) >> 4);
                num3 = (byte) (num3 + num2);
                num2 = (byte) ((num7 & 15) << 4);
                byte num4 = (byte) ((num8 & 60) >> 2);
                num4 = (byte) (num4 + num2);
                num2 = (byte) ((num8 & 3) << 6);
                byte num5 = num9;
                num5 = (byte) (num5 + num2);
                buffer2[num10 * 3] = num3;
                buffer2[(num10 * 3) + 1] = num4;
                buffer2[(num10 * 3) + 2] = num5;
            }
            this.length3 = this.length2 - this.paddingCount;
            byte[] buffer3 = new byte[this.length3];
            for (int num11 = 0; num11 < this.length3; num11++)
            {
                buffer3[num11] = buffer2[num11];
            }
            return buffer3;
        }


        // Fields
        private int blockCount;
        private int length;
        private int length2;
        private int length3;
        private int paddingCount;
        private char[] source;
    }
}

