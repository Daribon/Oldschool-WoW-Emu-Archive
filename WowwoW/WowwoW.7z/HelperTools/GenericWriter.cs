namespace HelperTools
{
    using System;
    using System.IO;

    public class GenericWriter
    {
        // Methods
        public GenericWriter(string filename)
        {
            this.buffer = new byte[0x80];
            if (filename != "")
            {
                try
                {
                    this.ms = File.Create(filename);
                    this.fs = new MemoryStream();
                }
                catch (IOException)
                {
                    Console.WriteLine("Erreur de sauvegarde");
                }
            }
        }

        public void Close()
        {
            this.fs.Seek((long) 0, SeekOrigin.Begin);
            byte[] buffer1 = new byte[0x8000];
            while (true)
            {
                int num1 = this.fs.Read(buffer1, 0, 0x8000);
                if (num1 <= 0)
                {
                    break;
                }
                this.ms.Write(buffer1, 0, num1);
            }
            this.ms.Flush();
            this.ms.Close();
            this.fs.Close();
        }

        public void Write(bool a)
        {
            if (a)
            {
                this.fs.WriteByte(1);
            }
            else
            {
                this.fs.WriteByte(0);
            }
        }

        public void Write(byte a)
        {
            this.fs.WriteByte(a);
        }

        public void Write(char a)
        {
            this.fs.WriteByte((byte) a);
        }

        public void Write(double d)
        {
            int num1 = 0;
            Converter.ToBytes(d, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }

        public void Write(short a)
        {
            int num1 = 0;
            Converter.ToBytes(a, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }

        public void Write(int a)
        {
            int num1 = 0;
            Converter.ToBytes(a, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }

        public void Write(long a)
        {
            int num1 = 0;
            Converter.ToBytes((float) a, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }

        public void Write(float d)
        {
            int num1 = 0;
            Converter.ToBytes(d, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }

        public void Write(string s)
        {
            this.Write(s.Length);
            char[] chArray1 = s.ToCharArray();
            char[] chArray2 = chArray1;
            for (int num2 = 0; num2 < chArray2.Length; num2++)
            {
                byte num1 = (byte) chArray2[num2];
                this.fs.WriteByte(num1);
            }
        }

        public void Write(ushort a)
        {
            int num1 = 0;
            Converter.ToBytes(a, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }

        public void Write(uint a)
        {
            int num1 = 0;
            Converter.ToBytes(a, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }

        public void Write(ulong a)
        {
            int num1 = 0;
            Converter.ToBytes(a, this.buffer, ref num1);
            this.fs.Write(this.buffer, 0, num1);
        }


        // Fields
        private byte[] buffer;
        protected MemoryStream fs;
        protected FileStream ms;
    }
}

