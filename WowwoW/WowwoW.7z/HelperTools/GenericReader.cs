namespace HelperTools
{
    using System;
    using System.Collections;
    using System.IO;

    public class GenericReader
    {
        // Methods
        public GenericReader(string filename)
        {
            this.buffer = new byte[0x100];
            this.envs = new ArrayList();
            this.prots = new ArrayList();
            this.notFound = false;
            try
            {
                this.ms = File.OpenRead(filename);
                int num1 = (int) this.ms.Seek((long) 0, SeekOrigin.End);
                this.ms.Seek((long) 0, SeekOrigin.Begin);
                byte[] buffer1 = new byte[num1];
                this.ms.Read(buffer1, 0, num1);
                this.ms.Close();
                this.fs = new MemoryStream(buffer1);
            }
            catch (IOException)
            {
                this.notFound = true;
            }
        }

        public void Close()
        {
            this.fs.Close();
        }

        public bool ReadBool()
        {
            if (this.fs.ReadByte() == 0)
            {
                return false;
            }
            return true;
        }

        public byte ReadByte()
        {
            return (byte) this.fs.ReadByte();
        }

        public char ReadChar()
        {
            return (char) ((ushort) this.fs.ReadByte());
        }

        public double ReadDouble()
        {
            this.fs.Read(this.buffer, 0, 8);
            return BitConverter.ToDouble(this.buffer, 0);
        }

        public float ReadFloat()
        {
            this.fs.Read(this.buffer, 0, 4);
            return BitConverter.ToSingle(this.buffer, 0);
        }

        public int ReadInt()
        {
            this.fs.Read(this.buffer, 0, 4);
            return BitConverter.ToInt32(this.buffer, 0);
        }

        public ulong ReadInt64()
        {
            this.fs.Read(this.buffer, 0, 8);
            return BitConverter.ToUInt64(this.buffer, 0);
        }

        public short ReadShort()
        {
            this.fs.Read(this.buffer, 0, 2);
            return BitConverter.ToInt16(this.buffer, 0);
        }

        public string ReadString()
        {
            string text1 = "";
            int num1 = this.ReadInt();
            for (int num2 = 0; num2 < num1; num2++)
            {
                text1 = text1 + ((char) ((ushort) this.fs.ReadByte()));
            }
            return text1;
        }


        // Fields
        private byte[] buffer;
        private ArrayList envs;
        protected MemoryStream fs;
        protected FileStream ms;
        public bool notFound;
        private ArrayList prots;
    }
}

