namespace HelperTools
{
    using Server;
    using System;

    public class WowTimer
    {
        // Methods
        public WowTimer(double d)
        {
            this.state = States.Paused;
            this.delay = (int) d;
            if (d < 100)
            {
                this.priority = Priorities.Milisec10;
            }
            else if (d < 1000)
            {
                this.priority = Priorities.Milisec100;
            }
            else if (d < 5000)
            {
                this.priority = Priorities.Second;
            }
            else if (d < 10000)
            {
                this.priority = Priorities.Second5;
            }
            else if (d > 3600000)
            {
                this.priority = Priorities.Hour;
            }
            else
            {
                this.priority = Priorities.Second30;
            }
            TimeSpan span1 = DateTime.Now.Subtract(World.startingTime);
            this.lastCall = (long) span1.TotalMilliseconds;
        }

        public WowTimer(Priorities p, double d)
        {
            this.state = States.Paused;
            this.delay = (int) d;
            this.priority = p;
            TimeSpan span1 = DateTime.Now.Subtract(World.startingTime);
            this.lastCall = (long) span1.TotalMilliseconds;
        }

        public virtual void OnTick()
        {
        }

        public void Restart()
        {
            this.lastCall = DateTime.Now.Ticks;
        }

        public bool Slice(long now)
        {
            if (this.State == States.Paused)
            {
                return false;
            }
            int num1 = (int) (now - this.lastCall);
            num1 /= 0x2710;
            if (num1 > this.delay)
            {
                this.lastCall = now;
                this.OnTick();
                if (this.State == States.Paused)
                {
                    return false;
                }
            }
            return true;
        }

        public void Start()
        {
            this.lastCall = DateTime.Now.Ticks;
            this.state = States.Started;
            World.timers[(int) this.priority].Enqueue(this);
        }

        public void Stop()
        {
            this.state = States.Paused;
        }


        // Properties
        public int Delay
        {
            get
            {
                return this.delay;
            }
            set
            {
                this.delay = value;
            }
        }

        public States State
        {
            get
            {
                return this.state;
            }
            set
            {
                this.state = value;
            }
        }


        // Fields
        private int delay;
        private long lastCall;
        private Priorities priority;
        private States state;

        // Nested Types
        public enum Priorities
        {
            // Fields
            Hour = 7,
            Milisec = 0,
            Milisec10 = 1,
            Milisec100 = 2,
            Minute = 6,
            Second = 3,
            Second30 = 5,
            Second5 = 4
        }

        public enum States
        {
            // Fields
            Paused = 1,
            Started = 0
        }
    }
}

