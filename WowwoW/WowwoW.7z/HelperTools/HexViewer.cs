namespace HelperTools
{
    using System;

    public class HexViewer
    {
        // Methods
        public HexViewer()
        {
        }

        public static void View(byte[] b, int offset, int len)
        {
            for (int num1 = 0; num1 < len; num1 += 0x10)
            {
                for (int num2 = num1; (num2 < (num1 + 0x10)) && ((num2 + offset) < b.Length); num2++)
                {
                    if (num2 < len)
                    {
                        Console.Write("{0} ", b[num2 + offset].ToString("X2"));
                    }
                    else
                    {
                        Console.Write("   ");
                    }
                }
                for (int num3 = num1; (((num3 + offset) < b.Length) && (num3 < (num1 + 0x10))) && (num3 < len); num3++)
                {
                    if ((b[num3 + offset] > 0x1f) && (b[num3 + offset] < 0x80))
                    {
                        Console.Write("{0}", "" + ((char) b[num3 + offset]));
                    }
                    else
                    {
                        Console.Write(".");
                    }
                }
                Console.WriteLine("");
            }
        }

        public static void View(byte[] b, int offset, int len, bool noChar)
        {
            for (int num1 = 0; num1 < len; num1 += 0x20)
            {
                for (int num2 = num1; (num2 < (num1 + 0x20)) && ((num2 + offset) < b.Length); num2++)
                {
                    if (num2 < len)
                    {
                        Console.Write("0x{0}, ", b[num2 + offset].ToString("X2"));
                    }
                    else
                    {
                        Console.Write("   ");
                    }
                }
                Console.WriteLine("");
            }
        }

    }
}

