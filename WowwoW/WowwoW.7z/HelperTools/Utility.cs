namespace HelperTools
{
    using System;
    using System.Collections;
    using System.Reflection;
    using System.Text;

    public class Utility
    {
        // Methods
        static Utility()
        {
            Utility.seed = 1;
            Utility.rlist = new RandomList();
            Utility.allConstructors = new Hashtable();
        }

        public Utility()
        {
        }

        public static string ClassName(object o)
        {
            string text1 = o.GetType().ToString();
            char[] chArray2 = new char[1] { '.' } ;
            char[] chArray1 = chArray2;
            string[] textArray1 = text1.Split(chArray1);
            return textArray1[textArray1.Length - 1];
        }

        public static string ClassName(string cls)
        {
            char[] chArray2 = new char[1] { '.' } ;
            char[] chArray1 = chArray2;
            string[] textArray1 = cls.Split(chArray1);
            return textArray1[textArray1.Length - 1];
        }

        public static void FillConstructorList()
        {
            ConstructorInfo[] infoArray7;
            int num2;
            Module[] moduleArray1 = Utility.externAsm.GetModules(false);
            Module module1 = moduleArray1[0];
            Type[] typeArray1 = module1.FindTypes(Module.FilterTypeName, "*");
            Type[] typeArray2 = typeArray1;
            int num1 = 0;
            while (num1 < typeArray2.Length)
            {
                Type type1 = typeArray2[num1];
                if (!type1.Name.StartsWith("$$"))
                {
                    ConstructorInfo[] infoArray1 = type1.GetConstructors();
                    infoArray7 = infoArray1;
                    for (num2 = 0; num2 < infoArray7.Length; num2++)
                    {
                        ConstructorInfo info1 = infoArray7[num2];
                        ParameterInfo[] infoArray2 = info1.GetParameters();
                        if (infoArray2.Length == 0)
                        {
                            Utility.allConstructors[Utility.ClassName(type1.Name)] = info1;
                            break;
                        }
                    }
                }
                num1++;
            }
            moduleArray1 = Assembly.GetAssembly(typeof(Utility)).GetModules(false);
            module1 = moduleArray1[0];
            typeArray1 = module1.FindTypes(Module.FilterTypeName, "*");
            typeArray2 = typeArray1;
            num1 = 0;
            while (num1 < typeArray2.Length)
            {
                Type type2 = typeArray2[num1];
                if (!type2.Name.StartsWith("$$"))
                {
                    ConstructorInfo[] infoArray3 = type2.GetConstructors();
                    infoArray7 = infoArray3;
                    for (num2 = 0; num2 < infoArray7.Length; num2++)
                    {
                        ConstructorInfo info2 = infoArray7[num2];
                        ParameterInfo[] infoArray4 = info2.GetParameters();
                        if (infoArray4.Length == 0)
                        {
                            Utility.allConstructors[Utility.ClassName(type2.Name)] = info2;
                            break;
                        }
                    }
                }
                num1++;
            }
            moduleArray1 = Utility.externAsmItem.GetModules(false);
            module1 = moduleArray1[0];
            typeArray1 = module1.FindTypes(Module.FilterTypeName, "*");
            typeArray2 = typeArray1;
            for (num1 = 0; num1 < typeArray2.Length; num1++)
            {
                Type type3 = typeArray2[num1];
                if (!type3.Name.StartsWith("$$"))
                {
                    ConstructorInfo[] infoArray5 = type3.GetConstructors();
                    infoArray7 = infoArray5;
                    for (num2 = 0; num2 < infoArray7.Length; num2++)
                    {
                        ConstructorInfo info3 = infoArray7[num2];
                        ParameterInfo[] infoArray6 = info3.GetParameters();
                        if (infoArray6.Length == 0)
                        {
                            Utility.allConstructors[Utility.ClassName(type3.Name)] = info3;
                            break;
                        }
                    }
                }
            }
        }

        public static ConstructorInfo FindConstructor(string cls)
        {
            return (ConstructorInfo) Utility.allConstructors[Utility.ClassName(cls)];
        }

        public static ConstructorInfo FindConstructor(string cls, Assembly fromAssembly)
        {
            return (ConstructorInfo) Utility.allConstructors[Utility.ClassName(cls)];
        }

        public static int Random(int max)
        {
            return (Utility.rlist.val[Utility.seed++ & 0xfffff] % max);
        }

        public static int Random(int min, int max)
        {
            if (min == max)
            {
                return min;
            }
            return (min + (Utility.rlist.val[Utility.seed++ & 0xfffff] % (max - min)));
        }

        public static int Random1024()
        {
            return (Utility.rlist.val[Utility.seed++ & 0xfffff] & 0x3ff);
        }

        public static int Random1024x1024()
        {
            return (Utility.rlist.val[Utility.seed++ & 0xfffff] & 0xfffff);
        }

        public static int Random16()
        {
            return (Utility.rlist.val[Utility.seed++ & 0xfffff] & 15);
        }

        public static int Random4()
        {
            return (Utility.rlist.val[Utility.seed++ & 0xfffff] & 3);
        }

        public static int Random8()
        {
            return (Utility.rlist.val[Utility.seed++ & 0xfffff] & 7);
        }

        public static double RandomDouble()
        {
            int num1 = Utility.rlist.val[Utility.seed++ & 0xfffff] & 0xfffffff;
            int num2 = Utility.rlist.val[Utility.seed++ & 0xfffff] & 0xfffffff;
            double num3 = ((double) num1) / 72057594037927936;
            return (num3 + (((double) num2) / 268435456));
        }

        public static bool ToBoolean(string value)
        {
            bool flag1;
            try
            {
                flag1 = Convert.ToBoolean(value);
            }
            catch
            {
                flag1 = false;
            }
            return flag1;
        }

        public static double ToDouble(string value)
        {
            double num1;
            try
            {
                num1 = Convert.ToDouble(value);
            }
            catch
            {
                num1 = 0;
            }
            return num1;
        }

        public static int ToInt32(string value)
        {
            int num1;
            try
            {
                if (value.StartsWith("0x"))
                {
                    return Convert.ToInt32(value.Substring(2), 0x10);
                }
                num1 = Convert.ToInt32(value);
            }
            catch
            {
                num1 = 0;
            }
            return num1;
        }

        public static TimeSpan ToTimeSpan(string value)
        {
            TimeSpan span1;
            try
            {
                span1 = TimeSpan.Parse(value);
            }
            catch
            {
                span1 = TimeSpan.Zero;
            }
            return span1;
        }


        // Properties
        public static Encoding UTF8
        {
            get
            {
                if (Utility.m_UTF8 == null)
                {
                    Utility.m_UTF8 = new UTF8Encoding(false, false);
                }
                return Utility.m_UTF8;
            }
        }

        public static Encoding UTF8WithEncoding
        {
            get
            {
                if (Utility.m_UTF8WithEncoding == null)
                {
                    Utility.m_UTF8WithEncoding = new UTF8Encoding(true, false);
                }
                return Utility.m_UTF8WithEncoding;
            }
        }


        // Fields
        public static Hashtable allConstructors;
        public static Assembly externAsm;
        public static Assembly externAsmItem;
        private static Encoding m_UTF8;
        private static Encoding m_UTF8WithEncoding;
        public static RandomList rlist;
        public static int seed;
    }
}

