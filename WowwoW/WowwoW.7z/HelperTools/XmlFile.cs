namespace HelperTools
{
    using System;
    using System.Xml;

    public class XmlFile : XmlDocument
    {
        // Methods
        public XmlFile()
        {
            this.Init(false, "", "elements");
        }

        public XmlFile(string file)
        {
            this.Load(file);
        }

        public XmlFile(bool UseXsl, string XslFile, string RootTag)
        {
            this.Init(UseXsl, XslFile, RootTag);
        }

        public XmlAttribute AddAttribute(XmlNode Into, string AttributeName, string Text)
        {
            XmlAttribute attribute1 = base.CreateAttribute(AttributeName);
            attribute1.Value = Text;
            return Into.Attributes.Append(attribute1);
        }

        public XmlNode AddNode(XmlNode Into, string NodeName, string InnerText)
        {
            return Into.AppendChild(this.CreateNode(NodeName, InnerText));
        }

        public XmlNode CreateNode(string NodeName, string InnerText)
        {
            XmlNode node1 = this.CreateNode(XmlNodeType.Element, NodeName, "");
            node1.InnerText = InnerText;
            return node1;
        }

        public string GetAttributeVal(XmlNode node, string attr_name, string def_value)
        {
            if (node.Attributes[attr_name] == null)
            {
                return def_value;
            }
            return node.Attributes[attr_name].Value;
        }

        public string GetInnerText(XmlNode node, string def_value)
        {
            if (node.InnerText == null)
            {
                return def_value;
            }
            return node.InnerText;
        }

        protected void Init(bool UseXsl, string XslFile, string RootTag)
        {
            string[] textArray1 = new string[7] { "<?xml version=\"1.0\" encoding=\"utf-8\"?>", UseXsl ? ("<?xml-stylesheet type=\"text/xsl\" href=\"" + XslFile + "\"?>") : "", "<", RootTag, "></", RootTag, ">" } ;
            this.LoadXml(string.Concat(textArray1));
        }

    }
}

