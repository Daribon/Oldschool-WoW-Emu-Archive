namespace HelperTools
{
    using ICSharpCode.SharpZipLib.Zip.Compression.Streams;
    using System;
    using System.IO;

    public class Zip
    {
        // Methods
        static Zip()
        {
            Zip.writeData = new byte[0x100000];
        }

        public Zip()
        {
        }

        public static byte[] Compress(byte[] b, int offset, int len)
        {
            byte[] buffer2;
            try
            {
                MemoryStream stream1 = new MemoryStream();
                DeflaterOutputStream stream2 = new DeflaterOutputStream(stream1);
                stream2.Write(b, offset, len);
                stream2.Flush();
                stream2.Close();
                byte[] buffer1 = stream1.ToArray();
                buffer2 = buffer1;
            }
            catch (Exception exception1)
            {
                Console.WriteLine(exception1.Message);
                buffer2 = null;
            }
            return buffer2;
        }

        public static byte[] DeCompress(byte[] b)
        {
            byte[] buffer2;
            Stream stream1 = new InflaterInputStream(new MemoryStream(b));
            try
            {
                byte[] buffer1 = null;
                int num1 = stream1.Read(Zip.writeData, 0, Zip.writeData.Length);
                if (num1 > 0)
                {
                    buffer1 = new byte[num1];
                    Buffer.BlockCopy(Zip.writeData, 0, buffer1, 0, num1);
                }
                stream1.Flush();
                stream1.Close();
                buffer2 = buffer1;
            }
            catch (Exception exception1)
            {
                Console.WriteLine(exception1.Message);
                buffer2 = null;
            }
            return buffer2;
        }


        // Fields
        private static byte[] writeData;
    }
}

