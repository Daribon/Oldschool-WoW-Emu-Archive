using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Level.
	/// </summary>
	[ChatCmdHandler()]
	
	public class level
	{
		[ChatCmdAttribute("level", "level <level>")]
		static bool OnLevel(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int level = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					level = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					level = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid level.");
				return true;
			}

			if(level == 0)
			{
				Chat.System(client, "level cannot be 0!");
				return true;
			}
			client.Player.Level = level;
			client.Player.NextLevelExp = level * 900;
			client.Player.Health = client.Player.MaxHealth =75 + 25 * level;
			client.Player.Power = client.Player.MaxPower = 80 + level * 20;
			client.Player.Strength = client.Player.BaseStrength = 19 + level;
			client.Player.Stamina = client.Player.BaseStamina = 19 + level;
			client.Player.Agility = client.Player.BaseAgility = 19 + level;
			client.Player.Intellect = client.Player.BaseIntellect = 19 + level;
			client.Player.Spirit = client.Player.BaseSpirit = 19 + level;
			client.Player.SkillPoints = level;
			client.Player.TalentPoints = level;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
