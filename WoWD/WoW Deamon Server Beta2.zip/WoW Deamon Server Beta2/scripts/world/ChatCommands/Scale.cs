using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Scale.
	/// </summary>
	[ChatCmdHandler()]
	public class scale
	{
		[ChatCmdAttribute("scale", "scale <scale>")]
		static bool OnScale(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			float scale = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					scale = float.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					scale = float.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid scale.");
				return true;
			}

			if(scale == 0)
			{
				Chat.System(client, "scale cannot be 0!");
				return true;
			}
			client.Player.Scale = scale;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
