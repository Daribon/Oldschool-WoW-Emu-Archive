using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for MaxHealth.
	/// </summary>
	[ChatCmdHandler()]
	public class maxhealth
	{
		[ChatCmdAttribute("maxhealth", "maxhealth <maxhealth>")]
		static bool OnMaxHealth(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int maxhealth = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					maxhealth = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					maxhealth = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid maxhealth.");
				return true;
			}
			
			if(maxhealth == 0)
			{
				Chat.System(client, "maxhealth cannot be 0!");
				return true;
			}
			client.Player.MaxHealth = maxhealth;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
