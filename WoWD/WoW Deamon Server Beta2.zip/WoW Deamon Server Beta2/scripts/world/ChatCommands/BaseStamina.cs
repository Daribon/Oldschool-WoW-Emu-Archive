using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for BaseStamina.
	/// </summary>
	[ChatCmdHandler()]
	public class basestamina
	{
		[ChatCmdAttribute("basestamina", "basestamina <basestamina>")]
		static bool OnBaseStamina(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int basestamina = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					basestamina = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					basestamina = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid basestamina.");
				return true;
			}
			
			if(basestamina == 0)
			{
				Chat.System(client, "basestamina cannot be 0!");
				return true;
			}
			client.Player.BaseStamina = basestamina;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
