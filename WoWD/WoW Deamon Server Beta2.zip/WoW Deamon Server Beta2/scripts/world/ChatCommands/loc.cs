using System;
using System.Text.RegularExpressions;
using System.Collections;
using WoWDaemon.Common;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Location.
	/// </summary>
	[ChatCmdHandler()]
	public class Location
	{
		[ChatCmdAttribute("Location", "No usage.")]
		[ChatCmdAttribute("Loc", "No usage.")]
		static bool OnLocation(WorldClient client, string input)

		{
			string str = "Your current location is: ";
			str += client.Player.Continent.ToString();
			str += " ";
			str += client.Player.Position.X.ToString();
			str += " ";
			str += client.Player.Position.Y.ToString();
			str += " ";
			str += client.Player.Position.Z.ToString();
			Chat.System(client, str);
			return true;
		}
	}
}