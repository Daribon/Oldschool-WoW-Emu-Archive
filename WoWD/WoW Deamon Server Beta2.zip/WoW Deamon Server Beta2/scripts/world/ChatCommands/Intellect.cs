using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Intellect.
	/// </summary>
	[ChatCmdHandler()]
	public class intellect
	{
		[ChatCmdAttribute("intellect", "intellect <intellect>")]
		static bool OnIntellect(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int intellect = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					intellect = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					intellect = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid intellect.");
				return true;
			}
			
			if(intellect == 0)
			{
				Chat.System(client, "intellect cannot be 0!");
				return true;
			}
			client.Player.Intellect = intellect;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
