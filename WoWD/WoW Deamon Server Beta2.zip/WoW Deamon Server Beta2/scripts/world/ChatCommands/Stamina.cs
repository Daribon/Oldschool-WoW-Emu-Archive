using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Stamina.
	/// </summary>
	[ChatCmdHandler()]
	public class stamina
	{
		[ChatCmdAttribute("stamina", "stamina <stamina>")]
		static bool OnStamina(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int stamina = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					stamina = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					stamina = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid stamina.");
				return true;
			}
			
			if(stamina == 0)
			{
				Chat.System(client, "stamina cannot be 0!");
				return true;
			}
			client.Player.Stamina = stamina;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
