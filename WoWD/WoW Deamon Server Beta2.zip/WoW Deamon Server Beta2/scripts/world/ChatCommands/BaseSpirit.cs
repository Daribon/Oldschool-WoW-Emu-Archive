using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for BaseSpirit.
	/// </summary>
	[ChatCmdHandler()]
	public class basespirit
	{
		[ChatCmdAttribute("basespirit", "basespirit <basespirit>")]
		static bool OnBaseSpirit(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int basespirit = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					basespirit = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					basespirit = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid basespirit.");
				return true;
			}
			
			if(basespirit == 0)
			{
				Chat.System(client, "basespirit cannot be 0!");
				return true;
			}
			client.Player.BaseSpirit = basespirit;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
