using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Exp.
	/// </summary>
	[ChatCmdHandler()]
	public class exp
	{
		[ChatCmdAttribute("exp", "exp <exp>")]
		static bool OnExp(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int exp = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					exp = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					exp = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid exp.");
				return true;
			}
			/*
			if(exp == 0)
			{
				Chat.System(client, "exp cannot be 0!");
				return true;
			}*/
			client.Player.Exp = exp;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
