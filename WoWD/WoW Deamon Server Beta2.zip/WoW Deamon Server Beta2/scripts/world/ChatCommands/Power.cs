using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Power.
	/// </summary>
	[ChatCmdHandler()]
	public class power
	{
		[ChatCmdAttribute("power", "power <power>")]
		static bool OnPower(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int power = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					power = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					power = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid power.");
				return true;
			}
			/*
			if(exp == 0)
			{
				Chat.System(client, "power cannot be 0!");
				return true;
			}*/
			client.Player.Power = power;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
