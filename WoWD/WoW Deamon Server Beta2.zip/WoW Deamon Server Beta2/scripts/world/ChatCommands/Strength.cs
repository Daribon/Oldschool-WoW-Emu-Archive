using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Strength.
	/// </summary>
	[ChatCmdHandler()]
	public class strength
	{
			[ChatCmdAttribute("strength", "strength <strength>")]
		static bool OnStrength(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int strength = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					strength = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					strength = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid strength.");
				return true;
			}
			
			if(strength == 0)
			{
				Chat.System(client, "strength cannot be 0!");
				return true;
			}
			client.Player.Strength = strength;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
