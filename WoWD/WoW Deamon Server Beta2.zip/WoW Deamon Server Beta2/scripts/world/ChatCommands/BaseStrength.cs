using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for BaseStrength.
	/// </summary>
	[ChatCmdHandler()]
	public class basestrength
	{
		[ChatCmdAttribute("basestrength", "basestrength <basestrength>")]
			static bool OnBaseStrength(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int basestrength = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					basestrength = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					basestrength = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid basestrength.");
				return true;
			}
			
			if(basestrength == 0)
			{
				Chat.System(client, "basestrength cannot be 0!");
				return true;
			}
			client.Player.BaseStrength = basestrength;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
