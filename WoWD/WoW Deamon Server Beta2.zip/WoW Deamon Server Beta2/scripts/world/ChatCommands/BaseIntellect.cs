using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for BaseIntellect.
	/// </summary>
	[ChatCmdHandler()]
	public class baseintellect
	{
		[ChatCmdAttribute("baseintellect", "baseintellect <baseintellect>")]
		static bool OnBaseIntellect(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int baseintellect = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					baseintellect = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					baseintellect = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid baseintellect.");
				return true;
			}
			
			if(baseintellect == 0)
			{
				Chat.System(client, "baseintellect cannot be 0!");
				return true;
			}
			client.Player.BaseIntellect = baseintellect;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
