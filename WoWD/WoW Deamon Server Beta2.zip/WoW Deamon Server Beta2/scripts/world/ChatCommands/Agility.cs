using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Agility.
	/// </summary>
	[ChatCmdHandler()]
	public class agility
	{
		[ChatCmdAttribute("agility", "agility <agility>")]
		static bool OnAgility(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int agility = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					agility = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					agility = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid agility.");
				return true;
			}
			
			if(agility == 0)
			{
				Chat.System(client, "agility cannot be 0!");
				return true;
			}
			client.Player.Agility = agility;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
