using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for MaxPower.
	/// </summary>
	[ChatCmdHandler()]
	public class maxpower
	{
		[ChatCmdAttribute("maxpower", "maxpower <maxpower>")]
		static bool OnMaxPower(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int maxpower = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					maxpower = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					maxpower = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid maxpower.");
				return true;
			}
			/*
			if(exp == 0)
			{
				Chat.System(client, "maxpower cannot be 0!");
				return true;
			}*/
			client.Player.MaxPower = maxpower;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
