using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for BaseAgility.
	/// </summary>
	[ChatCmdHandler()]
	public class baseagility
	{
		[ChatCmdAttribute("baseagility", "baseagility <baseagility>")]
		static bool OnBaseAgility(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int baseagility = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					baseagility = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					baseagility = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid baseagility.");
				return true;
			}
			
			if(baseagility == 0)
			{
				Chat.System(client, "baseagility cannot be 0!");
				return true;
			}
			client.Player.BaseAgility = baseagility;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
