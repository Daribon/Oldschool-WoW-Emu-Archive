using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Health.
	/// </summary>
	[ChatCmdHandler()]
	public class health
	{
		[ChatCmdAttribute("health", "health <health>")]
		static bool OnHealth(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int health = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					health = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					health = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid health.");
				return true;
			}
			
			if(health == 0)
			{
				Chat.System(client, "health cannot be 0!");
				return true;
			}
			client.Player.Health = health;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
