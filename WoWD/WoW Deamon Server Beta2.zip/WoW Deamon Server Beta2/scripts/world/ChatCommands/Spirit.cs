using System;
using WoWDaemon.Common.Attributes;
using WoWDaemon.World;
namespace WorldScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Spirit.
	/// </summary>
	[ChatCmdHandler()]
	public class spirit
	{
		[ChatCmdAttribute("spirit", "spirit <spirit>")]
		static bool OnSpirit(WorldClient client, string input)
		{
			string[] split = input.Split(' ');
			if(split.Length != 2)
				return false;
			int spirit = 0;
			try
			{
				if(split[1].StartsWith("0x"))
					spirit = int.Parse(split[1].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					spirit = int.Parse(split[1]);
			}
			catch(Exception)
			{
				Chat.System(client, "Invalid spirit.");
				return true;
			}
			
			if(spirit == 0)
			{
				Chat.System(client, "spirit cannot be 0!");
				return true;
			}
			client.Player.Spirit = spirit;
			client.Player.UpdateData();
			return true;
		}
	}
} 
       
