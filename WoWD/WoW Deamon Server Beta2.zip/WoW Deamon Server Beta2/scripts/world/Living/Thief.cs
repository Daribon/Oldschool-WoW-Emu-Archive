using System;
using WoWDaemon.Common;
using WoWDaemon.World;
using WoWDaemon.Database.DataTables;
namespace WorldScripts.Living
{
	public class Thief : UnitBase
	{
		public Thief(DBCreature creature) : base(creature)
		{
			MaxHealth = Health = 100;
			MaxPower = Power = 100;
			PowerType = POWERTYPE.ENERGY;
			Level = 3;
			Faction = 7;
			DisplayID = 508;
		}
	}
}
