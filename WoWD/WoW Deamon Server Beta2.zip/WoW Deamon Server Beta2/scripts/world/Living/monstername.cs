using System;
using WoWDaemon.Common;
using WoWDaemon.World;
using WoWDaemon.Database.DataTables;
namespace WorldScripts.Living
{
	public class KodoBeast : UnitBase
	{
		public KodoBeast(DBCreature creature) : base(creature)
		{
			MaxHealth = Health = 100;
			MaxPower = Power = 100;
			PowerType = POWERTYPE.RAGE;
			Level = 1;
			Faction = 7;
			DisplayID = 179;
		}
	}
	public class Frog : UnitBase
	{
		public Frog(DBCreature creature) : base(creature)
		{
			MaxHealth = Health = 10;
			MaxPower = Power = 10;
			PowerType = POWERTYPE.RAGE;
			Level = 1;
			Faction = 31;
			DisplayID = 901;
		}
	}
}
