using System;
using WoWDaemon.Common;
using WoWDaemon.World;
using WoWDaemon.Database.DataTables;
namespace WorldScripts.Living
{
	public class SmallThief : UnitBase
	{
		public SmallThief(DBCreature creature) : base(creature)
		{
			MaxHealth = Health = 80;
			MaxPower = Power = 80;
			PowerType = POWERTYPE.ENERGY;
			Level = 1;
			Faction = 7;
			DisplayID = 508;
		}
	}
}
