using System;
using WoWDaemon.Common;
using WoWDaemon.Common.Attributes;
using WoWDaemon.Login;
using WoWDaemon.Database.DataTables;
using WoWDaemon.Database;
namespace LoginScripts.GMChatCommands
{
	/// <summary>
	/// Summary description for ScaleSpawn.
	/// </summary>
	[ChatCmdHandler()]
	public class ScaleSpawn
	{
		/// <summary>
		/// Spawns a temp mob on a worldmap
		/// </summary>
		/// <param name="client"></param>
		/// <param name="input"></param>
		[ChatCmdAttribute("scalespawn", "scalespawn <name> <displayid> <scale>")]
		static bool OnScaleSpawn(LoginClient client, string input)
		{
			string[] split = input.Split('\"');
			if(split.Length == 4)
			{
				split[2] = split[2].TrimStart(' ');
			}
			else if(split.Length == 1)
			{
				split = input.Split(' ');
			}

			if(split.Length != 4)
				return false;
			int displayID = 0;
			try
			{
				if(split[2].StartsWith("0x"))
					displayID = int.Parse(split[2].Substring(2), System.Globalization.NumberStyles.HexNumber);
				else
					displayID = int.Parse(split[2]);
			}
			catch(Exception)
			{
				return false;
			}
			if(displayID == 0)
			{
				Chat.System(client, "You must set a displayID.");
				return true;
			}
			
			int scale = 0;
			try
			{
				if(split[3].StartsWith("0x"))
					scale = int.Parse(split[3].Substring(3), System.Globalization.NumberStyles.HexNumber);
				else
					scale = int.Parse(split[3]);
			}
			catch(Exception)
			{
				return false;
			}
			if(scale == 0)
			{
				Chat.System(client, "You must set a scale.");
				return true;
			}

			string name = split[1];
			name = name.Replace("'", ""); // bleh!!
			if(name.Length > 20)
				name = name.Substring(0, 20);
			DataObject[] objs;
			try
			{
				objs = DataServer.Database.SelectObjects(typeof(DBCreature), "Name = '" + name + "'");
			}
			catch(Exception)
			{
				Chat.System(client, "Error looking up name in database.");
				return true;
			}

			DBCreature creature;
			if(objs.Length == 0)
			{
				creature = new DBCreature();
				creature.Name = name;
				DataServer.Database.AddNewObject(creature);
			}
			else
				creature = (DBCreature)objs[0];
			
			client.WorldConnection.Send(creature);

			ScriptPacket pkg = new ScriptPacket(0x0A9);
			pkg.Write(client.Character.ObjectId);
			pkg.Write(creature.ObjectId);
			pkg.Write(displayID);
			pkg.Write(scale);
			client.WorldConnection.Send(pkg);
			return true;
		}
	}
}
