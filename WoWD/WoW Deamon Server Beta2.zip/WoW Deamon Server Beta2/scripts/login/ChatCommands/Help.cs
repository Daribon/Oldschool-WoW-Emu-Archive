using System;
using WoWDaemon.Common;
using WoWDaemon.Common.Attributes;
using WoWDaemon.Login;
namespace LoginScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Help.
	/// </summary>
	[ChatCmdHandler()]
	public class help
	{
		[ChatCmdAttribute("help", "No usage.")]
		static bool OnHelp(LoginClient client, string input)
		{
			Chat.System(client, "A list of commands!");
			Chat.System(client, "!baseagility to change your baseagility");
			Chat.System(client, "!agility to change your agility");
			Chat.System(client, "!baseintelect to change your baseintelect");
			Chat.System(client, "!intelect to change your intelect");
			Chat.System(client, "!basespirit to change your basespirit");
			Chat.System(client, "!spirit to change your spirit");
			Chat.System(client, "!basestamina to change your basestamina");
			Chat.System(client, "!stamina to change your stamina");
			Chat.System(client, "!basestrength to change your basestrength");
			Chat.System(client, "!strength to change your strength");
			Chat.System(client, "!cleanup to cleanup your spawns");
			Chat.System(client, "!exp to change your exp");
			Chat.System(client, "!goto to go a location");
			Chat.System(client, "!healthto change your health");
			Chat.System(client, "!maxhealth to change your maxhealth");
			Chat.System(client, "!power to change your power");
			Chat.System(client, "!maxpower to change your maxpower");
			Chat.System(client, "!level to change your level");
			Chat.System(client, "!loc to see your location");
			Chat.System(client, "!morph to morph into a creature");
			Chat.System(client, "!spawn to spawn a creature");
			Chat.System(client, "!scalespawn to spawn a creature with different scale");
			Chat.System(client, "!stopspawn to spawn a creature that dont move");
			Chat.System(client, "!scale to change your scale");
			Chat.System(client, "!mount to mount and !dismount to dismount");
			Chat.System(client, "!worldport to worldport");
			return true;
		}
	}
}
