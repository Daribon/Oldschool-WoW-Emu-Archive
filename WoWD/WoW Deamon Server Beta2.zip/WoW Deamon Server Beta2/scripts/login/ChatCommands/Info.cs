using System;
using WoWDaemon.Common;
using WoWDaemon.Common.Attributes;
using WoWDaemon.Login;
using WoWDaemon.Database;
using WoWDaemon.Database.DataTables;
namespace LoginScripts.ChatCommands
{
	/// <summary>
	/// Summary description for Info.
	/// </summary>
	[ChatCmdHandler()]
	public class Info
	{
		[ChatCmdAttribute("info", "No usage.")]
		static bool OnInfo(LoginClient client, string input)
		{
			Chat.System(client, "This server is running Magic_k0's modifyed WoWDaemon 0.1.");
			Chat.System(client, "Current users: " + LoginServer.CurrentUsers);
			Chat.System(client,	"Top users this uptime: " + LoginServer.TopUsers);
			Chat.System(client, "Type !help for a list of Commands");
			int accounts = DataServer.Database.SelectAllObjects(typeof(DBAccount)).Length;
			int characters = DataServer.Database.SelectAllObjects(typeof(DBCharacter)).Length;
			Chat.System(client, "Accounts: " + accounts + " Characters: " + characters);
			Chat.System(client, "Type !help for a list of commands");
			return true;
		}
	}
}
