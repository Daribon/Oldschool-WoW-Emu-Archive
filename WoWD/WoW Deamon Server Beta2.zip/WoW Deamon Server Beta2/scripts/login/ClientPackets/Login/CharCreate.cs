using System;
using System.Text.RegularExpressions;
using WoWDaemon.Common;
using WoWDaemon.Common.Attributes;
using WoWDaemon.Login;
using WoWDaemon.Database.DataTables;

namespace LoginScripts.ClientPackets
{
	/// <summary>
	/// Summary description for CharCreate.
	/// </summary>
	[LoginPacketHandler()]
	public class CharCreate
	{
		static Regex nameCheck = new Regex(@"[^a-z]", RegexOptions.Compiled);
		static int[] male_models = {0, 49, 51, 53, 55, 57, 59, 1563, 1478};
		static int[] female_models = {0, 50, 52, 54, 56, 58, 60, 1564, 1479};
		[LoginPacketDelegate(CMSG.CHAR_CREATE)]
		static bool HandleCharCreate(LoginClient client, CMSG msgID, BinReader data)
		{
			string name = data.ReadString().ToLower();
			BinWriter w = LoginClient.NewPacket(SMSG.CHAR_CREATE);

			if(name != nameCheck.Replace(name, ""))
			{
				w.Write((byte)0x29);
				client.Send(w);
				return true;
			}

			DBCharacter c = (DBCharacter)DataServer.Database.FindObjectByKey(typeof(DBCharacter), name);
			if(c != null)
			{
				w.Write((byte)0x2B);
				client.Send(w);
				return true;
			}
			if(client.Account.Characters != null && client.Account.Characters.Length == 8)
			{
				w.Write((byte)0x2D);
				client.Send(w);
				return true;
			}
			c = new DBCharacter();
			c.Name = name;
			c.AccountID = client.Account.ObjectId;
			c.Race = (RACE)data.ReadByte();
			c.Class = (CLASS)data.ReadByte();
			c.Gender = data.ReadByte();
			c.Skin = data.ReadByte();
			c.Face = data.ReadByte();
			c.HairStyle = data.ReadByte();
			c.HairColor = data.ReadByte();
			c.FacialHairStyle = data.ReadByte();
						
            //c.Position = new Vector(-90.0f, 150.0f, 60.0f);
			//c.Zone = 90;
			//c.WorldMapID = 1;
			//c.Continent = 0;
			switch((RACE)c.Race)
			{
				case RACE.HUMAN:				
					c.Position = new Vector(-8949.280273f, -131.158997f, 83.484198f);
					c.Zone = 90;
					c.WorldMapID = 1;
					c.Continent = 0;
					break;
				case RACE.ORC:				
					c.Position = new Vector(-622.79303f, -4284.720215f, 39.543598f);
					c.Zone = 90;
					c.WorldMapID = 2;
					c.Continent = 1;
					break;
				case RACE.DWARF:				
					c.Position = new Vector(-6237.830078f, 311.192993f, 383.7818f);
					c.Zone = 90;
					c.WorldMapID = 1;
					c.Continent = 0;
					break;
				case RACE.NIGHTELF:				
					c.Position = new Vector(10313f, 830.203979f, 1326.400024f);
					c.Zone = 90;
					c.WorldMapID = 2;
					c.Continent = 1;
					break;
				case RACE.UNDEAD:				
					c.Position = new Vector(1671.310059f, 1678.369995f, 120.719002f);
					c.Zone = 90;
					c.WorldMapID = 1;
					c.Continent = 0;
					break;
				case RACE.TAUREN:				
					c.Position = new Vector(-2920.649902f, -258.485992f, 52.994900f);
					c.Zone = 90;
					c.WorldMapID = 2;
					c.Continent = 1;
					break;
				case RACE.GNOME:				
					c.Position = new Vector(-6237.830078f, 311.192993f, 383.7818f);
					c.Zone = 90;
					c.WorldMapID = 1;
					c.Continent = 0;
					break;
				case RACE.TROLL:				
					c.Position = new Vector(-626.210999f, -4252.870117f, 38.425900f);
					c.Zone = 90;
					c.WorldMapID = 2;
					c.Continent = 1;
					break;
				case RACE.MAX:				
					c.Position = new Vector(-89, 208.5f, 53.3f);
					c.Zone = 90;
					c.WorldMapID = 1;
					c.Continent = 0;
					break;
				default:				
					c.Position = new Vector(-89, 208.5f, 53.3f);
					c.Zone = 90;
					c.WorldMapID = 1;
					c.Continent = 0;
					break;
			}
			
			

					c.Level = 1;
					c.Facing = 0.0f;
					c.Scale = 1.0f;
					c.Health = 100;
					c.MaxHealth = 100;
					c.Power = 100;
					c.MaxPower = 100;
					switch((CLASS)c.Class)
				{
					case CLASS.WARRIOR:
						c.PowerType = POWERTYPE.RAGE;
						break;
					case CLASS.HUNTER:
						c.PowerType = POWERTYPE.FOCUS;
						break;
					case CLASS.ROGUE:
						c.PowerType = POWERTYPE.ENERGY;
						break;
					default:
						c.PowerType = POWERTYPE.MANA;
						break;
				}

					c.BaseStrength = 20;
					c.Strength = 20;
					c.BaseAgility = 20;
					c.Agility = 20;
					c.BaseStamina = 20;
					c.Stamina = 20;
					c.BaseIntellect = 20;
					c.Intellect = 20;
					c.BaseSpirit = 20;
					c.Spirit = 20;
					c.Resist_Physical = 10;
					c.Resist_Holy = 10;
					c.Resist_Fire = 10;
					c.Resist_Nature = 10;
					c.Resist_Frost = 10;
					c.Resist_Shadow = 10;
					c.AttackPower = 10;
					c.AttackPowerModifier = 2;
					c.GuildRank = 1;
					c.Money = 100000;
					//c.Faction = 1;
			switch((RACE)c.Race)
			{
				case RACE.HUMAN:
					c.Faction = 1;
					break;
				case RACE.ORC:
					c.Faction = 2;
					break;
				case RACE.DWARF:
					c.Faction = 3;
					break;
				case RACE.NIGHTELF:
					c.Faction = 4;
					break;
				case RACE.UNDEAD:
					c.Faction = 5;
					break;
                case RACE.TAUREN:
					c.Faction = 6;
					break;
				case RACE.GNOME:
					c.Faction = 8;
					break;
				case RACE.TROLL:
					c.Faction = 9;
					break;
			}
					if(c.Gender == 0)
						c.DisplayID = male_models[(byte)c.Race];
					else
						c.DisplayID = female_models[(byte)c.Race];
					c.Exp = 0;
					DataServer.Database.AddNewObject(c);
			
				switch((CLASS)c.Class)
				{
					case CLASS.WARRIOR:
						//weapon 1
						DBItemTemplate wsword = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)1);
						DBItem wsword_item = new DBItem();
						wsword_item.TemplateID = wsword.ObjectId;
						wsword_item.OwnerID = c.ObjectId;
						wsword_item.OwnerSlot = 15;
						DataServer.Database.AddNewObject(wsword_item);
						DataServer.Database.FillObjectRelations(wsword_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//chest	2 		
						DBItemTemplate wchest = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)2);
						DBItem wchest_item = new DBItem();
						wchest_item.TemplateID = wchest.ObjectId;
						wchest_item.OwnerID = c.ObjectId;
						wchest_item.OwnerSlot = 4;
						DataServer.Database.AddNewObject(wchest_item);
						DataServer.Database.FillObjectRelations(wchest_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//pants 3
						DBItemTemplate wpants = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)3);
						DBItem wpants_item = new DBItem();
						wpants_item.TemplateID = wpants.ObjectId;
						wpants_item.OwnerID = c.ObjectId;
						wpants_item.OwnerSlot = 6;
						DataServer.Database.AddNewObject(wpants_item);
						DataServer.Database.FillObjectRelations(wpants_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//boots 4
						DBItemTemplate wboots = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)4);
						DBItem wboot_item = new DBItem();
						wboot_item.TemplateID = wboots.ObjectId;
						wboot_item.OwnerID = c.ObjectId;
						wboot_item.OwnerSlot = 7;
						DataServer.Database.AddNewObject(wboot_item);
						DataServer.Database.FillObjectRelations(wboot_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//buckler 5
						DBItemTemplate wbuckler = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)5);
						DBItem wbuckler_item = new DBItem();
						wbuckler_item.TemplateID = wbuckler.ObjectId;
						wbuckler_item.OwnerID = c.ObjectId;
						wbuckler_item.OwnerSlot = 16;
						DataServer.Database.AddNewObject(wbuckler_item);
						DataServer.Database.FillObjectRelations(wbuckler_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						w.Write((byte)0x28);
						client.Send(w);
						return true;
				
					case CLASS.MAGE:
						//weapon 1
						DBItemTemplate msword = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)11);
						DBItem msword_item = new DBItem();
						msword_item.TemplateID = msword.ObjectId;
						msword_item.OwnerID = c.ObjectId;
						msword_item.OwnerSlot = 15;
						DataServer.Database.AddNewObject(msword_item);
						DataServer.Database.FillObjectRelations(msword_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//chest	2 		
						DBItemTemplate mchest = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)12);
						DBItem mchest_item = new DBItem();
						mchest_item.TemplateID = mchest.ObjectId;
						mchest_item.OwnerID = c.ObjectId;
						mchest_item.OwnerSlot = 4;
						DataServer.Database.AddNewObject(mchest_item);
						DataServer.Database.FillObjectRelations(mchest_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//pants 3
						DBItemTemplate mpants = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)13);
						DBItem mpants_item = new DBItem();
						mpants_item.TemplateID = mpants.ObjectId;
						mpants_item.OwnerID = c.ObjectId;
						mpants_item.OwnerSlot = 6;
						DataServer.Database.AddNewObject(mpants_item);
						DataServer.Database.FillObjectRelations(mpants_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//boots 4
						DBItemTemplate mboots = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)14);
						DBItem mboot_item = new DBItem();
						mboot_item.TemplateID = mboots.ObjectId;
						mboot_item.OwnerID = c.ObjectId;
						mboot_item.OwnerSlot = 7;
						DataServer.Database.AddNewObject(mboot_item);
						DataServer.Database.FillObjectRelations(mboot_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);

						w.Write((byte)0x28);
						client.Send(w);
						return true;

					default:
						//weapon 1
						DBItemTemplate dsword = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)1);
						DBItem dsword_item = new DBItem();
						dsword_item.TemplateID = dsword.ObjectId;
						dsword_item.OwnerID = c.ObjectId;
						dsword_item.OwnerSlot = 15;
						DataServer.Database.AddNewObject(dsword_item);
						DataServer.Database.FillObjectRelations(dsword_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//chest	2 		
						DBItemTemplate dchest = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)2);
						DBItem dchest_item = new DBItem();
						dchest_item.TemplateID = dchest.ObjectId;
						dchest_item.OwnerID = c.ObjectId;
						dchest_item.OwnerSlot = 4;
						DataServer.Database.AddNewObject(dchest_item);
						DataServer.Database.FillObjectRelations(dchest_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//pants 3
						DBItemTemplate dpants = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)3);
						DBItem dpants_item = new DBItem();
						dpants_item.TemplateID = dpants.ObjectId;
						dpants_item.OwnerID = c.ObjectId;
						dpants_item.OwnerSlot = 6;
						DataServer.Database.AddNewObject(dpants_item);
						DataServer.Database.FillObjectRelations(dpants_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);
						//boots 4
						DBItemTemplate dboots = (DBItemTemplate)DataServer.Database.FindObjectByKey(typeof(DBItemTemplate), (uint)4);
						DBItem dboot_item = new DBItem();
						dboot_item.TemplateID = dboots.ObjectId;
						dboot_item.OwnerID = c.ObjectId;
						dboot_item.OwnerSlot = 7;
						DataServer.Database.AddNewObject(dboot_item);
						DataServer.Database.FillObjectRelations(dboot_item);
						DataServer.Database.FillObjectRelations(c);
						DataServer.Database.FillObjectRelations(client.Account);

						w.Write((byte)0x28);
						client.Send(w);
						return true;
					
				}
		}
	}
}
