This is the pre 0.1 binaries of WoWDaemon. it will probably crash alot and it
won't work on linux with mono. Mainly because it's built with a mcpp and vjsharp
codeprovider dll reference. But also because there's some bugs in mono that the mono
project needs to know about. (Try recompiling the source and report any bugs NOT RELATED
TO WOWDAEMON to the mono project. Goto www.go-mono.com and read more about how todo that.)
Run loader -l to start the server and edit the configs as you see fit. 
You can delete *.config if you mess them up. That's about it, other then that you
will have to figure it out by reading the code. This is not what I wanted to release.

Enjoy.

- Codemonkey