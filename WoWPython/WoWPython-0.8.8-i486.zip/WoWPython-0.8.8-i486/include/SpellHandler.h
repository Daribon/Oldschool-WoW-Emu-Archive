//////////////////////////////////////////////////////////////////////
//  Spell Handler
//
//  Receives all messages with spell management opcodes
//////////////////////////////////////////////////////////////////////

#ifndef WOWPYTHONSERVER_SPELLHANDLER_H
#define WOWPYTHONSERVER_SPELLHANDLER_H

#include "MsgHandler.h"

class Unit;
class GameClient;
class DatabaseInterface;

class SpellHandler : public MsgHandler
{
public:
	SpellHandler();
	~SpellHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );
	int applySpell( GameClient *pClient, Unit* target, uint32 spell, float range);
	int setAura(Unit *pUnit, uint32 spell);

protected:

};


#endif

