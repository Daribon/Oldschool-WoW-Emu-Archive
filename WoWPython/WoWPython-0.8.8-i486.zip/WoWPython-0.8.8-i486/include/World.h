#ifndef WOWPYTHONSERVER_WORLD_H
#define WOWPYTHONSERVER_WORLD_H

#include "Singleton.h"

class Character;
class World : public Singleton < World > {
public:
  World( ) { }
  ~World( ) { }
protected:
//  std::set < Character * > mCharacters;
};

#endif

