#ifndef WOWPYTHONSERVER_ITEMHANDLER_H
#define WOWPYTHONSERVER_ITEMHANDLER_H

#include "MsgHandler.h"


class ItemHandler : public MsgHandler
{
public:
	ItemHandler();
	~ItemHandler();
	void createItemUpdate( wowWData *data, GameClient *pClient, int invcount);
	void HandleMsg( wowWData & recv_data, GameClient *pClient );
protected:
    char curopcodebuf[256]; uint32 debugcounter;
};


#endif

