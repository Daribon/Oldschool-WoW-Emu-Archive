// Console.h : Add support for some interesting console tricks.

#ifndef _CONSOLE_H_
#define _CONSOLE_H_

#include <string>
using std::string;

// Named keypresses for "get()".
enum
{
	Backspace = 8, Tab = 9, Enter = 13, Esc = 27, Spacebar = 32,
	Extended = 300,
	F1 = 359, F2, F3, F4, F5, F6, F7, F8, F9, F10,
	Home = 371, Up = 372, PageUp = 373, Left = 375,
	Right = 377, End = 379, Down = 380, PageDown = 381,
	F11 = 433, F12,
};

// How we're trying to change the output.
enum conout_cmd { Color, FGColor, BGColor, };
// An output command.
struct conout
{
	// What we're doin'.
	conout_cmd cmd;

	// Extra info.
	unsigned short arg1;
};
// The built-in actions for all to use.
extern const conout Def, Black, DarkRed, DarkGreen, DarkBlue, DarkYellow, DarkMagenta, DarkCyan,
	LightGray, DarkGray, Red, Green, Blue, Yellow, Magenta, Cyan, White,
	FGBlack, FGDarkRed, FGDarkGreen, FGDarkBlue, FGDarkYellow, FGDarkMagenta, FGDarkCyan,
	FGLightGray, FGDarkGray, FGRed, FGGreen, FGBlue, FGYellow, FGMagenta, FGCyan, FGWhite,
	BGBlack, BGDarkRed, BGDarkGreen, BGDarkBlue, BGDarkYellow, BGDarkMagenta, BGDarkCyan,
	BGLightGray, BGDarkGray, BGRed, BGGreen, BGBlue, BGYellow, BGMagenta, BGCyan, BGWhite;

// The console window.
class Console
{
	private:
		// Where our standard output goes.
		static void *sout;
		// Where our standard input comes from.
		static void *sin;

		// How many columns our console window has (0+).
		static int cols;
		// How many lines our console window has (0+).
		static int rows;

		// Our current background (high nibble) and foreground (low nibble) colors.
		static unsigned short bgfg;

		// Our Windows handle.
		static void *hwnd;

		// The coords of any little scrollable window area within the screen.
		static int wleft, wtop, wright, wbottom;

		// Perform a "safe" newline, i.e., one which preserves our colors.
		void nl(void) const;

		// Print something to the output.
		//
		// In:	ch	The character to show.
		void put(char ch) const;

		// Make sure a box's dimensions make sense.
		//
		// I/O:	left	The left coordinate of the area (l -> r, <= right).
		//		top		The top coordinate of the area (t -> b, <= bottom).
		//		right	The right coordinate of the area (l -> r, >= left).
		//		bottom	The bottom coordinate of the area (t -> b, >= top).
		//
		// In:	l, t, r, b	Acceptable left, top, right and bottom coordinates.
		void BoxCheck(int &left, int &top, int &right, int &bottom,
			int l = 0, int t = 0, int r = cols - 1, int b = rows - 1) const;

	public:
		// Constructor.
		//
		// In:	width		The desired number o' columns (1+, 0 for max possible).
		//		height		The desired number o' rows (1+, 0 for max possible).
		//		pos			true to maximize and center the window.
		//		fs			true to go full screen.
		Console(int width = 80, int height = 25, bool pos = true, bool fs = false);
		// Destructor.
		virtual ~Console(void) { }

		// Return:	How many columns our console window has (0+).
		int Cols(void) const { return cols; }
		// Return:	How many lines our console window has (0+).
		int Rows(void) const { return rows; }

		// Clear the entire screen or just our limited window.  This leaves the cursor in the
		//	upper-left corner o' whatever area it just wiped.
		//
		// In:	window	true to limit ourselves to our box.
		void Clear(bool window = true) const;

		// Clear a line.  The cursor doesn't move.
		//
		// In:	r		The row to wipe (0 -> "Rows()" - 1).
		//		window	true to limit ourselves to our box.
		void Clear(int r, bool window = true) const;

		// Return:	true if the cursor is visible right now or false if it's not.
		bool CursorIsOn(void) const;

		// Turn on/off the blinkin' cursor.
		//
		// In:	visible		true to make it show or false to hide it.
		void CursorOn(bool visible) const;

		// Find where the cursor is now.
		//
		// Out:	x	The horizontal location (0 -> "Cols()" - 1).
		//		y	The vertical location (0 -> "Rows()" - 1).
		void CP(int &x, int &y) const;

		// Place the cursor at a specific spot on the screen.
		//
		// In:	y	The vertical location (0 -> "Rows()" - 1).
		//		x	The horizontal location (0 -> "Cols()" - 1).
		void Goto(int y = 0, int x = 0) const;

		// Turn End-o'-Line (EOL) wrapping on or off.  This can be used to keep the display from
		//	moving up a line when a character is written in the lower-right hand corner of the
		//	window.
		//
		// In:	on	true to enable scrolling (the default) or false to disable it.
		//
		// Note:	Turn this back ON before getting any input!!
		void EOLWrap(bool on = true) const;

		// Return:	A keypress identifier or 0 if nothing has been touched.
		int get(void) const;

		// Change our window's title.
		//
		// In:	s	The text to display.
		void Title(const string &s) const;

		// Copy a section of the window somewhere else.
		//
		// In:	sleft		The left coordinate of the area to scroll (0 -> "Cols()" - 1).
		//		stop		The top coordinate of the area to scroll (0 -> "Rows()" - 1).
		//		sright		The right coordinate of the area to scroll (0 -> "Cols()" - 1).
		//		sbottom		The bottom coordinate of the area to scroll (0 -> "Rows()" - 1).
		//		dx			The left coordinate of the destination (0 -> "Cols()" - 1).
		//		dy			The top coordinate of the destination (0 -> "Rows()" - 1).
		void Scroll(int sleft, int stop, int sright = cols - 1, int sbottom = rows - 1,
			int dx = 0, int dy = 0) const;

		// Adjust the window dimensions.
		//
		// In:	width		The desired number o' columns (1+, 0 for max possible).
		//		height		The desired number o' rows (1+, 0 for max possible).
		//		pos			true to maximize and center the window.
		//
		// Note:	You may not get the size you want and this resets any internal window to the full
		//				screen.
		void Size(int width, int height, bool pos = true) const;

		// Create a "separate" box within our screen.
		//
		// In:	left	The left coordinate of the area (0 -> "Cols()" - 1).
		//		top		The top coordinate of the area (0 -> "Rows()" - 1).
		//		right	The right coordinate of the area (0 -> "Cols()" - 1).
		//		bottom	The bottom coordinate of the area (0 -> "Rows()" - 1).
		//
		// Note:	Letting lines wrap without explicit newlines and/or getting input with cin can
		//				mess the window up!
		void Window(int left = 0, int top = 0, int right = cols - 1, int bottom = rows - 1) const;

		// Return:	Our current fore/background colors.
		conout CColor(void) const;

		// Turn on/off the mouse cursor.
		//
		// In:	visible		true to make it show or false to hide it.
		//
		// Note:	This only works in full screen mode and then only to ditch the cursor...
		void MouseOn(bool visible) const;

		// All the little carefully-watched forms o' output.
		//
		// In:	???		What to show.
		//
		// Return:	Ourselves.
		Console &operator<<(char ch);
		Console &operator<<(unsigned char uch);
		Console &operator<<(signed char sch);
		Console &operator<<(const char *psz);
		Console &operator<<(const unsigned char *pusz);
		Console &operator<<(const signed char *pssz);
		Console &operator<<(short s);
		Console &operator<<(unsigned short us);
		Console &operator<<(int n);
		Console &operator<<(unsigned int un);
		Console &operator<<(long l);
		Console &operator<<(unsigned long ul);
		Console &operator<<(float f);
		Console &operator<<(double d);
		Console &operator<<(long double ld);
		Console &operator<<(const void *pv);
		Console &operator<<(const string &s);

		// Do something special with the output.
		//
		// In:	c	The command to execute.
		//
		// Return:	Ourselves.
		Console &operator<<(const conout &c);
};

#endif
