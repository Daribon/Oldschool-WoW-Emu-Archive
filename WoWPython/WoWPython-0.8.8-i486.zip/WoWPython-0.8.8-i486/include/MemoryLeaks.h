#ifndef WOWPYTHONSERVER_MEMORY_H
#define WOWPYTHONSERVER_MEMORY_H

#include "Common.h"
#include "Singleton.h"

#if COMPILER == COMPILER_MICROSOFT
#  define _CRTDBG_MAP_ALLOC
#  include <stdlib.h>
#  include <crtdbg.h>
#endif

struct MemoryManager : public Singleton < MemoryManager > {
	MemoryManager();
};

#endif

