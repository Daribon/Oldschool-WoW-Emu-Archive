#ifndef WOWPYTHONSERVER_THREADS_H
#define WOWPYTHONSERVER_THREADS_H

#include "Common.h"

#include "Singleton.h"

#if PLATFORM == PLATFORM_WIN32
#  define THREADCONVENTION __cdecl
#  define THREADRETURN void

#  define ENDTHREAD Threads::getSingleton( ).closeCurrentThread( ); return;

#  define THREADTYPE uint32
#else
#  include <pthread.h>
#  define THREADCONVENTION
#  define THREADRETURN void *

#  define ENDTHREAD Threads::getSingleton( ).closeCurrentThread( ); return NULL;

#  define THREADTYPE pthread_t
#endif

#define THREADCALL THREADRETURN THREADCONVENTION

class Threads : public Singleton < Threads > {
public:
  enum ThreadPriority {
    TP_IDLE,
    TP_LOWER,
    TP_LOW,
    TP_NORMAL,
    TP_HIGH,
    TP_HIGHER,
    TP_REALTIME
  };

  void Fork( THREADRETURN ( THREADCONVENTION * child )( void * ), void * param, ThreadPriority priority );

  void setCurrentPriority( ThreadPriority priority );
  void closeCurrentThread( );
  void closeAllThreads( );
private:
  int32 getPlatformPriority( ThreadPriority & priority );
  typedef std::set < THREADTYPE > threadSet;
  threadSet mThreads;
};

#endif

