//////////////////////////////////////////////////////////////////////
//  NPC Handler
//
//  Receives all messages with NPC management opcodes
//////////////////////////////////////////////////////////////////////

#ifndef WOWPYTHONSERVER_NPCHANDLER_H
#define WOWPYTHONSERVER_NPCHANDLER_H

#include "MsgHandler.h"

class DatabaseInterface;
class NPCHandler : public MsgHandler
{
public:
	NPCHandler();
	~NPCHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );

protected:

};


#endif

