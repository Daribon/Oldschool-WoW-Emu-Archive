//////////////////////////////////////////////////////////////////////
//  MovementHandler
//
//  Receives all messages with object update codes
//////////////////////////////////////////////////////////////////////

#ifndef WOWPYTHONSERVER_MOVEMENTHANDLER_H
#define WOWPYTHONSERVER_MOVEMENTHANDLER_H

#include "MsgHandler.h"

class MovementHandler : public MsgHandler
{
public:
	MovementHandler();
	~MovementHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );

protected:

};


#endif

