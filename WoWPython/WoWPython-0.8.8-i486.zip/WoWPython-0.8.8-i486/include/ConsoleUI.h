// ConsoleUI.h: interface for the CConsoleUI class.
//
//////////////////////////////////////////////////////////////////////

#ifndef WOWPYTHONSERVER_CCONSOLEUI_H
#define WOWPYTHONSERVER_CCONSOLEUI_H

class CConsoleUI  
{
public:
	CConsoleUI();
	 ~CConsoleUI(){}
	void GetOutput(char* msg);
	void ServOutput(char* msg);
};

#endif 
