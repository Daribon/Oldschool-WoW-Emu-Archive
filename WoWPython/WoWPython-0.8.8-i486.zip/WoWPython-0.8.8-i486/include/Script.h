#ifndef WOWPYTHONSERVER_SCRIPT_H
#define WOWPYTHONSERVER_SCRIPT_H

#include "Singleton.h"

class Script : public Singleton < Script > {
public:
	Script( );
	~Script( );
	
	void Initialise( );
};

#endif

