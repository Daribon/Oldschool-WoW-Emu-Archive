//////////////////////////////////////////////////////////////////////
//  MiscHandler
//
//  Temp home of all those opcodes that are in WorldServer.cpp
//////////////////////////////////////////////////////////////////////

#ifndef WOWPYTHONSERVER_MISCHANDLER_H
#define WOWPYTHONSERVER_MISCHANDLER_H

#include "MsgHandler.h"

class MiscHandler : public MsgHandler
{
	friend class WorldServer;
public:
	MiscHandler();
	~MiscHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );

protected:

};


#endif

