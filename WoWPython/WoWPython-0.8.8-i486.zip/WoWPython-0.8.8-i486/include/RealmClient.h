#ifndef WOWPYTHONSERVER_GAMECLIENT_H
#define WOWPYTHONSERVER_GAMECLIENT_H

#include "Common.h"

#include "Client.h"

class RealmClient : public Client {

};

#endif
