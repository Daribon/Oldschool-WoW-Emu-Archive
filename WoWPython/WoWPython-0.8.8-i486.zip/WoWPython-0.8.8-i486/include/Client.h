#ifndef WOWPYTHONSERVER_CLIENT_H
#define WOWPYTHONSERVER_CLIENT_H

#include "Common.h"

class NetworkInterface;

class Client {
public:
    inline NetworkInterface * getNetwork( ) const { return m_net; }
    void BindNI( NetworkInterface * &net ) { m_net = net; }
protected:
    NetworkInterface * m_net;
};

#endif
