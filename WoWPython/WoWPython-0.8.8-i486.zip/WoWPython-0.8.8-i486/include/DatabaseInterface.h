#ifndef WOWPYTHONSERVER_DATABASEINTERFACE_H
#define WOWPYTHONSERVER_DATABASEINTERFACE_H

#include "Common.h"
#include "GameClient.h"

class Unit;
class Character;
class Path;
struct wowWData;
class DatabaseInterface {
  friend class Database;
public:
  int doQuery( const char * query );
  int IsNameTaken(char * charname);
  int GetNameGUID(char * charname);
  void GetPlayerNameFromGUID(uint32 guid, uint8 *name);
  void addCharacter( Character * newChar );
  std::set< Character * > enumCharacters( int account_id );
  void removeCharacter( Character * newChar );
  void setCharacter( Character * diffChar );
  void setHighestGuids();

  uint32 getGlobalTaxiNodeMask( uint32 curloc );

  uint32 getPath( uint32 source, uint32 destination );
  void getPathNodes( uint32 path, Path *pathnodes );
  uint32 getNearestTaxiNode( float x, float y, float z, uint16 continent );

  void getTrainerSpells( Character * pChar, const uint32 *trainer, wowWData & data ); //load spells for this char
  int getTrainerSpellsCount( const uint32 *trainer ); //count how many spells a given trainer has
  int getTrainerSpellsPrice( uint32 spellGuid, uint32 trainerGuid ); //get the price for a specific spell
  int addTrainerSpell ( const uint32 *trainer, uint32 iSpellGuid, uint32 iSpellPrice ); //add spells to trainer

  void saveCreature(Unit *pUnit);
  std::set< Unit * > loadCreatures();
  void loadCreatureNames(std::map< uint32, uint8*> & p_names);
  void saveCreatureNames(std::map< uint32, uint8*> p_names);

  void loadItems();

  void loadQuests();  // load the quests into QuestHandler
  void loadQuestStatus(Character *pChar);   // load quest progress for this character
  void saveQuestStatus(Character *pChar);   // save quest progress for this character

  int Login(char* username, char* password);
  int getAccountLvl(int account_id);
  // <WoW Chile Dev Team> Start Change
  int IsCharMoveExist(uint32 guid);
  // <WoW Chile Dev Team> Stop Change
  // <WoW Chile Dev Team> Start Change
  ///////////////////////////// NIMROD //////////////////////////////////////
  int DatabaseInterface::addUserGuild(char *member, char *leader); // adds a user to a clan -- agrega a un wn al clan
  int addNewGuild(char *lider, char *nombre, char *motd); // agrega un clan // adds a guild
  char* DatabaseInterface::getGuildMotd(char* usuario); //get motd -- saca el mensaje del dia
  int DatabaseInterface::setGuildMotd(char *lider, char *mensaje); // set new guild motd -- pone nuevo motd
  int DatabaseInterface::removeUserGuild(char *member, char *leader); // remove an user from the guild -- saca a 1 user del clan
  int DatabaseInterface::disbandGuild(char *leader); // disband the guild -- desarma el clan
  int DatabaseInterface::setGuildRank(char *leader, char *member, int rank); // gives a rank to a user -- da ranking a un wn
  /////////////////////////////// END NIMROD /////////////////////////////////////////
  // <WoW Chile Dev Team> Stop Change
protected:

  DatabaseInterface( void * handle );
  ~DatabaseInterface( );

  /// Handle to the database connection represented by this object
  void * mDatabaseConnection;
};

#endif

