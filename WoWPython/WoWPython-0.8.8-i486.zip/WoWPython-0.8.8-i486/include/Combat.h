#ifndef WOWPYTHONSERVER_COMBATHANDLER_H
#define WOWPYTHONSERVER_COMBATHANDLER_H

#include "MsgHandler.h"

class Unit;
class GameClient;
struct wowWData;
struct UpdateMask;
class CombatHandler
{
public:
	CombatHandler() {};
	virtual ~CombatHandler() {};

	void HandleMsg( wowWData & recv_data, GameClient *pClient );

    /////////////////////////////////////////////////////////////////////////
    //  Deals damage from pAttacker to pVictim
    //  Does checks for death and lots of other keen things
    void DealDamage(Unit *pAttacker, Unit *pVictim, uint32 damage);

    void smsg_AttackStart(Unit* pAttacker, Unit* pVictim);
    void smsg_AttackStop(Unit* pAttacker, uint32 victim_guid[2]);

    void AttackerStateUpdate(Unit *pAttacker, Unit *pVictim);
	void Heal(Unit *pAttacker, Unit *pVictim, uint32 damage);
    
};

#endif
