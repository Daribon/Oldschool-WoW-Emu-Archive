#ifndef WOWPYTHONSERVER_UNIT_H
#define WOWPYTHONSERVER_UNIT_H

#include "Object.h"
#include "UpdateMask.h"
#include <time.h>


struct creepItem{
	uint32 itemid;
	int amount;
};

enum DeathState{
    ALIVE=0,    // Unit is alive and well
    JUST_DIED,  // Unit has JUST died
    CORPSE,     // Unit has died but remains in the world as a corpse
    DEAD        // Unit is dead and his corpse is gone from the world
};

#define UF_TARGET_DIED  1
#define UF_ATTACKING    2   // this unit is attacking it's selection

class Quest;
class Character;
class Item;
class GameClient;
//====================================================================
//  Unit
//  Base object for Players ? is that all?
//====================================================================
class Unit : public Object
{
    friend class WorldServer;
    friend class DatabaseInterface;
	friend class MiscHandler;
public:
    Unit ( );
    virtual ~Unit ( );

    ///////  Creation / Updates  ///////////////////////////////////////////////////////
    virtual void Create (uint32 guidlow);
    virtual void Create (uint32 guidlow, uint8* creature_name, 
                         float x, float y, float z, float ang);
    void Update( float time );

	// <WoW Chile Dev Team> Start Change
	void UpdateMobMovement( float p_time);
	// <WoW Chile Dev Team> Stop Change

    void SendCreateWithTempNpcFlags(UpdateMask *updateMask, GameClient *pClient);  // kinda hackish function I guess
    virtual void BuildUpdateBlock(UpdateMask* updateMask, uint8 * data, int* length);

    // fill UpdateValues with data from a space seperated string of uint32s
    virtual void LoadUpdateValues(uint8* data);
    ///////////////////////////////////////////////////////////////////////



    ///////  Quests ///////////////////////////////////////////////////////
    uint32 getQuestStatus(Character *pPlayer);
    uint32 getCurrentQuest(Character *pPlayer);

    char* getQuestTitle(uint32 quest_id);
    char* getQuestDetails(uint32 quest_id);
    char* getQuestObjectives(uint32 quest_id);
    char* getQuestCompleteText(uint32 quest_id);
    char* getQuestIncompleteText(uint32 quest_id);

    bool hasQuest(uint32 quest_id);
    void addQuest(uint32 quest_id) { mQuestIds.push_back(quest_id); };
    void removeQuest(uint32 quest_id);
    ///////////////////////////////////////////////////////////////////////


    ///////  Combat / Death Status /////////////////////////////////////////
    inline bool IsAlive() { return m_deathState == ALIVE; };
    inline bool IsDead() { return m_deathState == DEAD; };
    inline void setDeathState(DeathState s) { m_deathState = s; };
    void setTimeOfDeath() { m_timeOfDeath = time(NULL); };
    void setAttackTime();
    bool canAttack();
    ///////////////////////////////////////////////////////////////////////

    ///////  AI  /////////////////////////////////////////////////////////////////////////
    void AI_Update();
    void AI_AttackReaction(Unit *pAttacker, uint32 damage_dealt);
	// <WoW Chile Dev Team> Start Change
    void AI_MoveTo(float new_pos[3], uint32 time,int StateFlag);
	void AI_ChangeState(int __state){ creature_state = __state; };
	void AI_scape(); //mob scape if his healt is low
	// <WoW Chile Dev Team> Stop Change
    //////////////////////////////////////////////////////////////////////////////////////


    //////  Items ///////////////////////////////////////////////////////////////////////////////
	void	setItemId(int slot, uint32 tempitemid) { item_list[slot].itemid = tempitemid; }
	void	setItemAmount(int slot, int tempamount) { item_list[slot].amount = tempamount; }
	void	setItemAmountById(int tempitemid, int tempamount) {
		int i;
		for(i=0;i<itemcount;i++)
		{
			if(item_list[i].itemid == tempitemid)
				item_list[i].amount = tempamount;
		}
	}
	void	increaseItemCount() { itemcount++; }
	void	addItem(uint32 itemid, uint32 amount) {
		item_list[itemcount].amount = amount;
		item_list[itemcount].itemid = itemid;
		itemcount++;
	}
	int		getItemCount() { return itemcount; }
	int		getItemAmount(int slot) { return item_list[slot].amount; }
	uint32	getItemId(int slot) { return item_list[slot].itemid; }
    //////////////////////////////////////////////////////////////////////////////////////////////


    ///////  Flags /////////////////////////////////////////////////////////
    inline const uint32 addUnitFlag(uint32 new_flag){
        uint32 flags = getUpdateValue(UNIT_FIELD_FLAGS);
        flags |= new_flag;
        setUpdateValue(UNIT_FIELD_FLAGS, flags);
        return flags;
    };

    inline const uint32 removeUnitFlag(uint32 old_flag){
        uint32 flags = getUpdateValue(UNIT_FIELD_FLAGS);
        flags &= ~old_flag;
        setUpdateValue(UNIT_FIELD_FLAGS, flags);
        return flags;
    };

    // State flags are server-only flags to help me know when to do stuff, like die, or attack
    inline void addStateFlag(uint32 f) { m_state |= f; };
    inline void clearStateFlag(uint32 f) { m_state &= ~f; };
    ///////////////////////////////////////////////////////////////////////


    /////////  Misc / Get / Set /////////////////////////////////////
    virtual bool IsPlayer() { return false; };
    inline void setEmoteState(uint8 emote) { m_emoteState = emote; };
    void setAnimFrequency( uint32 anim, float frequency );
    char* getCreatureName() { return (char*)m_creatureName; };
	uint8 getMovementState() { return m_movementState; };
	uint8 setMovementState(uint8 movement) { m_movementState = movement; };
    inline uint8  GetLevel()    { return (uint8)m_updateValues[ UNIT_FIELD_LEVEL ]; };
    inline uint8  GetRace()     { return (uint8)m_updateValues[ UNIT_FIELD_BYTES_0 ] & 0xFF; };
    inline uint8  GetClass()    { return (uint8)(m_updateValues[ UNIT_FIELD_BYTES_0 ] >> 8) & 0xFF; };
    inline uint8  GetGender()   { return (uint8)(m_updateValues[ UNIT_FIELD_BYTES_0 ] >> 16) & 0xFF; };
    inline uint16 GetZone()     { return m_mapId; };
    /////////////////////////////////////////////////////////////////

    /////////  Looting //////////////////////////////////////////////
	void generateLoot();
	uint32 getLootMoney() { return m_lootMoney; };
	void setLootMoney(uint32 amount) { m_lootMoney = amount; };
	/////////////////////////////////////////////////////////////////

protected:

	// Looting
	uint32 m_lootMoney;

	// Spells/Skills
	uint8  m_movementState;

    // Creature data
    uint8  m_emoteState;
    uint8  m_creatureName[80];
    uint32 m_timeOfDeath;   // time of death or corpse disappearance
    uint32 m_respawnDelay;  // delay between corpse disappearance and respawning
    uint32 m_corpseDelay;   // delay between death and corpse disappearance
    DeathState m_deathState;
    uint32 m_state;         // flags for keeping track of some states

    // Combat
    uint32 m_lastAttack;    // time of last attack
    std::list<Unit*> m_attackers;

    // Quest data 
    std::list<uint32> mQuestIds;

    // Anim data for frexxy
    std::map <uint32, float> mAnimFrequencies;

    // Item data
	creepItem item_list[128];
	int itemcount;

    // Taxi data
    uint32 mTaxiNode;
	
	// <WoW Chile Dev Team> Start Change
	//Movement
	int creature_state; // 0= stop , 1=move, 3=attack;
	int creature_canMove;
	int creature_RandomMove,creature_Run;
	int current_path;
	int current_dir;
	int creature_paths;
	float creature_cord[16][3];
	float TimeTomove;
	uint32 movestartTime;
	// <WoW Chile Dev Team> finish Change
};
#endif

