#ifndef WOWPYTHONSERVER_QUERY_H
#define WOWPYTHONSERVER_QUERY_H

#include "MsgHandler.h"

class QueryHandler : public MsgHandler
{
public:
	QueryHandler();
	~QueryHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );
protected:
};


#endif

