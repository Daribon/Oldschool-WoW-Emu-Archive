// WorldServer.h: interface for the WorldServer class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_WORLDSERVER_H__640A742F_9A0B_4F43_B406_7FA0546820C1__INCLUDED_)
#define AFX_WORLDSERVER_H__640A742F_9A0B_4F43_B406_7FA0546820C1__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Server.h"
#include "Common.h"
#include "GameClient.h"
#include <time.h>

#include "Group.h"

#include "ObjectMgr.h"

// include handlers
#include "ChatHandler.h"
#include "CharacterHandler.h"
#include "MovementHandler.h"
#include "QueryHandler.h"
#include "QuestHandler.h"
#include "TaxiHandler.h"
#include "GroupHandler.h"
#include "SpellHandler.h"
#include "SkillHandler.h"
#include "ItemHandler.h"
#include "NPCHandler.h"
#include "Combat.h"
#include "Item.h"
#include "MiscHandler.h"

class Object;
class Character;
class Unit;
class Quest;


// Distance a Player can "see" other objects and receive updates from them
#define UPDATE_DISTANCE 155.8


class WorldServer : public Server, public Singleton < WorldServer >  
{
	friend class ChatHandler;
	friend class CharacterHandler;
	friend class MovementHandler;
    friend class QueryHandler;
    friend class QuestHandler;
    friend class CombatHandler;
    friend class SpellHandler;
    friend class NPCHandler;
    friend class SkillHandler;
	friend class MiscHandler;
	
    friend class Character;
public:
	WorldServer();
	~WorldServer();

	void updateRealm(char *);

	int dbstate;

	Group * WorldServer::GetGroupByLeader(char* name);
	void AddGroup(Group* pGroup);
	void DelGroup(Group* pGroup);
    void Update( float time );  // update the world server every frame


	uint32 GetClientsConnected(){return mClients.size();}

	void SetMotd(char *newMotd);
	uint8 *GetMotd(){ return motd; }

	void SendGlobalMessage(wowWData* data, GameClient *pSelf);
//	void SendZoneMessage(wowWData* data, GameClient *pSelf, int flag);
//	void SendAreaMessage(wowWData* data, GameClient *pSelf, int flag);
//	void SendUnitZoneMessage(wowWData* data, int zoneid, int mapid);
//	void SendUnitAreaMessage(wowWData* data, Unit *pUnit);

	float CalcDistance(Unit *pCa, Unit *pCb);
	float CalcDistanceByPosition(Unit *pCa, float x, float y, float z);


	//Overloaded function, not second arguments so it truly send to -everyone-
	void SendGlobalMessage(wowWData* data);
	int SendMessageToPlayer(wowWData *data, char* name);  // name of the player to send a message to
    int SendMessageToPlayer(wowWData *data, uint32 guid);  // name of the player to send a message to

	void SendWorldText(uint8 *text);
    void SendWorldText(uint8 *text, GameClient *pSelf);

    inline void addQuest(Quest* pQuest) { mQuestHandler.addQuest(pQuest); };
    inline Quest* getQuest(uint32 quest_id) { return mQuestHandler.getQuest(quest_id); };

    uint32 addCreatureName(uint8* name);
    inline uint8 * getCreatureName( uint32 entry ) {
		if( mCreatureNames.find( entry ) != mCreatureNames.end( ) )
			return mCreatureNames[entry];
		return 0;
    };
    void saveCreatures();

    void SetInitialWorldSettings();
    std::map< uint32, Unit*> getCreatureMap() { return mCreatures; };
    std::map< uint32, Character*> getCharacterMap() { return mCharacters; };
    std::map< uint32, Item*> getItemMap() { return mItems; };

    void CheckForInRangeObjects(Object* obj);

	void AddItem(Item* pItem);
	Item *GetItem(uint32 itemid);

	Unit *GetCreature(uint32 unitguid);
	Unit *GetValidCreature(uint32 unitguid);
	GameClient * GetClientByName(char* name);

    inline long int updateGameTime(){
      // Update Server time
      long int thisTime = time(NULL);
      m_gameTime += thisTime - m_lastTick;
      m_lastTick = thisTime;
      return m_gameTime; 
     };

    uint32 m_hiCharGuid;  // highest GUID, used for creating new objects
    uint32 m_hiCreatureGuid;  // highest GUID, used for creating new objects
    uint32 m_hiItemGuid;  // highest GUID, used for creating new objects
    uint32 m_hiGoGuid;
	
    DatabaseInterface *dbi;
	void server_sockevent(struct nlink_server *cptr, unsigned short revents, void * myNet);
	void client_sockevent(struct nlink_client *cptr, unsigned short revents);
	void disconnect_client(	struct nlink_client *cptr );

	void eventStart( );
	void eventStop( );
protected:

    void LogoutPlayer(GameClient *pClient);


	uint32	mClientsConnected;

	uint8	*motd;
	uint16	motd_size;

    // map text emote to emote animation id
   	typedef std::map< uint8, uint8> EmotesMap;
	EmotesMap mEmotes;

    // map entry to a creature name
	typedef std::map< uint32, uint8*> CreatureNameMap;
	CreatureNameMap mCreatureNames;
    uint32 m_creatureEntries;

    long int m_gameTime; // uh oh!  attempting to synchronize time!
    long int m_lastTick;

    ///// Object Tables ////
    // These tables are modified as creatures are created and destroyed in the world

	// Group List
	typedef std::list< Group * > GroupList;
	GroupList mGroupList;
	
	// Map of active characters in the game
	typedef std::map< uint32, Character*> CharacterMap;
	CharacterMap mCharacters;

	// Map of active creatures in the game
	typedef std::map< uint32, Unit*> CreatureMap;
	CreatureMap mCreatures;

	// Map of all item types in the game
	typedef std::map< uint32, Item*> ItemMap;
	ItemMap mItems;

	int killingItem; //thread safety
	int dontkillItem;

public:
    ObjectMgr           mObjectMgr;

	// Message Handlers
	ChatHandler         mChatHandler;
    TaxiHandler         mTaxiHandler;
    ItemHandler         mItemHandler;
    GroupHandler		mGroupHandler;
	QueryHandler        mQueryHandler;
    QuestHandler        mQuestHandler;
	MovementHandler     mMovementHandler;
	CharacterHandler    mCharacterHandler;
    CombatHandler       mCombatHandler;
    SpellHandler        mSpellHandler;
    NPCHandler          mNPCHandler;
	MiscHandler			mMiscHandler;
    SkillHandler		mSkillHandler;


};



#endif // !defined(AFX_WORLDSERVER_H__640A742F_9A0B_4F43_B406_7FA0546820C1__INCLUDED_)
