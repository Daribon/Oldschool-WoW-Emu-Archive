#ifndef WOWPYTHONSERVER_GAMECLIENT_H
#define WOWPYTHONSERVER_GAMECLIENT_H

#include "Common.h"

#include "Client.h"

class DatabaseInterface;

class Object;
class Character;
struct wowWData;
typedef std::list<Character*> CharacterList;	

class GameClient : public Client {
public:
    GameClient();
    ~GameClient();

    void Create( int account_id, NetworkInterface * net );
    void SendMsg( wowWData * data );
    void CreateDB();
    void BindAcctID( int account_id );
    DatabaseInterface * getDB( ) const { return m_db; }

    inline bool IsInWorld() { return m_isInWorld; };
    inline void InWorld(bool bNew) { m_isInWorld = bNew; };

    inline Character * getCurrentChar() const { return mCurrentChar; }
    void addCharacter(Character* pChar);
    inline void setCurrentChar(Character* pChar) { mCurrentChar = pChar; };
    inline int numCharacters() { return m_characters.size( ); };
    char* getCharacterName();
    char* getCharacterName(uint32 guid);
    void ClearCharacterList();
    Character* getCurrentChar(uint32 player_guid);

    inline void eraseCharacter( CharacterList::iterator iter ) { m_characters.erase(iter); };
    inline CharacterList::iterator charListBegin() { return m_characters.begin(); };
    inline CharacterList::iterator charListEnd() { return m_characters.end(); };
    int isAuth() { return rcvAuth; }
    void setAuth() { rcvAuth = 1; }
    void SetLastTarget(uint32 ttarget) { lasttarget = ttarget; }
    uint32 getLastTarget() { return lasttarget; }

    inline void setAccountLvl(int lvl) { m_accountLvl = lvl; };
    inline int getAccountLvl() { return m_accountLvl; };
    int getAccountID() { return m_accountId; }

    inline void LogoutRequest(uint32 requestTime) { logoutTime = requestTime; };
    inline bool ShouldLogOut(uint32 currTime) { return (logoutTime > 0 && currTime >= logoutTime + 20); };

protected:
    DatabaseInterface * m_db;
    Character * mCurrentChar;

    CharacterList m_characters; // list of characters this client has

    int m_accountLvl;   // 0 - normal, 1 - GM
    int m_accountId;
    int numThreadsUsing;
    bool pleaseKillMe;
    bool m_isInWorld;	// true when the client's character has been created and is int he world

    uint32 logoutTime;  // time we received a logout request -- wait 20 seconds, and quit
    uint32 lasttarget;

    int rcvAuth;
};

#endif

