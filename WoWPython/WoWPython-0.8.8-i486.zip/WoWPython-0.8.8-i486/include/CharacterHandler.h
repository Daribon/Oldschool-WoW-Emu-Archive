//////////////////////////////////////////////////////////////////////
//  CharacterHandler
//
//  Receives all messages with character management opcodes
//////////////////////////////////////////////////////////////////////

#ifndef WOWPYTHONSERVER_CHARACTERHANDLER_H
#define WOWPYTHONSERVER_CHARACTERHANDLER_H

#include "MsgHandler.h"

class DatabaseInterface;
class CharacterHandler : public MsgHandler
{
public:
	CharacterHandler();
	~CharacterHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );

protected:

};


#endif

