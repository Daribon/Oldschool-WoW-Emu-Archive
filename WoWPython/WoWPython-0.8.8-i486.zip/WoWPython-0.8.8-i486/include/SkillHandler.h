//////////////////////////////////////////////////////////////////////
//  Skill Handler
//
//  Receives all messages with Skill management opcodes
//////////////////////////////////////////////////////////////////////

#ifndef WOWPYTHONSERVER_SKILLHANDLER_H
#define WOWPYTHONSERVER_SKILLHANDLER_H

#include "MsgHandler.h"

class DatabaseInterface;
class SkillHandler : public MsgHandler
{
public:
	SkillHandler();
	~SkillHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );

protected:

};


#endif

