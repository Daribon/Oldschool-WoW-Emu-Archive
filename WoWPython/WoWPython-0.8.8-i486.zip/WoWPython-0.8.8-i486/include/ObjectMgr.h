#ifndef WOWPYTHON_OBJECTMGR_H
#define WOWPYTHON_OBJECTMGR_H

#include "Common.h"

struct UpdateMask;
struct wowWData;
class Character;
class Unit;
class ObjectMgr
{
public:
    ObjectMgr() {};
    ~ObjectMgr(){};

    void BuildCreatePlayerMsg(Character *pNewChar, std::list<wowWData*>* msglist);
    void SetCreatePlayerBits(UpdateMask *updateMask);

    void BuildCreateUnitMsg(Unit *pNewUnit, wowWData* data);
    void SetCreateUnitBits(UpdateMask &updateMask);


protected:
};

#endif