#ifndef WOWPYTHONSERVER_TAXIHANDLER_H
#define WOWPYTHONSERVER_TAXIHANDLER_H

#include "MsgHandler.h"


class TaxiHandler : public MsgHandler
{
public:
	TaxiHandler();
	~TaxiHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );
protected:
};


#endif

