#ifndef WOWPYTHONSERVER_QUESTHANDLER_H
#define WOWPYTHONSERVER_QUESTHANDLER_H

#include "MsgHandler.h"

class Quest;
class QuestHandler : public MsgHandler
{
public:
	QuestHandler();
	~QuestHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );
    void addQuest(Quest *pQuest);
    Quest* getQuest(uint32 quest_id);
protected:
    // Quest data 
    typedef std::map<uint32, Quest*> QuestMap;
    QuestMap mQuests;
};


#endif

