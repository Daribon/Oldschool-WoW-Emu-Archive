#ifndef WOWPYTHONSERVER_LOG_H
#define WOWPYTHONSERVER_LOG_H

#include "Common.h"
#include "Singleton.h"

class Log : public Singleton< Log > {
public:
  void outString( const char * str, ... );
  void outError( const char * err, ... );
};

#endif

