#ifndef WOWPYTHONSERVER_GAMEOBJECT_H
#define WOWPYTHONSERVER_GAMEOBJECT_H

#include "Object.h"

class GameObject : public Object {
public:
    GameObject::GameObject( );

    void Create ( uint32 guidlow, uint32 display_id, uint8 state, float scale, uint16 type, uint16 faction,  float x, float y, float z, float ang );

};

#endif

