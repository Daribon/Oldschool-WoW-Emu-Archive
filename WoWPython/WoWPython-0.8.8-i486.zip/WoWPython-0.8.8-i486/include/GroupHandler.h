#ifndef WOWPYTHONSERVER_GROUPHANDLER_H
#define WOWPYTHONSERVER_GROUPHANDLER_H

#include "MsgHandler.h"

class GroupHandler : public MsgHandler
{
public:
	GroupHandler();
	~GroupHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );
protected:
};




#endif
