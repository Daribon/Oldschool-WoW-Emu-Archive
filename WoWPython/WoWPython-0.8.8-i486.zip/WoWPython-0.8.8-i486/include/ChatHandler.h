//////////////////////////////////////////////////////////////////////
//  ChatHandler
//
//  Receives all messages with a chat-related opcode.
//////////////////////////////////////////////////////////////////////
#ifndef WOWPYTHONSERVER_CHAT_H
#define WOWPYTHONSERVER_CHAT_H

#include "MsgHandler.h"

class GameClient;
class ChatHandler : public MsgHandler
{
public:
	ChatHandler();
	~ChatHandler();

	void HandleMsg( wowWData & recv_data, GameClient *pClient );

	void FillMessageData( wowWData *data, uint8 type, GameClient *pClient, uint8 *text );
    void SpawnCreature(GameClient *pClient, char* pName, uint32 display_id, uint32 npcFlags, uint32 faction_id, uint32 level);
    void smsg_NewWorld(GameClient *pClient, uint8 c, float x, float y, float z);
    void MovePlayer(GameClient *pClient, float x, float y, float z);

protected:
    int ParseCommands(uint8* textCompare, uint16 text_length);
    int ParseLvl0Commands(uint8* textCompare, uint16 text_length);
    int ParseLvl1Commands(uint8* textCompare, uint16 text_length);
    int ParseLvl2Commands(uint8* textCompare, uint16 text_length);
	int ParseLvl3Commands(uint8* textCompare, uint16 text_length);

    GameClient *m_pClient;
};


#endif

