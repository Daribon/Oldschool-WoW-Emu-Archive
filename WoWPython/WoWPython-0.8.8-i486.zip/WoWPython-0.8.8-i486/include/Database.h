#ifndef WOWPYTHONSERVER_DATABASE_H
#define WOWPYTHONSERVER_DATABASE_H

#include "Common.h"
#include "Singleton.h"
#include "DatabaseInterface.h"

class Database : public Singleton < Database > {
public:
  Database( );
  ~Database( );
  void Initialise( const char *host, const char *user, const char *password, const char *database, uint32 port = 3306 );
  void removeDatabaseInterface( DatabaseInterface *db );
  DatabaseInterface * createDatabaseInterface( );

  inline void toggleAutoCreateAcct() { m_bAutoCreateAcct = !m_bAutoCreateAcct; };
  inline bool isAutoCreateAccts() { return m_bAutoCreateAcct; };

private:
  std::string mHost,mUser,mPassword,mDatabase;
  uint32 mPort;
  std::set < DatabaseInterface * > mInterfaces;

  bool m_bAutoCreateAcct;
};

#endif

