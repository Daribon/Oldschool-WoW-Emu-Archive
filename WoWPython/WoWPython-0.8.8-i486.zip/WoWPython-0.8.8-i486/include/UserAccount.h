#ifndef WOWPYTHONSERVER_USERACCOUNT_H
#define WOWPYTHONSERVER_USERACCOUNT_H

class UserAccount
{
public:
	UserAccount(){ }
	~UserAccount();

	void Create( );

protected:

};

#endif

