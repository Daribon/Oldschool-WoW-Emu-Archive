#ifndef WOWPYTHONSERVER_REDIRECTORSRV_H
#define WOWPYTHONSERVER_REDIRECTORSRV_H

#include "Common.h"
#include "Client.h"

#include "Server.h"
#include "Network.h"

class RedirectorSrv : public Server {
public:
    RedirectorSrv( ) { }
    ~RedirectorSrv( ) { }
    void Initialise( int port, char * type, char * destination );
protected:

	virtual void client_sockevent(struct nlink_client *cptr, unsigned short revents);
	virtual void server_sockevent( nlink_server *cptr, uint16 revents, void *myNet );
	virtual void disconnect_client(	struct nlink_client *cptr );
	
	std::string mDestination;
private:
    void Initialise( int port, char * type );
};

#endif

