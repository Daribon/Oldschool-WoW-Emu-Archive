#include "Log.h"
#include <stdio.h>
#include <stdarg.h>

createFileSingleton( Log );

void Log::outString( const char * str, ... ) {
    if( !str ) return;
    va_list ap;
    va_start(ap, str);
    vprintf( str, ap );
    printf( "\n" );
    va_end(ap);
}

void Log::outError( const char * err, ... ) {
    if( !err ) return;
    va_list ap;
    va_start(ap, err);
    vfprintf( stderr, err, ap );
    fprintf( stderr, "\n" );
    va_end(ap);
}