#include "Item.h"

Item::Item( ) {
    Object::Object( );
	m_objectType |= TYPE_ITEM;
    m_objectTypeId = 1;

}

void Item::Create( uint32 guidlow, uint32 itemid ) {
    Object::Create(guidlow);
	m_guid[0] = guidlow;
	m_guid[1] = 0x00000040;
    setUpdateValue(OBJECT_FIELD_ENTRY, itemid);
}
