#include "ChatHandler.h"
#include "NetworkInterface.h"
#include "GameClient.h"
#include "Opcodes.h"
#include "Log.h"
#include "WorldServer.h"
#include "Character.h"
#include "UpdateMask.h"
#include "Database.h"

#define world WorldServer::getSingleton()

ChatHandler::ChatHandler()
{

}

ChatHandler::~ChatHandler()
{

}

int ChatHandler::ParseCommands(uint8* textCompare, uint16 text_length)
{
    if (m_pClient->getAccountLvl() >= 0) // Normal User Commands
        if (ParseLvl0Commands(textCompare, text_length) > 0)  return 1;

    if (m_pClient->getAccountLvl() >= 1) // GM Commands
        if (ParseLvl1Commands(textCompare, text_length) > 0)  return 1;
		if (ParseLvl3Commands(textCompare, text_length) > 0)  return 1;

    if (m_pClient->getAccountLvl() >= 2) //Admin Level Commands
        if (ParseLvl2Commands(textCompare, text_length) > 0)  return 1;
 
    return 0;
}

void ChatHandler::HandleMsg( wowWData & recv_data, GameClient *pClient )
{
    wowWData data;
    char f[256];
    sprintf(f, "WORLD: Chat Opcode 0x%.4X", recv_data.opcode);
    Log::getSingleton( ).outString( f );
    switch (recv_data.opcode)
    {
    case CMSG_MESSAGECHAT:  
        {
            uint16 text_length = strlen((char*)recv_data.data+8)+1;

            m_pClient = pClient;
            if (ParseCommands(recv_data.data+8, text_length) > 0)
                return;

            uint8 text_mode = recv_data.data[0];
            FillMessageData( &data, text_mode, pClient, recv_data.data+8 );

            if (text_mode != CHAT_MSG_WHISPER) { // whisper message send in FillMessageData
                pClient->SendMsg( &data );
                world.SendGlobalMessage(&data, pClient);
            }
        }break;
  case CMSG_TEXT_EMOTE:
        {
            uint32 text_emote, guid1, guid2;
            recv_data.readData(text_emote);
            recv_data >> guid1 >> guid2;

            char *nam=0; uint16 namlen=0;
            WorldServer::CharacterMap::iterator chariter;
            WorldServer::CreatureMap::iterator npciter;
            if( ( npciter = world.mCreatures.find( guid1 ) ) != world.mCreatures.end( ) ) {
                nam = npciter->second->getCreatureName( );
                namlen = strlen( nam ) + 1;
            } else if( ( chariter = world.mCharacters.find( guid1 ) ) != world.mCharacters.end( ) ) {
                nam = chariter->second->getName( );
                namlen = strlen( nam ) + 1;
            }

            data.clear();
            data.Initialise(12, SMSG_EMOTE);

            uint8 emote_anim = world.mEmotes[uint8(text_emote&0xff)];

            data << (uint8)emote_anim;
            data << (uint8)0x00;
            data << (uint8)0x00;
            data << (uint8)0x00;

            uint32 guid = pClient->getCurrentChar()->getGUID();
            data << (uint32)guid << (uint8)0x00 << (uint8)0x00 << (uint8)0x00 << (uint8)0x00;
            world.SendGlobalMessage(&data);

            data.clear();
            data.setLength(12 + namlen);
            data.opcode = SMSG_TEXT_EMOTE;


            memcpy(data.data, &guid, 4);
            data.data[4] = 0x00;
            data.data[5] = 0x00;
            data.data[6] = 0x00;
            data.data[7] = 0x00;

            memcpy(data.data+8,recv_data.data,4);

            if( namlen > 0 )
                memcpy( data.data + 12, nam, namlen );

            pClient->SendMsg( &data );
            world.SendGlobalMessage(&data, pClient);
        } break;
    }
}

void ChatHandler::FillMessageData( wowWData *data, uint8 type, GameClient* pClient, uint8 *text )
{

    // !!!! Be careful using strlen to determine the size of the chat message.
    // A CHAT_MSG_WHISPER sends TWO null terminated  strings(first the name of 
    // the whisper target, then the message) and doing strlen only finds the 
    // length of the first string.  -- DeathCheese

    const uint8 msgchat_header_size=13;
    uint8 msgchat_header[msgchat_header_size] = {type,
        0x00, 0x00, 0x00, 0x00}; //no idea what are those bytes for

    // add guid to message header
    uint32 guid=0;
    if(pClient)
        guid = pClient->getCurrentChar()->getGUID();
    memcpy(msgchat_header+5, &guid, 4);
    msgchat_header[9] = 0x00;
    msgchat_header[10] = 0x00;
    msgchat_header[11] = 0x00;
    msgchat_header[12] = 0x00;

    data->clear();

    std::string logoutput = "CHAT: ";
    if( pClient ) {
        logoutput += pClient->getCurrentChar( )->getName( );
        logoutput += ": ";
    }

    uint16 length = strlen((char*)text) + 1;
    if (type == CHAT_MSG_WHISPER){
        // Whisper Chat:  Server receives two strings.  First is the target of whisper, second is the message.
        uint16 msg_length = strlen((char*)text+length) + 1;

        data->setLength(msgchat_header_size + msg_length + 1);
        data->opcode = SMSG_MESSAGECHAT;
        memcpy(data->data, msgchat_header, msgchat_header_size);
        memcpy(data->data+msgchat_header_size, text+length, msg_length);
        data->data[msgchat_header_size+msg_length] = 0; //NULL terminated string
        logoutput += "->";
        logoutput += (char *)text;
        logoutput += "<- ";
        logoutput += (char *)(text + length);
    }
    else{
        data->setLength(msgchat_header_size + length + 1);
        data->opcode = SMSG_MESSAGECHAT;

        memcpy(data->data,msgchat_header,msgchat_header_size);
        memcpy(data->data+msgchat_header_size, text, length);
        data->data[msgchat_header_size+length] = 0; //NULL terminated string
        logoutput += (char *)text;
    }

    Log::getSingleton( ).outString( logoutput.c_str( ) );

    // The last byte is most likely a flag, 0 or 1, denoting on or off
    uint8 byte = 0x00;
    if(type == CHAT_MSG_AFK && pClient!=0) { // toggle AFK
        byte = pClient->getCurrentChar()->ToggleAFK();
    }

    data->data[data->length-1] = byte;

    if (type == CHAT_MSG_WHISPER){
        // save the whisper TO name
        char name[22];
        memcpy(name, text, length);
        world.SendMessageToPlayer(data, (char*)name); // slightly hackish I guess
    }
}

void ChatHandler::SpawnCreature(GameClient *pClient, char* pName, uint32 display_id, uint32 npcFlags, uint32 faction_id, uint32 level)
{
    wowWData data;

    // Create the requested monster

    Character *chr = pClient->getCurrentChar();
    float x = chr->getPositionX();
    float y = chr->getPositionY();
    float z = chr->getPositionZ();
    float o = chr->getOrientation();

    Unit* pUnit = new Unit();
    UpdateMask unitMask;
    WorldServer::getSingletonPtr()->mObjectMgr.SetCreateUnitBits(unitMask);

    pUnit->Create(world.m_hiCreatureGuid++, (uint8*)pName, x, y, z, o);
    pUnit->setMapId(chr->getMapId());
    pUnit->setZone(chr->getZone());
    data.clear();
    pUnit->setUpdateValue(OBJECT_FIELD_ENTRY, world.addCreatureName((uint8*)pUnit->getCreatureName()));
    pUnit->setUpdateFloatValue(OBJECT_FIELD_SCALE_X, 1.0f);    
    pUnit->setUpdateValue(UNIT_FIELD_DISPLAYID, display_id);
    pUnit->setUpdateValue(UNIT_NPC_FLAGS , npcFlags);
    pUnit->setUpdateValue(UNIT_FIELD_FACTIONTEMPLATE , faction_id);
    pUnit->setUpdateValue(UNIT_FIELD_HEALTH, 100 + 30*level);
    pUnit->setUpdateValue(UNIT_FIELD_MAXHEALTH, 100 + 30*level);
    pUnit->setUpdateValue(UNIT_FIELD_LEVEL , level);

    pUnit->setUpdateFloatValue(UNIT_FIELD_COMBATREACH , 1.5f);
    pUnit->setUpdateFloatValue(UNIT_FIELD_MAXDAMAGE ,  5.0f);
    pUnit->setUpdateFloatValue(UNIT_FIELD_MINDAMAGE , 8.0f);
    pUnit->setUpdateValue(UNIT_FIELD_BASEATTACKTIME, 1900);
    pUnit->setUpdateValue(UNIT_FIELD_BASEATTACKTIME+1, 2000);
    pUnit->setUpdateFloatValue(UNIT_FIELD_BOUNDINGRADIUS, 2.0f);

    pUnit->CreateObject(&unitMask, &data, 0);

    // add to the world list of creatures
    WPAssert( pUnit->getGUID() != 0 );
    world.mCreatures[pUnit->getGUID()] = pUnit;

    // send create message to everyone
    world.SendGlobalMessage(&data);

    DatabaseInterface *dbi = Database::getSingleton( ).createDatabaseInterface( );
    dbi->saveCreature(pUnit);                   
    Database::getSingleton( ).removeDatabaseInterface(dbi);
}

void ChatHandler::smsg_NewWorld(GameClient *pClient, uint8 c, float x, float y, float z)
{
    wowWData data;

    // Build a NEW WORLD packet
    data.clear();
    data.Initialise(20, SMSG_NEW_WORLD);
    data << (uint32)c << (float)x << (float)y << (float)z << (float)0.0f;
    pClient->SendMsg( &data );

    // Destroy this client's player from all clients (including self)
    uint32 guid = pClient->getCurrentChar()->getGUID();
    data.clear();
    data.Initialise(8, SMSG_DESTROY_OBJECT);
    data << (uint32)guid << (uint8)0x00 << (uint8)0x00 << (uint8)0x00 << (uint8)0x00;
    pClient->SendMsg(&data);
    pClient->getCurrentChar()->setMapId(c);

    std::map< uint32, Unit*> creatures = world.getCreatureMap();
    for( std::map< uint32, Unit*>::iterator i = creatures.begin( ); i != creatures.end( ); ++ i ) {
        uint32 guid = i->second->getGUID();
        data.clear();
        data.Initialise(8, SMSG_DESTROY_OBJECT);
        data << (uint32)guid << i->second->getGUIDHigh();
        pClient->SendMsg(&data);
    }

    pClient->getCurrentChar()->setPosition(x,y,z,0,true);
}

void ChatHandler::MovePlayer(GameClient *pClient, float x, float y, float z)
{
    wowWData data; 

    //Output new position to the console
    uint8 txtBuffer[512];
    sprintf((char*)txtBuffer,"WORLD: Moved player to (%f, %f, %f)",x,y,z );
    Log::getSingleton( ).outString( (char*)txtBuffer );

    sprintf((char*)txtBuffer,"You have been moved to (%f, %f, %f)",x,y,z );
    FillMessageData(&data, 0x09, pClient, txtBuffer);
    pClient->SendMsg( &data );

    ////////////////////////////////////////
    //Set the new position of the character
    Character *chr = pClient->getCurrentChar();

    //Send new position to client via MSG_MOVE_TELEPORT_ACK
    chr->TeleportAck(&data, x,y,z);
    pClient->SendMsg(&data);

    //////////////////////////////////
    //Now send new position of this player to all clients using MSG_MOVE_HEARTBEAT
    chr->BuildHeartBeat(&data);
    world.SendGlobalMessage(&data, pClient);
}