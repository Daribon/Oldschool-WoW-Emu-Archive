/////////////////////////////////////////////////
//  Admin Chat Commands
//

#include "ChatHandler.h"
#include "NetworkInterface.h"
#include "GameClient.h"
#include "WorldServer.h"
#include "Character.h"
#include "Opcodes.h"
#include "Database.h"
#include "GameObject.h"

#define world WorldServer::getSingleton()

int ChatHandler::ParseLvl2Commands(uint8* textCompare, uint16 text_length)
{
    GameClient *pClient = m_pClient;
    wowWData data;

    if(strncmp((char*)textCompare,"@help",5)==0)
    {
        int arraysize=9; //Numbers of lines of text in the adminMessage belove
 		uint8 adminMessage[][250] = {
 			"Team Python Game Moderator commands::",
 			"@gold      Gives you gold.",
 			"@object    Creates a gameobject.",
 			"@hp        Alters your HP.",
 			"@mana      Alters your Mana.",
 			"@speed     Modifies your speed.  VALUES ABOVE 50 WILL MAKE CHARACTER UNPLAYABLE!",
 			"@aura      Aura test - Might crash you!",
 			"@morph     Changes your model into another model, Will crash you!",
 			"@die       Death world test...might make char unplayable!"
 		};
 		for (int size=0;size <= arraysize-1;size++ )
 		{
 			uint8 buf[256];
 			sprintf((char*)buf,"%s	",  adminMessage[size]);
 			FillMessageData(&data, 0x09, pClient, buf);
 			pClient->SendMsg( &data );
 		}
 		return 1;
    }

    else if(strncmp((char*)textCompare, "@object ", 7)==0)
    {
        strtok((char*)textCompare, " ");
        char* pObjId = strtok(NULL, " ");
        if (!pObjId){
            return 1;
        }
        
        if (pObjId[1]=='x'){
            uint8 syntaxError[]= "No Hex 'round here homeboi!";
            FillMessageData(&data, 0x09, pClient, syntaxError);
            pClient->SendMsg( &data );
            return 1;
        }

        uint32 display_id = atoi(pObjId);

        Character *chr = pClient->getCurrentChar();
        float x = chr->getPositionX();
        float y = chr->getPositionY();
        float z = chr->getPositionZ();
        float o = chr->getOrientation();

        GameObject* pGO = new GameObject();
        
        // uint32 guidlow, uint16 display_id, uint8 state, uint8 scale, uint16 type, uint16 faction,  float x, float y, float z, float ang
        pGO->Create(world.m_hiGoGuid++, display_id, 1, 1, 33, 1, x, y, z, o );
        pGO->CreateObject( 0, pClient );

        delete [] textCompare;
        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    //  Alter your HP
    //  @hp <currhp> <maxhp>
    else if (strncmp((char*)textCompare, "@hp ", 4)==0) 
    {
        //change level of char
        strtok((char*)textCompare, " ");
        char* pHp = strtok(NULL, " ");
        if (!pHp) return 1;

        char* pHpMax = strtok(NULL, " ");
        if (!pHpMax) return 1;

        uint32 hpm = atoi(pHpMax);
        uint32 hp = atoi(pHp);
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_MAXHEALTH, hpm );
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_HEALTH, hp );
        return 1;
    }

    else if (strncmp((char*)textCompare, "@mana ", 6)==0) 
    {
        //change level of char
        strtok((char*)textCompare, " ");
        char* pLvl = strtok(NULL, " ");
        if (!pLvl)  return 1;

        uint32 lvl = atoi(pLvl);
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_LEVEL, lvl );
        return 1;
    }

    else if (strncmp((char*)textCompare,"@speed ",7)==0)
    {
        strtok((char*)textCompare, " ");
        char* pSpeed = strtok(NULL, " ");
        if( !pSpeed ) {
            return 1;
        }
        float mspeed = atof(pSpeed);
        data.Initialise( 12, SMSG_FORCE_SPEED_CHANGE );
        data << pClient->getCurrentChar( )->getUpdateValue( OBJECT_FIELD_GUID );
        data << pClient->getCurrentChar( )->getUpdateValue( OBJECT_FIELD_GUID + 1 );
        data << mspeed;
        pClient->getCurrentChar( )->SendMessageToSet( &data, true );
        return 1;
    }

    else if(strncmp((char*)textCompare,"@animfreq ",10)==0)
    {
        strtok((char*)textCompare, " ");
        char* pAnimId = strtok(NULL, " ");
        if (!pAnimId){
            return 1;
        }

        char* pFreq = strtok(NULL, " ");
        if (!pFreq){
            return 1;
        }

        uint32 anim_id = atoi(pAnimId);
        float freq = (float)atof(pFreq);

        uint32 selection = pClient->getCurrentChar( )->getSelection( );

        Unit * charselection = WorldServer::getSingleton( ).getCreatureMap( )[ selection ];
        if( charselection != 0 )
            charselection->setAnimFrequency( anim_id, freq );

        return 1;
    }

    else if(strncmp((char*)textCompare,"@anim ",5)==0)
    {
        strtok((char*)textCompare, " ");
        char* pAnimId = strtok(NULL, " ");
        if (!pAnimId){
            return 1;
        }
        uint32 anim_id = atoi(pAnimId);

        data.Initialise(12, SMSG_EMOTE);
        data << anim_id << pClient->getCurrentChar( )->getGUID( ) << uint32( 0 );
        pClient->getCurrentChar()->SendMessageToSet(&data, true);

        return 1;
    }

    else if(strncmp((char*)textCompare,"@standstate ",12)==0)
    {
        strtok((char*)textCompare, " ");
        char* pAnimId = strtok(NULL, " ");
        if (!pAnimId){
            return 1;
        }
        uint32 anim_id = atoi(pAnimId);
        pClient->getCurrentChar( )->setUpdateValue( UNIT_NPC_EMOTESTATE , anim_id );

        return 1;
    }


    else if(strncmp((char*)textCompare,"@itemmove ",10)==0)
    {
        uint8 srcslot, destslot;
        strtok((char*)textCompare, " ");

        char* pParam1 = strtok(NULL, " ");
        if (!pParam1){
            return 1;
        }

        char* pParam2 = strtok(NULL, " ");
        if (!pParam2){
            return 1;
        }
        srcslot = (uint8)atoi(pParam1);
        destslot = (uint8)atoi(pParam2);

        pClient->getCurrentChar()->SwapItemInSlot((int)srcslot, (int)destslot);
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD  + (destslot*2), pClient->getCurrentChar()->getGuidBySlot(destslot) );
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD  + (destslot*2)+1, pClient->getCurrentChar()->getGuidBySlot(destslot) == 0 ? 0 : 0x00000040 );
        
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD  + (srcslot*2), pClient->getCurrentChar()->getGuidBySlot(srcslot) );
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD  + (srcslot*2)+1, pClient->getCurrentChar()->getGuidBySlot(srcslot) == 0 ? 0 : 0x00000040 );

        return 1;
    }

    else if(strncmp((char*)textCompare,"@die",4)==0)
    {
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_HEALTH, 0 );
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_BYTES_2, 0x10 );
        pClient->getCurrentChar( )->setUpdateMaskBit( UNIT_FIELD_MAXHEALTH );
        pClient->getCurrentChar()->setDeathState(JUST_DIED);

        return 1;
    }
    else if(strncmp((char*)textCompare,".@gold",5)==0)
    {
        
        strtok((char*)textCompare, " ");
        char* pGold = strtok(NULL, " ");
        if (!pGold){
            return 1;
        }

        uint32 gold = atoi(pGold);
        uint32 player_gold = pClient->getCurrentChar( )->getUpdateValue( PLAYER_FIELD_COINAGE );
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_COINAGE, player_gold+gold );

        return 1;
    }
    else if(strncmp((char*)textCompare,"@morph ",6)==0)
    {
        strtok((char*)textCompare, " ");
        char* pDisplayId = strtok(NULL, " ");
        if (!pDisplayId){
            return 1;
        }

        uint16 display_id = atoi(pDisplayId);

        // build mask
        UpdateMask updateMask;
        updateMask.setCount(PLAYER_BLOCKS);
        updateMask.setBit(UNIT_FIELD_DISPLAYID );

        pClient->getCurrentChar()->setUpdateValue(UNIT_FIELD_DISPLAYID, display_id);
        pClient->getCurrentChar()->UpdateObject( );
        pClient->getCurrentChar()->SendMessageToSet(&data, true);

        return 1;
    }
    else if(strncmp((char*)textCompare,"@aura ",6)==0)
    {
        strtok((char*)textCompare, " ");
        char* pAuraId = strtok(NULL, " ");
        if (!pAuraId){
            return 1;
        }

        uint32 aura_id = atoi(pAuraId);

        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_AURA, aura_id );
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_AURAFLAGS, 0x0000000d );
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_AURA+32, aura_id );
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_AURALEVELS+8, 0xeeeeee00 );
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_AURAAPPLICATIONS+8, 0xeeeeee00 );
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_AURAFLAGS+4, 0x0000000d );
        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_AURASTATE, 0x00000002 );
        pClient->getCurrentChar()->UpdateObject( );
        return 1;
    }


    return 0;
}


       /*
            
  else if(strncmp((char*)textCompare,"@channeltest",12)==0)
                {
                    //unsigned char pdata[12] = "Python Chat";
                    data.Initialise(28, SMSG_CHANNEL_NOTIFY);
                    data << uint8(1);
                    data << uint32(0x64617254);
                    data << uint32(0x202d2065);
                    data << uint32(0x206e7544);
                    data << uint32(0x6f726f4d);
                    data << uint16(0x6867);
                    data << uint8(0);
                    data << pClient->getCurrentChar( )->getGUID( ) << uint32( 0 );
                    pClient->SendMsg( &data );

                    delete [] textCompare;
                    return;
                }
                
  else if(strncmp((char*)textCompare,"@effect ",7)==0)
                {
if ((pClient->getCurrentChar( )->getSelection( ) == 0) || (pClient->getCurrentChar( )->getSelection( ) == NULL)) {
delete [] textCompare;
return;
}
                    uint32 tguid = pClient->getCurrentChar( )->getSelection( );
                    if(!tguid)
                    {
                        delete [] textCompare;
                        return;
                    }
                    if(tguid==pClient->getCurrentChar()->getGUID())
                    {
                        delete [] textCompare;
                        return;
                    }
                    strtok((char*)textCompare, " ");
                    char* pSpell = strtok(NULL, " ");
                    if (!pSpell){
                        delete [] textCompare;
                        return;
                    }
                    uint32 Spell = atoi(pSpell);
    
    data.clear();
    data.Initialise( 12, SMSG_PLAY_SPELL_VISUAL );
    data << tguid << world.mCreatures[tguid]->getGUIDHigh() << Spell;
//                    world.SendZoneMessage( &data , pClient , 1);
                    pClient->getCurrentChar()->SendMessageToSet(&data, true);

                    delete [] textCompare;
                    return;
    }
  */