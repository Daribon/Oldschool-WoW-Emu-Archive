#include "Character.h"
#include "UpdateMask.h"
#include "NetworkInterface.h"
#include "Quest.h"
#include "Opcodes.h"
#include "WorldServer.h"
#include "Timer.h"


#define world WorldServer::getSingleton()

Character::Character ( ): Unit()
{ 
    m_objectType |= TYPE_PLAYER;
    m_objectTypeId = 4;
    m_afk = 0;
    m_curTarget[ 0 ] = m_curTarget[ 1 ] = 0;
    m_curSelection[ 0 ] = m_curSelection[ 1 ] = 0;
    m_updateValues[ OBJECT_FIELD_TYPE ] = m_objectType;
	m_lootGuid[1] = 0;
	m_lootGuid[0] = 0;
    m_guildId = 0;
    m_petInfoId = 0;
    m_petLevel = 0;
    m_petFamilyId = 0;
    
    memset(m_items, 0, 8*39);

    // Init inventory slots...should they be set to 0?  Better than not initializing them at all I guess
    for (int i = 0; i < 20; i++) {
        m_inventory[i].displayId = 0;
        m_inventory[i].itemType = 0;
    }

    m_lastHpRegen = 0;
    m_lastManaRegen = 0;
}


Character::~Character ( ) 
{ 

}


//====================================================================
//	Create
//	params: p_newChar
//	desc:	data form client to create a new character
//====================================================================
void Character::Create( uint32 guidlow, wowWData& data )//( uint8 * data, uint16 length )
{
    int i=0;
    uint8 race,class_,gender,skin,face,hairStyle,hairColor,facialHair,outfitId;
    uint16 displayId=0;
    uint8 stat0, stat1, stat2, stat3, stat4;
    uint32 baseattacktime[2];

    // Stats
    uint32 health=0, mana=0, attackpower, rage=0;
    float mindmg, maxdmg;

    Unit::Create(guidlow);
    m_guid[1] = 0;

    for (i = 0; i < 39; i++) {
        m_items[i].guid = 0;
        m_items[i].itemid = 0;
    }

    // unpack data into member variables
    data >> (char *)m_name;
    data >> race >> class_ >> gender >> skin >> face;
    data >> hairStyle >> hairColor >> facialHair >> outfitId;

    //////////  Constant for everyone  ////////////////
/* Starting Locs
Human: 0, -8949.95, -132.493, 83.5312
Orc: 1, -618.518, -4251.67, 38.718
Dwarf: 0, -6240.32, 331.033, 382.758
Night Elf: 1, 10311.3, 832.463, 1326.41
Undead: 0, 1676.35, 1677.45, 121.67
Tauren: 1, -2917.58, -257.98, 52.9968
Gnome: See Dwarf
Troll: See Orc
*/
    baseattacktime[0] = 2000;
    baseattacktime[1] = 2000;

    // starting stats from: http://wowvault.ign.com/?dir=characters&content=stats
    // Determine starting stats, display ID by race
    if (race == 1)  // Human
    {
        m_mapId = 0;
        m_zoneId = 12;
        m_positionX = -8949.95f;
        m_positionY = -132.493f;
        m_positionZ = 83.5312f;
        stat0 = 20;
        stat1 = 20;
        stat2 = 20;
        stat3 = 20;
        stat4 = 20;
        displayId = 49 + gender;
    }
    else if (race == 2) // orc
    {
        m_mapId = 1;
        m_zoneId = 14;
        m_positionX = -618.518f;
        m_positionY = -4251.67f;
        m_positionZ = 38.718f;
        stat0 = 23;
        stat1 = 17;
        stat2 = 22;
        stat3 = 17;
        stat4 = 21;
        displayId = 51 + gender;
    }
    else if (race == 3) // dwarf
    {
        m_mapId = 0;
        m_zoneId = 1;
        m_positionX = -6240.32f;
        m_positionY = 331.033f;
        m_positionZ = 382.758f;
        stat0 = 22;
        stat1 = 17;
        stat2 = 23;
        stat3 = 19;
        stat4 = 19;
        displayId = 53 + gender;
    }
    else if (race == 4) // night elf
    {
        m_mapId = 1;
        m_zoneId = 141;
        m_positionX = 10311.3f;
        m_positionY = 832.463f;
        m_positionZ = 1326.41f;
        stat0 = 16;
        stat1 = 25;
        stat2 = 19;
        stat3 = 20;
        stat4 = 20;
        displayId = 55 + gender;
    }
    else if (race == 5) // undead
    {
        m_mapId = 0;
        m_zoneId = 85;
        m_positionX = 1676.35f;
        m_positionY = 1677.45f;
        m_positionZ = 121.67f;
        stat0 = 19;
        stat1 = 18;
        stat2 = 21;
        stat3 = 17;
        stat4 = 25;
        displayId = 57 + gender;
    }
    else if (race == 6) // tauren
    {
        m_mapId = 1;
        m_zoneId = 215;
        m_positionX = -2917.58f;
        m_positionY = -257.98f;
        m_positionZ = 52.9968f;
        stat0 = 25;
        stat1 = 16;
        stat2 = 22;
        stat3 = 16;
        stat4 = 21;
        displayId = 59 + gender;
    }   
    else if (race == 7) // gnome
    {
        m_mapId = 0;
        m_zoneId = 1;
        m_positionX = -6240.32f;
        m_positionY = 331.033f;
        m_positionZ = 382.758f;
        stat0 = 15;
        stat1 = 23;
        stat2 = 19;
        stat3 = 23;
        stat4 = 20;
        displayId = 1563 + gender;
    }
    else if (race == 8)     // troll
    {
        m_mapId = 1;
        m_zoneId = 14;
        m_positionX = -618.518f;
        m_positionY = -4251.67f;
        m_positionZ = 38.718f;
        stat0 = 20;
        stat1 = 22;
        stat2 = 21;
        stat3 = 16;
        stat4 = 21;
        displayId = 1478 + gender;
    }

/*
LEFT SIDE
Head		0
Neck		1
Shoulders	2
Back		14
Chest		4
Shirt		3
Tabard		18
Wrists		8

RIGHT SIDE
Hands		9
Waist		5
Legs		6
Feet		7
Finger A	10
Finger B	11
Trinket A	12
Trinket B	13

WIELDED
Main hand	15
Offhand		16
Ranged		17
/**/

// slot 19 is invalid.

    // Adjust stats and items based on class
    // Starting stats from: http://wowvault.ign.com/?dir=characters&content=stats
    // Starting items from: www.gotwow.net -- M!lksJake
    if (class_ == WARRIOR)    // warrior
    {
        //abilities
        addSpell(0x19CB, 0);   //attack
        addSpell(2457, 0);     //battle stance
        addSpell(107, 0);      //block
        addSpell(78, 0);       //Strike (Rank 1)
        addSpell(81, 0);       //dodge

	    world.m_hiItemGuid++;	 
        
        if (race == 1) // Human
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 60;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
        }
        if (race == 1) // Human
        {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);      // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);      // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);      // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);   // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);     // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 2070);   // Darnassian Bleu
        }
        if (race == 2) // Orc
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 80;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
	}
	if (race == 2) // Orc
        {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);      // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);      // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);      // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);   // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);     // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        }
        if (race == 3) // Dwarf
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 90;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
        }
       	if (race == 3) // Dwarf
        {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);    // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);    // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);    // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);  // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);  // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);   // tough hunk of bread
        }
        if (race == 4) // Night Elf
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 50;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
        }
       	if (race == 4) // Night Elf
        {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);    // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);    // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);    // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);  // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);  // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);   // tough hunk of bread
        }
        if (race == 5) // Undead
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 70;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
        }
       	if (race == 5) // Undead
        {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);    // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);    // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);    // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);  // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);  // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 4604);    // forest mushroom cap
        }
        if (race == 6) // Tauren
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 80;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
        }
       	if (race == 6) // Tauren
        {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);      // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);      // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);      // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);   // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);     // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);   // tough hunk of bread
        }
        if (race == 7) // Gnome
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 50;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
        }
       	if (race == 7) // Gnome
        {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);      // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);      // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);    // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);  // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);  // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);   // tough hunk of bread
        }
        if (race == 8) // Troll
        {
        // +3 strength
        // +2 Stamina
        stat0 += 3;
        stat2 += 2;

        health      = 70;
        rage        = 35;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;
        //POWER TYPE: USES RAGE
    }
       	if (race == 8) // Troll
    {

	    AddItemToSlot(3, world.m_hiItemGuid++, 38);      // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);      // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);      // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);   // worn wooden shield
        AddItemToSlot(15, world.m_hiItemGuid++, 25);     // worn short sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);    // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        }
    }
    else if (class_ == PALADIN)   // Paladin
    {
        //spells
        addSpell(679, 1);     //holy strike
        addSpell(635, 2);     //holy light
        //abilities
        addSpell(0x19CB, 0);  //attack
        addSpell(107, 0);     //block
        addSpell(81, 0);      //dodge

        world.m_hiItemGuid++;	

        if (race == 1) // Human
        {
        // +2 Strenght
        // +2 Stamina
        // +1 Strenght
        stat0 += 2;
        stat2 += 2;
        stat4 += 1;

        health      = 58;
        mana        = 84;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: USES MANA
        }
	if (race == 1) // Human
        {	        
	    AddItemToSlot(3, world.m_hiItemGuid++, 45);    // squire's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 44);    // squire's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 43);    // squire's boots
        AddItemToSlot(15, world.m_hiItemGuid++, 2361);  // battleworn hammer
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 2070);    // Darnassian Bleu
        }
        if (race == 3) // Dwarfs
        {
        // +2 Strenght
        // +2 Stamina
        // +1 Strenght
        stat0 += 2;
        stat2 += 2;
        stat4 += 1;
        
        health      = 85;
        mana        = 83;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: USES MANA
        }
	if (race == 3) // Dwarfs
        {    
	    AddItemToSlot(3, world.m_hiItemGuid++, 45);    // squire's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 44);    // squire's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 43);    // squire's boots
        AddItemToSlot(15, world.m_hiItemGuid++, 2361);  // battleworn hammer
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        }
    }
    else if (class_ == HUNTER)   // Hunter
    {
        health      = 95;
        mana        = 0;
        attackpower = 16;
        mindmg      = 5.0f;
        maxdmg      = 7.0f;

	    world.m_hiItemGuid++;	    
	    AddItemToSlot(3, world.m_hiItemGuid++, 38);    // recruit's shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 39);    // recruit's pants
        AddItemToSlot(7, world.m_hiItemGuid++, 40);    // recruit's boots
        AddItemToSlot(16, world.m_hiItemGuid++, 2362);  // worn shield
        AddItemToSlot(15, world.m_hiItemGuid++, 2488);  // footman sword
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread

    }
    else if (class_ == ROGUE)   // Rogue
    {
        //abilities
        addSpell(0x19CB, 0); //attack
        addSpell(1752, 1);      //sinister strike
        addSpell(2764, 2);      //throw
        addSpell(2098, 0);      //eviscrate
        addSpell(81, 0);        //dodge
        
	    world.m_hiItemGuid++;	    

        if (race == 1) // Human
        {
        // +2 Strenght
        stat0 += 2;
        
        health      = 56;
        mana        = 84;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: USES ENERGY
        }
       	if (race == 1) // Human
        {
	    AddItemToSlot(3, world.m_hiItemGuid++, 49);       // Footpad�s shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 48);       // Footpad�s Pants
        AddItemToSlot(7, world.m_hiItemGuid++, 47);       // Footpad�s shoes
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // Worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(23, world.m_hiItemGuid++, 2070);    // Darnassian Bleu
        }
        if (race == 2) // Orc
        {
        // +2 Strenght
        stat0 += 2;
        
        health      = 72;
        mana        = 83;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: USES ENERGY
        }
       	if (race == 2) // Orc
        {
	    AddItemToSlot(3, world.m_hiItemGuid++, 49);    // Footpad�s shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 48);    // Footpad�s Pants
        AddItemToSlot(7, world.m_hiItemGuid++, 47);    // Footpad�s shoes
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // Worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        }
        if (race == 3) // Dwarf
        {
        // +2 Strenght
        stat0 += 2;
        
        health      = 80;
        mana        = 84;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: ENERGY
        }
       	if (race == 3) // Dwarf
        {
	    AddItemToSlot(3, world.m_hiItemGuid++, 49);    // Footpad�s shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 48);    // Footpad�s Pants
        AddItemToSlot(7, world.m_hiItemGuid++, 47);    // Footpad�s shoes
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // Worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        }
        if (race == 4) // Night Elf
        {
        // +2 Strenght
        stat0 += 2;
        
        health      = 48;
        mana        = 83;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: USES ENERGY
        }
	if (race == 4) // Night Elf
        {
	    AddItemToSlot(3, world.m_hiItemGuid++, 49);    // Footpad�s shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 48);    // Footpad�s Pants
        AddItemToSlot(7, world.m_hiItemGuid++, 47);    // Footpad�s shoes
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // Worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        }
        if (race == 5) // Undead
        {
        // +2 Strenght
        stat0 += 2;
        
        health      = 64;
        mana        = 83;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: USES ENERGY
        }
	if (race == 5) // Undead
        {
	    AddItemToSlot(3, world.m_hiItemGuid++, 49);    // Footpad�s shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 48);    // Footpad�s Pants
        AddItemToSlot(7, world.m_hiItemGuid++, 47);    // Footpad�s shoes
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // Worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4604);    // forest mushroom cap
        AddItemToSlot(23, world.m_hiItemGuid++, 4604);    // forest mushroom cap
        }
        if (race == 7) // Gnome
        {
        // +2 Strenght
        stat0 += 2;
        
        health      = 48;
        mana        = 84;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: ENERGY
    }
       	if (race == 7) // Gnome
    {
	    AddItemToSlot(3, world.m_hiItemGuid++, 49);       // Footpad�s shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 48);       // Footpad�s Pants
        AddItemToSlot(7, world.m_hiItemGuid++, 47);       // Footpad�s shoes
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);    // Worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        }
        if (race == 8) // Troll
        {
        // +2 Strenght
        stat0 += 2;

        health      = 64;
        mana        = 83;
        attackpower = 27;
        mindmg      = 10.59f;
        maxdmg      = 13.59f;
        baseattacktime[0] = 2900;
        baseattacktime[1] = 2000;
        //POWER TYPE: USES ENERGY
        }
        if (race == 8) // Troll
        {
	    AddItemToSlot(3, world.m_hiItemGuid++, 49);       // Footpad�s shirt
        AddItemToSlot(6, world.m_hiItemGuid++, 48);       // Footpad�s Pants
        AddItemToSlot(7, world.m_hiItemGuid++, 47);       // Footpad�s shoes
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);    // Worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        }

    }
    else if (class_ == PRIEST)   // Priest
    {
        //spells
        addSpell(585, 1); // holy smite 
        addSpell(2050, 2);       // lesser heal
        //abilities
        addSpell(0x19CB, 0); //attack
        addSpell(5019, 0);       // shoot wands
        addSpell(81, 0);         //dodge
        

        if (race == 1) // Human
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat3 += 2;

        health      = 52;
        mana        = 150;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: USES MANA
        }
       	if (race == 1) // Human
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);     // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);     // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6119);     // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);     // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 36);     // worn mace
        AddItemToSlot(23, world.m_hiItemGuid++, 2070);    // Darnassian Bleu
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 8) // Troll
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat3 += 2;

        health      = 58;
        mana        = 128;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: USES MANA
        }
       	if (race == 8) // Troll
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);     // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);     // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6119);     // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);     // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 36);     // worn mace
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 3) // Dwarf
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat3 += 2;

        health      = 76;
        mana        = 130;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: USES MANA
        }
       	if (race == 3) // Dwarf
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);     // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);     // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6119);     // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);     // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 36);     // worn mace
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 4) // Night Elf
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat3 += 2;

        health      = 45;
        mana        = 160;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: USES MANA
        }
	if (race == 4) // Night Elf
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);     // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);     // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6119);     // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);     // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 36);     // worn mace
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 5) // Undead
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat3 += 2;

        health      = 58;
        mana        = 129;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: USES MANA
        }
	if (race == 5) // Undead
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);     // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);     // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6119);   // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);     // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 36);     // worn mace
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 4604);    // forest mushroom cap
        }
    }
    else if (class_ == SHAMAN)   // Shaman
    {
        //spells
        addSpell(403, 1);    // lightning bolt
        addSpell(331, 2);       // healing wave
        //abilities
        addSpell(0x19CB, 0); //attack
        addSpell(81, 0);        //dodge
        addSpell(107, 0);       //block


	    world.m_hiItemGuid++;

        if (race == 2) // Orc
        {
        // +1 Strenght
        // +1 Stamina
        // +2 Intellect
        // +1 Spirit
        stat0 += 1;
        stat2 += 1;
        stat3 += 2;
        stat4 += 1;

        health      = 72;
        mana        = 68;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
       	if (race == 2) // Orc
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);       // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);       // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6119);     // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);       // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 36);      // worn mace
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 6) // Tauren
        {
        // +1 Strenght
        // +1 Stamina
        // +2 Intellect
        // +1 Spirit
        stat0 += 1;
        stat2 += 1;
        stat3 += 2;
        stat4 += 1;

        health      = 72;
        mana        = 67;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
       	if (race == 6) // Tauren
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);     // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);     // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6144);   // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);     // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 35);     // bent staff
        AddItemToSlot(15, world.m_hiItemGuid++, 36);      // worn mace
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
    }
        if (race == 8) // Troll
    {
        // +1 Strenght
        // +1 Stamina
        // +2 Intellect
        // +1 Spirit
        stat0 += 1;
        stat2 += 1;
        stat3 += 2; 
        stat4 += 1;
        
        health      = 64;
        mana        = 67;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
	if (race == 8) // Troll
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 51);       // neophytes's boots
        AddItemToSlot(6, world.m_hiItemGuid++, 52);       // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6144);     // neophyte's robe
        AddItemToSlot(3, world.m_hiItemGuid++, 53);       // neophyte's shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 35);      // bent staff
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
    }
    else if (class_ == MAGE)   // mage
    {
        //spells
        addSpell(0x0085, 1);    // firebolt
        addSpell(168, 2);      // frost armor
        //abilities
        addSpell(0x19CB, 0); //attack
        addSpell(5019, 0);     //shoot wand
        addSpell(81, 0);       //dodge


	    world.m_hiItemGuid++;	

        if (race == 1) //human
        {
        // +2 Intellect
        // +3 Spirit
        stat3 += 2;
        stat4 += 3;
          
        health      = 52;
        mana        = 150;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
       	if (race == 1) // Human
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 55);     // Apprentice�s Boots
        AddItemToSlot(6, world.m_hiItemGuid++, 1395);     // Apprentice�s Pants
        AddItemToSlot(4, world.m_hiItemGuid++, 56);       // Apprentice�s Robe
        AddItemToSlot(3, world.m_hiItemGuid++, 6096);     // Apprentice�s Shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 35);      // bent staff
        AddItemToSlot(23, world.m_hiItemGuid++, 2070);    // Darnassian Bleu
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 8) // Troll
        {
        // +2 Intellect
        // +3 Spirit
        stat3 += 2;
        stat4 += 3;
         
        health      = 58;
        mana        = 128;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
       	if (race == 8) // Troll
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 55);     // Apprentice�s Boots
        AddItemToSlot(6, world.m_hiItemGuid++, 1395);     // Apprentice�s Pants
        AddItemToSlot(4, world.m_hiItemGuid++, 56);       // Apprentice�s Robe
        AddItemToSlot(3, world.m_hiItemGuid++, 6096);     // Apprentice�s Shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 35);     // bent staff
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 3) // Dwarf
        {
        // +2 Intellect
        // +3 Spirit
        stat3 += 2;
        stat4 += 3;
         
        health      = 70;
        mana        = 140;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
       	if (race == 3) // Dwarf
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 55);     // Apprentice�s Boots
        AddItemToSlot(6, world.m_hiItemGuid++, 1395);     // Apprentice�s Pants
        AddItemToSlot(4, world.m_hiItemGuid++, 56);   // Apprentice�s Robe
        AddItemToSlot(3, world.m_hiItemGuid++, 6096);     // Apprentice�s Shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 35);     // bent staff
        AddItemToSlot(23, world.m_hiItemGuid++, 2070);    // Darnassian Bleu
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 5) // Undead
        {
        // +2 Intellect
        // +3 Spirit
        stat3 += 2;
        stat4 += 3;
         
        health      = 58;
        mana        = 129;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
	if (race == 5) // Undead
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 55);     // Apprentice�s Boots
        AddItemToSlot(6, world.m_hiItemGuid++, 1395);     // Apprentice�s Pants
        AddItemToSlot(4, world.m_hiItemGuid++, 56);       // Apprentice�s Robe
        AddItemToSlot(3, world.m_hiItemGuid++, 6096);     // Apprentice�s Shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 35);     // bent staff
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 4604);    // forest mushroom cap
        }
        if (race == 7) // Gnome
        {
        // +2 Intellect
        // +3 Spirit
        stat3 += 2;
        stat4 += 3;
         
        health      = 51;
        mana        = 180;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        }
       	if (race == 7) // Gnome
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 55);     // Apprentice�s Boots
        AddItemToSlot(6, world.m_hiItemGuid++, 1395);     // Apprentice�s Pants
        AddItemToSlot(4, world.m_hiItemGuid++, 56);   // Apprentice�s Robe
        AddItemToSlot(3, world.m_hiItemGuid++, 6096);     // Apprentice�s Shirt
        AddItemToSlot(15, world.m_hiItemGuid++, 35);     // bent staff
        AddItemToSlot(24, world.m_hiItemGuid++, 159);     // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        }
    }
    else if (class_ == WARLOCK)   // Warlock
    {
        //spells
        addSpell(686, 1);      //shadow bolt
        addSpell(687, 2);      //demon skin
        //abilities
        addSpell(0x19CB, 0);   //attack
        addSpell(5019, 0);     // shoot wands
        addSpell(81, 0);       //dodge

	    world.m_hiItemGuid++;	

        if (race == 1) //human
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat4 += 2;
        
        health      = 54;
        mana        = 130;
        attackpower = 20;
        mindmg      = 3.28f;
        maxdmg      = 5.28f;
        baseattacktime[0] = 1600;
        baseattacktime[1] = 2000;
        //POWER TYPE: MANA
        }
       	if (race == 1) // Human
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 59);     // acolyte's shoes
        AddItemToSlot(6, world.m_hiItemGuid++, 1396);   // acolyte's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6129);     // acolyte's robe
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        AddItemToSlot(25, world.m_hiItemGuid++, 159);     // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 2070);    // Darnassian Bleu
        }
        if (race == 2) // Orc
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat4 += 2;
        
        health      = 68;
        mana        = 109;
        attackpower = 20;
        mindmg      = 3.28f;
        maxdmg      = 5.28f;
        baseattacktime[0] = 1600;
        baseattacktime[1] = 2000;
        //POWER TYPE: MANA
        }
       	if (race == 2) // Orc
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 59);     // acolyte's shoes
        AddItemToSlot(6, world.m_hiItemGuid++, 1396);   // acolyte's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6129);     // acolyte's robe
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        AddItemToSlot(25, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 7) // Gnome
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat4 += 2;
        
        health      = 47;
        mana        = 160;
        attackpower = 20;
        mindmg      = 3.28f;
        maxdmg      = 5.28f;
        baseattacktime[0] = 1600;
        baseattacktime[1] = 2000;
        //POWER TYPE: MANA
        }
       	if (race == 7) // Gnome
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 59);     // acolyte's shoes
        AddItemToSlot(6, world.m_hiItemGuid++, 1396);   // acolyte's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6129);     // acolyte's robe
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);    // tough hunk of bread
        AddItemToSlot(25, world.m_hiItemGuid++, 159);     // refreshing spring water
        }
        if (race == 5) // Undead
        {
        // +1 Stamina
        // +2 Intellect
        // +2 Spirit
        stat2 += 1;
        stat3 += 2;
        stat4 += 2;
        
        health      = 61;
        mana        = 109;
        attackpower = 20;
        mindmg      = 3.28f;
        maxdmg      = 5.28f;
        baseattacktime[0] = 1600;
        baseattacktime[1] = 2000;
        //POWER TYPE: MANA
        }
	if (race == 5) // Undead
        {
	    AddItemToSlot(7, world.m_hiItemGuid++, 59);     // acolyte's shoes
        AddItemToSlot(6, world.m_hiItemGuid++, 1396);   // acolyte's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6129);     // acolyte's robe
        AddItemToSlot(15, world.m_hiItemGuid++, 2092);  // worn dagger
        AddItemToSlot(23, world.m_hiItemGuid++, 117);     // tough jerky
        AddItemToSlot(25, world.m_hiItemGuid++, 159);     // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 4604);    // forest mushroom cap
        }	    
    }
    else if (class_ == DRUID)  // druid
    {
        //spells
        addSpell(5176, 1);    // wrath
        addSpell(5185, 2);    // healing touch
        addSpell(1126, 1);    // Mark of the Wild
        //abilities
        addSpell(0x19CB, 0); //attack
        addSpell(81, 0);      //dodge

	    world.m_hiItemGuid++;	    
     
        if (race == 4) // Night Elf
        {
        // +1 Strenght
        // +1 Stamina
        // +1 Agility
        // +1 Intellect
        // +1 Spirit
        stat0 += 1;
        stat1 += 1;
        stat2 += 1;
        stat3 += 1;
        stat4 += 1;
        
        health      = 46;
        mana        = 105;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        //NOTE: USES RAGE IN BEAR FORM
        }
	if (race == 4) // Night Elf
        {
        AddItemToSlot(6, world.m_hiItemGuid++, 3661);    // Novice's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6123);    // Novice's Robe
        AddItemToSlot(15, world.m_hiItemGuid++, 6124);   // Hand crafted staff
        AddItemToSlot(24, world.m_hiItemGuid++, 159);    // Refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);   // Tough hunk of bread
        }
        if (race == 6) // Tauren
        {
        // +1 Strenght
        // +1 Stamina
        // +1 Agility
        // +1 Intellect
        // +1 Spirit
        stat0 += 1;
        stat1 += 1;
        stat2 += 1;
        stat3 += 1;
        stat4 += 1;
        
        health      = 68;
        mana        = 84;
        attackpower = 8;
        mindmg      = 2.0f;
        maxdmg      = 4.0f;
        //POWER TYPE: MANA
        //NOTE: USES RAGE IN BEAR FORM
        }
	if (race == 6) // Tauren
        {
        AddItemToSlot(6, world.m_hiItemGuid++, 52);     // neophytes's pants
        AddItemToSlot(4, world.m_hiItemGuid++, 6123);    // Novice's Robe
        AddItemToSlot(15, world.m_hiItemGuid++, 35);     // bent staff
        AddItemToSlot(24, world.m_hiItemGuid++, 159);    // refreshing spring water
        AddItemToSlot(23, world.m_hiItemGuid++, 4540);   // tough hunk of bread
        }     
    }

    // Set Starting stats for char
    setUpdateMaskBit(OBJECT_FIELD_GUID);          
    setUpdateMaskBit(OBJECT_FIELD_TYPE);
    setUpdateFloatValue(OBJECT_FIELD_SCALE_X, 1.0f);         
    setUpdateValue(OBJECT_FIELD_PADDING, 0xeeeeeeee);
    setUpdateValue(UNIT_FIELD_HEALTH, health);   
    setUpdateValue(UNIT_FIELD_POWER1, mana );        
    setUpdateValue(UNIT_FIELD_POWER2, 1000 );
    setUpdateValue(UNIT_FIELD_POWER3, 10 );        
    setUpdateValue(UNIT_FIELD_POWER4, 100 );
    setUpdateValue(UNIT_FIELD_POWER5, 0xeeeeeeee );
    setUpdateValue(UNIT_FIELD_MAXHEALTH, health);
    setUpdateValue(UNIT_FIELD_MAXPOWER1, mana );        
    setUpdateValue(UNIT_FIELD_MAXPOWER2, 1000 );
    setUpdateValue(UNIT_FIELD_MAXPOWER3, 10 );        
    setUpdateValue(UNIT_FIELD_MAXPOWER4, 100 );
    setUpdateValue(UNIT_FIELD_LEVEL, 1 );            
    setUpdateValue(UNIT_FIELD_FACTIONTEMPLATE, 1 );
    setUpdateValue(UNIT_FIELD_BYTES_0, ( race ) + ( class_ << 8 ) + ( gender << 16 ) );          
    setUpdateValue(PLAYER_FIELD_STAT0, stat0 );
    setUpdateValue(PLAYER_FIELD_STAT1, stat1 );            
    setUpdateValue(PLAYER_FIELD_STAT2, stat2 );
    setUpdateValue(PLAYER_FIELD_STAT3, stat3 );            
    setUpdateValue(PLAYER_FIELD_STAT4, stat4 );
    setUpdateValue(PLAYER_FIELD_POSSTAT0, 0  );        
	setUpdateValue(PLAYER_FIELD_POSSTAT1, 0 );
	setUpdateValue(PLAYER_FIELD_POSSTAT2, 0 );        
	setUpdateValue(PLAYER_FIELD_POSSTAT3, 0 );
	setUpdateValue(PLAYER_FIELD_POSSTAT4, 0 );        
	setUpdateValue(PLAYER_FIELD_NEGSTAT0, 0 );        
	setUpdateValue(PLAYER_FIELD_NEGSTAT1, 0 );
	setUpdateValue(PLAYER_FIELD_NEGSTAT2, 0 );        
	setUpdateValue(PLAYER_FIELD_NEGSTAT3, 0 );
	setUpdateValue(PLAYER_FIELD_NEGSTAT4, 0 );        
    setUpdateValue(PLAYER_FIELD_COINAGE, 100  );
    setUpdateValue(UNIT_FIELD_BASEATTACKTIME, baseattacktime[0] );   
    setUpdateValue(UNIT_FIELD_BASEATTACKTIME+1, baseattacktime[1]  );
    setUpdateFloatValue(UNIT_FIELD_BOUNDINGRADIUS, 0.388999998569489f );  
    setUpdateFloatValue(UNIT_FIELD_COMBATREACH, 1.5f   );
    setUpdateValue(UNIT_FIELD_DISPLAYID, displayId  );       
    setUpdateFloatValue(UNIT_FIELD_MINDAMAGE, mindmg );
    setUpdateFloatValue(UNIT_FIELD_MAXDAMAGE, maxdmg );       
    setUpdateValue(UNIT_FIELD_FLAGS, 0x00000008 );
    setUpdateValue(PLAYER_FIELD_ATTACKPOWER, attackpower );
    setUpdateValue(PLAYER_FIELD_ATTACKPOWERMODPOS, 0 );
    setUpdateValue(PLAYER_FIELD_ATTACKPOWERMODNEG, 0 );
    setUpdateValue(PLAYER_BYTES, ((uint32)skin) | ((uint32)face << 8) | ((uint32)hairStyle << 16) | (hairColor << 24));
    setUpdateValue(PLAYER_BYTES_2, (facialHair << 8) + (01 << 24) );
    setUpdateValue(PLAYER_XP, 0 );                 
    setUpdateValue(PLAYER_NEXT_LEVEL_XP, 800);
    setUpdateValue(PLAYER_REST_STATE_EXPERIENCE, 0 );
	setUpdateValue(UNIT_FIELD_AURALEVELS , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 1 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 2 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 3 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 4 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 5 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 6 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 7 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 8 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURALEVELS + 9 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 1 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 2 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 3 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 4 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 5 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 6 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 7 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 8 , 0xeeeeeeee);
	setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + 9 , 0xeeeeeeee);

    // Init inventory slots...should they be set to 0?  Better than not initializing them at all I guess
    for (i = 0; i < 20; i++) {
        m_inventory[i].displayId = 0;
        m_inventory[i].itemType = 0;
    }

    // Not worrying about this stuff for now
    m_guildId = 0;
    m_petInfoId = 0;
    m_petLevel = 0;
    m_petFamilyId = 0;
}


void Character::Update( float p_time )
{
    if (m_state & UF_ATTACKING)
    {
        // In combat!
        if (canAttack())
        {
            Unit *pVictim = NULL;
            if (m_curSelection[1] == uint32(0)) 
            {   // player guid
                // player vs player not implemented

                // !! Bah, previously spawned creatures have guid[1] of 0
                if (world.mCreatures.find(m_curSelection[0]) != world.mCreatures.end()){
                    pVictim = world.mCreatures[m_curSelection[0]];
                }
            } 
            else if (m_curSelection[1] == 0xF0001000 || m_curSelection[1] == 0xF0003000)
            {   // monster
                if (world.mCreatures.find(m_curSelection[0]) != world.mCreatures.end()){
                    pVictim = world.mCreatures[m_curSelection[0]];
                }
            }

            if (!pVictim){
                printf("Character::Update:  No valid current selection to attack, stopping attack\n");
                clearStateFlag(UF_ATTACKING);
                world.mCombatHandler.smsg_AttackStop((Unit*)this, m_curSelection);
            }
            else
            {
                world.mCombatHandler.AttackerStateUpdate((Unit*)this, pVictim);
                setAttackTime();
            }
        }
    }
    // only regenerate if NOT in combat, and if alive
    else if (IsAlive()) 
    {
        uint32 hp       = getUpdateValue(UNIT_FIELD_HEALTH);
        uint32 max_hp   = getUpdateValue(UNIT_FIELD_MAXHEALTH);

        uint32 mp       = getUpdateValue(UNIT_FIELD_POWER1);
        uint32 max_mp   = getUpdateValue(UNIT_FIELD_MAXPOWER1);

        // Regenerate health and mana if necessary
        hp = Regen(hp, max_hp, UNIT_FIELD_HEALTH, &m_lastHpRegen);
        mp = Regen(mp, max_mp, UNIT_FIELD_POWER1, &m_lastManaRegen);
    }

   // Dead System
    if (m_deathState == JUST_DIED){     
		pClient->getCurrentChar( )->setUpdateValue( PLAYER_BYTES_2, 0x10 );
		pClient->getCurrentChar( )->setUpdateValue(UNIT_FIELD_FLAGS, 65536 );
        pClient->getCurrentChar()->setDeathState(JUST_DIED);

    }
	if (m_timeOfDeath > 0 && (uint32)time(NULL) > m_timeOfDeath + m_corpseDelay){
        m_timeOfDeath = 5000;
        m_respawnDelay = 5000;
		pClient->getCurrentChar( )->setUpdateValue(PLAYER_BYTES_2, ( 8) + (01 << 24));
		pClient->getCurrentChar( )->setUpdateValue(UNIT_FIELD_FLAGS, 0x00000008 );
		pClient->getCurrentChar()->setDeathState(ALIVE);
	}

    UpdateObject();
}

// Regenerates the regenField's curValue to the maxValue
// Right now, everything regenerates at the same rate
// A possible mod is to add another parameter, the stat regeneration is based off of (Intelligence for mana, Strength for HP)
// And build a regen rate based on that
uint32 Character::Regen(uint32 curValue, uint32 maxValue, uint16 regenField, uint32* lastRegen)
{
    if (curValue < maxValue)
    {
        uint32 regenDelay = 3;
        if ((getUpdateValue(UNIT_FIELD_BYTES_1) & 0xff) == 1) {// sitting
            regenDelay = 1;
        }

        // check if it's time to regen health
        if ((uint32)time(NULL) > *lastRegen + regenDelay)
        {
            *lastRegen = (time(NULL));
            curValue+=2;
            if (curValue > maxValue) curValue = maxValue;
            setUpdateValue(regenField, curValue);
            printf("Regenerating...\n");
        }
    }

    return curValue;
}

void Character::SwapItemInSlot(int srcslot, int destslot)
{
	uint32 tempguid1, tempitemid;
	tempguid1 = this->m_items[srcslot].guid;
	tempitemid = this->m_items[srcslot].itemid;
	this->m_items[srcslot].guid = this->m_items[destslot].guid;
	this->m_items[srcslot].itemid = this->m_items[destslot].itemid;
	this->m_items[destslot].guid = tempguid1;
	this->m_items[destslot].itemid = tempitemid;
}

void Character::BuildEnumData( uint8 * data, uint8 * length )
{
/*
   oint64      id; 
   char      Name[MAX_CHARACTER_NAME_SIZE]; 
   obyte      Race; 
   obyte      Class; 
   obyte      Gender; 
   obyte      Skin; 
   obyte      Face; 
   obyte      HairStyle; 
   obyte      HairColour; 
   obyte      FacialHair; 
   obyte      Level; 
   obyte      OutfitID; 
   oint32      ZoneID; 
   obyte      unknown1; 
   obyte      unknown2; 
   obyte      unknown3; 
   ofloat32   PositionX; 
   ofloat32   PositionY; 
   ofloat32   PositionZ; 
   oint32      GuildID; 
   oint32      unknown4; 
   obyte      rest; 
   oint32      PetDisplayInfoID; 
   oint32      PetExperienceLevel; 
   oint32      PetCreatureFamilyID; 
   InventoryItem_t      InventoryItem[20]; 
*/
    uint8 i = 0, doo = 0;
    assert(data);

    memcpy(data, &m_guid[0], 4);
    memcpy(data+4, &m_guid[1], 4);
    doo=8;

    // name
    uint16 name_size = 0;
    for (i=0; m_name[i] != 0; i++){
        name_size++;
        data[doo++] = m_name[i];
    }

    assert( name_size <= 21 );

    data[doo++] = 0x00;

    uint32 bytes = getUpdateValue(UNIT_FIELD_BYTES_0);
    data[doo++] = uint8(bytes & 0xff); // race
    data[doo++] = uint8((bytes >> 8) & 0xff); // class
    data[doo++] = uint8((bytes >> 16) & 0xff); // gender

    bytes = getUpdateValue(PLAYER_BYTES);
    data[doo++] = uint8(bytes & 0xff); //skin 
    data[doo++] = uint8((bytes >> 8) & 0xff); //face
    data[doo++] = uint8((bytes >> 16) & 0xff); //hairstyle
    data[doo++] = uint8((bytes >> 24) & 0xff); //haircolor

    bytes = getUpdateValue(PLAYER_BYTES_2);
    data[doo++] = uint8((bytes >> 8) & 0xff); //facialhair

    data[doo++] = uint8(getUpdateValue(UNIT_FIELD_LEVEL)); //level

    memcpy(data+doo, &m_zoneId, 2); // zoneid
    doo+=2;
    data[doo++] = 0x00;
    data[doo++] = 0x00;

    memcpy(data+doo, &m_mapId, 2); // mapid
    doo+=2;
    data[doo++] = 0x00;
    data[doo++] = 0x00;

    memcpy(data+doo, &m_positionX, 4); //x
    doo+=4;

    memcpy(data+doo, &m_positionY, 4); //y
    doo+=4;

    memcpy(data+doo, &m_positionZ, 4); //z
    doo+=4;

/*    data[doo++] = ((uint8)((m_guildId>>8) & 0xFF)); //guild
    data[doo++] = (uint8)(m_guildId);
    data[doo++] = ((uint8)((m_petInfoId>>8) & 0xFF)); 
    data[doo++] = (uint8)(m_petInfoId);
    data[doo++] = ((uint8)((m_petLevel>>8) & 0xFF));
    data[doo++] = (uint8)(m_petLevel);
    data[doo++] = 0; // lower half of unknown uint16
    data[doo++] = 0; // upper half of unknown uints16
    data[doo++] = 1; // 1=well rested., 2=rested, 3=normal, 4=tired, 5=exhausted
    data[doo++] = ((uint8)((m_petFamilyId>>8) & 0xFF));
    data[doo++] = (uint8)(m_petFamilyId);
*/
	int tempstor = 0xffffffff;
    memcpy(data+doo, &tempstor, 4); //guild
    doo+=4;
	tempstor = 0;
    memcpy(data+doo, &tempstor, 4); //unknown
    doo+=4;
	data[doo++] = 1; //rest state
    memcpy(data+doo, &m_petInfoId, 4); //pet info id
    doo+=4;
    memcpy(data+doo, &m_petLevel, 4); //pet info id
    doo+=4;
    memcpy(data+doo, &m_petFamilyId, 4); //pet info id
    doo+=4;
	
	

    Item *tempitem;
    for (i = 0; i < 20; i++) {
		  tempitem = WorldServer::getSingleton().GetItem(m_items[i].itemid);
		  if ((tempitem == NULL) && (m_items[i].guid != 0))
			  return;
		  if (m_items[i].guid != 0) {
			memcpy(data+doo, &tempitem->DisplayInfoID, 4);
			doo+=4;
			data[doo++] = uint8(tempitem->Inventorytype);
		  }
		  else {
 			memcpy(data+doo, &m_inventory[i].displayId, 4);
 			doo+=4;
 			data[doo++] = i;
		  }
    }
    // pad out the rest
    while (doo-name_size < 159){
        data[doo++] = 0x00;
    }

    assert( doo <= 176 );

    *length = name_size + 159;
}


void Character::BuildUpdateBlock(UpdateMask* updateMask, uint8 * data, int* length)
{
    Unit::BuildUpdateBlock(updateMask, data, length);
}



/////////////////////////////////// QUESTS ////////////////////////////////////////////
uint32 Character::getQuestStatus(uint32 quest_id)
{
    if( mQuestStatus.find( quest_id ) == mQuestStatus.end( ) ) return 0;
    return mQuestStatus[quest_id].status;
}

uint32 Character::addNewQuest(uint32 quest_id, uint32 status)
{ 
    quest_status qs;
    qs.quest_id = quest_id;
    qs.status = status;

    mQuestStatus[quest_id] = qs;
    return status; 
};

void Character::loadExistingQuest(quest_status qs)
{
    mQuestStatus[qs.quest_id] = qs;
}

void Character::setQuestStatus(uint32 quest_id, uint32 new_status)
{ 
    assert( mQuestStatus.find( quest_id ) != mQuestStatus.end( ) );
    mQuestStatus[quest_id].status = new_status; 
}

uint16 Character::getOpenQuestSlot()
{
    int start = PLAYER_QUEST_LOG_1_1;
    int end = PLAYER_QUEST_LOG_1_1 + 80;
    for (int i = start; i <= end; i+=4)
        if (m_updateValues[i] == 0)
            return i;

    return 0;
}

uint16 Character::getQuestSlot(uint32 quest_id)
{
    int start = PLAYER_QUEST_LOG_1_1;
    int end = PLAYER_QUEST_LOG_1_1 + 80;
    for (int i = start; i <= end; i+=4)
        if (m_updateValues[i] == quest_id)
            return i;

    return 0;
}

void Character::setQuestLogBits(UpdateMask *updateMask)
{
    for( StatusMap::iterator i = mQuestStatus.begin( ); i != mQuestStatus.end( ); ++ i ) {
        if (i->second.status == 3){ // incomplete, put the quest in the log
            uint16 log_slot = getQuestSlot(i->second.quest_id);
            struct quest_status qs = i->second;
            if (log_slot == 0){ // in case this quest hasnt been added to the updateValues (but it shoudl have been!)
                log_slot = getOpenQuestSlot();
                setUpdateValue(log_slot, qs.quest_id);
                setUpdateValue(log_slot+1, 0x337);
            }

            updateMask->setBit(log_slot);
            updateMask->setBit(log_slot+1); 

            if (qs.m_questMobCount[0] > 0 || qs.m_questMobCount[1] > 0 ||
                qs.m_questMobCount[2] > 0 || qs.m_questMobCount[3] > 0)
            {
                updateMask->setBit(log_slot+2);
            }
        }
    }
}


void Character::KilledMonster(uint32 entry, uint32 guid)
{
    for( StatusMap::iterator i = mQuestStatus.begin( ); i != mQuestStatus.end( ); ++ i ) {
        if (i->second.status == 3){
            Quest *pQuest = WorldServer::getSingleton().getQuest(i->first);
            for (int j=0; j<4; j++)
            {
                if (pQuest->m_questMobId[j] == entry)
                {
                    if (i->second.m_questMobCount[j]+1 <= pQuest->m_questMobCount[j])
                    {
                        i->second.m_questMobCount[j]++ ;

                        // Send Update quest update kills message
                        wowWData data;
                        data.Initialise(24, SMSG_QUESTUPDATE_ADD_KILL);
                        data << pQuest->m_questId;
                        data << uint32(pQuest->m_questMobId[j]);
                        data << uint32(i->second.m_questMobCount[j]);
                        data << uint32(pQuest->m_questMobCount[j]);
                        data << guid << 0xF0001000;
                        WorldServer::getSingleton().SendMessageToPlayer(&data, m_name);

                        // update journal
                        // this is crazy.  each bit corresponds to a kill, set multiple bits to signify multiple kills
                        uint32 start_bit=0;
                        if (j-1 < 0) start_bit = 0;
                        else
                            for (int n=j-1; n>=0; n--)
                                start_bit += pQuest->m_questMobCount[n];

                        uint16 log_slot = getQuestSlot(pQuest->m_questId);
                        uint32 kills = getUpdateValue(log_slot+2);

                        int exp = start_bit + i->second.m_questMobCount[j]-1;
                        kills |= 1 << exp;
                        setUpdateValue(log_slot+2, kills);
                    }

//                    checkQuestStatus(i->second.quest_id);
                    // Ehh, I think a packet should be sent here, but I havent found one in the official logs yet

                    return;
                } // end if mobId == entry
            } // end for each mobId
        } // end if status == 3
    } // end for each quest
}

//======================================================
//  Check to see if all the required monsters and items
//  have been killed and collected.
//======================================================
bool Character::checkQuestStatus(uint32 quest_id)
{
    assert( mQuestStatus.find( quest_id ) != mQuestStatus.end( ) );
    quest_status qs = mQuestStatus[quest_id];
    Quest *pQuest = WorldServer::getSingleton().getQuest(quest_id);

    if (qs.m_questItemCount[0] == pQuest->m_questItemCount[0] &&
        qs.m_questItemCount[1] == pQuest->m_questItemCount[1] &&
        qs.m_questItemCount[2] == pQuest->m_questItemCount[2] &&
        qs.m_questItemCount[3] == pQuest->m_questItemCount[3] &&
        qs.m_questMobCount[0] == pQuest->m_questMobCount[0] &&
        qs.m_questMobCount[1] == pQuest->m_questMobCount[1] &&
        qs.m_questMobCount[2] == pQuest->m_questMobCount[2] &&
        qs.m_questMobCount[3] == pQuest->m_questMobCount[3])
    {
        // Quest complete!
        return true;
    }

    return false;
}


//  This function sends the message displaying the purple XP gain for the char
//  It assumes you will send out an UpdateObject packet at a later time.
void Character::giveXP(uint32 xp_to_give, uint32 guidlow, uint32 guidhi)
{
    if (xp_to_give == 0) return;

    wowWData data;
    if (guidlow != 0)
    {      
        // Send out purple XP gain message, but ONLY if a valid GUID was passed in
        // This message appear to be only for gaining XP from a death
        data.Initialise(17, SMSG_LOG_XPGAIN);
        data << uint32(guidlow) << uint32(guidhi);
        data << uint32(xp_to_give);
        data << uint8(0) << uint16(xp_to_give) << uint8(0);
        data << uint8(0);
        WorldServer::getSingleton().SendMessageToPlayer(&data, m_name);
    }

    uint32 xp           = getUpdateValue(PLAYER_XP);
    uint32 next_lvl_xp  = getUpdateValue(PLAYER_NEXT_LEVEL_XP);
    uint32 new_xp       = xp + xp_to_give;

    // Check for level-up
    if (new_xp >= next_lvl_xp)
    {
        uint32 health_gain=0, new_health=0, mana_gain=0, new_mana=0;
        // Level-Up!
        new_xp = new_xp - next_lvl_xp;  // reset XP to 0, but add extra from this xp add
        next_lvl_xp += next_lvl_xp/2;   // set the new next level xp
        uint16 level = (uint16)getUpdateValue(UNIT_FIELD_LEVEL) + 1;    // increment the level
		
        health_gain = getUpdateValue(PLAYER_FIELD_STAT2) / 2;
        new_health = getUpdateValue(UNIT_FIELD_MAXHEALTH) + health_gain;

        if (getUpdateValue(UNIT_FIELD_POWER1) > 0){
            mana_gain = getUpdateValue(PLAYER_FIELD_STAT4) / 2;
            new_mana = getUpdateValue(UNIT_FIELD_POWER1) + mana_gain;
        }

        setUpdateValue(PLAYER_NEXT_LEVEL_XP,    next_lvl_xp);
        setUpdateValue(UNIT_FIELD_LEVEL,        level);
        setUpdateValue(UNIT_FIELD_MAXHEALTH,    new_health);
        setUpdateValue(UNIT_FIELD_HEALTH,       new_health);
        setUpdateValue(UNIT_FIELD_POWER1,       new_mana);
        setUpdateValue(UNIT_FIELD_MAXPOWER1,    new_mana);
		
		updateItemStats();
        data.Initialise(48, SMSG_LEVELUP_INFO);

        data << uint32(level);
        data << uint32(health_gain);     // health gain
        data << uint32(mana_gain);       // mana gain
        data << uint32(0);
        data << uint32(0);
        data << uint32(0);

        // 6 new fields
        data << uint32(0);  
        data << uint32(0);  
        data << uint32(0);  
        data << uint32(0);  
        data << uint32(0);
        data << uint32(0);

        WorldServer::getSingleton().SendMessageToPlayer(&data, m_name);
    }

    // Set the update bit
    setUpdateValue(PLAYER_XP, new_xp);
}


////////////////////////////////////////////////////////////////////////////////
//  Fill the object's Update Values from a space deliminated list of values.
////////////////////////////////////////////////////////////////////////////////
void Character::LoadUpdateValues(uint8* data)
{
    char* next = strtok((char*)data, " ");
    m_updateValues[0] = atol(next);
    for( uint16 index = 1; index < UPDATE_BLOCKS; index++)
    {
        char* next = strtok(NULL, " ");
        if (!next) continue;
        m_updateValues[index] = atol(next);
        assert(m_updateValues[index] != 0x7FFFFFFF);
    }
}


///////////////////////////////////////////////////////////////////////////////
//	Items Update
///////////////////////////////////////////////////////////////////////////////
void Character::updateItemStats()
{
	uint16 level = (uint16)getUpdateValue(UNIT_FIELD_LEVEL);
	if (this->getGuidBySlot(15) == 0)
	{
		setUpdateValue(PLAYER_FIELD_ATTACKPOWER, 2+2*level);
		setUpdateFloatValue(UNIT_FIELD_MINDAMAGE, float(6+2*level - 1));
		setUpdateFloatValue(UNIT_FIELD_MAXDAMAGE, float(6+2*level + 1));
	}
	else {
		uint32 minDmg, maxDmg;
		minDmg = world.GetItem( this->getItemIdBySlot(15) )->MinimumDamage[0];
		maxDmg = world.GetItem( this->getItemIdBySlot(15) )->MaximumDamage[0];
		uint32 tmpAttackPower = minDmg + (maxDmg - minDmg)/2;
		setUpdateFloatValue(UNIT_FIELD_MINDAMAGE, float(minDmg));
		setUpdateFloatValue(UNIT_FIELD_MAXDAMAGE, float(maxDmg));
		setUpdateValue(PLAYER_FIELD_ATTACKPOWER, tmpAttackPower);
	}
}


void Character::smsg_InitialSpells()
{
    wowWData data;
    uint16 spellCount = m_spells.size();

    data.Initialise(3+(4*spellCount), SMSG_INITIAL_SPELLS);
    data << uint8(0);
    data << uint16(spellCount); // spell count

    std::list<struct spells>::iterator itr;
    for (itr = m_spells.begin(); itr != m_spells.end(); ++itr)
    {
        data << uint16(itr->spellId); // spell id
        data << uint16(itr->slotId); // slot
    }

    world.SendMessageToPlayer(&data, m_name);
    printf( "CHARACTER: Sent Initial Spells" );
}

void Character::addSpell(uint16 spell_id, uint16 slot_id)
{
    struct spells newspell;
    newspell.spellId = spell_id;
    
    if (slot_id == 0xffff){
        uint16 maxid = 0;
        std::list<struct spells>::iterator itr;
        for (itr = m_spells.begin(); itr != m_spells.end(); ++itr)
        {
            if (itr->slotId > maxid) maxid = itr->slotId;
        }

        slot_id = maxid + 1;
    }

    newspell.slotId = slot_id;
    m_spells.push_back(newspell);
}

