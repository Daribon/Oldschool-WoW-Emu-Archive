#include "RedirectorSrv.h"

#include "Network.h"
#include "Log.h"
#include "Sockets.h"

void RedirectorSrv::client_sockevent(struct nlink_client *cptr, unsigned short revents){
}

void RedirectorSrv::Initialise( int port, char *type, char * destination ) {
    assert( this != 0 );
    mDestination = destination;
    Server::Initialise( port, type );
}


void RedirectorSrv::server_sockevent( nlink_server *cptr, uint16 revents, void *myNet ) {
	NetworkInterface * client;
	struct nlink_client *ncptr;
	if(revents & PF_READ)
	{
		client = ( ( NetworkInterface * ) myNet )->getConnection( );
		if (!client) 
			return;
		uint32 nonblockingstate = true;
		IOCTL_SOCKET( client->getSocketID(), IOCTL_NOBLOCK, &nonblockingstate );

		ncptr = new nlink_client;
		if(ncptr == NULL)
			return;
		memset(ncptr, 0, sizeof(*ncptr));
		ncptr->hdr.type = RCLIENT;
		ncptr->hdr.fd = client->getSocketID();
		
		nlink_insert((struct nlink *)ncptr);

		Client *pClient = new Client();
		pClient->BindNI(client);
		ncptr->pClient = pClient;
		pClient->getNetwork()->sendData( mDestination.length( ), mDestination.c_str( ) );
		Log::getSingleton( ).outString( "REDIRECTOR: Sent world server" );
		disconnect_client( ncptr );
	}
}

void RedirectorSrv::disconnect_client(	struct nlink_client *cptr )
{
	Client * pClient = static_cast < Client * > ( cptr->pClient );
	mClients.erase( pClient );
	delete pClient;
	Log::getSingleton( ).outString( "REDIRECTOR: Socket Closed!" );
	Server::disconnect_client( cptr );
}