#include "SpellHandler.h"
#include "NetworkInterface.h"
#include "Opcodes.h"
#include "Log.h"
#include "Character.h"
#include "WorldServer.h"
#include "Database.h"
#include "UpdateMask.h"
#include "Unit.h"

#define world WorldServer::getSingleton()

SpellHandler::SpellHandler()
{

}

SpellHandler::~SpellHandler()
{

}

void SpellHandler::HandleMsg( wowWData & recv_data, GameClient *pClient )
{
	wowWData data;
    char f[256];
    sprintf(f, "WORLD: Spell 0x%.4X", recv_data.opcode);
    Log::getSingleton( ).outString( f );
	switch (recv_data.opcode)
	{
		case CMSG_USE_ITEM:
			{
                /*//A quick dirty hack for now...
                uint32 level = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_LEVEL );
                uint32 curr_health = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_HEALTH );
                uint32 max_health = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_MAXHEALTH );
                uint32 heal = ((((rand()%50)*level)/2));
                if(curr_health==max_health)
                {
                    break;
                }
                else
                { 
                    if( heal+curr_health>max_health )
                    {
                        heal=max_health-curr_health;
                    }
                    data.Initialise(4, SMSG_HEALSPELL_ON_PLAYER );
                    data << heal;
                    pClient->SendMsg( &data );
                    pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_HEALTH, heal+curr_health );
                }*/
				uint8 packslot,slot;
				uint16 targets;
				uint8 spell;
				int datalen = recv_data.length;
				recv_data >> packslot >> slot >> spell;
				recv_data >> targets;
				if (targets == 0)
					return;
				uint32 spellid;
				printf("Item ID - %d\nItem GUID - %d\n",pClient->getCurrentChar()->getItemIdBySlot(slot),pClient->getCurrentChar()->getGuidBySlot(slot));
				Item *tmpItem = world.GetItem( pClient->getCurrentChar()->getItemIdBySlot(slot) );
				spellid = tmpItem->SpellID[spell - 1];
				for(int i = 0;i < 5;i++) {
					printf("spell number %d - %d\n",i,tmpItem->SpellID[i]);
				}
				printf("item class - %d\n",tmpItem->Class);
				printf("item displayid - %d\n",tmpItem->DisplayInfoID);
				data.clear();
				data.Initialise( datalen - 3 + 32, SMSG_SPELL_GO);
				
				data << uint32(pClient->getCurrentChar()->getGUID()) << uint32(pClient->getCurrentChar()->getGUIDHigh());
				data << uint32(pClient->getCurrentChar()->getGUID()) << uint32(pClient->getCurrentChar()->getGUIDHigh());
				data << uint32(spellid);
				data << uint8(0x00) << uint8(0x01);

				if( targets & 0x2 || targets & 0x800 || targets & 0x8000 ) {
					uint64 unitTarget;
					recv_data >> unitTarget;
					data << uint8(0x01);
					data << uint64(unitTarget);
					data << uint8(0x00);
					data << uint16(targets);
					data << uint64(unitTarget);
				}
				pClient->SendMsg( &data );

			}break;
		case CMSG_CAST_SPELL:
			{
				uint32 spell ,target1, target2, pguid;
				uint16 flags;
				recv_data >> spell >> flags;
				pguid = pClient->getCurrentChar()->getGUID();
				if ((spell == 133) || (spell == 116) || (spell == 585) || (spell == 403) || (spell == 686) || (spell == 5176)) {
						recv_data >> target1 >> target2;
				
			        	    data.clear();		
			        	    data.Initialise( 36, SMSG_SPELL_START );
			        	    data << pguid << uint32( 0 ) << pguid << uint32( 0 ) << spell;
			        	    data << flags << uint32 ( 0 ) << flags << target1 << target2;
			        	    pClient->SendMsg( &data );
			        	    
			        	    data.clear();		
			        	    data.Initialise( 5, SMSG_CAST_RESULT );
			        	    data << spell << uint8( 0x01);
			        	    pClient->SendMsg( &data );
			        	    
			        	    data.clear();		
			        	    data.Initialise( 54, SMSG_SPELL_GO );
			        	    data << pguid << uint32( 0 ) << pguid << uint32( 0 );
			        	    data << spell << uint8( 0x00 ) << uint8( 0x01 ) << uint8( 0x01 ) << target1 << target2;
			        	    data << uint8( 0 ) << uint8( 0x42 ) << uint8( 0 ) << target1 << target2;
			        	    data << pClient->getCurrentChar( )->getPositionX( ) << pClient->getCurrentChar( )->getPositionY( ) << pClient->getCurrentChar( )->getPositionZ( );
                            //data.writeData(&tdata);

			        	    //pClient->SendMsg( &data );
//                            world.SendAreaMessage(&data, pClient, 1);
                            pClient->getCurrentChar()->SendMessageToSet(&data, true);

                            // Modified by DeathCheese
                            // Basically, takes your spell damage and puts it into CombatHandler's function which checks for death,
                            // and gives out XP, logs quest kills, etc
                            uint32 damage = rand()%30;
                            world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target1 ], damage);
				} else if ((spell == 9163)) {
					//self targeting spells!
					switch(spell) {
						case 9163: {
								/*//some ugly code for testing self healing spell (9163)								
								uint32 hp = pClient->getCurrentChar()->getUpdateValue( UNIT_FIELD_HEALTH );
								uint32 mhp = pClient->getCurrentChar()->getUpdateValue( UNIT_FIELD_MAXHEALTH );
								uint32 mana = pClient->getCurrentChar()->getUpdateValue( UNIT_FIELD_POWER1 );
								if(hp<mhp){
									pClient->getCurrentChar()->setUpdateValue( UNIT_FIELD_HEALTH, hp+50);
									pClient->getCurrentChar()->setUpdateValue( UNIT_FIELD_POWER1, mana-20 );
								}*/
								uint32 level = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_LEVEL );
								uint32 curr_health = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_HEALTH );
								uint32 max_health = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_MAXHEALTH );
								uint32 mana = pClient->getCurrentChar()->getUpdateValue( UNIT_FIELD_POWER1 );
								uint32 heal = ((((rand()%50)*level)/2));
								if(curr_health==max_health)
								{
									break;
								}
								else
								{ 
									if( heal+curr_health>max_health )
									{
										heal=max_health-curr_health;
									}
									data.Initialise(4, SMSG_HEALSPELL_ON_PLAYER );
									data << heal;
									pClient->SendMsg( &data );
									pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_HEALTH, heal+curr_health );
									pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_POWER1, mana-20 );
								}
						   }break;
						default: {}
					}
				}                
				else {
					//uint32 damage;
					int templen = 0;
					uint8 targetCount = 0;
					uint16 targets = flags;
					wowWData tmpData;
					float sourceLocationx, sourceLocationy, sourceLocationz;
					uint64 itemTarget;
					uint64 unitTarget;
					float destLocationx, destLocationy, destLocationz;
					//char targetString[0x80];
					
					tmpData.Initialise(100, SMSG_SPELL_START);
					tmpData << pguid << uint32( 0 ) << pguid << uint32( 0 ) << spell;
					tmpData << flags << uint32 ( 0 ) << flags;
					if( targets & 0x2 || targets & 0x800 || targets & 0x8000 ) {
						templen += 8;
						recv_data >> unitTarget;
						tmpData << uint64(unitTarget);
					}
					if( targets & 0x10 || targets & 0x1000 ) {
						templen += 8;
						recv_data >> itemTarget;
						tmpData << uint64(itemTarget);
					}
					if( targets & 0x20 ) {
						templen += 12;
						recv_data >> sourceLocationx >> sourceLocationy >> sourceLocationz;
						tmpData << sourceLocationx << sourceLocationy << sourceLocationz;
					}
					if( targets & 0x40 ) {
						templen += 12;
						recv_data >> destLocationx >> destLocationy >> destLocationz;
						tmpData << destLocationx << destLocationy << destLocationz;
					}
					if( targets & 0x2000 ) {
						templen += 128;
					}
					
					data.Initialise(28 + templen,SMSG_SPELL_START);
					memcpy(data.data, tmpData.data,28+templen );
//					world.SendAreaMessage(&data,pClient,1);
                    pClient->getCurrentChar()->SendMessageToSet(&data, true);

					data.Initialise( 5, SMSG_CAST_RESULT );
			        data << spell << uint8( 0x01);
			        pClient->SendMsg( &data );
					
					switch (spell) {
						case 122: case 1449: case 2120: case 2121: case 8422: 
						case 8423: case 10: case 6141: case 8427: case 865:
						case 6131: case 8437: case 8438: case 8439:
							{
								wowWData tmpSpellGo;

								data.clear();		
			        			tmpSpellGo.Initialise( 500, SMSG_SPELL_GO );
					       	    tmpSpellGo << pguid << uint32( 0 ) << pguid << uint32( 0 );
					       	    tmpSpellGo << spell;
								tmpSpellGo << uint8(0) << uint8(1);
								tmpSpellGo << uint8(targetCount); //temp
								
								WorldServer::CreatureMap::iterator itr;
								for (itr = world.mCreatures.begin(); itr != world.mCreatures.end(); ++itr){
									if (( itr->second->IsAlive() ) && (!itr->second->IsPlayer()))
									{
										
										if (!( targets & 0x40 )) {
											if ((world.CalcDistance((Unit*)pClient->getCurrentChar(), (itr->second)) < 10) && (pClient->getCurrentChar()->getMapId() == itr->second->getMapId()  ))
											{
												if (itr->second->getZone() == pClient->getCurrentChar()->getZone()) {
													if (applySpell(pClient, itr->second , spell , world.CalcDistance((Unit*)pClient->getCurrentChar(), (itr->second)))) {												
														targetCount++;
														tmpSpellGo << itr->second->getGUID() << itr->second->getGUIDHigh();
													}												
												}
											}
										}
										else {
											if ((world.CalcDistanceByPosition((itr->second),destLocationx,destLocationy,destLocationz) < 10) && (pClient->getCurrentChar()->getMapId() == itr->second->getMapId()  ))
											{
												if (itr->second->getZone() == pClient->getCurrentChar()->getZone()) {
													//Do Something
													if (applySpell(pClient, itr->second , spell, world.CalcDistanceByPosition((itr->second),destLocationx,destLocationy,destLocationz))) {
														targetCount++;
														tmpSpellGo << itr->second->getGUID() << itr->second->getGUIDHigh();
													}													
												}
											}											
										}
									}
								}
								memcpy(tmpSpellGo.data + 22, &targetCount ,1);
								tmpSpellGo << uint8(0) << uint16(targets);
								if( targets & 0x2 || targets & 0x800 || targets & 0x8000 ) {
									tmpSpellGo << uint64(unitTarget);
								}
								if( targets & 0x10 || targets & 0x1000 ) {
									tmpSpellGo << uint64(itemTarget);
								}
								if( targets & 0x20 ) {
									tmpSpellGo << float(sourceLocationx) << float(sourceLocationy) << float(sourceLocationz);
								}
								if( targets & 0x40 ) {
									tmpSpellGo << float(destLocationx) << float(destLocationy) << float(destLocationz);
								}								
								data.Initialise(26 + 8*targetCount + templen,SMSG_SPELL_GO);
								memcpy(data.data, tmpSpellGo.data, 26 + 8*targetCount + templen);
//								world.SendAreaMessage(&data,pClient,1);
                                pClient->getCurrentChar()->SendMessageToSet(&data, true);
							}
					}

				}
            }break;
            default: {}break;
    }
}

int SpellHandler::setAura(Unit *pUnit, uint32 spell)
{
    return 1;  // test
	uint8 tmpStore = 0x00;
	int found = -1,found2 = -1;
	uint32 auraValue;
	int i;
	for( i = 0; (i < 10) && (found == -1); i++) {
		if (!(pUnit->getUpdateValue(UNIT_FIELD_AURALEVELS + i) == 0xeeeeeeee)) {
			found = i;		
		}
	}
	if (found == -1)
		return 0;
	auraValue = pUnit->getUpdateValue(UNIT_FIELD_AURALEVELS + found);

	for( i = 0; (i < 4) && (found2 == -1); i++)
	{
		if ((uint8)*(&auraValue + i) != 0xee) {
			found2 = i;
			memcpy(&auraValue + i,&tmpStore,1);
		}	
	}
	pUnit->setUpdateValue(UNIT_FIELD_AURALEVELS + found, auraValue);
	pUnit->setUpdateValue(UNIT_FIELD_AURAAPPLICATIONS + found, auraValue);
	pUnit->setUpdateValue(UNIT_FIELD_AURA + found*4 + found2, uint32(spell));
}

int SpellHandler::applySpell( GameClient *pClient, Unit *target, uint32 spell, float range)
{
	switch (spell)
	{
	case 122: //frost nova lvl 1
		{
			if (range > 5)
				return 0;
			uint32 damage,freezetime;			
			damage = 21 + rand()%3;
			freezetime = 1 + rand()%9;
			world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target->getGUID() ], damage);			
			setAura(target, spell);
			return 1;
		}break;
	case 865: //frost nova lvl 2
		{
			if (range > 5)
				return 0;
			uint32 damage,freezetime;			
			damage = 33 + rand()%4;
			freezetime = 1 + rand()%9;
			world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target->getGUID() ], damage);			
			setAura(target, spell);
			return 1;
		}break;
	case 6131: //frost nova lvl 3
		{
			if (range > 5)
				return 0;
			uint32 damage,freezetime;			
			damage = 47 + rand()%6;
			freezetime = 1 + rand()%9;
			world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target->getGUID() ], damage);			
			setAura(target, spell);
			return 1;
		}break;
	case 2120: //flame strike lvl 1
		{
			if (range > 5)
				return 0;
			uint32 damage;			
			damage = 61 + rand()%16;
			world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target->getGUID() ], damage);			
			setAura(target, spell);
			return 1;
		}break;
	case 2121: //flame strike lvl 2
		{
			if (range > 5)
				return 0;
			uint32 damage,freezetime;			
			damage = 33 + rand()%4;
			freezetime = 1 + rand()%9;
			world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target->getGUID() ], damage);			
			setAura(target, spell);
			return 1;
		}break;
	case 8422: //flame strike lvl 3
		{
			if (range > 5)
				return 0;
			uint32 damage,freezetime;			
			damage = 47 + rand()%6;
			freezetime = 1 + rand()%9;
			world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target->getGUID() ], damage);			
			setAura(target, spell);
			return 1;
		}break;
	case 8423: //flame strike lvl 4
		{
			if (range > 5)
				return 0;
			uint32 damage,freezetime;			
			damage = 47 + rand()%6;
			freezetime = 1 + rand()%9;
			world.mCombatHandler.DealDamage(pClient->getCurrentChar( ), world.getCreatureMap( )[ target->getGUID() ], damage);			
			setAura(target, spell);
			return 1;
		}break;
	default:
		{
			return 0;
		}break;
	}
}