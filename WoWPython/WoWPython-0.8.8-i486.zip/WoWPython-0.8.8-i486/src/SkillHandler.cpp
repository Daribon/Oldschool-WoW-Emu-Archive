#include "SkillHandler.h"
#include "NetworkInterface.h"
#include "Opcodes.h"
#include "Log.h"
#include "Character.h"
#include "WorldServer.h"
#include "Database.h"
#include "UpdateMask.h"

#define world WorldServer::getSingleton()

SkillHandler::SkillHandler()
{

}

SkillHandler::~SkillHandler()
{

}

void SkillHandler::HandleMsg( wowWData & recv_data, GameClient *pClient )
{
	/*
	wowWData data;
    char f[256];
    sprintf(f, "WORLD: Skill Opcode: 0x%.4X", recv_data.opcode);
    Log::getSingleton( ).outString( f );
	switch (recv_data.opcode)
	{
    case CMSG_SKILL_LEVELUP:
        {
            uint32 slot, skill_id, amount, current_points, current_skill, points;
            recv_data >> slot >> skill_id >> amount;
            current_points = pClient->getCurrentChar( )->getUpdateValue( PLAYER_SKILL_INFO_1_1+slot+1 );
            current_skill = pClient->getCurrentChar( )->getUpdateValue( PLAYER_SKILL_INFO_1_1+slot );
            points = pClient->getCurrentChar( )->getUpdateValue( PLAYER_CHARACTER_POINTS2 );
            pClient->getCurrentChar( )->setUpdateValue( PLAYER_SKILL_INFO_1_1+slot , ( 0x000001a1 ));
            pClient->getCurrentChar( )->setUpdateValue( PLAYER_SKILL_INFO_1_1+slot+1 , ( (current_points & 0xffff) + (amount << 16) ) );
            pClient->getCurrentChar( )->setUpdateValue( PLAYER_CHARACTER_POINTS2, points-amount );
			pClient->getCurrentChar( )->UpdateObject( );
        }break;

    default: {}break;
    }
	*/
}

