#include "MovementHandler.h"
#include "NetworkInterface.h"
#include "Opcodes.h"
#include "Log.h"
#include "Character.h"
#include "WorldServer.h"
#include "UpdateMask.h"
#include <time.h>
#include <math.h>

#define world WorldServer::getSingleton()

MovementHandler::MovementHandler()
{

}

MovementHandler::~MovementHandler()
{

}

void MovementHandler::HandleMsg( wowWData & recv_data, GameClient *pClient )
{
    wowWData data;
    bool updateself = false;

    // Was getting crashes receiving heartbeats from players that had logged out
    // So dont go any further if they have no current character
    if (!pClient->IsInWorld())  return;

    //printf("WORLD: Movement Opcode 0x%.4X\n", recv_data.opcode );
    switch (recv_data.opcode)
    {
    case MSG_MOVE_HEARTBEAT:
        {
            data.clear();
            data.Initialise( 8+recv_data.length, MSG_MOVE_HEARTBEAT);

            if( pClient->getCurrentChar() && !pClient->getCurrentChar( )->setPosition( recv_data.data+8 ) ) {
                wowWData movedata;
                pClient->getCurrentChar( )->TeleportAck( &movedata, pClient->getCurrentChar( )->getPositionX( ), pClient->getCurrentChar( )->getPositionY( ), pClient->getCurrentChar( )->getPositionZ( ) );
                pClient->getNetwork( )->sendWData(&movedata);
            }

            // GUID of player who sent heartbeat
            uint32 guid = pClient->getCurrentChar()->getGUID();
            memcpy(data.data, &guid, 4);
            data.data[4] = 0x00;
            data.data[5] = 0x00;
            data.data[6] = 0x00;
            data.data[7] = 0x00;

            memcpy(data.data+8, recv_data.data, recv_data.length);
//            world.SendAreaMessage(&data, pClient, 0);
            pClient->getCurrentChar()->SendMessageToSet(&data, false);
        }break;

    case MSG_MOVE_JUMP: case MSG_MOVE_START_FORWARD : case MSG_MOVE_START_BACKWARD: case MSG_MOVE_SET_FACING: 
    case MSG_MOVE_STOP: case MSG_MOVE_START_STRAFE_LEFT: case MSG_MOVE_START_STRAFE_RIGHT: case MSG_MOVE_STOP_STRAFE: 
    case MSG_MOVE_START_TURN_LEFT: case MSG_MOVE_START_TURN_RIGHT:  case MSG_MOVE_STOP_TURN: case MSG_MOVE_START_PITCH_UP :
    case MSG_MOVE_START_PITCH_DOWN: case MSG_MOVE_STOP_PITCH : case MSG_MOVE_SET_RUN_MODE: case MSG_MOVE_SET_WALK_MODE:
    case MSG_MOVE_SET_PITCH: case MSG_MOVE_START_SWIM:
    case MSG_MOVE_STOP_SWIM:
        {
            if( !pClient->getCurrentChar( )->setPosition( recv_data.data+8 ) ) {
                wowWData movedata;
                pClient->getCurrentChar( )->TeleportAck( &movedata, pClient->getCurrentChar( )->getPositionX( ), pClient->getCurrentChar( )->getPositionY( ), pClient->getCurrentChar( )->getPositionZ( ) );
                pClient->getNetwork( )->sendWData(&movedata);
                pClient->getCurrentChar( )->getPosition( recv_data.data+8 );
            }

            // GUID of player who sent the message
            uint32 guid = pClient->getCurrentChar()->getGUID();

            data.clear();
            data.Initialise( 8+recv_data.length, recv_data.opcode);

            memcpy(data.data, &guid, 4);
            data.data[4] = 0x00;
            data.data[5] = 0x00;
            data.data[6] = 0x00;
            data.data[7] = 0x00;

            memcpy(data.data+8, recv_data.data, recv_data.length);
//            world.SendAreaMessage(&data, pClient, 0);
            pClient->getCurrentChar()->SendMessageToSet(&data, false);

        }break;
    case MSG_MOVE_WORLDPORT_ACK:
        {
            UpdateMask updateMask;
            updateMask.setCount(PLAYER_BLOCKS);

            updateMask.setBit( OBJECT_FIELD_GUID  ); updateMask.setBit( OBJECT_FIELD_GUID+1  );
            updateMask.setBit( OBJECT_FIELD_TYPE  ); updateMask.setBit( OBJECT_FIELD_SCALE_X  );
            updateMask.setBit( UNIT_FIELD_HEALTH  ); updateMask.setBit( UNIT_FIELD_MAXHEALTH  );
            updateMask.setBit( UNIT_FIELD_LEVEL  ); updateMask.setBit( UNIT_FIELD_BYTES_0  );
            updateMask.setBit( UNIT_FIELD_BASEATTACKTIME );
            updateMask.setBit( UNIT_FIELD_BASEATTACKTIME ); updateMask.setBit( UNIT_FIELD_DISPLAYID  );
            updateMask.setBit( PLAYER_BYTES  ); updateMask.setBit( PLAYER_XP  );
            updateMask.setBit( PLAYER_NEXT_LEVEL_XP  ); updateMask.setBit( PLAYER_BYTES_2  );


            // Create other players for this client
            std::map< uint32, Character*> chars = world.getCharacterMap();
            for( std::map< uint32, Character*>::iterator i = chars.begin( ); i != chars.end( ); ++ i ) {
                if (pClient->getCurrentChar() != i->second && i->second != NULL){
                    i->second->CreateObject(&updateMask, &data,0);
                    pClient->SendMsg(&data);
                }
            }

            // recreate player for this client
            pClient->getCurrentChar()->CreateObject(&updateMask, &data, 0x00000001);
            pClient->getNetwork()->sendWData(&data);

            // these messages always get sent after a player; not waiting for them causes mad problems
              /*pClient->getNetwork()->getWData();
//            pClient->getNetwork()->getWData(&recv_data);
//            pClient->getNetwork()->getWData(&recv_data);

            // one of the three packets received above is a query time packet, so lets respond!
            // Or else CRASH.
            data.clear();
            data.Initialise(4, SMSG_QUERY_TIME_RESPONSE);
            data << (int32)time(NULL);
            pClient->SendMsg(&data);*/

            // Update our position for other characters
            data.clear();
            pClient->getCurrentChar()->UpdateMovement(0, &data);
//            world.SendZoneMessage(&data, pClient, 0);
            pClient->getCurrentChar()->SendMessageToSet(&data, false);

            std::map< uint32, Unit*> creatures = world.getCreatureMap();
            UpdateMask unitMask;
            unitMask.setCount(UNIT_BLOCKS);
            memset(unitMask.updateMask, 0, sizeof(uint32)*6);
            unitMask.setBit(OBJECT_FIELD_GUID );   unitMask.setBit(OBJECT_FIELD_GUID+1 );
            unitMask.setBit(OBJECT_FIELD_TYPE );   unitMask.setBit(OBJECT_FIELD_ENTRY );
            unitMask.setBit(OBJECT_FIELD_SCALE_X );   unitMask.setBit(UNIT_FIELD_HEALTH );
            unitMask.setBit(UNIT_FIELD_MAXHEALTH );    unitMask.setBit(UNIT_FIELD_LEVEL );
            unitMask.setBit(UNIT_FIELD_FACTIONTEMPLATE );   unitMask.setBit(UNIT_FIELD_DISPLAYID );
            unitMask.setBit(UNIT_NPC_FLAGS );

            for( std::map< uint32, Unit*>::iterator i = creatures.begin( ); i != creatures.end( ); ++ i ) {
                data.clear();
                i->second->CreateObject(&unitMask, &data, 0);
                pClient->SendMsg(&data);
            }

        };

    default: {}break;
    }

}

