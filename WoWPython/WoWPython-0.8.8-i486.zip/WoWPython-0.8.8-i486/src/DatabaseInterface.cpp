    #include "DatabaseInterface.h"
    
    #include "Sockets.h"
    
    #include "mysql.h"
    #include "Character.h"
    #include "Log.h"
    #include "Errors.h"
    #include "Path.h"
    #include "Quest.h"
    #include "UpdateMask.h"
    #include "WorldServer.h"
    #include "Item.h"
    #include "Database.h"
    
    uint32 DatabaseInterface::getGlobalTaxiNodeMask( uint32 curloc ) {
		std::stringstream TaxiMask;
			TaxiMask << "SELECT taxipath.destination FROM taxipath WHERE ( ( taxipath.source =" << curloc << " ) )";
		doQuery( TaxiMask.str( ).c_str( ) );
	    MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        uint32 mask = 0;
        while( row = mysql_fetch_row( res ) ) {
            mask |= 1 << ( atoi(row[0]) - 1 );
        }
        mysql_free_result( res );
        return mask;
    }
    
    uint32 DatabaseInterface::getNearestTaxiNode( float x, float y, float z, uint16 continent ) {
        std::stringstream Q;
         Q << " SELECT DISTINCT taxinodes.id, taxinodes.x, taxinodes.y, taxinodes.z FROM taxipath "
              " INNER JOIN taxinodes ON (taxipath.source = taxinodes.ID),  taxipathnodes "
              " WHERE    (    (taxipathnodes.continent = "
              << continent << " )    and    (taxipathnodes.index = 0)    and     (taxipathnodes.path = taxipath.id)   ) ";
        doQuery( Q.str( ).c_str( ) );
        uint32 nearest = 0;
        float distance = -1;
        float nx, ny, nz, nd;
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        while( row = mysql_fetch_row( res ) ) {
            nx = float( atof(row[1]) ) - x;
            ny = float( atof(row[2]) ) - y;
            nz = float( atof(row[3]) ) - z;
            nd = nx * nx + ny * ny + nz * nz;
            if( nd < distance || distance < 0 ) {
                distance = nd;
                nearest = atoi(row[0]);
            }
        }
        mysql_free_result( res );
        return nearest;
    }
    
    uint32 DatabaseInterface::getPath( uint32 source, uint32 destination ) {
        std::stringstream ss;
        ss << " select ID from taxipath "
            << " where source = " << source
            << " and destination = " << destination;
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        uint32 path = atoi(mysql_fetch_row( res )[0]);
        mysql_free_result( res );
        return path;
    }
    
    void DatabaseInterface::getPathNodes( uint32 path, Path *pathnodes ) {
        std::stringstream ss;
        ss << " SELECT X,Y,Z FROM taxipathnodes where path = "
            << path << " order by 'index' ";
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res = mysql_store_result( (MYSQL *)mDatabaseConnection );
        uint16 numrows = (uint16)mysql_num_rows( res );
        pathnodes->setLength( numrows );
        MYSQL_ROW row;
        for( uint32 a = 0; a < numrows; a++ ) {
            row = mysql_fetch_row( res );
            pathnodes->getNodes( )[ a ].x = (float)atof( row[ 0 ] );
            pathnodes->getNodes( )[ a ].y = (float)atof( row[ 1 ] );
            pathnodes->getNodes( )[ a ].z = (float)atof( row[ 2 ] );
        }
        mysql_free_result( res );
    }
    
	int DatabaseInterface::getTrainerSpellsCount( const uint32 *trainer ) {
        int answer;
		std::stringstream ss;
		const uint32 *guid = trainer; //pClient->getCurrentChar()->getSelectionPtr();
        ss << " select COUNT(*) as spellcount from trainers t INNER JOIN spells s ON t.spellGuid = s.ID where t.trainerGuid = "
            << guid[0] << " order by t.spellGuid "; 
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        row = mysql_fetch_row( res );
        if (row == NULL) {
            answer = 0;
        }
        else {
			answer = (int)atof ( row[0] );
            //answer = 1;
        }
        mysql_free_result( res );
        return answer;
    }

	int DatabaseInterface::getTrainerSpellsPrice( uint32 spellGuid, uint32 trainerGuid ) {
        int answer;
		std::stringstream ss;
        ss << " select t.price from trainers t where t.trainerGuid = "
            << trainerGuid << " and t.spellGuid = "
			<< spellGuid << " order by t.spellGuid "; 
		// select t.price from trainers where t.trainerGuid = <trainerGuid> and t.spellGuid = <spellGuid>
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        uint16 numrows = (uint16)mysql_num_rows( res );
        MYSQL_ROW row;
        for( uint32 a = 0; a < numrows; a++ ) {
            row = mysql_fetch_row( res );
			answer = int((uint32((uint32)atof ( row[ 0 ] )))); //set price
        }
        mysql_free_result( res );
        return answer;
    }

	int DatabaseInterface::addTrainerSpell ( const uint32 *trainer, uint32 iSpellGuid, uint32 iSpellPrice ) {
		const uint32 *guid = trainer; //pClient->getCurrentChar()->getSelectionPtr();
		char sql[512];
		sprintf(sql, "INSERT INTO trainers (`trainerGuid`, `spellGuid`, `price`) VALUES ('%u', '%i', '%i');", guid[0], (int)iSpellGuid, (int)iSpellPrice);
        doQuery( sql );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        /*MYSQL_ROW row;
        row = mysql_fetch_row( res );
        if (row == NULL) {
            answer = 0;
        }
        else {
            answer = 1;
        }*/
        mysql_free_result( res );
        return 0; //answer;
	}

	void DatabaseInterface::getTrainerSpells( Character * pChar, const uint32 *trainer, wowWData & data ) {
		/*
			sql: select * from trainers t INNER JOIN spells s ON t.spellGuid = s.ID where t.trainerGuid = <trainerGuid>;
			^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
			spell id:		2 (base-1 array) / 1 (base-0 array)
			level req.:		28 (base-1 array) / 27 (base-0 array)
			price:			3 (base-1 array) / 2 (base-0 array)
		*/
        std::stringstream ss;
		const uint32 *guid = trainer; //pClient->getCurrentChar()->getSelectionPtr();
		uint32 player_level, player_gold;
		player_level = pChar->getUpdateValue( UNIT_FIELD_LEVEL );
        player_gold = pChar->getUpdateValue( PLAYER_FIELD_COINAGE );
        ss << " select * from trainers t INNER JOIN spells s ON t.spellGuid = s.ID where t.trainerGuid = "
            << guid[0] << " order by t.spellGuid ";
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res = mysql_store_result( (MYSQL *)mDatabaseConnection );
        uint16 numrows = (uint16)mysql_num_rows( res );
        MYSQL_ROW row;
        for( uint32 a = 0; a < numrows; a++ ) {
            row = mysql_fetch_row( res );
			data << uint32((uint32)atof ( row[ 1 ] )); //spell id
			std::stringstream usedsql;
			usedsql << "SELECT COUNT(*) FROM char_spells WHERE spellId = " << row[ 1 ] << " AND charId = " << pChar->getGUID();
			doQuery( usedsql.str( ).c_str( ) );
			MYSQL_RES *resused = mysql_store_result( (MYSQL *)mDatabaseConnection );
			MYSQL_ROW rowused;
			rowused = mysql_fetch_row( resused );
			if((uint32)atof (rowused [ 0 ]) == 0) {
		    if(player_level>=uint32((uint32)atof ( row[ 27 ] ))) { //check if player is right level
				if(player_gold>=uint32((uint32)atof ( row[ 2 ] ))) { //check if player has money enough
					data << uint8(0); //ok (non zero = not ok)
				} else {
					data << uint8(1); //not ok
				}
			    } else {
				data << uint8(1); //not ok
			    }
			} else {
			    data << uint8(2); //used by character
			}
    			mysql_free_result( resused );
			data << uint32((uint32((uint32)atof ( row[ 2 ] )))); //set price
			data << uint32(0) << uint32(0);
			data << uint32((uint32((uint32)atof ( row[ 27 ] )))); //set required level
			data << uint32(0) << uint32(0) << uint32(0) << uint32(0) << uint8(0);
        }
        mysql_free_result( res );

		data << uint32(0x6c6c6548) << uint32(0x5220216f) << uint32(0x79646165);
        data << uint32(0x726f6620) << uint32(0x6d6f7320) << uint32(0x72742065);
        data << uint32(0x696e6961) << uint32(0x003f676e);
    }
    
    void DatabaseInterface::setCharacter( Character * diffChar ) {
        int i;
		char invtemp[30];
		WPAssert( diffChar );
        std::stringstream ss;
		std::string invstr;
        ss << "update characters set"
            " positionX = " << diffChar->m_positionX << ", "
            " positionY = " << diffChar->m_positionY << ", "
            " positionZ = " << diffChar->m_positionZ << ", "
            " orientation= " << diffChar->m_orientation << ", "
            " data = '";
            for( uint16 index = 0; index < UPDATE_BLOCKS; index ++ )
            {
                ss << diffChar->getUpdateValue(index) << " ";
            }
            ss << "', " << 
            " zoneId= " << diffChar->m_zoneId << ", "
            " mapId= " << diffChar->m_mapId  
            << " where guid = " << diffChar->m_guid[ 0 ];
        doQuery( ss.str( ).c_str( ) );
		invstr.empty();
		invstr = "delete from inventory where charGuid = ";
		sprintf(invtemp, "%d", diffChar->getGUID());
		invstr += invtemp;
        doQuery( invstr.c_str( ) );
		
		for(i = 0; i<39; i++)
		{
			if (diffChar->m_items[i].guid != 0)
			{
				invstr.empty();
				invstr = "INSERT INTO inventory (charGuid,inventorySlot,itemGuid,itemId) VALUES (";
				sprintf(invtemp, "%d", diffChar->getGUID());
				invstr += invtemp;
				invstr += ", ";
				sprintf(invtemp, "%d", i);
				invstr += invtemp;
				invstr += ", ";
				sprintf(invtemp, "%d", diffChar->m_items[i].guid);
				invstr += invtemp;
				invstr += ", ";
				sprintf(invtemp, "%d", diffChar->m_items[i].itemid);
				invstr += invtemp;
				invstr += " )";
				doQuery( invstr.c_str( ) );
			}
		}
        // save quest progress
        saveQuestStatus(diffChar);

        // Spells
        std::stringstream spellstr;
        spellstr << "DELETE FROM char_spells where charId=" << diffChar->getGUID();
        doQuery(spellstr.str().c_str());

        std::list<struct spells> spells = diffChar->getSpellList();
        std::list<struct spells>::iterator itr;
        for (itr = spells.begin(); itr != spells.end(); ++itr)
        {
            std::stringstream spellstr2;
            spellstr2 << "INSERT INTO char_spells (charId,spellId,slotId) VALUES "
                      << "(" << diffChar->getGUID() << ", " << itr->spellId << ", " << itr->slotId << ")";
            doQuery(spellstr2.str().c_str());
        }
    }
    
    void DatabaseInterface::removeCharacter( Character * newChar ) {
        if( strcmp( (char * ) newChar->m_name, "RandomGuy" ) ) {
            std::stringstream a; a << "delete from characters where guid = " << newChar->m_guid[ 0 ];
            doQuery( a.str( ).c_str( ) );

            std::stringstream b; b << "delete from char_spells where id = " << newChar->m_guid[ 0 ];
            doQuery( b.str( ).c_str( ) );

            std::stringstream c; c << "delete from inventory where charGuid = " << newChar->m_guid[ 0 ];
            doQuery( c.str( ).c_str( ) );

            std::stringstream d; d << "delete from queststatus where playerId = " << newChar->m_guid[ 0 ];
            doQuery( d.str( ).c_str( ) );

        }
    }
    
    std::set< Character *> DatabaseInterface::enumCharacters( int account_id) {
        std::set< Character *> temp;
        std::stringstream ss;
        ss << "select * from characters where acct=" << (int)account_id << "";
		std::string invstr;
  		char invtemp[20];
 
    	doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        if (!res) return temp;
        MYSQL_ROW row;
    	MYSQL_RES *invres;
        MYSQL_ROW invrow;
        Character * tempchar;
        while( row = mysql_fetch_row( res ) ) {
            tempchar = new Character( );
            strcpy( (char *)tempchar->m_name, row[ 3 ] );
            
            uint16 length = strlen(row[2])+1;
            uint8 *data = new uint8[length];
            memcpy(data, row[2], length);
    
            tempchar->LoadUpdateValues(data);
            tempchar->m_zoneId = atoi( row[ 8 ] );
            tempchar->m_mapId = atoi( row[ 7 ] );
            tempchar->m_positionX = (float)atof( row[ 4 ] );
            tempchar->m_positionY = (float)atof( row[ 5 ] );
            tempchar->m_positionZ = (float)atof( row[ 6 ] );
            tempchar->m_orientation = (float)atof( row[9] );
    
    /*
            tempchar->m_outfitId = atoi( row[ 11 ] );
            tempchar->m_guildId = atoi( row[ 17 ] );
            tempchar->m_petInfoId = atoi( row[ 18 ] );
            tempchar->m_petLevel = atoi( row[ 19 ] );
            tempchar->m_petFamilyId = atoi( row[ 20 ] );
  */
 
            // Inventory
  		    invstr = "select * from inventory where charGuid=";
  		    sprintf(invtemp, "%d", (int)tempchar->m_guid[ 0 ]);
  		    invstr += invtemp;
  		    invstr += "";
  		    doQuery( invstr.c_str( ) );
  		    invres = mysql_store_result( (MYSQL *)mDatabaseConnection );
  		    while( invrow = mysql_fetch_row( invres ) ) {
			    if (atol(invrow[2]) == 0 || atol(invrow[3]) == 0) {
				    continue;
			    }
  			    tempchar->m_items[(int)atoi(invrow[1])].guid = (uint32)atol(invrow[2]);
  			    tempchar->m_items[(int)atoi(invrow[1])].itemid = (uint32)atol(invrow[3]);
  		    }

            // Spells
            std::stringstream spellstr;
            spellstr << "SELECT * FROM char_spells WHERE charId=" << tempchar->m_guid[0];
            doQuery(spellstr.str().c_str());
  		    MYSQL_RES *spellres = mysql_store_result( (MYSQL *)mDatabaseConnection );
            MYSQL_ROW spellrow;
  		    while( spellrow = mysql_fetch_row( spellres ) ) {
			    tempchar->addSpell(atoi(spellrow[2]), atoi(spellrow[3]));
  		    }

            mysql_free_result( spellres );
  		    mysql_free_result( invres );

            temp.insert( tempchar );
        }
        mysql_free_result( res );
        return temp;
    }

	// <WoW Chile Dev Team> Start Change
	int DatabaseInterface::IsCharMoveExist(uint32 guid) {
        char query[300];
        strcpy(query,"");
        sprintf(query, "SELECT COUNT(*) FROM creatures_mov WHERE creatureId = '%u'", guid); 
        doQuery(query);
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        row = mysql_fetch_row( res );
		if( atoi(row[0]) > 0 ) //if not cero then mob can move
			return atoi(row[0]);
		else
			return 0;
	    mysql_free_result( res );
    }		
    // <WoW Chile Dev Team> Stop Change    

    int DatabaseInterface::IsNameTaken(char * charname) {
        int answer;
        char query[300];
        strcpy(query,"");
        sprintf(query, "SELECT * FROM characters WHERE name = '%s'", charname); 
        doQuery(query);
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        row = mysql_fetch_row( res );
        if (row == NULL) {
            answer = 0;
        }
        else {
            answer = 1;
        }
        mysql_free_result( res );
        return answer;
    }
    
    
    
    int DatabaseInterface::GetNameGUID(char * charname) {
        int Guid=-1;
        char query[300];
        strcpy(query,"");
        sprintf(query, "SELECT * FROM characters WHERE name = '%s'", charname); 
        doQuery(query);
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        row = mysql_fetch_row( res );
        if (row != NULL) {
            Guid = atoi(row[0]);
        }
        mysql_free_result( res );
        return Guid;
    }
    
    void DatabaseInterface::GetPlayerNameFromGUID(uint32 guid, uint8 *name)
    {
        std::stringstream ss;
        ss << "SELECT * FROM characters WHERE guid=" << guid;
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        if (res->row_count != 1)
        {
            name = NULL;
            return;
        }

        row = mysql_fetch_row( res );
        strcpy((char*)name, row[3]);
    }
    
    void DatabaseInterface::addCharacter( Character *newChar ) {
        std::stringstream ss;
        ss << "INSERT INTO characters "
           << "(data,name,acct,positionX,positionY,positionZ,orientation, zoneId, mapId,guid) "
           << "VALUES ('"; 
        
        for( uint16 index = 0; index < UPDATE_BLOCKS; index ++ )
        {
            ss << newChar->getUpdateValue(index) << " ";
        }
    
        ss << "', " 
           << "'" << newChar->m_name << "', "
           << newChar->m_accountId << ", "
           << (float)newChar->m_positionX << ", "
           << (float)newChar->m_positionY << ", "
           << (float)newChar->m_positionZ << ", "
           << (float)newChar->m_orientation << ", "
           << newChar->m_zoneId << ", "
           << newChar->m_mapId << ", "
           << newChar->getGUID() << " "
           << ")";
        
        doQuery( ss.str( ).c_str( ) );
    }
    
    
    int DatabaseInterface::doQuery( const char * query ) {
        Log::getSingleton( ).outString( (std::string("SQL: ") + query).c_str( ) );
        mysql_query( (MYSQL *)mDatabaseConnection, query );
        printf("%s", mysql_error((MYSQL*)mDatabaseConnection));
        return mysql_field_count( (MYSQL *)mDatabaseConnection );
    }
    
    
    // Logs in a client with username and password, or creates new account is username doesnt exist    
    int DatabaseInterface::Login(char* username, char* password) 
    {        
        Log::getSingleton( ).outString( "DB: Checking username..." );        
        char query[300];        
        strcpy(query, "");        
        sprintf(query, "SELECT * FROM accounts WHERE login='%s'", username);        
        doQuery(query);        
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );        
        MYSQL_ROW row;            
        if (!res) return -2;          
        if (res->row_count == 1){ // Match!            
            strcpy(query, "");            
            
            sprintf(query, "SELECT * FROM accounts WHERE login='%s' ", /*AND password='%s'", */ username/*, password*/);
            doQuery(query);            
            MYSQL_RES *login_res = mysql_store_result( (MYSQL *)mDatabaseConnection );            
            if (login_res->row_count == 1){                // select this account's character                
                row = mysql_fetch_row( login_res );                
                return atoi(row[0]);            
            }        
        }        
        else {
            
            // Check the config if we should auto create accounts
            if (!Database::getSingleton().isAutoCreateAccts()) return -3;

            // create new account withusername and password            
            strcpy(query, "");            
            sprintf(query, "INSERT INTO accounts (login, password) VALUES ('%s', '%s')", username, password);            
            doQuery(query);                
            // select the new account to get its ID #            
            strcpy(query, "");            
            sprintf(query, "SELECT * FROM accounts WHERE login='%s' AND password='%s'", username, password);            
            doQuery(query);            
            MYSQL_RES *login_res = mysql_store_result( (MYSQL *)mDatabaseConnection );            
            row = mysql_fetch_row( login_res );            
            return atoi(row[0]);        
        }            
        return -1;    
    }


    int DatabaseInterface::getAccountLvl(int account_id)
    {
        std::stringstream ss;
        ss << "SELECT gm FROM accounts WHERE acct=" << account_id;
        doQuery(ss.str().c_str());
        MYSQL_RES *res = mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        if (res->row_count >= 1){
            row = mysql_fetch_row(res);
            return atoi(row[0]);
        }

        // account id not found, default to 0
        return 0;
    }
    
    
    DatabaseInterface::DatabaseInterface( void * db ) : mDatabaseConnection( (MYSQL *)db ) { }
    
    DatabaseInterface::~DatabaseInterface( ) {
        mysql_close( (MYSQL *)mDatabaseConnection );
    }
    
    void DatabaseInterface::saveCreature(Unit *pUnit)
    {
        // then save all creatures
        std::stringstream ss;
        ss << "INSERT INTO creatures "
            "(name_id,positionX,positionY,positionZ,orientation,id,mapId,zoneId,data) "
            "VALUES ("
            "" << pUnit->getUpdateValue(OBJECT_FIELD_ENTRY) << ", "
            << pUnit->m_positionX << ", "
            << pUnit->m_positionY << ", "
            << pUnit->m_positionZ << ", "
            << pUnit->m_orientation << ", "
            << pUnit->m_guid[0] << ", "
            << pUnit->m_mapId << ", "
			<< pUnit->m_zoneId << ", "
            << "'";
            for( uint16 index = 0; index < UNIT_END; index ++ )
            {
                ss << pUnit->getUpdateValue(index) << " ";
            }
            ss << "') ";
        doQuery( ss.str( ).c_str( ) );
    
        printf("%s", mysql_error((MYSQL*)mDatabaseConnection));
    }
    
    void DatabaseInterface::loadCreatureNames(std::map< uint32, uint8*> & m_names)
    {
        std::stringstream ss;
        ss << "SELECT * FROM creature_names";
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        
        while( row = mysql_fetch_row( res ) ) {
            m_names[ atol(row[0]) ] = (uint8*)row[1];
        }
    }
    
    void DatabaseInterface::saveCreatureNames(std::map< uint32, uint8*> p_names)
    {
        std::stringstream ss2;
        ss2 << "DELETE FROM creature_names";
        doQuery( ss2.str( ).c_str( ) );
        for( std::map< uint32, uint8*>::iterator itr = p_names.begin( ); itr != p_names.end( ); ++ itr )
        {
            std::stringstream ss;
            ss << "INSERT INTO creature_names (name_id,creature_name) VALUES (" << itr->first << ", '" << itr->second << "')";
            doQuery( ss.str( ).c_str( ) );
        }
    }


    std::set<Unit*> DatabaseInterface::loadCreatures()
    {
        std::set< Unit *> temp;
        std::stringstream ss;
        ss << "SELECT * FROM creatures";
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
  		std::string invstr;
  		char invtemp[20];
    	MYSQL_RES *invres;
        MYSQL_ROW invrow;
        Unit * tempunit;
        while( row = mysql_fetch_row( res ) ) {
    
            uint16 length = strlen(row[7])+1;
            uint8 *data = new uint8[length];
            memcpy(data, row[7], length);
    
            uint8 * name = WorldServer::getSingleton().getCreatureName(atol(row[8]));
			if( !name ) name = (uint8 *)"ERROR_NO_CREATURENAME_FOR_ENTRY";

            tempunit = new Unit();
            tempunit->Create(atol(row[0]), name, (float)atof(row[1]), (float)atof(row[2]), (float)atof(row[3]), (float)atof(row[4]));
            tempunit->setZone((uint16)atol(row[5]));
            tempunit->setMapId((uint16)atol(row[6]));
			// <WoW Chile Dev Team> Start Change
			tempunit->creature_RandomMove=((int)atoi(row[9]));
			tempunit->creature_Run=((int)atoi(row[10]));
			// <WoW Chile Dev Team> Stop Change
			tempunit->LoadUpdateValues(data);
			if (tempunit->getUpdateValue( UNIT_NPC_FLAGS ) & 4) {
				//omg we got a vendor!!! 
				//load his goods :)
				invstr.empty();
				invstr = "select * from vendors where vendorGuid=";
				sprintf(invtemp, "%d", (int)tempunit->m_guid[ 0 ]);
				invstr += invtemp;
  				invstr += "";
				doQuery( invstr.c_str( ) );
				invres = mysql_store_result( (MYSQL *)mDatabaseConnection );
				while( invrow = mysql_fetch_row( invres ) ) {
//					tempchar->m_items[atol(invrow[1])].guid = atol(invrow[2]);
//					tempchar->m_items[atol(invrow[1])].itemid = atol(invrow[3]);
					if (tempunit->getItemCount() >= 128) {
						//this should never happen unless someone has been fucking with the dbs
						//complain and break :P
						Log::getSingleton( ).outString( "Vendor has too many items. Check the DB!" );
						break;
					}
					tempunit->setItemId(tempunit->getItemCount() , (uint32)atol(invrow[1]));
					tempunit->setItemAmount(tempunit->getItemCount() , (int)atoi(invrow[2]));
					tempunit->increaseItemCount();
				}
				mysql_free_result( invres );
			}

            if (tempunit->getUpdateValue( UNIT_NPC_FLAGS ) & 2) {
                // load assigned quests
                std::stringstream ss2;
                ss2 << "SELECT * FROM creaturequestrelation WHERE creatureId=" << tempunit->getGUID() << " ORDER BY questId";
                doQuery( ss2.str( ).c_str( ) );
                MYSQL_RES *res2 =  mysql_store_result( (MYSQL *)mDatabaseConnection );
                MYSQL_ROW row2;
                while( row2 = mysql_fetch_row( res2 ) ) {
                    uint32 quest_id = atol(row2[1]);
                    tempunit->addQuest(quest_id);
                }
            }
    		// <WoW Chile Dev Team> Start Change
			MYSQL_RES *invres1;
			MYSQL_ROW invrow1;
			tempunit->creature_canMove=0;
			//tempunit->TimeTomove=0;
			tempunit->creature_state=0;
			tempunit->current_path=0;
			tempunit->current_dir=0;			
			invstr.empty();
			invstr = "select COUNT(creatureId) from creatures_mov where creatureId=";
			sprintf(invtemp, "%d", (int)tempunit->m_guid[ 0 ]);
			invstr += invtemp;
  			invstr += "";
			doQuery( invstr.c_str( ) );
			invres1 = mysql_store_result( (MYSQL *)mDatabaseConnection );
			invrow1 = mysql_fetch_row( invres1 );
			if( atoi(invrow1[0]) > 0 ) //if not cero then mob can move
			{				
				tempunit->creature_canMove=1;
				tempunit->creature_paths=atoi(invrow1[0]);
				invstr.empty();
				invstr = "select X,Y,Z from creatures_mov where creatureId=";
				sprintf(invtemp, "%d", (int)tempunit->m_guid[ 0 ]);
				invstr += invtemp;
  				invstr += "";
				doQuery( invstr.c_str( ) );
				MYSQL_RES *invres2 = mysql_store_result( (MYSQL *)mDatabaseConnection );
				MYSQL_ROW invrow2;
				//invrow2 = mysql_fetch_row( invres2 );
				int col1=0;
				while( invrow2 = mysql_fetch_row( invres2 ) )
				{
					tempunit->creature_cord[col1][0]=atof(invrow2[0]);
					tempunit->creature_cord[col1][1]=atof(invrow2[1]);
					tempunit->creature_cord[col1][2]=atof(invrow2[2]);
					col1++;
				}
			}
			// <WoW Chile Dev Team> Finish Change
            temp.insert(tempunit);
        }
        mysql_free_result( res );
        return temp;
    }
    
    
    void DatabaseInterface::setHighestGuids()
    {
        uint32 max=0;
        uint32 maxchar=0,maxcreature=0;
        doQuery( "SELECT MAX(guid) FROM characters" );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        if( res ) {
            MYSQL_ROW row;
            row = mysql_fetch_row( res );
            if (row[0])
                WorldServer::getSingleton().m_hiCharGuid = atol(row[0])+1;
        }
    
        mysql_free_result( res );
    
        doQuery( "SELECT MAX(id) FROM creatures" );
        res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        if( res ) {
            MYSQL_ROW row;
            row = mysql_fetch_row( res );
            if (row[0])
                WorldServer::getSingleton().m_hiCreatureGuid = atol(row[0])+1;
        }
        mysql_free_result( res );
        doQuery( "SELECT MAX(itemGuid) FROM inventory" );
        res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
		if( res ) {
            MYSQL_ROW row1;
            row1 = mysql_fetch_row( res );
			if (row1[0]) {
                WorldServer::getSingleton().m_hiItemGuid = atol(row1[0])+1;
			}
		}   
        mysql_free_result( res );
    }
    
    void DatabaseInterface::loadItems()
    {
    	std::stringstream ss;
        ss << "SELECT * FROM items";
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        Item *pItem;
    	int i;
    	while( row = mysql_fetch_row( res ) ) {
            if( atol(row[0]) ) {
    		    pItem = new Item;
    		    pItem->Create(0, atol(row[0]));
    		    pItem->Class = atol(row[1]);
    		    pItem->SubClass = atol(row[2]);
    		    pItem->name1 = row[3];
    		    pItem->name2 = row[4];
    		    pItem->name3 = row[5];
    		    pItem->name4 = row[6];
    		    pItem->DisplayInfoID = atol(row[7]); 
    		    pItem->OverallQualityID = atol(row[8]); 
    		    pItem->Flags = atol(row[9]); 
    		    pItem->Buyprice = atol(row[10]); 
    		    pItem->Sellprice = atol(row[11]); 
    		    pItem->Inventorytype = atol(row[12]); 
    		    pItem->AllowableClass = atol(row[13]); 
    		    pItem->AllowableRace = atol(row[14]); 
    		    pItem->ItemLevel = atol(row[15]); 
    		    pItem->RequiredLevel = atol(row[16]); 
    		    pItem->RequiredSkill = atol(row[17]); 
    		    pItem->RequiredSkillRank = atol(row[18]); 
    		    pItem->MaxCount = atol(row[19]); 
    		    pItem->Stackable = atol(row[20]); 
    		    pItem->ContainerSlots = atol(row[21]);
    		    for(i = 0; i < 20; i+=2) {
    			    pItem->BonusStat[i/2] = atol(row[22 + i]);
    			    pItem->BonusAmount[i/2] = atol(row[23 + i]);
    		    }
    		    for(i = 0; i < 15; i+=3) {
    			    pItem->MinimumDamage[i/3] = atol(row[42 + +i]); 
    			    pItem->MaximumDamage[i/3] = atol(row[43 +i]);
    			    pItem->DamageType[i/3] = atol(row[44 + i]);
    		    }
    		    for(i = 0; i < 6; i++) {
    			    pItem->Resistances[i] = atol(row[57 + i]);
    		    }
    		    pItem->Delay = atol(row[63]); 
    		    pItem->AmmunitionType = atol(row[64]); 
    		    pItem->MaxDurability = atol(row[65]); 
    		    for(i = 0; i < 30; i+=6) {
    			    pItem->SpellID[i/6] = atol(row[66+i]);
    			    pItem->SpellTrigger[i/6] = atol(row[67+i]); 
    			    pItem->SpellCharges[i/6] = atol(row[68+i]);
    			    pItem->SpellCooldown[i/6] = atol(row[69+i]);
    			    pItem->SpellCategory[i/6] = atol(row[70+i]);
    			    pItem->SpellCategoryCooldown[i/6] = atol(row[71+i]); 
    		    }
    		    pItem->Bonding = atol(row[96]);  
    		    pItem->Description = row[97];  
    		    pItem->Pagetext = atol(row[98]);  
    		    pItem->LanguageID = atol(row[99]);  
    		    pItem->PageMaterial = atol(row[100]);  
    		    pItem->StartQuestID = atol(row[101]);  
    		    pItem->LockID = atol(row[102]);  
    		    pItem->Material = atol(row[103]);  
    		    pItem->Sheathetype = atol(row[104]);
    		    pItem->Unknown1 = atol(row[105]);
    		    pItem->Unknown2 = 0;
    		    WorldServer::getSingleton().AddItem(pItem);
            }
    	}
    }
    
    void DatabaseInterface::loadQuests()
    {
        std::stringstream ss;
        ss << "SELECT * FROM quests";
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        while( row = mysql_fetch_row( res ) ) {
            Quest *pQuest = new Quest;
            pQuest->m_questId = atol(row[0]);
            pQuest->m_zone = atol(row[1]);
            pQuest->m_title = row[2];
            pQuest->m_details = row[3];
            pQuest->m_objectives = row[4];
            pQuest->m_completedText = row[5];
            pQuest->m_incompleteText = row[6];
            pQuest->m_targetGuid = atol(row[7]);
            pQuest->m_questItemId[0] = atol(row[8]);
            pQuest->m_questItemId[1] = atol(row[9]);
            pQuest->m_questItemId[2] = atol(row[10]);
            pQuest->m_questItemId[3] = atol(row[11]);
            pQuest->m_questItemCount[0] = atol(row[12]);
            pQuest->m_questItemCount[1] = atol(row[13]);
            pQuest->m_questItemCount[2] = atol(row[14]);
            pQuest->m_questItemCount[3] = atol(row[15]);
            pQuest->m_questMobId[0] = atol(row[16]);
            pQuest->m_questMobId[1] = atol(row[17]);
            pQuest->m_questMobId[2] = atol(row[18]);
            pQuest->m_questMobId[3] = atol(row[19]);
            pQuest->m_questMobCount[0] = atol(row[20]);
            pQuest->m_questMobCount[1] = atol(row[21]);
            pQuest->m_questMobCount[2] = atol(row[22]);
            pQuest->m_questMobCount[3] = atol(row[23]);
            pQuest->m_choiceRewards = atoi(row[24]);
            pQuest->m_choiceItemId[0] = atol(row[25]);
            pQuest->m_choiceItemId[1] = atol(row[26]);
            pQuest->m_choiceItemId[2] = atol(row[27]);
            pQuest->m_choiceItemId[3] = atol(row[28]);
            pQuest->m_choiceItemId[4] = atol(row[29]);
            pQuest->m_choiceItemCount[0] = atol(row[30]);
            pQuest->m_choiceItemCount[1] = atol(row[31]);
            pQuest->m_choiceItemCount[2] = atol(row[32]);
            pQuest->m_choiceItemCount[3] = atol(row[33]);
            pQuest->m_choiceItemCount[4] = atol(row[34]);
            pQuest->m_itemRewards = atoi(row[35]);
            pQuest->m_rewardItemId[0] = atol(row[36]);
            pQuest->m_rewardItemId[1] = atol(row[37]);
            pQuest->m_rewardItemId[2] = atol(row[38]);
            pQuest->m_rewardItemId[3] = atol(row[39]);
            pQuest->m_rewardItemId[4] = atol(row[40]);
            pQuest->m_rewardItemCount[0] = atol(row[41]);
            pQuest->m_rewardItemCount[1] = atol(row[42]);
            pQuest->m_rewardItemCount[2] = atol(row[43]);
            pQuest->m_rewardItemCount[3] = atol(row[44]);
            pQuest->m_rewardItemCount[4] = atol(row[45]);
            pQuest->m_rewardGold = atol(row[46]);
            pQuest->m_questXp = atol(row[47]);
            pQuest->m_originalGuid = atol(row[48]);
            pQuest->m_requiredLevel = atol(row[49]);
            pQuest->m_previousQuest = atol(row[50]);
            WorldServer::getSingleton().addQuest(pQuest);
        }
    
        mysql_free_result(res);
    }
    
    
    void DatabaseInterface::loadQuestStatus(Character *pChar)
    {
        std::stringstream ss;
        ss << "SELECT * FROM queststatus WHERE playerId=" << pChar->getGUID();
        doQuery( ss.str( ).c_str( ) );
        MYSQL_RES *res =  mysql_store_result( (MYSQL *)mDatabaseConnection );
        MYSQL_ROW row;
        while( row = mysql_fetch_row( res ) ) {
            uint32 status = atol(row[2]);
            quest_status qs;
            qs.status = status;
            qs.quest_id = atol(row[1]);
            qs.m_questMobCount[0] = atol(row[3]);
            qs.m_questMobCount[1] = atol(row[4]);
            qs.m_questMobCount[2] = atol(row[5]);
            qs.m_questMobCount[3] = atol(row[6]);
            qs.m_questItemCount[0] = atol(row[7]);
            qs.m_questItemCount[1] = atol(row[8]);
            qs.m_questItemCount[2] = atol(row[9]);
            qs.m_questItemCount[3] = atol(row[10]);
    
            pChar->loadExistingQuest(qs);
        }
    
        mysql_free_result( res );  
    }
    
    void DatabaseInterface::saveQuestStatus(Character *pChar)
    {
        std::stringstream ss;
        ss << "DELETE FROM queststatus WHERE playerId=" << pChar->getGUID();
        doQuery( ss.str( ).c_str( ) );
    
        std::map<uint32, struct quest_status> temp = pChar->getQuestStatusMap();
        for( std::map<uint32, struct quest_status>::iterator i = temp.begin( ); i != temp.end( ); ++ i ) {
            std::stringstream ss2;
            ss2 << "INSERT INTO queststatus (playerId,questId,status,questMobCount1,questMobCount2,questMobCount3,questMobCount4,"
                << "questItemCount1,questItemCount2,questItemCount3,questItemCount4) VALUES "
                << "(" << pChar->getGUID() << ", " 
                << i->first << ", " 
                << i->second.status << ", "
                << i->second.m_questMobCount[0] << ", "
                << i->second.m_questMobCount[1] << ", "
                << i->second.m_questMobCount[2] << ", "
                << i->second.m_questMobCount[3] << ", "
                << i->second.m_questItemCount[0] << ", "
                << i->second.m_questItemCount[1] << ", "
                << i->second.m_questItemCount[2] << ", "
                << i->second.m_questItemCount[3]            
                << ")";
            doQuery(ss2.str( ).c_str( ) );
            printf("%s", mysql_error((MYSQL*)mDatabaseConnection));
        }
    }


