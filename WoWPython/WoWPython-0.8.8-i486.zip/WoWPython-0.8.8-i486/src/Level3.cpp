 // <WoW Chile Dev Team> Start Change
//Level3.cpp for handle Mobs and npcs movement.
///////////////////////////////////////////////
//  Admin Movement Commands
//

#include "ChatHandler.h"
#include "NetworkInterface.h"
#include "GameClient.h"
#include "WorldServer.h"
#include "Character.h"
#include "Opcodes.h"
#include "Database.h"
#include "GameObject.h"

#define world WorldServer::getSingleton()

int ChatHandler::ParseLvl3Commands(uint8* textCompare, uint16 text_length)
{
    GameClient *pClient = m_pClient;
    wowWData data;
	
	if(strncmp((char*)textCompare,"#help",5)==0)
    {
        int arraysize=4; //Numbers of lines of text in the gmMessage belove
 	    uint8 gmMessage[][250] = {
 		    "Team Python Game Moderator commands:",
 		    "#addmove     Add your current location for move.",
 		    "#random       Set random movement! 1=ranom(default), 0=path",
 		    "#run            Set run or walk! 1=run, 0=walk(default)"
 	    };
 	    for (int size=0;size <= arraysize-1;size++ )
 	    {
 		    uint8 buf[256];
 		    sprintf((char*)buf,"%s	",  gmMessage[size]);
 		    FillMessageData(&data, 0x09, pClient, buf);
 		    pClient->SendMsg( &data );
 	    }
        return 1;
	}
    // <WoW Chile Dev Team> Start Change
    ///////////////////////////////////////////////////////////////////////////////////////
    // addmovepoint add move point to npc or mob
    // #addmove
    else if(strncmp((char*)textCompare,"#addmove",8)==0)
   {	
		const uint32 *guid;
		float X,Y,Z;
        guid = pClient->getCurrentChar()->getSelectionPtr();
        if (guid[0] == 0) return 1;					
		int maxpoint=15;
		DatabaseInterface *dbi = Database::getSingleton( ).createDatabaseInterface( );
        char sql[512];
		
		if(pClient->getDB()->IsCharMoveExist(guid[0]) >= maxpoint )
		{
			pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
			uint8 syntaxError[] = "You have allready set all points.";
			FillMessageData(&data, 0x09, pClient, syntaxError);	
			pClient->SendMsg( &data );   
			return 1;
		}																		
		else if (pClient->getDB()->IsCharMoveExist(guid[0])==0) 
		{
			std::map<uint32, Unit*>::iterator itr = world.mCreatures.find(guid[0]);
			X=itr->second->getPositionX();
			Y=itr->second->getPositionY();
			Z=itr->second->getPositionZ();
			sprintf(sql, "insert into creatures_mov (creatureId,X,Y,Z) values ('%u', '%f', '%f', '%f')", guid[0], X,Y,Z);
			dbi->doQuery(sql);
		}
		
		sprintf(sql, "insert into creatures_mov (creatureId,X,Y,Z) values ('%u', '%f', '%f', '%f')", guid[0], pClient->getCurrentChar()->getPositionX(), pClient->getCurrentChar()->getPositionY(),pClient->getCurrentChar()->getPositionZ());
		dbi->doQuery(sql);
		Database::getSingleton( ).removeDatabaseInterface(dbi);
		
		pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
		uint8 syntaxError[] = "Point stored in DB.";
		FillMessageData(&data, 0x09, pClient, syntaxError);
		pClient->SendMsg( &data );      
        return 1;
	}
	///////////////////////////////////////////////////////////////////////////////////////
    // random set not random, or set a ransom movement to a mob 
    // #random <option>    || 1 Set random movement   || 0 set a follow path in orden movement
	else if(strncmp((char*)textCompare,"#random ",8)==0)
    {	
		strtok((char*)textCompare, " ");
        char* option = strtok(NULL, " ");
        if (!option){
			pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
			uint8 syntaxError[] = "ERROR: Syntaxis !random <option>";
			FillMessageData(&data, 0x09, pClient, syntaxError);
			pClient->SendMsg( &data );      
            return 1;
        }
		else
		{
			if( (atoi(option)!=1) && (atoi(option)!=0) )
			{
				pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
				uint8 syntaxError[] = "ERROR: Bad Command use 0 or 1";
				FillMessageData(&data, 0x09, pClient, syntaxError);
				pClient->SendMsg( &data );      
				return 1;
			}
		}

		const uint32 *guid;
        guid = pClient->getCurrentChar()->getSelectionPtr();
        if (guid[0] == 0) return 1;						
		DatabaseInterface *dbi = Database::getSingleton( ).createDatabaseInterface( );
        char sql[512];
			
		sprintf(sql, "update creatures set moverandom = '%i' where id = '%u'",atoi(option), guid[0]);
		dbi->doQuery(sql);
		Database::getSingleton( ).removeDatabaseInterface(dbi);
		
		pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
		uint8 syntaxError[] = "all ok...you must restar server to see";
		FillMessageData(&data, 0x09, pClient, syntaxError);
		pClient->SendMsg( &data );      
        return 1;
	}
	///////////////////////////////////////////////////////////////////////////////////////
    // run set a running movement to a mob or npc
    // #run <option>    || 1 run   || 0 walk
	else if(strncmp((char*)textCompare,"#run ",5)==0)
    {	
		strtok((char*)textCompare, " ");
        char* option = strtok(NULL, " ");
        if (!option){
			pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
			uint8 syntaxError[] = "ERROR: Syntaxis !run <option>";
			FillMessageData(&data, 0x09, pClient, syntaxError);
			pClient->SendMsg( &data );      
            return 1;
        }
		else
		{
			if( (atoi(option)!=1) && (atoi(option)!=0) )
			{
				pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
				uint8 syntaxError[] = "ERROR: Bad Command use 0 or 1 to set";
				FillMessageData(&data, 0x09, pClient, syntaxError);
				pClient->SendMsg( &data );      
				return 1;
			}
		}

		const uint32 *guid;
        guid = pClient->getCurrentChar()->getSelectionPtr();
        if (guid[0] == 0) return 1;						
		DatabaseInterface *dbi = Database::getSingleton( ).createDatabaseInterface( );
        char sql[512];
			
		sprintf(sql, "update creatures set running = '%i' where id = '%u'",atoi(option), guid[0]);
		dbi->doQuery(sql);
		Database::getSingleton( ).removeDatabaseInterface(dbi);
		
		pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
		uint8 syntaxError[] = "all ok...you must restar server to see";
		FillMessageData(&data, 0x09, pClient, syntaxError);
		pClient->SendMsg( &data );      
        return 1;
	}

    return 0;
}
 // <WoW Chile Dev Team> Stop Change
