#include "SpellHandler.h"
#include "NetworkInterface.h"
#include "Opcodes.h"
#include "Log.h"
#include "Character.h"
#include "WorldServer.h"
#include "Database.h"
#include "UpdateMask.h"
#include "Character.h"

#include "DatabaseInterface.h"
#include "Sockets.h"
#include "mysql.h"

#define world WorldServer::getSingleton()

NPCHandler::NPCHandler()
{

}

NPCHandler::~NPCHandler()
{

}

void NPCHandler::HandleMsg( wowWData & recv_data, GameClient *pClient )
{
	wowWData data;
    char f[256];
    sprintf(f, "WORLD: NPC Opcode: 0x%.4X", recv_data.opcode);
    Log::getSingleton( ).outString( f );
	switch (recv_data.opcode)
	{   
        case MSG_TABARDVENDOR_ACTIVATE:
            {
                uint32 guid, guid2;
				recv_data >> guid >> guid2;                
                data.Initialise( 8, MSG_TABARDVENDOR_ACTIVATE );
				data << guid << guid2;
				pClient->SendMsg( &data );             
            }break;

        case CMSG_BANKER_ACTIVATE:
            {  
				uint32 bguid, bguid2;
				recv_data >> bguid >> bguid2;

				data.Initialise( 8, SMSG_SHOW_BANK );
				data << bguid << bguid2;
				pClient->SendMsg( &data );
            }break;

			/*case CMSG_TRAINER_LIST: //needs to be changed to the vendor-list
			{ 
                uint32 player_level, player_gold;
                player_level = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_LEVEL );
                player_gold = pClient->getCurrentChar( )->getUpdateValue( PLAYER_FIELD_COINAGE );
                uint32 guid1, guid2;
                uint32 count;
                //count = 2; //we can have more then 2 spells now ;)
				recv_data >> guid1 >> guid2;

				DatabaseInterface *dbi = Database::getSingleton().createDatabaseInterface(); //
				count = (uint32)dbi->getTrainerSpellsCount ( pClient );
                data.Initialise( (38*count)+48, SMSG_TRAINER_LIST ); //set packet size - count = number of spells
				data << guid1 << guid2;
                data << uint32(0) << count;

				dbi->getTrainerSpells( pClient, data);
				Database::getSingleton().removeDatabaseInterface( dbi );

				pClient->SendMsg( &data );
			}break;*/

        case CMSG_TRAINER_LIST:
			{ 
                uint32 player_level, player_gold;
                player_level = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_LEVEL );
                player_gold = pClient->getCurrentChar( )->getUpdateValue( PLAYER_FIELD_COINAGE );
                uint32 guid1, guid2;
                uint32 count;
                //count = 2; //we can have more then 2 spells now ;)
				recv_data >> guid1 >> guid2;

				DatabaseInterface *dbi = Database::getSingleton().createDatabaseInterface(); //
				const uint32 *trainer = pClient->getCurrentChar()->getSelectionPtr();
				count = (uint32)dbi->getTrainerSpellsCount ( trainer );
                data.Initialise( (38*count)+48, SMSG_TRAINER_LIST ); //set packet size - count = number of spells
				data << guid1 << guid2;
                data << uint32(0) << count;

				dbi->getTrainerSpells( pClient->getCurrentChar(), pClient->getCurrentChar()->getSelectionPtr(), data);
				Database::getSingleton().removeDatabaseInterface( dbi );

				/*
					sql: select * from trainers t INNER JOIN spells s ON t.spellGuid = s.ID where t.trainerGuid = <trainerGuid>;
					^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^
					spell id:		2 (base-1 array) / 1 (base-0 array)
					level req.:		28 (base-1 array) / 27 (base-0 array)
					price:			3 (base-1 array) / 2 (base-0 array)
				*/

                /*data << uint32(2120); //Spell_id
                //Check for stuff here....
                if(player_level>=3 ) {
                    if(player_gold>=200) {
                        data << uint8(0); //available (non zero = no)
                    }
                    else {
                        data << uint8(1);
                    }
                }
                else {
                    data << uint8(1);
                }
                data << uint32(200); // Cost (2 silver)
                data << uint32(0) << uint32(0); // ?, ?
                data << uint32(3); //Required level
                data << uint32(0) << uint32(0) << uint32(0) << uint32(0) << uint8(0); //?????

                data << uint32(0x6c6c6548) << uint32(0x5220216f) << uint32(0x79646165);
                data << uint32(0x726f6620) << uint32(0x6d6f7320) << uint32(0x72742065);
                data << uint32(0x696e6961) << uint32(0x003f676e);*/
				pClient->SendMsg( &data );
//H  e  l  l  o  !     R  e  a  d  y     f  o  r     s  o  m  e     t  r  a  i  n  i  n  g  ?  
//48 65 6c 6c 6f 21 20 52 65 61 64 79 20 66 6f 72 20 73 6f 6d 65 20 74 72 61 69 6e 69 6e 67 3f 00
			}break;

        case CMSG_TRAINER_BUY_SPELL:
			{				
                uint32 guid1, guid2, spell_id, player_gold;
				int price;
				const uint32 * guid = pClient->getCurrentChar()->getSelectionPtr(); //guid for trainer
                recv_data >> guid1 >> guid2 >> spell_id;  
                player_gold = pClient->getCurrentChar( )->getUpdateValue( PLAYER_FIELD_COINAGE );

                data.clear();
                data.Initialise( 12, SMSG_TRAINER_BUY_SUCCEEDED );
				data << guid1 << guid2 << spell_id;
				pClient->SendMsg( &data );

				DatabaseInterface *dbi = Database::getSingleton().createDatabaseInterface();
				price = dbi->getTrainerSpellsPrice ( spell_id, guid[0] );
				Database::getSingleton().removeDatabaseInterface( dbi );

				if(player_gold >= (uint32)price) {

					pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_COINAGE, player_gold-price );

                data.clear();
                data.Initialise( 36, SMSG_SPELL_START );
                data << guid1 << guid2;
                data << guid1 << guid2;
				data << spell_id;
                data << uint16(0) << uint32(0);
                data << uint16(2);
                data << pClient->getCurrentChar()->getGUID() << uint32(0);
				pClient->SendMsg( &data );

                data.clear();
                data.Initialise( 4, SMSG_LEARNED_SPELL );
				data << spell_id;
				pClient->SendMsg( &data );
					pClient->getCurrentChar()->addSpell(spell_id);

                data.clear();
                data.Initialise( 42, SMSG_SPELL_GO );
                data << guid1 << guid2;
                data << guid1 << guid2;
				data << spell_id;
                data << uint8(0) << uint8(1) << uint8(1);
                data << pClient->getCurrentChar()->getGUID() << uint32(0);
                data << uint8(0) << uint16(2);
                data << pClient->getCurrentChar()->getGUID() << uint32(0);
				pClient->SendMsg( &data );

                data.clear();
                data.Initialise( 32, SMSG_SPELLLOGEXECUTE );
                data << guid1 << guid2;
				data << spell_id;
                data << uint32(1);
                data << uint32(0x24);
                data << uint32(1);
                data << pClient->getCurrentChar()->getGUID() << uint32(0);
				pClient->SendMsg( &data );
				}
			}break;

            case CMSG_PETITION_SHOWLIST:
			{				
                uint32 guid1, guid2;
                unsigned char tdata[21] =
                {
                   0x01, 0x01, 0x00, 0x00, 0x00, 0xe7, 0x16, 0x00, 0x00, 0xef, 0x23, 0x00, 0x00, 0xe8, 0x03, 0x00, 0x00, 0x01, 0x00, 0x00, 0x00
                };
                recv_data >> guid1 >> guid2;
                data.clear();
				data.Initialise( 12, SMSG_PETITION_SHOWLIST );
				data << guid1 << guid2;
                data.writeData( &tdata );
				pClient->SendMsg( &data );				
			}break;

            case MSG_AUCTION_HELLO:
			{
                uint32 guid1, guid2;
                recv_data >> guid1 >> guid2;
                data.Initialise( 12, MSG_AUCTION_HELLO );
				data << guid1 << guid2;
                data << uint32(0);
				pClient->SendMsg( &data );
			}break;

    default: {}break;
    }
}

