/////////////////////////////////////////////////
//  Normal User Chat Commands
//

#include "ChatHandler.h"
#include "NetworkInterface.h"
#include "GameClient.h"
#include "WorldServer.h"
#include "Character.h"
#include "Opcodes.h"
#include "Database.h"

int ChatHandler::ParseLvl0Commands(uint8* textCompare, uint16 text_length)
{
    GameClient *pClient = m_pClient;
    wowWData data;
    
    if(strncmp((char*)textCompare,".help",5)==0)
    {
        int arraysize=8; //Numbers of lines of text in the helpMessage belove
 		uint8 helpMessage[][250] = {
 			"Team Python General User Commands:",
 			".info     Displays the current number of online players",
 			".mount    Gives you a mount (LvL 15 and above)",
 			".dismount Dismounts you from your mount or a taxi",
 			".thel     Teleports you to Loch Modan.",
 			".storm    Teleports you to Stormwind City",
 			".iron     Teleports you to Ironforge",
 			".under    Teleports you to The Undercity"
 		};
 		for (int size=0;size <= arraysize-1;size++ )
 		{
 			uint8 buf[256];
 			sprintf((char*)buf,"%s	",  helpMessage[size]);
 			FillMessageData(&data, 0x09, pClient, buf);
 			pClient->SendMsg( &data );
 		}
        
        return 1;
    }
    else if(strncmp((char*)textCompare,".info",5)==0)
    {
        uint32 clientsNum = WorldServer::getSingleton().GetClientsConnected();
        uint8 buf[256];
        
        //more info come.. right now only display users connected
        sprintf((char*)buf,"Number of users connected: %i", (int) clientsNum);
        FillMessageData(&data, 0x09, pClient, buf);
        pClient->SendMsg( &data );
        
        return 1;
    }
    else if(strncmp((char*)textCompare,".dismount",9)==0)
    {
        pClient->getCurrentChar( )->setUpdateValue(UNIT_FIELD_MOUNTDISPLAYID , 0);
        pClient->getCurrentChar( )->removeUnitFlag( 0x003000 );

        // Remove the "player locked" flag, to allow movement
        if (pClient->getCurrentChar( )->getUpdateValue(UNIT_FIELD_FLAGS) & 0x000004 )
            pClient->getCurrentChar( )->removeUnitFlag( 0x000004 );

        float dmspeed = 7.5; // Exact value of normal player speed

        data.Initialise( 12, SMSG_FORCE_SPEED_CHANGE );
        data << pClient->getCurrentChar( )->getUpdateValue( OBJECT_FIELD_GUID );
        data << pClient->getCurrentChar( )->getUpdateValue( OBJECT_FIELD_GUID + 1 );
        data << dmspeed;
        
        pClient->getCurrentChar( )->SendMessageToSet( &data, true );
                
        return 1;
    }
    else if (strncmp((char*)textCompare,".thel",5)==0)
    {
        MovePlayer(pClient, -5395.57f, -3015.79f, 327.58f);
        return 1;
    }
    else if (strncmp((char*)textCompare,".storm",6)==0)
    {
        MovePlayer(pClient, -8913.23f, 554.633f, 93.7944f);
        return 1;
    }
    else if (strncmp((char*)textCompare,".iron",5)==0)
    {
        MovePlayer(pClient, -4981.25f, -881.542f, 501.66f);
        return 1;
    }
    else if (strncmp((char*)textCompare,".under",6)==0)
    {
        MovePlayer(pClient, 1586.48f, 239.562f, -52.149f);
        return 1;
    }

   // <WoW Chile Dev Team> Start Change
    else if(strncmp((char*)textCompare,".mount ",6)==0)
    {   
              Character *_char = pClient->getCurrentChar();
			  int char_race = _char->GetRace();
			  int char_level= _char->GetLevel();
			  char* pDisplayId;			  
			  if(char_level >= 15)
			  {
				if (char_race == 1) // humans
				{
					char* horse[6];
					horse[0]="236";
					horse[1]="237";
					horse[2]="238";
					horse[3]="239";
					horse[4]="235";
					horse[5]="908";
					pDisplayId = horse[rand()%6];
				}
				else if (char_race == 2) // orcs
				{
					char* wolfs[5];
					wolfs[0]="2320";
					wolfs[1]="2327";
					wolfs[2]="2328";
					wolfs[3]="207";
					wolfs[4]="246";
					pDisplayId = wolfs[rand()%5];
				}
				else if (char_race == 3) // dwarfs
				{
					char* dwmount[5];
					dwmount[0]="2784";
					dwmount[1]="2787";
					dwmount[2]="2785";
					dwmount[3]="2736";
					dwmount[4]="2786";
					pDisplayId = dwmount[rand()%5];
				}
				else if (char_race == 4) // elfs
				{
					char* tiger[6];
					tiger[0]="616";
					tiger[1]="632";
					tiger[2]="1056";
					tiger[3]="320";
					tiger[4]="321";
					tiger[5]="748"; 
					pDisplayId = tiger[rand()%6];
				}
				else if (char_race == 5) // undeads
				{
					pDisplayId ="5050";
				}
				/*else if (char_race == 6) // taurents
				{
					pDisplayId = "1147";
				}*/				
				else if (char_race == 7) // gnomos 
				{
					pDisplayId = "6544";
				}
				else if (char_race == 8) // trolls
				{
					char* dino[7];
					dino[0]="180";
					dino[1]="322";
					dino[2]="675";
					dino[3]="787";
					dino[4]="960";
					dino[5]="1960";
					dino[6]="1337";
					pDisplayId = dino[rand()%7];
				}
				
				if (char_race != 6) // if character is not Taurent
				{									
					uint16 display_id = atoi(pDisplayId);
                    // first create the mount
					pClient->getCurrentChar( )->addUnitFlag(0x001000);                   
					pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_MOUNTDISPLAYID , display_id );
                    // now mount it.  this must be done separately for it to animate while moving for some reason.                    
					pClient->getCurrentChar( )->addUnitFlag( 0x002000 );
				}

				// speeduo
				float mspeed = 25;
                data.Initialise( 12, SMSG_FORCE_SPEED_CHANGE );
                data << pClient->getCurrentChar( )->getUpdateValue( OBJECT_FIELD_GUID );
                data << pClient->getCurrentChar( )->getUpdateValue( OBJECT_FIELD_GUID + 1 );
                data << mspeed;
                pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
				uint8 syntaxError[] = "Activated Mount.";
				FillMessageData(&data, 0x09, pClient, syntaxError);
                pClient->SendMsg( &data );           
			  }
			  else
			  {
                pClient->getCurrentChar( )->SendMessageToSet( &data, true );              
				uint8 syntaxError[] = "You Need level 15.";
				FillMessageData(&data, 0x09, pClient, syntaxError);
                pClient->SendMsg( &data );
			  }
        return 1;
		// <WoW Chile Dev Team> Stop Change
    }
    else if (strncmp((char*)textCompare,".guid",5)==0)
    {
        const uint32 *guid;
        guid = pClient->getCurrentChar()->getSelectionPtr();
        if (guid[0] == 0) return 1;

        DatabaseInterface *dbi = Database::getSingleton( ).createDatabaseInterface( );
        uint8 buf[256];
        sprintf((char*)buf,"The Creatures Guid is: %i", (int) guid[0]);
        FillMessageData(&data, 0x09, pClient, buf);
        pClient->SendMsg( &data );
        return 1;
    }
    return 0;
}
