#include "ObjectMgr.h"
#include "UpdateMask.h"
#include "WorldServer.h"
#include "Character.h"
#include "Item.h"

void ObjectMgr::BuildCreatePlayerMsg(Character *pNewChar, std::list<wowWData*>* msglist)
{
    int i=0, invcount=0;
    UpdateMask playerMask, invUpdateMask;

    SetCreatePlayerBits(&playerMask);
	for(i = 0; i<46; i+=2)
	{
		if (pNewChar->getGuidBySlot(i/2) != 0) {
			pNewChar->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i , pNewChar->getGuidBySlot(i/2),  playerMask.updateMask);
			pNewChar->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i + 1 , 0x00000040,  playerMask.updateMask);
		}
	}

    // Create Item for this player
    for(invcount = 0; invcount < 23; invcount++)
	{
		if ((pNewChar->getGuidBySlot(invcount) != 0) && (pNewChar->getGuidBySlot(invcount) != NULL)){

			invUpdateMask.clear();
			invUpdateMask.setCount(0x02);
			Item* tempitem = new Item;
            wowWData *itemdata = new wowWData;

			invUpdateMask.setBit( OBJECT_FIELD_GUID );
			invUpdateMask.setBit( OBJECT_FIELD_GUID+1 );
			invUpdateMask.setBit( OBJECT_FIELD_TYPE );
			invUpdateMask.setBit( OBJECT_FIELD_ENTRY );
			invUpdateMask.setBit( OBJECT_FIELD_SCALE_X );
			invUpdateMask.setBit( OBJECT_FIELD_PADDING );
			invUpdateMask.setBit( ITEM_FIELD_OWNER );
			invUpdateMask.setBit( ITEM_FIELD_CONTAINED );
			invUpdateMask.setBit( ITEM_FIELD_OWNER +1 );
			invUpdateMask.setBit( ITEM_FIELD_CONTAINED +1 );
			invUpdateMask.setBit( ITEM_FIELD_STACK_COUNT );
			tempitem->Create(pNewChar->getGuidBySlot(invcount),pNewChar->getItemIdBySlot(invcount));
			tempitem->setUpdateValue( OBJECT_FIELD_GUID , pNewChar->getGuidBySlot(invcount) ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( OBJECT_FIELD_GUID+1 , 0x00000040 ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( OBJECT_FIELD_TYPE , 0x00000003 ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( OBJECT_FIELD_ENTRY , pNewChar->getItemIdBySlot(invcount) ,invUpdateMask.updateMask);
			tempitem->setUpdateFloatValue( OBJECT_FIELD_SCALE_X , 1.0f ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( OBJECT_FIELD_PADDING , 0xeeeeeeee ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( ITEM_FIELD_OWNER , pNewChar->getGUID() ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( ITEM_FIELD_CONTAINED , pNewChar->getGUID() ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( ITEM_FIELD_OWNER +1 , 0 ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( ITEM_FIELD_CONTAINED +1 , 0 ,invUpdateMask.updateMask);
			tempitem->setUpdateValue( ITEM_FIELD_STACK_COUNT , 1 ,invUpdateMask.updateMask);

			tempitem->CreateObject(&invUpdateMask, itemdata, 0);
            msglist->push_back(itemdata);
			delete tempitem;
		}
	}

    wowWData *data = new wowWData;
    pNewChar->CreateObject(&playerMask, data, 0);
    msglist->push_back(data);
}

void ObjectMgr::SetCreatePlayerBits(UpdateMask *updateMask)
{
    // Set update mask for player creation
    updateMask->setCount(PLAYER_BLOCKS);
    updateMask->setBit(OBJECT_FIELD_GUID);          
    updateMask->setBit(OBJECT_FIELD_TYPE);
    updateMask->setBit(OBJECT_FIELD_SCALE_X);         
    updateMask->setBit(OBJECT_FIELD_PADDING);
    updateMask->setBit(UNIT_FIELD_HEALTH ); 
    updateMask->setBit(UNIT_FIELD_POWER1  );        
    updateMask->setBit(UNIT_FIELD_POWER2  );
    updateMask->setBit(UNIT_FIELD_POWER3  );        
    updateMask->setBit(UNIT_FIELD_POWER4 );
    updateMask->setBit(UNIT_FIELD_MAXHEALTH  );
    updateMask->setBit(UNIT_FIELD_MAXPOWER1  );        
    updateMask->setBit(UNIT_FIELD_MAXPOWER2  );
    updateMask->setBit(UNIT_FIELD_MAXPOWER3  );        
    updateMask->setBit(UNIT_FIELD_MAXPOWER4 );
    updateMask->setBit(UNIT_FIELD_LEVEL  );            
    updateMask->setBit(UNIT_FIELD_FACTIONTEMPLATE  );
    updateMask->setBit(UNIT_FIELD_BYTES_0 );          
    updateMask->setBit(PLAYER_FIELD_STAT0  );
    updateMask->setBit(PLAYER_FIELD_STAT1 );            
    updateMask->setBit(PLAYER_FIELD_STAT2 );
    updateMask->setBit(PLAYER_FIELD_STAT3  );            
    updateMask->setBit(PLAYER_FIELD_STAT4  );
    updateMask->setBit(PLAYER_FIELD_POSSTAT0  );        
    updateMask->setBit(PLAYER_FIELD_POSSTAT1 );
    updateMask->setBit(PLAYER_FIELD_POSSTAT2 );        
    updateMask->setBit(PLAYER_FIELD_POSSTAT3 );
    updateMask->setBit(PLAYER_FIELD_POSSTAT4 );        
    updateMask->setBit(PLAYER_FIELD_NEGSTAT0 );        
    updateMask->setBit(PLAYER_FIELD_NEGSTAT1 );
    updateMask->setBit(PLAYER_FIELD_NEGSTAT2 );        
    updateMask->setBit(PLAYER_FIELD_NEGSTAT3 );
    updateMask->setBit(PLAYER_FIELD_NEGSTAT4 );            
    updateMask->setBit(PLAYER_FIELD_COINAGE  );
    updateMask->setBit(UNIT_FIELD_FLAGS  );
    updateMask->setBit(UNIT_FIELD_BASEATTACKTIME );   
    updateMask->setBit(UNIT_FIELD_BASEATTACKTIME+1  );
    updateMask->setBit(UNIT_FIELD_BOUNDINGRADIUS );  
    updateMask->setBit(UNIT_FIELD_COMBATREACH   );
    updateMask->setBit(UNIT_FIELD_DISPLAYID  );       
    updateMask->setBit(UNIT_FIELD_MINDAMAGE);
    updateMask->setBit(UNIT_FIELD_MAXDAMAGE );       
    updateMask->setBit(PLAYER_FIELD_ATTACKPOWER );
    updateMask->setBit(PLAYER_FIELD_ATTACKPOWERMODPOS );
    updateMask->setBit(PLAYER_FIELD_ATTACKPOWERMODNEG );
    updateMask->setBit(PLAYER_BYTES);
    updateMask->setBit(PLAYER_BYTES_2 );
    updateMask->setBit(PLAYER_XP );                 
    updateMask->setBit(PLAYER_NEXT_LEVEL_XP);
    updateMask->setBit(PLAYER_REST_STATE_EXPERIENCE );                         
    updateMask->setBit(UNIT_FIELD_MOUNTDISPLAYID);
}


void ObjectMgr::SetCreateUnitBits(UpdateMask &npcMask)
{
    npcMask.setCount(UNIT_BLOCKS);
    npcMask.setBit(OBJECT_FIELD_GUID);   
    npcMask.setBit(OBJECT_FIELD_GUID+1);
    npcMask.setBit(OBJECT_FIELD_TYPE);   
    npcMask.setBit(OBJECT_FIELD_ENTRY);
    npcMask.setBit(OBJECT_FIELD_SCALE_X);
    npcMask.setBit(UNIT_FIELD_HEALTH);
    npcMask.setBit(UNIT_FIELD_MAXHEALTH );
    npcMask.setBit(UNIT_FIELD_LEVEL );
    npcMask.setBit(UNIT_FIELD_FACTIONTEMPLATE );
    npcMask.setBit(UNIT_FIELD_FLAGS  );
    npcMask.setBit(UNIT_FIELD_DISPLAYID );
    npcMask.setBit(UNIT_FIELD_MOUNTDISPLAYID );
    npcMask.setBit(UNIT_NPC_FLAGS );
    npcMask.setBit(UNIT_FIELD_COMBATREACH );
    npcMask.setBit(UNIT_FIELD_MAXDAMAGE  );
    npcMask.setBit(UNIT_FIELD_MINDAMAGE );
    npcMask.setBit(UNIT_FIELD_BASEATTACKTIME);
    npcMask.setBit(UNIT_FIELD_BASEATTACKTIME+1);
    npcMask.setBit(UNIT_FIELD_BOUNDINGRADIUS);
}

void ObjectMgr::BuildCreateUnitMsg(Unit *pNewUnit, wowWData *data)
{
    UpdateMask unitMask;
    if (!pNewUnit->IsDead())
    {
        SetCreateUnitBits(unitMask);
        pNewUnit->CreateObject(&unitMask, data, 0);
    }
}