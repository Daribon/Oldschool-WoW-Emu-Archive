/////////////////////////////////////////////////
//  GM Chat Commands
//

#include "ChatHandler.h"
#include "NetworkInterface.h"
#include "GameClient.h"
#include "WorldServer.h"
#include "Character.h"
#include "Opcodes.h"
#include "Database.h"

#define world WorldServer::getSingleton()

int ChatHandler::ParseLvl1Commands(uint8* textCompare, uint16 text_length)
{
        GameClient *pClient = m_pClient;
        wowWData data;

    if(strncmp((char*)textCompare,"!help",5)==0)
    {
        int arraysize=16; //Numbers of lines of text in the gmMessage belove
 	    uint8 gmMessage[][250] = {
 		    "Team Python Game Moderator commands:",
 		    "!prog      Teleports you to Programer's Island",
 		    "!item      Allows you to assign an item to a vendor!",
 		    "!move      Allows you to move to any co-ordinates on the map!",
 		    "!spawntaxi Spawns a taxi vendor.",
 		    "!spell     Allows you to assign an skill/spell to a trainer!",
 		    "!lvl       Allows you to change your level.",
 		    "!cinematic Not working?",
 		    "!announce  Sends a Global message",
 		    "!spawn     Allows you to spawn a NPC.",
 		    "!delete    Allows you to delete a NPC.",
 		    "!unitflags Unknown function.",
 		    "!gmon      Turns on the <gm> tag.",
 		    "!gmoff     Turns off the <gm> tag.",
 		    "!learn     Teaches you a spell",
 		    "!worldport Moves your character, may crash!"
 	    };
 	    for (int size=0;size <= arraysize-1;size++ )
 	    {
 		    uint8 buf[256];
 		    sprintf((char*)buf,"%s	",  gmMessage[size]);
 		    FillMessageData(&data, 0x09, pClient, buf);
 		    pClient->SendMsg( &data );
 	    }

        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    //  Send a Broadcast to everyone on the server
    //  !announce <message>
    else if (strncmp((char*)textCompare,"!announce ",10)==0) //Europa
    {
        int tempint = strlen((char*)textCompare); // get the length of the string
        char temp[256];
        int j = 0;
        for (int i = 10; i < tempint; i++) //sets the loop
        {
            temp[j] = textCompare[i];
            j++;
            if(i+1 == tempint) 
            {
                temp[j] = NULL;
            };
        }

        uint8 pAnnounce[256];
        sprintf((char*)pAnnounce, "BROADCAST: %s", temp);   //Adds BROADCAST:
        WorldServer::getSingleton().SendWorldText((uint8*)pAnnounce); // send message
        return 1;
    }

    else if (strncmp((char*)textCompare,"!prog",5)==0)
    {
        MovePlayer(pClient, 16843.00f, 16308.00f, 94.00f);
        return 1;
    }

    else if (strncmp((char*)textCompare,"!spawntaxi",10)==0)
    {
        SpawnCreature(pClient, "Taxi", 20, 8, 1 , 1);
        return 1;
    }    

    ///////////////////////////////////////////////////////////////////////////////////////
    // Add an Item to a vender
    // !item <itemId> <amount>
    else if (strncmp((char*)textCompare,"!item ",6)==0)
    {
        const uint32 *guid;
        guid = pClient->getCurrentChar()->getSelectionPtr();
        if (guid[0] == 0) return 1;
        strtok((char*)textCompare, " ");

        uint32 item = 1;
        char* pitem = strtok(NULL, " ");
        if (!pitem) return 1;

        item = atoi(pitem);

        uint32 amount = 1;
        char* pamount = strtok(NULL, " ");
        if (pamount)
            amount = atoi(pamount);

        DatabaseInterface *dbi = Database::getSingleton( ).createDatabaseInterface( );
        uint8 buf[256];
        char sql[512];

        sprintf(sql, "insert into vendors values ('%u', '%i', '%i')", guid[0], (int) item, (int) amount);
        dbi->doQuery(sql);
        
        std::map<uint32, Unit*>::iterator itr = world.mCreatures.find(guid[0]);
        itr->second->setItemId(itr->second->getItemCount() , (int)item);
        itr->second->setItemAmount(itr->second->getItemCount() , (int)amount);
        itr->second->increaseItemCount();
        
        sprintf((char*)buf,"Added item");
        
        FillMessageData(&data, 0x09, pClient, buf);
        pClient->SendMsg( &data );
        
        return 1;
    }    

    ///////////////////////////////////////////////////////////////////////////////////////
    // Add a spell to a trainer
    // !spell <spellId> <price>
    else if (strncmp((char*)textCompare,"!spell ",7)==0) 
    {
        const uint32 *guid;
        guid = pClient->getCurrentChar()->getSelectionPtr();
        if (guid[0] == 0) return 1;
        strtok((char*)textCompare, " ");

        uint32 spell = 1;
        char* pspell = strtok(NULL, " ");
        if (!pspell)
            return 1;
        
        spell = atoi(pspell);

        uint32 price = 1;
        char* pprice = strtok(NULL, " ");
        if (pprice)
            price = atoi(pprice);

        if(price < 0)
            price = (0 - price);
        else if (price == 0)
            price = 100; //1 silver sounds like a good default

        DatabaseInterface *dbi = Database::getSingleton().createDatabaseInterface();
        const uint32 * trainer = pClient->getCurrentChar()->getSelectionPtr();
        dbi->addTrainerSpell ( trainer, spell, price ); //add spell to trainer
        Database::getSingleton().removeDatabaseInterface( dbi ); //clean up

        uint8 buf[256];
        sprintf((char*)buf,"You added the following spell to trainer %i: %i", (int)guid[0], spell);
        FillMessageData(&data, 0x09, pClient, buf);
        pClient->SendMsg( &data );

        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    // Alter your level
    // !lvl <new level>
    else if (strncmp((char*)textCompare, "!lvl ", 5)==0) 
    {
        //change level of char
        strtok((char*)textCompare, " ");
        char* pLvl = strtok(NULL, " ");
        if (!pLvl) return 1;
        
        uint32 lvl = atoi(pLvl);
        if(lvl >= 1024)   lvl = 1024;
        else if (lvl < 1) lvl = 1;

        pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_LEVEL, lvl );
        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    // Spawn a creature
    // !spawn <modelId> <npcFlags> <faction_id> <level> <name>
    else if(strncmp((char*)textCompare, "!spawn ", 7)==0)
    {
        strtok((char*)textCompare, " ");
        char* pEntry = strtok(NULL, " ");

        if (!pEntry){
            return 1;
        }

        uint32 npcFlags = 0;
        char* pFlags = strtok(NULL, " ");
        if (pFlags){
            npcFlags = atoi(pFlags);
        }

        uint32 faction_id;
        char* pFaction = strtok(NULL, " ");
        if (!pFaction){
            return 1;
        }

        uint32 level = 1;
        char* pLevel = strtok(NULL, " ");
        if (pLevel){
            level = atoi(pLevel);
        }

        char* pName = strtok(NULL, "%");
        if (!pName){
            uint8 syntaxError[] = "Syntax Error!  .spawn command changed to:\n.spawn model npcflags faction level name\nSet faction to 1 to be friendly.";
            FillMessageData(&data, 0x09, pClient, syntaxError);
            pClient->SendMsg( &data );
            return 1;
        }
        if (pEntry[1]=='x'){
            uint8 syntaxError[]= "Please use decimal.";
            FillMessageData(&data, 0x09, pClient, syntaxError);
            pClient->SendMsg( &data );
            return 1;
        }

        faction_id = atol(pFaction);
        uint16 display_id = atoi(pEntry);             

        SpawnCreature(pClient, pName, display_id, npcFlags, faction_id, level);

        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    // Delete currently selected NPC
    else if(strncmp((char*)textCompare,"!delete",7)==0)
    {
        const uint32 *guid;
        guid = pClient->getCurrentChar()->getSelectionPtr();
        if (guid[0] == 0) return 1;

        data.clear();
        data.Initialise(8, SMSG_DESTROY_OBJECT);
        data << (uint32)guid[0] << uint32(guid[1]);
        pClient->getCurrentChar()->SendMessageToSet(&data, true);
 		std::map<uint32, Unit*>::iterator itr = world.mCreatures.find(guid[0]);

		for( WorldServer::CharacterMap::iterator iter = world.mCharacters.begin( ); iter != world.mCharacters.end( ); ++ iter )
			iter->second->RemoveInRangeObject( itr->second );
       
		delete itr->second;
		world.mCreatures.erase(itr);

        DatabaseInterface *dbi = Database::getSingleton( ).createDatabaseInterface( );
        char sql[512];
        sprintf(sql, "DELETE FROM creatures WHERE id=%u", guid[0]);
        dbi->doQuery(sql);
        Database::getSingleton( ).removeDatabaseInterface(dbi);

        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    // Moves to coords within the same map
    // !move <x> <y> <z>
    else if(strncmp((char*)textCompare,"!move ",6)==0)
    {
        //Replace all spaces by 0, so it converts the single in multiple strings, delimited by the old spaces
        for(int i=6; textCompare[i]!=0;)
        {
            if(textCompare[i]==' ')
                textCompare[i]=0;
            i++;
        }

        //Get the x,y and z position from the new multiple strings
        uint32 posy=strlen((char*)textCompare+6)+7;
        uint32 posz=strlen((char*)textCompare+posy)+posy+1;
        float x = (float)atof((char*)textCompare+6);
        float y = (float)atof((char*)textCompare+posy);
        float z = (float)atof((char*)textCompare+posz);

        MovePlayer(pClient, x, y, z);
        return 1;                                                                     
    }
    
    ///////////////////////////////////////////////////////////////////////////////////////
    // Toggle Unit flags
    // !unitflags <flag>
    else if(strncmp((char*)textCompare,"!unitflags ",10)==0)
    {
        strtok((char*)textCompare, " ");
        char* pFlags = strtok(NULL, " ");
        if (!pFlags){
            return 1;
        }

        uint32 flags = atoi(pFlags);

        if (pClient->getCurrentChar( )->getUpdateValue(UNIT_FIELD_FLAGS) & flags)
            pClient->getCurrentChar( )->removeUnitFlag( flags );
        else 
            pClient->getCurrentChar( )->addUnitFlag( flags );

        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    // Trigger opening cinematic
    // !cinematic <id>
    else if(strncmp((char*)textCompare,"!cinematic ",10)==0)
    {
        strtok((char*)textCompare, " ");
        char* pCinematic = strtok(NULL, " ");
        if (!pCinematic){
            return 1;
        }

        uint32 cinematic = atoi(pCinematic);

        data.Initialise( 4, SMSG_TRIGGER_CINEMATIC );
        data << cinematic;
        pClient->SendMsg( &data );

        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    // Learn a new spell / ability
    // !learn <id>
    else if(strncmp((char*)textCompare,"!learn",6)==0)
    {
        strtok((char*)textCompare, " ");
        char* pSpell = strtok(NULL, " ");
        if (!pSpell){
            return 1;
        }
        uint32 Spell = atol(pSpell);

        data.clear();
        data.Initialise( 4, SMSG_LEARNED_SPELL );
        data << Spell;
        pClient->SendMsg( &data );
        pClient->getCurrentChar()->addSpell((uint16)Spell);

        return 1;
    }

    else if(strncmp((char*)textCompare,"!gmon",5)==0)
    {
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_BYTES_2, 0x8);
        return 1;
    }

    else if(strncmp((char*)textCompare,"!gmoff",6)==0)
    {
        pClient->getCurrentChar( )->setUpdateValue( PLAYER_BYTES_2, 0x0);
        return 1;
    }

    ///////////////////////////////////////////////////////////////////////////////////////
    // Worldport to a new map and x,y,z
    // !worldport <map id> <x> <y> <z>
    else if(strncmp((char*)textCompare,"!worldport ",11)==0)
    {
        strtok((char*)textCompare, " ");
        char* pContinent = strtok(NULL, " ");
        if (!pContinent){
            return 1;
        }

        char* px = strtok(NULL, " ");
        char* py = strtok(NULL, " ");
        char* pz = strtok(NULL, " ");

        if (!px || !py || !pz){
            return 1;
        }

        uint8 c = atoi(pContinent);
        float x = (float)atof(px);
        float y = (float)atof(py);
        float z = (float)atof(pz);

        smsg_NewWorld(pClient, c, x, y, z);
        return 1;
    }  
	///////////////////////////////////////////////////////////////////////////////////////
    //  Appear to players location. Only works if they are on the same continent atm.
    //  !appear <player>
	else if (strncmp((char*)textCompare,"!appear ",8)==0) // -- europa
            {
				// all this code wasn't written by me :s
					strtok((char*)textCompare, " ");
					char* pName = strtok(NULL, "%");
                    
					if (!pName){
						delete [] textCompare;
						return 1;
					}
					Character *chr = NULL;

					WorldServer::ClientSet::iterator itr;
					for (itr = world.mClients.begin(); itr != world.mClients.end(); itr++) {
						if( strcmp(((GameClient*)(*itr))->getCharacterName(), pName) == 0 )
						{
							chr = ((GameClient*)(*itr))->getCurrentChar();
						}
					}

					if (chr)
					{
						float x = chr->getPositionX();
						float y = chr->getPositionY();
						float z = chr->getPositionZ();

						uint8 buf[256];
						uint8 buf0[256];
						sprintf((char*)buf,"Appearing at %s's location.", chr->getName());  // -- europa
						FillMessageData(&data, 0x09, pClient, buf);
						pClient->SendMsg( &data );

						// -- europa --
						MovePlayer(pClient, chr->getPositionX(), chr->getPositionY(), chr->getPositionZ());

						sprintf((char*)buf0,"%s is appearing to your location.", pClient->getCurrentChar()->getName());
						FillMessageData(&data, 0x09, pClient, buf0);
						WorldServer::getSingleton().SendMessageToPlayer(&data, chr->getGUID());
						// -- europa --
					}
					else
					{
						uint8 buf[256];
						sprintf((char*)buf,"Character (%s) does not exist or is not logged in.", pName);
						FillMessageData(&data, 0x09, pClient, buf);
						pClient->SendMsg( &data );
					}						
					delete [] textCompare;
					return 1;
	}

	///////////////////////////////////////////////////////////////////////////////////////
    //  Summons a player to your current location. Only works if they are on the same continent atm.
    //  !summon <player>
	else if (strncmp((char*)textCompare,"!summon ",8)==0) // -- europa
    {
		strtok((char*)textCompare, " ");
		char* pName = strtok(NULL, "%");
                    
		if (!pName){
			delete [] textCompare;
			return 1;
		}
		Character *chr = NULL;

		WorldServer::ClientSet::iterator itr;
		for (itr = world.mClients.begin(); itr != world.mClients.end(); itr++) {
			if( strcmp(((GameClient*)(*itr))->getCharacterName(), pName) == 0 )
			{
				chr = ((GameClient*)(*itr))->getCurrentChar();
			}
		}

		if (chr)
		{
			// get <player> position
			float x = pClient->getCurrentChar()->getPositionX();
			float y = pClient->getCurrentChar()->getPositionY();
			float z = pClient->getCurrentChar()->getPositionZ();
						
			
			// send message to user
			uint8 buf[256];
			uint8 buf0[256];
			sprintf((char*)buf,"You are summoning %s.", chr->getName());
			FillMessageData(&data, 0x09, pClient, buf);
			pClient->SendMsg( &data );

			wowWData data; 

			// teleport
			chr->TeleportAck(&data, x, y, z);
			pClient->getNetwork( )->sendWData(&data);
		    chr->BuildHeartBeat(&data);

			world.SendGlobalMessage(&data, pClient);
									
			chr->setPosition(x,y,z,0,true);

			// send message to player
			sprintf((char*)buf0,"You are being summoned by %s.", pClient->getCurrentChar()->getName());
			FillMessageData(&data, 0x09, pClient, buf0);
			WorldServer::getSingleton().SendMessageToPlayer(&data, chr->getGUID());
		}
		else
		{
			uint8 buf[256];
			sprintf((char*)buf,"Character (%s) does not exist or is not logged in.", pName);
			FillMessageData(&data, 0x09, pClient, buf);
			pClient->SendMsg( &data );
		}						
		delete [] textCompare;
		return 1;
	}
    //fincambio
    return 0;
}