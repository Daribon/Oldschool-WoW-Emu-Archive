#include "Combat.h"
#include "NetworkInterface.h"
#include "Log.h"
#include "GameClient.h"
#include "Opcodes.h"
#include "Character.h"
#include "WorldServer.h"
#include "UpdateMask.h"
#include "Stats.h"

#define world WorldServer::getSingleton()

void CombatHandler::HandleMsg( wowWData & recv_data, GameClient *pClient )
{
    wowWData data;
    char f[256];
    sprintf(f, "WORLD: Combat Opcode 0x%.4X from %u", recv_data.opcode, pClient->getCurrentChar()->getGUID());
    Log::getSingleton( ).outString( f );
    switch (recv_data.opcode)
    {
        case CMSG_ATTACKSWING:
	    {
            uint32 mguid[2], pguid;
		    pguid = pClient->getCurrentChar()->getGUID();
            recv_data >> mguid[0] >> mguid[1];

		    // AttackSwing
            Log::getSingleton( ).outString( "WORLD: Recvd CMSG_ATTACKSWING Message" );

            WPAssert( world.mCreatures.find(mguid[0]) != world.mCreatures.end() );
            Unit *pEnemy = world.mCreatures[mguid[0]];
            mguid[1] = pEnemy->getGUIDHigh();

            pClient->getCurrentChar()->addStateFlag(UF_ATTACKING);
            smsg_AttackStart(pClient->getCurrentChar(), pEnemy);
    }break;

    case CMSG_ATTACKSTOP:
	    {
		    uint32 mguid[2];
            mguid[0] = *(pClient->getCurrentChar()->getSelectionPtr());
            mguid[1] = *(pClient->getCurrentChar()->getSelectionPtr()+1);
            smsg_AttackStop((Unit*)pClient->getCurrentChar(), mguid);

            pClient->getCurrentChar()->clearStateFlag(UF_ATTACKING);
//            pClient->getCurrentChar()->removeUnitFlag(0x00080000);
	    }break;
    }
}


//================================================================================================
//  AttackerStateUpdate
//  This function determines whether there is a hit, and the resultant damage
//================================================================================================
void CombatHandler::AttackerStateUpdate(Unit *pAttacker, Unit *pVictim)
{
    if (pVictim->getUpdateValue(UNIT_FIELD_HEALTH) == 0 || 
        pAttacker->getUpdateValue(UNIT_FIELD_HEALTH) == 0 ) 
        return;

    wowWData data;
    uint32 hit_status = 0xe2;

    uint32 damage = CalculateDamage(pAttacker);

    uint32 some_value = 0xffffffff;
    some_value = 0x0;

    data.clear();
    data.Initialise(61, SMSG_ATTACKERSTATEUPDATE);
    data.writeData( hit_status );   // Attack flags
    data.writeData( pAttacker->getGUID() );
    data.writeData( pAttacker->getGUIDHigh() );
    data.writeData( pVictim->getGUID() );
    data.writeData( pVictim->getGUIDHigh() );
    data.writeData( damage );
    data.writeData( uint8(1) );     // Damage type counter

    // for each...
    data.writeData( uint32(0) );    // Damage type, // 0 - white font, 1 - yellow
    data.writeData( uint32(0x0) );  // damage float
    data.writeData( damage );       // Damage amount
    data.writeData( uint32(0) );    // damage absorbed

    data.writeData( uint32(1) );    // new victim state
    data.writeData( uint32(0) );    // victim round duraction
    data.writeData( uint32(0) );    // additional spell damage amount
    data.writeData( uint32(0) );    // additional spell damage id
    data.writeData( uint32(0) );    // Damage amount blocked

    pAttacker->SendMessageToSet(&data, true);
    printf("AttackerStateUpdate:  %u attacked %u for %u dmg.\n", pAttacker->getGUID(), pVictim->getGUID(), damage);

    DealDamage(pAttacker, pVictim, damage);
}


void CombatHandler::smsg_AttackStop(Unit* pAttacker, uint32 victim_guid[2])
{
	uint32 attacker_guid[2];
	attacker_guid[0] = pAttacker->getGUID();
	attacker_guid[1] = pAttacker->getGUIDHigh();
	wowWData data;
    data.Initialise( 20, SMSG_ATTACKSTOP );
    data << attacker_guid[0] << attacker_guid[1] << victim_guid[0] << victim_guid[1] << uint32( 0 );
//    world.SendUnitAreaMessage(&data, pAttacker);
    pAttacker->SendMessageToSet(&data, true);
    printf("%u stopped attacking %u\n", attacker_guid[0], victim_guid[0]);

}

void CombatHandler::smsg_AttackStart(Unit* pAttacker, Unit* pVictim)
{
    // Prevent user from ignoring attack speed and stopping and start combat really really fast
    if (pAttacker->canAttack())
    {
        AttackerStateUpdate(pAttacker, pVictim);
        pAttacker->setAttackTime();
    }

    // Send out ATTACKSTART
    wowWData data;
    data.clear();
    data.Initialise( 16, SMSG_ATTACKSTART );
    data << pAttacker->getGUID() << pAttacker->getGUIDHigh() << pVictim->getGUID() << pVictim->getGUIDHigh();
//    world.SendUnitAreaMessage(&data, pAttacker);  //probably global
    pAttacker->SendMessageToSet(&data, true);
    Log::getSingleton( ).outString( "WORLD: Sent SMSG_ATTACKSTART" );

// FLAGS changed so other players see attack animation
//    pAttacker->addUnitFlag(0x00080000);
//    pAttacker->setUpdateMaskBit(UNIT_FIELD_FLAGS );
}

void CombatHandler::DealDamage(Unit *pAttacker, Unit *pVictim, uint32 damage)
{
    uint32 health = pVictim->getUpdateValue(UNIT_FIELD_HEALTH );
    if (health <= damage)
    {
		pVictim->generateLoot();
        // victim died!
        pVictim->setTimeOfDeath();
        pVictim->setDeathState(JUST_DIED);

        // Send SMSG_PARTYKILLLOG 0x1e6
        // To everyone in the party?

        // SMSG_ATTACKSTOP
        uint32 aguid[2], vguid[2];
        aguid[0] = pAttacker->getGUID();
        aguid[1] = pAttacker->getGUIDHigh();
        vguid[0] = pVictim->getGUID();
        vguid[1] = pVictim->getGUIDHigh();
        smsg_AttackStop(pVictim, aguid);

        // Send MSG_MOVE_ROOT   0xe7

        // Set update values... try flags 917504
        // health
        pVictim->setUpdateValue(UNIT_FIELD_HEALTH, 0);

        // then another update message, sets health to 0, maxhealth to 100, and dynamic flags
        pVictim->setUpdateValue(UNIT_FIELD_HEALTH, 0);
        pVictim->setUpdateMaskBit(UNIT_FIELD_MAXHEALTH);
        pVictim->removeUnitFlag(0x00080000);
	
		if (!pVictim->IsPlayer())
			pVictim->setUpdateValue(UNIT_DYNAMIC_FLAGS, 1);
        
        if (pAttacker->IsPlayer()){
            uint32 xp = CalculateXpToGive(pVictim, pAttacker);

            // check running quests in case this monster belongs to it
            uint32 entry = pVictim->getUpdateValue(OBJECT_FIELD_ENTRY );

            // Is this player part of a group?
            Group *pGroup = WorldServer::getSingleton().GetGroupByLeader(((Character*)pAttacker)->GetGroupLeader());
            if (pGroup){
                xp /= pGroup->count;
                for (uint32 c=0; c < pGroup->count; c++){
                    Character *pGroupGuy = world.mCharacters[pGroup->members[c].guid];
                    pGroupGuy->giveXP(xp, pVictim->getGUID(), pVictim->getGUIDHigh());
                    pGroupGuy->KilledMonster(entry, pVictim->getGUID());
                }
            }
            else
            {
                // update experience
                ((Character*)pAttacker)->giveXP(xp, pVictim->getGUID(), pVictim->getGUIDHigh());
                ((Character*)pAttacker)->KilledMonster(entry, pVictim->getGUID());
            }
        }
        else
        {
            smsg_AttackStop(pAttacker, vguid);
            pAttacker->removeUnitFlag(0x00080000);
            pAttacker->setUpdateMaskBit(UNIT_FIELD_FLAGS );
            pAttacker->addStateFlag(UF_TARGET_DIED);
        }
    } else {
        pVictim->setUpdateValue(UNIT_FIELD_HEALTH , health - damage);

		// <WoW Chile Dev Team> Start Change
		// this need alot of work.
        if (!pVictim->IsPlayer())
		{	
			pVictim->AI_ChangeState(3); //if mob are attack then they stop moving around
			pVictim->AI_AttackReaction(pAttacker, damage);
			/*
			//uint32 max_health = getUpdateValue(UNIT_FIELD_MAXHEALTH);
			//uint32 health_porcent = (max_health*10)/100; // this if for know 10% of total healt,need changes about mobs lvls
			pVictim->AI_ChangeState(3); //if mob are attack then they stop moving around
            pVictim->AI_AttackReaction(pAttacker, damage);
			
			//well mobs scape if have a movement assignet atm
			//if(health<=health_porcent)
			{}
			*/
			
		}
		// <WoW Chile Dev Team> Start Change
    }
}

void CombatHandler::Heal(Unit *pAttacker, Unit *pVictim, uint32 damage)
{
    uint32 health = pVictim->getUpdateValue(UNIT_FIELD_HEALTH );
    if (health <= damage)
    {
		pVictim->generateLoot();
        // victim died!
        pVictim->setTimeOfDeath();
        pVictim->setDeathState(JUST_DIED);

        // Send SMSG_PARTYKILLLOG 0x1e6
        // To everyone in the party?

        // SMSG_ATTACKSTOP
        uint32 aguid[2], vguid[2];
        aguid[0] = pAttacker->getGUID();
        aguid[1] = pAttacker->getGUIDHigh();
        vguid[0] = pVictim->getGUID();
        vguid[1] = pVictim->getGUIDHigh();
        smsg_AttackStop(pVictim, aguid);

        // Send MSG_MOVE_ROOT   0xe7

        // Set update values... try flags 917504
        // health
        pVictim->setUpdateValue(UNIT_FIELD_HEALTH, 0);

        // then another update message, sets health to 0, maxhealth to 100, and dynamic flags
        pVictim->setUpdateValue(UNIT_FIELD_HEALTH, 0);
        pVictim->setUpdateMaskBit(UNIT_FIELD_MAXHEALTH);
        pVictim->removeUnitFlag(0x00080000);


		if (!pVictim->IsPlayer())
			pVictim->setUpdateValue(UNIT_DYNAMIC_FLAGS, 1);

        
        if (pAttacker->IsPlayer()){
            uint32 xp = CalculateXpToGive(pVictim, pAttacker);

            // check running quests in case this monster belongs to it
            uint32 entry = pVictim->getUpdateValue(OBJECT_FIELD_ENTRY );

            // Is this player part of a group?
            Group *pGroup = WorldServer::getSingleton().GetGroupByLeader(((Character*)pAttacker)->GetGroupLeader());
            if (pGroup){
                xp /= pGroup->count;
                for (uint32 c=0; c < pGroup->count; c++){
                    Character *pGroupGuy = world.mCharacters[pGroup->members[c].guid];
                    pGroupGuy->giveXP(xp, pVictim->getGUID(), pVictim->getGUIDHigh());
                    pGroupGuy->KilledMonster(entry, pVictim->getGUID());
                }
            }
            else
            {
                // update experience
                ((Character*)pAttacker)->giveXP(xp, pVictim->getGUID(), pVictim->getGUIDHigh());
                ((Character*)pAttacker)->KilledMonster(entry, pVictim->getGUID());
            }
        }
        else
        {
            smsg_AttackStop(pAttacker, vguid);
            pAttacker->removeUnitFlag(0x00080000);
            pAttacker->setUpdateMaskBit(UNIT_FIELD_FLAGS );
            pAttacker->addStateFlag(UF_TARGET_DIED);
        }
    } else {
        pVictim->setUpdateValue(UNIT_FIELD_HEALTH , health + damage);

    }
}
