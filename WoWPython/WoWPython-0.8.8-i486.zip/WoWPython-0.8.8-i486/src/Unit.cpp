#include "Unit.h"
#include "UpdateMask.h"
#include "WorldServer.h"
#include "Quest.h"
#include "Character.h"
#include "Opcodes.h"
#include "Timer.h"
#include <math.h>

#define world WorldServer::getSingleton()


Unit::Unit() : Object()
{
    m_objectType |= TYPE_UNIT;
    m_objectTypeId = 3;
    m_updateValues[ OBJECT_FIELD_TYPE ] = m_objectType;

    setAnimFrequency( 1, 5 );

    mQuestIds.clear();

    m_corpseDelay = 30;
    m_respawnDelay = 0;
    m_timeOfDeath = 0;
	movestartTime = 0;

    m_lastAttack = 0;
	
	itemcount = 0;
	memset(item_list, 0, 8*128);

    m_deathState = ALIVE;
    m_state = 0;
}

Unit::~Unit()
{
    mQuestIds.clear( );

}

void Unit::setAnimFrequency( uint32 anim, float frequency ) {
    mAnimFrequencies[ anim ] = frequency;
}

// <WoW Chile Dev Team> Start Change
// Asus: soon i optimized the code, for better visual look.
void Unit::UpdateMobMovement( float p_time)
{
	if(IsAlive())
	  if((creature_canMove) && (rand()%25==rand()%10)) // just for not inmediate move, u can delete or change
		if(creature_state == 1) //creature is moving.
		{ 		  
			//printf("-----> %i IS MOVING \n",m_guid[0]);
			if((uint32)time(NULL) > movestartTime + TimeTomove)
			{
				TimeTomove = 0;
				movestartTime=time(NULL);
				creature_state = 0;						
				//printf("-----> %i STOP MOVE \n",m_guid[0]);
			}
		}
		else if((creature_state == 0)) //creature is stoped 
		{
			float poss1[3], poss2[3], vecc[3];
			int destpoint;	
			float distance;				
			poss1[0] = getPositionX();
			poss1[1] = getPositionY();
			poss1[2] = getPositionZ();							
			if(creature_RandomMove)
			{
				destpoint = rand()%creature_paths;		
			}
			else
			{
				if (current_path==(creature_paths-1))
					current_dir=1;
				if (current_path==0)
					current_dir=0;
				if (current_dir==0) //if char gone 0..n
					destpoint = ++current_path;
				else  ////if char gone (n-1)..0
					destpoint = --current_path;
			}
			poss2[0] = creature_cord[destpoint][0];								
			poss2[1] = creature_cord[destpoint][1];				
			poss2[2] = creature_cord[destpoint][2];
			vecc[0] = poss2[0] - poss1[0];
			vecc[1] = poss2[1] - poss1[1];
			vecc[2] = poss2[2] - poss1[2];		
			distance = sqrt((vecc[0]*vecc[0]) + (vecc[1]*vecc[1]) + + (vecc[2]*vecc[2]));
			if ( distance > 0 ) // if random chose current point mobs doit nothing
			{		
				//printf("-----> %i START MOVE \n",m_guid[0]);	
				float dxtake;
				int mrun;
				if(!creature_Run)
				{
					dxtake = 350.0+rand()%200;
					mrun = 0;
				}
				else
				{
					dxtake = 50.0+rand()%100;
					mrun = 1;
				}
				uint32 _gtime = uint32(dxtake * distance);												
				AI_MoveTo(poss2, _gtime,mrun);	
				TimeTomove = (distance * dxtake)/1000; // maybe someone do more better this..			
				m_positionX = poss2[0];
				m_positionY = poss2[1];
				m_positionZ = poss2[2];										
				creature_state = 1;
				movestartTime = time(NULL);			
			}
		}	
		UpdateObject();
}
// <WoW Chile Dev Team> Stop Change
void Unit::Update( float p_time ) {  //<-- im not sure about this

    if (m_deathState == JUST_DIED){
        // remove me as an attacker from the AttackMap
        m_attackers.clear();
        m_deathState = CORPSE;
    }

    if (m_state & UF_TARGET_DIED){
        
    }

    if (m_timeOfDeath > 0 && (uint32)time(NULL) > m_timeOfDeath + m_corpseDelay)
    {
        // time to respawn!
        wowWData data;
        data.clear();
		data.Initialise(8, SMSG_DESTROY_OBJECT);
		data << (uint32)m_guid[0] << m_guid[1];
        SendMessageToSet(&data, false);
//		WorldServer::getSingleton().SendUnitZoneMessage(&data,m_zoneId,m_mapId);
        m_timeOfDeath = time(NULL);
        m_respawnDelay = 10;
        setDeathState(DEAD);
		// <WoW Chile Dev Team> Start Change
		//set to spawn point		
		m_positionX=respawn_cord[0][0];
		m_positionY=respawn_cord[0][1];
		m_positionZ=respawn_cord[0][2];
		//printf("PT %f, %f, %f \n", respawn_cord[0][0],respawn_cord[0][1],respawn_cord[0][2]);
		//printf("ACT MOV respawn coords--> Mob ID: %i - Nodo:X (x:%i, y:%i, z:%i)\n",m_guid[0],(int)creature_cord[0][0],(int)creature_cord[0][1],(int)creature_cord[0][2]);
		// <WoW Chile Dev Team> Stop Change
        printf("Removing corpse...\n");
    }
    else if (m_respawnDelay > 0 && m_timeOfDeath > 0 && (uint32)time(NULL) > m_timeOfDeath + m_respawnDelay)
    {
        UpdateMask mask;
        wowWData data;
        WorldServer::getSingletonPtr()->mObjectMgr.SetCreateUnitBits(mask);
        setUpdateFloatValue( UNIT_FIELD_COMBATREACH, 1.5f);
        setUpdateFloatValue( UNIT_FIELD_MAXDAMAGE, 10.0f);
        setUpdateFloatValue( UNIT_FIELD_MINDAMAGE, 20.0f);
	    setUpdateValue( UNIT_FIELD_BASEATTACKTIME, uint32(0x76c));
	    setUpdateValue( UNIT_FIELD_BASEATTACKTIME, uint32(0x7d0));

        uint32 max_health = getUpdateValue(UNIT_FIELD_MAXHEALTH);
        setUpdateValue(UNIT_FIELD_HEALTH, max_health);

        CreateObject(&mask, &data, 0);
        SendMessageToSet(&data, false);
//        WorldServer::getSingleton().SendUnitZoneMessage(&data,m_zoneId,m_mapId);
        m_timeOfDeath = 0;
        m_respawnDelay = 0;
        setDeathState(ALIVE);
        printf("Respawning...\n");
		// <WoW Chile Dev Team> Start Change
		creature_state=0; //after respawn monster can move
		// <WoW Chile Dev Team> Start Change
    }

    if (IsAlive())
    {
        AI_Update();
    }

    /*std::map< uint32, float >::iterator iter;
    float comparison = 60 * 2 / ( RAND_MAX * p_time );
    for( iter = mAnimFrequencies.begin( ); iter != mAnimFrequencies.end( ); ++ iter )
        if( iter->second > comparison * float( rand( ) ) ) {
            wowWData data;
            data.Initialise(12, SMSG_EMOTE);
            data << iter->first << m_guid[ 0 ] << m_guid[ 1 ];
            WorldServer::getSingleton( ).SendUnitZoneMessage(&data,m_zoneId,m_mapId);
            break;
        }*/
    UpdateObject();
}


void Unit::Create( uint32 guidlow )
{
    Object::Create(guidlow);
    m_guid[1] = 0xF0001000;
}

void Unit::Create (uint32 guidlow, uint8* creature_name, float x, float y, float z, float ang)
{
    strcpy((char*)m_creatureName, (char*)creature_name);
    Object::Create(guidlow, x,y,z,ang);
    m_guid[1] = 0xF0001000;
}


void Unit::BuildUpdateBlock(UpdateMask *updateMask, uint8 *data, int *length)
{
    m_updateValues[ UNIT_NPC_EMOTESTATE ] = m_emoteState;

    Object::BuildUpdateBlock(updateMask, data, length);
}


/////////////////////////////////// QUESTS ////////////////////////////////////////////
uint32 Unit::getQuestStatus(Character *pPlayer)
{
    for( std::list<uint32>::iterator i = mQuestIds.begin( ); i != mQuestIds.end( ); ++ i ) {
        uint32 quest_id = *i;
        uint32 status = pPlayer->getQuestStatus(quest_id);

        if (status == 0 || status == QUEST_STATUS_UNAVAILABLE) {
            Quest *pQuest = world.getQuest(quest_id);
            // if 0, then the player has never been offered this before
            // Add it to the player with a new quest value of 4
            if (pQuest->m_requiredLevel >= pPlayer->getUpdateValue(UNIT_FIELD_LEVEL))
                status = pPlayer->addNewQuest(quest_id,2);
            else
                status = pPlayer->addNewQuest(quest_id);
        }

        if (status != QUEST_STATUS_COMPLETE)
            return status;
    }
   
    return 0;
}

uint32 Unit::getCurrentQuest(Character *pPlayer)
{
    for( std::list<uint32>::iterator i = mQuestIds.begin( ); i != mQuestIds.end( ); ++ i ) {
        uint32 quest_id = *i;
        uint32 status = pPlayer->getQuestStatus(quest_id);
        
        if (status == 0) 
            // if 0, then the player has never been offered this before
            // Add it to the player with a new quest value of 4
            status = pPlayer->addNewQuest(quest_id);
        
        if (status != QUEST_STATUS_COMPLETE) // if quest is not completed yet, then this is the active quest to return
            return quest_id;
    }
   
    return 0;
}


char* Unit::getQuestTitle(uint32 quest_id) 
{ 
    Quest *pQuest = world.getQuest(quest_id);
    return (char*)pQuest->m_title.c_str();
}

char* Unit::getQuestDetails(uint32 quest_id) 
{ 
    Quest *pQuest = world.getQuest(quest_id);
    return (char*)pQuest->m_details.c_str();
}

char* Unit::getQuestObjectives(uint32 quest_id) 
{ 
    Quest *pQuest = world.getQuest(quest_id);
    return (char*)pQuest->m_objectives.c_str();
}

char* Unit::getQuestCompleteText(uint32 quest_id) 
{ 
    Quest *pQuest = world.getQuest(quest_id);
    return (char*)pQuest->m_completedText.c_str();
}

char* Unit::getQuestIncompleteText(uint32 quest_id)
{
    Quest *pQuest = world.getQuest(quest_id);
    return (char*)pQuest->m_incompleteText.c_str();
}


bool Unit::hasQuest(uint32 quest_id)
{
    for( std::list<uint32>::iterator i = mQuestIds.begin( ); i != mQuestIds.end( ); ++ i ) {
        if (*i == quest_id)
            return true;
    }

    return false;
}


void Unit::SendCreateWithTempNpcFlags(UpdateMask *updateMask, GameClient *pClient)
{
    if (m_deathState == DEAD) return;

    // for each quest this creature has,
    //   if player->getStatus != 0
    //     if quest->targetGuid != 0 && quest->targetGuid != thisCreature->guid and status==3
    //       thisCreature->npcflags = 0
    //     else if quest->targetGuid == thisCreature->guid && quest->status == 1||3
    //       thisCreature->npc_flags = 2
    Character *pPlayer = pClient->getCurrentChar();
    wowWData data;
    for( std::list<uint32>::iterator i = mQuestIds.begin( ); i != mQuestIds.end( ); ++ i ) {
        uint32 quest_id = *i;
        uint32 status = pPlayer->getQuestStatus(quest_id);
        Quest *pQuest = world.getQuest(quest_id);
        if (status != 0){
            if (pQuest->m_targetGuid != 0 && pQuest->m_targetGuid != m_guid[0] && status==3){
                setUpdateValue(UNIT_NPC_FLAGS, 0);
                CreateObject(updateMask, &data, 0);
                pClient->SendMsg(&data);
                setUpdateValue(UNIT_NPC_FLAGS, 2);
                return;
            }
            else if (pQuest->m_targetGuid == m_guid[0] && (status == 1 || status == 3)){
                setUpdateValue(UNIT_NPC_FLAGS, 2);
                CreateObject(updateMask, &data, 0);
                pClient->SendMsg(&data);
                setUpdateValue(UNIT_NPC_FLAGS, 0);
                return;
            }
        }
    } 
    
    CreateObject(updateMask, &data, 0);
    pClient->SendMsg(&data);
}


bool Unit::canAttack()
{
    uint32 attackTime = getUpdateValue(UNIT_FIELD_BASEATTACKTIME);
    return (getMSTime() > m_lastAttack + attackTime);
}

void Unit::setAttackTime() 
{ 
    m_lastAttack = getMSTime(); 
}

////////////////////////////////////////////////////////////////////////////////
//  Fill the object's Update Values from a space deliminated list of values.
////////////////////////////////////////////////////////////////////////////////
void Unit::LoadUpdateValues(uint8* data)
{
    char* next = strtok((char*)data, " ");
    m_updateValues[0] = atol(next);
    for( uint16 index = 1; index < UNIT_END; index++)
    {
        char* next = strtok(NULL, " ");
        m_updateValues[index] = atol(next);
    }
}


///////////////////////////////////////////////////////////////////////////////////////////////////
//    Looting
///////////////////////////////////////////////////////////////////////////////////////////////////

void Unit::generateLoot()
{
	int retryCount = 0;
	itemcount = 0;
	memset(item_list, 0, 8*128);

	int itemCount,i,randItem,found = 0,tempLevel;
	this->m_lootMoney = this->GetLevel() * (rand()%5 + 1);
	itemCount = (this->GetLevel() + rand()%7) / 5;
	if (itemCount > 3)
		itemCount = 3;
	//itemCount = 2; //temp
	for(i = 0; i < itemCount; i++) {
		//This is an ugly way to do it
		//I may implement a 'baskets' system later - tmm`
		retryCount = 0;
		while(!found && (retryCount <= 150)) {
			retryCount++;
			randItem = rand()%7000;
			if (world.GetItem(randItem) != NULL) {
				tempLevel = world.GetItem(randItem)->ItemLevel;
				if ((tempLevel < this->GetLevel() +2) && (tempLevel > this->GetLevel() -2)) {
					if ((world.GetItem(randItem)->Class == 2) || (world.GetItem(randItem)->Class == 4)) {
                		found = 1;
					}
				}
			}
		}
		if (found == 0)
		{
			//this is getting dangerous, we don't want an infinite loop :/
			//lets just not give him any items
			itemcount = 0;
			return;
		}
        this->addItem(randItem,1);
		found = 0;
	}
}

///////////////////////////////////////////////////////////////////////////////////////////////////
//    Unit AI
///////////////////////////////////////////////////////////////////////////////////////////////////

// This Unit has just been attacked by someone
// Reaction:  Add this Unit to the list of current attackers
void Unit::AI_AttackReaction(Unit *pAttacker, uint32 damage_dealt)
{
    std::list<Unit*>::iterator itr;
    for (itr = m_attackers.begin(); itr != m_attackers.end(); ++itr)
        if (*itr == pAttacker){
            // Attacker already in list
            return;
        }

    m_attackers.push_back(pAttacker);
}

void Unit::AI_Update()
{
    // Cycle through attackers
    // If one is out of range, remove from the map
    std::list<Unit*>::iterator itr;
    for (itr = m_attackers.begin(); itr != m_attackers.end(); )
    {
        Unit *pVictim = *itr;
        if (!pVictim || !pVictim->IsAlive()){
            itr = m_attackers.erase(itr);
            continue;
        }

        float pos1[3], pos2[3], vec[3];
        pos1[0] = pVictim->getPositionX();
        pos1[1] = pVictim->getPositionY();
        pos1[2] = pVictim->getPositionZ();

        pos2[0] = getPositionX();
        pos2[1] = getPositionY();
        pos2[2] = getPositionZ();

        vec[0] = pos2[0] - pos1[0];
        vec[1] = pos2[1] - pos1[1];
        vec[2] = pos2[2] - pos1[2];

        float length = sqrt((vec[0]*vec[0]) + (vec[1]*vec[1]) + (vec[2]*vec[2]));
        float reach = getUpdateFloatValue(UNIT_FIELD_COMBATREACH);
        float radius = getUpdateFloatValue(UNIT_FIELD_BOUNDINGRADIUS);

        if (length > 25.0f)
        {
            // stop attacking because the target is too far
            itr = m_attackers.erase(itr);
            continue;
        }

        // --- Comment out this block if you find monster movement too buggy
        if (length > reach + radius)
        {
            // this attacker is out of range
            // shrink the vector to the victim by their bounding radius to as to not stand on top of them
/*  !-- Buggy, but mess with this so that the monster doesnt walk "on top" of the char
            if (radius < 0){
                vec[0] *= radius;
                vec[1] *= radius;
                vec[2] *= radius;
            } else {
                vec[0] /= radius;
                vec[1] /= radius;
                vec[2] /= radius;
            }
*/
            float new_pos[3];
            new_pos[0] = pos2[0] - vec[0];
            new_pos[1] = pos2[1] - vec[1];
            new_pos[2] = pos2[2] - vec[2];

            float length2 = sqrt((vec[0]*vec[0]) + (vec[1]*vec[1]) + (vec[2]*vec[2]));
            uint32 time = uint32(150.0 * length2);

            AI_MoveTo(new_pos, time,1); //just attack
            m_positionX = new_pos[0];
            m_positionY = new_pos[1];
            m_positionZ = new_pos[2];
        } // --- End Monster movement block
        else if (canAttack())
        {
            world.mCombatHandler.AttackerStateUpdate((Unit*)this, pVictim);
            setAttackTime();
        }

        ++itr;
    }

}


void Unit::AI_MoveTo(float new_pos[3], uint32 time,int StateFlag) // StateFlag = 0, ust walk around,StateFlag = 1, run
{   
	uint32 FlagMov;
	if(StateFlag) FlagMov =0x00000100;
	else FlagMov=0x00000000;
    wowWData data;
    data.Initialise(49, SMSG_MONSTER_MOVE);
    data << m_guid[0] << m_guid[1];
    data << getPositionX() << getPositionY() << getPositionZ() << getOrientation();
    data << uint8(0);
    data << uint32(FlagMov);
    data << time;
    data << uint32(1);
    data << new_pos[0] << new_pos[1] << new_pos[2];
    world.SendGlobalMessage(&data);
}