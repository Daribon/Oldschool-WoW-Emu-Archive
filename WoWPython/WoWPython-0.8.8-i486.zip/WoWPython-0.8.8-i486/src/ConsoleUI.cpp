// ConsoleUI.cpp: implementation of the CConsoleUI class.
//
//////////////////////////////////////////////////////////////////////

#include "ConsoleUI.h"

#include <iostream>
using std::cout;
using std::cin;
#include "console.h"
#ifdef _DEBUG
#pragma comment(lib, "ConsoleD")
#else
#pragma comment(lib, "ConsoleR")
#endif

Console con(0,0,true,false);

//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CConsoleUI::CConsoleUI()
{

}


void CConsoleUI::GetOutput(char* msg)
{
	con<<msg;
}

void CConsoleUI::ServOutput(char* msg)
{
	//Todo Move to output line
	GetOutput(msg);
	
}