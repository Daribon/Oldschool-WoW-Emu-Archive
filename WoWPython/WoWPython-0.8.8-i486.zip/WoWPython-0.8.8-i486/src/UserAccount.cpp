#include "UserAccount.h"

UserAccount::~UserAccount()
{

}

