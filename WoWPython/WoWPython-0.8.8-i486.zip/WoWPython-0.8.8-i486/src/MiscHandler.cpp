#include "MiscHandler.h"
#include "NetworkInterface.h"
#include "Opcodes.h"
#include "Log.h"
#include "Character.h"
#include "WorldServer.h"
#include "Database.h"
#include <string.h>

#define world WorldServer::getSingleton()

MiscHandler::MiscHandler( ) {

}

MiscHandler::~MiscHandler( ) {

}


void MiscHandler::HandleMsg( wowWData & recv_data, GameClient *pClient )
{
    wowWData data;
	char f[256];
    sprintf(f, "WORLD: Misc Opcode 0x%.4X", recv_data.opcode);
    Log::getSingleton( ).outString( f );
	NetworkInterface *net = pClient->getNetwork();
    switch (recv_data.opcode)
    {
				case CMSG_REPOP_REQUEST:
					{
						Log::getSingleton( ).outString( "WORLD: Recvd CMSG_REPOP_REQUEST Message" );

						//-5345.88, -2872.91, 340.411 - Loch Madon Graveyard
//						float x = float(-5345.88);
//						float y = float(-2872.91);
//						float z = float(340.411);

						Character *chr = pClient->getCurrentChar();

//						chr->TeleportAck(&data, x,y,z);
//						pClient->SendMsg(&data);

//						chr->BuildHeartBeat(&data); 
//						world.SendZoneMessage(&data, pClient, 0);
//                        pClient->getCurrentChar()->SendMessageToSet(&data, false);

						pClient->getCurrentChar( )->setUpdateValue( UNIT_FIELD_HEALTH, 1 );
                        pClient->getCurrentChar()->setDeathState(ALIVE);

					}break;  
				case CMSG_AUTOSTORE_LOOT_ITEM:
					{
						int i,slot = 0;
						uint32 itemid;
						uint8 lootSlot;
						std::map<uint32, Unit*>::iterator itr = world.mCreatures.find(pClient->getCurrentChar()->getLootGUID());
						if (itr->second == NULL)
							return;
						recv_data >> lootSlot;
						for(i = 23; i <= 38; i++) 
						{
							if (pClient->getCurrentChar()->getGuidBySlot(i) == 0) {
								slot = i;
								break;
							}
						}
						if (slot == 0)
							return; //maybe whine a bit too?
   						if (itr->second->getItemAmount(lootSlot) == 0)
							return; //maybe whine a bit too?
						world.m_hiItemGuid++;
						itemid = itr->second->getItemId(lootSlot);
						itr->second->setItemAmount(lootSlot, 0);
						pClient->getCurrentChar()->AddItemToSlot(slot,world.m_hiItemGuid,itemid);
						
						world.mItemHandler.createItemUpdate(&data, pClient, slot);
						pClient->SendMsg( &data );

						UpdateMask updateMask;
						updateMask.setCount( 0x1b );
						pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD  + (slot*2), pClient->getCurrentChar()->getGuidBySlot(slot), updateMask.updateMask );
						pClient->getCurrentChar( )->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD  + (slot*2)+1, pClient->getCurrentChar()->getGuidBySlot(slot) == 0 ? 0 : 0x00000040, updateMask.updateMask );
						pClient->getCurrentChar( )->UpdateObject( &updateMask, &data );
						pClient->SendMsg( &data );

						data.Initialise(1 , SMSG_LOOT_REMOVED);
						data << uint8(lootSlot);
						pClient->SendMsg( &data );

					}break;
				case CMSG_LOOT_MONEY:
					{
						UpdateMask updateMask;
						updateMask.setCount( 0x1b );
						uint32 newcoinage = 0;
						std::map<uint32, Unit*>::iterator itr = world.mCreatures.find(pClient->getCurrentChar()->getLootGUID());
						if (itr->second == NULL)
							return;

						newcoinage = pClient->getCurrentChar()->getUpdateValue(PLAYER_FIELD_COINAGE) + itr->second->getLootMoney();
						itr->second->setLootMoney(0);
						pClient->getCurrentChar()->setUpdateValue( PLAYER_FIELD_COINAGE , newcoinage);				
					}break;
				case CMSG_LOOT:
					{  
						uint32 guid1, guid2;
						uint16 tmpDataLen,tmpItemsCount = 0;
						uint8 i;
						Item *tmpLootItem;
						recv_data >> guid1 >> guid2;

						std::map<uint32, Unit*>::iterator itr = world.mCreatures.find(guid1);
						if (itr->second == NULL)
							return;

						pClient->getCurrentChar()->setLootGUID(guid1,guid2);
						for(i = 0; i<itr->second->getItemCount() ; i++) {
							if (itr->second->getItemAmount((int)i) > 0)
								tmpItemsCount++;
						}
						tmpDataLen = 14 + tmpItemsCount*21;
						data.Initialise(tmpDataLen, SMSG_LOOT_RESPONSE);
						data << uint32(guid1);
						data << uint32(guid2);
						data << uint8(0x01);
						data << uint32(itr->second->getLootMoney());
						data << uint8(itr->second->getItemCount());
						for(i = 0; i<itr->second->getItemCount() ; i++) {
							if (itr->second->getItemAmount((int)i) > 0) {
								data << uint8(i);
								tmpLootItem = world.GetItem(itr->second->getItemId((int)i));
								data << uint32(itr->second->getItemId((int)i));
								data << uint32(itr->second->getItemAmount((int)i));
								data << uint32(tmpLootItem->DisplayInfoID);
								data << uint32(0) << uint32(0);
							}
						}
						net->sendWData( &data ); 
					}break;   
				case CMSG_LOOT_RELEASE:
					{  
						uint32 guid1, guid2;    
						pClient->getCurrentChar()->setLootGUID(0,0);
						recv_data >> guid1 >> guid2;
						data.Initialise( 9, SMSG_LOOT_RELEASE_RESPONSE );
						data << guid1 << guid2 << uint8( 1 );            
						net->sendWData( &data );
					}break;
				case CMSG_WHO:
					{	
						uint64 clientcount = 0;
						int datalen = 8;
						int countcheck = 0;
						Log::getSingleton( ).outString( "WORLD: Recvd CMSG_WHO Message" );

						WorldServer::ClientSet::iterator itr;
						for (itr = world.mClients.begin(); itr != world.mClients.end(); itr++) {
							if ( ((GameClient*)(*itr))->getCharacterName() ) {
								clientcount++;
								datalen = datalen + strlen(((GameClient*)(*itr))->getCharacterName()) + 1 + 21;

							}
						}

						data.clear();
						data.Initialise(datalen, SMSG_WHO);
						data << uint64( clientcount );
						for (itr = world.mClients.begin(); itr != world.mClients.end(); itr++) {
							if ((( ((GameClient*)(*itr))->getCharacterName() ) && (((GameClient*)(*itr))->IsInWorld()) ) && (countcheck  < clientcount)) {
								countcheck++;
								data.writeData(((GameClient*)(*itr))->getCurrentChar()->getName() , strlen(((GameClient*)(*itr))->getCurrentChar()->getName()) + 1);
								data << uint8( 0x00 );
								data << uint32( ((GameClient*)(*itr))->getCurrentChar()->GetLevel() );
								data << uint32( ((GameClient*)(*itr))->getCurrentChar()->GetClass() );
								data << uint32( ((GameClient*)(*itr))->getCurrentChar()->GetRace() );
								data << uint32( ((GameClient*)(*itr))->getCurrentChar()->getZone() );

								data << uint32( 0x00000000 ); // this is the guild id...once we have guilds working it'll go here.
							}
						}
						pClient->SendMsg(&data);
					}break;

				case CMSG_LOGOUT_REQUEST:
					{
						Log::getSingleton( ).outString( "WORLD: Recvd CMSG_LOGOUT_REQUEST Message" );

						data.clear();
						data.length = 1;
						data.data = new uint8[ data.length ];
						data.opcode = SMSG_LOGOUT_RESPONSE;
						data.data[0] = 0xC;
						net->sendWData( &data );

                        pClient->LogoutRequest(time(NULL));
					}break;

				case CMSG_PLAYER_LOGOUT:
					{
						Log::getSingleton( ).outString( "WORLD: Recvd CMSG_PLAYER_LOGOUT Message" );

						data.clear();
						data.length = 0;
						data.data = new uint8[ data.length ];
						data.opcode = SMSG_LOGOUT_COMPLETE;
						net->sendWData( &data );

						world.LogoutPlayer(pClient);

						Log::getSingleton( ).outString( "WORLD: sent SMSG_LOGOUT_COMPLETE Message" );
					}break;

				case CMSG_LOGOUT_CANCEL:
					{
						Log::getSingleton( ).outString( "WORLD: Recvd CMSG_LOGOUT_CANCEL Message" );

                        pClient->LogoutRequest(0);

						data.clear();
						data.length = 0;
						data.data = new uint8[ data.length ];
						data.opcode = SMSG_LOGOUT_CANCEL_ACK;
						net->sendWData( &data );

						Log::getSingleton( ).outString( "WORLD: sent SMSG_LOGOUT_CANCEL_ACK Message" );
					}break;

				case CMSG_PING:
					{
						//Log::getSingleton( ).outString( "WORLD: Recvd CMSG_PING Message" );
						uint32 ping;
						memcpy(&ping, recv_data.data, 4);
						data.clear();						
						data.Initialise( 4, SMSG_PONG );						
						data << ping;
						net->sendWData( &data );
						//Log::getSingleton( ).outString( "WORLD: sent SMSG_PONG Message" );
					}break;

                case CMSG_GMTICKET_GETTICKET:
					{
						data.Initialise( 10, SMSG_GMTICKET_GETTICKET );	
						data << uint32(6);
                        data << uint32(0xffbfbfbf);
                        data << uint8(0);
                        data << uint8(3);
						net->sendWData( &data );
					}break;

                case CMSG_GMTICKET_CREATE:
					{
                        //TODO: Receive message sent and relay it to an online GM
						data.Initialise( 4, SMSG_GMTICKET_CREATE );	
						data << uint32(2);
						net->sendWData( &data );
					}break;

                case CMSG_GMTICKET_SYSTEMSTATUS:
					{
                        //TODO: Receive message sent and relay it to an online GM
						data.Initialise( 4, SMSG_GMTICKET_SYSTEMSTATUS );	
						data << uint32(1);
						net->sendWData( &data );
					}break;

				case CMSG_ZONEUPDATE:
					{
						uint32 newZone,oldZone;
						recv_data.readData(newZone);
						printf("WORLD: Recvd ZONE_UPDATE: %u\n", newZone);
						if (pClient->getCurrentChar()->getZone() == newZone)
							return;

						oldZone = pClient->getCurrentChar( )->getZone();
						//Setting new zone
						if( pClient->getCurrentChar( ) )
							pClient->getCurrentChar()->setZone((uint16)newZone);
/*
						//First, we kill all creeps from the previous zone
						for( WorldServer::CreatureMap::iterator tmpi = world.mCreatures.begin( ); tmpi != world.mCreatures.end( ); ++ tmpi ) {
							if (tmpi->second->getZone() == oldZone)
							{
								data.clear();
								data.Initialise(8 , SMSG_DESTROY_OBJECT );
								data << tmpi->second->getGUID() << tmpi->second->getGUIDHigh();
								pClient->SendMsg(&data);
							}
						}
						//Now we kill all the old clients
                        WorldServer::ClientSet::iterator tmpiter;
						for (tmpiter = world.mClients.begin(); tmpiter != world.mClients.end(); tmpiter++){
							if (((GameClient*)(*tmpiter))->getCurrentChar()) {
								if (oldZone == ((GameClient*)(*tmpiter))->getCurrentChar()->getZone())
								{
									for(icount=0;icount<23;icount++) {
										if (((GameClient*)(*tmpiter))->getCurrentChar()->getGuidBySlot(icount) != 0)
										{
											data.clear();
											data.Initialise(8 , SMSG_DESTROY_OBJECT );
											data << ((GameClient*)(*tmpiter))->getCurrentChar()->getGuidBySlot(icount) << 0x00000040;
											pClient->SendMsg(&data);
										}
									}
									data.clear();
									data.Initialise(8 , SMSG_DESTROY_OBJECT );
									data << ((GameClient*)(*tmpiter))->getCurrentChar()->getGUID() << ((GameClient*)(*tmpiter))->getCurrentChar()->getGUIDHigh();
									pClient->SendMsg(&data);
								}
							}
						}

						//Now we kill our char 

						for(icount=0;icount<23;icount++) {
							if (pClient->getCurrentChar()->getGuidBySlot(icount) != 0)
							{
								data.clear();
								data.Initialise(8 , SMSG_DESTROY_OBJECT );
								data << pClient->getCurrentChar()->getGuidBySlot(icount) << 0x00000040;
								world.SendUnitZoneMessage(&data, oldZone,pClient->getCurrentChar()->getMapId());
							}
						}
						data.clear();
						data.Initialise(8 , SMSG_DESTROY_OBJECT );
						data << pClient->getCurrentChar()->getGUID() << pClient->getCurrentChar()->getGUIDHigh();
						world.SendUnitZoneMessage(&data, oldZone,pClient->getCurrentChar()->getMapId());

						//Creating new zone 
						UpdateMask updateMask, invUpdateMask;
						updateMask.setCount(PLAYER_BLOCKS);

						Character *pCurrChar = pClient->getCurrentChar();

						// Set update mask for player creation
						updateMask.setBit(OBJECT_FIELD_GUID);          
						updateMask.setBit(OBJECT_FIELD_TYPE);
						updateMask.setBit(OBJECT_FIELD_SCALE_X);         
						updateMask.setBit(OBJECT_FIELD_PADDING);
						updateMask.setBit(UNIT_FIELD_HEALTH ); 
						updateMask.setBit(UNIT_FIELD_POWER1  );        
						updateMask.setBit(UNIT_FIELD_POWER2  );
						updateMask.setBit(UNIT_FIELD_POWER3  );        
						updateMask.setBit(UNIT_FIELD_POWER4 );
						updateMask.setBit(UNIT_FIELD_MAXHEALTH  );
						updateMask.setBit(UNIT_FIELD_MAXPOWER1  );        
						updateMask.setBit(UNIT_FIELD_MAXPOWER2  );
						updateMask.setBit(UNIT_FIELD_MAXPOWER3  );        
						updateMask.setBit(UNIT_FIELD_MAXPOWER4 );
						updateMask.setBit(UNIT_FIELD_LEVEL  );            
						updateMask.setBit(UNIT_FIELD_FACTIONTEMPLATE  );
						updateMask.setBit(UNIT_FIELD_BYTES_0 );          
						updateMask.setBit(PLAYER_FIELD_STAT0  );
						updateMask.setBit(PLAYER_FIELD_STAT1 );            
						updateMask.setBit(PLAYER_FIELD_STAT2 );
						updateMask.setBit(PLAYER_FIELD_STAT3  );            
						updateMask.setBit(PLAYER_FIELD_STAT4  );
						updateMask.setBit(PLAYER_FIELD_BASESTAT0  );        
						updateMask.setBit(PLAYER_FIELD_BASESTAT1 );
						updateMask.setBit(PLAYER_FIELD_BASESTAT2 );        
						updateMask.setBit(PLAYER_FIELD_BASESTAT3 );
						updateMask.setBit(PLAYER_FIELD_BASESTAT4 );        
						updateMask.setBit(PLAYER_FIELD_COINAGE  );
						updateMask.setBit(UNIT_FIELD_FLAGS  );
						updateMask.setBit(UNIT_FIELD_BASEATTACKTIME );   
						updateMask.setBit(UNIT_FIELD_BASEATTACKTIME+1  );
						updateMask.setBit(UNIT_FIELD_BOUNDINGRADIUS );  
						updateMask.setBit(UNIT_FIELD_COMBATREACH   );
						updateMask.setBit(UNIT_FIELD_DISPLAYID  );       
						updateMask.setBit(UNIT_FIELD_MINDAMAGE);
						updateMask.setBit(UNIT_FIELD_MAXDAMAGE );       
						updateMask.setBit(PLAYER_FIELD_ATTACKPOWER );
						updateMask.setBit(PLAYER_BYTES);
						updateMask.setBit(PLAYER_BYTES_2 );
						updateMask.setBit(PLAYER_XP );                 
						updateMask.setBit(PLAYER_NEXT_LEVEL_XP);
						updateMask.setBit(PLAYER_REST_STATE_EXPERIENCE );                         
						updateMask.setBit(UNIT_FIELD_MOUNTDISPLAYID);

						// Send messages to the client creating all existing players in the new zone
						WorldServer::ClientSet::iterator iter;
						Item *tempitem;
						for (iter = world.mClients.begin(); iter != world.mClients.end(); iter++){
							if (pClient->getCurrentChar() && pClient != (*iter)){
								if (!((GameClient*)(*iter))->getCurrentChar())
									continue;
								if (pClient->getCurrentChar()->getZone() != ((GameClient*)(*iter))->getCurrentChar()->getZone())
									continue;
								Character *chr = ((GameClient*)(*iter))->getCurrentChar();
								if( chr ) {
									for(i = 0; i<46; i++)
									{
										updateMask.unSetBit( PLAYER_FIELD_INV_SLOT_HEAD + i );
									}
									for(i = 0; i<46; i+=2)
									{
										if (chr->m_items[i/2].guid != 0) {
											chr->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i , chr->m_items[i/2].guid, updateMask.updateMask );
											chr->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i + 1 , 0x00000040, updateMask.updateMask);
										}
									}								
									data.clear();
									chr->CreateObject(&updateMask, &data, 0);
									net->sendWData(&data);

									for(invcount = 0; invcount < 23; invcount++)
									{
										if (chr->m_items[invcount].guid != 0) {
											data.clear();

											invUpdateMask.clear();
											invUpdateMask.setCount(0x02);
											tempitem = new Item;

											invUpdateMask.setBit( OBJECT_FIELD_GUID );
											invUpdateMask.setBit( OBJECT_FIELD_GUID+1 );
											invUpdateMask.setBit( OBJECT_FIELD_TYPE );
											invUpdateMask.setBit( OBJECT_FIELD_ENTRY );
											invUpdateMask.setBit( OBJECT_FIELD_SCALE_X );
											invUpdateMask.setBit( OBJECT_FIELD_PADDING );
											invUpdateMask.setBit( ITEM_FIELD_OWNER );
											invUpdateMask.setBit( ITEM_FIELD_CONTAINED );
											invUpdateMask.setBit( ITEM_FIELD_OWNER +1 );
											invUpdateMask.setBit( ITEM_FIELD_CONTAINED +1 );
											invUpdateMask.setBit( ITEM_FIELD_STACK_COUNT );
											tempitem->Create(chr->m_items[invcount].guid,chr->m_items[invcount].itemid);
											tempitem->setUpdateValue( OBJECT_FIELD_GUID , chr->m_items[invcount].guid ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_GUID+1 , 0x00000040 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_TYPE , 0x00000003 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_ENTRY , chr->m_items[invcount].itemid ,invUpdateMask.updateMask);
											tempitem->setUpdateFloatValue( OBJECT_FIELD_SCALE_X , 1.0f ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_PADDING , 0xeeeeeeee ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_OWNER , chr->getGUID() ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_CONTAINED , chr->getGUID() ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_OWNER +1 , 0 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_CONTAINED +1 , 0 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_STACK_COUNT , 1 ,invUpdateMask.updateMask);

											tempitem->CreateObject(&invUpdateMask, &data, 0);
											pClient->getNetwork()->sendWData(&data);
											delete tempitem;
										}
									}
								}
							}
						}

						// Send a zone message that a new players has entered the zone
						data.clear();
						for(i = 0; i<46; i++)
						{
							updateMask.unSetBit( PLAYER_FIELD_INV_SLOT_HEAD + i );
						}
						for(i = 0; i<46; i+=2)
						{
							if (pClient->getCurrentChar()->m_items[i/2].guid != 0) {
								pClient->getCurrentChar()->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i , pClient->getCurrentChar()->m_items[i/2].guid,  updateMask.updateMask);
								pClient->getCurrentChar()->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i + 1 , 0x00000040,  updateMask.updateMask);
							}

						}
						data.clear();
						pClient->getCurrentChar()->CreateObject(&updateMask, &data, 0);
						world.SendZoneMessage(&data, pClient, 0);

						for(invcount = 0; invcount < 23; invcount++)
						{
							if ((pClient->getCurrentChar()->m_items[invcount].guid != 0) && (pClient->getCurrentChar()->m_items[invcount].guid != NULL)){
								data.clear();

								invUpdateMask.clear();
								invUpdateMask.setCount(0x02);
								tempitem = new Item;

								invUpdateMask.setBit( OBJECT_FIELD_GUID );
								invUpdateMask.setBit( OBJECT_FIELD_GUID+1 );
								invUpdateMask.setBit( OBJECT_FIELD_TYPE );
								invUpdateMask.setBit( OBJECT_FIELD_ENTRY );
								invUpdateMask.setBit( OBJECT_FIELD_SCALE_X );
								invUpdateMask.setBit( OBJECT_FIELD_PADDING );
								invUpdateMask.setBit( ITEM_FIELD_OWNER );
								invUpdateMask.setBit( ITEM_FIELD_CONTAINED );
								invUpdateMask.setBit( ITEM_FIELD_OWNER +1 );
								invUpdateMask.setBit( ITEM_FIELD_CONTAINED +1 );
								invUpdateMask.setBit( ITEM_FIELD_STACK_COUNT );
								tempitem->Create(pClient->getCurrentChar()->m_items[invcount].guid,pClient->getCurrentChar()->m_items[invcount].itemid);
								tempitem->setUpdateValue( OBJECT_FIELD_GUID , pClient->getCurrentChar()->m_items[invcount].guid ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_GUID+1 , 0x00000040 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_TYPE , 0x00000003 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_ENTRY , pClient->getCurrentChar()->m_items[invcount].itemid ,invUpdateMask.updateMask);
								tempitem->setUpdateFloatValue( OBJECT_FIELD_SCALE_X , 1.0f ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_PADDING , 0xeeeeeeee ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_OWNER , pClient->getCurrentChar()->getGUID() ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_CONTAINED , pClient->getCurrentChar()->getGUID() ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_OWNER +1 , 0 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_CONTAINED +1 , 0 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_STACK_COUNT , 1 ,invUpdateMask.updateMask);

								tempitem->CreateObject(&invUpdateMask, &data, 0);
								world.SendZoneMessage(&data, pClient, 0);
								delete tempitem;
							}
						}

						// Create monsters
						for( WorldServer::CreatureMap::iterator i = world.mCreatures.begin( ); i != world.mCreatures.end( ); ++ i ) {
							if (pClient->getCurrentChar()->getZone() != i->second->getZone())
								continue;
							data.clear();
                            UpdateMask unitMask;
                            i->second->SetBitsForCreateNpc(unitMask);

							i->second->SendCreateWithTempNpcFlags(&unitMask, pClient);
							i->second->clearUpdateMask();
						}
*/
					}break;

				case CMSG_PLAYER_LOGIN:
					{
						Log::getSingleton( ).outString( "WORLD: Recvd Player Logon Message" );
						int invcount;
						uint32 player_guid=0;

						memcpy(&player_guid,recv_data.data,4); //This is the GUID selected by the player
						pClient->setCurrentChar(pClient->getCurrentChar(player_guid));
						world.dbi->loadQuestStatus(pClient->getCurrentChar());


						int i;

                        data.Initialise(80, SMSG_ACCOUNT_DATA_MD5);
                        memset(data.data, 0, 80);
                        pClient->SendMsg(&data);

						// MOTD
						const uint8 msgchat_header_size=13;
						uint8 msgchat_header[msgchat_header_size] = { 0x09, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00 };

						uint8 msgchat_info[256];
						uint8 msgchat_info_size=0;
						sprintf((char*)msgchat_info,"Number of users connected: %i\n",(int)world.GetClientsConnected());
						for(;msgchat_info[msgchat_info_size]!=0;msgchat_info_size++){}

                        data.Initialise(world.motd_size + msgchat_header_size + msgchat_info_size + 1, SMSG_MESSAGECHAT);
						memcpy(data.data, msgchat_header, msgchat_header_size);
						memcpy(data.data+msgchat_header_size, msgchat_info, msgchat_info_size);
						memcpy(data.data+msgchat_header_size+msgchat_info_size, world.motd, world.motd_size);
						data.data[world.motd_size + msgchat_header_size + msgchat_info_size]=0; //Yeah, it looks like there must be two 0 at the end of the string
						pClient->SendMsg( &data );
						Log::getSingleton( ).outString( "WORLD: Sent motd (SMSG_MESSAGECHAT)" );


                        //data.Initialise(4, SMSG_SET_REST_START);
                        //data << unsure;
                        //pClient->SendMsg(&data);

                        //Tutorial Flags
						data.Initialise(32,SMSG_TUTORIAL_FLAGS);
                        memset(data.data, 0xff, 32);
                        pClient->SendMsg(&data);
						Log::getSingleton( ).outString( "WORLD: Sent tutorial flags." ); 

                        //Initial Spells
                        pClient->getCurrentChar()->smsg_InitialSpells();

                        // SMSG_ACTION_BUTTONS
                        data.Initialise(480, SMSG_ACTION_BUTTONS);
                        data << uint32(0x19CB);
                        data << uint32(0x0074);
                        data << uint32(0x0085);
                        data << uint32(0x0848);
                        for(int temp_counter=116; temp_counter>0; temp_counter--)
                        {
                            data << uint32(0);
                        }
                        pClient->SendMsg( &data );

                        // SMSG_INITIALIZE_FACTIONS

                        // SMSG_EXPLORATION_EXPERIENCE

                        // SMSG_CAST_RESULT -- Spell_id = 836 (LOGINEFFECT (24347)) From spells.dbc.csv

    					data.Initialise(8, SMSG_LOGIN_SETTIMESPEED);
						uint32 minutes = world.updateGameTime( ) / 60;
						uint32 hours = minutes / 60; minutes %= 60;
						uint32 gameTime = minutes + ( hours << 6 );
						data << (uint32)gameTime;
						data << (float)0.017f;	// Normal Game Speed
						pClient->SendMsg( &data ); 

                        // SMSG_UPDATE_AURA_DURATION -- if the player had an aura on when he logged out

                        // Bojangles has Been up in here :0 Cinematics working Just need
						// the sound flags to kick off sound.
						// doesnt check yet if its the first login to run. *YET*

							data.Initialise( 4, SMSG_TRIGGER_CINEMATIC );
							uint8 theRace = pClient->getCurrentChar()->GetRace(); // get race
                            
                            if (theRace == 1) // Human
							{
								data << uint32(81);
								pClient->SendMsg( &data );
							}
							if (theRace == 2) // Orc
							{
								data << uint32(21);
								pClient->SendMsg( &data );
							}
							if (theRace == 3) // Dwarf
							{
								data << uint32(41);
								pClient->SendMsg( &data );
							}
							if (theRace == 4) // Night Elves
							{
								data << uint32(61);
								pClient->SendMsg( &data );
							}
							if (theRace == 5) // undead <-- WORKING thats Correct
							{
								data << uint32(2);
								pClient->SendMsg( &data );
							}
							if (theRace == 6) // Tauren
							{
								data << uint32(141);
								pClient->SendMsg( &data );
							}
							if (theRace == 7) // Gnome
							{
								data << uint32(101);
								pClient->SendMsg( &data );
							}
							if (theRace == 8) // Troll
							{
								data << uint32(121);
								pClient->SendMsg( &data );
							}
						// Now send all A9's

                        // Now send all A9's

						// create update mask to create the player object with
						// Use external mask so that is can be re-used for multiple players
						UpdateMask updateMask, invUpdateMask;
						updateMask.setCount(PLAYER_BLOCKS);

						Character *pCurrChar = pClient->getCurrentChar();

						// Set update mask for player creation
						updateMask.setBit(OBJECT_FIELD_GUID);          
						updateMask.setBit(OBJECT_FIELD_TYPE);
						updateMask.setBit(OBJECT_FIELD_SCALE_X);         
						updateMask.setBit(OBJECT_FIELD_PADDING);
						updateMask.setBit(UNIT_FIELD_HEALTH ); 
						updateMask.setBit(UNIT_FIELD_POWER1  );        
						updateMask.setBit(UNIT_FIELD_POWER2  );
						updateMask.setBit(UNIT_FIELD_POWER3  );        
						updateMask.setBit(UNIT_FIELD_POWER4 );
						updateMask.setBit(UNIT_FIELD_MAXHEALTH  );
						updateMask.setBit(UNIT_FIELD_MAXPOWER1  );        
						updateMask.setBit(UNIT_FIELD_MAXPOWER2  );
						updateMask.setBit(UNIT_FIELD_MAXPOWER3  );        
						updateMask.setBit(UNIT_FIELD_MAXPOWER4 );
						updateMask.setBit(UNIT_FIELD_LEVEL  );            
						updateMask.setBit(UNIT_FIELD_FACTIONTEMPLATE  );
						updateMask.setBit(UNIT_FIELD_BYTES_0 );          
						updateMask.setBit(PLAYER_FIELD_STAT0  );
						updateMask.setBit(PLAYER_FIELD_STAT1 );            
						updateMask.setBit(PLAYER_FIELD_STAT2 );
						updateMask.setBit(PLAYER_FIELD_STAT3  );            
						updateMask.setBit(PLAYER_FIELD_STAT4  );
						updateMask.setBit(PLAYER_FIELD_POSSTAT0  );        
						updateMask.setBit(PLAYER_FIELD_POSSTAT1 );
						updateMask.setBit(PLAYER_FIELD_POSSTAT2 );        
						updateMask.setBit(PLAYER_FIELD_POSSTAT3 );
						updateMask.setBit(PLAYER_FIELD_POSSTAT4 );        
						updateMask.setBit(PLAYER_FIELD_NEGSTAT0  );        
						updateMask.setBit(PLAYER_FIELD_NEGSTAT1 );
						updateMask.setBit(PLAYER_FIELD_NEGSTAT2 );        
						updateMask.setBit(PLAYER_FIELD_NEGSTAT3 );
						updateMask.setBit(PLAYER_FIELD_NEGSTAT4 );        

						updateMask.setBit(PLAYER_FIELD_COINAGE  );
						updateMask.setBit(UNIT_FIELD_FLAGS  );
						updateMask.setBit(UNIT_FIELD_BASEATTACKTIME );   
						updateMask.setBit(UNIT_FIELD_BASEATTACKTIME+1  );
						updateMask.setBit(UNIT_FIELD_BOUNDINGRADIUS );  
						updateMask.setBit(UNIT_FIELD_COMBATREACH   );
						updateMask.setBit(UNIT_FIELD_DISPLAYID  );       
						updateMask.setBit(UNIT_FIELD_MINDAMAGE);
						updateMask.setBit(UNIT_FIELD_MAXDAMAGE );       
						updateMask.setBit(PLAYER_FIELD_ATTACKPOWER );
                        updateMask.setBit(PLAYER_FIELD_ATTACKPOWERMODPOS );
                        updateMask.setBit(PLAYER_FIELD_ATTACKPOWERMODNEG );
						updateMask.setBit(PLAYER_BYTES);
						updateMask.setBit(PLAYER_BYTES_2 );
						updateMask.setBit(PLAYER_XP );                 
						updateMask.setBit(PLAYER_NEXT_LEVEL_XP);
						updateMask.setBit(PLAYER_REST_STATE_EXPERIENCE );                         
						updateMask.setBit(UNIT_FIELD_MOUNTDISPLAYID);

                        Item *tempitem;
/*
						// Send messages to the new client creating all existing players in the world
						Log::getSingleton( ).outString( "WORLD: Create existing players" );
						WorldServer::ClientSet::iterator iter;
						
						for (iter = world.mClients.begin(); iter != world.mClients.end(); iter++){
							if (((pClient->getCurrentChar() != (Character*)0) && (pClient != (*iter))) && (((GameClient*)(*iter))->getCurrentChar() != (Character*)0)) {
								if (pClient->getCurrentChar()->getZone() != ((GameClient*)(*iter))->getCurrentChar()->getZone())
									continue;
								Character *chr = ((GameClient*)(*iter))->getCurrentChar();
								if( chr ) {
									for(i = 0; i<46; i++)
									{
										updateMask.unSetBit( PLAYER_FIELD_INV_SLOT_HEAD + i );
									}
									for(i = 0; i<46; i+=2)
									{
										if (chr->m_items[i/2].guid != 0) {
											chr->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i , chr->m_items[i/2].guid, updateMask.updateMask );
											chr->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i + 1 , 0x00000040, updateMask.updateMask);
										}
									}								
									data.clear();
									chr->CreateObject(&updateMask, &data, 0);
									net->sendWData(&data);

									for(invcount = 0; invcount < 23; invcount++)
									{
										if (chr->m_items[invcount].guid != 0) {
											data.clear();

											invUpdateMask.clear();
											invUpdateMask.setCount(0x02);
											tempitem = new Item;

											invUpdateMask.setBit( OBJECT_FIELD_GUID );
											invUpdateMask.setBit( OBJECT_FIELD_GUID+1 );
											invUpdateMask.setBit( OBJECT_FIELD_TYPE );
											invUpdateMask.setBit( OBJECT_FIELD_ENTRY );
											invUpdateMask.setBit( OBJECT_FIELD_SCALE_X );
											invUpdateMask.setBit( OBJECT_FIELD_PADDING );
											invUpdateMask.setBit( ITEM_FIELD_OWNER );
											invUpdateMask.setBit( ITEM_FIELD_CONTAINED );
											invUpdateMask.setBit( ITEM_FIELD_OWNER +1 );
											invUpdateMask.setBit( ITEM_FIELD_CONTAINED +1 );
											invUpdateMask.setBit( ITEM_FIELD_STACK_COUNT );
											tempitem->Create(chr->m_items[invcount].guid,chr->m_items[invcount].itemid);
											tempitem->setUpdateValue( OBJECT_FIELD_GUID , chr->m_items[invcount].guid ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_GUID+1 , 0x00000040 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_TYPE , 0x00000003 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_ENTRY , chr->m_items[invcount].itemid ,invUpdateMask.updateMask);
											tempitem->setUpdateFloatValue( OBJECT_FIELD_SCALE_X , 1.0f ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( OBJECT_FIELD_PADDING , 0xeeeeeeee ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_OWNER , chr->getGUID() ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_CONTAINED , chr->getGUID() ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_OWNER +1 , 0 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_CONTAINED +1 , 0 ,invUpdateMask.updateMask);
											tempitem->setUpdateValue( ITEM_FIELD_STACK_COUNT , 1 ,invUpdateMask.updateMask);

											tempitem->CreateObject(&invUpdateMask, &data, 0);
											pClient->getNetwork()->sendWData(&data);
											delete tempitem;
										}
									}

								}
							}
						}
*/

                        ////////  Send Create Message to Myself 
						// Set flags and values here only the client player cares about
						pClient->getCurrentChar()->setQuestLogBits(&updateMask);

						for(i = 0; i<78; i++)
						{
							updateMask.unSetBit( PLAYER_FIELD_INV_SLOT_HEAD + i );
						}

						for(i = 0; i<78; i+=2)
						{
							if (pClient->getCurrentChar()->m_items[i/2].guid != 0) {
								pClient->getCurrentChar()->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i , pClient->getCurrentChar()->m_items[i/2].guid,  updateMask.updateMask);
								pClient->getCurrentChar()->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i + 1 , 0x00000040,  updateMask.updateMask);
							}
						}

//						pClient->getCurrentChar()->m_positionZ+=6; // quick hack to stop player from falling through the ground
						data.clear();
						pClient->getCurrentChar()->CreateObject(&updateMask, &data, 0x00000001);
						pClient->getNetwork()->sendWData(&data);
						Log::getSingleton( ).outString( "WORLD: Create Player Character" );

						for(invcount = 0; invcount < 39; invcount++)
						{
							if (pClient->getCurrentChar()->m_items[invcount].guid != 0) {
								data.clear();

								invUpdateMask.clear();
								invUpdateMask.setCount(0x02);
								tempitem = new Item;

								invUpdateMask.setBit( OBJECT_FIELD_GUID );
								invUpdateMask.setBit( OBJECT_FIELD_GUID+1 );
								invUpdateMask.setBit( OBJECT_FIELD_TYPE );
								invUpdateMask.setBit( OBJECT_FIELD_ENTRY );
								invUpdateMask.setBit( OBJECT_FIELD_SCALE_X );
								invUpdateMask.setBit( OBJECT_FIELD_PADDING );
								invUpdateMask.setBit( ITEM_FIELD_OWNER );
								invUpdateMask.setBit( ITEM_FIELD_CONTAINED );
								invUpdateMask.setBit( ITEM_FIELD_OWNER +1 );
								invUpdateMask.setBit( ITEM_FIELD_CONTAINED +1 );
								invUpdateMask.setBit( ITEM_FIELD_STACK_COUNT );
								tempitem->Create(pClient->getCurrentChar()->m_items[invcount].guid,pClient->getCurrentChar()->m_items[invcount].itemid);
								tempitem->setUpdateValue( OBJECT_FIELD_GUID , pClient->getCurrentChar()->m_items[invcount].guid ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_GUID+1 , 0x00000040 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_TYPE , 0x00000003 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_ENTRY , pClient->getCurrentChar()->m_items[invcount].itemid ,invUpdateMask.updateMask);
								tempitem->setUpdateFloatValue( OBJECT_FIELD_SCALE_X , 1.0f ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_PADDING , 0xeeeeeeee ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_OWNER , pClient->getCurrentChar()->getGUID() ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_CONTAINED , pClient->getCurrentChar()->getGUID() ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_OWNER +1 , 0 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_CONTAINED +1 , 0 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_STACK_COUNT , 1 ,invUpdateMask.updateMask);

								tempitem->CreateObject(&invUpdateMask, &data, 0);
								pClient->getNetwork()->sendWData(&data);
								delete tempitem;
							}
						}

						// Add character to the ingame list
						// And let this client know we're in game
						pClient->InWorld(true);
						world.mCharacters[ pClient->getCurrentChar()->getGUID() ] = pClient->getCurrentChar();

                        // Build the in-range set
                        WorldServer::getSingleton().CheckForInRangeObjects(pClient->getCurrentChar());

						// Send a message that a new playera has entered the world
						data.clear();
						for(i = 0; i<46; i++)
						{
							updateMask.unSetBit( PLAYER_FIELD_INV_SLOT_HEAD + i );
						}
						for(i = 0; i<46; i+=2)
						{
							if (pClient->getCurrentChar()->m_items[i/2].guid != 0) {
								pClient->getCurrentChar()->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i , pClient->getCurrentChar()->m_items[i/2].guid,  updateMask.updateMask);
								pClient->getCurrentChar()->setUpdateValue( PLAYER_FIELD_INV_SLOT_HEAD + i + 1 , 0x00000040,  updateMask.updateMask);
							}

						}
						data.clear();
						pClient->getCurrentChar()->CreateObject(&updateMask, &data, 0);
//						world.SendZoneMessage(&data, pClient, 0);
                        pClient->getCurrentChar()->SendMessageToSet(&data, false);
						Log::getSingleton( ).outString( "WORLD: Create new player for existing players" );

						for(invcount = 0; invcount < 23; invcount++)
						{
							if ((pClient->getCurrentChar()->m_items[invcount].guid != 0) && (pClient->getCurrentChar()->m_items[invcount].guid != NULL)){
								data.clear();

								invUpdateMask.clear();
								invUpdateMask.setCount(0x02);
								tempitem = new Item;

								invUpdateMask.setBit( OBJECT_FIELD_GUID );
								invUpdateMask.setBit( OBJECT_FIELD_GUID+1 );
								invUpdateMask.setBit( OBJECT_FIELD_TYPE );
								invUpdateMask.setBit( OBJECT_FIELD_ENTRY );
								invUpdateMask.setBit( OBJECT_FIELD_SCALE_X );
								invUpdateMask.setBit( OBJECT_FIELD_PADDING );
								invUpdateMask.setBit( ITEM_FIELD_OWNER );
								invUpdateMask.setBit( ITEM_FIELD_CONTAINED );
								invUpdateMask.setBit( ITEM_FIELD_OWNER +1 );
								invUpdateMask.setBit( ITEM_FIELD_CONTAINED +1 );
								invUpdateMask.setBit( ITEM_FIELD_STACK_COUNT );
								tempitem->Create(pClient->getCurrentChar()->m_items[invcount].guid,pClient->getCurrentChar()->m_items[invcount].itemid);
								tempitem->setUpdateValue( OBJECT_FIELD_GUID , pClient->getCurrentChar()->m_items[invcount].guid ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_GUID+1 , 0x00000040 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_TYPE , 0x00000003 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_ENTRY , pClient->getCurrentChar()->m_items[invcount].itemid ,invUpdateMask.updateMask);
								tempitem->setUpdateFloatValue( OBJECT_FIELD_SCALE_X , 1.0f ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( OBJECT_FIELD_PADDING , 0xeeeeeeee ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_OWNER , pClient->getCurrentChar()->getGUID() ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_CONTAINED , pClient->getCurrentChar()->getGUID() ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_OWNER +1 , 0 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_CONTAINED +1 , 0 ,invUpdateMask.updateMask);
								tempitem->setUpdateValue( ITEM_FIELD_STACK_COUNT , 1 ,invUpdateMask.updateMask);

								tempitem->CreateObject(&invUpdateMask, &data, 0);
//								world.SendZoneMessage(&data, pClient, 0);
                                pClient->getCurrentChar()->SendMessageToSet(&data, false);
								delete tempitem;
							}
						}

/*
						Log::getSingleton( ).outString( "WORLD: Creating creatures..." );
						for( WorldServer::CreatureMap::iterator i = world.mCreatures.begin( ); i != world.mCreatures.end( ); ++ i ) {
							if (pClient->getCurrentChar()->getZone() != i->second->getZone())
									continue;
							data.clear();
                            UpdateMask unitMask;
                            WorldServer::getSingletonPtr()->mObjectMgr.SetCreateUnitBits(unitMask);

							i->second->SendCreateWithTempNpcFlags(&unitMask, pClient);
							i->second->clearUpdateMask();
						}
*/
						printf("%s\n",pClient->getCharacterName( ));
						std::string outstring = pClient->getCharacterName( );
						outstring.append( " has entered the world." );
						world.SendWorldText( (uint8*)outstring.c_str( ) );	
					}break;

				case CMSG_SET_TARGET:
					{
						Log::getSingleton( ).outString( "WORLD: Recieved CMSG_SET_TARGET" );
						uint32 guid1, guid2;
						recv_data >> guid1 >> guid2;
						if( pClient->getCurrentChar( ) != 0 ) {
							pClient->getCurrentChar( )->m_curTarget[ 0 ] = guid1;
							pClient->getCurrentChar( )->m_curTarget[ 1 ] = guid2;
						}
					}break;

				case CMSG_SET_SELECTION:
					{
//						Log::getSingleton( ).outString( "WORLD: Recieved CMSG_SET_SELECTION" );
						if( pClient->getCurrentChar( ) != 0 )
							recv_data >> pClient->getCurrentChar( )->m_curSelection[ 0 ] >> pClient->getCurrentChar( )->m_curSelection[ 1 ];
					}break;
				case CMSG_STANDSTATECHANGE:
					{
						if( pClient->getCurrentChar( ) != 0 ) {
                            // retrieve current BYTES
                            uint32 bytes1 = pClient->getCurrentChar( )->getUpdateValue( UNIT_FIELD_BYTES_1 );
                            uint8 bytes[4];
                            bytes[0] = uint8(bytes1 & 0xff);
                            bytes[1] = uint8((bytes1>>8) & 0xff);
                            bytes[2] = uint8((bytes1>>16) & 0xff);
                            bytes[3] = uint8((bytes1>>24) & 0xff);

                            // retrieve new stand state
                            uint8 animstate;
							recv_data >> animstate;

//                            if (bytes[0] == animstate) break;
                            bytes[0] = animstate;

                            uint32 newbytes = (bytes[0]) + (bytes[1]<<8) + (bytes[2]<<16) + (bytes[3]<<24);
							pClient->getCurrentChar( )->setUpdateValue(UNIT_FIELD_BYTES_1 , newbytes);
						}
					}break;


					// Friends related

					/*
					case  	CMSG_NAME_QUERY:
					{
					Log::getSingleton( ).outString( "WORLD: Recieved CMSG_NAME_QUERY"  );



					uint64 GUID=0;
					recv_data >> GUID;
					char tmpBuf[2156];
					sprintf( tmpBuf, "WORLD: %s name querried : '%d'", pClient->getCharacterName( ), GUID );
					Log::getSingleton( ).outString( tmpBuf );


					uint64  	GUID
					string 	Name
					uint 	Race
					uint 	Sex
					uint 	Class

					int FriendArea=0;
					int FriendLevel=0;
					int FriendClass=0;



					// TODO: Delete Friend from list, and fill in FriendResult.



					// Send reposnse.
					data.clear();
					data.opcode =SMSG_FRIEND_STATUS;
					data.length=sizeof(FriendResult) + sizeof(FriendGUID);
					data.data= new uint8[ data.length ];
					data <<  FriendResult << FriendGUID;		
					net->sendWData( &data );

					Log::getSingleton( ).outString( "WORLD: Sent motd (SMSG_FRIEND_STATUS)" );




					}break;*/
				case CMSG_FRIEND_LIST:
					{
						char tmpBuf[2156];

						Log::getSingleton( ).outString( "WORLD: Recieved CMSG_FRIEND_LIST"  );
						// TODO: send SMSG_FRIEND_LIST with a list of friend

						unsigned char Counter=0;
						while (0) {
							// get friend list add them to buffer	
						}

						FriendStr friendstr[255];


						/// add RandomGuy to the friend's list
						friendstr[Counter].PlayerGUID= 48;
						friendstr[Counter].Status=0;
						friendstr[Counter].Area=0;
						friendstr[Counter].Level=1;
						friendstr[Counter].Class=1;
						Counter++;

						data.clear();
						data.opcode =SMSG_FRIEND_LIST;
						data.length=sizeof(Counter) + (Counter * sizeof(friendstr));
						data.data= new uint8[ data.length ];

						data << Counter;

						for (int j=0; j<Counter; j++) {
							//adding friend
							sprintf(tmpBuf,"Adding Friend - Guid:%ld, Status:%d, Area:%d, Level:%d Class:%d",
								friendstr[j].PlayerGUID, friendstr[j].Status, friendstr[j].Area,friendstr[j].Level,friendstr[j].Class);
							Log::getSingleton( ).outString( tmpBuf  );
							data << friendstr[j].PlayerGUID << friendstr[j].Status ;
							if (friendstr[j].Status != 0)
								data << friendstr[j].Area << friendstr[j].Level << friendstr[j].Class;
						}


						net->sendWData( &data );




						Log::getSingleton( ).outString( "WORLD: Sent (SMSG_FRIEND_LIST)" );



					}break;
				case CMSG_ADD_FRIEND:
					{
						Log::getSingleton( ).outString( "WORLD: Recieved CMSG_ADD_FRIEND"  );

						char FriendName[2048]="UNKNOWN";
						recv_data >> FriendName;
						char tmpBuf[2156];
						sprintf( tmpBuf, "WORLD: %s asked to add friend : '%s'", pClient->getCharacterName( ), FriendName );
						Log::getSingleton( ).outString( tmpBuf );


						unsigned char FriendResult = FRIEND_NOT_FOUND;
						uint64 friendGuid = 0;
						int FriendArea=0;
						int FriendLevel=0;
						int FriendClass=0;


						// TODO: Add Friend To list, and fill in FriendResult.
						int tmpguid = pClient->getDB()->GetNameGUID(FriendName);
						if (tmpguid > 0) {
							friendGuid = tmpguid;

							if( world.mCharacters.find( (uint32)friendGuid ) != world.mCharacters.end( ) )
								FriendResult = FRIEND_ADDED_ONLINE;	
							else
								FriendResult = FRIEND_ADDED_OFFLINE;	

							sprintf( tmpBuf, "WORLD: %s Guid found '%ld' area:%d Level:%d Class:%d. ", FriendName , friendGuid, FriendArea,FriendLevel,FriendClass);
							Log::getSingleton( ).outString( tmpBuf );

						} else {
							sprintf( tmpBuf, "WORLD: %s Guid not found ", FriendName );
							Log::getSingleton( ).outString( tmpBuf );
						}


						if (!strcmp(pClient->getCharacterName(),FriendName))
							FriendResult = FRIEND_SELF;

						// Send reposnse.
						data.clear();
						data.opcode =SMSG_FRIEND_STATUS;
						if (FriendResult ==  FRIEND_ADDED_ONLINE || FriendResult == FRIEND_ONLINE || 
							FriendResult ==  FRIEND_OFFLINE  
							//|| FriendResult ==  FRIEND_ADDED_OFFLINE 
							){
								data.length=sizeof(FriendResult) + sizeof(friendGuid) + sizeof(FriendArea) 
									+ sizeof(FriendLevel) +  sizeof(FriendClass);
								data.data= new uint8[ data.length ];
								data <<  FriendResult << friendGuid;
								data <<  FriendArea << FriendLevel << FriendClass;
							}
						else {
							data.length=sizeof(FriendResult) + sizeof(friendGuid);
							data.data= new uint8[ data.length ];
							data <<  FriendResult << friendGuid;					
						}

						net->sendWData( &data );

						Log::getSingleton( ).outString( "WORLD: Sent (SMSG_FRIEND_STATUS)" );

					}break;
				case CMSG_DEL_FRIEND:
					{
						Log::getSingleton( ).outString( "WORLD: Recieved CMSG_DEL_FRIEND"  );


						uint64 FriendGUID;
						recv_data >> FriendGUID;
						char tmpBuf[2156];
						sprintf( tmpBuf, "WORLD: %s asked to Remove friend : '%ld'", pClient->getCharacterName( ), FriendGUID );
						Log::getSingleton( ).outString( tmpBuf );


						unsigned char FriendResult = FRIEND_REMOVED;
						int FriendArea=0;
						int FriendLevel=0;
						int FriendClass=0;



						// TODO: Delete Friend from list, and fill in FriendResult.



						// Send reposnse.
						data.clear();
						data.opcode =SMSG_FRIEND_STATUS;
						data.length=sizeof(FriendResult) + sizeof(FriendGUID);
						data.data= new uint8[ data.length ];
						data <<  FriendResult << FriendGUID;		
						net->sendWData( &data );

						Log::getSingleton( ).outString( "WORLD: Sent motd (SMSG_FRIEND_STATUS)" );



					}break;
				case CMSG_BUG:
					{
						uint32 suggestion, contentlen;
						std::string content;
						uint32 typelen;
						std::string type;
						recv_data >> suggestion >> contentlen >> content >> typelen >> type;
						if( suggestion == 0 )
							Log::getSingleton( ).outString( "WORLD: Recieved CMSG_BUG [Bug Report]" );
						else
							Log::getSingleton( ).outString( "WORLD: Recieved CMSG_BUG [Suggestion]" );
						Log::getSingleton( ).outString( type.c_str( ) );
						Log::getSingleton( ).outString( content.c_str( ) );
					}break;
                case CMSG_JOIN_CHANNEL:
					{
                     
                        char channelname[50] = "General - Elwynn Forest";
                        recv_data >> channelname;
					    data.Initialise((sizeof(channelname)+6), SMSG_CHANNEL_NOTIFY);
                        data << uint8(2);
                        data << channelname;
                        data << uint8(0);
                        data << uint32(1);
                        pClient->SendMsg( &data );
					}break;
    }
}
