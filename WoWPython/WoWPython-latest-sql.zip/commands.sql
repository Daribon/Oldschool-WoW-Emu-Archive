#----------------------------
# Table structure for commands
#----------------------------
CREATE TABLE `commands` (
  `name` varchar(100) NOT NULL default '',
  `security` int(11) NOT NULL default '0',
  `help` longtext NOT NULL
) TYPE=MyISAM;

#----------------------------
# Records for table commands
#----------------------------

insert  into commands values
('help', 0, 'Syntax: !help <command name>\r\nDisplays help on a command.');
