# Connection: 192.168.0.10
# Host: 192.168.0.10
# Saved: 2004-08-06 12:14:34
# 
#  NPC Text Database Patch


create table npc_text (id INT NOT NULL PRIMARY KEY,type
INT NOT NULL,guid INT(6) UNSIGNED NOT NULL);
INSERT INTO npc_text VALUES (0,0,0);