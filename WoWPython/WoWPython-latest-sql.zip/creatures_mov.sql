/*
MySQL Backup
Source Host:           localhost
Source Server Version: 4.0.20a-nt
Source Database:       wow
Date:                  2004-08-01 17:48:34
*/

SET FOREIGN_KEY_CHECKS=0;
#----------------------------
# Table structure for creatures_mov
#----------------------------
CREATE TABLE `creatures_mov` (
  `id` bigint(20) NOT NULL auto_increment,
  `creatureId` bigint(20) NOT NULL default '0',
  `X` float NOT NULL default '0',
  `Y` float NOT NULL default '0',
  `Z` float NOT NULL default '0',
  PRIMARY KEY  (`id`)
) TYPE=MyISAM;
#UPDATES CREATURE TABLE
ALTER TABLE `creatures` ADD `moverandom` INT( 11 ) DEFAULT '1',
ADD `running` INT( 11 ) DEFAULT '0';
