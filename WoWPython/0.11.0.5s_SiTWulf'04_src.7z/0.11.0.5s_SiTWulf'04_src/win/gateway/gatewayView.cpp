// gatewayView.cpp : implementation of the CGatewayView class
//

#include "stdafx.h"
#include "gateway.h"

#include "gatewayDoc.h"
#include "gatewayView.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CGatewayView

IMPLEMENT_DYNCREATE(CGatewayView, CView)

BEGIN_MESSAGE_MAP(CGatewayView, CView)
	//{{AFX_MSG_MAP(CGatewayView)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CGatewayView construction/destruction

CGatewayView::CGatewayView()
{
	// TODO: add construction code here

}

CGatewayView::~CGatewayView()
{
}

BOOL CGatewayView::PreCreateWindow(CREATESTRUCT& cs)
{
	// TODO: Modify the Window class or styles here by modifying
	//  the CREATESTRUCT cs

	return CView::PreCreateWindow(cs);
}

/////////////////////////////////////////////////////////////////////////////
// CGatewayView drawing

void CGatewayView::OnDraw(CDC* pDC)
{
	CGatewayDoc* pDoc = GetDocument();
	ASSERT_VALID(pDoc);
	// TODO: add draw code for native data here
}

/////////////////////////////////////////////////////////////////////////////
// CGatewayView diagnostics

#ifdef _DEBUG
void CGatewayView::AssertValid() const
{
	CView::AssertValid();
}

void CGatewayView::Dump(CDumpContext& dc) const
{
	CView::Dump(dc);
}

CGatewayDoc* CGatewayView::GetDocument() // non-debug version is inline
{
	ASSERT(m_pDocument->IsKindOf(RUNTIME_CLASS(CGatewayDoc)));
	return (CGatewayDoc*)m_pDocument;
}
#endif //_DEBUG

/////////////////////////////////////////////////////////////////////////////
// CGatewayView message handlers
