// gateway.h : main header file for the GATEWAY application
//

#if !defined(AFX_GATEWAY_H__5928C1DD_FDE2_4763_91EA_BC89137C9BA4__INCLUDED_)
#define AFX_GATEWAY_H__5928C1DD_FDE2_4763_91EA_BC89137C9BA4__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#ifndef __AFXWIN_H__
	#error include 'stdafx.h' before including this file for PCH
#endif

#include "resource.h"       // main symbols

/////////////////////////////////////////////////////////////////////////////
// CGatewayApp:
// See gateway.cpp for the implementation of this class
//

class CGatewayApp : public CWinApp
{
public:
	CGatewayApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGatewayApp)
	public:
	virtual BOOL InitInstance();
	//}}AFX_VIRTUAL

// Implementation
	//{{AFX_MSG(CGatewayApp)
	afx_msg void OnAppAbout();
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};


/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GATEWAY_H__5928C1DD_FDE2_4763_91EA_BC89137C9BA4__INCLUDED_)
