// gatewayView.h : interface of the CGatewayView class
//
/////////////////////////////////////////////////////////////////////////////

#if !defined(AFX_GATEWAYVIEW_H__6543BFC7_0206_4752_BDD5_9F322121265E__INCLUDED_)
#define AFX_GATEWAYVIEW_H__6543BFC7_0206_4752_BDD5_9F322121265E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000


class CGatewayView : public CView
{
protected: // create from serialization only
	CGatewayView();
	DECLARE_DYNCREATE(CGatewayView)

// Attributes
public:
	CGatewayDoc* GetDocument();

// Operations
public:

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CGatewayView)
	public:
	virtual void OnDraw(CDC* pDC);  // overridden to draw this view
	virtual BOOL PreCreateWindow(CREATESTRUCT& cs);
	protected:
	//}}AFX_VIRTUAL

// Implementation
public:
	virtual ~CGatewayView();
#ifdef _DEBUG
	virtual void AssertValid() const;
	virtual void Dump(CDumpContext& dc) const;
#endif

protected:

// Generated message map functions
protected:
	//{{AFX_MSG(CGatewayView)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

#ifndef _DEBUG  // debug version in gatewayView.cpp
inline CGatewayDoc* CGatewayView::GetDocument()
   { return (CGatewayDoc*)m_pDocument; }
#endif

/////////////////////////////////////////////////////////////////////////////

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_GATEWAYVIEW_H__6543BFC7_0206_4752_BDD5_9F322121265E__INCLUDED_)
