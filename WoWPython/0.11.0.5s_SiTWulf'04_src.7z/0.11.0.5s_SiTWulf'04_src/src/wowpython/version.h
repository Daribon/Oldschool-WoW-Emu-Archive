#ifndef VERSION
# define VERSION "0.11.0.5S"
#endif
#if PLATFORM == PLATFORM_WIN32
# define FULLVERSION VERSION "-win"
#else
# define FULLVERSION VERSION "-*nix"
#endif
