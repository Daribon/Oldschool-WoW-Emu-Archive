// THIS FILE WILL BE OVERWRITTEN BY DEV-C++!
// DO NOT EDIT!

#ifndef WOWPYTHON_PRIVATE_H
#define WOWPYTHON_PRIVATE_H

// VERSION DEFINITIONS
#define VER_STRING	"0.11.0.5"
#define VER_MAJOR	0
#define VER_MINOR	11
#define VER_RELEASE	0
#define VER_BUILD	5
#define COMPANY_NAME	"WSD Team"
#define FILE_VERSION	""
#define FILE_DESCRIPTION	"World of Warcraft Server Emulation"
#define INTERNAL_NAME	""
#define LEGAL_COPYRIGHT	"WSDTeam Copyright (C) 2004-2005"
#define LEGAL_TRADEMARKS	""
#define ORIGINAL_FILENAME	"wsdserver.exe"
#define PRODUCT_NAME	"WoWPython"
#define PRODUCT_VERSION	""

#endif //WOWPYTHON_PRIVATE_H
