The following files:
wowpython.dev
wowpython.ico
wowpython_private.h
wowpython_private.rc
are only required by the Bloodshed Dev-C++ IDE.