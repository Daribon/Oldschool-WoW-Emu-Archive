#
# Extraindo dados da tabela `worldports`
#

INSERT INTO `worldports` VALUES (10, 1, 'Thunderbluff', '-1200', '-50', '200');
INSERT INTO `worldports` VALUES (9, 1, 'Orgimmar', '1484', '-4417', '25');
INSERT INTO `worldports` VALUES (11, 1, 'Darnassus', '9948', '2413', '1330');
INSERT INTO `worldports` VALUES (12, 0, 'Ironforge', '-4981', '-881', '505');
INSERT INTO `worldports` VALUES (13, 0, 'Stormwind', '-8913', '554', '100');
INSERT INTO `worldports` VALUES (15, 0, 'Undercity', '1628', '239', '65');
INSERT INTO `worldports` VALUES (16, 0, 'Gnomeregan', '-5179', '660', '390');
INSERT INTO `worldports` VALUES (17, 0, 'Dalaran', '386', '212', '45');
INSERT INTO `worldports` VALUES (18, 0, 'Darkshire', '-10567', '-1169', '30');
INSERT INTO `worldports` VALUES (19, 0, 'AeriePeak', '327', '-1959', '200');
INSERT INTO `worldports` VALUES (20, 0, 'Lakeshire', '-9282', '-2269', '70');
INSERT INTO `worldports` VALUES (21, 0, 'Ambermill', '-126', '815', '70');
INSERT INTO `worldports` VALUES (22, 0, 'BootyBay', '-14406', '419', '25');
INSERT INTO `worldports` VALUES (23, 0, 'Stonard', '-10452', '-3263', '22');
INSERT INTO `worldports` VALUES (24, 0, 'Brill', '2260', '289', '35');
INSERT INTO `worldports` VALUES (25, 0, 'Moonbrook', '-11018', '1513', '45');
INSERT INTO `worldports` VALUES (26, 0, 'Menethil', '-3740', '-755', '15');
INSERT INTO `worldports` VALUES (27, 1, 'Astrnaar', '2745', '-378', '110');
INSERT INTO `worldports` VALUES (28, 1, 'Aszhara', '3546', '-5287', '110');
INSERT INTO `worldports` VALUES (29, 1, 'BaelModan', '-4095', '-2305', '125');
INSERT INTO `worldports` VALUES (30, 1, 'Crossroads', '-456', '-2652', '96');
INSERT INTO `worldports` VALUES (31, 1, 'Auberdine', '6439', '614', '6');
INSERT INTO `worldports` VALUES (32, 1, 'Thalanaar', '-4517', '-780', '-39');
INSERT INTO `worldports` VALUES (33, 1, 'Razorhill', '304', '-4734', '10');
INSERT INTO `worldports` VALUES (34, 1, 'BloodhoofVillage', '-2321', '-378', '-8');
INSERT INTO `worldports` VALUES (35, 1, 'Racetrack', '-6202', '-3901', '-59');
INSERT INTO `worldports` VALUES (36, 1, 'Tanaris', '-6942', '-4847', '1');
INSERT INTO `worldports` VALUES (37, 1, 'StonetalonPeak', '2506', '1470', '263');
INSERT INTO `worldports` VALUES (38, 1, 'FreewindPost', '-5437', '-2437', '90');
INSERT INTO `worldports` VALUES (39, 1, 'Dolanaar', '9892', '982', '1314');
INSERT INTO `worldports` VALUES (40, 1, 'TheramoreIsle', '-3729', '-4421', '31');
INSERT INTO `worldports` VALUES (42, 1, 'Hyjal', '4674', '-3638', '1000');
INSERT INTO `worldports` VALUES (43, 0, 'ColdRidge', '-6325', '294', '380');
INSERT INTO `worldports` VALUES (45, 0, 'Deathknell', '1871', '1587', '92');