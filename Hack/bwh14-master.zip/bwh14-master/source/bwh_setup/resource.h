//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by bwh_setup.rc
//
#define IDD_MAIN                        101
#define IDI_MAIN                        103
#define IDD_ASSIGN                      104
#define IDC_POINTERS                    1001
#define IDC_SCAN                        1002
#define IDC_FILENAME                    1003
#define IDC_BROWSE                      1004
#define IDC_SAVE                        1005
#define IDC_VIEW                        1006
#define IDC_HOTKEYS                     1007
#define IDC_DEFAULT                     1008
#define IDC_UNBIND                      1009
#define IDC_ASSIGN                      1010
#define IDC_FIXED                       1011
#define IDC_PROPORTIONAL                1012
#define IDC_SETFIXED                    1013
#define IDC_SETPROPORTIONAL             1014
#define IDC_BUTTON1                     1015
#define IDC_DUMMY                       1015

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        105
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1016
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
