#include <windows.h>

VOID scanTrackingTrackStructOffset_Init(HWND hwndList);