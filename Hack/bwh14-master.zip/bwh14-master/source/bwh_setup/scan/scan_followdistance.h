#include <windows.h>

VOID scanFollowDistance_Init(HWND hwndList);