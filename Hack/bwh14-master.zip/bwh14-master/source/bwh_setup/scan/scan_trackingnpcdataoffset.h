#include <windows.h>

VOID scanTrackingNpcDataOffset_Init(HWND hwndList);