#include <windows.h>

VOID scanTrackingCharTypeOffset_Init(HWND hwndList);