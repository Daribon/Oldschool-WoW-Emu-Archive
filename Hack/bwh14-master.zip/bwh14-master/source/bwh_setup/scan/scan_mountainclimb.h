#include <windows.h>

VOID scanMountainClimb_Init(HWND hwndList);