#include <windows.h>

VOID scanGetCharacterGuid_Init(HWND hwndList);