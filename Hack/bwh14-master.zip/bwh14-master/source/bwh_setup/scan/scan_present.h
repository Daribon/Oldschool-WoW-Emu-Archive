#include <windows.h>

VOID scanPresent_Init(HWND hwndList);