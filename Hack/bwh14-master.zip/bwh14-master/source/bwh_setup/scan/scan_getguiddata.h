#include <windows.h>

VOID scanGetGuidData_Init(HWND hwndList);