#include <windows.h>

VOID scanCorpse_Init(HWND hwndList);