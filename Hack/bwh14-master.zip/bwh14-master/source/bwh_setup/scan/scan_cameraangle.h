#include <windows.h>

VOID scanCameraAngle_Init(HWND hwndList);