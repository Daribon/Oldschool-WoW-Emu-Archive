#include <windows.h>

VOID scanReset_Init(HWND hwndList);