#include <windows.h>

VOID scanFollowNpc2_Init(HWND hwndList);