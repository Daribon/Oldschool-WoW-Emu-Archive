#include <windows.h>

VOID scanTrackingJumpSize_Init(HWND hwndList);