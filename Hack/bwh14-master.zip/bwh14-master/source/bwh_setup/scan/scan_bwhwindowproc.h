#include <windows.h>

VOID scanBwhWindowProc_Init(HWND hwndList);