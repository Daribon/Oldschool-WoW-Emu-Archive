#include <windows.h>

VOID scanNoFallDamageOffset_Init(HWND hwndList);