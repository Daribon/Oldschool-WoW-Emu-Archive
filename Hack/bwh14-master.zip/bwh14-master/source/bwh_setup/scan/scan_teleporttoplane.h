#include <windows.h>

VOID scanTeleportToPlane_Init(HWND hwndList);