#include <windows.h>

VOID scanTrackingCharStruct2Offset_Init(HWND hwndList);