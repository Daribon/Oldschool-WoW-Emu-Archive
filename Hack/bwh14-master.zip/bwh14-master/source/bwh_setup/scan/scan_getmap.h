#include <windows.h>

VOID scanGetMap_Init(HWND hwndList);