#include <windows.h>

VOID scanNoFallDamageHook_Init(HWND hwndList);