#include <windows.h>

VOID scanFallingTeleport_Init(HWND hwndList);