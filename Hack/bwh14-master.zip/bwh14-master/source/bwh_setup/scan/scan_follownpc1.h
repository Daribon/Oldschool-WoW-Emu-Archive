#include <windows.h>

VOID scanFollowNpc1_Init(HWND hwndList);