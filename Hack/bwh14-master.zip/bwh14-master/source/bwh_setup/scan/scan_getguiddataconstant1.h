#include <windows.h>

VOID scanGetGuidDataConstant1_Init(HWND hwndList);