#include <windows.h>

VOID scanLockSpeed_Init(HWND hwndList);