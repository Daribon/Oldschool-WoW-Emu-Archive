#include <windows.h>

VOID scanGetGuidDataConstant2_Init(HWND hwndList);