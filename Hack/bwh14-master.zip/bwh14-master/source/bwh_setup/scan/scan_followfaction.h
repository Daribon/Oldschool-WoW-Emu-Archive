#include <windows.h>

VOID scanFollowFaction_Init(HWND hwndList);