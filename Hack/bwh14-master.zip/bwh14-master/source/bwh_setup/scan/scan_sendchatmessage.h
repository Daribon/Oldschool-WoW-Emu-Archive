#include <windows.h>

VOID scanSendChatMessage_Init(HWND hwndList);