#include <windows.h>

VOID scan/*change me*/_Init(HWND hwndList);