#include <windows.h>

VOID scanTrackingHook_Init(HWND hwndList);