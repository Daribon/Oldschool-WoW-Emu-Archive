#include <windows.h>

VOID scanWowWindowProc_Init(HWND hwndList);