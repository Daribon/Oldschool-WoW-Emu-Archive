#include <windows.h>

VOID scanTrackingTrackDataOffset_Init(HWND hwndList);