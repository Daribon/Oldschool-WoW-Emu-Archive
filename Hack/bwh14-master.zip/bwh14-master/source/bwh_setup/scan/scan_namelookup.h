#include <windows.h>

VOID scanNameLookup_Init(HWND hwndList);