#include <windows.h>

VOID scanZeroGravity_Init(HWND hwndList);