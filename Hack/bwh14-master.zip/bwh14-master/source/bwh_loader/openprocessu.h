#ifndef _OPENPROCESSU_H
#define _OPENPROCESSU_H

#include <windows.h>

HANDLE OpenProcessU(DWORD dwDesiredAccess, DWORD dwPId);

#endif