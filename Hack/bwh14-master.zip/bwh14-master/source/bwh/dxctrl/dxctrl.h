#ifndef _DXCTRL_H
#define _DXCTRL_H

#include "dxctrlmanager.h"
#include "dxctrlbase.h"
#include "dxctrlwindow.h"
#include "dxctrlstatic.h"
#include "dxctrldialog.h"
#include "dxctrlbutton.h"
#include "dxctrltextbox.h"
#include "dxctrltreeview.h"

#endif