#ifndef _ZEROGRAVITY_H
#define _ZEROGRAVITY_H

#include <windows.h>

VOID ZeroGravity_Enable(PDWORD pZeroGravity, BOOL bEnable);

#endif