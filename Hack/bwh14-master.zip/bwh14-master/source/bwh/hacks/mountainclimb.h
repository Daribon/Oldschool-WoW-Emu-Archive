#ifndef _MOUNTAINCLIMB_H
#define _MOUNTAINCLIMB_H

#include <windows.h>

VOID MountainClimb_Enable(PDWORD pMountainClimb, BOOL bEnable);

#endif