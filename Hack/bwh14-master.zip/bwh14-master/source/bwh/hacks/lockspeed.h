#ifndef _LOCKSPEED_H
#define _LOCKSPEED_H

#include <windows.h>

VOID LockSpeed_Enable(PBYTE pLockSpeed, BOOL bEnable);

#endif