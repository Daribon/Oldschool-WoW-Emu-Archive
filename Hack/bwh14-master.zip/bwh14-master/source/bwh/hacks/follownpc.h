#ifndef _FOLLOWNPC_H
#define _FOLLOWNPC_H

#include <windows.h>

VOID FollowNPC_Enable(PBYTE pFollowNpc1, PBYTE pFollowNpc2, PBYTE pFollowFaction, PFLOAT pFollowNPCDistance, BOOL bEnable);

#endif