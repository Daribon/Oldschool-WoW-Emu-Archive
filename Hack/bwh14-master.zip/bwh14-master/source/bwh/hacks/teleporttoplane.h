#ifndef _TELEPORTTOPLANE_H
#define _TELEPORTTOPLANE_H

#include <windows.h>

VOID TeleportToPlane_Enable(PBYTE pPlaneTeleport, BOOL bEnable);

#endif