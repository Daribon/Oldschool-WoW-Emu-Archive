//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by bwh.rc
#define IDR_ATLAS                       101
#define IDD_MAIN                        102
#define IDD_GPS                         103
#define IDC_NEWGROUP                    104
#define IDC_ADDLOCATION                 105
#define IDC_EDITENTRY                   106
#define IDC_DELETEENTRY                 107
#define IDC_MOVEUP                      108
#define IDC_MOVEDOWN                    109
#define IDC_TELEPORT                    110
#define IDC_GOTOCORPSE                  111
#define IDC_GPS                         112
#define IDC_XLEFT                       113
#define IDC_XRIGHT                      114
#define IDC_XEDIT                       115
#define IDC_YLEFT                       116
#define IDC_YRIGHT                      117
#define IDC_YEDIT                       118
#define IDC_ZLEFT                       119
#define IDC_ZRIGHT                      120
#define IDC_ZEDIT                       121
#define IDC_SLEFT                       122
#define IDC_SRIGHT                      123
#define IDC_SEDIT                       124
#define IDC_DISABLEHOTKEYS              125
#define IDC_NOFALLDAMAGE                126
#define IDC_MOUNTAINCLIMB               127
#define IDC_TELEPORTTOPLANE             128
#define IDC_LOCKSPEED                   129
#define IDC_ZEROGRAVITY                 130
#define IDC_FOLLOWNPC                   131
#define IDC_TRACKEDIT                   132
#define IDC_ALLIANCE                    133
#define IDC_HORDE                       134
#define IDC_BEASTS                      135
#define IDC_DEMONS                      136
#define IDC_DRAGONS                     137
#define IDC_ELEMENTALS                  138
#define IDC_GIANTS                      139
#define IDC_HUMANOIDS                   140
#define IDC_UNDEAD                      141
#define IDC_MACHINES                    142
#define IDC_SLIMES                      143
#define IDC_CRITTERS                    144
#define IDC_TREASURE                    145
#define IDC_OBJECTS                     146
#define IDC_HERBS                       147
#define IDC_MINERALS                    148
#define IDC_FILEEDIT                    149
#define IDC_LOAD                        150
#define IDC_TREEVIEW                    151
#define IDC_CLOSE                       152
#define IDC_ADDLOCATIONWINDOW           153
#define IDC_ADDLOCATIONNEDIT            154
#define IDC_ADDLOCATIONXEDIT            155
#define IDC_ADDLOCATIONYEDIT            156
#define IDC_ADDLOCATIONZEDIT            157
#define IDC_ADDLOCATIONMEDIT            158
#define IDC_ADDLOCATIONOK               159
#define IDC_ADDLOCATIONCANCEL           160
#define IDC_NEWGROUPWINDOW              161
#define IDC_NEWGROUPNEDIT               162
#define IDC_NEWGROUPOK                  163
#define IDC_NEWGROUPCANCEL              164
#define IDC_GPSM                        165
#define IDC_GPSX                        166
#define IDC_GPSY                        167
#define IDC_GPSZ                        168
#define IDC_GPSS                        169
#define IDC_GPSCLOSE                    170
#define IDT_UPDATE                      171
#define IDT_CAMERASLEW                  172

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        173
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
