# bwh14
Automatically exported from code.google.com/p/bwh14


BWH 1.4b2 Crappy Readme
-----------------------
Another beta version, it's basically the first runnable version that came together for client 1.5. Keeping this short because this is still in development so maybe some things will change before I write the final readme.

Installation:
0. This will ONLY work if you are running in Direct3D mode. It's not going to do squat if your running in OpenGL and no there will never be support for it.
1. Run bwh_setup.exe
  1a. Ensure the path to your World of Warcraft executable is correct. (It's autodetected).
  1b. Click the 'Scan' button.
  1c. If enough pointers were found the 'Save' button should enable itself.
  1d. Double check the hotkey and font settings and adjust them to your preference.
  1e. Hit the 'Save' button to create a bwh.ini file.
2. Run World of Warcraft
3. Run bwh_loader.exe
  3a. Should see World of Warcraft listed in the list box.
  3b. Select either 'Injection' or 'Loader'
     3ba. Injection: You should normally run in this mode because it is less detectable.
     3bb. Loader: This is for debugging purposes, and can possibly be a tad more stable.
  3c. Hit the 'Install / Remove' button ONLY once.
4. Switch to the World of Warcraft window and see if the ShowHide hotkey pop's up the interface (default F12).

FAQ
---
Q. I use Windows (95/98/ME), will this be a problem?

A. Yes it will. Windows 9X sucks and you should upgrade to Windows 2000 or Windows XP. You will experience problems on Windows 9X systems, but you should still be able to use the hack... just very carefully =)

Q. This hack makes World of Warcraft crash; what can I do about it?

A. First you want to run bwh in "Loader" mode. When World of Warcraft crashes copy and paste that long ass crash dump that World of Warcraft spits out into a private message to me. You can reach me at http://rpg-exploiters.shoq.net/ under the username "bubba". Make sure the crash dump you send me was created when running in "Loader" mode or else the crash dump is useless to me. Also, go click crazy on the banners at http://rpg-exploiters.shoq.net/ will ya? =P

Q. The hack doesn't load and I get no errors; what can I do about it?

A. If you have pointer failures with bwh_setup.exe then pm me and we'll discuss them (unless Present or Reset fails; if this happens then update directx instead of pming me). If you have no pointer errors and you are running a NT based machine (Ex. Windows XP), try logging on as Administrator and trying again.

Q. I have some other question...

A. Go to http://rpg-exploiters.shoq.net/, find the bwh thread, and post a reply. Can also pm me if you want, np.
