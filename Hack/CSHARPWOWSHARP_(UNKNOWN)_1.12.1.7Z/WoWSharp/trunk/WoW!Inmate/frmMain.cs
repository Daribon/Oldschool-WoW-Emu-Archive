//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.Diagnostics;
using WoW_Sharp;

namespace WoW_Inmate
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		private WoW _wow;
		private Profile _profile;
		private bool _manual;
		private int _ignorepid;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.TextBox tbPassword;
		private System.Windows.Forms.TextBox tbUsername;
		private System.Windows.Forms.Label label3;
		private System.Windows.Forms.Button btnDirectory;
		private System.Windows.Forms.Button btnStart;
		private System.Windows.Forms.TextBox tbPath;
		private System.Windows.Forms.OpenFileDialog ofdWoW;
		private System.Windows.Forms.Timer tWoWCheck;
		private System.Windows.Forms.Button btnManual;
		private System.ComponentModel.IContainer components;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			this.components = new System.ComponentModel.Container();
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
			this.label2 = new System.Windows.Forms.Label();
			this.label1 = new System.Windows.Forms.Label();
			this.tbPassword = new System.Windows.Forms.TextBox();
			this.tbUsername = new System.Windows.Forms.TextBox();
			this.label3 = new System.Windows.Forms.Label();
			this.tbPath = new System.Windows.Forms.TextBox();
			this.btnDirectory = new System.Windows.Forms.Button();
			this.btnStart = new System.Windows.Forms.Button();
			this.ofdWoW = new System.Windows.Forms.OpenFileDialog();
			this.tWoWCheck = new System.Windows.Forms.Timer(this.components);
			this.btnManual = new System.Windows.Forms.Button();
			this.SuspendLayout();
			// 
			// label2
			// 
			this.label2.AutoSize = true;
			this.label2.Location = new System.Drawing.Point(136, 8);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(57, 16);
			this.label2.TabIndex = 9;
			this.label2.Text = "Password:";
			// 
			// label1
			// 
			this.label1.AutoSize = true;
			this.label1.Location = new System.Drawing.Point(8, 8);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(60, 16);
			this.label1.TabIndex = 8;
			this.label1.Text = "Username:";
			// 
			// tbPassword
			// 
			this.tbPassword.Location = new System.Drawing.Point(136, 24);
			this.tbPassword.Name = "tbPassword";
			this.tbPassword.PasswordChar = '*';
			this.tbPassword.Size = new System.Drawing.Size(120, 20);
			this.tbPassword.TabIndex = 7;
			this.tbPassword.Text = "";
			// 
			// tbUsername
			// 
			this.tbUsername.Location = new System.Drawing.Point(8, 24);
			this.tbUsername.Name = "tbUsername";
			this.tbUsername.Size = new System.Drawing.Size(120, 20);
			this.tbUsername.TabIndex = 6;
			this.tbUsername.Text = "";
			// 
			// label3
			// 
			this.label3.AutoSize = true;
			this.label3.Location = new System.Drawing.Point(8, 48);
			this.label3.Name = "label3";
			this.label3.Size = new System.Drawing.Size(95, 16);
			this.label3.TabIndex = 10;
			this.label3.Text = "World of Warcraft:";
			// 
			// tbPath
			// 
			this.tbPath.Location = new System.Drawing.Point(8, 64);
			this.tbPath.Name = "tbPath";
			this.tbPath.ReadOnly = true;
			this.tbPath.Size = new System.Drawing.Size(224, 20);
			this.tbPath.TabIndex = 11;
			this.tbPath.Text = "";
			// 
			// btnDirectory
			// 
			this.btnDirectory.Location = new System.Drawing.Point(232, 64);
			this.btnDirectory.Name = "btnDirectory";
			this.btnDirectory.Size = new System.Drawing.Size(23, 20);
			this.btnDirectory.TabIndex = 12;
			this.btnDirectory.Text = "...";
			this.btnDirectory.Click += new System.EventHandler(this.btnDirectory_Click);
			// 
			// btnStart
			// 
			this.btnStart.Location = new System.Drawing.Point(8, 88);
			this.btnStart.Name = "btnStart";
			this.btnStart.Size = new System.Drawing.Size(168, 20);
			this.btnStart.TabIndex = 13;
			this.btnStart.Text = "Start World of Warcraft";
			this.btnStart.Click += new System.EventHandler(this.btnStart_Click);
			// 
			// ofdWoW
			// 
			this.ofdWoW.DefaultExt = "EXE";
			this.ofdWoW.FileName = "wow.exe";
			this.ofdWoW.Filter = "World of Warcraft|wow.exe";
			this.ofdWoW.RestoreDirectory = true;
			this.ofdWoW.Title = "Select World of Warcraft";
			// 
			// tWoWCheck
			// 
			this.tWoWCheck.Enabled = true;
			this.tWoWCheck.Interval = 5000;
			this.tWoWCheck.Tick += new System.EventHandler(this.tWoWCheck_Tick);
			// 
			// btnManual
			// 
			this.btnManual.Location = new System.Drawing.Point(180, 88);
			this.btnManual.Name = "btnManual";
			this.btnManual.Size = new System.Drawing.Size(75, 20);
			this.btnManual.TabIndex = 14;
			this.btnManual.Text = "Manual";
			this.btnManual.Click += new System.EventHandler(this.btnManual_Click);
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(264, 114);
			this.Controls.Add(this.btnManual);
			this.Controls.Add(this.btnStart);
			this.Controls.Add(this.btnDirectory);
			this.Controls.Add(this.tbPath);
			this.Controls.Add(this.label3);
			this.Controls.Add(this.label2);
			this.Controls.Add(this.label1);
			this.Controls.Add(this.tbPassword);
			this.Controls.Add(this.tbUsername);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedDialog;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmMain";
			this.Text = "WoW!Inmate";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.frmMain_Closing);
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			Application.Run(new frmMain());
		}

		private void frmMain_Load(object sender, System.EventArgs e)
		{
			_wow = new WoW();
			_ignorepid = -1;
			_manual = false;

			Process [] procs = _wow.Memory.GetProcessesByExe( "wow!inmate.exe");
			if( procs.Length > 1)
			{
				MessageBox.Show( this, "WoW!Inmate is already started.", "Already started!");
				Application.Exit();
				return;
			}

			procs = _wow.Memory.GetProcessesByExe( "wow.exe");
			foreach( Process p in procs)
			{
				_wow.Memory.Open( p);
				_wow.Memory.CloseProcess();
			}

			_profile = new Profile();
			_profile.DefineVariable( "username", "");
			_profile.DefineVariable( "password", "");
			_profile.DefineVariable( "path", "");
			_profile.DefineVariable( "x", 0);
			_profile.DefineVariable( "y", 0);
			try
			{
				_profile.LoadProfile( "WoW!Inmate");
			} 
			catch {}

			Left = _profile.GetInteger( "x");
			Top = _profile.GetInteger( "y");
			tbUsername.Text = _profile.GetString( "username");
			tbPassword.Text = _profile.GetString( "password");
			tbPath.Text = _profile.GetString( "path");
		}

		private void frmMain_Closing(object sender, CancelEventArgs e)
		{
			Process [] procs = _wow.Memory.GetProcessesByExe( "wow.exe");
			if( procs.Length > 0)
			{
				if( MessageBox.Show( this, "World of Warcraft will also be closed, are you sure you want to quit WoW!Inmate?", "Are you sure?", MessageBoxButtons.YesNo) == DialogResult.No)
				{
					e.Cancel = true;
					return;
				}

				foreach( Process p in procs)
				{
					_wow.Memory.Open( p);
					_wow.Memory.CloseProcess();
				}
			}

			_profile.SetValue( "x", Left);
			_profile.SetValue( "y", Top);
			_profile.SetValue( "username", tbUsername.Text);
			_profile.SetValue( "password", tbPassword.Text);
			_profile.SetValue( "path", tbPath.Text);
			_profile.SaveProfile();
		}

		private void btnStart_Click(object sender, System.EventArgs e)
		{
			try
			{
				_wow.Username = tbUsername.Text;
				_wow.Password = tbPassword.Text;
				if( !_wow.StartWoW( tbPath.Text))
					MessageBox.Show( this, "Unknown error while starting WoW.", "Unable to start WoW");
				else
					btnStart.Enabled = false;
			}
			catch( Exception ex)
			{
				MessageBox.Show( this, ex.Message, "Unable to start WoW");
			}
		}

		private void btnDirectory_Click(object sender, System.EventArgs e)
		{
			if( ofdWoW.ShowDialog() == DialogResult.OK)
				tbPath.Text = ofdWoW.FileName;
		}

		private void tWoWCheck_Tick(object sender, System.EventArgs e)
		{
			bool closedwows = false;
			bool canstart = false;
			bool injected = false;
			bool error = false;

			uint cpid = (uint) Process.GetCurrentProcess().Id;
			Process [] procs = _wow.Memory.GetProcessesByExe( "wow.exe");
			foreach( Process p in procs)
			{
				if( _wow.Memory.ParentIds.ContainsKey( (uint) p.Id))
				{
					if( _manual)
					{
						_ignorepid = p.Id;
						_manual = false;

						try
						{
							_wow.Username = tbUsername.Text;
							_wow.Password = tbPassword.Text;
							injected = _wow.InjectWoW( p);
						}
						catch
						{
							injected = false;
						}

						if( !injected)
						{
							_ignorepid = 0;
							error = true;
						}
					}

					if( (uint) _wow.Memory.ParentIds[ (uint) p.Id] != cpid && p.Id != _ignorepid)
					{
						_wow.Memory.Open( p);
						_wow.Memory.CloseProcess();

						closedwows = true;
					}
					else
						canstart = true;
				}
			}

			if( closedwows && !error)
			{
				Microsoft.VisualBasic.Interaction.AppActivate( (int) cpid);
				MessageBox.Show( this, "Never start World of Warcraft without using WoW!Inmate !", "Warning!");
			}

			if( error)
			{
				Microsoft.VisualBasic.Interaction.AppActivate( (int) cpid);
				MessageBox.Show( this, "WoW!Inmate was unable to injected World of Warcraft.", "Warning!");
			}

			if( injected)
			{
				Microsoft.VisualBasic.Interaction.AppActivate( (int) cpid);
				MessageBox.Show( this, "WoW!Inmate has successfully injected World of Warcraft.", "Safe!");
			}

			btnStart.Enabled = !canstart && !_manual;
			btnManual.Enabled = !canstart && !_manual;
		}

		private void btnManual_Click(object sender, System.EventArgs e)
		{
			btnStart.Enabled = false;
			btnManual.Enabled = false;

			_manual = true;
			MessageBox.Show( this, "Please manually startup World of Warcraft, do *not* login your character yet.", "Warning!");
		}
	}
}
