//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;

namespace WoW_Sharp
{
	/// <summary>
	/// Summary description for WoW_InventoryBag.
	/// </summary>
	public class WoW_InventoryBag
	{
		private WoW owner;
		private WoW_Object container;

		private int nSlots = 0;
		private int firstSlotField = 0;

		private WoW_Object [] items;

		internal WoW_InventoryBag( WoW owner, WoW_Object container)
		{
			this.owner = owner;
			this.container = container;

			// Is the container the player
			if( container == owner.Player)
			{
				// Yes? Set the number of slots to 16
				nSlots = 16;
				firstSlotField = owner.Descriptors[ WoW_ObjectTypes.Player, "PLAYER_FIELD_PACK_SLOT_1"]; 
			}
			else
			{
				// No? Read the number of slots 
				nSlots = container.ReadStorageInt( owner.Descriptors[ WoW_ObjectTypes.Container, "CONTAINER_FIELD_NUM_SLOTS"]);
				firstSlotField = owner.Descriptors[ WoW_ObjectTypes.Container, "CONTAINER_FIELD_SLOT_1"];
			}

			// Create array to hold all the items
			items = new WoW_Object[ nSlots];
		}

		/// <summary>
		/// Updates the inventory bag class
		/// </summary>
		internal void Update()
		{
			// Read through all the slots
			for( int i = 0; i < nSlots; i ++)
			{
				// Get the item guid
				int itemField = firstSlotField + i*8;
				long itemGuid = container.ReadStorageLong( itemField);
				if( itemGuid == 0)
				{
					// No item?
					items[i] = null;
					continue;
				}

				// Get the item from the object hash
				items[i] = (WoW_Object) owner.Objects[itemGuid];;
			}
		}

		/// <summary>
		/// Returns the container
		/// </summary>
		public WoW_Object Container
		{
			get
			{
				return container;
			}
		}

		/// <summary>
		/// Returns the WoW_Object at a slot
		/// </summary>
		public WoW_Object this[int slot]
		{
			get
			{
				if( slot < 0 || slot >= nSlots)
					return null;

				return items[ slot];
			}
		}

		/// <summary>
		/// Return the first slot with the item name in it, -1 if it wasnt found
		/// </summary>
		public int this[string name]
		{
			get
			{
				if( name == null || name == "")
					return -1;

				for( int i = 0; i < nSlots; i ++)
				{
					if( items[i] != null && items[i].Name == name)
						return i;
				}

				return -1;
			}
		}

		/// <summary>
		/// Returns the number of slots
		/// </summary>
		public int Count
		{
			get
			{
				return nSlots;
			}
		}
	}
}
