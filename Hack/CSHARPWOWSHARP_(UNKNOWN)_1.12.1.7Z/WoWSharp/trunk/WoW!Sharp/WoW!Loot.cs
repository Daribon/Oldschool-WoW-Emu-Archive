//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;

namespace WoW_Sharp
{
	/// <summary>
	/// Summary description for WoW_Loot.
	/// </summary>
	public class WoW_Loot
	{
		private WoW owner;

		private int nSlots = 10;
		private WoW_LootSlot [] slots;

		internal WoW_Loot( WoW owner)
		{
			this.owner = owner;

			slots = new WoW_LootSlot[nSlots];
			for( int slot = 0; slot < nSlots; slot ++)
				slots[slot] = new WoW_LootSlot( owner, slot);
		}

		/// <summary>
		/// Returns the number of loot-slots (if any)
		/// </summary>
		/// <returns></returns>
		public int Count()
		{
			int nLoot = 0;
			if( owner.Memory.ReadLong( owner.pointers.getPointer("CGLootInfo__m_object")) != 0)
			{
				for( int i = 0; i < 10; i ++)
				{
					if( owner.Memory.ReadInteger( (owner.pointers.getPointer("CGLootInfo__m_loot")+4) + i * 0x1C) > 0)
						nLoot = i + 1;
				}

				if( owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_coins")) != 0)
					nLoot ++;
			}

			return nLoot;
		}

#if !NoHider
		/// <summary>
		/// Picks up all the loot
		/// </summary>
		public void PickupAllLoot()
		{
			WoW_Execute.AutoStoreAllLootItems();
		}
#endif

		/// <summary>
		/// Returns a loot slot
		/// </summary>
		public WoW_LootSlot this[int slot]
		{
			get
			{
				if( slot < 0 || slot >= nSlots)
					return null;

				return slots[slot];
			}
		}
	}

	/// <summary>
	/// Used to get information about each of the loot slots
	/// </summary>
	public class WoW_LootSlot
	{
		private WoW owner;
		private int slot;

		internal WoW_LootSlot( WoW owner, int slot)
		{
			this.owner = owner;
			this.slot = slot;
		}

		/// <summary>
		/// Is this slot an item?
		/// </summary>
		public bool IsItem
		{
			get
			{
				// Is the loot window even open?
				if( owner.Memory.ReadLong( owner.pointers.getPointer("CGLootInfo__m_object")) == 0)
					return false;

				bool hasCoins = owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_coins")) != 0;

				// Is this slot 0, and are there coins?  If so, its not an item
				if( slot == 0 && hasCoins)
					return false;

				// If there are coins, then the first slot is a 'virtual slot'
				int realslot = slot;
				if( hasCoins) realslot --;

				// Test if it contains an item
				return owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_loot") + 4 + realslot * 0x1C) != 0;
			}
		}

		/// <summary>
		/// Is this loot slot coins?
		/// </summary>
		public bool IsCoins
		{
			get
			{
				// Is the loot window even open?
				if( owner.Memory.ReadLong( owner.pointers.getPointer("CGLootInfo__m_object")) == 0)
					return false;

				// Is this slot 0, and are there coins?  If so, then its coins
				if( slot == 0 && owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_coins")) != 0)
					return true;

				// Its not the first slot, or there are no coins
				return false;
			}
		}

		/// <summary>
		/// Returns the item id, 0 for an invalid item
		/// </summary>
		public int ItemId
		{
			get
			{
				// Is the loot window even open?
				if( owner.Memory.ReadLong( owner.pointers.getPointer("CGLootInfo__m_object")) == 0)
					return 0;

				// If there are coins, then the first slot is a 'virtual slot'
				bool hasCoins = owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_coins")) != 0;
				int realslot = slot;
				if( hasCoins) realslot --;

				return owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_loot") + 4 + realslot * 0x1C);
			}
		}

		/// <summary>
		/// Returns the item name
		/// </summary>
		public string ItemName
		{
			get
			{
				int ptr = owner.itemNames.GetPointer( ItemId);
				if( ptr == 0)
					return "";

				return (string) owner.itemNames[ ItemId];
			}
		}

		/// <summary>
		/// Returns the item quality, -1 for an invalid item
		/// </summary>
		public int ItemQuality
		{
			get
			{
				int ptr = owner.itemNames.GetPointer( ItemId);
				if( ptr == 0)
					return -1;

				Console.WriteLine( ItemName + " : " + ptr.ToString("X"));
				return owner.Memory.ReadInteger( ptr + 0x18 + 0x1C);
			}
		}

		/// <summary>
		/// Returns the item quality, -1 for an invalid item
		/// </summary>
		public int ItemQuantity
		{
			get
			{
				// Is the loot window even open?
				if( owner.Memory.ReadLong( owner.pointers.getPointer("CGLootInfo__m_object")) == 0)
					return 0;

				// If there are coins, then the first slot is a 'virtual slot'
				bool hasCoins = owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_coins")) != 0;
				if( hasCoins && slot == 0)
					return 0;

				int realslot = slot;
				if( hasCoins) realslot --;

				return owner.Memory.ReadInteger( owner.pointers.getPointer("CGLootInfo__m_loot") + 0xC + realslot * 0x1C);
			}
		}	
	}
}
