//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Runtime.InteropServices;

namespace WoW_Sharp
{
	/// <summary>
	/// Summary description for WoW_Execute.
	/// </summary>
	internal class WoW_Execute
	{
#if !NoHider
		#region Set...Ptr
		[DllImport("WoW!Hider")]
		internal static extern void SetDetourPtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetProcessMessagePtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetAddChatMessagePtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetRightClickPtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetLeftClickPtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetClearTargetPtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetAutoStoreAllLootItemsPtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetScriptExecutePtr( int ptr, int ptr2);
		[DllImport("WoW!Hider")]
		internal static extern void SetCastSpellByIDPtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetOsGetAsyncTimeMsPtr( int ptr);
		[DllImport("WoW!Hider")]
		internal static extern void SetMovementPtr( int ptr1, int ptr2);
		[DllImport("WoW!Hider")]
		internal static extern void SetAntiAFKPtr( int ptr1, int offset1, int offset2);
		#endregion

		#region Inject
		[DllImport("WoW!Hider", SetLastError=true)]
		internal static extern int CreateProcessWithDll( string Command, string Dll);
		[DllImport("WoW!Hider", SetLastError=true)]
		internal static extern int ContinueProcessWithDll( IntPtr Handle, string Dll);
		#endregion

		#region WoW functions
		[DllImport("WoW!Hider")]
		internal static extern void RightClick( long target);
		[DllImport("WoW!Hider")]
		internal static extern void LeftClick( long target);
		[DllImport("WoW!Hider")]
		internal static extern void ClearTarget( long target);
		[DllImport("WoW!Hider")]
		internal static extern void AutoStoreAllLootItems();
		[DllImport("WoW!Hider")]
		internal static extern void ScriptExecute( string script);
		[DllImport("WoW!Hider")]
		internal static extern void CastSpellByID( int id);
		[DllImport("WoW!Hider")]
		internal static extern int GetAsyncTimeMs();
		[DllImport("WoW!Hider")]
		internal static extern int StartMovement( int bit);
		[DllImport("WoW!Hider")]
		internal static extern int StopMovement( int bit);
		[DllImport("WoW!Hider")]
		internal static extern int TimedMovement( int bit, int time);
		#endregion

		#region Misc functions
		[DllImport("WoW!Hider")]
		internal static extern bool SetChatlogPath( string path);
		[DllImport("WoW!Hider")]
		internal static extern void GetChatlogPath( System.Text.StringBuilder path);
		[DllImport("WoW!Hider")]
		internal static extern void SetReadAllLanguages( bool readall);
		#endregion
#endif
	}
}
