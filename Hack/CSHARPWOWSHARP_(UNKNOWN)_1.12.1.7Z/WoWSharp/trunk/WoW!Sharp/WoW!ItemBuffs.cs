//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;

namespace WoW_Sharp
{
	/// <summary>
	/// Contains all the item buff / enchantment stuff
	/// </summary>
	public class WoW_ItemBuffs
	{
		private WoW owner;
		private WoW_Object item;

		private WoW_ItemBuff [] buffs;
		private int nBuffs = 0x7;

		internal WoW_ItemBuffs( WoW owner, WoW_Object item)
		{
			this.owner = owner;
			this.item = item;

			buffs = new WoW_ItemBuff[nBuffs];
			for( int i = 0; i < nBuffs; i ++)
				buffs[i] = null;
		}

		/// <summary>
		/// Returns an item buff
		/// </summary>
		public WoW_ItemBuff this[int buff]
		{
			get
			{
				if( buff < 0 || buff >= nBuffs)
					return null;

				if( buffs[buff] == null)
					buffs[buff] = new WoW_ItemBuff( owner, item, buff);

				return buffs[buff];
			}
		}

		/// <summary>
		/// Number of buffs (they arent all active)
		/// </summary>
		public int Count
		{
			get
			{
				return nBuffs;
			}
		}
	}

	/// <summary>
	/// Contains information about a specific item buff / enchantment
	/// </summary>
	public class WoW_ItemBuff
	{
		private WoW owner;
		private WoW_Object item;
		private int index;

		internal WoW_ItemBuff( WoW owner, WoW_Object item, int index)
		{
			this.owner = owner;
			this.item = item;
			this.index = index;
		}

#if !NoHider
		/// <summary>
		/// Returns the time left for that buff (in seconds), -1 if there is no time
		/// </summary>
		public int TimeLeft
		{
			get
			{
				// Get the time left pointer
				int ptr = item.BasePtr + owner.offsets.getOffset("CGItem_C__BuffTimes") + index * 4;
				// Get the time left (0 == no time)
				int till = owner.Memory.ReadInteger( ptr);
				if( till == 0)
					return -1;

				// Return time left in seconds
				return (till - WoW_Execute.GetAsyncTimeMs()) / 1000;
			}
		}
#endif

		/// <summary>
		/// Returns the number of charges left (if any)
		/// </summary>
		public int ChargesLeft
		{
			get
			{
				int field = owner.Descriptors[ item.Type, "ITEM_FIELD_ENCHANTMENT"];
				if( field == 0)
					return 0;

				field += (index * 3 + 2) * 4;
				return item.ReadStorageInt( field);
			}
		}

		/// <summary>
		/// Returns the enchantment id
		/// </summary>
		public int EnchantmentId
		{
			get
			{
				int field = owner.Descriptors[ item.Type, "ITEM_FIELD_ENCHANTMENT"];
				if( field == 0)
					return 0;

				// Enchantment Id is in the first field of the 'enchantment structure'
				// which is build up out of 4 id's
				field += index * 4 * 3;
				return item.ReadStorageInt( field);
			}
			set
			{
				int field = owner.Descriptors[ item.Type, "ITEM_FIELD_ENCHANTMENT"];
				if( field == 0)
					return;

				// Enchantment Id is in the first field of the 'enchantment structure'
				// which is build up out of 4 id's
				field += index * 4 * 3;
				item.WriteStorageInt( field, value);
			}
		}

		/// <summary>
		/// Returns the enchantment name
		/// </summary>
		public string EnchantmentName
		{
			get
			{
				int id = EnchantmentId;
				if( id == 0)
					return "";

				int rows = owner.Memory.ReadInteger( owner.pointers.getPointer("g_spellItemEnchantment") + 8);
				int cnt = owner.Memory.ReadInteger( owner.pointers.getPointer("g_spellItemEnchantment") + 12);
				if( id >= cnt)
					return "";

				int row = owner.Memory.ReadInteger( rows + id * 4);
				if( row == 0)
					return "";

				int field = owner.Memory.ReadInteger( row + owner.offsets.getOffset("spellItemEnchantment_Name") * 4);
				return owner.Memory.ReadString( field, 64);
			}
		}
	}
}
