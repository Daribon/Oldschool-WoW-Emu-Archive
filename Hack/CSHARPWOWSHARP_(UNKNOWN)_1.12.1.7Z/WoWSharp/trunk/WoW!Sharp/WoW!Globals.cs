//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;

namespace WoW_Sharp
{
	/// <summary>
	/// This class contains all the global variables from WoW, including but not limited to
	/// player id, target id, etc.
	/// </summary>
	internal class WoW_Globals
	{
		private WoW owner;
		public WoW_Globals( WoW owner)
		{
			this.owner = owner;
		}

		internal int cdbFaction;
		internal int cdbFactionGroup;

		internal WoW_Object player;
		internal WoW_Object target;
	}
}
