//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Collections;

namespace WoW_Sharp
{
	/// <summary>
	/// This object handles all the pointers used by WoW Sharp. If a pointer isnt in the hashtable,
	/// it will be loaded from the website.
	/// </summary>
	internal class WoW_Pointers
	{
		private Hashtable pointers;
		private WoW_WSSClient _wssc;

		private WoW owner;
		internal WoW_Pointers( WoW owner, WoW_WSSClient wssc)
		{
			_wssc = wssc;

			this.owner = owner;

			pointers = new Hashtable();
			_wssc.GetHashtable( "POINTERS", pointers);
		}

		/// <summary>
		/// Returns a pointer, loads it from the website if needed.
		/// </summary>
		/// <param name="pointer">Pointer name</param>
		/// <returns>Pointer</returns>
		internal int getPointer( string pointer)
		{
			if( !pointers.ContainsKey( pointer))
				throw new Exception("Invalid pointer");

			return (int) pointers[ pointer];
		}
	}
}
