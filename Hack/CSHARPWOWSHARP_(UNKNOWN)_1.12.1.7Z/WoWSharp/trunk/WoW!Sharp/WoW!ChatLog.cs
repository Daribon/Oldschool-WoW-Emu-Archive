//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.IO;
using System.Text.RegularExpressions;

namespace WoW_Sharp
{
	/// <summary>
	/// ChatLog parser
	/// </summary>
	public class WoW_ChatLog
	{
		private WoW _owner;

		private string _path;
		private long _offset;

		internal WoW_ChatLog( WoW owner)
		{
			_owner = owner;

			Reset();
		}

		/// <summary>
		/// Resets the chatlog parser
		/// </summary>
		public void Reset()
		{
#if !NoHider
			_path = _owner.ChatlogPath;
#endif	
			_offset = 0;

			if( _path != "" && File.Exists( _path))
			{
				FileStream fs = new FileStream( _path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
				_offset = fs.Length;
				fs.Close();
			}
		}

		/// <summary>
		/// Read's a (parsed) chatlogline
		/// </summary>
		/// <returns>the ChatLogLine, or null if there was no line</returns>
		public WoW_ChatLogLine ReadLine()
		{
			if( _path == "" || !File.Exists( _path))
				return null;

			// Open the chatlog
			FileStream fs = new FileStream( _path, FileMode.Open, FileAccess.Read, FileShare.ReadWrite);
			try
			{
				// Offset beyond end? Reset the parser.
				if( _offset > fs.Length)
					Reset();

				// There's no new line
				if( _offset == fs.Length)
					return null;

				// Read a line
				fs.Seek( _offset, SeekOrigin.Begin);
				StreamReader sr = new StreamReader(fs);
				WoW_ChatLogLine line = new WoW_ChatLogLine( sr.ReadLine());
				_offset += System.Text.Encoding.UTF8.GetByteCount(line.RawLine) + 2; // \n == 2 bytes
				return line;
			}
			finally
			{
				fs.Close();
			}
		}
	}

	/// <summary>
	/// This object contains a parsed chatlog line
	/// </summary>
	public class WoW_ChatLogLine
	{
		/// <summary>
		/// The RegEx to parse the chatlog line which is in this format:
		/// [00:00:00][00][ABCDEFG]&gt;ABC&lt;(ABC){ABC}[ABC]: Abcdefg
		/// </summary>
		private static Regex _regex = new Regex( @"^\[(?<time>[\d,:]{8})\]\[(?<id>[\d,A-F]{2})\]\[(?<idstring>.[^\]]+)\](?:<(?<param5>.[^>]+)>){0,1}(?:\((?<param4>.[^\)]+)\)){0,1}(?:\{(?<param3>.[^\}]+)\}){0,1}(?:\[(?<param2>.[^\]]+)\]){0,1}(?:: (?<param1>.+)){0,1}$");

		/// <summary>
		/// Private variables
		/// </summary>
		private string _rawline = "";
		private bool _isvalid = false;

		private int _id = -1;
		private string _idstring = "";

		private string _param1 = "";
		private string _param2 = "";
		private string _param3 = "";
		private string _param4 = "";
		private string _param5 = "";

		internal WoW_ChatLogLine( string rawline)
		{
			_rawline = rawline;
			Match m = _regex.Match( rawline);
			_isvalid = m.Success;

			if( m.Success)
			{
				_id = int.Parse( m.Groups["id"].Value, System.Globalization.NumberStyles.AllowHexSpecifier);
				_idstring = m.Groups["idstring"].Value;

				_param1 = m.Groups["param1"].Value;
				_param2 = m.Groups["param2"].Value;
				_param3 = m.Groups["param3"].Value;
				_param4 = m.Groups["param4"].Value;
				_param5 = m.Groups["param5"].Value;
			}
		}

		/// <summary>
		/// Returns the raw string as its written in the chat.log file
		/// </summary>
		public string RawLine
		{
			get
			{
				return _rawline;
			}
		}

		/// <summary>
		/// Was the chat parser able to parse the raw line?  
		/// </summary>
		/// <remarks>
		/// If this is set to false then only RawLine will be filled!
		/// </remarks>
		public bool IsValid
		{
			get
			{
				return _isvalid;
			}
		}

		/// <summary>
		/// Returns the id of the chat line, ranging from 0 - 0x51
		/// </summary>
		public int Id
		{
			get
			{
				return _id;
			}
		}

		/// <summary>
		/// Returns the id string of the chat line [e.g. SAY, PARTY, GUILD, etc]
		/// </summary>
		public string IdString
		{
			get
			{
				return _idstring;
			}
		}

		/// <summary>
		/// Contains the message ([Bla] whispers: {message})
		/// </summary>
		public string Message
		{
			get
			{
				return _param1;	
			}
		}

		/// <summary>
		/// Contains the sender ([{sender}] whispers: bla)
		/// </summary>
		public string Sender
		{
			get
			{
				return _param2;
			}
		}

		/// <summary>
		/// Contains the sender's status like AFK,DND and possibly GM
		/// </summary>
		public string SenderStatus
		{
			get
			{
				return _param5;
			}
		}

		/// <summary>
		/// Contains the channel
		/// </summary>
		public string Channel
		{
			get
			{
				return _param3;
			}
		}

		/// <summary>
		/// Parameter 1 usually contains the message
		/// </summary>
		public string Param1
		{
			get
			{
				return _param1;
			}
		}

		/// <summary>
		/// Parameter 2 usually contains the sender
		/// </summary>
		public string Param2
		{
			get
			{
				return _param2;
			}
		}

		/// <summary>
		/// Parameter 3 usually contains the channel
		/// </summary>
		public string Param3
		{
			get
			{
				return _param3;
			}
		}

		/// <summary>
		/// Parameter 4 (unknown what it contains)
		/// </summary>
		public string Param4 
		{
			get
			{
				return _param4;
			}
		}

		/// <summary>
		/// Parameter 5 usually contains the senders status
		/// </summary>
		public string Param5
		{
			get
			{
				return _param5;
			}
		}
	}
}
