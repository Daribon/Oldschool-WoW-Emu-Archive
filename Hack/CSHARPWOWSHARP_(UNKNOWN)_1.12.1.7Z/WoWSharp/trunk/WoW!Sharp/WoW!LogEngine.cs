//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Threading;
using System.Collections;
using System.IO;

namespace WoW_Sharp
{
	internal class WoW_LogEngine : IDisposable
	{
		private AutoResetEvent evt;
		private Queue store;
		private Thread writeThread = null;
		private bool bThreadQuit = false;
		private string filename;
		private bool bEnabled = false;

		internal bool Enabled
		{
			get
			{
				return bEnabled;
			}
			set
			{
				bEnabled = value;
			}
		}

		protected bool isMessage()
		{
			lock (store.SyncRoot)
				if (store.Count > 0) return true;
			return false;
		}

		protected string getMessage()
		{
			lock (store.SyncRoot)
				if (store.Count > 0) return (string)store.Dequeue();
			return null;
		}

		protected void WriteThread()
		{
			StreamWriter sw = null;

			while( !bThreadQuit)
			{
				evt.WaitOne();

				if( !bThreadQuit)
				try 
				{
					sw = new StreamWriter(filename, true, System.Text.Encoding.ASCII);

					lock (store.SyncRoot)
					{
						while (isMessage() == true)
						{
							string sMsg = getMessage();
							sMsg = sMsg.Replace( "\r", "");
							sMsg = sMsg.Replace( "\n", "");
							sw.WriteLine(sMsg);
						}
					}
				
					sw.Close();
				}
				catch (Exception)
				{
					if (sw != null)
						sw.Close();
				}
			}
		}

		internal WoW_LogEngine(string fileName)
		{
			filename = fileName;
			store = Queue.Synchronized(new Queue(0));
			evt = new AutoResetEvent(false);
			
			writeThread = new Thread(new ThreadStart(WriteThread));
			writeThread.Name = "WoW!LogEngine writeThread";
			writeThread.Start();
		}

		~WoW_LogEngine()
		{
		    Dispose();
		}

		public void Dispose()
		{
			if (writeThread != null)
			{
				bThreadQuit = true;
				evt.Set();
				writeThread.Join();
				writeThread = null;
			}
		}

		protected void AddMessage(string sText)
		{
			if( bEnabled)
			lock (store.SyncRoot)
			{
				store.Enqueue(sText);
				evt.Set();
			}
		}

		internal void LogLine(string sText)
		{
			try 
			{
				AddMessage(sText);
			}
			catch { }
		}

		internal void LogLine(string sFormat, params object[] args)
		{
			System.IO.StringWriter sw = new System.IO.StringWriter();
			sw.WriteLine(sFormat, args);
			string sText = sw.ToString();
			
			LogLine(sText);
		}
	}
}