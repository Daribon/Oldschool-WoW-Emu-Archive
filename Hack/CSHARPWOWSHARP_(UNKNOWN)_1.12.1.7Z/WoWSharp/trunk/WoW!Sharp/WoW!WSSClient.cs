//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.IO;
using System.Xml;
using System.Net;
using System.Text;
using System.Security.Cryptography;
using System.Security.Cryptography.X509Certificates;
using System.Collections;
using System.Net.Sockets;
using Mono.Security.Protocol.Tls;

namespace WoW_Sharp
{
	/// <summary>
	/// Summary description for WoW_WSSClient.
	/// </summary>
	internal class WoW_WSSClient
	{
		private byte [] _password;
		private WoW _owner;
		private Socket _socket;
		private NetworkStream _ns = null;
		private SslClientStream _ssl = null;
		private X509CertificateCollection _certificates;
		private string _command;

		internal WoW_WSSClient( WoW owner)
		{
			_owner = owner;

			_certificates = new X509CertificateCollection();
			_socket = new Socket( AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
			_command = "";

			if( !Connect())
				throw( new Exception( "There was a problem contacting wowsharp.net. Please check your firewall settings and try again later."));
		}

		private bool Connect()
		{
			if( _socket.Connected)
				return true;

			_owner.LogLine( "Connecting to WoWSharp.NET (port 7728)...");
			try
			{
				_socket.Connect( new IPEndPoint( 3625172437, 7728));
				//_socket.Connect( new IPEndPoint( Dns.Resolve( "www.wowsharp.net").AddressList[0], 7728));
				//_socket.Connect( new IPEndPoint( Dns.Resolve( "localhost").AddressList[0], 7728));
				_ns = new NetworkStream( _socket, false);
				_ssl = new SslClientStream( _ns, "www.wowsharp.net", false, Mono.Security.Protocol.Tls.SecurityProtocolType.Tls, _certificates);
				//_ssl = new SslClientStream( _ns, "localhost", false, Mono.Security.Protocol.Tls.SecurityProtocolType.Tls, _certificates);
				_ssl.ServerCertValidationDelegate += new CertificateValidationCallback( CertificateValidation);

				string serverversion = ReceiveCommand().Split('|')[1].Replace( "\r\n", "");
				_owner.LogLine( "Connected to WoWSharp.NET (port 7728), server version {0}...", serverversion);

				return true;
			}
			catch( Exception e)
			{ 
				try
				{
					if( _socket.Connected)
					{
						_socket.Shutdown( SocketShutdown.Both);
						_socket.Close();
					}
				}
				catch {	}

				if( _ns != null)
					_ns = null;

				if( _ssl != null)
					_ssl = null;

				_owner.LogLine( "Failed to connect: {0}", e.Message);
			}

			return false;
		}

		internal string ReceiveCommand()
		{
			byte [] buffer = new byte[128];

			int bytes = 0;
			int received = 0;
			do
			{
				bytes = _ssl.Read( buffer, received, 1);
				received += bytes;
			} while( bytes != 0 && received < 128 && buffer[ received - 1] != '\n');

			return Encoding.UTF8.GetString( buffer, 0, received);
		}

		internal string SendCommand( string command, string action)
		{
			string result = "";
			try
			{
				_ssl.Write( Encoding.UTF8.GetBytes( string.Format( "{0}\r\n", command)));

				result = ReceiveCommand();
			}
			catch( Exception e)
			{
				_owner.LogLine( "Failed to {0}: {1}", action, e.Message);
				throw( e);
			}

			return result;
		}

		internal void Authenticate( string username, byte [] password)
		{
			_password = password;
			string sha512password = "";
			foreach( byte b in password)
				sha512password += String.Format( "{0:X2}", b);
			
			if( !Connect())
				throw( new Exception( "There was a problem contacting wowsharp.net. Please check your firewall settings and try again later."));

			_owner.LogLine( "Authenticating...");
			string result = SendCommand( string.Format( "AUTH|{0}|{1}", username, sha512password), "authenticate");

			if( result != "OK\r\n")
			{
				if( result.StartsWith( "ERROR|"))
					throw( new Exception( result.Split( '|')[1]));
				else
					throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));
			}
		}

		internal void VersionCheck( int majorpart, int minorpart, int buildpart, int privatepart)
		{
			if( !Connect())
				throw( new Exception( "There was a problem contacting wowsharp.net. Please check your firewall settings and try again later."));

			string result = SendCommand( string.Format( "VERSION|{0}.{1}.{2}.{3}", majorpart, minorpart, buildpart, privatepart), "version check");

			if( result != "OK\r\n")
			{
				if( result.StartsWith( "ERROR|"))
					throw( new Exception( result.Split( '|')[1]));
				else
					throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));
			}
		}

		internal void WoWSharpCheck( int majorpart, int minorpart, int buildpart, int privatepart)
		{
			if( !Connect())
				throw( new Exception( "There was a problem contacting wowsharp.net. Please check your firewall settings and try again later."));

			string result = SendCommand( string.Format( "WOWSHARP|{0}.{1}.{2}.{3}", majorpart, minorpart, buildpart, privatepart), "check WoWSharp's version");

			if( result != "OK\r\n")
			{
				if( result.StartsWith( "ERROR|"))
					throw( new Exception( result.Split( '|')[1]));
				else
					throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));
			}
		}

		internal void WoWHiderCheck( int majorpart, int minorpart, int buildpart, int privatepart)
		{
			if( !Connect())
				throw( new Exception( "There was a problem contacting wowsharp.net. Please check your firewall settings and try again later."));

			string result = SendCommand( string.Format( "WOWHIDER|{0}.{1}.{2}.{3}", majorpart, minorpart, buildpart, privatepart), "check WoWSharp's version");

			if( result != "OK\r\n")
			{
				if( result.StartsWith( "ERROR|"))
					throw( new Exception( result.Split( '|')[1]));
				else
					throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));
			}
		}

		internal void SetApplication( string application)
		{
			if( !Connect())
				throw( new Exception( "There was a problem contacting wowsharp.net. Please check your firewall settings and try again later."));

			string result = SendCommand( string.Format( "APPLICATION|{0}", application.Replace("|", "/")), "set the application");

			if( result != "OK\r\n")
			{
				if( result.StartsWith( "ERROR|"))
					throw( new Exception( result.Split( '|')[1]));
				else
					throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));
			}
		}

		internal void GetHashtable( string name, Hashtable table)
		{
			if( !Connect())
				throw( new Exception( "There was a problem contacting wowsharp.net. Please check your firewall settings and try again later."));

			_owner.LogLine( "Retrieving {0}...", name.ToLower());
			string result = SendCommand( name, string.Format("retrieve {0}", name));

			if( !result.StartsWith( "MORE|"))
			{
				if( result.StartsWith( "ERROR|"))
					throw( new Exception( result.Split( '|')[1]));
				else
					throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));
			}

			int length = int.Parse( result.Split('|')[1].Replace( "\r\n", ""));
			byte [] encrypted = new byte[length + 32];
			try
			{
				int bytes = _ssl.Read( encrypted, 0, length + 32);

				if( bytes != length)
					length = 0;
			}
			catch( Exception e)
			{ 
				_owner.LogLine( "Failed to retrieve {0} data: {1}", name.ToLower(), e.Message);
			}

			if( length == 0)
				throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));

			try
			{
				MemoryStream ms = new MemoryStream( Decrypt( encrypted, 0, length, _password));
				StreamReader sr = new StreamReader( ms);

				while( sr.Peek() != -1)
				{
					string line = sr.ReadLine();
					if( line == "")
						continue;

					string [] parts = line.Split('|');
					table.Add( parts[0], int.Parse(parts[1]));
				}
			}
			catch
			{
				throw( new Exception( "There was an unknown problem contacting wowsharp.net. Please try again later."));
			}
		}

		private byte [] Decrypt( byte [] data, int index, int count, byte [] sha512key)
		{
			MemoryStream output = new MemoryStream();
			MemoryStream input = new MemoryStream( data, index, count);

			byte [] key = new byte[24];
			byte [] iv = new byte[8];

			for( int b = 0; b < 24; b ++)
				key[ b] = sha512key[b * 2];

			for( int b = 0; b < 8; b ++)
				iv[ b] = sha512key[b * 6 + 1];

			TripleDESCryptoServiceProvider des3 = new TripleDESCryptoServiceProvider();
			des3.Key = key;
			des3.IV = iv;

			CryptoStream cs = new CryptoStream( output, des3.CreateDecryptor(), CryptoStreamMode.Write);
			input.WriteTo( cs);
			cs.Close();

			return output.ToArray();
		}

		internal void CheckPing()
		{
			if( !_socket.Connected)
				return;

			try
			{
				if( _socket.Available > 0)
				{
					byte [] buffer = new byte[128];
					int bytes = _ssl.Read( buffer, 0, 128);
					_command += System.Text.Encoding.UTF8.GetString( buffer, 0, bytes);
				}

				if( _command.IndexOf( "\r\n") >= 0)
				{
					if( _command == "PING\r\n")
						_ssl.Write( Encoding.UTF8.GetBytes( "PONG\r\n"));

					_command = _command.Remove( 0, _command.IndexOf( "\r\n") + 2);
				}
			}
			catch
			{
				Quit();
			}
		}

		internal void Quit()
		{
			try
			{
				if( !_socket.Connected)
					return;

				try
				{
					_ssl.Write( Encoding.UTF8.GetBytes( "QUIT\r\n"));
				}
				catch { }

				_socket.Shutdown( SocketShutdown.Both);
				_socket.Close();
			}
			catch{ }
		}

		private bool CertificateValidation( X509Certificate certificate, int[] certificateErrors)
		{
			if (certificateErrors.Length > 0) 
			{
				// multiple errors are possible using SslClientStream
				foreach( uint error in certificateErrors) 
				{
					switch( error)
					{
						case 0x800B0109:
							// CERT_E_UNTRUSTEDROOT
							break;

						default:
							return false;
					}
				}
			}

			if( certificate.GetCertHashString() != "0C826066923C83711F50928AE53517C535F8D1F7")
				return false;

			return true;
		}
	}
}
