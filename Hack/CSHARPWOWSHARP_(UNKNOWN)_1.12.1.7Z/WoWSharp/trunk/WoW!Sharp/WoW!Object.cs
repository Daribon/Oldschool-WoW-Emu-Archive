//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Runtime.InteropServices;

namespace WoW_Sharp
{
	/// <summary>
	/// The GUID structure used to identify WoW_Objects
	/// </summary>
	[StructLayout(LayoutKind.Explicit)]
	public struct WGUID 
	{
		/// <summary>
		/// The full GUID
		/// </summary>
		[ FieldOffset(0) ] public long GUID;
		
		/// <summary>
		/// The low part of the GUID
		/// </summary>
		[ FieldOffset(0) ] public int Low;
		
		/// <summary>
		/// The high part of the GUID
		/// </summary>
		[ FieldOffset(4) ] public int High;
	};

	/// <summary>
	/// This class is used by the GetNearest function
	/// </summary>
	public class WoW_Distance : IComparable 
	{
		private float distance;
		private WoW_Object obj;

		internal WoW_Distance( float distance, WoW_Object obj)
		{
			this.distance = distance;
			this.obj = obj;
		}

		/// <summary>
		/// Distance to the object
		/// </summary>
		public float Distance
		{
			get
			{
				return distance;
			}
		}

		/// <summary>
		/// The object
		/// </summary>
		public WoW_Object Obj
		{
			get
			{
				return obj;
			}
		}

		/// <summary>
		/// Compares two distance objects
		/// </summary>
		/// <param name="o">The distance object to compare it to</param>
		/// <returns>The result</returns>
		public int CompareTo( object o)
		{
			return distance.CompareTo( ((WoW_Distance)o).Distance);
		}
	}

	/// <summary>
	/// All the WoW_ObjectTypes
	/// </summary>
	public enum WoW_ObjectTypes
	{
		/// <summary>Unknown</summary>
		Unknown = 0,
		/// <summary>Item</summary>
		Item = 1,
		/// <summary>Container</summary>
		Container = 2,
		/// <summary>Unit</summary>
		Unit = 3,
		/// <summary>Player</summary>
		Player = 4,
		/// <summary>GameObject</summary>
		GameObject = 5,
		/// <summary>Dynamic</summary>
		Dynamic = 6,
		/// <summary>Corpse</summary>
		Corpse = 7
	}

	/// <summary>
	/// This class handles all the stuff for WoW 'game' objects (items/monsters/players)
	/// </summary>
	public class WoW_Object
	{
		private WoW owner;
		internal bool invalid = false;

		/// <summary>
		/// Pointer to the object and its storage
		/// </summary>
		private int ptrBase;
		private int ptrStorage;
		private int ptrStorageEnd;

		/// <summary>
		/// Some variables that shouldnt change
		/// </summary>
		private WoW_ObjectTypes type;
		private WGUID guid;
		private WoW_ItemBuffs itembuffs;

		/// <summary>
		/// Position information, not all objects have positioning, those without
		/// will have these variables set to 0
		/// </summary>
		private float x, y, z, facing, speed;

		/// <summary>
		/// Object name (if any)
		/// </summary>
		private string name;

		/// <summary>
		/// Constructor
		/// </summary>
		/// <param name="ptr">Pointer to the object</param>
		/// <param name="owner">Owner</param>
		internal WoW_Object( int ptr, WoW owner)
		{
			this.owner = owner;
			this.ptrBase = ptr;

			type = (WoW_ObjectTypes) owner.Memory.ReadInteger( ptrBase + 0x14);
			guid.GUID = owner.Memory.ReadLong( ptrBase + 0x30);

			ptrStorage = owner.Memory.ReadInteger( ptrBase + 0x08);
			ptrStorageEnd = owner.Memory.ReadInteger( ptrBase + 0x0C);

			itembuffs = null;
		}

		/// <summary>
		/// GUID of the object
		/// </summary>
		public WGUID GUID
		{
			get
			{
				return guid;
			}
		}

		/// <summary>
		/// Name of the object (if any)
		/// </summary>
		public string Name
		{
			get
			{
				return name;
			}
		}

		/// <summary>
		/// Type of the object
		/// </summary>
		public WoW_ObjectTypes Type
		{
			get
			{
				return type;
			}
		}

		/// <summary>
		/// Checks if the object is still valid.
		/// Currently only done by GUID.
		/// </summary>
		public bool IsValid
		{
			get
			{
				if( invalid)
					return false;

				// If the object GUID has changed, it no longer is valid
				if( guid.GUID != owner.Memory.ReadLong( ptrBase + 0x30))
				{
					invalid = true;
					return false;
				}

				return true;
			}
		}

		/// <summary>
		/// Updates the (cached) value's
		/// </summary>
		/// <returns>False, the object is no longer valid</returns>
		public bool Update()
		{
			// Check if the object is still valid
			if( !IsValid)
				return false;

			// Although this *should* never change, just to be sure
			type = (WoW_ObjectTypes) owner.Memory.ReadInteger( ptrBase + 0x14);

			if( type == WoW_ObjectTypes.Item)
			{
				x = y = z = facing = speed = 0;

				int itemid = ReadStorageInt( owner.Descriptors[ type, "OBJECT_FIELD_ENTRY"]);
				name = (string) owner.itemNames[ itemid];
			}

			if( type == WoW_ObjectTypes.Container)
			{
				x = y = z = facing = speed = 0;

				int itemid = ReadStorageInt( owner.Descriptors[ type, "OBJECT_FIELD_ENTRY"]);
				name = (string) owner.itemNames[ itemid];
			}

			if( type == WoW_ObjectTypes.Unit)
			{
				y = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Y"));
				x = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__X"));
				z = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Z"));
				facing = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Facing"));
				speed = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Speed"));

				int basePtr = owner.Memory.ReadInteger( ptrBase + owner.offsets.getOffset("CGUnit_C__Name"));
				if( basePtr != 0)
				{
					basePtr = owner.Memory.ReadInteger( basePtr);
					if( basePtr != 0)
                        name = owner.Memory.ReadString( basePtr, 64);
				}
			}

			if( type == WoW_ObjectTypes.Player)
			{
				y = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Y"));
				x = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__X"));
				z = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Z"));
				facing = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Facing"));
				speed = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGPlayer_C__Speed"));

				name = (string) owner.playerNames[ GUID.GUID];
			}

			if( type == WoW_ObjectTypes.GameObject)
			{
				y = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGGameObject_C__Y"));
				x = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGGameObject_C__X"));
				z = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGGameObject_C__Z"));
				facing = owner.Memory.ReadFloat( ptrBase + owner.offsets.getOffset("CGGameObject_C__Facing"));
				speed = 0;

				int basePtr = owner.Memory.ReadInteger( ptrBase + owner.offsets.getOffset("CGGameObject_C__Name"));
				if( basePtr != 0)
				{
					basePtr = owner.Memory.ReadInteger( basePtr + 0x8);

					if( basePtr != 0)
						name = owner.Memory.ReadString( basePtr, 64);
				}
			}

			if( type == WoW_ObjectTypes.Dynamic)
			{
				// No clue what's 'to get' here (yet)
			}

			if( type == WoW_ObjectTypes.Corpse)
			{
				int basePtr = owner.Memory.ReadInteger( ptrBase + 0x110);
				
				x = y = z = facing = speed = 0;
				if( basePtr != 0)
				{
					y = owner.Memory.ReadFloat( basePtr + 0x0C);
					x = owner.Memory.ReadFloat( basePtr + 0x10);
					z = owner.Memory.ReadFloat( basePtr + 0x14);
					facing = owner.Memory.ReadFloat( basePtr + 0x18);

					long ownerid = ReadStorageLong( owner.Descriptors[ type, "CORPSE_FIELD_OWNER"]);
					name = "Corpse of " + (string) owner.playerNames[ ownerid];
				}
			}

			return true;
		}
		
		/// <summary>
		/// Read a integer from the object storage
		/// </summary>
		/// <param name="field">Field offset</param>
		/// <returns>Value</returns>
		public int ReadStorageInt( int field)
		{
			if( (ptrStorage + field) > ptrStorageEnd)
				return -1;

			return owner.Memory.ReadInteger( ptrStorage + field);
		}

		/// <summary>
		/// Read a long from the object storage
		/// </summary>
		/// <param name="field">Field offset</param>
		/// <returns>Value</returns>
		public long ReadStorageLong( int field)
		{
			if( (ptrStorage + field) > ptrStorageEnd)
				return -1;

			return owner.Memory.ReadLong( ptrStorage + field);
		}

		/// <summary>
		/// Read a float from the object storage
		/// </summary>
		/// <param name="field">Field offset</param>
		/// <returns>Value</returns>
		public float ReadStorageFloat( int field)
		{
			if( (ptrStorage + field) > ptrStorageEnd)
				return -1;

			return owner.Memory.ReadFloat( ptrStorage + field);
		}

		/// <summary>
		/// Write a integer from the object storage
		/// </summary>
		/// <param name="field">Field offset</param>
		/// <param name="value">Value</param>
		public void WriteStorageInt( int field, int value)
		{
			if( (ptrStorage + field) > ptrStorageEnd)
				return;

			owner.Memory.WriteInteger( ptrStorage + field, value);
			return;
		}

		/// <summary>
		/// Write a long from the object storage
		/// </summary>
		/// <param name="field">Field offset</param>
		/// <param name="value">Value</param>
		public void WriteStorageLong( int field, long value)
		{
			if( (ptrStorage + field) > ptrStorageEnd)
				return;

			owner.Memory.WriteLong( ptrStorage + field, value);
			return;
		}

		/// <summary>
		/// Write a float from the object storage
		/// </summary>
		/// <param name="field">Field offset</param>
		/// <param name="value">Value</param>
		public void WriteStorageFloat( int field, float value)
		{
			if( (ptrStorage + field) > ptrStorageEnd)
				return;

			owner.Memory.WriteFloat( ptrStorage + field, value);
			return;
		}

		/// <summary>
		/// Returns a pointer to the faction group row of this object
		/// </summary>
		/// <returns></returns>
		internal int GetUnitFactionGroupRow()
		{
			// Get a pointer to, uh, uh, uh, dunno tbh
			int basePtr = owner.Memory.ReadInteger( ptrBase + 0x110);
			
			// Check if its 0
			if( basePtr == 0)
				return -1;

			// Retrieve the faction template from the object
			int factionTemplate = owner.Memory.ReadInteger( basePtr + 0x74);
			
			// Return the faction group row
			return owner.Memory.ReadInteger( factionTemplate * 4 + owner.globals.cdbFactionGroup);
		}

		/// <summary>
		/// Returns a string to the object model display mdx
		/// </summary>
		/// <returns></returns>
		internal string GetDisplayMDX()
		{
			int rows = owner.Memory.ReadInteger( owner.pointers.getPointer("g_gameObjectDisplayInfoDB") + 8);
			int displayID = ReadStorageInt( owner.Descriptors[ type, "GAMEOBJECT_DISPLAYID"]);

			int row = owner.Memory.ReadInteger( rows + displayID * 4);
			int field = owner.Memory.ReadInteger( row + 4);

			if( field == 0)
				return "";
					
			return owner.Memory.ReadString( field, 128).ToLower();
		}

		/// <summary>
		/// The base pointer of the object
		/// </summary>
		public int BasePtr
		{
			get
			{
				return ptrBase;
			}
		}

		/// <summary>
		/// The X position (not all objects have an X position)
		/// </summary>
		public float X
		{
			get
			{
				return x;
			}
		}

		/// <summary>
		/// The Y position (not all objects have an Y position)
		/// </summary>
		public float Y
		{
			get
			{
				return y;
			}
		}

		/// <summary>
		/// The Z position (not all objects have an Z position)
		/// </summary>
		public float Z
		{
			get
			{
				return z;
			}
		}

		/// <summary>
		/// Facing (in radians)(not all objects have facing)
		/// </summary>
		public float Facing
		{
			get
			{
				return facing;
			}
		}

		/// <summary>
		/// Returns the speed in map-units-per-second
		/// </summary>
		public float Speed
		{
			get
			{
				return speed;
			}
		}

		#region Item object type specific functions
		/// <summary>
		/// Is this item openable ?
		/// </summary>
		public bool IsOpenable
		{
			get
			{
				if( Type != WoW_ObjectTypes.Item)
					return false;

				return (ReadStorageInt( owner.Descriptors[ type, "ITEM_FIELD_FLAGS"]) & 0x4) != 0;
			}
		}

		/// <summary>
		/// Returns the Id of an item
		/// </summary>
		public int ItemId
		{
			get
			{
				if( Type != WoW_ObjectTypes.Item)
					return 0;

				return ReadStorageInt( owner.Descriptors[ type, "OBJECT_FIELD_ENTRY"]);
			}
		}

		/// <summary>
		/// Returns the amount of items
		/// </summary>
		public int StackCount
		{
			get
			{
				if( Type != WoW_ObjectTypes.Item)
					return 0;

				return ReadStorageInt( owner.Descriptors[ type, "ITEM_FIELD_STACK_COUNT"]);
			}
		}

		/// <summary>
		/// Returns the ItemBuffs class
		/// </summary>
		/// <remarks>
		/// null is returned for objects other then WoW_ObjectTypes.Item
		/// </remarks>
		public WoW_ItemBuffs ItemBuffs
		{
			get
			{
				if( Type != WoW_ObjectTypes.Item)
					return null;

				if( itembuffs == null)
					itembuffs = new WoW_ItemBuffs( owner, this);

				return itembuffs;
			}
		}
		#endregion

		#region Game object type specific functions
		private int isMiningNode = 0; // 0 = Unknown, 1 == No, 2 == Yes
		/// <summary>
		/// Is this a mining node?
		/// </summary>
		public bool IsMiningNode
		{
			get
			{
				// Only type 5 can be mines
				if( type != WoW_ObjectTypes.GameObject)
					isMiningNode = 1;

				// Is mining node cached yet?
				if( isMiningNode == 0)
				{
					// No check if its a mining node
					string displayMDX = GetDisplayMDX();

					isMiningNode = 1;
					if( displayMDX.IndexOf( "_miningnode_") > -1)
						isMiningNode = 2;
				}

				// Is it a mining node?
				return isMiningNode == 2;
			}
		}

		/// <summary>
		/// Cache of IsWeedNode
		/// </summary>
		private int isWeedNode = 0; // 0 = Unknown, 1 == No, 2 == Yes
		/// <summary>
		/// Is this object a Weed Node (e.g. is it weed)
		/// </summary>
		public bool IsWeedNode
		{
			get
			{
				// Only type 5 can be weed
				if( type != WoW_ObjectTypes.GameObject)
					isWeedNode = 1;

				// Is weed node cached yet?
				if( isWeedNode == 0)
				{
					// No check if its a weed node
					string displayMDX = GetDisplayMDX();

					isWeedNode = 1;
					if( displayMDX.IndexOf( "tradeskillnodes\\bush") > -1)
						isWeedNode = 2;
				}

				// Is it a mining node?
				return isWeedNode == 2;
			}
		}
		
		/// <summary>
		/// Cache of IsTreasureNoed
		/// </summary>
		private int isTreasureNode = 0; // 0 = Unknown, 1 == No, 2 == Yes
		/// <summary>
		/// Is this object a treasure node (e.g. is it treasure)
		/// </summary>
		public bool IsTreasureNode
		{
			get
			{
				// Only type 5 can be weed
				if( type != WoW_ObjectTypes.GameObject)
					isTreasureNode = 1;

				// Is weed node cached yet?
				if( isTreasureNode == 0)
				{
					// No check if its a weed node
					string displayMDX = GetDisplayMDX();

					isTreasureNode = 1;
					if( displayMDX.IndexOf( "treasure") > -1)
						isTreasureNode = 2;
				}

				// Is it a mining node?
				return isTreasureNode == 2;
			}
		}

		/// <summary>
		/// Returns true if the bobber is bobbing
		/// </summary>
		public bool BobberBobbing
		{
			get
			{
				if( Type != WoW_ObjectTypes.GameObject)
					return false;

				return owner.Memory.ReadInteger( ptrBase + 0xE8) != 0;
			}
		}
		#endregion

		#region Unit and/or Player specific properties and functions\
		/// <summary>
		/// Returns the unit/player's HP
		/// </summary>
		public int Health
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return 0;

				return ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_HEALTH"]);
			}
		}

		/// <summary>
		/// Returns the unit/player's Maximum HP
		/// </summary>
		public int MaximumHealth
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return 0;

				return ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_MAXHEALTH"]);
			}
		}

		/// <summary>
		/// Returns the health percentage
		/// </summary>
		public float HealthPercentage
		{
			get
			{
				return (float) Health / (float) MaximumHealth * 100f;
			}
		}

		/// <summary>
		/// Returns the current mana
		/// </summary>
		public int Mana
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return 0;

				return (int)ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_POWER1"]);
			}
		}

		/// <summary>
		/// Returns the unit/player's Maximum Mana
		/// </summary>
		public int MaximumMana
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return 0;

				return ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_MAXPOWER1"]);
			}
		}

		/// <summary>
		/// Returns the mana percentage
		/// </summary>
		public float ManaPercentage
		{
			get
			{
				// if there's no mana, return 100%
				if( MaximumMana == 0)
					return 100f;

				return (float) Mana / (float) MaximumMana * 100f;
			}
		}

		/// <summary>
		/// Returns the current rage
		/// </summary>
		public int Rage
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return 0;

				return (int)(ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_POWER2"]) / 10);
			}
		}

		/// <summary>
		/// Returns the number of combo points
		/// </summary>
		public int ComboPoints
		{
			get
			{
				if( Type != WoW_ObjectTypes.Player)
					return 0;

				int ptr = owner.Memory.ReadInteger( BasePtr + owner.offsets.getOffset("CGPlayer_C__ComboPoints_Ptr1"));
				return owner.Memory.ReadInteger( ptr + owner.offsets.getOffset("CGPlayer_C__ComboPoints_Ptr2")) & 0xFF;
			}
		}

		/// <summary>
		/// Returns the current focus
		/// </summary>
		public int Focus
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return 0;

				return (int)ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_POWER3"]);
			}
		}

		/// <summary>
		/// Returns the current energy
		/// </summary>
		public int Energy
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return 0;

				return (int)ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_POWER4"]);
			}
		}

		/// <summary>
		/// Returns the current Happiness of a pet as a percentage
		/// </summary>
		public int HappinessPercentage
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit)
					return 0;

				float petHappiness = (float)ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_POWER5"]);
				float petMaxHappiness = (float)ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_MAXPOWER5"]);

				if( petMaxHappiness == 0)
					return 100;

				return (int)((petHappiness/petMaxHappiness)*100);
			}
		}

		/// <summary>
		/// The unit/player's target
		/// </summary>
		public WoW_Object Target
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return null;

				return (WoW_Object) owner.Objects[TargetGUID];
			}
		}

		/// <summary>
		/// Returns unit/player's pet
		/// </summary>
		public WoW_Object Pet
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return null;

				long pet = ReadStorageLong( owner.Descriptors[ type, "UNIT_FIELD_SUMMON"]);
				if( pet == 0)
					pet = ReadStorageLong( owner.Descriptors[ type, "UNIT_FIELD_CHARM"]);

				return (WoW_Object) owner.Objects[pet];
			}
		}

		/// <summary>
		/// If this object is a pet, then this returns its owner
		/// </summary>
		public WoW_Object Owner
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return null;

				long ownerid = ReadStorageLong( owner.Descriptors[ type, "UNIT_FIELD_SUMMONEDBY"]);
				if( ownerid == 0)
					ownerid = ReadStorageLong( owner.Descriptors[ type, "UNIT_FIELD_CHARMEDBY"]);

				return (WoW_Object) owner.Objects[ownerid];
			}
		}

		/// <summary>
		/// Used internally to get number of attackers while updating
		/// </summary>
		internal long TargetGUID
		{
			get
			{
				if( Type == WoW_ObjectTypes.Unit)
					return ReadStorageLong( owner.Descriptors[ type, "UNIT_FIELD_TARGET"]);

				if( Type == WoW_ObjectTypes.Player)
					return ReadStorageLong( owner.Descriptors[ type, "PLAYER_SELECTION"]);

				return 0;
			}
		}

		/// <summary>
		/// Unit/player is dead?
		/// </summary>
		public bool IsDead
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return false;
				
				return Health == 0;
			}
		}

		/// <summary>
		/// Unit/player sitting?
		/// </summary>
		public bool IsSitting
		{
			get
			{
				if( Type != WoW_ObjectTypes.Unit && Type != WoW_ObjectTypes.Player)
					return false;

				return (ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_BYTES_1"]) & 0xFF) != 0;
			}
		}

		/// <summary>
		/// Unit is skinnable ?
		/// </summary>
		public bool IsSkinnable
		{
			get
			{
				if( type != WoW_ObjectTypes.Unit)
					return false;

				return (ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_FLAGS"]) & 0x4000000) != 0;
			}
		}

		/// <summary>
		/// Unit can be looted?
		/// </summary>
		public bool CanLoot
		{
			get
			{
				if( type != WoW_ObjectTypes.Unit)
					return false;

				return (ReadStorageInt( owner.Descriptors[ type, "UNIT_DYNAMIC_FLAGS"]) & 1) != 0;
			}
		}

		/// <summary>
		/// Unit / player level
		/// </summary>
		public int Level
		{
			get
			{
				if( type == WoW_ObjectTypes.Unit || type == WoW_ObjectTypes.Player)
					return ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_LEVEL"]);

				if( type == WoW_ObjectTypes.GameObject)
					return ReadStorageInt( owner.Descriptors[ type, "GAMEOBJECT_LEVEL"]);

				return 1;
			}
		}

		/// <summary>
		/// Is player casting a spell (either normal or channel spell)
		/// </summary>
		public bool IsCasting
		{
			get
			{
				if( type != WoW_ObjectTypes.Player)
					return false;

				return (owner.Memory.ReadInteger(BasePtr + owner.offsets.getOffset("CGPlayer_C__CastingSpellId")) != 0) || (ReadStorageInt( owner.Descriptors[ type, "UNIT_CHANNEL_SPELL"]) != 0);
			}
		}

		/// <summary>
		/// Is the player attacking using a melee weapon?
		/// </summary>
		public bool IsAttacking
		{
			get
			{
				if( type != WoW_ObjectTypes.Player)
					return false;

				return (owner.Memory.ReadLong( BasePtr + owner.offsets.getOffset("CGPlayer_C__MeleeTarget")) != 0);
			}
		}

		/// <summary>
		/// Is the player (auto) shooting using a ranged weapon?
		/// </summary>
		public bool IsShooting
		{
			get
			{
				if( type != WoW_ObjectTypes.Player)
					return false;

				return ((owner.Memory.ReadInteger( BasePtr + owner.offsets.getOffset("CGPlayer_C__IsShootingFlag")) & 0x1000) != 0);
			}
		}

		/// <summary>
		/// Is unit or player in combat?
		/// </summary>
		public bool IsInCombat
		{
			get
			{
				if( type != WoW_ObjectTypes.Unit && type != WoW_ObjectTypes.Player)
					return false;

				return (ReadStorageInt( owner.Descriptors[ type, "UNIT_FIELD_FLAGS"]) & 0x80000) != 0;
			}
		}

		/// <summary>
		/// Returns the object thats being channeled, for fishing it contains the fishing bobber
		/// </summary>
		public WoW_Object ChannelObject
		{
			get
			{
				if( type != WoW_ObjectTypes.Player)
					return null;

				long guid = ReadStorageLong( owner.Descriptors[ type, "UNIT_FIELD_CHANNEL_OBJECT"]);
				return (WoW_Object) owner.Objects[ guid];
			}
		}

		private string _racecache = null;
		/// <summary>
		/// Returns the unit's race
		/// </summary>
		public string UnitRace
		{
			get
			{
				if( _racecache != null)
					return _racecache;

				if( type != WoW_ObjectTypes.Unit && type != WoW_ObjectTypes.Player)
					return (_racecache = "");

				int Language = owner.Memory.ReadInteger( owner.pointers.getPointer( "WOW_LOCALE_CURRENT_LANGUAGE"));

				int basePtr = owner.Memory.ReadInteger( ptrBase + 0x110);
				int raceid = owner.Memory.ReadInteger( basePtr + 0x78) & 0xFF;

				if( raceid == 0 || raceid > owner.Memory.ReadInteger( owner.pointers.getPointer("g_charRacesCount")))
					return (_racecache = "");

				int rows = owner.Memory.ReadInteger( owner.pointers.getPointer("g_charRaces"));
				int row = owner.Memory.ReadInteger( rows + raceid * 4);
				
				int field = owner.Memory.ReadInteger( row + 0x44 + Language * 4);
				return (_racecache = owner.Memory.ReadString( field, 64));
			}
		}

		private string _classcache = null;
		/// <summary>
		/// Returns the unit's class
		/// </summary>
		public string UnitClass
		{
			get
			{
				if( _classcache != null)
					return _classcache;

				if( type != WoW_ObjectTypes.Unit && type != WoW_ObjectTypes.Player)
					return (_classcache = "");

				int Language = owner.Memory.ReadInteger( owner.pointers.getPointer( "WOW_LOCALE_CURRENT_LANGUAGE"));

				int basePtr = owner.Memory.ReadInteger( ptrBase + 0x110);
				int classid = owner.Memory.ReadInteger( basePtr + 0x79) & 0xFF;

				if( classid == 0 || classid > owner.Memory.ReadInteger( owner.pointers.getPointer("g_charClassesCount")))
					return (_classcache = "");

				int rows = owner.Memory.ReadInteger( owner.pointers.getPointer("g_charClasses"));
				int row = owner.Memory.ReadInteger( rows + classid * 4);
				
				int field = owner.Memory.ReadInteger( row + 0x14 + Language * 4);
				return (_classcache = owner.Memory.ReadString( field, 64));
			}
		}
		#endregion

		/// <summary>
		/// Returns the radian that would face the x,y specified
		/// </summary>
		/// <param name="faceX">x</param>
		/// <param name="faceY">y</param>
		/// <returns>Radian needed to face x,y</returns>
		internal float GetFaceRadian( float faceX, float faceY)
		{
			float dx = (x - faceX);
			float dy = faceY - y;

			float newRad=0;
			if(dx>0.0 && dy>=0.0) newRad = (float)Math.Atan( dy/dx );
			if(dx<0.0 && dy>=0.0) newRad = (float)Math.Atan( dy/dx ) + (float)Math.PI;
			if(dx<0.0 && dy<0.0) newRad = (float)Math.Atan( dy/dx ) + (float)Math.PI;
			if(dx>0.0 && dy<0.0) newRad = (float)Math.Atan( dy/dx ) + (float)(2*Math.PI);
	
			newRad -= (float)1.57079633 ;  //silly game making zero degrees due East
	
			return newRad;
		}

		/// <summary>
		/// Returns the distance between the two WoW_Objects
		/// </summary>
		/// <param name="obj">Object to measure distance between</param>
		/// <returns>Distance</returns>
		public float GetDistance( WoW_Object obj)
		{
			if( obj == null)
				return 0;

			return GetDistance( obj.X, obj.Y, obj.Z);
		}

		/// <summary>
		/// Gets the distance from the current object to the x,y specified
		/// </summary>
		/// <param name="x">x</param>
		/// <param name="y">y</param>
		/// <param name="z">z</param>
		/// <returns>Distance</returns>
		public float GetDistance( float x, float y, float z)
		{
			float dX = X - x;
			float dY = Y - y;
			float dZ = (z != 0 ? Z - z : 0);

			return (float)Math.Sqrt(dX*dX + dY*dY + dZ*dZ);
		}
	}
}
