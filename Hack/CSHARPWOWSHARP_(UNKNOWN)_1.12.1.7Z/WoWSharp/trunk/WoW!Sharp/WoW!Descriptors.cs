//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.IO;
using System.Collections;

namespace WoW_Sharp
{
	/// <summary>
	/// This class contains all the descriptors for all the WoW_ObjectTypes
	/// </summary>
	public class WoW_Descriptors
	{
		private WoW owner;

		private Hashtable [] descriptors;

		internal WoW_Descriptors( WoW owner)
		{
			this.owner = owner;

			descriptors = new Hashtable[8];
			descriptors[0] = LoadDescriptors( "s_objDescriptors");
			descriptors[1] = LoadDescriptors( "s_itemDescriptors");
			descriptors[2] = LoadDescriptors( "s_containerDescriptors");
			descriptors[3] = LoadDescriptors( "s_unitDescriptors");
			descriptors[4] = LoadDescriptors( "s_playerDescriptors");
			descriptors[5] = LoadDescriptors( "s_gameObjectDescriptors");
			descriptors[6] = LoadDescriptors( "s_dynamicObjectDescriptors");
			descriptors[7] = LoadDescriptors( "s_corpseDescriptors");
		}

		/// <summary>
		/// Returns a hashtable of the specified descriptor
		/// </summary>
		/// <param name="descriptor">Descriptor to parse</param>
		private Hashtable LoadDescriptors( string descriptor)
		{
			Hashtable htFields = new Hashtable();

			int i = 0;
			int basePtr = owner.pointers.getPointer( descriptor);

			//StreamWriter sw = new StreamWriter( descriptor);
			while( true)
			{
				int ptr = owner.Memory.ReadInteger(basePtr);

				if( (ptr&0x40000000) == 0x40000000)
					break;

				string field = owner.Memory.ReadString( ptr, 64);

				// Seems to be something wrong with the descriptor array, there's no 2nd OBJECT_FIELD_GUID after spot 1
				// There's probably a 'count' field somewhere, should find it
				if( field == "OBJECT_FIELD_GUID" && i > 2)
					break;

				if( !htFields.ContainsKey( field))
				{
					//sw.WriteLine( "{0}|{1}", i * 4, field);
					htFields.Add( field, i * 4);
				}

				basePtr += 0x14;
				i ++;
			}
			//sw.Close();

			return htFields;
		}

		/// <summary>
		/// Returns the descriptor index (in bytes) for the given object type and descriptor
		/// </summary>
		public int this[ WoW_ObjectTypes type, string descriptor]
		{
			get
			{
				return (int) descriptors[(int) type][descriptor];
			}
		}

		/// <summary>
		/// Returns the descriptor hashtable for a specific object type
		/// </summary>
		public Hashtable this[ WoW_ObjectTypes type]
		{
			get
			{
				return descriptors[(int) type];
			}
		}
	}
}