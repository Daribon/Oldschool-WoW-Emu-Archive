//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Collections;

namespace WoW_Sharp
{
	/// <summary>
	/// Retrieves the player names from the names db
	/// </summary>
	internal class WoW_PlayerNames : WoW_Hashtable
	{
		private class WoW_PlayerName
		{
			internal int ptr;
			internal string name;
		}
		
		internal WoW_PlayerNames( WoW owner) : base( owner)
		{
			basePtr = owner.pointers.getPointer("g_nameDBCache");
		}

		internal override object GetKey( int nPtr)
		{
			return owner.Memory.ReadLong( nPtr + 0x18);
		}

		internal override object GetValue( int nPtr)
		{
			WoW_PlayerName name = new WoW_PlayerName();
			name.ptr = nPtr;

			name.name = owner.Memory.ReadString( nPtr + 0x20, 64);

			if( name.name == "")
				name.name = null;

			return name;
		}

		internal override object this[object key]
		{
			get
			{
				WoW_PlayerName value = (WoW_PlayerName) table[key];
				if( value == null)
					return null;

				if( value.name == null)
				{
					value.name = owner.Memory.ReadString( value.ptr + 0x20, 64);

					if( value.name == "")
						value.name = null;
				}

				return value.name;
			}
		}	
	}

	/// <summary>
	/// Retrieves the item names from the names db
	/// </summary>
	internal class WoW_ItemNames : WoW_Hashtable
	{
		private class WoW_ItemName
		{
			internal int ptr;
			internal string name;
		}

		internal WoW_ItemNames( WoW owner) : base( owner)
		{
			basePtr = owner.pointers.getPointer("g_itemDBCache");
		}

		internal override object GetKey( int nPtr)
		{
			return owner.Memory.ReadInteger( nPtr);
		}

		internal override object GetValue( int nPtr)
		{
			WoW_ItemName name = new WoW_ItemName();
			name.ptr = nPtr;

			int sPtr = owner.Memory.ReadInteger( nPtr + 0x20);
			if( sPtr == 0)
			{
				name.name = null;
			}
			else
			{
				name.name = owner.Memory.ReadString( sPtr, 64);
				if( name.name == "")
					name.name = null;
			}

			return name;
		}

		internal override object this[object key]
		{
			get
			{
				WoW_ItemName value = (WoW_ItemName) table[key];
				if( value == null)
					return null;

				if( value.name == null)
				{
					int sPtr = owner.Memory.ReadInteger( value.ptr + 0x20);
					if( sPtr != 0)
						value.name = owner.Memory.ReadString( sPtr, 64);

					if( value.name == "")
						value.name = null;
				}

				return value.name;
			}
		}
	}
	
	/// <summary>
	/// This class reads the hashtables used in WoW. (more correctly, the linked list of the hashtable)
	/// </summary>
	internal abstract class WoW_Hashtable
	{
		/// <summary>
		/// Private declarations
		/// </summary>
		internal WoW owner;

		internal int basePtr;
		private int lastPtr;

		internal Hashtable table;
		private Hashtable ptrs;

		/// <summary>
		/// Base pointer to the hashtable class
		/// </summary>
		internal int BasePtr
		{
			get
			{
				return basePtr;
			}
		}

		/// <summary>
		/// Creates a reader-object for a WoW hashtable
		/// </summary>
		/// <param name="owner">Owner</param>
		internal WoW_Hashtable( WoW owner)
		{
			this.owner = owner;

			this.basePtr = basePtr;
			lastPtr = 0;


			table = new Hashtable();
			ptrs = new Hashtable();
		}

		internal abstract object GetKey( int nPtr);
		internal abstract object GetValue( int nPtr);

		/// <summary>
		/// Call this each update, it will check if a new item has been added to the
		/// WoW Hashtable linked list
		/// </summary>
		internal void Update()
		{
			int nPtr = 0;

			if( lastPtr == 0)
				lastPtr = owner.Memory.ReadInteger( basePtr + 0xC);

			nPtr = lastPtr;

			while( !((nPtr & 1) != 0 || nPtr == 0 || nPtr == 0x1c))
			{
				object key = GetKey( nPtr);
				if( !table.ContainsKey( key))
				{
					object value = GetValue( nPtr);
					if( value != null)
					{
						table.Add( key, value);
						ptrs.Add( key, nPtr);
					}
				}

				lastPtr = nPtr;
				nPtr = owner.Memory.ReadInteger( nPtr + 0x10);

				if( nPtr == lastPtr)
					break;
			}
		}

		internal virtual object this[object key]
		{
			get
			{
				object value = table[key];
				return value;
			}
		}

		internal int GetPointer( object key)
		{
			object ptr = ptrs[key];
			if( ptr == null)
				return 0;

			return (int) ptr;
		}

		internal int Count
		{
			get
			{
				return ptrs.Count;
			}
		}
	}
}
