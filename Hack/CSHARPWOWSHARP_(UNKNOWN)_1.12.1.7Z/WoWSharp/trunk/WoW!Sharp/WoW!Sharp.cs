//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Collections;
using System.Reflection;
using System.Diagnostics;
using System.Runtime.InteropServices;
using System.Threading;
using System.IO;
using System.Security.Cryptography;

namespace WoW_Sharp
{
	/// <summary>
	/// Generic event
	/// </summary>
	public delegate void WoW_SharpEvent( WoW sender);

	/// <summary>
	/// Event that gets fired when a possible teleport has been detected
	/// </summary>
	public delegate void OnTeleportDetectionDelegate( WoW sender, float distancemoved, float timemoved);

	/// <summary>
	/// Event that gets fired when a zone change has been detected
	/// </summary>
	public delegate void OnZoneChangeDelegate( WoW sender);

	/// <summary>
	/// Event fired when a line gets added to the log
	/// </summary>
	public delegate void OnLogLineDelegate( WoW sender, string line);

	/// <summary>
	/// Possible movement
	/// </summary>
	public enum WoW_Movement
	{
		/// <summary>Forward</summary>
		Forward = 0x10,
		/// <summary>Backward</summary>
		Backward = 0x20,
		/// <summary>Left</summary>
		Left = 0x100,
		/// <summary>Right</summary>
		Right = 0x200,
		/// <summary>StrafeLeft</summary>
		StrafeLeft = 0x40,
		/// <summary>StrafeRight</summary>
		StrafeRight = 0x80,
		/// <summary>PitchUp</summary>
		PitchUp = 0x400,
		/// <summary>PitchDown</summary>
		PitchDown = 0x800,
		/// <summary>AutoRun</summary>
		AutoRun = 0x1000
	}

	/// <summary>
	/// This class is used to access all the WoW objects / etc
	/// </summary>
	public class WoW
	{
		/// <summary>
		/// Private declarations
		/// </summary>
		private MemoryReader memory;
		private int interval = 125;
		private bool hasStarted = false;

		private bool terminateUpdateThread = false;
		private Thread updateThread;
		private ManualResetEvent updateWait;

		private Hashtable objsByPtr;
		private Hashtable objsById;

		private int numberOfAttackers;
		private ArrayList attackersByDistance;

		internal WoW_ItemNames itemNames;
		internal WoW_PlayerNames playerNames;
		
        private WoW_Buffs buffs;
		private WoW_Inventory inventory;
		private WoW_Loot loot;
		private WoW_Descriptors descriptors;
		private WoW_ChatLog _chatlog;

		private Hashtable knownSpells = null;
		private Hashtable highestKnownSpells = null;
		private Hashtable knownPetSpells = null;
		private Hashtable highestKnownPetSpells = null;

		const bool debuglogEnabled = true;
		private WoW_LogEngine debuglog;
		private WoW_WSSClient _wssc;
		
		private string username = "";
		private string password = "";
		internal byte [] sha512hash;
		private string application = "";

		private ArrayList partyMembers;
		private WoW_Object partyLeader;

		/// <summary>
		/// Internal declarations
		/// </summary>
		internal WoW_Globals globals;
		internal WoW_Pointers pointers;
		internal WoW_Offsets offsets;


		/// <summary>
		/// Internal variables used to detect teleportation
		/// </summary>
		internal bool lastknown;
		internal float lastx, lasty, lastz;
		internal int lastcontinent;
		internal DateTime lastcheck;

		private void Connect( FileVersionInfo fvi, FileVersionInfo fviws)
		{
			LogLine( "World of Warcraft v{0}.{1}.{2}.{3}", fvi.FileMajorPart, fvi.FileMinorPart, fvi.FileBuildPart, fvi.FilePrivatePart);
			LogLine( "Executable: " + fvi.FileName);

#if !NoHider
			FileVersionInfo fvih = FileVersionInfo.GetVersionInfo( "wow!hider.dll");
#endif			
			try
			{
				SHA512Managed SHA512Hash = new SHA512Managed();
				sha512hash = SHA512Hash.ComputeHash( System.Text.ASCIIEncoding.UTF8.GetBytes( password + "|" + username.ToLower()));
			
				_wssc = new WoW_WSSClient( this);
				_wssc.Authenticate( username, sha512hash);
				_wssc.WoWSharpCheck( fviws.FileMajorPart, fviws.FileMinorPart, fviws.FileBuildPart, fviws.FilePrivatePart);
#if !NoHider
				_wssc.WoWHiderCheck( fvih.FileMajorPart, fvih.FileMinorPart, fvih.FileBuildPart, fvih.FilePrivatePart);
#endif
				_wssc.VersionCheck( fvi.FileMajorPart, fvi.FileMinorPart, fvi.FileBuildPart, fvi.FilePrivatePart);
				_wssc.SetApplication( application);

				pointers = new WoW_Pointers( this, _wssc);
				offsets = new WoW_Offsets( this, _wssc);
			}
			catch( Exception E)
			{
				if( _wssc != null)
					_wssc.Quit();

				LogLine( "Unable to login: {0}", E.Message);
				throw E;
			}
		}

		/// <summary>
		/// Start the update thread
		/// </summary>
		/// <returns>Success</returns>
		public bool Start()
		{
			if( hasStarted)
				Stop();

			debuglog = new WoW_LogEngine( "debug.log");
			try
			{
				Assembly assembly = Assembly.GetAssembly(typeof(WoW));
				FileVersionInfo fviws = FileVersionInfo.GetVersionInfo( assembly.Location);
				debuglog.Enabled = debuglogEnabled;
				LogLine( "Starting WoW!Sharp v{0}.{1}.{2}.{3}", fviws.FileMajorPart, fviws.FileMinorPart, fviws.FileBuildPart, fviws.FilePrivatePart);

				Process [] wowLocal;
				try
				{
					wowLocal = memory.GetProcessesByExe( "wow.exe"); // Process.GetProcessesByName("WoW");
					if( wowLocal.Length == 0)
						throw new Exception("Unable to locate World of Warcraft");
				}
				catch( Exception E)
				{
					LogLine( "Unable to retrieve process list: {0}", E.Message);
					throw E;
				}

				try
				{
					if( memory.IsOpen)
						memory.Close();

					memory.Open( wowLocal[0]);
					if( (int) memory.Handle == 0)
						throw new Exception( "Unknown");
				}
				catch( Exception E)
				{
					LogLine( "Unable to open process: {0}", E.Message);
					throw E;
				}
			
				FileVersionInfo fvi = null;
				foreach( ProcessModule m in wowLocal[0].Modules)
				{
					if( m.ModuleName.ToLower() == "wow.exe")
					{
						fvi = FileVersionInfo.GetVersionInfo( m.FileName);
						break;
					}
				}

				if( fvi == null)
				{
					LogLine( "Unable to locate WoW.exe module.");
					throw new Exception( "Unable to locate WoW.exe module");
				}

				Connect( fvi, fviws);

				lastknown = false;
				knownSpells = null;
				highestKnownSpells = null;
				knownPetSpells = null;
				highestKnownPetSpells = null;
		
				globals = new WoW_Globals( this);

				terminateUpdateThread = false;

				foreach( WoW_Object obj in objsByPtr.Values)
					obj.invalid = true;

				objsByPtr.Clear();
				objsById.Clear();

				itemNames = new WoW_ItemNames(this);
				playerNames = new WoW_PlayerNames(this);
				buffs = new WoW_Buffs(this);
				loot = new WoW_Loot(this);
				descriptors = new WoW_Descriptors( this);

				_chatlog.Reset();

				updateWait = new ManualResetEvent(false);
				updateThread = new Thread( new ThreadStart(updateProc));
				updateThread.Start();

				LogLine( "Waiting for first update to finish");
				if( !updateWait.WaitOne( 30000, false))
					LogLine( "Update thread has taken longer then 30s.");

				hasStarted = true;
				LogLine( "Started WoW!Sharp");
			}
			catch( Exception E)
			{
				debuglog.Dispose();
				debuglog = null;

				throw( E);
			}
			return true;
		}


		/// <summary>
		/// This event is called after the local data has been updated
		/// </summary>
		public event WoW_SharpEvent AfterUpdate;

		/// <summary>
		/// This event is called when a line gets added to the log
		/// </summary>
		public event OnLogLineDelegate OnLogLine;

		/// <summary>
		/// This event is called when a minor player teleport is detected, this could be due to lag
		/// </summary>
		public event OnTeleportDetectionDelegate OnMinorTeleportDetection;

		/// <summary>
		/// This event is called when a major player teleport is detected
		/// </summary>
		public event OnTeleportDetectionDelegate OnMajorTeleportDetection;

		/// <summary>
		/// This event is called when a zone change is detected
		/// </summary>
		public event OnZoneChangeDelegate OnZoneChange;

		/// <summary>
		/// Update thread
		/// </summary>
		private void updateProc()
		{
			while( !terminateUpdateThread)
				try
				{
					// Are we still connected?
					_wssc.CheckPing();

					int newNumberOfAttackers = 0;
					ArrayList attackers = new ArrayList();

					Hashtable byId = new Hashtable();
					Hashtable byPtr = new Hashtable();

					if( memory.IsOpen)
					{
						playerNames.Update();
						itemNames.Update();

						globals.cdbFaction = memory.ReadInteger( pointers.getPointer( "g_factionDB"));
						globals.cdbFactionGroup = memory.ReadInteger( pointers.getPointer( "g_factionGroupDB"));

						long playerId = memory.ReadLong( pointers.getPointer("CGGameUI__m_player"));
						long targetId = memory.ReadLong( pointers.getPointer("CGGameUI__m_lockedTarget"));

						int currObjMgr = memory.ReadInteger( pointers.getPointer( "s_curMgr"));

						// + 0xB4 == pointer to the first entry, by substracting 0x3C
						// the while can stay the same while running through the whole linked list
						int ptrOffset = offsets.getOffset("s_curMgr_NextObject");
						int ptr = currObjMgr + (offsets.getOffset("s_curMgr_FirstObject") - ptrOffset);
						int lastPtr = 0;
						int ptrErr = 0;
						while( !terminateUpdateThread && currObjMgr > 0 && memory.IsOpen)
						{
							// + 0x3C contains the next ptr in the linked list
							ptr = memory.ReadInteger( ptr + ptrOffset);

							// If any of these are true, the last item has been reached
							if( (ptr&0x1) != 0 || ptr == 0 || ptr == 0x1c)
								break;

							WoW_Object obj = null;
							if( objsByPtr.Contains( ptr))
							{
								obj = (WoW_Object) objsByPtr[ ptr];
								if( !obj.Update())
									obj = null;
							}

							if( obj == null)
							{
								obj = new WoW_Object( ptr, this);
								obj.Update();
							}

							if( obj.GUID.GUID == playerId)
								globals.player = obj;
							else // Its not the player, check if the objects target == the player
								if( obj.TargetGUID == playerId)
							{
								if( obj.Type == WoW_ObjectTypes.Player)
								{
									if( (Player == null || GetUnitReaction( Player, obj) == 1) && obj.IsInCombat)
									{
										newNumberOfAttackers ++;
										attackers.Add( obj);
									}
								}
								else
								{
									newNumberOfAttackers ++;
									attackers.Add( obj);
								}
							}

							if( obj.GUID.GUID == targetId)
								globals.target = obj;

							if( !byPtr.Contains( ptr))
								byPtr.Add( ptr, obj);
							if( !byId.Contains( obj.GUID.GUID))
								byId.Add( obj.GUID.GUID, obj);

							// Detect memory-loop
							if( lastPtr == ptr)
							{
								ptrErr ++;
								if( ptrErr == 5)
									break;
							}
							else
							{
								lastPtr = ptr;
								ptrErr = 0;
							}
						}

						if( globals.player != null && globals.player.GUID.GUID != playerId)
							globals.player = null;

						if( globals.target != null && globals.target.GUID.GUID != targetId)
							globals.target = null;
					}

					ArrayList newAttackers = new ArrayList(attackers.Count);
					if( Player != null)
					{
						foreach( WoW_Object obj in attackers)
						{
							float distance = Player.GetDistance( obj);
							newAttackers.Add( new WoW_Distance( distance, obj));
						}

						if( lastknown)
						{
							float moved = Player.GetDistance( lastx, lasty, lastz);
							float perms = Player.Speed / 1000;
							if( perms == 0) perms = 7000;

							float timemoved = (float) DateTime.Now.Subtract( lastcheck).TotalMilliseconds;

							// Did we have a continent change?
							if( lastcontinent != CurrentContinent)
							{
								LogLine( "A zone change has been detected, old zone id was {0}, the current zone id is {1}.", lastcontinent, CurrentContinent);
								if( OnZoneChange != null)
									OnZoneChange( this);
							}

							// Only do the teleport check 
							if( timemoved > 100)
							{
								// Did we move then 10x the movement speed allows?
								if( moved > (perms * timemoved * 10))
								{
									LogLine( "Major teleport detected, the player moved {0:N} units in {1:N} ms.", moved, timemoved);
									if( OnMajorTeleportDetection != null)
										OnMajorTeleportDetection( this, moved, timemoved);

								}	// Did we move more then 2x the movement speed allows?
								else if( moved > (perms * timemoved * 2))
								{
									if( OnMinorTeleportDetection != null)
										OnMinorTeleportDetection( this, moved, timemoved);
								}

								// Only update if we've moved longer then 100ms
								lastx = Player.X;
								lasty = Player.Y;
								lastz = Player.Z;
								lastcheck = DateTime.Now;
								lastcontinent = CurrentContinent;
							}
						}
						else
						{
							// First update
							lastx = Player.X;
							lasty = Player.Y;
							lastz = Player.Z;
							lastknown = true;
							lastcheck = DateTime.Now;
							lastcontinent = CurrentContinent;
						}
					}
					newAttackers.Sort();

					objsById = byId;
					objsByPtr = byPtr;

					numberOfAttackers = newNumberOfAttackers;
					attackersByDistance = newAttackers;

					inventory.Update();
                    
					ArrayList members = new ArrayList();
					for( int i = 0; i < 4; i ++)
					{
						long memberId = memory.ReadLong( pointers.getPointer("CGPartyInfo__m_members") + i * 8);
						WoW_Object member = null;

						if( memberId != 0)
							member = (WoW_Object) objsById[ memberId];

						if( member != null)
							members.Add( member);
					}

					if( members.Count > 0)
						members.Add( globals.player);

					partyMembers = members;

					long leaderId = memory.ReadLong( pointers.getPointer("CGPartyInfo__m_leader"));
					if( leaderId != 0)
						partyLeader = (WoW_Object) objsById[ leaderId];

					updateWait.Set();
					if( AfterUpdate != null)
					{
						try
						{
							AfterUpdate( this);
						}
						catch( Exception E)
						{
							LogLine( "Exception in AfterUpdate.");
							LogLine( "Message: {0}", E.Message);
							LogLine( "Source: {0}", E.Source);
						}
					}

					Thread.Sleep( interval);
				}
				catch( Exception E)
				{
					LogLine( "Exception in updateProc: {0}", E.Message);
				}
		}


		/// <summary>
		/// Stop the update thread
		/// </summary>
		public void Stop()
		{
			if( !hasStarted)
				return;

			LogLine( "Stopping WoW!Sharp");

			// Quit from the server
			_wssc.Quit();
			_wssc = null;

			terminateUpdateThread = true;
			updateThread.Join();

			if( memory.IsOpen)
                memory.Close();

			LogLine( "Stopped WoW!Sharp");

			debuglog.Dispose();
			debuglog = null;
	
			hasStarted = false;
		}


		/// <summary>
		/// Active MemoryReader
		/// </summary>
		public MemoryReader Memory
		{
			get
			{
				return memory;
			}
		}


		/// <summary>
		/// Set the update interval
		/// </summary>
		/// <remarks>
		/// **WARNING** do not set too high **WARNING**
		/// </remarks>
		public int Interval
		{
			get
			{
				return interval;
			}
			set
			{
				interval = value;
			}
		}


		/// <summary>
		/// Class constructor
		/// </summary>
		public WoW()
		{
			inventory = new WoW_Inventory(this);

			objsById = new Hashtable();
			objsByPtr = new Hashtable();

			memory = new MemoryReader();
			//memory.EnableDebuggerPrivileges();

			_chatlog = new WoW_ChatLog( this);
		}


		/// <summary>
		/// Class destructor
		/// </summary>
		~WoW()
		{
			if( hasStarted)
				Stop();
		}


		/// <summary>
		/// Is WoW!Sharp currently started
		/// </summary>
		public bool HasStarted
		{
			get
			{
				return hasStarted;
			}
		}

		#region WoW!Sharp's active functions
#if !NoHider
		/// <summary>
		/// Startup WoW with WoW!Hider
		/// </summary>
		/// <returns>Success?</returns>
		public bool StartWoW( string path)
		{
			debuglog = new WoW_LogEngine( "debug.log");
			try
			{
				Assembly assembly = Assembly.GetAssembly( typeof( WoW));
				FileVersionInfo fviws = FileVersionInfo.GetVersionInfo( assembly.Location);
				debuglog.Enabled = debuglogEnabled;
				LogLine( "Starting WoW!Sharp v{0}.{1}.{2}.{3}", fviws.FileMajorPart, fviws.FileMinorPart, fviws.FileBuildPart, fviws.FilePrivatePart);

				FileVersionInfo fvi = FileVersionInfo.GetVersionInfo( path);

				Connect( fvi, fviws);
				try
				{
					WoW_Execute.SetChatlogPath( System.Environment.CurrentDirectory + "\\chat.log");
					WoW_Execute.SetClearTargetPtr( pointers.getPointer("CGGameUI__ClearTarget"));
					WoW_Execute.SetScriptExecutePtr( pointers.getPointer("FrameScript_Execute"), pointers.getPointer("g_HardwareEvent"));
					WoW_Execute.SetDetourPtr( pointers.getPointer("CGWorldFrame__RenderWorld"));
					WoW_Execute.SetProcessMessagePtr( pointers.getPointer("NetClient__ProcessMessage"));
					WoW_Execute.SetAddChatMessagePtr( pointers.getPointer("CGChat__AddChatMessage"));
					WoW_Execute.SetRightClickPtr( pointers.getPointer("CGGameUI__RightClick"));
					WoW_Execute.SetLeftClickPtr( pointers.getPointer("CGGameUI__LeftClick"));
					WoW_Execute.SetAutoStoreAllLootItemsPtr( pointers.getPointer("AutoStoreAllLootItems"));
					WoW_Execute.SetCastSpellByIDPtr( pointers.getPointer("Spell_C_CastSpellByID"));
					WoW_Execute.SetOsGetAsyncTimeMsPtr( pointers.getPointer("OsGetAsyncTimeMs"));
					WoW_Execute.SetMovementPtr( pointers.getPointer("CGInputControl__GetActive"), pointers.getPointer("CGInputControl__SetControlBit"));
					WoW_Execute.SetAntiAFKPtr( pointers.getPointer("s_currentWorldFrame"), offsets.getOffset("s_currentWorldFrame_AntiAFK_1"), offsets.getOffset("s_currentWorldFrame_AntiAFK_2"));

					int result = WoW_Execute.CreateProcessWithDll( path, System.Environment.CurrentDirectory + "\\wow!hider.dll");

					ChatLog.Reset();
				
					LogLine( "Started World of Warcraft");
					return result != 0;
				}
				finally
				{
					_wssc.Quit();
				}
			}
			finally
			{
				debuglog.Dispose();
				debuglog = null;
			}
		}

		public bool InjectWoW( Process process)
		{
			debuglog = new WoW_LogEngine( "debug.log");
			try
			{
				Assembly assembly = Assembly.GetAssembly( typeof( WoW));
				FileVersionInfo fviws = FileVersionInfo.GetVersionInfo( assembly.Location);
				debuglog.Enabled = debuglogEnabled;
				LogLine( "Starting WoW!Sharp v{0}.{1}.{2}.{3}", fviws.FileMajorPart, fviws.FileMinorPart, fviws.FileBuildPart, fviws.FilePrivatePart);

				FileVersionInfo fvi = null;
				foreach( ProcessModule m in process.Modules)
				{
					if( m.ModuleName.ToLower() == "wow.exe")
					{
						fvi = FileVersionInfo.GetVersionInfo( m.FileName);
						break;
					}
				}

				if( fvi == null)
					throw( new Exception( "Unable to determin the World of Warcraft version."));

				Connect( fvi, fviws);
				try
				{
					WoW_Execute.SetChatlogPath( System.Environment.CurrentDirectory + "\\chat.log");
					WoW_Execute.SetClearTargetPtr( pointers.getPointer("CGGameUI__ClearTarget"));
					WoW_Execute.SetScriptExecutePtr( pointers.getPointer("FrameScript_Execute"), pointers.getPointer("g_HardwareEvent"));
					WoW_Execute.SetDetourPtr( pointers.getPointer("CGWorldFrame__RenderWorld"));
					WoW_Execute.SetProcessMessagePtr( pointers.getPointer("NetClient__ProcessMessage"));
					WoW_Execute.SetAddChatMessagePtr( pointers.getPointer("CGChat__AddChatMessage"));
					WoW_Execute.SetRightClickPtr( pointers.getPointer("CGGameUI__RightClick"));
					WoW_Execute.SetLeftClickPtr( pointers.getPointer("CGGameUI__LeftClick"));
					WoW_Execute.SetAutoStoreAllLootItemsPtr( pointers.getPointer("AutoStoreAllLootItems"));
					WoW_Execute.SetCastSpellByIDPtr( pointers.getPointer("Spell_C_CastSpellByID"));
					WoW_Execute.SetOsGetAsyncTimeMsPtr( pointers.getPointer("OsGetAsyncTimeMs"));
					WoW_Execute.SetMovementPtr( pointers.getPointer("CGInputControl__GetActive"), pointers.getPointer("CGInputControl__SetControlBit"));
					WoW_Execute.SetAntiAFKPtr( pointers.getPointer("s_currentWorldFrame"), offsets.getOffset("s_currentWorldFrame_AntiAFK_1"), offsets.getOffset("s_currentWorldFrame_AntiAFK_2"));

					memory.Open( process);
					if( !memory.IsOpen)
						throw( new Exception( "Unable to open World of Warcraft"));

					int result = WoW_Execute.ContinueProcessWithDll( memory.Handle, System.Environment.CurrentDirectory + "\\wow!hider.dll");
					memory.Close();

					ChatLog.Reset();
				
					LogLine( "Started World of Warcraft");
					return result != 0;
				}
				finally
				{
					_wssc.Quit();
				}
			}
			finally
			{
				debuglog.Dispose();
				debuglog = null;
			}
		}

		/// <summary>
		/// Returns the path to the chat.log file created by WoW!Execute
		/// </summary>
		public string ChatlogPath
		{
			get
			{
				System.Text.StringBuilder newpath = new System.Text.StringBuilder (256);
				WoW_Execute.GetChatlogPath(  newpath);

				return newpath.ToString();
			}
		}

		/// <summary>
		/// Returns the chatlog parser
		/// </summary>
		public WoW_ChatLog ChatLog
		{
			get
			{
				return _chatlog;
			}
		}

		/// <summary>
		/// Right click an WoW_Object
		/// </summary>
		/// <param name="obj"></param>
		public void RightClick( WoW_Object obj)
		{
			WoW_Execute.RightClick( obj.GUID.GUID);
		}

		/// <summary>
		/// Clear the Players Target
		/// </summary>
		public void ClearTarget()
		{
			if( Target == null)
				return;

			WoW_Execute.ClearTarget( Target.GUID.GUID);
		}

		/// <summary>
		/// Left click an WoW_Object
		/// </summary>
		/// <param name="obj"></param>
		public void LeftClick( WoW_Object obj)
		{
			WoW_Execute.LeftClick( obj.GUID.GUID);
		}

		/// <summary>
		/// Cast a spell by name
		/// </summary>
		/// <remarks>
		/// You can specify the spell with or without a rank
		/// </remarks>
		/// <param name="spell">Spellname</param>
		public bool CastSpellByName( string spell)
		{
            int spellId = 0;
			if( KnownSpells.Contains( spell))
				spellId = (int) KnownSpells[ spell];
			if( HighestKnownSpells.Contains( spell))
				spellId = (int) HighestKnownSpells[ spell];
			if( KnownPetSpells.Contains( spell))
				spellId = (int) KnownPetSpells[ spell];
			if( HighestKnownPetSpells.Contains( spell))
				spellId = (int) HighestKnownPetSpells[ spell];

			if( spellId == 0)
				return false;

			CastSpellByID( spellId);
			return true;
		}

		/// <summary>
		/// Cast a spell by ID
		/// </summary>
		/// <remarks>
		/// Get the id by using the KnownSpells or KnownPetSpells properties
		/// </remarks>
		/// <param name="id">Spell ID</param>
		public void CastSpellByID( int id)
		{
			WoW_Execute.CastSpellByID( id);
		}

		/// <summary>
		/// Execute a script inside WoW
		/// </summary>
		public void SendScript( string script)
		{
			WoW_Execute.ScriptExecute( script);
		}

		/// <summary>
		/// Enable or Disable the 'Read all languages' option of WoWSharp
		/// </summary>
		/// <param name="readall">Enabled?</param>
		public void ReadAllLanguages( bool readall)
		{
			WoW_Execute.SetReadAllLanguages( readall);
		}

		/// <summary>
		/// Starts a movement
		/// </summary>
		/// <param name="movement">Movement to start</param>
		public void StartMovement( WoW_Movement movement)
		{
			WoW_Execute.StartMovement( (int) movement);
		}

		/// <summary>
		/// Stops a movement
		/// </summary>
		/// <param name="movement">Movement to stop</param>
		public void StopMovement( WoW_Movement movement)
		{
			WoW_Execute.StopMovement( (int) movement);
		}

		/// <summary>
		/// Starts a movement and stops it after specified time
		/// </summary>
		/// <param name="movement">Timed movement</param>
		/// <param name="time">Time</param>
		public void TimedMovement( WoW_Movement movement, int time)
		{
			WoW_Execute.TimedMovement( (int) movement, time);
			
			//sleep our thread the same amount of time
			Thread.Sleep(time);
		}

		const float PI2 = (float)(Math.PI * 2);
		const float TurnSpeed = 0.00328125F;

		/// <summary>
		/// Calculates the amount of radian to turn to face the x,y position specified
		/// </summary>
		/// <param name="x">x position</param>
		/// <param name="y">y position</param>
		/// <param name="faceAway">Face away from x / y?</param>
		/// <param name="turnRight">True if you have to turn right [output]</param>
		/// <returns>Radian amount to turn</returns>
		internal float GetTurnRadian( float x, float y, bool faceAway, out bool turnRight)
		{
			float newRadian = globals.player.GetFaceRadian( x, y) + (faceAway ? (float) Math.PI : 0);

			return GetTurnRadian(newRadian, faceAway, out turnRight);
		}

		/// <summary>
		/// Calculates the amount of radian to turn to face the new radian specified
		/// </summary>
		/// <param name="newRadian">The radian you want to face</param>
		/// <param name="faceAway">Face away from x / y?</param>
		/// <param name="turnRight">True if you have to turn right [output]</param>
		/// <returns>Radian amount to turn</returns>
		internal float GetTurnRadian( float newRadian, bool faceAway, out bool turnRight)
		{
			float oldRadian = globals.player.Facing;

			// Make sure both radians are between 0 - PI2
			while(newRadian < 0)   newRadian += PI2;
			while(newRadian > PI2) newRadian -= PI2;
			while(oldRadian < 0)   oldRadian += PI2;
			while(oldRadian > PI2) oldRadian -= PI2;

			// Calculate amount of radian to turn when turning left
			float leftRadian = newRadian - oldRadian;
			if( leftRadian < 0) leftRadian += PI2;

			// Calculate amount of radian to turn when turning right
			float rightRadian = oldRadian - newRadian;
			if( rightRadian < 0) rightRadian += PI2;
		
			// Default turn right
			turnRight = true;
			float difRadian = rightRadian;

			// If left radian difference is smaller, turn left
			if( leftRadian < rightRadian)
			{
				difRadian = leftRadian;
				turnRight = false;
			}

			return difRadian;
		}

		/// <summary>
		/// Face a WoW_Object
		/// </summary>
		/// <param name="obj">The WoW_Object to face</param>
		public void Face( WoW_Object obj)
		{
			Face(obj.X, obj.Y);
		}

		/// <summary>
		/// Face a X / Y coordinate
		/// </summary>
		/// <param name="x">X coordinate</param>
		/// <param name="y">Y coordinate</param>
		public void Face( float x, float y)
		{
			//LogLine( "Face( {0:N}, {1:N})", x, y);
			if( globals.player == null)
				return;

			// Update player information
			globals.player.Update();

			// Calculate amount needed to turn
			bool turnRight = true;
			float difRadian = GetTurnRadian( x, y, false, out turnRight);
			float msTurn = difRadian / TurnSpeed;

			// This is as good as it gets
			if( msTurn < 10)
				return;

			// Time the movement in WoW
            TimedMovement( turnRight ? WoW_Movement.Right : WoW_Movement.Left, (int) msTurn);

			// Update player information
			globals.player.Update();
		}

		/// <summary>
		/// Face away from two objects
		/// </summary>
		/// <param name="one">First object</param>
		/// <param name="two">Second object</param>
		public void FaceAway( WoW_Object one, WoW_Object two)
		{
			if( globals.player == null)
				return;

			// Update player information
			globals.player.Update();

			//get radian to face object one and two
			float headingOne = globals.player.GetFaceRadian(one.X, one.Y);
			float headingTwo = globals.player.GetFaceRadian(two.X, two.Y);

			// Make sure both radians are between 0 - PI2
			while(headingOne < 0)   headingOne += PI2;
			while(headingOne > PI2) headingOne -= PI2;
			while(headingTwo < 0)   headingTwo += PI2;
			while(headingTwo > PI2) headingTwo -= PI2;

			//find the heading that would be right betwen the two
			float headingMiddle = 0;
			if(headingOne > headingTwo)
			{
				float diff = headingOne - headingTwo;
				headingMiddle = headingTwo + (diff / 2);
			}			
			else
			{
				float diff = headingTwo - headingOne;
				headingMiddle = headingOne + (diff / 2);
			}

			//now face away from that heading
			bool turnRight = true;
			float difRadian = GetTurnRadian( headingMiddle, true, out turnRight);
			float msTurn = difRadian / TurnSpeed;

			// This is as good as it gets
			if( msTurn < 10)
				return;

			// Time the movement in WoW
			TimedMovement( turnRight ? WoW_Movement.Right : WoW_Movement.Left, (int) msTurn);

			// Update player information
			globals.player.Update();

		}
		/// <summary>
		/// Face away from X / Y coordinate
		/// </summary>
		/// <param name="x">X coordinate</param>
		/// <param name="y">Y coordinate</param>
		public void FaceAway( float x, float y)
		{
			//LogLine( "Face( {0:N}, {1:N})", x, y);
			if( globals.player == null)
				return;

			// Update player information
			globals.player.Update();

			// Calculate amount needed to turn
			bool turnRight = true;
			float difRadian = GetTurnRadian( x, y, true, out turnRight);
			float msTurn = difRadian / TurnSpeed;

			// This is as good as it gets
			if( msTurn < 10)
				return;

			// Time the movement in WoW
			TimedMovement( turnRight ? WoW_Movement.Right : WoW_Movement.Left, (int) msTurn);

			// Update player information
			globals.player.Update();
		}

		/// <summary>
		///	Moves to object until within distance
		/// </summary>
		/// <param name="obj">object to run to</param>
		/// <param name="distance">stop/return if within distance</param>
		/// <param name="stoprunning">before exiting, stop running</param>
		/// <param name="stopondamage">stop running when the player is damaged</param>
		public void MoveTo( WoW_Object obj, float distance, bool stoprunning, bool stopondamage)
		{
			if( globals.player == null)
				return;

			// Update information
			obj.Update();
			globals.player.Update();

			// Get full distance to walk
			float distToWalk = globals.player.GetDistance( obj.X, obj.Y, obj.Z);

			// Already in range?
			if( distToWalk < distance)
			{
				// Make sure we stop
				if( stoprunning)
					StopMovement( WoW_Movement.Forward);

				// Just face to make sure
				Face( obj.X, obj.Y);
				return;
			}

			bool turnRight = true;
			float difRadian = GetTurnRadian( obj.X, obj.Y, false, out turnRight);

			float msTurn = 0;

			// Has to turn more then 90?
			if( difRadian > (Math.PI / 2))
			{	// Then face before we walk there
				Face( obj.X, obj.Y);

				globals.player.Update();
				obj.Update();

				difRadian = GetTurnRadian( obj.X, obj.Y, false, out turnRight);
			}

			msTurn = difRadian / TurnSpeed;
			
			StartMovement( WoW_Movement.Forward);
			
			int stuckCounter = 0;
			int unstuckCounter = 0;
			float lastX, lastY, lastZ;

			int lastStuck = (int) distToWalk;
			int lastHealth = globals.player.Health;
			while( (distToWalk > distance) && !globals.player.IsDead)
			{
				lastX = globals.player.X;
				lastY = globals.player.Y;
				lastZ = globals.player.Z;

				if( msTurn > 10)
				{
					if( (distToWalk-distance) < 1.6)
					{
						StopMovement( WoW_Movement.Forward);
						Face( obj.X, obj.Y);
						StartMovement( WoW_Movement.Forward);
					}
					else
						Face( obj.X, obj.Y);
				} 
				else
				{
					Thread.Sleep( 100);

					// Update variables
					globals.player.Update();
					obj.Update();

					float distanceWalked = globals.player.GetDistance( lastX, lastY, lastZ);

					// If speed is below 50% of what it should be, we're obviously not running 'full speed'
					// and as such, we see this as 'stuck' (Speed / 10 == what we should have moved)
					// (100% == 1s, we're doing 100ms, so 10%, 50% of that is * 0.05)
					if( distanceWalked < (globals.player.Speed * 0.05) || globals.player.Speed == 0)
					{
						// Make sure we're actually still walking
						StartMovement( WoW_Movement.Forward);

						unstuckCounter = 0;
						stuckCounter ++;
						if( stuckCounter == 5)
							TimedMovement( WoW_Movement.StrafeLeft, 500);

						if( stuckCounter == 15)
							TimedMovement( WoW_Movement.StrafeRight, 500);
					
						if( stuckCounter == 25)
						{
							//calculate time to turn 90 degrees
							msTurn = (float) (Math.PI / 2) / TurnSpeed;
							//stop
							StopMovement(WoW_Movement.Forward);
							//turn around
							FaceAway( obj.X, obj.Y);
							//run back a little
							TimedMovement(WoW_Movement.Forward,500);
							//as we run turn RIGHT 90 degrees
							TimedMovement(WoW_Movement.Right, (int)msTurn);
							//move this direction sideways to our target
							TimedMovement(WoW_Movement.Forward, 1500);
							//face target again
							Face( obj.X, obj.Y);
							//start running again
							StartMovement(WoW_Movement.Forward);
						}

						if( stuckCounter == 35)
						{
							// Sorry but this has gone too far, stop running and exit
							stoprunning = true;
							break;
						}
					}
					else
					{
						unstuckCounter ++;
						if( unstuckCounter > 5)
							stuckCounter = 0;
					}
				}

				// Update variables
				globals.player.Update();
				obj.Update();

				distToWalk = globals.player.GetDistance( obj.X, obj.Y, obj.Z);
				difRadian = GetTurnRadian( obj.X, obj.Y, false, out turnRight);
				msTurn = difRadian / TurnSpeed;

				// Check if we have lost HP, if so, stop running
				if( stopondamage && lastHealth > globals.player.Health)
					break;

				lastHealth = globals.player.Health;
			}

			Face( obj.X, obj.Y);
			if( stoprunning)
				StopMovement( WoW_Movement.Forward);
		}

		/// <summary>
		///	Moves to position x,y,z until within distance
		/// </summary>
		/// <param name="x">x</param>
		/// <param name="y">y</param>
		/// <param name="z">z</param>
		/// <param name="distance">stop/return if within distance</param>
		/// <param name="stoprunning">before exiting, stop running</param>
		/// <param name="stopondamage">stop running when the player is damaged</param>
		public void MoveTo( float x, float y, float z, float distance, bool stoprunning, bool stopondamage)
		{
			//LogLine( "MoveTo( {0:N}, {1:N}, {2:N}, {3:N}, {4}, {5})", x, y, z, distance, stoprunning, stopondamage);
			if( globals.player == null)
				return;

			// Update player information
			globals.player.Update();

			// Get full distance to walk
			float distToWalk = globals.player.GetDistance( x, y, z);

			// Already in range?
			if( distToWalk < distance)
			{
				// Make sure we stop
				if( stoprunning)
					StopMovement( WoW_Movement.Forward);

				// Just face to make sure
				Face( x, y);
				return;
			}

			bool turnRight = true;
			float difRadian = GetTurnRadian( x, y, false, out turnRight);

			float msTurn = 0;

			// Has to turn more then 90?
			if( difRadian > (Math.PI / 2))
			{	// Then face before we walk there
				Face( x, y);

				globals.player.Update();
				difRadian = GetTurnRadian( x, y, false, out turnRight);
			}

			msTurn = difRadian / TurnSpeed;
			
			StartMovement( WoW_Movement.Forward);
			
			int stuckCounter = 0;
			int unstuckCounter = 0;
			float lastX, lastY, lastZ;

			int lastHealth = globals.player.Health;
			while( (distToWalk > distance) && !globals.player.IsDead)
			{
				lastX = globals.player.X;
				lastY = globals.player.Y;
				lastZ = globals.player.Z;

				if( msTurn > 10)
				{
					if( (distToWalk-distance) < 1.6)
					{
						StopMovement( WoW_Movement.Forward);
						Face( x, y);
						StartMovement( WoW_Movement.Forward);
					}
					else
						Face( x, y);
				} 
				else
				{
					Thread.Sleep( 100);

					// Update variables
					globals.player.Update();

					float distanceWalked = globals.player.GetDistance( lastX, lastY, lastZ);

					// If speed is below 50% of what it should be, we're obviously not running 'full speed'
					// and as such, we see this as 'stuck' (Speed / 10 == what we should have moved)
					// (100% == 1s, we're doing 100ms, so 10%, 50% of that is * 0.05)
					if( distanceWalked < (globals.player.Speed * 0.05) || globals.player.Speed == 0)
					{
						// Make sure we're actually still walking
						StartMovement( WoW_Movement.Forward);

						unstuckCounter = 0;
						stuckCounter ++;
						if( stuckCounter == 5)
							TimedMovement( WoW_Movement.StrafeLeft, 500);

						if( stuckCounter == 15)
							TimedMovement( WoW_Movement.StrafeRight, 500);
					
						if( stuckCounter == 25)
						{
							//calculate time to turn 90 degrees
							msTurn = (float) (Math.PI / 2) / TurnSpeed;
							//stop
							StopMovement(WoW_Movement.Forward);
							//turn around
							FaceAway( x, y);
							//run back a little
							TimedMovement(WoW_Movement.Forward,500);
							//as we run turn RIGHT 90 degrees
							TimedMovement(WoW_Movement.Right, (int)msTurn);
							//move this direction sideways to our target
							TimedMovement(WoW_Movement.Forward, 1500);
							//face target again
							Face( x, y);
							//start running again
							StartMovement(WoW_Movement.Forward);
						}

						if( stuckCounter == 35)
						{
							// Sorry but this has gone too far, stop running and exit
							stoprunning = true;
							break;
						}
					}
					else
					{
						unstuckCounter ++;
						if( unstuckCounter > 5)
							stuckCounter = 0;
					}
				}

				// Update variables
				globals.player.Update();
				distToWalk = globals.player.GetDistance( x, y, z);

				difRadian = GetTurnRadian( x, y, false, out turnRight);
				msTurn = difRadian / TurnSpeed;

				// Check if we have lost HP, if so, stop running
				if( stopondamage && lastHealth > globals.player.Health)
					break;

				lastHealth = globals.player.Health;
			}

			Face( x, y);
			if( stoprunning)
				StopMovement( WoW_Movement.Forward);
		}
#endif
		#endregion

		#region WoW!Sharp's passive functions
		/// <summary>
		/// Returns the reaction between two units (WoW Objects of type 3 or 4)
		/// </summary>
		/// <param name="unit1">Unit One</param>
		/// <param name="unit2">Unit Two</param>
		/// <returns>-1 for invalid unit1, -2 for invalid unit2, 0-6 hostile-friendly</returns>
		public int GetUnitReaction( WoW_Object unit1, WoW_Object unit2)
		{
			if( unit1.Type != WoW_ObjectTypes.Unit && unit1.Type != WoW_ObjectTypes.Player)
				return -1;

			if( unit2.Type != WoW_ObjectTypes.Unit && unit2.Type != WoW_ObjectTypes.Player)
				return -2;

			int ptr1 = unit1.GetUnitFactionGroupRow();
			int ptr2 = unit2.GetUnitFactionGroupRow();

			// This part is almost a direct copy of the function from WoW at sub_6043E0 (v1.2.4)
			// It *might* not work correctly on mobs with a reputation or on players
			if( (memory.ReadInteger( ptr1 + 0xC) &	memory.ReadInteger( ptr2 + 0x14)) != 0)
				return 1;

			int ptr3 = ptr2 + 0x18;
			for( int i = 0; i < 4; i ++)
			{
				if( memory.ReadInteger( ptr3) == 0)
					break;

				if( memory.ReadInteger( ptr3) == memory.ReadInteger( ptr1 + 0x4))
					return 1;

				ptr3 += 4;
			}

			if((memory.ReadInteger( ptr1 + 0xC) & memory.ReadInteger( ptr2 + 0x10)) != 0)
				return 4;

			ptr3 = ptr2 + 0x28;
			for( int i = 0; i < 4; i ++)
			{
				if( memory.ReadInteger( ptr3) == 0)
					break;

				if( memory.ReadInteger( ptr3) == memory.ReadInteger( ptr1 + 0x4))
					return 4;

				ptr3 += 4;
			}

			if((memory.ReadInteger( ptr2 + 0xC) & memory.ReadInteger( ptr1 + 0x14)) != 0)
				return 4;

			ptr3 = ptr1 + 0x28;
			for( int i = 0; i < 4; i ++)
			{
				if( memory.ReadInteger( ptr3) == 0)
					break;

				if( memory.ReadInteger( ptr3) == memory.ReadInteger( ptr2 + 0x4))
					return 4;

				ptr3 += 4;
			}

			return 3;
		}


		/// <summary>
		/// Hashtable that has all the WoW_Object's by ID
		/// </summary>
		public Hashtable Objects
		{
			get
			{
				return objsById;
			}
		}

		/// <summary>
		/// Returns all the objects within the maxDistance of the supplied object
		/// </summary>
		/// <param name="center">Center object</param>
		/// <param name="maxDistance">maxDistance</param>
		/// <param name="objType">Object type, WoW_ObjectTypes.Unkown for all</param>
		/// <returns>Arraylist (sorted by range)</returns>
		/// <remarks>
		/// The array list contains WoW_Distance objects, NOT WoW_Objects
		/// </remarks>
		public ArrayList GetNearest( WoW_Object center, int maxDistance, WoW_ObjectTypes objType)
		{
			return GetNearest( center.X, center.Y, center.Z, maxDistance, objType);
		}

		/// <summary>
		/// Returns all the objects within the maxDistance of the supplied coordinates
		/// </summary>
		/// <param name="X">X</param>
		/// <param name="Y">Y</param>
		/// <param name="Z">Z</param>
		/// <param name="maxDistance">maxDistance</param>
		/// <param name="objType">Object type, WoW_ObjectTypes.Unkown for all</param>
		/// <returns>Arraylist (sorted by range)</returns>
		/// <remarks>
		/// The array list contains WoW_Distance objects, NOT WoW_Objects
		/// </remarks>
		public ArrayList GetNearest( float X, float Y, float Z, int maxDistance, WoW_ObjectTypes objType)
		{
			ArrayList unsorted = new ArrayList();
			if( !hasStarted)
				return null;

			foreach( WoW_Object obj in objsById.Values)
			{
				float distance = obj.GetDistance( X, Y, Z);
				if( distance < (float) maxDistance && obj.X != X && obj.Y != Y && (objType == WoW_ObjectTypes.Unknown || objType == obj.Type))
					unsorted.Add( new WoW_Distance( distance, obj));
			}

			unsorted.Sort();
			return unsorted;
		}

		/// <summary>
		/// WoW_Object that always points to the current player.
		/// Unless there is no current player, then its null
		/// </summary>
		public WoW_Object Player
		{
			get
			{
				return globals.player;
			}
		}

		/// <summary>
		/// Returns true if there's a corpse
		/// </summary>
		public bool HasCorpse
		{
			get
			{
				return Memory.ReadInteger( pointers.getPointer("s_corpsePosition")) != 0;
			}
		}

		/// <summary>
		/// Returns the Y position of the players corpse
		/// </summary>
		public float CorpseY
		{
			get
			{
				return Memory.ReadFloat( pointers.getPointer("s_corpsePosition"));
			}
		}

		/// <summary>
		/// Returns the X position of the players corpse
		/// </summary>
		public float CorpseX
		{
			get
			{
				return Memory.ReadFloat( pointers.getPointer("s_corpsePosition") + 4);
			}
		}

		/// <summary>
		/// Returns the Z position of the players corpse
		/// </summary>
		public float CorpseZ
		{
			get
			{
				return Memory.ReadFloat( pointers.getPointer("s_corpsePosition") + 8);
			}
		}

		/// <summary>
		/// WoW_Object that always points to the current target.
		/// Unless there is no current target, then its null
		/// </summary>
		public WoW_Object Target
		{
			get
			{
				return (WoW_Object) objsById[memory.ReadLong( pointers.getPointer("CGGameUI__m_lockedTarget"))];
				//return globals.target;
			}
		}


		/// <summary>
		/// Returns the number of attackers attacking the player
		/// </summary>
		public int NumberOfAttackers
		{
			get
			{
				return numberOfAttackers;
			}
		}


		/// <summary>
		/// Returns the attackers, ordered by distance from the player
		/// </summary>
		/// <remarks>
		/// The objects in this array list are WoW_Distance objects
		/// </remarks>
		public ArrayList AttackersByDistance
		{
			get
			{
				return attackersByDistance;
			}
		}


		/// <summary>
		/// On which continent are we currently?
		/// </summary>
		/// <remarks>
		/// A 'bug' in WoW sometimes makes this value lag behind.
		/// </remarks>
		public int CurrentContinent
		{
			get
			{
				return memory.ReadInteger( pointers.getPointer( "CGWorldMap__m_currentContinent"));
			}
		}

		/// <summary>
		/// The Buffs class contains all the needed info to read out which
		/// buffs your character has.
		/// </summary>
		public WoW_Buffs Buffs
		{
			get
			{
				return buffs;
			}
		}

		/// <summary>
		/// Contains all the loot (if any)
		/// </summary>
		public WoW_Loot Loot
		{
			get
			{
				return loot;
			}
		}

		/// <summary>
		/// Return the game path of WoW
		/// </summary>
		public string GamePath
		{
			get
			{
				if( !memory.IsOpen)
					return null;

				foreach( ProcessModule m in memory.ReadProcess.Modules)
				{
					if( m.ModuleName.ToLower() == "wow.exe")
						return Path.GetDirectoryName( m.FileName);
				}

				return null;
			}
		}

	
		/// <summary>
		/// Makes WoW the active application
		/// </summary>
		public void ActivateGame()
		{
			if( memory.IsOpen)
				Microsoft.VisualBasic.Interaction.AppActivate( memory.ReadProcess.Id);
			else
				Microsoft.VisualBasic.Interaction.AppActivate( "World of Warcraft");
		}

		
		/// <summary>
		/// Returns the spell name for a given Id
		/// </summary>
		/// <param name="spellid">Spell Id</param>
		/// <param name="includerank">Include spell rank? (Rank 1)</param>
		/// <returns>Spell name</returns>
		public string GetSpellName( int spellid, bool includerank)
		{
			int Language = memory.ReadInteger( pointers.getPointer( "WOW_LOCALE_CURRENT_LANGUAGE"));

			int rows = memory.ReadInteger( pointers.getPointer( "g_SpellDB"));
			int nRows = memory.ReadInteger( pointers.getPointer( "g_SpellDBTotalRows"));

			if( spellid <= 0 || spellid > nRows)
				return "";

			int row = memory.ReadInteger( rows + spellid * 4);

			int fieldName = memory.ReadInteger( row + Language*4 + offsets.getOffset("spellDB_spellName") * 4);
			string spellName = memory.ReadString( fieldName, 128);

			if( includerank)
			{
				// Field 0x79 == Spell Rank
				int fieldRank = memory.ReadInteger( row + Language*4 + offsets.getOffset("spellDB_spellRank") * 4);

				string spellRank = memory.ReadString( fieldRank, 128);
				if( spellRank != "")
					spellName += "(" + spellRank + ")";
			}

			return spellName;
		}


		/// <summary>
		/// Returns a list of known spells that are found in the knownList
		/// </summary>
		/// <param name="knownList">Pointer the list with known spells</param>
		/// <param name="highest">Only return the highest level?</param>
		/// <returns>Hashtable with spell names and id's</returns>
		private Hashtable GetSpells( int knownList, bool highest)
		{
			Hashtable spells = new Hashtable();
			
			for( int i = 0; i < 0x400; i ++)
			{
				int spellId = memory.ReadInteger( knownList + i * 4);
				string spellName = GetSpellName( spellId, !highest);

				if( spellName == "")
					continue;

				if( spells.ContainsKey( spellName))
					spells[ spellName] = spellId;
				else
					spells.Add( spellName, spellId);
			}

			return spells;
		}

		/// <summary>
		/// Returns an Hashtable with all the known spells
		/// Where the key is "[spell name]([rank])" and the value is the spell ID
		/// </summary>
		/// <returns>Hashtable</returns>
		public Hashtable KnownSpells
		{
			get
			{
				if( knownSpells == null)
					knownSpells = GetSpells(pointers.getPointer( "CGSpellBook__m_knownSpells"), false);

				return knownSpells;
			}
		}

		/// <summary>
		/// Returns an Hashtable with all the known pet spells
		/// Where the key is "[spell name]([rank])" and the value is the spell ID
		/// </summary>
		/// <returns>Hashtable</returns>
		public Hashtable KnownPetSpells
		{
			get
			{
				if( knownPetSpells == null)
					knownPetSpells = GetSpells(pointers.getPointer( "CGSpellBook__m_petSpells"), false);

				return knownPetSpells;
			}
		}

		/// <summary>
		/// Returns an Hashtable with all the highest known spells
		/// </summary>
		/// <returns>Hashtable</returns>
		public Hashtable HighestKnownSpells
		{
			get
			{
				if( highestKnownSpells == null)
					highestKnownSpells = GetSpells(pointers.getPointer( "CGSpellBook__m_knownSpells"), true);

				return highestKnownSpells;
			}
		}

		/// <summary>
		/// Returns an Hashtable with all the highest known pet spells
		/// </summary>
		/// <returns>Hashtable</returns>
		public Hashtable HighestKnownPetSpells
		{
			get
			{
				if( highestKnownPetSpells == null)
					highestKnownPetSpells = GetSpells(pointers.getPointer( "CGSpellBook__m_petSpells"), true);

				return highestKnownPetSpells;
			}
		}

		/// <summary>
		/// Returns all the known spell names
		/// </summary>
		/// <param name="withrank">Include rank?</param>
		/// <returns>List of spellnames</returns>
		public ArrayList GetKnownSpellNames( bool withrank)
		{
			ArrayList names = new ArrayList();
			Hashtable spells;

			if( withrank)
				spells = KnownSpells;
			else
				spells = HighestKnownSpells;

			foreach( string key in spells.Keys)
				names.Add(key);

			return names;
		}

		/// <summary>
		/// Returns all the known pet spell names
		/// </summary>
		/// <param name="withrank">Include rank?</param>
		/// <returns>List of pet spellnames</returns>
		public ArrayList GetKnownPetSpellNames( bool withrank)
		{
			ArrayList names = new ArrayList();
			Hashtable spells;

			if( withrank)
				spells = KnownPetSpells;
			else
				spells = HighestKnownPetSpells;

			foreach( string key in spells.Keys)
				names.Add(key);

			return names;
		}

		/// <summary>
		/// Returns an array list with all the party members
		/// </summary>
		public ArrayList PartyMembers
		{
			get
			{
				return partyMembers;
			}
		}

		/// <summary>
		/// Returns the party leader
		/// </summary>
		public WoW_Object PartyLeader
		{
			get
			{
				return partyLeader;
			}
		}

		/// <summary>
		/// Inventory class, contains all the functions/properties
		/// to manipulate the Inventory
		/// </summary>
		public WoW_Inventory Inventory
		{
			get
			{
				return inventory;
			}
		}

		/// <summary>
		/// Contains all the descriptors for all the unit types
		/// </summary>
		public WoW_Descriptors Descriptors
		{
			get
			{
				return descriptors;
			}
		}

		/// <summary>
		/// Returns the last red message
		/// </summary>
		/// <returns>The last red message</returns>
		/// <remarks>
		/// This function resets the red message, so this is a semi-active function!
		/// </remarks>
		public string GetRedMessage()
		{
			string msg = memory.ReadString( pointers.getPointer("CGGameUI__s_lastErrorString"), 128);
			if( msg != "You are Dead" && msg != "") //test message to let us know if a new string was written by the game
			{
				memory.WriteString( pointers.getPointer("CGGameUI__s_lastErrorString"), "You are Dead");
				return msg;
			}

			return "";
		}

		/// <summary>
		/// This function returns the difficulty of the given unit
		/// </summary>
		/// <param name="unit">Unit to test</param>
		/// <returns>
		/// -1 for invalid player object
		/// 0 for gray unit
		/// 1 for green unit
		/// 2 for yellow unit
		/// 3 for orange unit
		/// 4 for red unit 
		/// </returns>
		public int GetDifficulty( WoW_Object unit)
		{
			int [] greenLevelRange = {0x4, 0x4, 0x5, 0x5, 0x6, 0x6, 0x7, 0x7, 0x8, 0x9, 0xA, 0xB, 0xC, 0xC, 0xC, 0xC, 0xC, 0xC, 0xC, 0xC};
			
			//int greenSelect = globals.player.Level / 3;
			long greenSelect = ((long) globals.player.Level * (long) 0x66666667) >> 33;
			if( greenSelect >= greenLevelRange.Length)
				greenSelect = greenLevelRange.Length - 1;

			int levelDiff = unit.Level - globals.player.Level;

			if( levelDiff >= 5)
				return 4;

			if( levelDiff >= 3)
				return 3;

			if( levelDiff >= -2)
				return 2;

			if( -levelDiff <= greenLevelRange[greenSelect])
				return 1;

			return 0;
		}
		#endregion

		/// <summary>
		/// Add a formated string to the WoW!Sharp debuglog
		/// </summary>
		/// <param name="sFormat">Format</param>
		/// <param name="args">Arguments</param>
		public void LogLine(string sFormat, params object[] args)
		{
			System.IO.StringWriter sw = new System.IO.StringWriter();
			sw.Write(sFormat, args);
			string sText = sw.ToString();
			
			LogLine(sText);
		}
		

		/// <summary>
		/// Add a string to the WoW!Sharp debuglog
		/// </summary>
		/// <param name="line">String</param>
		public void LogLine( string line)
		{
			line = DateTime.Now + "|" + line;
			Trace.WriteLineIf( debuglogEnabled, line);
			if( OnLogLine != null)
				OnLogLine( this, line);

			if( debuglog != null)
			{
				debuglog.LogLine( line);
			}
			else
			{
				WoW_LogEngine log = new WoW_LogEngine("debug.log");
				log.Enabled = debuglogEnabled;
				log.LogLine( line);
				log.Dispose();
			}
		}


		/// <summary>
		/// Username
		/// </summary>
		public string Username
		{
			get
			{
				return username;
			}
			set
			{
				username = value;
			}
		}


		/// <summary>
		/// Password
		/// </summary>
		public string Password
		{
			get
			{
				return password;
			}
			set
			{
				password = value;
			}
		}


		/// <summary>
		/// Optional application
		/// </summary>
		public string Application
		{
			get
			{
				return application;
			}
			set
			{
				application = value;
			}
		}
	}
}
