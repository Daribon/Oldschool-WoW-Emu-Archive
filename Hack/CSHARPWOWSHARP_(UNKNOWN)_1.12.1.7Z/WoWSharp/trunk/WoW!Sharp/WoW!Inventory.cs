//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Collections;

namespace WoW_Sharp
{
	/// <summary>
	/// Summary description for WoW_Inventory.
	/// </summary>
	public class WoW_Inventory
	{
		private WoW owner;
		private int nBags = 5;

		private WoW_InventoryBag [] bags;
		private Hashtable slotnames;
        
		internal WoW_Inventory( WoW owner)
		{
			this.owner = owner;

			bags = new WoW_InventoryBag[ nBags];
			for( int b = 0; b < nBags; b ++)
				bags[b] = null;
		}

		/// <summary>
		/// Updates the inventory class
		/// </summary>
		internal void Update()
		{
			// No player object probably means the game isnt loaded
			if( owner.Player == null)
			{
				// Empty all bags
				for( int b = 0; b < nBags; b ++)
					bags[b] = null;

				return;
			}

			if( slotnames == null)
			{
				slotnames = new Hashtable();

				int cnt = owner.Memory.ReadInteger(owner.pointers.getPointer("g_slotNamesCount"));
				int ptr = owner.Memory.ReadInteger(owner.pointers.getPointer("g_slotNames"));
				for( int i = 0; i < cnt; i ++)
				{
					int slotnameptr = owner.Memory.ReadInteger( ptr + i * 0x10);
					string slotname = owner.Memory.ReadString( slotnameptr, 64);
					int slotid = owner.Memory.ReadInteger( ptr + i * 0x10 + 8);

					slotnames.Add( slotname, slotid);
				}
			}

			// Check if the first bag isnt initialized, or if player changed
			if( bags[0] == null || bags[0].Container != owner.Player)
				bags[0] = new WoW_InventoryBag( owner, owner.Player);
			bags[0].Update();

			// Loop through all the bags
			for( int b = 1; b < nBags; b ++)
			{
				// Get the bag guid field
				int bagField = owner.Descriptors[ WoW_ObjectTypes.Player, "PLAYER_FIELD_INV_SLOT_HEAD"] + 18 * 8 + b * 8;
				long bagGuid = owner.Player.ReadStorageLong( bagField);
				if( bagGuid == 0)
				{
					// No bag
					bags[b] = null;
					continue;
				}

				// Get the bag from object hash
				WoW_Object bag = (WoW_Object) owner.Objects[bagGuid];
				if( bag == null)
				{
					// Couldnt be found
					bags[b] = null;
					continue;
				}

				// Check if the bag changed
				if( bags[b] == null || bags[b].Container != bag)
					bags[b] = new WoW_InventoryBag( owner, bag);

				// Update the bag
				bags[b].Update();
			}
		}

		/// <summary>
		/// Returns the item which is equiped at the given slotname
		/// </summary>
		/// <param name="slotname">slotname</param>
		/// <returns>Item, null if not present</returns>
		public WoW_Object GetInventoryItem( string slotname)
		{
			if( slotnames == null || !slotnames.ContainsKey( slotname))
				return null;

			if( owner.Player == null)
				return null;

            int slotid = (int) slotnames[ slotname] - 1;
			if( slotid == -1) // AmmoSlot
				return null;

			int field = owner.Descriptors[ WoW_ObjectTypes.Player, "PLAYER_FIELD_INV_SLOT_HEAD"];
			long Guid = owner.Player.ReadStorageLong( field + slotid * 8);
			return (WoW_Object) owner.Objects[Guid];
		}

		/// <summary>
		/// Returns a bag
		/// </summary>
		public WoW_InventoryBag this[int bag]
		{
			get
			{
				if( bag < 0 || bag >= nBags)
					return null;

				return bags[bag];
			}
		}

		/// <summary>
		/// Returns an item in a bag
		/// </summary>
		public WoW_Object this[int bag, int slot]
		{
			get
			{
				if( bag < 0 || bag >= nBags)
					return null;

				if( bags[bag] == null)
					return null;

				return bags[bag][slot];
			}
		}

		/// <summary>
		/// Retrieves the first slot of an item with the given name
		/// </summary>
		public WoW_Object this[ string name]
		{
			get
			{
				if( name == null || name == "")
					return null;

				for( int b = 0; b < nBags; b ++)
				{
					if( bags[b] == null)
						continue;

					int slot = bags[b][name];
					if( slot != -1)
						return bags[b][slot];
				}

				return null;
			}
		}

		/// <summary>
		/// Get a string like "(2,5)" suitable for passing to lua.
		/// </summary>
		/// <param name="name">The name of the item to find</param>
		private string GetUseString(string name)
		{
			for( int b = 0; b < nBags; b ++)
			{
				if( bags[b] == null)
					continue;

				int slot = bags[b][name];
				if( slot != -1)
					return string.Format("({0},{1})", b, slot+1);
			}

			return "";
		}

#if !NoHider
		/// <summary>
		/// Use an inventory item by name
		/// </summary>
		/// <param name="name">Name of the item to use</param>
		/// <returns>Used the item?</returns>
		public bool UseItem( string name)
		{
			string use = GetUseString( name);
			string script = "UseContainerItem" + use;

			if( use == "")
				return false;

			owner.LogLine( "Executing script: " + script);
			WoW_Execute.ScriptExecute( script);

			return true;
		}

		/// <summary>
		/// Picks up an inventory item (e.g. equiped item)
		/// </summary>
		/// <param name="slotname">Slotname, e.g. MainHandSlot</param>
		public void PickupInventoryItem( string slotname)
		{
			if( slotnames == null || !slotnames.ContainsKey( slotname))
				return;

			if( owner.Player == null)
				return;

			int slotid = (int) slotnames[ slotname];
			WoW_Execute.ScriptExecute( string.Format("PickupInventoryItem({0})", slotid));
		}
#endif

		/// <summary>
		/// Returns the amount of items in the inventory
		/// </summary>
		/// <param name="name">Name of the item</param>
		/// <returns>Amount</returns>
		public int StackCount( string name)
		{
			int count = 0;
			if( name == null || name == "")
				return count;

			for( int b = 0; b < nBags; b ++)
			{
				if( bags[b] == null)
					continue;

				for( int s = 0; s < bags[b].Count; s ++)
				{
					if( bags[b][s] == null || bags[b][s].Name != name)
						continue;

					count += bags[b][s].StackCount;
				}
			}

			return count;
		}

		/// <summary>
		/// Returns the number of bags
		/// </summary>
		public int Count
		{
			get
			{
				return nBags;
			}
		}

		/// <summary>
		/// Returns all the items in the players inventory
		/// </summary>
		/// <returns>Array list of all the items</returns>
		public ArrayList GetAllItems()
		{
			ArrayList items = new ArrayList();

			for( int b = 0; b < nBags; b ++)
			{
				if( bags[b] == null)
					continue;

				for( int i = 0; i < bags[b].Count; i ++)
					if( bags[b][i] != null)
						items.Add( bags[b][i]);
			}

			return items;
		}

		/// <summary>
		/// This finds an item by id within your inventory
		/// </summary>
		/// <param name="itemid">Item Id</param>
		/// <returns>The first item with that Id, or null</returns>
		public WoW_Object GetItemById( int itemid)
		{
			for( int b = 0; b < Count; b ++)
			{
				if( bags[b] == null)
					continue;

				for( int i = 0; i < bags[b].Count; i ++)
				{
					WoW_Object item = bags[b][i];
					if( item != null && item.ItemId == itemid)
						return item;
				}
			}

			return null;
		}
	}
}
