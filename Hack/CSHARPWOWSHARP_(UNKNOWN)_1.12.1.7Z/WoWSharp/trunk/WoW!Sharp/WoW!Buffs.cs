//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;

namespace WoW_Sharp
{
	/// <summary>
	/// Contains all the buff handling stuff
	/// </summary>
	public class WoW_Buffs
	{
		private WoW owner;

		private int nBuffs = 0x38;
		private WoW_Buff [] buffs;

		/// <summary>
		/// Create the buffs collection
		/// </summary>
		/// <param name="owner">WoW owner</param>
		internal WoW_Buffs( WoW owner)
		{
			this.owner = owner;

			buffs = new WoW_Buff[nBuffs];
			for( int index = 0; index < nBuffs; index ++)
				buffs[index] = new WoW_Buff( owner, index);
		}

		/// <summary>
		/// Return a buff
		/// </summary>
		public WoW_Buff this[int index]
		{
			get
			{
				if( index < 0 || index >= nBuffs)
					return null;

				return buffs[index];
			}
		}

		/// <summary>
		/// Returns a specific buff (if present)
		/// </summary>
		/// <remarks>
		/// Should not include rank
		/// </remarks>
		public WoW_Buff this[string buffname]
		{
			get
			{
				for( int b = 0; b < nBuffs; b ++)
					if( buffs[b].SpellName == buffname)
						return buffs[b];

				return null;
			}
		}

		/// <summary>
		/// Number of buffs (they arent all active)
		/// </summary>
		public int Count
		{
			get
			{
				return nBuffs;
			}
		}
	}

	/// <summary>
	/// Represents each buff that a user can have
	/// </summary>
	public class WoW_Buff
	{
		private WoW owner;
		private int index;
		private int buffPtr;

		/// <summary>
		/// Create the buff
		/// </summary>
		/// <param name="owner">WoW owner</param>
		/// <param name="index">Index of the buff</param>
		internal WoW_Buff( WoW owner, int index)
		{
			this.owner = owner;
			this.index = index;

			this.buffPtr = owner.pointers.getPointer("CGBuffBar__m_buffs") + (index << 4);
		}

		/// <summary>
		/// Is the buff active?
		/// </summary>
		public bool Active
		{
			get
			{
				return owner.Memory.ReadInteger(buffPtr) != -1;
			}
		}

		/// <summary>
		/// Which spell id ?
		/// </summary>
		public int SpellId
		{
			get
			{
				return owner.Memory.ReadInteger(buffPtr + 4);
			}
		}

		/// <summary>
		/// Which spell name ?
		/// </summary>
		/// <remarks>
		/// The spell name is returned without rank
		/// </remarks>
		public string SpellName
		{
			get
			{
				if( !Active)
					return "";

				
				return owner.GetSpellName( SpellId, false);
			}
		}

#if !NoHider
		/// <summary>
		/// Get time left, in seconds. If its below 0, its a permanent buff.
		/// </summary>
		public int TimeLeft
		{
			get
			{
				int timerId = owner.Memory.ReadInteger(buffPtr);
				if( timerId == -1)
					return 0;

				int timePtr = owner.pointers.getPointer("CGBuffBar__m_durations") + timerId*4;
				int time = owner.Memory.ReadInteger(timePtr) - WoW_Execute.GetAsyncTimeMs();

				return time / 1000;
			}
		}
#endif
	}
}
