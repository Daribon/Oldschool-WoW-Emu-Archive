//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;

namespace WoW_Radar
{
	/// <summary>
	/// Summary description for frmOptions.
	/// </summary>
	public class frmOptions : System.Windows.Forms.Form
	{
		private ListViewItem lviSelected = null;
		private clsDisplayItem diSelected = null;
		private System.Windows.Forms.Panel panel1;
		private System.Windows.Forms.Button btnOK;
		private System.Windows.Forms.Button btnCancel;
		private System.Windows.Forms.TabControl tcOptions;
		private System.Windows.Forms.CheckBox cbxRotateMap;
		private System.Windows.Forms.TabPage tpGeneral;
		private System.Windows.Forms.TabPage tpHighlights;
		private System.Windows.Forms.TextBox tbPassword;
		private System.Windows.Forms.Label label1;
		private System.Windows.Forms.Label label2;
		private System.Windows.Forms.TextBox tbUsername;
		private System.Windows.Forms.Panel panel2;
		private System.Windows.Forms.CheckBox cbStayOnTop;
		private System.Windows.Forms.CheckBox cbShowMinimap;
		private System.Windows.Forms.Label label7;
		private System.Windows.Forms.NumericUpDown nudMinimapRadius;
		private System.Windows.Forms.Panel panel3;
		private SharpListView.SharpListView slvHighlights;
		private System.Windows.Forms.ColumnHeader chColor;
		private System.Windows.Forms.ColumnHeader chName;
		private System.Windows.Forms.ColumnHeader chDisplay;
		private System.Windows.Forms.ColumnHeader chVisible;
		private PJLControls.ColorPicker cpColor;
		private System.Windows.Forms.ComboBox cbVisible;
		private System.Windows.Forms.ComboBox cbDisplayText;
		private System.Windows.Forms.TextBox tbName;
		private System.Windows.Forms.Panel panel4;
		private System.Windows.Forms.Button btnAddHighlight;
		private System.Windows.Forms.Button btnDeleteHighlight;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmOptions()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();

			//
			// TODO: Add any constructor code after InitializeComponent call
			//
		}

		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if(components != null)
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmOptions));
			this.panel1 = new System.Windows.Forms.Panel();
			this.btnCancel = new System.Windows.Forms.Button();
			this.btnOK = new System.Windows.Forms.Button();
			this.tcOptions = new System.Windows.Forms.TabControl();
			this.tpGeneral = new System.Windows.Forms.TabPage();
			this.nudMinimapRadius = new System.Windows.Forms.NumericUpDown();
			this.label7 = new System.Windows.Forms.Label();
			this.cbShowMinimap = new System.Windows.Forms.CheckBox();
			this.cbStayOnTop = new System.Windows.Forms.CheckBox();
			this.panel2 = new System.Windows.Forms.Panel();
			this.tbPassword = new System.Windows.Forms.TextBox();
			this.label1 = new System.Windows.Forms.Label();
			this.label2 = new System.Windows.Forms.Label();
			this.tbUsername = new System.Windows.Forms.TextBox();
			this.cbxRotateMap = new System.Windows.Forms.CheckBox();
			this.tpHighlights = new System.Windows.Forms.TabPage();
			this.slvHighlights = new SharpListView.SharpListView();
			this.chColor = new System.Windows.Forms.ColumnHeader();
			this.chVisible = new System.Windows.Forms.ColumnHeader();
			this.chDisplay = new System.Windows.Forms.ColumnHeader();
			this.chName = new System.Windows.Forms.ColumnHeader();
			this.panel4 = new System.Windows.Forms.Panel();
			this.btnDeleteHighlight = new System.Windows.Forms.Button();
			this.btnAddHighlight = new System.Windows.Forms.Button();
			this.panel3 = new System.Windows.Forms.Panel();
			this.tbName = new System.Windows.Forms.TextBox();
			this.cbDisplayText = new System.Windows.Forms.ComboBox();
			this.cbVisible = new System.Windows.Forms.ComboBox();
			this.cpColor = new PJLControls.ColorPicker();
			this.panel1.SuspendLayout();
			this.tcOptions.SuspendLayout();
			this.tpGeneral.SuspendLayout();
			((System.ComponentModel.ISupportInitialize)(this.nudMinimapRadius)).BeginInit();
			this.tpHighlights.SuspendLayout();
			this.panel4.SuspendLayout();
			this.panel3.SuspendLayout();
			this.SuspendLayout();
			// 
			// panel1
			// 
			this.panel1.Controls.Add(this.btnCancel);
			this.panel1.Controls.Add(this.btnOK);
			this.panel1.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel1.Location = new System.Drawing.Point(0, 216);
			this.panel1.Name = "panel1";
			this.panel1.Size = new System.Drawing.Size(346, 32);
			this.panel1.TabIndex = 5;
			// 
			// btnCancel
			// 
			this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.Cancel;
			this.btnCancel.Location = new System.Drawing.Point(264, 5);
			this.btnCancel.Name = "btnCancel";
			this.btnCancel.TabIndex = 1;
			this.btnCancel.Text = "Cancel";
			// 
			// btnOK
			// 
			this.btnOK.DialogResult = System.Windows.Forms.DialogResult.OK;
			this.btnOK.Location = new System.Drawing.Point(184, 5);
			this.btnOK.Name = "btnOK";
			this.btnOK.TabIndex = 0;
			this.btnOK.Text = "OK";
			// 
			// tcOptions
			// 
			this.tcOptions.Controls.Add(this.tpGeneral);
			this.tcOptions.Controls.Add(this.tpHighlights);
			this.tcOptions.Dock = System.Windows.Forms.DockStyle.Fill;
			this.tcOptions.Location = new System.Drawing.Point(0, 0);
			this.tcOptions.Name = "tcOptions";
			this.tcOptions.SelectedIndex = 0;
			this.tcOptions.Size = new System.Drawing.Size(346, 216);
			this.tcOptions.TabIndex = 6;
			// 
			// tpGeneral
			// 
			this.tpGeneral.Controls.Add(this.nudMinimapRadius);
			this.tpGeneral.Controls.Add(this.label7);
			this.tpGeneral.Controls.Add(this.cbShowMinimap);
			this.tpGeneral.Controls.Add(this.cbStayOnTop);
			this.tpGeneral.Controls.Add(this.panel2);
			this.tpGeneral.Controls.Add(this.tbPassword);
			this.tpGeneral.Controls.Add(this.label1);
			this.tpGeneral.Controls.Add(this.label2);
			this.tpGeneral.Controls.Add(this.tbUsername);
			this.tpGeneral.Controls.Add(this.cbxRotateMap);
			this.tpGeneral.Location = new System.Drawing.Point(4, 22);
			this.tpGeneral.Name = "tpGeneral";
			this.tpGeneral.Size = new System.Drawing.Size(338, 190);
			this.tpGeneral.TabIndex = 0;
			this.tpGeneral.Text = "General";
			// 
			// nudMinimapRadius
			// 
			this.nudMinimapRadius.Location = new System.Drawing.Point(112, 40);
			this.nudMinimapRadius.Name = "nudMinimapRadius";
			this.nudMinimapRadius.Size = new System.Drawing.Size(56, 20);
			this.nudMinimapRadius.TabIndex = 2;
			// 
			// label7
			// 
			this.label7.Location = new System.Drawing.Point(16, 40);
			this.label7.Name = "label7";
			this.label7.Size = new System.Drawing.Size(93, 20);
			this.label7.TabIndex = 33;
			this.label7.Text = "Minimap radius";
			this.label7.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// cbShowMinimap
			// 
			this.cbShowMinimap.Location = new System.Drawing.Point(-8, 24);
			this.cbShowMinimap.Name = "cbShowMinimap";
			this.cbShowMinimap.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.cbShowMinimap.Size = new System.Drawing.Size(134, 16);
			this.cbShowMinimap.TabIndex = 1;
			this.cbShowMinimap.Text = "Show minimap";
			// 
			// cbStayOnTop
			// 
			this.cbStayOnTop.Location = new System.Drawing.Point(32, 64);
			this.cbStayOnTop.Name = "cbStayOnTop";
			this.cbStayOnTop.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.cbStayOnTop.Size = new System.Drawing.Size(94, 16);
			this.cbStayOnTop.TabIndex = 3;
			this.cbStayOnTop.Text = "Stay on top";
			// 
			// panel2
			// 
			this.panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.panel2.Location = new System.Drawing.Point(0, 88);
			this.panel2.Name = "panel2";
			this.panel2.Size = new System.Drawing.Size(336, 4);
			this.panel2.TabIndex = 30;
			// 
			// tbPassword
			// 
			this.tbPassword.Location = new System.Drawing.Point(112, 128);
			this.tbPassword.Name = "tbPassword";
			this.tbPassword.PasswordChar = '*';
			this.tbPassword.Size = new System.Drawing.Size(136, 20);
			this.tbPassword.TabIndex = 5;
			this.tbPassword.Text = "";
			// 
			// label1
			// 
			this.label1.Location = new System.Drawing.Point(40, 104);
			this.label1.Name = "label1";
			this.label1.Size = new System.Drawing.Size(68, 20);
			this.label1.TabIndex = 26;
			this.label1.Text = "Username";
			this.label1.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// label2
			// 
			this.label2.Location = new System.Drawing.Point(40, 128);
			this.label2.Name = "label2";
			this.label2.Size = new System.Drawing.Size(68, 20);
			this.label2.TabIndex = 27;
			this.label2.Text = "Password";
			this.label2.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
			// 
			// tbUsername
			// 
			this.tbUsername.Location = new System.Drawing.Point(112, 104);
			this.tbUsername.Name = "tbUsername";
			this.tbUsername.Size = new System.Drawing.Size(136, 20);
			this.tbUsername.TabIndex = 4;
			this.tbUsername.Text = "";
			// 
			// cbxRotateMap
			// 
			this.cbxRotateMap.Location = new System.Drawing.Point(32, 8);
			this.cbxRotateMap.Name = "cbxRotateMap";
			this.cbxRotateMap.RightToLeft = System.Windows.Forms.RightToLeft.Yes;
			this.cbxRotateMap.Size = new System.Drawing.Size(94, 16);
			this.cbxRotateMap.TabIndex = 2;
			this.cbxRotateMap.Text = "Rotate Map";
			// 
			// tpHighlights
			// 
			this.tpHighlights.Controls.Add(this.slvHighlights);
			this.tpHighlights.Controls.Add(this.panel4);
			this.tpHighlights.Controls.Add(this.panel3);
			this.tpHighlights.Location = new System.Drawing.Point(4, 22);
			this.tpHighlights.Name = "tpHighlights";
			this.tpHighlights.Size = new System.Drawing.Size(338, 190);
			this.tpHighlights.TabIndex = 5;
			this.tpHighlights.Text = "Highlights";
			// 
			// slvHighlights
			// 
			this.slvHighlights.Columns.AddRange(new System.Windows.Forms.ColumnHeader[] {
																							this.chColor,
																							this.chVisible,
																							this.chDisplay,
																							this.chName});
			this.slvHighlights.Dock = System.Windows.Forms.DockStyle.Fill;
			this.slvHighlights.FullRowSelect = true;
			this.slvHighlights.HideSelection = false;
			this.slvHighlights.Location = new System.Drawing.Point(0, 32);
			this.slvHighlights.MultiSelect = false;
			this.slvHighlights.Name = "slvHighlights";
			this.slvHighlights.Size = new System.Drawing.Size(338, 134);
			this.slvHighlights.TabIndex = 2;
			this.slvHighlights.View = System.Windows.Forms.View.Details;
			this.slvHighlights.SelectedIndexChanged += new System.EventHandler(this.slvHighlights_SelectedIndexChanged);
			this.slvHighlights.SLVDrawItem += new SharpListView.SharpListView.DrawItemEventHandler(this.slvHighlights_SLVDrawItem);
			// 
			// chColor
			// 
			this.chColor.Text = "Color";
			this.chColor.Width = 41;
			// 
			// chVisible
			// 
			this.chVisible.Text = "Visible";
			this.chVisible.Width = 43;
			// 
			// chDisplay
			// 
			this.chDisplay.Text = "Display";
			this.chDisplay.Width = 98;
			// 
			// chName
			// 
			this.chName.Text = "Name";
			this.chName.Width = 135;
			// 
			// panel4
			// 
			this.panel4.Controls.Add(this.btnDeleteHighlight);
			this.panel4.Controls.Add(this.btnAddHighlight);
			this.panel4.Dock = System.Windows.Forms.DockStyle.Bottom;
			this.panel4.Location = new System.Drawing.Point(0, 166);
			this.panel4.Name = "panel4";
			this.panel4.Size = new System.Drawing.Size(338, 24);
			this.panel4.TabIndex = 3;
			// 
			// btnDeleteHighlight
			// 
			this.btnDeleteHighlight.Location = new System.Drawing.Point(200, 3);
			this.btnDeleteHighlight.Name = "btnDeleteHighlight";
			this.btnDeleteHighlight.Size = new System.Drawing.Size(136, 20);
			this.btnDeleteHighlight.TabIndex = 1;
			this.btnDeleteHighlight.Text = "Delete custom highlight";
			this.btnDeleteHighlight.Click += new System.EventHandler(this.btnDeleteHighlight_Click);
			// 
			// btnAddHighlight
			// 
			this.btnAddHighlight.Location = new System.Drawing.Point(2, 3);
			this.btnAddHighlight.Name = "btnAddHighlight";
			this.btnAddHighlight.Size = new System.Drawing.Size(136, 20);
			this.btnAddHighlight.TabIndex = 0;
			this.btnAddHighlight.Text = "Add custom highlight";
			this.btnAddHighlight.Click += new System.EventHandler(this.btnAddHighlight_Click);
			// 
			// panel3
			// 
			this.panel3.Controls.Add(this.tbName);
			this.panel3.Controls.Add(this.cbDisplayText);
			this.panel3.Controls.Add(this.cbVisible);
			this.panel3.Controls.Add(this.cpColor);
			this.panel3.Dock = System.Windows.Forms.DockStyle.Top;
			this.panel3.Location = new System.Drawing.Point(0, 0);
			this.panel3.Name = "panel3";
			this.panel3.Size = new System.Drawing.Size(338, 32);
			this.panel3.TabIndex = 1;
			// 
			// tbName
			// 
			this.tbName.Location = new System.Drawing.Point(184, 8);
			this.tbName.Name = "tbName";
			this.tbName.Size = new System.Drawing.Size(136, 20);
			this.tbName.TabIndex = 3;
			this.tbName.Text = "";
			this.tbName.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbName_KeyPress);
			this.tbName.TextChanged += new System.EventHandler(this.tbName_TextChanged);
			// 
			// cbDisplayText
			// 
			this.cbDisplayText.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbDisplayText.Items.AddRange(new object[] {
															   "Nothing",
															   "Name",
															   "Level",
															   "Name+Level",
															   "Race+Class",
															   "Race+Class+Level"});
			this.cbDisplayText.Location = new System.Drawing.Point(88, 8);
			this.cbDisplayText.Name = "cbDisplayText";
			this.cbDisplayText.Size = new System.Drawing.Size(96, 21);
			this.cbDisplayText.TabIndex = 2;
			this.cbDisplayText.SelectedIndexChanged += new System.EventHandler(this.cbDisplayText_SelectedIndexChanged);
			// 
			// cbVisible
			// 
			this.cbVisible.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList;
			this.cbVisible.Items.AddRange(new object[] {
														   "Yes",
														   "No"});
			this.cbVisible.Location = new System.Drawing.Point(40, 8);
			this.cbVisible.Name = "cbVisible";
			this.cbVisible.Size = new System.Drawing.Size(48, 21);
			this.cbVisible.TabIndex = 1;
			this.cbVisible.SelectedIndexChanged += new System.EventHandler(this.cbVisible_SelectedIndexChanged);
			// 
			// cpColor
			// 
			this.cpColor.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
			this.cpColor.Columns = 8;
			this.cpColor.DisplayColorWidth = 18;
			this.cpColor.Location = new System.Drawing.Point(0, 8);
			this.cpColor.Name = "cpColor";
			this.cpColor.Size = new System.Drawing.Size(40, 21);
			this.cpColor.TabIndex = 0;
			this.cpColor.ColorChanged += new PJLControls.ColorChangedEventHandler(this.cpColor_ColorChanged);
			// 
			// frmOptions
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.ClientSize = new System.Drawing.Size(346, 248);
			this.Controls.Add(this.tcOptions);
			this.Controls.Add(this.panel1);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedToolWindow;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.Name = "frmOptions";
			this.Text = "Options";
			this.panel1.ResumeLayout(false);
			this.tcOptions.ResumeLayout(false);
			this.tpGeneral.ResumeLayout(false);
			((System.ComponentModel.ISupportInitialize)(this.nudMinimapRadius)).EndInit();
			this.tpHighlights.ResumeLayout(false);
			this.panel4.ResumeLayout(false);
			this.panel3.ResumeLayout(false);
			this.ResumeLayout(false);

		}
		#endregion

		public void LoadSettings( clsSettings settings)
		{
			cbStayOnTop.Checked = settings.StayOnTop;

			cbxRotateMap.Checked = settings.RotateMap;
			cbShowMinimap.Checked = settings.ShowMinimap;
			nudMinimapRadius.Value = settings.MinimapRadius;

			tbUsername.Text = settings.Username;
			tbPassword.Text = settings.Password;

			for( int i = 0; i < settings.arrDisplayItems.Count; i ++)
			{
				clsDisplayItem di = (clsDisplayItem) settings.arrDisplayItems[i];

				ListViewItem item = new ListViewItem();
				item.Text = di.Color.ToString();
				item.SubItems.Add( di.Visible ? "Yes" : "No");
				switch( di.DisplayText)
				{
					case eDisplayText.Nothing:
						item.SubItems.Add( "Nothing");
						break;
					case eDisplayText.OnlyName:
						item.SubItems.Add( "Name");
						break;
					case eDisplayText.OnlyLevel:
						item.SubItems.Add( "Level");
						break;
					case eDisplayText.BothNameAndLevel:
						item.SubItems.Add( "Name+Level");
						break;
					case eDisplayText.RaceAndClass:
						item.SubItems.Add( "Race+Class");
						break;
					case eDisplayText.RaceAndClassAndLevel:
						item.SubItems.Add( "Race+Class+Level");
						break;
				}
				item.Tag = di.Clone();
				item.SubItems.Add( di.Name);

				slvHighlights.Items.Add( item);
			}

			slvHighlights_SelectedIndexChanged( null, null);
		}

		public void SaveSettings( clsSettings settings)
		{
			settings.StayOnTop = cbStayOnTop.Checked;

			settings.RotateMap = cbxRotateMap.Checked;
			settings.ShowMinimap = cbShowMinimap.Checked;
			settings.MinimapRadius = (int)nudMinimapRadius.Value;

			settings.Username = tbUsername.Text;
			settings.Password = tbPassword.Text;

			settings.arrDisplayItems.Clear();
			foreach( ListViewItem item in slvHighlights.Items)
				settings.arrDisplayItems.Add( item.Tag);
		}

		private void slvHighlights_SLVDrawItem(object sender, DrawItemEventArgs e)
		{
			if( e.Index >= slvHighlights.Items.Count) return;

			ListViewItem item;
			try
			{
				item = slvHighlights.Items[ e.Index];
			}
			catch
			{
				item = null;
			}

			if( item == null) return;

			if( item.Selected)
				e.Graphics.FillRectangle( Brushes.DarkBlue, e.Bounds);
			else
				e.Graphics.FillRectangle( slvHighlights.BkBrush, e.Bounds);

			SolidBrush br = new SolidBrush( Color.FromArgb( int.Parse( item.Text)));
			Rectangle r = new Rectangle( e.Bounds.X, e.Bounds.Y, chColor.Width, e.Bounds.Height);

			r.Inflate( -2, -2);
			ControlPaint.DrawBorder3D( e.Graphics, r, Border3DStyle.Flat, Border3DSide.All);

			r.Inflate( -1, -1);
			e.Graphics.FillRectangle( br, r);

			StringFormat s = new StringFormat();
			s.FormatFlags = StringFormatFlags.NoWrap;
			s.Trimming = StringTrimming.EllipsisCharacter;
			s.Alignment = StringAlignment.Near;

			Brush b;
			if( item.Selected)
				b = Brushes.White;
			else
				b = Brushes.Black;

			r = new Rectangle( e.Bounds.X + chColor.Width, e.Bounds.Y, chVisible.Width, e.Bounds.Height);
			e.Graphics.DrawString( item.SubItems[1].Text, slvHighlights.Font, b, r, s);

			r = new Rectangle( r.X + r.Width, r.Y, chDisplay.Width, r.Height);
			e.Graphics.DrawString( item.SubItems[2].Text, slvHighlights.Font, b, r, s);

			r = new Rectangle( r.X + r.Width, r.Y, chName.Width, r.Height);
			e.Graphics.DrawString( item.SubItems[3].Text, slvHighlights.Font, b, r, s);
		}

		private void slvHighlights_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( slvHighlights.SelectedItems.Count == 0)
			{
				cpColor.Enabled = false;
				cpColor.Color = Color.Black;

				cbVisible.Enabled = false;
				cbDisplayText.Enabled = false;

				tbName.Tag = 1;
				tbName.Text = "";
				tbName.Tag = 0;

				tbName.Enabled = false;

				btnDeleteHighlight.Enabled = false;

				diSelected = null;
				lviSelected = null;
				return;
			}

			cpColor.Enabled = true;
			cbVisible.Enabled = true;
			cbDisplayText.Enabled = true;

			clsDisplayItem di = (clsDisplayItem) slvHighlights.SelectedItems[0].Tag;
			
			cpColor.Color = Color.FromArgb( di.Color);
			cbVisible.SelectedIndex = di.Visible ? 0 : 1;
			cbDisplayText.SelectedIndex = (int) di.DisplayText;

			tbName.Tag = 1;
			tbName.Text = di.Name;
			tbName.Tag = 0;

			tbName.Enabled = !(di.Name.StartsWith("[") && di.Name.EndsWith("]"));
			btnDeleteHighlight.Enabled = tbName.Enabled;

			diSelected = di;
			lviSelected = slvHighlights.SelectedItems[0];
		}

		private void cpColor_ColorChanged(object sender, PJLControls.ColorChangedEventArgs e)
		{
			if( diSelected != null)
			{
				diSelected.Color = cpColor.Color.ToArgb();
				lviSelected.SubItems[0].Text = diSelected.Color.ToString();
			}
		}

		private void cbVisible_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( diSelected != null)
			{
				diSelected.Visible = cbVisible.SelectedIndex == 0;
				lviSelected.SubItems[1].Text = diSelected.Visible ? "Yes" : "No";
			}		
		}

		private void cbDisplayText_SelectedIndexChanged(object sender, System.EventArgs e)
		{
			if( diSelected != null)
			{
				diSelected.DisplayText = (eDisplayText) cbDisplayText.SelectedIndex;
				switch( diSelected.DisplayText)
				{
					case eDisplayText.Nothing:
						lviSelected.SubItems[2].Text = "Nothing";
						break;
					case eDisplayText.OnlyName:
						lviSelected.SubItems[2].Text = "Name";
						break;
					case eDisplayText.OnlyLevel:
						lviSelected.SubItems[2].Text = "Level";
						break;
					case eDisplayText.BothNameAndLevel:
						lviSelected.SubItems[2].Text = "Name+Level";
						break;
					case eDisplayText.RaceAndClass:
						lviSelected.SubItems[2].Text = "Race+Class";
						break;
					case eDisplayText.RaceAndClassAndLevel:
						lviSelected.SubItems[2].Text = "Race+Class+Level";
						break;
				}
			}		
		}

		private void tbName_TextChanged(object sender, System.EventArgs e)
		{
			if( diSelected != null && (int) tbName.Tag == 0)
			{
				diSelected.Name = tbName.Text;
				lviSelected.SubItems[3].Text = diSelected.Name;
			}
		}

		private void tbName_KeyPress(object sender, KeyPressEventArgs e)
		{
			if( e.KeyChar == '[' || e.KeyChar == ']')
				e.Handled = true;
		}

		private void btnDeleteHighlight_Click(object sender, System.EventArgs e)
		{
			if( diSelected == null || lviSelected == null)
				return;

			if( diSelected.Name.StartsWith("[") && diSelected.Name.EndsWith("]"))
				return;

			slvHighlights.Items.Remove( lviSelected);
		}

		private void btnAddHighlight_Click(object sender, System.EventArgs e)
		{
			int ch = 1;
			foreach( ListViewItem item in slvHighlights.Items)
			{
				if( item.SubItems[3].Text.StartsWith("Custom Highlight #"))
					ch ++;

				item.Selected = false;
			}
            
			diSelected = new clsDisplayItem( true, eDisplayText.Nothing, "Custom Highlight #" + ch.ToString(), Color.Black.ToArgb());

			lviSelected = new ListViewItem();
			lviSelected.SubItems[0].Text = Color.Black.ToArgb().ToString();
			lviSelected.SubItems.Add( "Yes");
			lviSelected.SubItems.Add( "Nothing");
			lviSelected.SubItems.Add( diSelected.Name);
			lviSelected.Tag = diSelected;
			lviSelected.Selected = true;

			slvHighlights.Items.Add( lviSelected);
		}
	}
}
