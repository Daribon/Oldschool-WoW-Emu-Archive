//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.Xml.Serialization;

namespace WoW_Radar
{
	public enum eDisplayText
	{
		Nothing = 0,
		OnlyName,
		OnlyLevel,
		BothNameAndLevel,
		RaceAndClass,
		RaceAndClassAndLevel
	}

	public class clsDisplayItem : ICloneable 
	{
		[XmlAttribute( "Visible")]
		public bool Visible = true;
		[XmlAttribute( "DisplayText")]
		public eDisplayText DisplayText = eDisplayText.Nothing;
		[XmlAttribute( "Name")]
		public string Name = "";
		[XmlAttribute( "Color")]
		public int Color = System.Drawing.Color.White.ToArgb();

		public clsDisplayItem()
		{
		}

		public clsDisplayItem( bool visible, eDisplayText display, string name, int color)
		{
			Visible = visible;
			DisplayText = display;
			Name = name;
			Color = color;
		}

		public object Clone()
		{
			return new clsDisplayItem( Visible, DisplayText, Name, Color);
		}
	}

	[XmlRootAttribute("Settings", Namespace="", IsNullable=false)]
	public class clsSettings
	{
		[XmlArray("DisplayItems")]
		[XmlArrayItem("DisplayItem", typeof( clsDisplayItem))]
		public ArrayList arrDisplayItems = new ArrayList();

		[XmlIgnore()]
		public Hashtable DisplayItems = new Hashtable();

		public void UpdateHashtable()
		{
			DisplayItems.Clear();
			foreach( clsDisplayItem di in arrDisplayItems)
			{
				try
				{
					if( di.Name.StartsWith("[") && di.Name.EndsWith("]"))
                        DisplayItems.Add( di.Name, di);
					else
						DisplayItems.Add( di.Name.ToLower(), di);
				}
				catch
				{
				}
			}
		}

		public clsSettings()
		{
		}

		public void LoadDefaults()
		{
			arrDisplayItems.Clear();
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.OnlyName, "[Object: Metal Ore]", Color.White.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.OnlyName, "[Object: Weed]", Color.White.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.OnlyName, "[Object: Treasure]", Color.Yellow.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(false, eDisplayText.Nothing, "[Object: Other]", Color.Gray.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[NPC's: Agressive]", Color.Red.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[NPC's: Neutral]", Color.Yellow.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[NPC's: Friendly]", Color.Green.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[NPC's: Dead]", Color.Gray.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.BothNameAndLevel, "[Players: Agressive]", Color.DarkRed.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[Players: Neutral]", Color.Orange.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[Players: Friendly]", Color.DarkGreen.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(false, eDisplayText.Nothing, "[Players: Dead]", Color.Gray.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[Player]", Color.White.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[Target]", Color.Blue.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[Party]", Color.DarkGreen.ToArgb()));
			arrDisplayItems.Add( new clsDisplayItem(true, eDisplayText.Nothing, "[Guild]", Color.DarkGreen.ToArgb()));

			UpdateHashtable();
		}

		public clsDisplayItem GetDisplayItem( string id, clsDisplayItem oldDI)
		{
			clsDisplayItem di = (clsDisplayItem) DisplayItems[id];
			if( di != null)
				return di;

			return oldDI;
		}

		[XmlAttribute( "Username")]
		public string Username = "";
		[XmlAttribute( "Password")]
		public string Password = "";

		[XmlAttribute( "StayOnTop")]
		public bool StayOnTop = true;

		[XmlAttribute( "FormX")]
		public int FormX = 0;
		[XmlAttribute( "FormY")]
		public int FormY = 0;
		[XmlAttribute( "FormWidth")]
		public int FormWidth = 300;
		[XmlAttribute( "FormHeight")]
		public int FormHeight = 300;
			
		[XmlAttribute( "RotateMap")]
		public bool RotateMap = false;
		[XmlAttribute( "ShowMinimap")]
		public bool ShowMinimap = true;
		[XmlAttribute( "MinimapRadius")]
		public int MinimapRadius = 1;
	}
}
