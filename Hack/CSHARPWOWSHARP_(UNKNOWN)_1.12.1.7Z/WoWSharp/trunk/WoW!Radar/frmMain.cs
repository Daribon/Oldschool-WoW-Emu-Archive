//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
using System;
using System.Drawing;
using System.Collections;
using System.ComponentModel;
using System.Windows.Forms;
using System.Data;
using System.IO;
using System.Xml;
using System.Xml.Serialization;
using Microsoft.DirectX;
using Microsoft.DirectX.Direct3D;
using WoW_Sharp;
using SFmpqapi;
using BLP2API;
using System.Diagnostics;
using System.Text.RegularExpressions;

namespace WoW_Radar
{
	/// <summary>
	/// Summary description for Form1.
	/// </summary>
	public class frmMain : System.Windows.Forms.Form
	{
		// Our global variables for this project
		Device device = null; // Our rendering device
		VertexBuffer vbMonster = null;
		VertexBuffer vbPlayer = null;
		VertexBuffer vbWeed = null;
		VertexBuffer vbMine = null;
		VertexBuffer vbObject = null;
		VertexBuffer vbMinimap = null;
		Microsoft.DirectX.Direct3D.Font font;

		// From WoW
		float mapSize = ((64*16) * ((150.0f/36.0f)*8));
		float tileSize = 150.0f / 36.0f * 8 * 16;

		float scale = 2;

		public clsSettings settings;
		public WoW_Sharp.WoW WoW;
		private System.Windows.Forms.TextBox tbInstructions;
		/// <summary>
		/// Required designer variable.
		/// </summary>
		private System.ComponentModel.Container components = null;

		public frmMain()
		{
			//
			// Required for Windows Form Designer support
			//
			InitializeComponent();
		}
		/// <summary>
		/// Clean up any resources being used.
		/// </summary>
		protected override void Dispose( bool disposing )
		{
			if( disposing )
			{
				if (components != null) 
				{
					components.Dispose();
				}
			}
			base.Dispose( disposing );
		}

		#region Windows Form Designer generated code
		/// <summary>
		/// Required method for Designer support - do not modify
		/// the contents of this method with the code editor.
		/// </summary>
		private void InitializeComponent()
		{
			System.Resources.ResourceManager resources = new System.Resources.ResourceManager(typeof(frmMain));
			this.tbInstructions = new System.Windows.Forms.TextBox();
			this.SuspendLayout();
			// 
			// tbInstructions
			// 
			this.tbInstructions.BackColor = System.Drawing.Color.Black;
			this.tbInstructions.BorderStyle = System.Windows.Forms.BorderStyle.None;
			this.tbInstructions.Enabled = false;
			this.tbInstructions.ForeColor = System.Drawing.Color.White;
			this.tbInstructions.Location = new System.Drawing.Point(8, 8);
			this.tbInstructions.Multiline = true;
			this.tbInstructions.Name = "tbInstructions";
			this.tbInstructions.ReadOnly = true;
			this.tbInstructions.Size = new System.Drawing.Size(160, 88);
			this.tbInstructions.TabIndex = 3;
			this.tbInstructions.Text = "Press ESC to Quit\r\n\r\nPress F1 for Options\r\nPress F2 to Zoom Out\r\nPress F3 to Zoom" +
				" In\r\nPress F10 to Start / Stop\r\n\r\nYou can only resize this window if WoW!Radar i" +
				"s not running.";
			// 
			// frmMain
			// 
			this.AutoScaleBaseSize = new System.Drawing.Size(5, 13);
			this.BackColor = System.Drawing.Color.Black;
			this.ClientSize = new System.Drawing.Size(300, 300);
			this.Controls.Add(this.tbInstructions);
			this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.SizableToolWindow;
			this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
			this.KeyPreview = true;
			this.Name = "frmMain";
			this.Closing += new System.ComponentModel.CancelEventHandler(this.frmMain_Closing);
			this.Load += new System.EventHandler(this.frmMain_Load);
			this.KeyUp += new System.Windows.Forms.KeyEventHandler(this.frmMain_KeyUp);
			this.ResumeLayout(false);

		}
		#endregion

		/// <summary>
		/// The main entry point for the application.
		/// </summary>
		[STAThread]
		static void Main() 
		{
			frmMain frm = new frmMain();
			if( frm.InitializeGraphics())
				Application.Run(frm);
			else
				MessageBox.Show("Could not initialize Direct3D.");
		}

		public bool InitializeGraphics()
		{
			try
			{
				// Now let's setup our D3D stuff
				PresentParameters presentParams = new PresentParameters();
				presentParams.Windowed=true;
				presentParams.SwapEffect = SwapEffect.Discard;

				device = new Device(0, DeviceType.Hardware, this, CreateFlags.SoftwareVertexProcessing, presentParams);
				device.DeviceReset += new System.EventHandler(this.OnResetDevice);
				this.OnCreateDevice(device, null);
				this.OnResetDevice(device, null);

				font = new Microsoft.DirectX.Direct3D.Font( device, new System.Drawing.Font("Verdana", 8f));
				
				return true;
			}
			catch (DirectXException)
			{ 
				return false; 
			}
		}

		public void OnCreateDevice(object sender, EventArgs e)
		{
			Device dev = (Device)sender;
			
			// Now Create the VB
			vbMonster = new VertexBuffer(typeof(CustomVertex.PositionColored), 3, dev, 0, CustomVertex.PositionColored.Format, Pool.Default);
			vbMonster.Created += new System.EventHandler(this.OnCreateVBMonster);
			this.OnCreateVBMonster(vbMonster, null);

			// Now Create the VB
			vbPlayer = new VertexBuffer(typeof(CustomVertex.PositionColored), 6, dev, 0, CustomVertex.PositionColored.Format, Pool.Default);
			vbPlayer.Created += new System.EventHandler(this.OnCreateVBPlayer);
			this.OnCreateVBPlayer(vbPlayer, null);

			// Now Create the VB
			vbWeed = new VertexBuffer(typeof(CustomVertex.PositionColored), 12, dev, 0, CustomVertex.PositionColored.Format, Pool.Default);
			vbWeed.Created += new System.EventHandler(this.OnCreateVBWeed);
			this.OnCreateVBWeed(vbWeed, null);

			// Now Create the VB
			vbMine = new VertexBuffer(typeof(CustomVertex.PositionColored), 15, dev, 0, CustomVertex.PositionColored.Format, Pool.Default);
			vbMine.Created += new System.EventHandler(this.OnCreateVBMine);
			this.OnCreateVBMine(vbMine, null);

			// Now Create the VB
			vbObject = new VertexBuffer(typeof(CustomVertex.PositionColored), 6, dev, 0, CustomVertex.PositionColored.Format, Pool.Default);
			vbObject.Created += new System.EventHandler(this.OnCreateVBObject);
			this.OnCreateVBObject(vbObject, null);

			// Now Create the VB
			vbMinimap = new VertexBuffer(typeof(CustomVertex.PositionNormalTextured), 6, dev, 0, CustomVertex.PositionNormalTextured.Format, Pool.Default);
			vbMinimap.Created += new System.EventHandler(this.OnCreateVBMinimap);
			this.OnCreateVBMinimap(vbMinimap, null);
		}

		public void OnResetDevice(object sender, EventArgs e)
		{
			Device dev = (Device)sender;
			
			// Turn off culling, so we see the front and back of the triangle
			dev.RenderState.CullMode = Cull.None;

			// Turn off D3D lighting, since we are providing our own vertex colors
			dev.RenderState.Lighting = false;
			
			// Turn on the ZBuffer
			dev.RenderState.ZBufferEnable = true;

			dev.RenderState.AntiAliasedLineEnable = true;
		}

		private Vector3 ComputeNormal(Vector3 v1, Vector3 v2, Vector3 v3)
		{
			Vector3 N = Vector3.Cross( Vector3.Subtract(v2, v1), Vector3.Subtract(v3, v1));
			return Vector3.Normalize( N);
		}
				
		public void OnCreateVBMinimap(object sender, EventArgs e)
		{
			VertexBuffer vb = (VertexBuffer)sender;
			CustomVertex.PositionNormalTextured[] verts = (CustomVertex.PositionNormalTextured[])vb.Lock(0,0);

			Vector3 v1 = new Vector3(-((float)(tileSize)/2),-((float)(tileSize)/2), 0);
			Vector3 v2 = new Vector3( ((float)(tileSize)/2),-((float)(tileSize)/2), 0);
			Vector3 v3 = new Vector3(-((float)(tileSize)/2), ((float)(tileSize)/2), 0);
			Vector3 n = ComputeNormal( v1, v2, v3);

			verts[ 0] = new CustomVertex.PositionNormalTextured( v1, n, 0, 0);
			verts[ 1] = new CustomVertex.PositionNormalTextured( v2, n, 1, 0);
			verts[ 2] = new CustomVertex.PositionNormalTextured( v3, n, 0, 1);
			
			v1 = new Vector3( ((float)(tileSize)/2), ((float)(tileSize)/2), 0);
			v2 = new Vector3(-((float)(tileSize)/2), ((float)(tileSize)/2), 0);
			v3 = new Vector3( ((float)(tileSize)/2),-((float)(tileSize)/2), 0);
			n = ComputeNormal( v1, v2, v3);
			verts[ 3] = new CustomVertex.PositionNormalTextured( v1, n, 1, 1);
			verts[ 4] = new CustomVertex.PositionNormalTextured( v2, n, 0, 1);
			verts[ 5] = new CustomVertex.PositionNormalTextured( v3, n, 1, 0);

			vb.Unlock();
		}

		public void OnCreateVBObject(object sender, EventArgs e)
		{
			VertexBuffer vb = (VertexBuffer)sender;
			CustomVertex.PositionColored[] verts = (CustomVertex.PositionColored[])vb.Lock(0,0);

			verts[ 0].X=-1.0f;verts[ 0].Y=-1.0f;verts[ 0].Z=0f; verts[ 0].Color = System.Drawing.Color.White.ToArgb();
			verts[ 1].X= 1.0f;verts[ 1].Y=-1.0f;verts[ 1].Z=0f; verts[ 1].Color = System.Drawing.Color.White.ToArgb();
			verts[ 2].X=-1.0f;verts[ 2].Y= 1.0f;verts[ 2].Z=0f; verts[ 2].Color = System.Drawing.Color.White.ToArgb();
			
			verts[ 3].X= 1.0f;verts[ 3].Y= 1.0f;verts[ 3].Z=0f; verts[ 3].Color = System.Drawing.Color.White.ToArgb();
			verts[ 4].X= 1.0f;verts[ 4].Y=-1.0f;verts[ 4].Z=0f; verts[ 4].Color = System.Drawing.Color.White.ToArgb();
			verts[ 5].X=-1.0f;verts[ 5].Y= 1.0f;verts[ 5].Z=0f; verts[ 5].Color = System.Drawing.Color.White.ToArgb();

			vb.Unlock();
		}

		public void OnCreateVBMine(object sender, EventArgs e)
		{
			VertexBuffer vb = (VertexBuffer)sender;
			CustomVertex.PositionColored[] verts = (CustomVertex.PositionColored[])vb.Lock(0,0);

			verts[ 0].X=-2.0f;verts[ 0].Y= 0.0f;verts[ 0].Z=0f; verts[ 0].Color = System.Drawing.Color.White.ToArgb();
			verts[ 1].X=-2.0f;verts[ 1].Y= 1.0f;verts[ 1].Z=0f; verts[ 1].Color = System.Drawing.Color.White.ToArgb();
			verts[ 2].X= 0.0f;verts[ 2].Y= 0.0f;verts[ 2].Z=0f; verts[ 2].Color = System.Drawing.Color.White.ToArgb();
			
			verts[ 3].X= 2.0f;verts[ 3].Y= 0.0f;verts[ 3].Z=0f; verts[ 3].Color = System.Drawing.Color.White.ToArgb();
			verts[ 4].X= 2.0f;verts[ 4].Y= 1.0f;verts[ 4].Z=0f; verts[ 4].Color = System.Drawing.Color.White.ToArgb();
			verts[ 5].X= 0.0f;verts[ 5].Y= 0.0f;verts[ 5].Z=0f; verts[ 5].Color = System.Drawing.Color.White.ToArgb();

			verts[ 6].X= 2.0f;verts[ 6].Y= 1.0f;verts[ 6].Z=0f; verts[ 6].Color = System.Drawing.Color.White.ToArgb();
			verts[ 7].X= 1.0f;verts[ 7].Y= 2.0f;verts[ 7].Z=0f; verts[ 7].Color = System.Drawing.Color.White.ToArgb();
			verts[ 8].X= 0.0f;verts[ 8].Y= 0.0f;verts[ 8].Z=0f; verts[ 8].Color = System.Drawing.Color.White.ToArgb();
			
			verts[ 9].X=-2.0f;verts[ 9].Y= 1.0f;verts[ 9].Z=0f; verts[ 9].Color = System.Drawing.Color.White.ToArgb();
			verts[10].X=-1.0f;verts[10].Y= 2.0f;verts[10].Z=0f; verts[10].Color = System.Drawing.Color.White.ToArgb();
			verts[11].X= 0.0f;verts[11].Y= 0.0f;verts[11].Z=0f; verts[11].Color = System.Drawing.Color.White.ToArgb();

			verts[12].X=-1.0f;verts[12].Y= 2.0f;verts[12].Z=0f; verts[12].Color = System.Drawing.Color.White.ToArgb();
			verts[13].X= 1.0f;verts[13].Y= 2.0f;verts[13].Z=0f; verts[13].Color = System.Drawing.Color.White.ToArgb();
			verts[14].X= 0.0f;verts[14].Y= 0.0f;verts[14].Z=0f; verts[14].Color = System.Drawing.Color.White.ToArgb();

			vb.Unlock();
		}

		public void OnCreateVBWeed(object sender, EventArgs e)
		{
			VertexBuffer vb = (VertexBuffer)sender;
			CustomVertex.PositionColored[] verts = (CustomVertex.PositionColored[])vb.Lock(0,0);

			verts[ 0].X= 0.0f;verts[ 0].Y= 2.0f;verts[ 0].Z=0f; verts[ 0].Color = System.Drawing.Color.White.ToArgb();
			verts[ 1].X=-1.0f;verts[ 1].Y= 0.0f;verts[ 1].Z=0f; verts[ 1].Color = System.Drawing.Color.White.ToArgb();
			verts[ 2].X= 1.0f;verts[ 2].Y= 0.0f;verts[ 2].Z=0f; verts[ 2].Color = System.Drawing.Color.White.ToArgb();
			
			verts[ 3].X= 0.0f;verts[ 3].Y=-2.0f;verts[ 3].Z=0f; verts[ 3].Color = System.Drawing.Color.White.ToArgb();
			verts[ 4].X=-1.0f;verts[ 4].Y= 0.0f;verts[ 4].Z=0f; verts[ 4].Color = System.Drawing.Color.White.ToArgb();
			verts[ 5].X= 1.0f;verts[ 5].Y= 0.0f;verts[ 5].Z=0f; verts[ 5].Color = System.Drawing.Color.White.ToArgb();

			verts[ 6].X=-2.0f;verts[ 6].Y= 0.0f;verts[ 6].Z=0f; verts[ 6].Color = System.Drawing.Color.White.ToArgb();
			verts[ 7].X= 0.0f;verts[ 7].Y= 1.0f;verts[ 7].Z=0f; verts[ 7].Color = System.Drawing.Color.White.ToArgb();
			verts[ 8].X= 0.0f;verts[ 8].Y=-1.0f;verts[ 8].Z=0f; verts[ 8].Color = System.Drawing.Color.White.ToArgb();
			
			verts[ 9].X= 2.0f;verts[ 9].Y= 0.0f;verts[ 9].Z=0f; verts[ 9].Color = System.Drawing.Color.White.ToArgb();
			verts[10].X= 0.0f;verts[10].Y= 1.0f;verts[10].Z=0f; verts[10].Color = System.Drawing.Color.White.ToArgb();
			verts[11].X= 0.0f;verts[11].Y=-1.0f;verts[11].Z=0f; verts[11].Color = System.Drawing.Color.White.ToArgb();

			vb.Unlock();
		}

		public void OnCreateVBPlayer(object sender, EventArgs e)
		{
			VertexBuffer vb = (VertexBuffer)sender;
			CustomVertex.PositionColored[] verts = (CustomVertex.PositionColored[])vb.Lock(0,0);

			verts[ 0].X=-2.0f;verts[ 0].Y=-2.0f;verts[ 0].Z=0f; verts[ 0].Color = System.Drawing.Color.White.ToArgb();
			verts[ 1].X= 0.0f;verts[ 1].Y=-1.0f;verts[ 1].Z=0f; verts[ 1].Color = System.Drawing.Color.White.ToArgb();
			verts[ 2].X= 0.0f;verts[ 2].Y= 2.0f;verts[ 2].Z=0f; verts[ 2].Color = System.Drawing.Color.White.ToArgb();
			
			verts[ 3].X= 2.0f;verts[ 3].Y=-2.0f;verts[ 3].Z=0f; verts[ 3].Color = System.Drawing.Color.White.ToArgb();
			verts[ 4].X= 0.0f;verts[ 4].Y=-1.0f;verts[ 4].Z=0f; verts[ 4].Color = System.Drawing.Color.White.ToArgb();
			verts[ 5].X= 0.0f;verts[ 5].Y= 2.0f;verts[ 5].Z=0f; verts[ 5].Color = System.Drawing.Color.White.ToArgb();

			vb.Unlock();
		}

		public void OnCreateVBMonster(object sender, EventArgs e)
		{
			VertexBuffer vb = (VertexBuffer)sender;
			CustomVertex.PositionColored[] verts = (CustomVertex.PositionColored[])vb.Lock(0,0);

			verts[0].X=-1.0f;verts[0].Y=-2.0f;verts[0].Z=0f; verts[0].Color = System.Drawing.Color.White.ToArgb();
			verts[1].X= 1.0f;verts[1].Y=-2.0f;verts[1].Z=0f; verts[1].Color = System.Drawing.Color.White.ToArgb();
			verts[2].X= 0.0f;verts[2].Y= 2.0f;verts[2].Z=0f; verts[2].Color = System.Drawing.Color.White.ToArgb();

			vb.Unlock();
		}

		private void frmMain_Load(object sender, EventArgs e)
		{
			settings = new clsSettings();
			settings.LoadDefaults();

			if( File.Exists( "WoW!Radar.xml"))
			{
				try
				{
					XmlTextReader xr = new XmlTextReader( "WoW!Radar.xml");
					XmlSerializer xs = new XmlSerializer( settings.GetType());
					settings = (clsSettings) xs.Deserialize( xr);
					xr.Close();
				}
				catch
				{
					settings = new clsSettings();
					settings.LoadDefaults();
				}
			}

			Left = settings.FormX;
			Top = settings.FormY;
            Width = settings.FormWidth;
			Height = settings.FormHeight;

			settings.UpdateHashtable();
			this.TopMost = settings.StayOnTop;

			WoW = new WoW_Sharp.WoW();
			WoW.AfterUpdate += new WoW_SharpEvent(WoW_AfterUpdate);
		}

		private void frmMain_Closing(object sender, CancelEventArgs e)
		{
			WoW.Stop();

			settings.FormX = Left;
			settings.FormY = Top;
			settings.FormWidth = Width;
			settings.FormHeight = Height;

			XmlTextWriter xw = new XmlTextWriter( "WoW!Radar.xml", System.Text.Encoding.ASCII);
			XmlSerializer xs = new XmlSerializer( settings.GetType());
			xs.Serialize( xw, settings);
			xw.Close();
		}

		private void WoW_AfterUpdate(WoW_Sharp.WoW sender)
		{
			if( device == null)
				return;

			if( sender.Player == null)
				return;

			WoW_Object player = WoW.Player;
			WoW_Object target = WoW.Target;

			//Clear the backbuffer to a black color
			device.Clear(ClearFlags.Target, System.Drawing.Color.Black, 1.0f, 0);

			float camDist = 100000.0F;
			Vector3 camPos = new Vector3( 0.0F, 0.0F, camDist);
			Vector3 camTarg = new Vector3( 0.0F, 0.0F, 0.0F);
			Vector3 camUpVec = new Vector3( 0.0F, -1.0F, 0.0F);

			Matrix rotMap = Matrix.RotationY(180 * 0.01745329f) * Matrix.RotationX(180 * 0.01745329f);

			if( settings.RotateMap)
				rotMap *= Matrix.RotationZ( 360 * 0.01745329f -  player.Facing);

			camPos.TransformCoordinate( rotMap);
			camTarg.TransformCoordinate( rotMap);
			camUpVec.TransformCoordinate( rotMap);

			camTarg.Add(new Vector3(player.X, player.Y, player.Z));
			camPos.Add(new Vector3(player.X, player.Y, player.Z));

			device.Transform.View = Matrix.LookAtLH(camPos, camTarg, camUpVec);
			device.Transform.Projection = Matrix.PerspectiveLH(Width / (camDist * scale), Height / (camDist * scale), 1, 1000000);

			//Begin the scene
			device.BeginScene();

			if( settings.ShowMinimap)
				DrawMinimap();

			int playerGuildId = player.ReadStorageInt( sender.Descriptors[ WoW_ObjectTypes.Player, "PLAYER_GUILDID"]);
			foreach( WoW_Object obj in WoW.Objects.Values)
			{
				if( obj.Type == WoW_ObjectTypes.Unit || obj.Type == WoW_ObjectTypes.Player || obj.Type == WoW_ObjectTypes.GameObject || obj.Type == WoW_ObjectTypes.Corpse)
				{
					clsDisplayItem di = settings.GetDisplayItem( "[Object: Other]", null);
					
					bool rotate = false;

					int noVertexs = 2;
					VertexBuffer vBuffer = vbObject;

					if( obj.Type == WoW_ObjectTypes.Unit)
					{
						rotate = true;
						vBuffer = vbMonster;
						noVertexs = 1;

						switch( WoW.GetUnitReaction( obj, player))
						{
							case 1:
								di = settings.GetDisplayItem( "[NPC's: Agressive]", null);
								break;

							case 3:
								di = settings.GetDisplayItem( "[NPC's: Neutral]", null);
								break;

							case 4:
								di = settings.GetDisplayItem( "[NPC's: Friendly]", null);
								break;
						}

						if( obj.IsDead)
						{
							di = settings.GetDisplayItem( "[NPC's: Dead]", null);
						}
					}

					if( obj.Type == WoW_ObjectTypes.Player)
					{
						rotate = true;
						vBuffer = vbPlayer;
						noVertexs = 2;

						switch( WoW.GetUnitReaction( obj, player))
						{
							case 1:
								di = settings.GetDisplayItem( "[Players: Agressive]", null);
								break;

							case 3:
								di = settings.GetDisplayItem( "[Players: Neutral]", null);
								break;

							case 4:
								di = settings.GetDisplayItem( "[Players: Friendly]", null);

								if( obj.ReadStorageInt( sender.Descriptors[ WoW_ObjectTypes.Player, "PLAYER_GUILDID"]) == playerGuildId)
								{
									clsDisplayItem tmp = settings.GetDisplayItem( "[Guild]", null);
									if( tmp != null && tmp.Visible)
										di = tmp;
								}
								break;
						}
					}

					if( obj.Type == WoW_ObjectTypes.GameObject)
					{
						if( obj.IsMiningNode)
						{
							vBuffer = vbMine;
							noVertexs = 5;

							di = settings.GetDisplayItem( "[Object: Metal Ore]", null);
						}

						if( obj.IsWeedNode)
						{
							vBuffer = vbWeed;
							noVertexs = 4;

							di = settings.GetDisplayItem( "[Object: Weed]", null);
						}

						if( obj.IsTreasureNode)
						{
							vBuffer = vbMine;
							noVertexs = 5;

							di = settings.GetDisplayItem( "[Object: Treasure]", null);
						}
					}

					if( obj.Type == WoW_ObjectTypes.Corpse)
					{
						rotate = true;
						vBuffer = vbMonster;
						noVertexs = 1;

						di = settings.GetDisplayItem( "[Players: Dead]", null);
					}

					if( obj.Name != null)
						di = settings.GetDisplayItem( obj.Name.ToLower(), di);

					if( WoW.PartyMembers != null && WoW.PartyMembers.IndexOf( obj) != -1)
					{
						clsDisplayItem tmp = settings.GetDisplayItem( "[Party]", null);
						if( tmp != null && tmp.Visible)
							di = tmp;
					}

					if( obj == player)
						di = settings.GetDisplayItem( "[Player]", null);

					if( obj == target)
					{
						clsDisplayItem tmp = settings.GetDisplayItem( "[Target]", null);
						if( tmp != null && tmp.Visible)
							di = tmp;
					}

					if( di != null && di.Visible)
					{
						float iscale = 2 * (2 / scale);
						Vector3 pos = new Vector3( obj.X, obj.Y, obj.Z);

						device.Transform.World = Matrix.Scaling( iscale, iscale, iscale);

						if( rotate)
								device.Transform.World *= Matrix.RotationZ( 360 * 0.01745329f - obj.Facing);
						else if( settings.RotateMap)
							device.Transform.World *= Matrix.RotationZ( 360 * 0.01745329f -  player.Facing);

						device.Transform.World *= Matrix.Translation( pos);

						device.RenderState.TextureFactor = di.Color;
						device.TextureState[0].ColorOperation = TextureOperation.Modulate;
						device.TextureState[0].ColorArgument0 = TextureArgument.TextureColor;
						device.TextureState[0].ColorArgument1 = TextureArgument.TFactor;

						device.VertexFormat = CustomVertex.PositionColored.Format;
						device.SetTexture( 0, null);

						device.SetStreamSource( 0, vBuffer, 0);
						device.DrawPrimitives(PrimitiveType.TriangleList, 0, noVertexs);

						if( di.DisplayText != eDisplayText.Nothing)
						{
							string text = "";
							switch( di.DisplayText)
							{
								case eDisplayText.OnlyLevel:
									text = obj.Level.ToString();
									break;
								case eDisplayText.OnlyName:
									text = obj.Name;
									break;
								case eDisplayText.BothNameAndLevel:
									text = obj.Name + "(" + obj.Level.ToString() + ")";
									break;
								case eDisplayText.RaceAndClass:
									text = obj.UnitRace + " " + obj.UnitClass;
									break;
								case eDisplayText.RaceAndClassAndLevel:
									text = obj.UnitRace + " " + obj.UnitClass + "(" + obj.Level.ToString() + ")";
									break;
							}

							if( text != "")
							{
								pos = Vector3.Project( new Vector3( 0, 0, 0), device.Viewport, device.Transform.Projection, device.Transform.View, device.Transform.World);
								font.DrawText( null, text, (int) pos.X + 10, (int) pos.Y - 4, di.Color);
							}
						}
					}
				}
			}
		
			device.EndScene();
			device.Present();
		}

		ArrayList minimapCache = new ArrayList();
		private void DrawMinimap()
		{
			float absCoordX = (mapSize / 2) - WoW.Player.X + tileSize;
			float absCoordY = (mapSize / 2) - WoW.Player.Y + tileSize;

			int tileX = (int)(absCoordX / tileSize) - 1;
			int tileY = (int)(absCoordY / tileSize) - 1;

			foreach( clsMinimap minimap in minimapCache)
				minimap.cache = false;

			string area = "";
			switch( WoW.CurrentContinent)
			{
				case 0:
					area = "Kalimdor";
					break;

				case 1:
					area = "Azeroth";
					break;

				default:
					area = "";
					break;
			}

			for( int x = tileX - settings.MinimapRadius; x <= (tileX + settings.MinimapRadius); x ++)
			for( int y = tileY - settings.MinimapRadius; y <= (tileY + settings.MinimapRadius); y ++)
			{
				clsMinimap minimap = LoadMinimap( x, y, area);

				if( minimap == null) 
					continue;

				minimap.cache = true;
				if( minimap.texture != null)
				{
					float mapX = -((x * tileSize) - (mapSize / 2)) - (tileSize/2);
					float mapY = -((y * tileSize) - (mapSize / 2)) - (tileSize/2);

					if( minimap.dxt1)
                        device.Transform.World = Matrix.RotationX(180 * 0.01745329f) * Matrix.RotationY(180 * 0.01745329f) * Matrix.Translation( mapX, mapY, -1000);
					else
						device.Transform.World = Matrix.RotationY(180 * 0.01745329f) * Matrix.Translation( mapX, mapY, -1000);

					device.SetTexture(0, minimap.texture);
					device.TextureState[0].ColorOperation = TextureOperation.Modulate;
					device.TextureState[0].ColorArgument1 = TextureArgument.TextureColor;
					device.TextureState[0].ColorArgument2 = TextureArgument.Diffuse;
					device.TextureState[0].AlphaOperation = TextureOperation.Disable;

					device.VertexFormat = CustomVertex.PositionNormalTextured.Format;

					device.SetStreamSource( 0, vbMinimap, 0);
					device.DrawPrimitives(PrimitiveType.TriangleList, 0, 2);
				}
			}

			foreach( clsMinimap minimap in minimapCache)
				if( !minimap.cache)
				{
					// Dont cache it anymore
					if( minimap.texture != null)
					{
						minimap.texture.Dispose();
						minimap.texture = null;
					}
				}
		}

		private void GetMinimapTexture( clsMinimap minimap)
		{
			int hMPQ = 0;
			int hFile = 0;
			int FileSize = 0;
			int FileRead = 0;

			//WoW.LogLine( "Opening {0}", WoW.GamePath + "\\Data\\texture.MPQ");
			if( SFmpq.SFileOpenArchive( WoW.GamePath + "\\Data\\texture.MPQ", 0, 0, ref hMPQ) != 1)
			{
				WoW.LogLine( "Error opening {0}", WoW.GamePath + "\\Data\\texture.MPQ");
				return;
			}

			//WoW.LogLine( "Opening texture.MPQ|textures\\Minimap\\{0}", minimap.filename);
			if( SFmpq.SFileOpenFileEx( hMPQ, "textures\\Minimap\\" + minimap.filename, 0, ref hFile) != 1)
			{
				WoW.LogLine( "Error opening texture.MPQ|textures\\Minimap\\{0}", minimap.filename);
				SFmpq.SFileCloseFile( hMPQ);
				return;
			}

			FileSize = SFmpq.SFileGetFileSize( hFile, ref FileSize);
			byte [] buffer = new byte[ FileSize];

			//WoW.LogLine( "Reading texture.MPQ|textures\\Minimap\\{0}", minimap.filename);
			if( SFmpq.SFileReadFile( hFile, buffer, (uint) FileSize, ref FileRead, IntPtr.Zero) == 1)
			{
				//WoW.LogLine( "Parsing texture.MPQ|textures\\Minimap\\{0}", minimap.filename);

				minimap.dxt1 = true;
				MemoryStream ms = BLP2Parse.BLPtoDXT1( buffer);
				if( ms != null && ms.Length > 0x70)
				{
					ms.Seek( 0, SeekOrigin.Begin);
					try
					{
						minimap.texture = TextureLoader.FromStream( device, ms);
						if( minimap.texture == null)
							minimap.dxt1 = false;
					}
					catch
					{
						minimap.dxt1 = false;
					}
				}

				if( !minimap.dxt1)
				{
					ms = BLP2Parse.BLPtoTGA( buffer);
					ms.Seek( 0, SeekOrigin.Begin);
					try
					{
						minimap.texture = TextureLoader.FromStream( device, ms);
					}
					catch
					{
						WoW.LogLine( "Error loading texture.MPQ|textures\\Minimap\\{0}", minimap.filename);
					}
				}

			}
			else
			{
				WoW.LogLine( "Error reading texture.MPQ|textures\\Minimap\\{0}", minimap.filename);
			}

			SFmpq.SFileCloseFile( hFile);
			SFmpq.SFileCloseArchive( hMPQ);

			return;
		}

		private clsMinimap LoadMinimap( int X, int Y, string Area)
		{
			if( X > 63 || Y > 63 || X < 0 || Y < 0)
				return null;

			clsArea area = (clsArea) areas[Area];
			if( area == null)
				return null;

			clsMinimap minimap = area.minimaps[ X, Y];
			if( minimap != null && minimap.texture == null)
				GetMinimapTexture( minimap);

			return minimap;
		}

		Hashtable areas = new Hashtable();
		class clsMinimap
		{
			public string filename = null;
			public Texture texture = null;
			public bool cache = false;
			public bool dxt1 = false;
		}

		class clsArea
		{
			public string area = "";
			public clsMinimap [,] minimaps = new clsMinimap[64,64];
		}
		
		private void BuildMinimapList( byte [] md5list)
		{
			MemoryStream src = new MemoryStream( md5list);
			StreamReader sr = new StreamReader( src);

			Regex map = new Regex( @"^.[^\\]+\\[a-z,A-Z]+([0-9][0-9])_([0-9][0-9])\.blp[\t, ]+(.+)$");

			clsArea area = null;
			while( sr.Peek() != -1)
			{
				string line = sr.ReadLine();

				if( line.StartsWith( "dir: "))
				{
					if( area != null)
					{
						int count = 0;
						for( int x = 0; x < 64; x ++)
							for( int y = 0; y < 64; y++)
								if( area.minimaps[x,y] != null)
									count ++;

						WoW.LogLine( "Parsed {0}, {1} minimaps found.", area.area, count);
					}

					// Check if its a zone map, or an indoor map
					if( line.IndexOf( "\\") == -1)
					{
						area = new clsArea();
						area.area = line.Remove( 0, 5);
						areas.Add( area.area, area);
					}
					else
					{
						area = null;
					}
				}
				else if( area != null)
				{
					Match m = map.Match(line);
					if( m.Success)
					{
						int x = int.Parse( m.Groups[1].Value);
						int y = int.Parse( m.Groups[2].Value);

						area.minimaps[x,y] = new clsMinimap();
						area.minimaps[x,y].filename = m.Groups[3].Value;
					}
				}
			}
		}
		
		public void BuildAreas( string path)
		{
			int hMPQ = 0;
			int hFile = 0;
			int FileSize = 0;
			int FileRead = 0;

			areas.Clear();

			//WoW.LogLine( "Opening {0}", path + "\\Data\\misc.MPQ");
			if( SFmpq.SFileOpenArchive( path + "\\Data\\misc.MPQ", 0, 0, ref hMPQ) == 1)
			{
				//WoW.LogLine( "Opening misc.MPQ|textures\\Minimap\\md5translate.trs");
				if( SFmpq.SFileOpenFileEx( hMPQ, "textures\\Minimap\\md5translate.trs", 0, ref hFile) == 1)
				{
					FileSize = SFmpq.SFileGetFileSize( hFile, ref FileSize);

					byte [] buffer = new byte[ FileSize];
					//WoW.LogLine( "Reading misc.MPQ|textures\\Minimap\\md5translate.trs[{0}]", FileSize);
					if( SFmpq.SFileReadFile( hFile, buffer, (uint) FileSize, ref FileRead, IntPtr.Zero) == 1)
					{
						//WoW.LogLine( "Parsing md5translate.trs");
						BuildMinimapList( buffer);
					}
					else
					{
						WoW.LogLine( "Error reading md5translate.trs");
					}

					SFmpq.SFileCloseFile( hFile);
				}
				else
				{
					WoW.LogLine( "Error opening md5translate.trs");
				}

				SFmpq.SFileCloseArchive( hMPQ);
			}
			else
			{
				WoW.LogLine( "Error opening misc.MPQ");
			}
		}

		private void frmMain_KeyUp(object sender, KeyEventArgs e)
		{
			if( e.KeyCode == Keys.Escape)
				Close();

			if( e.KeyCode == Keys.F10)
			{
				if( settings.Username == "" || settings.Password == "")
				{
					MessageBox.Show( "No username and/or password entered in the option screen, please press F1.", "Unable to start WoW!Radar");
					return;
				}

				if( !WoW.HasStarted)
				{
					tbInstructions.Visible = false;

					//this.Text = "WoW!Radar: Starting";
					this.Text = "";
					this.FormBorderStyle = FormBorderStyle.FixedToolWindow;
					WoW.Username = settings.Username;
					WoW.Password = settings.Password;
					WoW.Application = "WoW!Radar v" + Application.ProductVersion;
					try
					{
						WoW.Start();
						try
						{
							BuildAreas( WoW.GamePath);

							//this.Text = "WoW!Radar: Started";
							this.Text = "";
						}
						catch( Exception E)
						{
							WoW.LogLine( "Exception while parsing md5translate.trs: {0}", E.Message);
						}
					}
					catch( Exception E)
					{
						MessageBox.Show( E.Message, "Unable to start WoW!Sharp");
						//this.Text = "WoW!Radar: Stopped";
						this.Text = "";
						tbInstructions.Visible = true;
					}
				}
				else
				{
					//this.Text = "WoW!Radar: Stopping";
					this.Text = "";
					WoW.Stop();
					//this.Text = "WoW!Radar: Stopped";
					this.Text = "";
					
					tbInstructions.Visible = true;
					this.FormBorderStyle = FormBorderStyle.SizableToolWindow;
				}
			}

			if( e.KeyCode == Keys.F2)
				scale *= 0.9f;

			if( e.KeyCode == Keys.F3)
				scale *= 1.1f;
			
			if( e.KeyCode == Keys.F1)
			{
				this.TopMost = false;

				frmOptions frm = new frmOptions();
				frm.LoadSettings( settings);
				if( frm.ShowDialog() == DialogResult.OK)
				{
					frm.SaveSettings( settings);
					settings.UpdateHashtable();
				}

				this.TopMost = settings.StayOnTop;
			}
		}
	}
}
