//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------
#define WOWEXECUTE_API __declspec(dllexport)

// Structures / classes
typedef struct _WoWGuid
{
	union {
		__int64 ullGuid;
		struct
		{
			unsigned long A;
			unsigned long B;
		};
	};
} WGUID, *PWGUID;

// Defines
#define FUNCTION_AT_ADDRESS(function,offset) __declspec(naked) function\
{\
	__asm{jmp offset};\
}
#define WAIT_FOR_EVENT for( int i = 0; i < 10000 && Event != DoNothing; i ++) ::Sleep(1);

// Enums
enum ExecuteEvents
{
	DoNothing,
	DoRightClick,
	DoLeftClick,
	DoClearTarget,
	DoAutoStoreAllLootItems,
	DoScriptExecute,
	DoCastSpellByID,
	DoStartMovement,
	DoStopMovement,
	DoTimedMovement,
	DoGetAsyncTimeMs
};

// External setup functions
extern "C" WOWEXECUTE_API void SetDetourPtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetAddChatMessagePtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetRightClickPtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetLeftClickPtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetClearTargetPtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetAutoStoreAllLootItemsPtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetScriptExecutePtr( DWORD ptr, DWORD ptr2);
extern "C" WOWEXECUTE_API void SetCastSpellByIDPtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetOsGetAsyncTimeMsPtr( DWORD ptr);
extern "C" WOWEXECUTE_API void SetAntiAFKPtr( DWORD ptr, DWORD offset1, DWORD offset2);

// External WoW functions
extern "C" WOWEXECUTE_API void RightClickTarget( __int64 target);
extern "C" WOWEXECUTE_API void LeftClickTarget( __int64 target);
extern "C" WOWEXECUTE_API void PickupAllLoot();
extern "C" WOWEXECUTE_API bool SendScript( LPCSTR pScript);
extern "C" WOWEXECUTE_API void CastSpellByID( int id);
extern "C" WOWEXECUTE_API void ClearTarget( __int64 target);
extern "C" WOWEXECUTE_API void StartMovement( int bit);
extern "C" WOWEXECUTE_API void StopMovement( int bit);
extern "C" WOWEXECUTE_API void TimedMovement( int bit, DWORD time);

// External misc functions
extern "C" WOWEXECUTE_API DWORD GetAsyncTimeMs();
extern "C" WOWEXECUTE_API bool SetChatlogPath( LPCSTR path);

// Functions used internally
bool CheckRange( DWORD ptr, DWORD ptrLength, DWORD address, DWORD addressLength);
void CheckDetours( DWORD address, DWORD length);
void DetourFunctions();
void RestoreFunctions();

// Shared variables
extern ExecuteEvents Event;
extern WGUID Target;
extern bool ReadAllLanguages;
extern int MovementBit;
extern DWORD MovementTime;
extern DWORD AsyncTimeMs;
extern int SpellId;
extern char Script[255];
extern char ChatLog[255];
extern DWORD ptrDetour;
extern DWORD ptrAddChatMessage;
extern DWORD ptrProcessMessage;
extern DWORD ptrRightClick;
extern DWORD ptrLeftClick;
extern DWORD ptrScriptExecute;
extern DWORD ptrCastSpellByID;
extern DWORD ptrAutoStoreAllLootItems;
extern DWORD ptrOsGetAsyncTimeMs;
extern DWORD ptrClearTarget;
extern DWORD ptrCGInputControl__GetActive;
extern DWORD ptrCGInputControl__SetControlBit;
extern DWORD ptrg_HardwareEvent;
extern DWORD ptrCurrentWorldFrame;
extern DWORD offsetAntiAFK_1;
extern DWORD offsetAntiAFK_2;
