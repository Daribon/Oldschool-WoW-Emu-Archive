//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------

#include <windows.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "detours.h"
#undef CreateProcessWithDll
#undef ContinueProcessWithDll
#include "WoW!Execute.h"

extern "C" WOWEXECUTE_API void SetDetourPtr( DWORD ptr)
{
	ptrDetour = ptr;
}

extern "C" WOWEXECUTE_API void SetProcessMessagePtr( DWORD ptr)
{
	ptrProcessMessage = ptr;
}

extern "C" WOWEXECUTE_API void SetAddChatMessagePtr( DWORD ptr)
{
	ptrAddChatMessage = ptr;
}

extern "C" WOWEXECUTE_API bool SetChatlogPath( LPCSTR path)
{
	if( strlen( path) > 254)
		return false;

	strcpy( ChatLog, path);
	return true;
}

extern "C" WOWEXECUTE_API void GetChatlogPath( LPVOID returnPath)
{
	strcpy( (char*)returnPath, ChatLog);
}

extern "C" WOWEXECUTE_API void SetRightClickPtr( DWORD ptr)
{
	ptrRightClick = ptr;
}

extern "C" WOWEXECUTE_API void SetLeftClickPtr( DWORD ptr)
{
	ptrLeftClick = ptr;
}

extern "C" WOWEXECUTE_API void SetAutoStoreAllLootItemsPtr( DWORD ptr)
{
	ptrAutoStoreAllLootItems = ptr;
}

extern "C" WOWEXECUTE_API void SetCastSpellByIDPtr( DWORD ptr)
{
	ptrCastSpellByID = ptr;
}

extern "C" WOWEXECUTE_API void SetScriptExecutePtr( DWORD ptr, DWORD ptr2)
{
	ptrScriptExecute = ptr;
	ptrg_HardwareEvent = ptr2;
}

extern "C" WOWEXECUTE_API void SetOsGetAsyncTimeMsPtr( DWORD ptr)
{
	ptrOsGetAsyncTimeMs = ptr;
}

extern "C" WOWEXECUTE_API void SetClearTargetPtr( DWORD ptr)
{
	ptrClearTarget = ptr;
}

extern "C" WOWEXECUTE_API void SetMovementPtr( DWORD ptr1, DWORD ptr2)
{
	ptrCGInputControl__GetActive = ptr1;
	ptrCGInputControl__SetControlBit = ptr2;
}

extern "C" WOWEXECUTE_API void SetAntiAFKPtr( DWORD ptr, DWORD offset1, DWORD offset2)
{
	ptrCurrentWorldFrame = ptr;
	offsetAntiAFK_1 = offset1;
	offsetAntiAFK_2 = offset2;
}

extern "C" WOWEXECUTE_API void SetReadAllLanguages( bool Enabled)
{
	ReadAllLanguages = Enabled;
}

extern "C" WOWEXECUTE_API void LeftClick( __int64 target)
{
	Target.ullGuid = target;
	Event = DoLeftClick;

	WAIT_FOR_EVENT;
}

extern "C" WOWEXECUTE_API void RightClick( __int64 target)
{
	Target.ullGuid = target;
	Event = DoRightClick;

	WAIT_FOR_EVENT;
}

extern "C" WOWEXECUTE_API void ClearTarget( __int64 target)
{
	Target.ullGuid = target;
	Event = DoClearTarget;

	WAIT_FOR_EVENT;
}

extern "C" WOWEXECUTE_API void StartMovement( int bit)
{
	MovementBit = bit;
	Event = DoStartMovement;

	WAIT_FOR_EVENT;
}

extern "C" WOWEXECUTE_API void StopMovement( int bit)
{
	MovementBit = bit;
	Event = DoStopMovement;

	WAIT_FOR_EVENT;
}

extern "C" WOWEXECUTE_API void TimedMovement( int bit, DWORD time)
{
	MovementBit = bit;
	MovementTime = time;
	Event = DoTimedMovement;

	WAIT_FOR_EVENT;
}

extern "C" WOWEXECUTE_API DWORD GetAsyncTimeMs()
{
	Event = DoGetAsyncTimeMs;

	WAIT_FOR_EVENT;
	return AsyncTimeMs; 
}

extern "C" WOWEXECUTE_API void CastSpellByID( int id)
{
	SpellId = id;
	Event = DoCastSpellByID;

	WAIT_FOR_EVENT;
}


extern "C" WOWEXECUTE_API bool ScriptExecute( LPCSTR pScript)
{
	if( strlen( pScript) > 254)
		return false;

	strcpy( Script, pScript);
	Event = DoScriptExecute;

	WAIT_FOR_EVENT;
	return true;
}

extern "C" WOWEXECUTE_API void AutoStoreAllLootItems()
{
	Event = DoAutoStoreAllLootItems;

	WAIT_FOR_EVENT;
}

extern "C" WOWEXECUTE_API BOOL CreateProcessWithDll( LPSTR lpCommandLine, LPCSTR lpDllName)
{
	STARTUPINFO si;
	PROCESS_INFORMATION pi;
    
	ZeroMemory(&si, sizeof(si));
	ZeroMemory(&pi, sizeof(pi));
	si.cb = sizeof(si);

	char currentdir[2048] = {0};
    strncpy( currentdir, lpCommandLine, 2047);
	char *slash = strrchr( currentdir, '\\');
	if( slash == NULL) slash = strrchr( currentdir, '/');
	if( slash != NULL) slash[0] = '\0';

	return DetourCreateProcessWithDll( NULL, lpCommandLine, NULL, NULL, TRUE, CREATE_DEFAULT_ERROR_MODE, NULL, currentdir, &si, &pi, lpDllName, NULL);
}

extern "C" WOWEXECUTE_API BOOL ContinueProcessWithDll( HANDLE hProcess, LPCSTR lpDllName)
{
	return DetourContinueProcessWithDll( hProcess, lpDllName);
}