//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------

#include <windows.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "WoW!Execute.h"
#include "detours.h"

//-------------------------------------------------------
// shared data 
// Notice:	seen by both: the instance of "WoW!Hider.dll" mapped
//			into the remote process as well as by the instance
//			mapped into our "WoW!Hider.dll"
#pragma data_seg (".shared")
ExecuteEvents Event = DoNothing;

// Target to rightclick/leftclick/cleartarget
WGUID Target = {0};

// Read all languages?
bool ReadAllLanguages = false;

// Movement directions
int MovementBit = 0;
DWORD MovementTime = 0;

// Latest time
DWORD AsyncTimeMs = 0;

// Which spell to cast
int SpellId = 0;

// Script to run
char Script[255] = {0};

// Where to dump chat.log
char ChatLog[255] = "chat.log";

// All the pointers to the possible functions
DWORD ptrDetour = 0;
DWORD ptrAddChatMessage = 0;
DWORD ptrProcessMessage = 0;
DWORD ptrRightClick = 0;
DWORD ptrLeftClick = 0;
DWORD ptrScriptExecute = 0;
DWORD ptrCastSpellByID = 0;
DWORD ptrAutoStoreAllLootItems = 0;
DWORD ptrOsGetAsyncTimeMs = 0;
DWORD ptrClearTarget = 0;
DWORD ptrCGInputControl__GetActive = 0;
DWORD ptrCGInputControl__SetControlBit = 0;
DWORD ptrg_HardwareEvent = 0;
DWORD ptrCurrentWorldFrame = 0;
DWORD offsetAntiAFK_1 = 0;
DWORD offsetAntiAFK_2 = 0;
#pragma data_seg ()

#pragma comment(linker,"/SECTION:.shared,RWS") 

int count = 0;
#ifdef debug_output
#include "WoW!PacketOpcodes.h"
#endif

// All the possible chat messages
#include "WoW!ChatMsgTypes.h"
typedef void (__fastcall *ADDCHATMESSAGE)(char const *, int, char const *, DWORD, char const *, char const *, char const *, DWORD, DWORD, DWORD);
ADDCHATMESSAGE Real_AddChatMessage = NULL;
void __fastcall Mine_AddChatMessage( char const *s1, int e, char const *s2, DWORD i1, char const *s3, char const *s4, char const *s5, DWORD i2, DWORD i3, DWORD i4)
{
	HANDLE hLogFile = NULL;
	
	char logline[1024] = {0};
	size_t len = 1024;

	char now[9];
	_strtime( now);

	char *MSG = (e <= 0x51) ? CHAT_MSG[e] : "UNKNOWN";
	_snprintf( logline, len, "[%s][%02X][%s]", now, e, MSG);
	len = 1024 - strlen( logline);

	if( s5 != 0 && s5[0] != 0)
	{
		_snprintf( &logline[1024 - len], len, "<%s>", s5);
		len = 1024 - strlen( logline);
	}
	if( s4 != 0 && s4[0] != 0)
	{
		_snprintf( &logline[1024 - len], len, "(%s)", s4);
		len = 1024 - strlen( logline);
	}
	if( s3 != 0 && s3[0] != 0)
	{
		_snprintf( &logline[1024 - len], len, "{%s}", s3);
		len = 1024 - strlen( logline);
	}
	if( s2 != 0 && s2[0] != 0)
	{
		_snprintf( &logline[1024 - len], len, "[%s]", s2);
		len = 1024 - strlen( logline);
	}
	if( s1 != 0 && s1[0] != 0)
	{
		_snprintf( &logline[1024 - len], len, ": %s", s1);
		len = 1024 - strlen( logline);
	}

	_snprintf( &logline[1024 - len], len, "\r\n");
	len = 1024 - strlen( logline);
	
	if( ReadAllLanguages)
		i1 = 0; // Language to 0, basicly enabling 'listen to all'

	hLogFile = CreateFile( ChatLog, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, NULL, NULL);
	if( hLogFile != INVALID_HANDLE_VALUE)
	{
		DWORD dNumWrt = 0;

		SetFilePointer( hLogFile, 0, 0, FILE_END);
		WriteFile( hLogFile, logline, (DWORD) 1024 - len, &dNumWrt, 0);
		CloseHandle( hLogFile);
	}

	return Real_AddChatMessage( s1, e, s2, i1, s3, s4, s5, i2, i3, i4);
}

FUNCTION_AT_ADDRESS( bool  __stdcall  _RightClick(WGUID guid), ptrRightClick);
FUNCTION_AT_ADDRESS( bool  __stdcall  _LeftClick(WGUID guid), ptrLeftClick);
FUNCTION_AT_ADDRESS( void  __stdcall  _AutoStoreAllLootItems(), ptrAutoStoreAllLootItems);
FUNCTION_AT_ADDRESS( void  __fastcall _ScriptExecute(char const *,char const *), ptrScriptExecute);
FUNCTION_AT_ADDRESS( void  __fastcall _Spell_C_CastSpellByID(int, int, int, int), ptrCastSpellByID);
FUNCTION_AT_ADDRESS( DWORD __stdcall  _OsGetAsyncTimeMs( void), ptrOsGetAsyncTimeMs);
FUNCTION_AT_ADDRESS( bool  __fastcall _ClearTarget(WGUID guid, int flag), ptrClearTarget);
FUNCTION_AT_ADDRESS( int   __fastcall _CGInputControl__GetActive(void), ptrCGInputControl__GetActive);
FUNCTION_AT_ADDRESS( void  __fastcall _CGInputControl__SetControlBit(int CGInputControl, int dummy, int input_control, int startstop, int time, int unknown), ptrCGInputControl__SetControlBit);

typedef void (__fastcall *RENDERWORLD)(void *);
RENDERWORLD Real_RenderWorld = NULL;
void __fastcall Mine_RenderWorld( void *p)
{
	if( Event != DoNothing)
	{
		if( Event == DoRightClick)
			_RightClick( Target);

		if( Event == DoLeftClick)
			_LeftClick( Target);

		if( Event == DoAutoStoreAllLootItems)
			_AutoStoreAllLootItems();

		if( Event == DoScriptExecute)
		{
			*(DWORD *)ptrg_HardwareEvent = 1;
			_ScriptExecute( Script, Script);
		}

		if( Event == DoCastSpellByID)
			_Spell_C_CastSpellByID( SpellId, 0, 0, 0);

		if( Event == DoClearTarget)
			_ClearTarget( Target, 0);	

		if( Event == DoStartMovement || Event == DoStopMovement || Event == DoTimedMovement)
		{
			int starttime = _OsGetAsyncTimeMs();
			int stoptime = starttime;
			int CGInputControl = _CGInputControl__GetActive();

			if( Event == DoTimedMovement) 
				stoptime += MovementTime;

			if( Event == DoStartMovement || Event == DoTimedMovement)
				_CGInputControl__SetControlBit( CGInputControl, 0, MovementBit, 1, starttime, 0);

			if( Event == DoStopMovement || Event == DoTimedMovement)
				_CGInputControl__SetControlBit( CGInputControl, 0, MovementBit, 0, stoptime, 0);
		}

		// These events dont need to increase the anti-afk timer
		if( Event == DoGetAsyncTimeMs)
		{
			AsyncTimeMs = _OsGetAsyncTimeMs();
		}
		else
		{
			// Get new AFK time
            int AsyncTimeMs = _OsGetAsyncTimeMs();

			// Update the Anti-AFK
			int ptrAntiAFK_1 = *(DWORD *)(ptrCurrentWorldFrame);
			int ptrAntiAFK_2 = *(DWORD *)(ptrAntiAFK_1 + offsetAntiAFK_1);
			*(DWORD *)(ptrAntiAFK_2 + offsetAntiAFK_2) = AsyncTimeMs;
		}

		Event = DoNothing;
	}

	return Real_RenderWorld( p);
}

// This checks if either of the addresses cross match
void DetourFunctions()
{
	Real_RenderWorld = (RENDERWORLD) DetourFunction( (PBYTE) ptrDetour, (PBYTE) Mine_RenderWorld);
	Real_AddChatMessage = (ADDCHATMESSAGE) DetourFunction( (PBYTE) ptrAddChatMessage, (PBYTE) Mine_AddChatMessage);
}

void RestoreFunctions()
{
	DetourRemove( (PBYTE) Real_RenderWorld, (PBYTE) Mine_RenderWorld);
	DetourRemove( (PBYTE) Real_AddChatMessage, (PBYTE) Mine_AddChatMessage);
}