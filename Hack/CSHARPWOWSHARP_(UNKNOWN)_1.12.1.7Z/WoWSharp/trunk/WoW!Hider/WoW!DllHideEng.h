//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------

#ifndef	_KNTIDLLHIDEENG_H
#define	_KNTIDLLHIDEENG_H

#define LOWCASE(a) ((a>='A' && a<='Z')?a-('Z'-'z'):a)
#define LOAD_ORDER_TYPE 0
#define MEM_ORDER_TYPE	1
#define INIT_ORDER_TYPE	2
#define FUNC_ERROR	0
#define FUNC_SUCCESS 1
#define BUFMAXLEN 512

int HideDll(char *szDllName, BOOL bHide);
int WalkModuleList(char ModuleListType, char *szDllToStrip);
int WalkModuleListAdd(char ModuleListType, char *szDllToStrip);
DWORD GetPEB(DWORD Pid);

extern "C" DWORD whImageBase;
extern "C" DWORD whImageSize;

#endif
