//------------------------------------------------------------------------------
//  <copyright from='2004' to='2005' company='WoWSharp.NET'>
//    Copyright (c) WoWSharp.NET. All Rights Reserved.
//
//    Please look in the accompanying license.htm file for the license that 
//    applies to this source code. (a copy can also be found at: 
//    http://www.wowsharp.net/license.htm)
//  </copyright>
//-------------------------------------------------------------------------------

#include <windows.h>
#include <time.h>
#include <stdlib.h>
#include <stdio.h>
#include "WoW!Process.h"
#include "WoW!DllHideEng.h"
#include "WoW!Execute.h"
#include "detours.h"
#include "Psapi.h"

typedef DWORD (WINAPI *NTQUERYSYSTEMINFORMATION)(DWORD SystemInformationClass, PVOID SystemInformation, ULONG SystemInformationLength, PULONG ReturnLength);
NTQUERYSYSTEMINFORMATION Real_NtQuerySystemInformation;
DWORD WINAPI Mine_NtQuerySystemInformation(DWORD SystemInformationClass, PVOID SystemInformation, ULONG SystemInformationLength, PULONG ReturnLength)
{
#ifdef debug_output
	char now[9];
	_strtime( now);

	char logline[1024] = {0};
	size_t len = 1024;

	_snprintf( logline, len, "[%s][00][WoW!Hider]NtQuerySystemInformation\r\n", now);
	HANDLE hLogFile = CreateFile( ChatLog, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, NULL, NULL);
	if( hLogFile != INVALID_HANDLE_VALUE)
	{
		DWORD dNumWrt = 0;

		SetFilePointer( hLogFile, 0, 0, FILE_END);
		WriteFile( hLogFile, logline, (DWORD) strlen( logline), &dNumWrt, 0);
		CloseHandle( hLogFile);
	}
#endif

	PSYSTEM_PROCESS_INFORMATION pSpiCurrent, pSpiPrec;
	char *pname = NULL;
	DWORD rc;	

	// 1st of all, get the return value of the function
	rc = Real_NtQuerySystemInformation(SystemInformationClass, SystemInformation, SystemInformationLength, ReturnLength);
	
	// if sucessfull, perform sorting
	if (rc == STATUS_SUCCESS)
	{
		// system info
		switch (SystemInformationClass)
		{
			// process list 
		case SystemProcessInformation:			
			pSpiCurrent = pSpiPrec = (PSYSTEM_PROCESS_INFORMATION) SystemInformation;
			DWORD pExplorerId = 0;
			
			while (1)
			{				
				// alloc memory to save process name in AINSI 8bits string charset
				pname = (char *) GlobalAlloc(GMEM_ZEROINIT, pSpiCurrent->ProcessName.Length + 2);
				if (pname == NULL) return (rc); // alloc failed ?
				
				// Convert unicode string to ainsi
				WideCharToMultiByte(CP_ACP, 0, pSpiCurrent->ProcessName.Buffer, pSpiCurrent->ProcessName.Length + 1, pname, pSpiCurrent->ProcessName.Length + 1, NULL, NULL);

				if( !_strnicmp((char*)pname, "Explorer.EXE", strlen("Explorer.EXE")))
					pExplorerId = pSpiCurrent->dUniqueProcessId;
				
				if(!_strnicmp((char*)pname, "WoW!", strlen("WoW!"))) // if "hidden" process
				{
					if (pname) GlobalFree(pname); // free process's name memory

					if (pSpiCurrent->NextEntryDelta == 0) {
						pSpiPrec->NextEntryDelta = 0;
						break;
					}
					else {
						pSpiPrec->NextEntryDelta += pSpiCurrent->NextEntryDelta;
						pSpiCurrent = (PSYSTEM_PROCESS_INFORMATION) ((PCHAR) pSpiCurrent + pSpiCurrent->NextEntryDelta);
					}
				}
				else
				{
					if (pname) GlobalFree(pname); // free process's name memory

					if (pSpiCurrent->NextEntryDelta == 0) break;
					pSpiPrec = pSpiCurrent;
					
					// Walk the list
					pSpiCurrent = (PSYSTEM_PROCESS_INFORMATION) ((PCHAR) pSpiCurrent + pSpiCurrent->NextEntryDelta);
				}
			} // while

			while (1)
			{				
				// alloc memory to save process name in AINSI 8bits string charset
				pname = (char *) GlobalAlloc(GMEM_ZEROINIT, pSpiCurrent->ProcessName.Length + 2);
				if (pname == NULL) return (rc); // alloc failed ?
				
				// Convert unicode string to ainsi
				WideCharToMultiByte(CP_ACP, 0, pSpiCurrent->ProcessName.Buffer, pSpiCurrent->ProcessName.Length + 1, pname, pSpiCurrent->ProcessName.Length + 1, NULL, NULL);

				if( !_strnicmp((char*)pname, "wow.exe", strlen("wow.exe")))
					pSpiCurrent->dParentProcessID = pExplorerId;
				
				if (pname) GlobalFree(pname); // free process's name memory

				if (pSpiCurrent->NextEntryDelta == 0) break;
				pSpiPrec = pSpiCurrent;
					
				// Walk the list
				pSpiCurrent = (PSYSTEM_PROCESS_INFORMATION) ((PCHAR) pSpiCurrent + pSpiCurrent->NextEntryDelta);
			} // while
			break;
		} // switch
	} // if
	
	return (rc);
}

typedef HWND (WINAPI *FINDWINDOW)( LPCTSTR lpClassName, LPCTSTR lpWindowName);

bool output;
FINDWINDOW Real_FindWindowA;
HWND WINAPI Mine_FindWindowA( LPCTSTR lpClassName, LPCTSTR lpWindowName)
{
#ifdef debug_output
	char now[9];
	_strtime( now);

	char logline[1024] = {0};
	size_t len = 1024;

	_snprintf( logline, len, "[%s][00][WoW!Hider]FindWindowA( %s, %s)\r\n", now, lpClassName == NULL ? "NULL" : lpClassName, lpWindowName == NULL ? "NULL" : lpWindowName);
	HANDLE hLogFile = CreateFile( ChatLog, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, NULL, NULL);
	if( hLogFile != INVALID_HANDLE_VALUE)
	{
		DWORD dNumWrt = 0;

		SetFilePointer( hLogFile, 0, 0, FILE_END);
		WriteFile( hLogFile, logline, (DWORD) strlen( logline), &dNumWrt, 0);
		CloseHandle( hLogFile);
	}
#endif

	if( lpWindowName != NULL)
	{
		HWND rc;
		if( !_strnicmp((char*)lpWindowName, "WoW!", strlen("WoW!")))
			rc = Real_FindWindowA( "FindThis~!@#$%", "WardenClient4tehwinz");
		else
			rc = Real_FindWindowA( lpClassName, lpWindowName);

		return rc;
	}
	else
		return Real_FindWindowA( lpClassName, lpWindowName);
}

FINDWINDOW Real_FindWindowW;
HWND WINAPI Mine_FindWindowW( LPCTSTR lpClassName, LPCTSTR lpWindowName)
{
#ifdef debug_output
	char now[9];
	_strtime( now);

	char logline[1024] = {0};
	size_t len = 1024;

	_snprintf( logline, len, "[%s][00][WoW!Hider]FindWindowW( %s, %s)\r\n", now, lpClassName == NULL ? "NULL" : lpClassName, lpWindowName == NULL ? "NULL" : lpWindowName);
	HANDLE hLogFile = CreateFile( ChatLog, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, NULL, NULL);
	if( hLogFile != INVALID_HANDLE_VALUE)
	{
		DWORD dNumWrt = 0;

		SetFilePointer( hLogFile, 0, 0, FILE_END);
		WriteFile( hLogFile, logline, (DWORD) strlen( logline), &dNumWrt, 0);
		CloseHandle( hLogFile);
	}
#endif

	char *pname = NULL;
	if( lpWindowName != NULL)
	{	// alloc memory to save process name in AINSI 8bits string charset
		pname = (char *) GlobalAlloc(GMEM_ZEROINIT, wcslen( (wchar_t *)lpWindowName) + 2);
		if (pname == NULL) return Real_FindWindowW( "FindThis~!@#$%", "WardenClient4tehwinz"); // alloc failed ?

		// Convert unicode string to ainsi
		WideCharToMultiByte(CP_ACP, 0, (LPCWSTR) lpWindowName, (int) wcslen( (wchar_t *)lpWindowName) + 1, pname, (int) wcslen( (wchar_t *)lpWindowName) + 1, NULL, NULL);

		HWND rc;
		if( !_strnicmp((char*)pname, "WoW!", strlen("WoW!")))
			rc = Real_FindWindowW( "FindThis~!@#$%", "WardenClient4tehwinz");
		else
			rc = Real_FindWindowW( lpClassName, lpWindowName);

		if (pname) GlobalFree(pname); // free process's name memory

		return rc;
	}
	else
		return Real_FindWindowW( lpClassName, lpWindowName);
}

typedef HWND (WINAPI *FINDWINDOWEX)( DWORD hwndParent, DWORD hwndChildAfter, LPCTSTR lpClassName, LPCTSTR lpWindowName);

FINDWINDOWEX Real_FindWindowExA;
HWND WINAPI Mine_FindWindowExA( DWORD hwndParent, DWORD hwndChildAfter, LPCTSTR lpClassName, LPCTSTR lpWindowName)
{
#ifdef debug_output
	char now[9];
	_strtime( now);

	char logline[1024] = {0};
	size_t len = 1024;

	_snprintf( logline, len, "[%s][00][WoW!Hider]FindWindowExA( %i, %i, %s, %s)\r\n", now, hwndParent, hwndChildAfter, lpClassName == NULL ? "NULL" : lpClassName, lpWindowName == NULL ? "NULL" : lpWindowName);
	HANDLE hLogFile = CreateFile( ChatLog, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, NULL, NULL);
	if( hLogFile != INVALID_HANDLE_VALUE)
	{
		DWORD dNumWrt = 0;

		SetFilePointer( hLogFile, 0, 0, FILE_END);
		WriteFile( hLogFile, logline, (DWORD) strlen( logline), &dNumWrt, 0);
		CloseHandle( hLogFile);
	}
#endif

	if( lpWindowName != NULL)
	{
		HWND rc;
		if( !_strnicmp((char*)lpWindowName, "WoW!", strlen("WoW!")))
			rc = Real_FindWindowExA( hwndParent, hwndChildAfter, "FindThis~!@#$%", "WardenClient4tehwinz");
		else
			rc = Real_FindWindowExA( hwndParent, hwndChildAfter, lpClassName, lpWindowName);

		return rc;
	}
	else
		return Real_FindWindowExA( hwndParent, hwndChildAfter, lpClassName, lpWindowName);
}

FINDWINDOWEX Real_FindWindowExW;
HWND WINAPI Mine_FindWindowExW( DWORD hwndParent, DWORD hwndChildAfter, LPCTSTR lpClassName, LPCTSTR lpWindowName)
{
#ifdef debug_output
	char now[9];
	_strtime( now);

	char logline[1024] = {0};
	size_t len = 1024;

	_snprintf( logline, len, "[%s][00][WoW!Hider]FindWindowExW( %i, %i, %s, %s)\r\n", now, hwndParent, hwndChildAfter, lpClassName == NULL ? "NULL" : lpClassName, lpWindowName == NULL ? "NULL" : lpWindowName);
	HANDLE hLogFile = CreateFile( ChatLog, GENERIC_WRITE | GENERIC_READ, FILE_SHARE_READ, NULL, OPEN_ALWAYS, NULL, NULL);
	if( hLogFile != INVALID_HANDLE_VALUE)
	{
		DWORD dNumWrt = 0;

		SetFilePointer( hLogFile, 0, 0, FILE_END);
		WriteFile( hLogFile, logline, (DWORD) strlen( logline), &dNumWrt, 0);
		CloseHandle( hLogFile);
	}
#endif

	char *pname = NULL;
	if( lpWindowName != NULL)
	{	// alloc memory to save process name in AINSI 8bits string charsetw
		pname = (char *) GlobalAlloc(GMEM_ZEROINIT, wcslen( (wchar_t *) lpWindowName) + 2);
		if (pname == NULL) return Real_FindWindowExW( hwndParent, hwndChildAfter, "FindThis~!@#$%", "WardenClient4tehwinz"); // alloc failed ?

		// Convert unicode string to ainsi
		WideCharToMultiByte(CP_ACP, 0, (LPCWSTR)lpWindowName, (int) wcslen( (wchar_t *)lpWindowName) + 1, pname, (int) wcslen( (wchar_t *)lpWindowName) + 1, NULL, NULL);

		HWND rc;
		if( !_strnicmp((char*)pname, "WoW!", strlen("WoW!")))
			rc = Real_FindWindowExW( hwndParent, hwndChildAfter, "FindThis~!@#$%", "WardenClient4tehwinz");
		else
			rc = Real_FindWindowExW( hwndParent, hwndChildAfter, lpClassName, lpWindowName);

		if (pname) GlobalFree(pname); // free process's name memory

		return rc;
	}
	else
		return Real_FindWindowExW( hwndParent, hwndChildAfter, lpClassName, lpWindowName);
}

DWORD aNtQuerySystemInformation = 0;
DWORD aFindWindowA = 0;
DWORD aFindWindowW = 0;
DWORD aFindWindowExA = 0;
DWORD aFindWindowExW = 0;

DETOUR_TRAMPOLINE(BOOL __stdcall Real_GetWindowTextA( HWND hWnd, LPSTR lpString, int nMaxCount), GetWindowTextA);
BOOL __stdcall Mine_GetWindowTextA( HWND hWnd, LPSTR lpString, int nMaxCount)
{
	char *text = (char *) GlobalAlloc( GMEM_ZEROINIT, nMaxCount);
	if( text == NULL) return 0;

	int len = Real_GetWindowTextA( hWnd, text, nMaxCount);
	if( len != 0)
	{
		if( _strnicmp( text, "WoW!", strlen("WoW!")))
			strncpy( lpString, text, strlen( text));
		else
		{
			lpString[0] = 0;
			len = 0;
		}
	}

	GlobalFree( text);
	return len;
}

DETOUR_TRAMPOLINE(BOOL __stdcall Real_GetWindowTextW( HWND hWnd, LPWSTR lpString, int nMaxCount), GetWindowTextW);
BOOL __stdcall Mine_GetWindowTextW( HWND hWnd, LPWSTR lpString, int nMaxCount)
{
	wchar_t *text = (wchar_t *) GlobalAlloc( GMEM_ZEROINIT, nMaxCount * sizeof( wchar_t));
	if( text == NULL) return 0;

	int len = Real_GetWindowTextW( hWnd, lpString, nMaxCount);
	if( len != 0)
	{
		if( _wcsnicmp( text, L"WoW!", wcslen(L"WoW!")))
			wcsncpy( lpString, text, wcslen( text));
		else
		{
			lpString[0] = 0;
			len = 0;
		}
	}

	GlobalFree( text);
	return len;
}

DETOUR_TRAMPOLINE(int __stdcall Real_GetWindowTextLength( HWND hWnd), GetWindowTextLength);
int __stdcall Mine_GetWindowTextLength( HWND hWnd)
{
	char text[64];
	if( Real_GetWindowTextA( hWnd, text, 64))
		if( !_strnicmp( text, "WoW!", strlen("WoW!")))
			return (int) 0;

	return Real_GetWindowTextLength( hWnd);
}

DETOUR_TRAMPOLINE(SIZE_T __stdcall Real_VirtualQuery( LPCVOID lpAddress, PMEMORY_BASIC_INFORMATION lpBuffer, SIZE_T dwLength), VirtualQuery);
SIZE_T __stdcall Mine_VirtualQuery( LPCVOID lpAddress, PMEMORY_BASIC_INFORMATION lpBuffer, SIZE_T dwLength)
{
	SIZE_T result = Real_VirtualQuery( lpAddress, lpBuffer, dwLength);

	if( (((DWORD)lpBuffer->BaseAddress) + lpBuffer->RegionSize) == whImageBase)
		lpBuffer->RegionSize += whImageSize;

	return result;
}

DETOUR_TRAMPOLINE(SIZE_T __stdcall Real_VirtualQueryEx( HANDLE hProcess, LPCVOID lpAddress, PMEMORY_BASIC_INFORMATION lpBuffer, SIZE_T dwLength), VirtualQueryEx);
SIZE_T __stdcall Mine_VirtualQueryEx( HANDLE hProcess, LPCVOID lpAddress, PMEMORY_BASIC_INFORMATION lpBuffer, SIZE_T dwLength)
{
	SIZE_T result = Real_VirtualQueryEx( hProcess, lpAddress, lpBuffer, dwLength);

	if( (((DWORD)lpBuffer->BaseAddress) + lpBuffer->RegionSize) == whImageBase)
		lpBuffer->RegionSize += whImageSize;

	return result;
}

BOOL APIENTRY DllMain( HANDLE hModule, DWORD  ul_reason_for_call, LPVOID lpReserved)
{
    char szParentEXEName[MAX_PATH] = {0};
    char szModuleName[MAX_PATH] = {0}; 

	GetModuleFileName( (HMODULE)hModule, szModuleName, MAX_PATH);
	GetModuleFileName( 0, szParentEXEName, MAX_PATH); 

	char *pEXEName = strrchr(szParentEXEName, '\\');
	bool should_attach = stricmp(pEXEName, "\\wow.exe") == 0;

	if( (ul_reason_for_call == DLL_PROCESS_ATTACH) && should_attach)
	{
		HideDll( "wow!hider.dll", true);

		aNtQuerySystemInformation = (DWORD) GetProcAddress( GetModuleHandle("ntdll.dll"), "NtQuerySystemInformation");
		Real_NtQuerySystemInformation = (NTQUERYSYSTEMINFORMATION) DetourFunction( (PBYTE) aNtQuerySystemInformation, (PBYTE) Mine_NtQuerySystemInformation);
		aFindWindowA = (DWORD) GetProcAddress( GetModuleHandle( "user32.dll"), "FindWindowA");
		Real_FindWindowA = (FINDWINDOW) DetourFunction( (PBYTE) aFindWindowA, (PBYTE) Mine_FindWindowA);
		aFindWindowW = (DWORD) GetProcAddress( GetModuleHandle( "user32.dll"), "FindWindowW");
		Real_FindWindowW = (FINDWINDOW) DetourFunction( (PBYTE) aFindWindowW, (PBYTE) Mine_FindWindowW);
		aFindWindowExA = (DWORD) GetProcAddress( GetModuleHandle( "user32.dll"), "FindWindowExA");
		Real_FindWindowExA = (FINDWINDOWEX) DetourFunction( (PBYTE) aFindWindowExA, (PBYTE) Mine_FindWindowExA);
		aFindWindowExW = (DWORD) GetProcAddress( GetModuleHandle( "user32.dll"), "FindWindowExW");
		Real_FindWindowExW = (FINDWINDOWEX) DetourFunction( (PBYTE) aFindWindowExW, (PBYTE) Mine_FindWindowExW);

		DetourFunctionWithTrampoline( (PBYTE)Real_GetWindowTextA, (PBYTE)Mine_GetWindowTextA);
		DetourFunctionWithTrampoline( (PBYTE)Real_GetWindowTextW, (PBYTE)Mine_GetWindowTextW);
		DetourFunctionWithTrampoline( (PBYTE)Real_GetWindowTextLength, (PBYTE)Mine_GetWindowTextLength);

		DetourFunctionWithTrampoline( (PBYTE)Real_VirtualQuery, (PBYTE)Mine_VirtualQuery);
		DetourFunctionWithTrampoline( (PBYTE)Real_VirtualQueryEx, (PBYTE)Mine_VirtualQueryEx);

		DetourFunctions();
	}

    return TRUE;
}