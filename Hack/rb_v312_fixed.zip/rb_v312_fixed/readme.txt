Realm Bot 3.11 ReadMe

For this version to optimally work, a file named whisper_respones.txt, and Alarm.wav must reside in the same folder as your RB.exe program.  Whisper_responses.txt is a custom file y ou can create that contains up to 50 lines of responses that RB will draw from when replying to incoming whispers.  Additionally, whenever a whisper is received, Alarm.wav will play.  

AFKLog is an automatically generated file that RB will overwrite each time you start the program.  This log will contain a full record of everything displayed in your console.  please note that whenever you start RB, any existing AFKLog.log will be overwritten so if you want to back these up, you should do so before you start the program or after each AFK session.   


