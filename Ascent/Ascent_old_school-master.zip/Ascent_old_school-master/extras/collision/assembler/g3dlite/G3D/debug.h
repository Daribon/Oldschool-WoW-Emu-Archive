
#ifndef G3D_LITE_DEBUG_H
#define G3D_LITE_DEBUG_H

#define debugAssert(x)
#define debugAssertM(x, y)
#define alwaysAssertM(x, y)

#endif

