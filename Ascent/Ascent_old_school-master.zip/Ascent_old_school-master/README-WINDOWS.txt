Ascent Win32/64 Installation Instructions
=========================================

Download the ascent-windows-libraries.zip distribution from www.ascentemu.com.
http://www.ascentemu.com/ascent-windows-libraries.zip

Mirrors:
http://filebeam.com/44c5ae2aa19266452590eab37b04218c
http://rapidshare.com/files/99571783/ascent-windows-libraries.zip.html

Extract this file, and follow the instructions contained within.
Build as normal.
