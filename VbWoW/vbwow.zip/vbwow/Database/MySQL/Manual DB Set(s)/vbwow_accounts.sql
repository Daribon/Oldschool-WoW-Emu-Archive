/*
MySQL Backup
Source Host:           localhost
Source Server Version: 4.1.8-nt
Source Database:       vbwowdb
Date:                  2006.07.14 11:35:54
*/

SET FOREIGN_KEY_CHECKS=0;
use `vbwowdb`;

CREATE TABLE `vbwow_accounts` (
  `account` varchar(30) NOT NULL default '',
  `password` varchar(30) NOT NULL default '',
  `plevel` tinyint(1) unsigned NOT NULL default '0',
  `email` varchar(50) NOT NULL default '',
  `joindate` varchar(10) NOT NULL default '00-00-0000',
  `last_sshash` varchar(90) NOT NULL default '',
  `last_ip` varchar(15) NOT NULL default '',
  `last_login` varchar(100) NOT NULL default '0000-00-00',
  `banned` tinyint(1) unsigned NOT NULL default '0',
  `expansion` tinyint(1) unsigned NOT NULL default '1',
  `account_id` mediumint(3) NOT NULL auto_increment,
  PRIMARY KEY  (`account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

insert  into `vbwow_accounts`(`account`,`password`,`plevel`,`email`,`joindate`,`last_sshash`,`last_ip`,`last_login`,`banned`,`expansion`,`account_id`) values ('vbwow','test',2,'admin@vbwow.org','00-00-0000','','127.0.0.1','0000-00-00',0,1,1);
