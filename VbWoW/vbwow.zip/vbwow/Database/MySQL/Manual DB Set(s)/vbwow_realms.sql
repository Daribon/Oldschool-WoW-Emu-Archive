/*
MySQL Backup
Source Host:           localhost
Source Server Version: 4.1.8-nt
Source Database:       vbwowdb
Date:                  2006.07.14 11:39:59
*/

SET FOREIGN_KEY_CHECKS=0;
use vbwowdb;
#----------------------------
# Table structure for vbwow_realms
#----------------------------
CREATE TABLE `vbwow_realms` (
  `ws_name` varchar(50) NOT NULL default '',
  `ws_host` varchar(50) NOT NULL default '',
  `ws_port` int(5) NOT NULL default '0',
  `ws_status` tinyint(3) unsigned NOT NULL default '0',
  `ws_id` tinyint(3) unsigned NOT NULL default '0',
  `ws_type` tinyint(3) unsigned NOT NULL default '0',
  `ws_population` float(3,0) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ws_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;
#----------------------------
# Records for table vbwow_realms
#----------------------------


insert  into vbwow_realms values 
('vbWoW', '127.0.0.1', 8085, 0, 0, 0, '0'), 
