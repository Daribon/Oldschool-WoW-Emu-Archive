/*
MySQL Backup
Source Host:           localhost
Source Server Version: 4.1.8-nt
Source Database:       vbwowdb
Date:                  2006.07.14 11:35:54
*/

create database if not exists `vbwowdb`;

USE `vbwowdb`;

/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;

/*Table structure for table `tmpspawnedcoprses` */

DROP TABLE IF EXISTS `tmpspawnedcoprses`;

CREATE TABLE `tmpspawnedcoprses` (
  `corpse_guid` bigint(20) NOT NULL default '0',
  `corpse_owner` bigint(20) NOT NULL default '0',
  `corpse_positionX` double NOT NULL default '0',
  `corpse_positionY` double NOT NULL default '0',
  `corpse_positionZ` double NOT NULL default '0',
  `corpse_orientation` double NOT NULL default '0',
  `corpse_mapId` smallint(6) NOT NULL default '0',
  `corpse_bytes1` int(11) NOT NULL default '0',
  `corpse_bytes2` int(11) NOT NULL default '0',
  `corpse_model` smallint(6) NOT NULL default '0',
  `corpse_guild` smallint(6) NOT NULL default '0',
  `corpse_items` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`corpse_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `tmpspawnedcoprses` */

/*Table structure for table `tmpspawnedcreatures` */

DROP TABLE IF EXISTS `tmpspawnedcreatures`;

CREATE TABLE `tmpspawnedcreatures` (
  `spawned_guid` bigint(20) NOT NULL default '0',
  `spawned_positionX` double default NULL,
  `spawned_positionY` double default NULL,
  `spawned_positionZ` double default NULL,
  `spawned_orientation` double default NULL,
  `spawned_map` smallint(2) default NULL,
  `spawned_entry` mediumint(2) default NULL,
  `spawn_id` mediumint(9) default NULL,
  PRIMARY KEY  (`spawned_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `tmpspawnedcreatures` */

/*Table structure for table `tmpspawnedgameobjects` */

DROP TABLE IF EXISTS `tmpspawnedgameobjects`;

CREATE TABLE `tmpspawnedgameobjects` (
  `gameObject_guid` bigint(20) NOT NULL default '0',
  `gameObject_entry` mediumint(6) NOT NULL default '0',
  `gameObject_rotation1` double NOT NULL default '0',
  `gameObject_rotation2` double NOT NULL default '0',
  `gameObject_rotation3` double NOT NULL default '0',
  `gameObject_rotation4` double NOT NULL default '0',
  `gameObject_positionX` double NOT NULL default '0',
  `gameObject_positionY` double NOT NULL default '0',
  `gameObject_positionZ` double NOT NULL default '0',
  `gameObject_orientation` double NOT NULL default '0',
  `gameObject_map` smallint(6) NOT NULL default '0',
  `gameObject_spawnId` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`gameObject_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `tmpspawnedgameobjects` */

/*Table structure for table `vbwow_accounts` */

DROP TABLE IF EXISTS `vbwow_accounts`;

CREATE TABLE `vbwow_accounts` (
  `account` varchar(30) NOT NULL default '',
  `password` varchar(30) NOT NULL default '',
  `plevel` tinyint(1) unsigned NOT NULL default '0',
  `email` varchar(50) NOT NULL default '',
  `joindate` varchar(10) NOT NULL default '00-00-0000',
  `last_sshash` varchar(90) NOT NULL default '',
  `last_ip` varchar(15) NOT NULL default '',
  `last_login` varchar(100) NOT NULL default '0000-00-00',
  `banned` tinyint(1) unsigned NOT NULL default '0',
  `expansion` tinyint(1) unsigned NOT NULL default '1',
  `account_id` mediumint(3) NOT NULL auto_increment,
  PRIMARY KEY  (`account_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_accounts` */

insert  into `vbwow_accounts`(`account`,`password`,`plevel`,`email`,`joindate`,`last_sshash`,`last_ip`,`last_login`,`banned`,`expansion`,`account_id`) values ('vbwow','test',2,'admin@vbwow.org','00-00-0000','','127.0.0.1','0000-00-00',0,1,1);

/*Table structure for table `vbwow_addonsinfo` */

DROP TABLE IF EXISTS `vbwow_addonsinfo`;

CREATE TABLE `vbwow_addonsinfo` (
  `id` smallint(6) NOT NULL auto_increment,
  `addOn_Name` varchar(255) NOT NULL default '',
  `addOn_Key` bigint(20) NOT NULL default '0',
  `addOn_State` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=12 DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_addonsinfo` */

insert  into `vbwow_addonsinfo`(`id`,`addOn_Name`,`addOn_Key`,`addOn_State`) values (1,'Blizzard_AuctionUI',0,2),(2,'Blizzard_BattlefieldMinimap',0,2),(3,'Blizzard_BindingUI',0,2),(4,'Blizzard_CraftUI',0,2),(5,'Blizzard_InspectUI',0,2),(6,'Blizzard_MacroUI',0,2),(7,'Blizzard_RaidUI',0,2),(8,'Blizzard_TalentUI',0,2),(9,'Blizzard_TradeSkillUI',0,2),(10,'Blizzard_TrainerUI',0,2),(11,'LootLink',0,1);

/*Table structure for table `vbwow_auctionhouse` */

DROP TABLE IF EXISTS `vbwow_auctionhouse`;

CREATE TABLE `vbwow_auctionhouse` (
  `auction_id` int(11) NOT NULL auto_increment,
  `auction_bid` int(11) NOT NULL,
  `auction_buyout` int(11) NOT NULL,
  `auction_timeleft` int(11) NOT NULL,
  `auction_bidder` int(11) NOT NULL default '0',
  `auction_owner` int(11) NOT NULL,
  `auction_itemId` mediumint(11) NOT NULL,
  `auction_itemCount` tinyint(4) unsigned NOT NULL default '1',
  `auction_itemGUID` int(11) NOT NULL,
  PRIMARY KEY  (`auction_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_auctionhouse` */

/*Table structure for table `vbwow_bans` */

DROP TABLE IF EXISTS `vbwow_bans`;

CREATE TABLE `vbwow_bans` (
  `ip` varchar(100) NOT NULL default '',
  `date` date default '0000-00-00',
  `reason` varchar(100) default NULL,
  `who` varchar(100) default NULL,
  PRIMARY KEY  (`ip`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_bans` */

/*Table structure for table `vbwow_characters` */

DROP TABLE IF EXISTS `vbwow_characters`;

CREATE TABLE `vbwow_characters` (
  `account_id` mediumint(3) unsigned NOT NULL default '0',
  `char_guid` int(8) NOT NULL auto_increment,
  `char_name` varchar(21) NOT NULL default '',
  `char_level` tinyint(1) unsigned NOT NULL default '0',
  `char_xp` mediumint(3) NOT NULL default '0',
  `char_access` tinyint(1) unsigned NOT NULL default '0',
  `char_online` tinyint(1) unsigned NOT NULL default '0',
  `char_positionX` float NOT NULL default '0',
  `char_positionY` float NOT NULL default '0',
  `char_positionZ` float NOT NULL default '0',
  `char_map_id` smallint(2) NOT NULL default '0',
  `char_zone_id` smallint(2) NOT NULL default '0',
  `char_orientation` float NOT NULL default '0',
  `char_model` smallint(2) NOT NULL default '0',
  `bindpoint_positionX` float NOT NULL default '0',
  `bindpoint_positionY` float NOT NULL default '0',
  `bindpoint_positionZ` float NOT NULL default '0',
  `bindpoint_map_id` smallint(2) NOT NULL default '0',
  `bindpoint_zone_id` smallint(2) NOT NULL default '0',
  `char_guildId` int(1) NOT NULL default '0',
  `char_guildRank` tinyint(1) unsigned NOT NULL default '0',
  `char_guildPNote` varchar(255) NOT NULL default '',
  `char_guildOffNote` varchar(255) NOT NULL default '',
  `char_race` tinyint(1) unsigned NOT NULL default '0',
  `char_class` tinyint(1) unsigned NOT NULL default '0',
  `char_gender` tinyint(1) unsigned NOT NULL default '0',
  `char_skin` tinyint(1) unsigned NOT NULL default '0',
  `char_face` tinyint(1) unsigned NOT NULL default '0',
  `char_hairStyle` tinyint(1) unsigned NOT NULL default '0',
  `char_hairColor` tinyint(1) unsigned NOT NULL default '0',
  `char_facialHair` tinyint(1) unsigned NOT NULL default '0',
  `char_outfitId` tinyint(1) unsigned NOT NULL default '0',
  `char_restState` tinyint(1) unsigned NOT NULL default '0',
  `char_mana` smallint(2) NOT NULL default '1',
  `char_energy` smallint(2) NOT NULL default '0',
  `char_rage` smallint(2) NOT NULL default '0',
  `char_life` smallint(2) NOT NULL default '1',
  `char_manaType` tinyint(1) unsigned NOT NULL default '0',
  `char_strength` tinyint(1) unsigned NOT NULL default '0',
  `char_agility` tinyint(1) unsigned NOT NULL default '0',
  `char_stamina` tinyint(1) unsigned NOT NULL default '0',
  `char_intellect` tinyint(1) unsigned NOT NULL default '0',
  `char_spirit` tinyint(1) unsigned NOT NULL default '0',
  `char_copper` mediumint(3) NOT NULL default '0',
  `char_watchedFactionIndex` tinyint(1) unsigned NOT NULL default '255',
  `char_reputation` text NOT NULL,
  `char_spellList` varchar(255) NOT NULL default '',
  `char_skillList` varchar(255) NOT NULL default '',
  `char_frendList` varchar(255) NOT NULL default '',
  `char_ignoreList` varchar(255) NOT NULL default '',
  `char_tutorialFlags` varchar(255) NOT NULL default '',
  `char_actionBar` varchar(255) NOT NULL default '',
  `char_mapExplored` varchar(255) NOT NULL default '',
  `force_restrictions` tinyint(1) unsigned NOT NULL default '0',
  `char_talentPoints` tinyint(1) unsigned NOT NULL default '0',
  `char_bankSlots` tinyint(1) unsigned NOT NULL default '0',
  PRIMARY KEY  (`char_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_characters` */

/*Table structure for table `vbwow_characters_honor` */

DROP TABLE IF EXISTS `vbwow_characters_honor`;

CREATE TABLE `vbwow_characters_honor` (
  `char_guid` bigint(20) NOT NULL default '0',
  `arena_currency` smallint(6) NOT NULL default '0',
  `honor_currency` smallint(6) NOT NULL default '0',
  `honor_title` tinyint(3) unsigned NOT NULL default '0',
  `honor_knownTitles` smallint(4) NOT NULL default '0',
  `honor_killsToday` smallint(11) NOT NULL default '0',
  `honor_killsYesterday` smallint(11) NOT NULL default '0',
  `honor_pointsToday` smallint(11) NOT NULL default '0',
  `honor_pointsYesterday` smallint(11) NOT NULL default '0',
  `honor_kills` mediumint(11) NOT NULL default '0',
  PRIMARY KEY  (`char_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_characters_honor` */

/*Table structure for table `vbwow_characters_inventory` */

DROP TABLE IF EXISTS `vbwow_characters_inventory`;

CREATE TABLE `vbwow_characters_inventory` (
  `item_guid` bigint(8) NOT NULL default '0',
  `item_id` smallint(2) NOT NULL default '0',
  `item_slot` tinyint(6) unsigned NOT NULL default '255',
  `item_bag` bigint(8) NOT NULL default '-1',
  `item_owner` bigint(8) NOT NULL default '0',
  `item_creator` bigint(8) NOT NULL default '0',
  `item_giftCreator` bigint(8) NOT NULL default '0',
  `item_stackCount` tinyint(1) unsigned NOT NULL default '0',
  `item_durability` smallint(2) NOT NULL default '0',
  `item_flags` smallint(11) NOT NULL default '0',
  `item_chargesLeft` tinyint(1) unsigned NOT NULL default '0',
  `item_textId` smallint(6) NOT NULL default '0',
  `item_enchantment` varchar(255) NOT NULL default '',
  `item_random_properties` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`item_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_characters_inventory` */

/*Table structure for table `vbwow_characters_mail` */

DROP TABLE IF EXISTS `vbwow_characters_mail`;

CREATE TABLE `vbwow_characters_mail` (
  `mail_id` smallint(5) NOT NULL auto_increment,
  `mail_sender` bigint(20) NOT NULL default '0',
  `mail_receiver` bigint(20) NOT NULL default '0',
  `mail_type` tinyint(3) unsigned NOT NULL default '0',
  `mail_stationery` smallint(4) NOT NULL default '41',
  `mail_subject` varchar(255) NOT NULL default '',
  `mail_body` varchar(255) NOT NULL default '',
  `mail_item_guid` bigint(20) NOT NULL default '0',
  `mail_money` int(6) NOT NULL default '0',
  `mail_COD` smallint(6) NOT NULL default '0',
  `mail_time` smallint(6) NOT NULL default '30',
  `mail_read` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`mail_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_characters_mail` */

/*Table structure for table `vbwow_characters_quests` */

DROP TABLE IF EXISTS `vbwow_characters_quests`;

CREATE TABLE `vbwow_characters_quests` (
  `id` int(11) NOT NULL auto_increment,
  `char_guid` bigint(20) NOT NULL default '0',
  `quest_id` int(11) NOT NULL default '0',
  `quest_status` int(5) NOT NULL default '0',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_characters_quests` */

/*Table structure for table `vbwow_characters_tickets` */

DROP TABLE IF EXISTS `vbwow_characters_tickets`;

CREATE TABLE `vbwow_characters_tickets` (
  `char_guid` bigint(20) NOT NULL default '0',
  `ticket_text` text NOT NULL,
  `ticket_category` tinyint(3) unsigned NOT NULL default '0',
  PRIMARY KEY  (`char_guid`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_characters_tickets` */

/*Table structure for table `vbwow_creatures` */

DROP TABLE IF EXISTS `vbwow_creatures`;

CREATE TABLE `vbwow_creatures` (
  `creature_id` mediumint(2) NOT NULL default '0',
  `creature_name` varchar(100) NOT NULL default '',
  `creature_guild` varchar(100) NOT NULL default '',
  `creature_model` mediumint(3) NOT NULL default '0',
  `creature_size` double NOT NULL default '0',
  `creature_life` smallint(2) NOT NULL default '0',
  `creature_mana` smallint(2) NOT NULL default '0',
  `creature_manaType` tinyint(1) unsigned NOT NULL default '0',
  `creature_elite` tinyint(1) unsigned NOT NULL default '0',
  `creature_faction` smallint(2) NOT NULL default '0',
  `creature_family` tinyint(1) unsigned NOT NULL default '0',
  `creature_type` tinyint(1) unsigned NOT NULL default '0',
  `creature_minDamage` double NOT NULL default '0',
  `creature_maxDamage` double NOT NULL default '0',
  `creature_minRangedDamage` double NOT NULL default '0',
  `creature_maxRangedDamage` double NOT NULL default '0',
  `creature_attackPower` smallint(2) NOT NULL default '0',
  `creature_rangedAttackPower` smallint(2) NOT NULL default '0',
  `creature_armor` tinyint(3) unsigned NOT NULL default '0',
  `creature_resHoly` tinyint(3) unsigned NOT NULL default '0',
  `creature_resFire` tinyint(3) unsigned NOT NULL default '0',
  `creature_resNature` tinyint(3) unsigned NOT NULL default '0',
  `creature_resFrost` tinyint(3) unsigned NOT NULL default '0',
  `creature_resShadow` tinyint(3) unsigned NOT NULL default '0',
  `creature_resArcane` tinyint(3) unsigned NOT NULL default '0',
  `creature_walkSpeed` double NOT NULL default '0',
  `creature_runSpeed` double NOT NULL default '0',
  `creature_baseAttackSpeed` smallint(2) NOT NULL default '0',
  `creature_baseRangedAttackSpeed` smallint(2) NOT NULL default '0',
  `creature_combatReach` double NOT NULL default '0',
  `creature_bondingRadius` double NOT NULL default '0',
  `creature_npcFlags` smallint(1) NOT NULL default '0',
  `creature_flags` mediumint(3) NOT NULL default '0',
  `creature_minLevel` tinyint(1) unsigned NOT NULL default '0',
  `creature_maxLevel` tinyint(1) unsigned NOT NULL default '0',
  `creature_loot` smallint(6) NOT NULL default '0',
  `creature_lootSkinning` smallint(6) NOT NULL default '0',
  `creature_sell` smallint(6) NOT NULL default '0',
  `creature_aiScript` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`creature_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_creatures` */

/*Table structure for table `vbwow_gameobjects` */

DROP TABLE IF EXISTS `vbwow_gameobjects`;

CREATE TABLE `vbwow_gameobjects` (
  `gameObject_ID` mediumint(6) NOT NULL default '0',
  `gameObject_Size` double NOT NULL default '0',
  `gameObject_Model` smallint(6) NOT NULL default '0',
  `gameObject_Flags` smallint(6) NOT NULL default '0',
  `gameObject_Name` varchar(255) NOT NULL default '',
  `gameObject_Type` tinyint(3) unsigned NOT NULL default '0',
  `gameObject_Faction` mediumint(6) NOT NULL default '0',
  `gameObject_Sound0` mediumint(6) NOT NULL default '0',
  `gameObject_Sound1` mediumint(6) NOT NULL default '0',
  `gameObject_Sound2` mediumint(6) NOT NULL default '0',
  `gameObject_Sound3` mediumint(6) NOT NULL default '0',
  `gameObject_Sound4` mediumint(6) NOT NULL default '0',
  `gameObject_Sound5` mediumint(6) NOT NULL default '0',
  `gameObject_Sound6` mediumint(6) NOT NULL default '0',
  `gameObject_Sound7` mediumint(6) NOT NULL default '0',
  `gameObject_Sound8` mediumint(6) NOT NULL default '0',
  `gameObject_Sound9` mediumint(6) NOT NULL default '0',
  `gameObject_Loot` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`gameObject_ID`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_gameobjects` */

insert  into `vbwow_gameobjects`(`gameObject_ID`,`gameObject_Size`,`gameObject_Model`,`gameObject_Flags`,`gameObject_Name`,`gameObject_Type`,`gameObject_Faction`,`gameObject_Sound0`,`gameObject_Sound1`,`gameObject_Sound2`,`gameObject_Sound3`,`gameObject_Sound4`,`gameObject_Sound5`,`gameObject_Sound6`,`gameObject_Sound7`,`gameObject_Sound8`,`gameObject_Sound9`,`gameObject_Loot`) values (21680,1,787,0,'Duel Flag',16,4,0,0,0,0,0,0,0,0,0,0,0),(35591,1,668,0,'Fishing Bobber',17,6,0,0,0,0,0,0,0,0,0,0,0);

/*Table structure for table `vbwow_guilds_petition` */

DROP TABLE IF EXISTS `vbwow_guilds_petition`;

CREATE TABLE `vbwow_guilds_petition` (
  `petition_id` int(11) NOT NULL,
  `petition_itemGuid` int(11) NOT NULL,
  `petition_owner` int(11) NOT NULL,
  `petition_name` varchar(255) NOT NULL,
  `petition_signedMembers` tinyint(3) unsigned NOT NULL,
  `petition_signedMember1` int(11) NOT NULL default '0',
  `petition_signedMember2` int(11) NOT NULL default '0',
  `petition_signedMember3` int(11) NOT NULL default '0',
  `petition_signedMember4` int(11) NOT NULL default '0',
  `petition_signedMember5` int(11) NOT NULL default '0',
  `petition_signedMember6` int(11) NOT NULL default '0',
  `petition_signedMember7` int(11) NOT NULL default '0',
  `petition_signedMember8` int(11) NOT NULL default '0',
  `petition_signedMember9` int(11) NOT NULL default '0',
  PRIMARY KEY  (`petition_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_guilds_petition` */

/*Table structure for table `vbwow_item_pages` */

DROP TABLE IF EXISTS `vbwow_item_pages`;

CREATE TABLE `vbwow_item_pages` (
  `pageId` smallint(6) NOT NULL default '0',
  `pageNext` smallint(6) NOT NULL default '0',
  `pageText` text NOT NULL,
  `pageWDBVersion` smallint(6) NOT NULL default '0',
  `pageChecksum` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`pageId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_item_pages` */

/*Table structure for table `vbwow_itemnames` */

DROP TABLE IF EXISTS `vbwow_itemnames`;

CREATE TABLE `vbwow_itemnames` (
  `itemID` smallint(6) NOT NULL default '0',
  `itemName` text NOT NULL,
  `itemWDBVersion` smallint(6) NOT NULL default '0',
  `itemChecksum` int(6) NOT NULL default '0',
  PRIMARY KEY  (`itemID`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COMMENT='InnoDB free: 4096 kB';

/*Data for the table `vbwow_itemnames` */

/*Table structure for table `vbwow_items` */

DROP TABLE IF EXISTS `vbwow_items`;

CREATE TABLE `vbwow_items` (
  `item_id` mediumint(3) NOT NULL default '0',
  `item_availableClasses` smallint(2) NOT NULL default '0',
  `item_availableRaces` smallint(2) NOT NULL default '0',
  `item_model` int(2) NOT NULL default '0',
  `item_class` tinyint(1) unsigned NOT NULL default '0',
  `item_subclass` tinyint(1) unsigned NOT NULL default '0',
  `item_level` tinyint(1) unsigned NOT NULL default '0',
  `item_requiredLevel` tinyint(1) unsigned NOT NULL default '0',
  `item_requiredSkill` tinyint(1) unsigned NOT NULL default '0',
  `item_requiredSkillRank` tinyint(1) unsigned NOT NULL default '0',
  `item_requiredSpell` tinyint(1) unsigned NOT NULL default '0',
  `item_requiredFaction` smallint(1) NOT NULL default '0',
  `item_requiredFactionLevel` tinyint(1) unsigned NOT NULL default '0',
  `item_requiredHonorRank` tinyint(1) unsigned NOT NULL default '0',
  `item_name` varchar(255) NOT NULL default '',
  `item_quality` tinyint(1) unsigned NOT NULL default '0',
  `item_sheath` tinyint(1) unsigned NOT NULL default '0',
  `item_buyPrice` mediumint(3) NOT NULL default '0',
  `item_sellPrice` mediumint(3) NOT NULL default '0',
  `item_inventoryType` tinyint(1) unsigned NOT NULL default '0',
  `item_stackable` tinyint(1) unsigned NOT NULL default '0',
  `item_material` smallint(1) NOT NULL default '0',
  `item_durability` smallint(2) NOT NULL default '0',
  `item_containerSlots` tinyint(1) unsigned NOT NULL default '0',
  `item_ammoType` tinyint(1) unsigned NOT NULL default '0',
  `item_block` smallint(2) NOT NULL default '0',
  `item_bonding` tinyint(1) unsigned NOT NULL default '0',
  `item_delay` smallint(2) NOT NULL default '0',
  `item_description` varchar(255) NOT NULL default '',
  `item_set` tinyint(1) unsigned NOT NULL default '0',
  `item_extra` smallint(2) NOT NULL default '0',
  `item_flags` smallint(2) NOT NULL default '0',
  `item_language` tinyint(1) unsigned NOT NULL default '0',
  `item_lockid` smallint(2) NOT NULL default '0',
  `item_pageMaterial` tinyint(1) unsigned NOT NULL default '0',
  `item_pageText` smallint(2) NOT NULL default '0',
  `item_maxCount` tinyint(1) unsigned NOT NULL default '0',
  `item_armor` smallint(2) NOT NULL default '0',
  `item_resHoly` smallint(2) NOT NULL default '0',
  `item_resFire` smallint(2) NOT NULL default '0',
  `item_resNature` smallint(2) NOT NULL default '0',
  `item_resFrost` smallint(2) NOT NULL default '0',
  `item_resShadow` smallint(2) NOT NULL default '0',
  `item_resArcane` smallint(2) NOT NULL default '0',
  `item_startQuest` smallint(2) NOT NULL default '0',
  `item_bonusHealth` tinyint(1) unsigned NOT NULL default '0',
  `item_bonusMana` tinyint(1) unsigned NOT NULL default '0',
  `item_bonusAgility` tinyint(1) unsigned NOT NULL default '0',
  `item_bonusStrength` tinyint(1) unsigned NOT NULL default '0',
  `item_bonusIntellect` tinyint(1) unsigned NOT NULL default '0',
  `item_bonusSpirit` tinyint(1) unsigned NOT NULL default '0',
  `item_bonusStamina` tinyint(1) unsigned NOT NULL default '0',
  `item_socketBonus` mediumint(9) NOT NULL default '0',
  `item_socket1` tinyint(3) unsigned NOT NULL default '0',
  `item_socket2` tinyint(3) unsigned NOT NULL default '0',
  `item_socket3` tinyint(3) unsigned NOT NULL default '0',
  `item_bagFamily` tinyint(3) unsigned NOT NULL default '0',
  `item_gemID` tinyint(3) unsigned NOT NULL default '0',
  `item_rangeMod` tinyint(3) unsigned NOT NULL default '0',
  `item_damage` varchar(255) NOT NULL default '',
  `item_spells` varchar(255) NOT NULL default '',
  `item_loot` mediumint(9) NOT NULL,
  PRIMARY KEY  (`item_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_items` */

insert  into `vbwow_items`(`item_id`,`item_availableClasses`,`item_availableRaces`,`item_model`,`item_class`,`item_subclass`,`item_level`,`item_requiredLevel`,`item_requiredSkill`,`item_requiredSkillRank`,`item_requiredSpell`,`item_requiredFaction`,`item_requiredFactionLevel`,`item_requiredHonorRank`,`item_name`,`item_quality`,`item_sheath`,`item_buyPrice`,`item_sellPrice`,`item_inventoryType`,`item_stackable`,`item_material`,`item_durability`,`item_containerSlots`,`item_ammoType`,`item_block`,`item_bonding`,`item_delay`,`item_description`,`item_set`,`item_extra`,`item_flags`,`item_language`,`item_lockid`,`item_pageMaterial`,`item_pageText`,`item_maxCount`,`item_armor`,`item_resHoly`,`item_resFire`,`item_resNature`,`item_resFrost`,`item_resShadow`,`item_resArcane`,`item_startQuest`,`item_bonusHealth`,`item_bonusMana`,`item_bonusAgility`,`item_bonusStrength`,`item_bonusIntellect`,`item_bonusSpirit`,`item_bonusStamina`,`item_socketBonus`,`item_socket1`,`item_socket2`,`item_socket3`,`item_bagFamily`,`item_gemID`,`item_rangeMod`,`item_damage`,`item_spells`,`item_loot`) values (5863,32767,2047,16161,15,0,0,0,0,0,0,0,0,0,'Guild Charter',1,0,0,0,0,1,0,0,0,0,0,1,0,'',0,0,8192,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'0:0:0 0:0:0 0:0:0 0:0:0 0:0:0','0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0',0),(8164,32767,2047,1069,0,0,0,0,0,0,0,0,0,0,'Test Stationery',1,0,10,2,0,10,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'0:0:0 0:0:0 0:0:0 0:0:0 0:0:0','0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0',0),(9311,32767,2047,7798,0,0,0,0,0,0,0,0,0,0,'Default Stationery',1,0,0,0,0,1,0,0,0,0,0,0,0,'',0,0,0,0,0,1,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'0:0:0 0:0:0 0:0:0 0:0:0 0:0:0','0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0',0),(18154,32767,2047,30658,0,0,0,0,0,0,0,0,0,0,'Blizzard Stationery',1,0,0,0,0,1,0,0,0,0,0,0,0,'',0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,'0:0:0 0:0:0 0:0:0 0:0:0 0:0:0','0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0 0:0:0:0:0:0',0);

/*Table structure for table `vbwow_loots` */

DROP TABLE IF EXISTS `vbwow_loots`;

CREATE TABLE `vbwow_loots` (
  `loot_id` mediumint(6) NOT NULL auto_increment,
  `loot_item` smallint(6) NOT NULL default '0',
  `loot_chance` double NOT NULL default '0',
  `loot_group` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`loot_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_loots` */

/*Table structure for table `vbwow_npctext` */

DROP TABLE IF EXISTS `vbwow_npctext`;

CREATE TABLE `vbwow_npctext` (
  `text_id` smallint(6) NOT NULL default '0',
  `text_dens_0` tinyint(3) unsigned NOT NULL default '0',
  `text_text_0_1` varchar(255) NOT NULL default '',
  `text_text_0_2` varchar(255) NOT NULL default '',
  `text_lang_0` tinyint(3) unsigned NOT NULL default '0',
  `text_emote_0_1` smallint(6) NOT NULL default '0',
  `text_delay_0_1` smallint(6) NOT NULL default '0',
  `text_emote_0_2` smallint(6) NOT NULL default '0',
  `text_delay_0_2` smallint(6) NOT NULL default '0',
  `text_emote_0_3` smallint(6) NOT NULL default '0',
  `text_delay_0_3` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`text_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_npctext` */

/*Table structure for table `vbwow_quests` */

DROP TABLE IF EXISTS `vbwow_quests`;

CREATE TABLE `vbwow_quests` (
  `id` int(11) NOT NULL default '0',
  `NextQuest` int(11) NOT NULL default '0',
  `Title` varchar(255) NOT NULL default 'No Quest Title',
  `Zone` int(11) NOT NULL default '0',
  `Type` int(11) NOT NULL default '0',
  `Flags` int(11) NOT NULL default '0',
  `Level_Start` tinyint(3) unsigned NOT NULL default '0',
  `Level_Normal` tinyint(3) unsigned NOT NULL default '60',
  `Required_Quest` int(11) NOT NULL default '0',
  `Required_Race` int(11) NOT NULL default '0',
  `Required_Class` int(11) NOT NULL default '0',
  `Required_TradeSkill` int(11) NOT NULL default '0',
  `Required_Reputation1` int(11) NOT NULL default '0',
  `Required_Reputation1_Faction` int(11) NOT NULL default '0',
  `Required_Reputation2` int(11) NOT NULL default '0',
  `Required_Reputation2_Faction` int(11) NOT NULL default '0',
  `NPC_Start` int(11) NOT NULL default '0',
  `NPC_End` int(11) NOT NULL default '0',
  `Text_Objectives` text NOT NULL,
  `Text_Description` text NOT NULL,
  `Text_Incomplete` text NOT NULL,
  `Text_PreComplete` text NOT NULL,
  `Text_Complete` text NOT NULL,
  `QuestScript` varchar(255) NOT NULL default '',
  `Reward_XP` int(11) NOT NULL default '0',
  `Reward_Gold` int(11) NOT NULL default '0',
  `Reward_Spell` int(11) NOT NULL default '0',
  `Reward_Reputation1` int(11) NOT NULL default '0',
  `Reward_Reputation1_Faction` int(11) NOT NULL default '0',
  `Reward_Reputation2` int(11) NOT NULL default '0',
  `Reward_Reputation2_Faction` int(11) NOT NULL default '0',
  `Reward_Item1` int(11) NOT NULL default '0',
  `Reward_Item1_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_Item2` int(11) NOT NULL default '0',
  `Reward_Item2_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_Item3` int(11) NOT NULL default '0',
  `Reward_Item3_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_Item4` int(11) NOT NULL default '0',
  `Reward_Item4_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_Item5` int(11) NOT NULL default '0',
  `Reward_Item5_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_Item6` int(11) NOT NULL default '0',
  `Reward_Item6_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_StaticItem1` int(11) NOT NULL default '0',
  `Reward_StaticItem1_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_StaticItem2` int(11) NOT NULL default '0',
  `Reward_StaticItem2_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_StaticItem3` int(11) NOT NULL default '0',
  `Reward_StaticItem3_Count` tinyint(3) unsigned NOT NULL default '0',
  `Reward_StaticItem4` int(11) NOT NULL default '0',
  `Reward_StaticItem4_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Kill1` int(11) NOT NULL default '0',
  `Objective_Kill1_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Kill2` int(11) NOT NULL default '0',
  `Objective_Kill2_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Kill3` int(11) NOT NULL default '0',
  `Objective_Kill3_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Kill4` int(11) NOT NULL default '0',
  `Objective_Kill4_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Item1` int(11) NOT NULL default '0',
  `Objective_Item1_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Item2` int(11) NOT NULL default '0',
  `Objective_Item2_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Item3` int(11) NOT NULL default '0',
  `Objective_Item3_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Item4` int(11) NOT NULL default '0',
  `Objective_Item4_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Deliver1` int(11) NOT NULL default '0',
  `Objective_Deliver1_Count` tinyint(3) unsigned NOT NULL default '0',
  `Objective_Gold` int(11) NOT NULL default '0',
  `Objective_Text1` varchar(255) NOT NULL default '',
  `Objective_Text2` varchar(255) NOT NULL default '',
  `Objective_Text3` varchar(255) NOT NULL default '',
  `Objective_Text4` varchar(255) NOT NULL default '',
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_quests` */

/*Table structure for table `vbwow_realms` */

DROP TABLE IF EXISTS `vbwow_realms`;

CREATE TABLE `vbwow_realms` (
  `ws_name` varchar(50) NOT NULL default '',
  `ws_host` varchar(50) NOT NULL default '',
  `ws_port` int(5) NOT NULL default '0',
  `ws_status` tinyint(3) unsigned NOT NULL default '0',
  `ws_id` tinyint(3) unsigned NOT NULL default '0',
  `ws_type` tinyint(3) unsigned NOT NULL default '0',
  `ws_population` float(3,0) unsigned NOT NULL default '0',
  PRIMARY KEY  (`ws_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_realms` */

/*Table structure for table `vbwow_sells` */

DROP TABLE IF EXISTS `vbwow_sells`;

CREATE TABLE `vbwow_sells` (
  `sell_id` mediumint(9) NOT NULL auto_increment,
  `sell_item` mediumint(9) NOT NULL default '0',
  `sell_count` tinyint(3) unsigned NOT NULL default '1',
  `sell_group` smallint(6) NOT NULL default '0',
  `sell_price` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`sell_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_sells` */

/*Table structure for table `vbwow_spawns` */

DROP TABLE IF EXISTS `vbwow_spawns`;

CREATE TABLE `vbwow_spawns` (
  `spawn_id` mediumint(6) NOT NULL auto_increment,
  `spawn_entry` mediumint(6) NOT NULL default '0',
  `spawn_time` smallint(6) NOT NULL default '0',
  `spawn_positionX` double NOT NULL default '0',
  `spawn_positionY` double NOT NULL default '0',
  `spawn_positionZ` double NOT NULL default '0',
  `spawn_orientation` double NOT NULL default '0',
  `spawn_spawned` tinyint(1) unsigned NOT NULL default '0',
  `spawn_range` smallint(5) NOT NULL default '0',
  `spawn_type` tinyint(1) unsigned NOT NULL default '0',
  `spawn_map` smallint(6) NOT NULL default '0',
  `spawn_left` smallint(6) NOT NULL default '0',
  `spawn_waypoints` smallint(6) NOT NULL default '0',
  PRIMARY KEY  (`spawn_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_spawns` */

/*Table structure for table `vbwow_trainer_spells` */

DROP TABLE IF EXISTS `vbwow_trainer_spells`;

CREATE TABLE `vbwow_trainer_spells` (
  `id` int(11) NOT NULL auto_increment,
  `trainerId` int(11) NOT NULL default '0',
  `spellId` int(11) NOT NULL default '0',
  `spellCost` int(11) NOT NULL default '0',
  `requiredLevel` tinyint(3) unsigned NOT NULL default '0',
  `requiredSpell` int(11) NOT NULL,
  `requiredSkill` int(11) NOT NULL,
  `requiredSkill_Value` int(11) NOT NULL,
  `requiredRace` int(11) NOT NULL,
  `requiredClass` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_trainer_spells` */

/*Table structure for table `vbwow_weather` */

DROP TABLE IF EXISTS `vbwow_weather`;

CREATE TABLE `vbwow_weather` (
  `weather_zone` smallint(6) NOT NULL default '0',
  `weather_type` tinyint(3) unsigned NOT NULL default '0',
  `weather_intensity` double NOT NULL default '0',
  `weather_aviableTypes` varchar(255) NOT NULL default '0',
  PRIMARY KEY  (`weather_zone`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwow_weather` */

insert  into `vbwow_weather`(`weather_zone`,`weather_type`,`weather_intensity`,`weather_aviableTypes`) values (12,1,0.33,'0'),(141,2,0.33,'0'),(14,1,0.1,'0'),(85,1,0.1,'0'),(1,2,0.2,'0'),(215,1,0.7,'0'),(184,1,0.1,'0'),(36,1,0.1,'0'),(33,1,0,'0'),(357,1,0,'0'),(490,1,0,'0'),(405,2,0,'0'),(440,3,0,'0'),(1377,3,0,'0'),(3429,3,0,'0');

/*Table structure for table `vbwowdb_guilds` */

DROP TABLE IF EXISTS `vbwowdb_guilds`;

CREATE TABLE `vbwowdb_guilds` (
  `guild_id` int(11) NOT NULL auto_increment,
  `guild_name` varchar(255) NOT NULL,
  `guild_leader` int(11) NOT NULL default '0',
  `guild_MOTD` varchar(255) NOT NULL default '',
  `guild_info` varchar(255) NOT NULL default '',
  `guild_cYear` tinyint(3) unsigned NOT NULL default '0',
  `guild_cMonth` tinyint(3) unsigned NOT NULL default '0',
  `guild_cDay` tinyint(3) unsigned NOT NULL default '0',
  `guild_tEmblemStyle` tinyint(3) unsigned NOT NULL default '0',
  `guild_tEmblemColor` tinyint(3) unsigned NOT NULL default '0',
  `guild_tBorderStyle` tinyint(3) unsigned NOT NULL default '0',
  `guild_tBorderColor` tinyint(3) unsigned NOT NULL default '0',
  `guild_tBackgroundColor` tinyint(3) unsigned NOT NULL default '0',
  `guild_rank0` varchar(255) NOT NULL default 'Leader',
  `guild_rank0_Rights` int(11) NOT NULL default '61951',
  `guild_rank1` varchar(255) NOT NULL default 'Officer',
  `guild_rank1_Rights` int(11) NOT NULL default '67',
  `guild_rank2` varchar(255) NOT NULL default 'Veteran',
  `guild_rank2_Rights` int(11) NOT NULL default '67',
  `guild_rank3` varchar(255) NOT NULL default 'Member',
  `guild_rank3_Rights` int(11) NOT NULL default '67',
  `guild_rank4` varchar(255) NOT NULL default 'Initiate',
  `guild_rank4_Rights` int(11) NOT NULL default '67',
  `guild_rank5` varchar(255) NOT NULL default '',
  `guild_rank5_Rights` int(11) NOT NULL default '0',
  `guild_rank6` varchar(255) NOT NULL default '',
  `guild_rank6_Rights` int(11) NOT NULL default '0',
  `guild_rank7` varchar(255) NOT NULL default '',
  `guild_rank7_Rights` int(11) NOT NULL default '0',
  `guild_rank8` varchar(255) NOT NULL default '',
  `guild_rank8_Rights` int(11) NOT NULL default '0',
  `guild_rank9` varchar(255) NOT NULL default '',
  `guild_rank9_Rights` int(11) NOT NULL default '0',
  PRIMARY KEY  (`guild_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

/*Data for the table `vbwowdb_guilds` */

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
