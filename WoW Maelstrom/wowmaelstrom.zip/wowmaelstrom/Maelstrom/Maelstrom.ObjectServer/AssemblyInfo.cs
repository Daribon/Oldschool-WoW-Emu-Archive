using System.Reflection;
using System.Runtime.CompilerServices;

[assembly: AssemblyTitle("Maelstrom Object Server Library")]
[assembly: AssemblyDescription("Maelstrom World of Warcraft Server Emulator")]
[assembly: AssemblyConfiguration("")]
[assembly: AssemblyCompany("Team Maelstrom")]
[assembly: AssemblyProduct("")]
[assembly: AssemblyCopyright("Copyright (c) 2004")]
[assembly: AssemblyTrademark("")]

[assembly: AssemblyCulture("")]		
[assembly: AssemblyVersion("1.0.*")]
[assembly: AssemblyDelaySign(false)]
[assembly: AssemblyKeyFile("")]
[assembly: AssemblyKeyName("")]
