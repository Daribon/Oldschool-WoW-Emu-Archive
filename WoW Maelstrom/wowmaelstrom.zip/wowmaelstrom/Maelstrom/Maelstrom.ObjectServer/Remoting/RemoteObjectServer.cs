using System;

namespace Maelstrom.Remoting
{
	using Maelstrom.Remoting.Interfaces;

	/// <summary>
	/// Provides the server-side object to deal with inter-component communication for the Object Server.
	/// </summary>
	internal sealed class RemoteObjectServer: MarshalByRefObject, IObjectServer
	{
	}
}
