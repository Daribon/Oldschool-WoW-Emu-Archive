using System;
using System.Net;

namespace Maelstrom.ObjectServer
{
	using Maelstrom.Remoting;
	using Maelstrom.Remoting.Interfaces;

	/// <summary>
	/// Provides a central location for .NET Remoting Proxies used by the Object Server Library.
	/// </summary>
	public sealed class Proxies
	{
		internal static void Initialize()
		{
		}
	}
}
