using System;

namespace Maelstrom.Remoting
{
	using Maelstrom.Remoting.Interfaces;

	/// <summary>
	/// Provides the server-side object to deal with inter-component communication for the Realm List Server.
	/// </summary>
	public class RemoteRealmListServer: MarshalByRefObject, IRealmListServer
	{
	}
}
