using System;

namespace Maelstrom.Remoting
{
	using Maelstrom.Remoting.Interfaces;

	/// <summary>
	/// Provides the server-side object to deal with inter-component communication for the World Server.
	/// </summary>
	internal sealed class RemoteWorldServer: MarshalByRefObject, IWorldServer
	{
	}
}
