using System;

namespace Maelstrom
{
	using Maelstrom.Network;

	#region Server Delegates

	public delegate void RedirectTCPEvent(RedirectServerConnection Connection);

	#endregion
}
