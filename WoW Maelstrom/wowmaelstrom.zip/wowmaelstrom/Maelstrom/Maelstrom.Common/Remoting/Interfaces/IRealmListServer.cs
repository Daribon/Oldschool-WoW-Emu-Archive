using System;

namespace Maelstrom.Remoting.Interfaces
{
	/// <summary>
	/// Provides a remoting interface to the Realm List Server Library.
	/// </summary>
	public interface IRealmListServer
	{
	}
}
