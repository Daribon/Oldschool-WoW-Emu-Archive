using System;

namespace Maelstrom.Remoting.Interfaces
{
	/// <summary>
	/// Provides a remoting interface to the Object Server Library.
	/// </summary>
	public interface IObjectServer
	{
	}
}
