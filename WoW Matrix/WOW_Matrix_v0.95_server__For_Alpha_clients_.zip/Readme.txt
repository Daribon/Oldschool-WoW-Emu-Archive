========================== WoW Matrix Sandbox v0.95 ==========================

This is the first release of my sandbox.  Following features are supported:

Character creation (any character type can be selected)
Character saving (current location will be saved on logout)
Partial support for worldport console command



Instructions
------------
Extract the files to the WoW directory.  Run WowMatrixLoader.exe to run the game, the sandbox will be loaded automatically.  

Currently, in order to start in the Kalimdor continent you must put a 'K' before the name of the character.  So if the character you wanted to create was "Thrall", you would put the name "KThrall" in the creation box.  





Worldport command is partially implemented, usage is

worldport 0 X Y Z 1

Where the destination coordinates are (X, Y, Z).  Currently you cannot travel between continents though.  You can use the console command "dloc" to get your current coordinates.

-YobGuls



