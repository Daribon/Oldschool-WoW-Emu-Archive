from Ludmilla import *

import const_spells
co = const_spells
reload (co)

#------------------------------------------------------------------------------
class Spell_MarkoftheWild_rank2:
    """ Mark of the Wild rank 2
    """
    def CanCast (self, caster, target_dummy):
        print "Spell_MarkoftheWild_rank2: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_MarkoftheWild_rank2: SpellEffect called!"
        
        target.SetStrength(target.GetStrength() + 2)
        target.SetAgility(target.GetAgility() + 2)
        target.SetStamina(target.GetStamina() + 2)
        target.SetIntellect(target.GetIntellect() + 2)
        target.SetSpirit(target.GetSpirit() + 2)

#------------------------------------------------------------------------------
class Spell_MarkoftheWild_rank3:
    """ Mark of the Wild rank 3
    """
    def CanCast (self, caster, target_dummy):
        print "Spell_MarkoftheWild_rank3: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_MarkoftheWild_rank3: SpellEffect called!"
        
        target.SetStrength(target.GetStrength() + 4)
        target.SetAgility(target.GetAgility() + 4)
        target.SetStamina(target.GetStamina() + 4)
        target.SetIntellect(target.GetIntellect() + 4)
        target.SetSpirit(target.GetSpirit() + 4)

#------------------------------------------------------------------------------
class Spell_MarkoftheWild_rank4:
    """ Mark of the Wild rank 4
    """
    def CanCast (self, caster, target_dummy):
        print "Spell_MarkoftheWild_rank4: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_MarkoftheWild_rank4: SpellEffect called!"
        
        target.SetStrength(target.GetStrength() + 6)
        target.SetAgility(target.GetAgility() + 6)
        target.SetStamina(target.GetStamina() + 6)
        target.SetIntellect(target.GetIntellect() + 6)
        target.SetSpirit(target.GetSpirit() + 6)

        target.SetHolyResist(target.GetHolyResist() + 5)
        target.SetFireResist(target.GetFireResist() + 5)
        target.SetNatureResist(target.GetNatureResist() + 5)
        target.SetFrostResist(target.GetFrostResist() + 5)        
        target.SetShadowResist(target.GetShadowResist() + 5)
        target.SetArcaneResist(target.GetArcaneResist() + 5)

#------------------------------------------------------------------------------
class Spell_MarkoftheWild_rank5:
    """ Mark of the Wild rank 5
    """
    def CanCast (self, caster, target_dummy):
        print "Spell_MarkoftheWild_rank5: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_MarkoftheWild_rank5: SpellEffect called!"
        
        target.SetStrength(target.GetStrength() + 8)
        target.SetAgility(target.GetAgility() + 8)
        target.SetStamina(target.GetStamina() + 8)
        target.SetIntellect(target.GetIntellect() + 8)
        target.SetSpirit(target.GetSpirit() + 8)

        target.SetHolyResist(target.GetHolyResist() + 10)
        target.SetFireResist(target.GetFireResist() + 10)
        target.SetNatureResist(target.GetNatureResist() + 10)
        target.SetFrostResist(target.GetFrostResist() + 10)        
        target.SetShadowResist(target.GetShadowResist() + 10)
        target.SetArcaneResist(target.GetArcaneResist() + 10)

#------------------------------------------------------------------------------
class Spell_MarkoftheWild_rank6:
    """ Mark of the Wild rank 6
    """
    def CanCast (self, caster, target_dummy):
        print "Spell_MarkoftheWild_rank6: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_MarkoftheWild_rank6: SpellEffect called!"
        
        target.SetStrength(target.GetStrength() + 10)
        target.SetAgility(target.GetAgility() + 10)
        target.SetStamina(target.GetStamina() + 10)
        target.SetIntellect(target.GetIntellect() + 10)
        target.SetSpirit(target.GetSpirit() + 10)

        target.SetHolyResist(target.GetHolyResist() + 15)
        target.SetFireResist(target.GetFireResist() + 15)
        target.SetNatureResist(target.GetNatureResist() + 15)
        target.SetFrostResist(target.GetFrostResist() + 15)        
        target.SetShadowResist(target.GetShadowResist() + 15)
        target.SetArcaneResist(target.GetArcaneResist() + 15)

#------------------------------------------------------------------------------
class Spell_MarkoftheWild_rank7:
    """ Mark of the Wild rank 7
    """
    def CanCast (self, caster, target_dummy):
        print "Spell_MarkoftheWild_rank7: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_MarkoftheWild_rank7: SpellEffect called!"
        
        target.SetStrength(target.GetStrength() + 12)
        target.SetAgility(target.GetAgility() + 12)
        target.SetStamina(target.GetStamina() + 12)
        target.SetIntellect(target.GetIntellect() + 12)
        target.SetSpirit(target.GetSpirit() + 12)

        target.SetHolyResist(target.GetHolyResist() + 20)
        target.SetFireResist(target.GetFireResist() + 20)
        target.SetNatureResist(target.GetNatureResist() + 20)
        target.SetFrostResist(target.GetFrostResist() + 20)        
        target.SetShadowResist(target.GetShadowResist() + 20)
        target.SetArcaneResist(target.GetArcaneResist() + 20)

#------------------------------------------------------------------------------

#--- END ---