from Ludmilla import *

def GetRequiredSkill(spellid):
    """ This function return the requires skill level for the spell ID defined in
        the class.
    """
    if spellid in (2387, 2393, 2963, 3915, 12044, 2881, 2152, 9059, 9058, 7126, 2149):
        return 1
    elif spellid == 2385:
        return 10
    elif spellid in (8776, 2153):
        return 15
    elif spellid == 12045:
        return 20
    elif spellid == 3753:
        return 25
    elif spellid in (3914, 7623, 7624, 9062, 9060):
        return 30
    elif spellid in (3840, 3816, 9064):
        return 35
    elif spellid in (2389, 2392, 2394, 8465, 5244, 2160):
        return 40
    elif spellid in (3755, 7629, 7630):
        return 50
    elif spellid in (3756, 2161):
        return 55
    elif spellid in (2397, 2964, 3841, 2162, 2163):
        return 60
    elif spellid == 2386:
        return 65
    elif spellid in (2395, 2396, 3842, 6686, 7633, 9065):
        return 70
    elif spellid in (12046, 2402, 3759, 2164):
        return 75
    elif spellid in (3757, 3845, 3763):
        return 80
    elif spellid in (2399, 3843, 2159, 3761):
        return 85
    elif spellid in (3758, 3847, 6521, 7636, 8322, 7953, 6702, 2158):
        return 90
    elif spellid in (2401, 3844, 7639, 9068, 6703):
        return 95
    elif spellid in (2403, 2406, 20648, 3817, 2165, 3762, 9070, 2167, 2169):
        return 100
    elif spellid in (7954, 7133):
        return 105
    elif spellid in (3839, 3848, 3850, 3866, 6688, 7643, 8467, 2168):
        return 110
    elif spellid in (3939, 7955, 7135):
        return 115
    elif spellid in (3941, 3940, 3765, 9074, 9072, 3767, 2166):
        return 120
    elif spellid in (3947, 3946, 3945, 3944, 3942, 9269, 9145, 3766):
        return 125
    elif spellid in (3949, 3768):
        return 130
    elif spellid in (6458, 8243, 9147, 9146, 3770):
        return 135
    elif spellid in (3950, 3952, 9148, 3769):
        return 140
    elif spellid in (3953, 3764, 9149):
        return 145
    elif spellid in (12584, 3954, 3956, 3955, 20649, 3818, 3760, 9194, 9193, 3771, 3780):
        return 150 # done
    elif spellid == 3957:
        return 155
    elif spellid == 3958:
        return 160
    elif spellid in (9273, 3959):
        return 165
    elif spellid in (3961, 3960):
        return 170
    elif spellid in (12590, 12586, 3963, 3962, 12585, 12587, 12719):
        return 175
    elif spellid in (3964, 23068, 23066, 3979, 23069):
        return 180
    elif spellid in (3965, 3966):
        return 185
    elif spellid == 3967:
        return 190
    elif spellid in (12589, 12603, 12599, 3968, 12621):
        return 195
    elif spellid in (12591, 15255, 12900, 12895, 3969, 12597, 23070, 19788, 19796):
        return 200
    elif spellid in (12760, 12718, 12595, 12594, 12899, 12717):
        return 205
    elif spellid in (15628, 12715, 12596, 3971, 12902, 12897):
        return 210
    elif spellid in (3972, 12903, 12615):
        return 215
    elif spellid in (12720, 12722, 12614, 12607, 12904):
        return 220
    elif spellid in (12754, 12616, 12905):
        return 225
    elif spellid in (12755, 12617, 12906, 12618):
        return 230
    elif spellid in (12716, 12619, 12907, 12758):
        return 235
    elif spellid in (8895, 12620, 12759, 23129, 12908):
        return 240
    elif spellid in (12622, 19567, 23071):
        return 245
    elif spellid in (12624, 23096):
        return 250
    elif spellid == 23080:
        return 255
    elif spellid in (23077, 19791, 19792, 19790, 23078, 19793):
        return 260
    elif spellid == 23079:
        return  265
    elif spellid in (23489, 23486, 19794):
        return 270
    elif spellid in (19795, 19814):
        return 275
    elif spellid in (15633, 19825):
        return 280
    elif spellid in (19800, 19815, 19799, 19819, 23081):
        return 285
    elif spellid in (21940, 19833, 19831, 23082, 19830, 22797, 22795, 22793, 22704):
        return 300
    else:
        return 1

