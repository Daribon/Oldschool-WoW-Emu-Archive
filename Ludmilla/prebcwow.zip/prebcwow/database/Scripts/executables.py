from Ludmilla import *
from random import *
from const_ai import *


""" This module is used for Functions which function as VOID type.
"""

# CalcRP used to calculate REPUTATION given by killing Creature
def CalcReputation(self, victim):

    """ http://www.wowwiki.com/Reputation#What_is_Reputation_.5Bused_for.5D.3F
    """
    # TO_DO: We have to make descent script for this function. It is active now. Core activates it for every Kill.
    # All dependencies are in WoWWiki Web Site.
    
    # Functions to modify Reputation: SetReputation(x,y), GetReputation(x,y)
    #                                                  SetReputationValue(x,y),GetReputationValue(x,y)
    # Example for Reputations see in Plyer_class.py - def Reputation (p): function.

    pass
    
    