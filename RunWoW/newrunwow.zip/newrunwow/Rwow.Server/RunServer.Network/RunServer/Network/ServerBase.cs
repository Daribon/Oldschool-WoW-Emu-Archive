//
namespace RunServer.Network
{
    using RunServer;
    using RunServer.Common;
    using System;
    using System.Globalization;
    using System.IO;
    using System.Threading;

    public abstract class ServerBase : NetworkServer, IJobHandler
    {
        private JobQueue m_criticalQueue;
        private JobQueue m_criticalSecondQueue;
        private static JobQueue[] m_packetJobs;
        private JobQueue m_primaryQueue;
        private JobQueue m_separateQueue;
        private JobQueue m_separateSecondQueue;
        private CustomThreadPool m_threadPool;

        public ServerBase(int port) : this(true, port)
        {
        }

        public ServerBase(bool addThreads, int port)
        {
            LogConsole.WriteLine(RunServer.Common.LogLevel.SYSTEM, "Listening at port " + port);
            if (addThreads)
            {
                this.m_primaryQueue = new JobQueue(false, 0x3e8);
                this.m_separateQueue = new JobQueue(false, 100);
                this.m_separateSecondQueue = new JobQueue(false, 100);
                this.m_criticalQueue = new JobQueue(true, 100);
                this.m_criticalSecondQueue = new JobQueue(true, 100);
                m_packetJobs = new JobQueue[10];
                this.m_threadPool = new CustomThreadPool(10);
            }
            else
            {
                this.m_primaryQueue = new JobQueue(true, 100);
            }
            this.Start(port);
        }

        public void AddJob(IJob job)
        {
            if (job != null)
            {
                if (this.m_separateQueue == null)
                {
                    this.m_primaryQueue.Enqueue(job);
                }
                else
                {
                    switch (job.ExecutionPriority)
                    {
                        case ExecutionPriority.Packet:
                            m_packetJobs[job.OwnerCode % m_packetJobs.Length].Enqueue(job);
                            return;

                        case ExecutionPriority.Pool:
                            this.m_threadPool.QueueUserWorkItem(new WaitCallback(job.Execute), job.Name);
                            return;

                        case ExecutionPriority.QSeparate:
                            this.m_separateQueue.Enqueue(job);
                            return;

                        case ExecutionPriority.QSeparateSecond:
                            this.m_separateSecondQueue.Enqueue(job);
                            return;

                        case ExecutionPriority.QCritical:
                            this.m_criticalQueue.Enqueue(job);
                            return;

                        case ExecutionPriority.QCriticalSecond:
                            this.m_criticalSecondQueue.Enqueue(job);
                            return;
                    }
                    this.m_primaryQueue.Enqueue(job);
                }
            }
        }

        public void DumpInfo(TextWriter tw)
        {
        }

        public void ReceiveFlush()
        {
            for (int i = 0; i < base.m_clients.Length; i++)
            {
                if (((base.m_clients[i] != null) && !base.m_clients[i].Closed) && !((ClientBase) base.m_clients[i]).FlushReceive())
                {
                    base.OnClientException(base.m_clients[i], new Exception("Junk received"));
                }
            }
        }

        public void SendFlush()
        {
            for (int i = 0; i < base.m_clients.Length; i++)
            {
                if ((base.m_clients[i] != null) && !base.m_clients[i].Closed)
                {
                    base.m_clients[i].FlushSend();
                }
            }
        }

        public override void Start(int port)
        {
            base.Start(port);
            this.m_primaryQueue.Start(CultureInfo.CurrentCulture);
            if (this.m_separateQueue != null)
            {
                this.m_separateQueue.Start(CultureInfo.CurrentCulture);
            }
            if (this.m_separateSecondQueue != null)
            {
                this.m_separateSecondQueue.Start(CultureInfo.CurrentCulture);
            }
            if (this.m_criticalQueue != null)
            {
                this.m_criticalQueue.Start(CultureInfo.CurrentCulture);
            }
            if (this.m_criticalSecondQueue != null)
            {
                this.m_criticalSecondQueue.Start(CultureInfo.CurrentCulture);
            }
            if (m_packetJobs != null)
            {
                for (int i = 0; i < m_packetJobs.Length; i++)
                {
                    m_packetJobs[i] = new JobQueue(true, 500);
                    m_packetJobs[i].Start(CultureInfo.CurrentCulture);
                }
            }
        }

        public override void Stop()
        {
            this.m_primaryQueue.Stop();
            if (this.m_separateQueue != null)
            {
                this.m_separateQueue.Stop();
            }
            if (this.m_separateSecondQueue != null)
            {
                this.m_separateSecondQueue.Stop();
            }
            if (this.m_criticalQueue != null)
            {
                this.m_criticalQueue.Stop();
            }
            if (this.m_criticalSecondQueue != null)
            {
                this.m_criticalSecondQueue.Stop();
            }
            if (this.m_threadPool != null)
            {
                this.m_threadPool.Dispose();
            }
            if (m_packetJobs != null)
            {
                for (int i = 0; i < m_packetJobs.Length; i++)
                {
                    m_packetJobs[i].Stop();
                }
            }
            base.Stop();
        }

        public override string ToString()
        {
            string[] textArray = base.GetType().ToString().Split(new char[] { '.' });
            return string.Format("{0}({1})", textArray[textArray.Length - 1], base.LocalEndPoint);
        }

        public abstract ScriptAssembly PacketHandler { get; }
    }
}

