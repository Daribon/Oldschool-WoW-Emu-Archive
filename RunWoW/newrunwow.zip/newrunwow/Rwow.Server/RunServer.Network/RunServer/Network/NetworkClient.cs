//
namespace RunServer.Network
{
    using System;
    using System.Net;
    using System.Net.Sockets;

    public abstract class NetworkClient
    {
        private RunServer.Network.CloseState m_closed;
        private int m_id;
        private IPEndPoint m_iep;
        private DateTime m_lastActivity;
        protected NetworkServer m_parent;
        private byte[] m_rbuffer;
        private bool m_sending;
        private System.Net.Sockets.Socket m_socket;
        public int Sending;

        public NetworkClient(System.Net.Sockets.Socket socket, NetworkServer parent) : this(socket, parent, new byte[Utility.ReceiveBufferSize])
        {
        }

        public NetworkClient(System.Net.Sockets.Socket socket, NetworkServer parent, byte[] receiveBuffer)
        {
            this.m_id = -1;
            this.m_rbuffer = receiveBuffer;
            this.m_socket = socket;
            this.m_iep = (IPEndPoint) this.m_socket.RemoteEndPoint;
            this.m_closed = RunServer.Network.CloseState.None;
            this.m_parent = parent;
            this.m_sending = false;
            this.GotActivity();
        }

        public virtual void Close()
        {
        }

        public void Close(string reason)
        {
            if (!this.Closed)
            {
                this.Parent.OnClientException(this, new Exception(reason));
            }
        }

        public virtual void DataSent(byte[] buffer, int bytes)
        {
        }

        public abstract void EnqueueIncomingData(int length);
        public virtual void FlushSend()
        {
        }

        public void GotActivity()
        {
            this.m_lastActivity = DateTime.Now.AddSeconds((double) Utility.IdleTimeout);
        }

        public bool Closed
        {
            get
            {
                return (this.m_closed != RunServer.Network.CloseState.None);
            }
            set
            {
                this.m_closed = RunServer.Network.CloseState.Closed;
            }
        }

        public RunServer.Network.CloseState CloseState
        {
            get
            {
                return this.m_closed;
            }
            set
            {
                this.m_closed = value;
            }
        }

        public bool Closing
        {
            get
            {
                return (this.m_closed == RunServer.Network.CloseState.Closing);
            }
            set
            {
                this.m_closed = RunServer.Network.CloseState.Closing;
            }
        }

        public int ID
        {
            get
            {
                return this.m_id;
            }
            set
            {
                this.m_id = value;
            }
        }

        public bool Idle
        {
            get
            {
                return (this.m_lastActivity < DateTime.Now);
            }
        }

        public NetworkServer Parent
        {
            get
            {
                return this.m_parent;
            }
        }

        public byte[] ReceiveBuffer
        {
            get
            {
                return this.m_rbuffer;
            }
        }

        public IPEndPoint RemoteEndPoint
        {
            get
            {
                return this.m_iep;
            }
        }

        public System.Net.Sockets.Socket Socket
        {
            get
            {
                return this.m_socket;
            }
        }
    }
}

