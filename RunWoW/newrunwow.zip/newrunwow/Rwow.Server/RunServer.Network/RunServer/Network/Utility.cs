﻿namespace RunServer.Network
{
    using System;
    using System.Net;

    public class Utility
    {
        public static int IdleTimeout = 180;
        public static int ReceiveBufferSize = 0x2000;
        public static int ReceiveTimeout = 0;
        public static int SendBufferSize = 0x10000;
        public static int SendTimeout = 0;
        public static bool UseNagle = true;

        public static IPAddress GetAddress(string str)
        {
            IPAddress address = null;
            if (((str == null) || (str == string.Empty)) || (str == "any"))
            {
                return Dns.GetHostEntry(Dns.GetHostName()).AddressList[0];
            }
            try
            {
                address = IPAddress.Parse(str);
            }
            catch (FormatException)
            {
                IPHostEntry hostEntry = Dns.GetHostEntry(str);
                if (hostEntry.AddressList.Length > 0)
                {
                    address = hostEntry.AddressList[0];
                }
            }
            return address;
        }
    }
}

