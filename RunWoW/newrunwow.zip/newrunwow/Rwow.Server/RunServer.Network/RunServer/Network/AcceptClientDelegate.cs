﻿namespace RunServer.Network
{
    using System;
    using System.Net.Sockets;
    using System.Runtime.CompilerServices;

    public delegate bool AcceptClientDelegate(Socket s);
}

