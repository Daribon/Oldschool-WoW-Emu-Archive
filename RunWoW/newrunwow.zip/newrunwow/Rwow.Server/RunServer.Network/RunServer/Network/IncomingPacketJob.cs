﻿namespace RunServer.Network
{
    using RunServer.Common;
    using System;

    public class IncomingPacketJob : IJob
    {
        private ClientBase m_client;
        private BinReader m_data;
        private string m_packetName;
        private RunServer.Common.ExecutionPriority m_priority;

        public IncomingPacketJob(ClientBase client, BinReader data, string packet, RunServer.Common.ExecutionPriority priority)
        {
            this.m_client = client;
            this.m_data = data;
            this.m_priority = priority;
            this.m_packetName = packet;
        }

        public void Execute(object state)
        {
            try
            {
                if ((this.m_client != null) && !this.m_client.Closed)
                {
                    this.m_client.ProcessPacket(this.m_data);
                }
            }
            catch (Exception exception)
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.ERROR, "Packet exception " + exception);
            }
            finally
            {
                if (!this.m_data.NoDispose)
                {
                    this.m_data.Clean();
                }
                this.m_data = null;
                this.m_client = null;
            }
        }

        public ClientBase Client
        {
            get
            {
                return this.m_client;
            }
        }

        public bool Empty
        {
            get
            {
                return (this.m_data == null);
            }
        }

        public RunServer.Common.ExecutionPriority ExecutionPriority
        {
            get
            {
                return this.m_priority;
            }
        }

        public string Name
        {
            get
            {
                return this.m_packetName;
            }
        }

        public int OwnerCode
        {
            get
            {
                return this.m_client.GetHashCode();
            }
        }
    }
}

