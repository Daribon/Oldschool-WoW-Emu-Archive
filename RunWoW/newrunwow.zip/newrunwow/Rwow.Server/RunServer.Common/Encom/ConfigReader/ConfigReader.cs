﻿namespace Encom.ConfigReader
{
    using System;
    using System.Collections;
    using System.Xml;

    public class ConfigReader
    {
        private static Hashtable configs = new Hashtable();
        private static object syncRoot = new object();

        private static void loadConfig(string file, string section)
        {
            XmlDocument document = new XmlDocument();
            document.Load(file);
            XmlNode node = document["root"][section];
            Hashtable hashtable = new Hashtable();
            foreach (XmlNode node2 in node.ChildNodes)
            {
                if (((node2 != null) && (node2.Attributes != null)) && ((node2.Attributes["key"] != null) && (node2.Attributes["value"] != null)))
                {
                    hashtable.Add(node2.Attributes["key"].Value, node2.Attributes["value"].Value);
                }
            }
            if (hashtable.Count == 0)
            {
                Console.WriteLine("Warning no config keys loaded from " + file);
            }
            configs[file] = hashtable;
        }

        public static object SafeConfigValue(string file, string section, string keyName, Type type)
        {
            object obj2;
            lock (syncRoot)
            {
                if (!configs.ContainsKey(file))
                {
                    loadConfig(file, section);
                }
                try
                {
                    string text = (string) ((Hashtable) configs[file])[keyName];
                    if (type == typeof(float))
                    {
                        text = text.TrimEnd(new char[] { 'f' }).Replace('.', ',');
                    }
                    obj2 = Convert.ChangeType(text, type);
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Error loading key {0} type {1} from file {2} section {3}", new object[] { keyName, type.Name, file, section });
                    throw exception;
                }
            }
            return obj2;
        }
    }
}

