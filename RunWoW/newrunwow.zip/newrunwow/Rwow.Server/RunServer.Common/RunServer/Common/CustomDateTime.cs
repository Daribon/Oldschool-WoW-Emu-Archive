﻿namespace RunServer.Common
{
    using System;

    public class CustomDateTime
    {
        private static DateTime m_now = DateTime.Now;
        private static string m_nowString = m_now.ToString("HH:mm:ss.ffff");

        public static void UpdateNow()
        {
            m_now = DateTime.Now;
            m_nowString = m_now.ToString("HH:mm:ss.ffff");
        }

        public static void UpdateNow(long ticks)
        {
            m_now = new DateTime(ticks);
            m_nowString = m_now.ToString("HH:mm:ss.ffff");
        }

        public static DateTime Now
        {
            get
            {
                return m_now;
            }
        }

        public static string NowString
        {
            get
            {
                return m_nowString;
            }
        }
    }
}

