//
namespace RunServer.Common
{
    using System;
    using System.Collections;
    using System.Collections.Specialized;
    using System.Text;

    public class BinReader
    {
        private byte[] m_buffer;
        private int m_index;
        private DateTime m_innerTime;
        private int m_length;
        private bool m_noDispose;

        public BinReader(BinWriter data) : this(data.GetBuffer(), data.Length)
        {
        }

        public BinReader(byte[] data) : this(data, data.Length)
        {
        }

        protected BinReader(int length)
        {
            m_buffer = null;
            m_length = length;
            m_index = 0;
            m_innerTime = CustomDateTime.Now;
        }

        public BinReader(byte[] data, int length)
        {
            m_buffer = data;
            m_length = length;
            m_index = 0;
            m_innerTime = CustomDateTime.Now;
        }

        public virtual void Clean()
        {
            if (m_buffer != null)
            {
                BufferPool.Instance.ReleaseBuffer(m_buffer);
                this.m_buffer = null;
            }
        }

        public virtual byte[] GetBuffer()
        {
            return m_buffer;
        }

        public float ReadAngle()
        {
            float num = ReadSingle();
            if (num > 3.1415926535897931)
            {
                num = 3.141593f;
            }
            if (num < -3.1415926535897931)
            {
                num = -3.141593f;
            }
            return (float) Math.Round((double) num, 5);
        }

        public virtual bool ReadBoolean()
        {
            m_index++;
            return (m_buffer[m_index - 1] != 0);
        }

        public virtual byte ReadByte()
        {
            m_index++;
            return m_buffer[m_index - 1];
        }

        public virtual byte[] ReadBytes(int length)
        {
            byte[] dst = new byte[length];
            Buffer.BlockCopy(m_buffer, m_index, dst, 0, length);
            m_index += length;
            return dst;
        }

        public DateTime ReadDateTime()
        {
            return new DateTime(ReadInt64());
        }

        public virtual double ReadDouble()
        {
            double num = BitConverter.ToDouble(GetBuffer(), m_index);
            m_index += 8;
            return num;
        }

        public virtual short ReadInt16()
        {
            byte b2 = ReadByte();
            byte b1 = ReadByte();
            return (short) ((b2 & 0xFF) | b1 << 8);
        }

        public virtual int ReadInt32()
        {
            byte b4 = ReadByte();
            byte b3 = ReadByte();
            byte b2 = ReadByte();
            byte b1 = ReadByte();
            return ((((b4 & 0xff) | (b3 << 8)) | (b2 << 0x10)) | (b1 << 0x18));
        }

        public virtual long ReadInt64()
        {
            uint num = ReadUInt32();
            return (long) (((ulong)ReadUInt32() << 0x20) | num);
        }

        public virtual sbyte ReadSByte()
        {
            m_index++;
            return (sbyte) m_buffer[m_index - 1];
        }

        public virtual float ReadSingle()
        {
            float num = BitConverter.ToSingle(GetBuffer(), m_index);
            m_index += 4;
            return num;
        }

        public string ReadString()
        {
            if (Position >= Length)
            {
                return string.Empty;
            }
            StringBuilder builder = new StringBuilder();
            while (Position < Length)
            {
                byte num = ReadByte();
                if (num == 0)
                {
                    break;
                }
                builder.Append((char) num);
            }
            return builder.ToString();
        }

        public string ReadString(int maxlen)
        {
            if (maxlen == 0)
            {
                return string.Empty;
            }
            byte[] bytes = BufferPool.Instance.AquireBuffer(maxlen);
            int index = 0;
            while (index < maxlen)
            {
                bytes[index] = ReadByte();
                if (bytes[index] == 0)
                {
                    break;
                }
                index++;
            }
            return Encoding.UTF8.GetString(bytes, 0, index);
        }

        public Type ReadType()
        {
            switch (ReadByte())
            {
                case 1:
                    return typeof(byte);

                case 2:
                    return typeof(sbyte);

                case 3:
                    return typeof(short);

                case 4:
                    return typeof(ushort);

                case 5:
                    return typeof(int);

                case 6:
                    return typeof(uint);

                case 7:
                    return typeof(long);

                case 8:
                    return typeof(ulong);

                case 9:
                    return typeof(float);

                case 10:
                    return typeof(double);

                case 11:
                    return typeof(byte[]);

                case 12:
                    return typeof(string);

                case 13:
                    return typeof(bool);

                case 14:
                    return typeof(Type);

                case 15:
                    return typeof(DateTime);
            }
            return null;
        }

        public virtual ushort ReadUInt16()
        {
            m_index += 2;
            return (ushort) ((m_buffer[m_index - 2] & 0xff) | (m_buffer[m_index - 1] << 8));
        }

        public virtual uint ReadUInt32()
        {
            m_index += 4;
            return (uint) (((m_buffer[m_index - 4] | (m_buffer[m_index - 3] << 8)) | (m_buffer[m_index - 2] << 0x10)) | (m_buffer[m_index - 1] << 0x18));
        }

        public virtual ulong ReadUInt64()
        {
            uint num1 = ReadUInt32();
            uint num2 = ReadUInt32();
            return (((ulong)num2 << 0x20) | num1);
        }

        public IDictionary ReadVariantDictionary()
        {
            int num = ReadInt32();
            IDictionary dictionary = new ListDictionary();
            for (int i = 0; i < num; i++)
            {
                object key = ReadVariantObject();
                object obj3 = ReadVariantObject();
                dictionary.Add(key, obj3);
            }
            return dictionary;
        }

        public object ReadVariantObject()
        {
            TypeEnum enum2 = (TypeEnum) ReadByte();
            switch (enum2)
            {
                case TypeEnum.@byte:
                    return ReadByte();

                case TypeEnum.@sbyte:
                    return ReadSByte();

                case TypeEnum.@short:
                    return ReadInt16();

                case TypeEnum.@ushort:
                    return ReadUInt16();

                case TypeEnum.@int:
                    return ReadInt32();

                case TypeEnum.@uint:
                    return ReadUInt32();

                case TypeEnum.@long:
                    return ReadInt64();

                case TypeEnum.@ulong:
                    return ReadUInt64();

                case TypeEnum.@float:
                    return ReadSingle();

                case TypeEnum.@double:
                    return ReadDouble();

                case TypeEnum.byteArray:
                    return ReadBytes(ReadInt32());

                case TypeEnum.@string:
                    return ReadString();

                case TypeEnum.@bool:
                    return ReadBoolean();

                case TypeEnum.type:
                    return ReadType();

                case TypeEnum.DateTime:
                    return ReadDateTime();
            }
            throw new Exception("Reading unknown type " + enum2);
        }

        public object[][] ReadVariantObjectArray()
        {
            int num = ReadInt32();
            object[][] objArray = new object[num][];
            for (int i = 0; i < num; i++)
            {
                objArray[i] = ReadVariantObjects();
            }
            return objArray;
        }

        public object[] ReadVariantObjects()
        {
            int num = ReadInt32();
            object[] objArray = new object[num];
            for (int i = 0; i < num; i++)
            {
                objArray[i] = ReadVariantObject();
            }
            return objArray;
        }

        public Vector ReadVector()
        {
            return new Vector(ReadSingle(), ReadSingle(), ReadSingle());
        }

        public BinReader BaseStream
        {
            get
            {
                return this;
            }
        }

        public DateTime InnerTime
        {
            get
            {
                return m_innerTime;
            }
            set
            {
                m_innerTime = value;
            }
        }

        public int Length
        {
            get
            {
                return m_length;
            }
        }

        public bool NoDispose
        {
            get
            {
                return m_noDispose;
            }
            set
            {
                m_noDispose = value;
            }
        }

        public int Position
        {
            get
            {
                return m_index;
            }
            set
            {
                m_index = value;
            }
        }
    }
}

