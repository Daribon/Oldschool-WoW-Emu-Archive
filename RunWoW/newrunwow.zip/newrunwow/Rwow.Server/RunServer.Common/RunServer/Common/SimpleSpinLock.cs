﻿namespace RunServer.Common
{
    using System;
    using System.Threading;

    public class SimpleSpinLock
    {
        private static readonly bool IsSingleCpuMachine = (Environment.ProcessorCount == 1);
        private int myLock;
        private int owner;

        public void Enter()
        {
            int managedThreadId = Thread.CurrentThread.ManagedThreadId;
            if (this.owner != managedThreadId)
            {
                if (Interlocked.CompareExchange(ref this.myLock, 1, 0) != 0)
                {
                    this.enterSpin();
                }
                else
                {
                    this.owner = managedThreadId;
                }
            }
        }

        private void enterSpin()
        {
            int num = 0;
        Label_0002:
            if ((num < 3) && !IsSingleCpuMachine)
            {
                Thread.SpinWait(20);
            }
            else
            {
                Thread.Sleep(0);
            }
            if (Interlocked.CompareExchange(ref this.myLock, 1, 0) == 0)
            {
                this.owner = Thread.CurrentThread.ManagedThreadId;
            }
            else
            {
                num++;
                goto Label_0002;
            }
        }

        public void Exit()
        {
            this.myLock = 0;
            this.owner = 0;
        }
    }
}

