//
namespace RunServer.Common
{
    using System;

    public class GenericPool<T>
    {
        private FastLockQueue<T[]> m_freeBuffers;
        private int m_initialBufferSize;
        private int m_initialCapacity;
        private int m_maximumCapacity;

        public GenericPool(int initialCapacity, int maximumCapacity, int initialBufferSize)
        {
            this.m_initialBufferSize = initialBufferSize;
            this.m_initialCapacity = initialCapacity;
            this.m_maximumCapacity = maximumCapacity;
            this.m_freeBuffers = new FastLockQueue<T[]>();
        }

        public T[] AquireBuffer()
        {
            T[] localArray = null;
            if (this.m_freeBuffers.Count > 0)
            {
                localArray = this.m_freeBuffers.Dequeue();
            }
            else
            {
                for (int i = 0; i < (this.m_initialCapacity - 1); i++)
                {
                    this.m_freeBuffers.Enqueue(new T[this.m_initialBufferSize]);
                }
            }
            if (localArray == null)
            {
                localArray = new T[this.m_initialBufferSize];
            }
            return localArray;
        }

        public T[] AquireBuffer(int minSize)
        {
            T[] buffer = null;
            int count = this.m_freeBuffers.Count;
            if (count > 10)
            {
                count = 0;
            }
            while (count-- > 0)
            {
                buffer = this.m_freeBuffers.Dequeue();
                if ((buffer != null) && (buffer.Length >= minSize))
                {
                    break;
                }
                this.ReleaseBuffer(buffer, false);
                buffer = null;
            }
            if (buffer == null)
            {
                return new T[minSize];
            }
            return buffer;
        }

        public void Free()
        {
            while (this.m_freeBuffers.Count > 0)
            {
                this.m_freeBuffers.Dequeue();
            }
        }

        public void ReleaseBuffer(T[] buffer)
        {
            this.ReleaseBuffer(buffer, true);
        }

        public void ReleaseBuffer(T[] buffer, bool clear)
        {
            if ((buffer != null) && (this.m_freeBuffers.Count < this.m_maximumCapacity))
            {
                for (int i = 0; i < buffer.Length; i++)
                {
                    buffer[i] = default(T);
                }
                this.m_freeBuffers.Enqueue(buffer);
            }
        }
    }
}

