//
namespace RunServer.Common.Attributes
{
    using System;

    public enum InitPass
    {
        First,
        Second,
        Third,
        Fourth
    }
}