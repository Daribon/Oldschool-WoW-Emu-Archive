﻿namespace RunServer.Common
{
    using System;
    using System.Collections.Generic;
    using System.Runtime.CompilerServices;
    using System.Threading;

    public class Timer : IJob
    {
        public static long IntervalTimers;
        private TimeSpan m_delay;
        private RunServer.Common.ExecutionPriority m_executionPriority;
        private int m_index;
        private TimeSpan m_interval;
        internal Dictionary<long, RunServer.Common.Timer> m_List;
        internal long m_ListKey;
        private string m_name;
        private long m_next;
        private TimerPriority m_priority;
        private bool m_queued;
        private bool m_running;
        private bool m_stopped;
        private bool m_stopQueued;
        private int m_сount;
        public static long RunningTimers;
        public static long TimerCount;

        public event TimerStartCallback OnStart;

        public event RunServer.Common.TimerCallback OnStop;

        public event RunServer.Common.TimerCallback OnTick;

        public Timer(TimeSpan delay) : this(delay, TimeSpan.Zero, 1)
        {
        }

        public Timer(TimeSpan delay, TimeSpan interval) : this(delay, interval, 0)
        {
        }

        public Timer(TimeSpan delay, TimeSpan interval, int count)
        {
            this.m_executionPriority = RunServer.Common.ExecutionPriority.None;
            long num1 = TimerCount + 1;
            TimerCount = num1;
            this.m_ListKey = num1;
            this.m_index = 0;
            this.m_List = null;
            this.m_stopped = false;
            this.m_name = string.Empty;
            this.m_delay = delay;
            this.m_interval = interval;
            this.m_сount = count;
            this.m_queued = false;
            this.m_stopQueued = false;
            this.m_running = false;
            this.m_next = TimerQueue.GetTickCount();
            this.OnStart = null;
            this.OnStop = null;
            this.OnTick = null;
            if (delay != TimeSpan.Zero)
            {
                this.m_priority = ComputePriority(delay);
            }
            else
            {
                this.m_priority = ComputePriority(interval);
            }
        }

        public static TimerPriority ComputePriority(TimeSpan ts)
        {
            if (ts >= TimeSpan.FromMinutes(1))
            {
                return TimerPriority.FiveSeconds;
            }
            if (ts >= TimeSpan.FromSeconds(10))
            {
                return TimerPriority.OneSecond;
            }
            if (ts >= TimeSpan.FromSeconds(5))
            {
                return TimerPriority.TwoFiftyMS;
            }
            if (ts >= TimeSpan.FromSeconds(2.5))
            {
                return TimerPriority.FiftyMS;
            }
            if (ts >= TimeSpan.FromSeconds(1))
            {
                return TimerPriority.TwentyFiveMS;
            }
            if (ts >= TimeSpan.FromSeconds(0.5))
            {
                return TimerPriority.TenMS;
            }
            return TimerPriority.EveryTick;
        }

        public void DoStop()
        {
            if (!this.m_stopped)
            {
                this.m_stopped = true;
                if (this.OnStop != null)
                {
                    try
                    {
                        this.OnStop();
                    }
                    catch (Exception exception)
                    {
                        LogConsole.WriteLine(RunServer.Common.LogLevel.ERROR, string.Concat(new object[] { "Error stopping timer ", this.ToString(), ": ", exception }));
                    }
                }
            }
        }

        public void DoTick()
        {
            if (this.OnTick != null)
            {
                try
                {
                    this.OnTick();
                }
                catch (Exception exception)
                {
                    LogConsole.WriteLine(RunServer.Common.LogLevel.ERROR, string.Concat(new object[] { "Error executing timer ", this.ToString(), ": ", exception }));
                }
            }
            this.Queued = false;
        }

        public void Execute(object state)
        {
            this.DoTick();
            if (this.StopQueued)
            {
                this.DoStop();
            }
        }

        public static string FormatDelegate(Delegate callback)
        {
            if (callback == null)
            {
                return "null";
            }
            return string.Format("{0}.{1}", callback.Method.DeclaringType.FullName, callback.Method.Name);
        }

        public void Prolongate(TimeSpan n_delay)
        {
            this.m_next += n_delay.Ticks;
            this.Priority = ComputePriority(this.m_delay + n_delay);
        }

        internal void QueueStop()
        {
            if (this.m_running)
            {
                this.m_running = false;
                TimerQueue.RemoveTimer(this);
                Interlocked.Decrement(ref RunningTimers);
                Interlocked.Decrement(ref IntervalTimers);
                this.m_stopQueued = true;
            }
        }

        public void Start()
        {
            if (!this.m_running)
            {
                this.m_running = true;
                Interlocked.Increment(ref RunningTimers);
                if ((this.OnStart == null) || this.OnStart())
                {
                    Interlocked.Increment(ref IntervalTimers);
                    TimerQueue.AddTimer(this);
                }
                else
                {
                    this.Stop();
                }
            }
        }

        public void Stop()
        {
            if (this.m_running)
            {
                this.m_running = false;
                Interlocked.Decrement(ref RunningTimers);
                Interlocked.Decrement(ref IntervalTimers);
                TimerQueue.RemoveTimer(this);
                this.DoStop();
            }
        }

        public override string ToString()
        {
            if (this.Name != string.Empty)
            {
                return this.Name;
            }
            return base.GetType().FullName;
        }

        public int Count
        {
            get
            {
                return this.m_сount;
            }
            set
            {
                this.m_сount = value;
            }
        }

        public TimeSpan Delay
        {
            get
            {
                return this.m_delay;
            }
            set
            {
                this.m_delay = value;
            }
        }

        public bool Empty
        {
            get
            {
                return false;
            }
        }

        public RunServer.Common.ExecutionPriority ExecutionPriority
        {
            get
            {
                return this.m_executionPriority;
            }
            set
            {
                this.m_executionPriority = value;
            }
        }

        public int Index
        {
            get
            {
                return this.m_index;
            }
            set
            {
                this.m_index = value;
            }
        }

        public TimeSpan Interval
        {
            get
            {
                return this.m_interval;
            }
            set
            {
                this.m_interval = value;
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                this.m_name = value;
            }
        }

        public long Next
        {
            get
            {
                return this.m_next;
            }
            set
            {
                this.m_next = value;
            }
        }

        public int OwnerCode
        {
            get
            {
                return this.m_index;
            }
        }

        public TimerPriority Priority
        {
            get
            {
                return this.m_priority;
            }
            set
            {
                if (this.m_priority != value)
                {
                    this.m_priority = value;
                    if (this.Running)
                    {
                        TimerQueue.PriorityChange(this, (int) this.m_priority);
                    }
                }
            }
        }

        public bool Queued
        {
            get
            {
                return this.m_queued;
            }
            set
            {
                this.m_queued = value;
            }
        }

        public bool Running
        {
            get
            {
                return this.m_running;
            }
        }

        public bool StopQueued
        {
            get
            {
                return this.m_stopQueued;
            }
            set
            {
                this.m_stopQueued = value;
            }
        }
    }
}

