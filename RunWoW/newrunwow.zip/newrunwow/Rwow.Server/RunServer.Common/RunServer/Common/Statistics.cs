﻿namespace RunServer.Common
{
    using System;
    using System.Collections.Generic;
    using System.IO;

    public class Statistics
    {
        private static Dictionary<int, PacketStat> m_packetStats = new Dictionary<int, PacketStat>();

        public static void AddPacketTime(int packet, int time)
        {
            lock (m_packetStats)
            {
                if (!m_packetStats.ContainsKey(packet))
                {
                    m_packetStats.Add(packet, new PacketStat(packet));
                }
                m_packetStats[packet].AddTime(time);
            }
        }

        public static void DumpInfo(TextWriter writer)
        {
            List<PacketStat> list;
            lock (m_packetStats)
            {
                list = new List<PacketStat>(m_packetStats.Values);
            }
            list.Sort(new PacketStatCompararer());
            foreach (PacketStat stat in list)
            {
                writer.WriteLine("Packet {0}, Average Value {1}, Maximal Value {2}, Minimal Value {3}, Calls {4}", new object[] { stat.ID, stat.AverageValue, stat.MaximalValue, stat.MinimalValue, stat.Count });
            }
        }

        public class PacketStat
        {
            private int m_count;
            private int m_id;
            private int m_maximalValue = -2147483648;
            private int m_minimalValue = 0x7fffffff;
            private double m_value;

            public PacketStat(int id)
            {
                this.m_id = id;
            }

            public void AddTime(int value)
            {
                if (this.m_maximalValue < value)
                {
                    this.m_maximalValue = value;
                }
                if (this.m_minimalValue > value)
                {
                    this.m_minimalValue = value;
                }
                this.m_value += value;
                this.m_count++;
            }

            public double AverageValue
            {
                get
                {
                    return (this.m_value / ((double) this.m_count));
                }
            }

            public int Count
            {
                get
                {
                    return this.m_count;
                }
            }

            public int ID
            {
                get
                {
                    return this.m_id;
                }
            }

            public int MaximalValue
            {
                get
                {
                    return this.m_maximalValue;
                }
            }

            public int MinimalValue
            {
                get
                {
                    return this.m_minimalValue;
                }
            }
        }
    }
}

