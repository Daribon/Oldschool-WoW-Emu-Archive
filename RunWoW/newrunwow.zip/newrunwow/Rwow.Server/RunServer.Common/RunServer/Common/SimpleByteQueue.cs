﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.CompilerServices;

    public class SimpleByteQueue
    {
        private HeapBuffer m_buffer;
        private volatile bool m_locked;
        private int m_readPos;
        private object m_readSyncRoot;
        private int m_writePos;
        private object m_writeSyncRoot;

        public SimpleByteQueue(int size)
        {
            this.m_buffer = new HeapBuffer(size);
            this.m_readSyncRoot = new object();
            this.m_writeSyncRoot = new object();
            this.m_writePos = 0;
            this.m_readPos = 0;
        }

        public HeapBuffer Dequeue(int count)
        {
            lock (this.m_readSyncRoot)
            {
                if ((this.m_writePos - this.m_readPos) < count)
                {
                    return null;
                }
                if ((this.m_buffer.Length - this.m_readPos) < count)
                {
                    return null;
                }
                HeapBuffer buffer = new HeapBuffer(count);
                try
                {
                    buffer.WriteData(this.m_buffer.Handle, this.m_readPos, count, 0);
                }
                catch
                {
                    buffer.Dispose();
                    return null;
                }
                this.m_readPos += count;
                return buffer;
            }
        }

        public void Enqueue(IntPtr buffer, int count)
        {
            lock (this.m_writeSyncRoot)
            {
                if ((this.m_writePos + count) > this.m_buffer.Length)
                {
                    lock (this.m_readSyncRoot)
                    {
                        HeapBuffer buffer3;
                        this.m_locked = true;
                        if (this.m_readPos == this.m_writePos)
                        {
                            this.m_writePos = this.m_readPos = 0;
                            goto Label_0143;
                        }
                        if (this.m_readPos <= count)
                        {
                            goto Label_00FE;
                        }
                        int length = this.m_writePos - this.m_readPos;
                        if (this.m_readPos < length)
                        {
                            using (HeapBuffer buffer2 = new HeapBuffer(length))
                            {
                                buffer2.WriteData(this.m_buffer.Handle, this.m_readPos, length, 0);
                                this.m_buffer.WriteData(buffer2.Handle, 0, length, 0);
                                goto Label_00E2;
                            }
                        }
                        this.m_buffer.WriteData(this.m_buffer.Handle, this.m_readPos, length, 0);
                    Label_00E2:
                        this.m_writePos -= this.m_readPos;
                        this.m_readPos = 0;
                        goto Label_0143;
                    Label_00FE:
                        buffer3 = new HeapBuffer(this.m_writePos + count);
                        buffer3.WriteData(this.m_buffer.Handle, this.m_readPos, this.m_writePos - this.m_readPos, 0);
                        this.m_buffer.Dispose();
                        this.m_buffer = buffer3;
                    Label_0143:
                        this.m_locked = false;
                        goto Label_019C;
                    }
                }
                if (this.m_readPos == this.m_writePos)
                {
                    lock (this.m_readSyncRoot)
                    {
                        if (this.m_readPos == this.m_writePos)
                        {
                            this.m_writePos = this.m_readPos = 0;
                        }
                    }
                }
            Label_019C:
                this.m_buffer.WriteData(buffer, 0, count, this.m_writePos);
                this.m_writePos += count;
            }
        }

        public unsafe void Enqueue(byte[] data, int offset, int count)
        {
            fixed (byte* numRef = data)
            {
                this.Enqueue((IntPtr) (((int) numRef) + offset), count);
            }
        }

        ~SimpleByteQueue()
        {
            this.m_buffer.Dispose();
        }

        public bool Peek(byte[] buffer, int count)
        {
            lock (this.m_readSyncRoot)
            {
                if ((this.m_writePos - this.m_readPos) < count)
                {
                    return false;
                }
                this.m_buffer.ReadData(buffer, 0, count, this.m_readPos);
                return true;
            }
        }

        public void Skip(int count)
        {
            lock (this.m_readSyncRoot)
            {
                if (((this.m_writePos - this.m_readPos) >= count) && ((this.m_buffer.Length - this.m_readPos) >= count))
                {
                    this.m_readPos += count;
                }
            }
        }

        public int Length
        {
            get
            {
                return (this.m_writePos - this.m_readPos);
            }
        }

        public bool Locked
        {
            get
            {
                return this.m_locked;
            }
        }
    }
}

