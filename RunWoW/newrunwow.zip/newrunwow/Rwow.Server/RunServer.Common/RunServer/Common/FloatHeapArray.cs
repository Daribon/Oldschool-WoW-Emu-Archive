﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.InteropServices;

    public class FloatHeapArray : GenericHeapArray<float>
    {
        public FloatHeapArray(int size) : base(size, 4)
        {
        }

        public FloatHeapArray(int width, int height) : base(width, height, 4)
        {
        }

        public FloatHeapArray(int width, int height, float value) : base(width, height, value, 4)
        {
        }

        protected override void Copy(float[] array, int index, IntPtr target, int count)
        {
            Marshal.Copy(array, index, target, count);
        }

        protected override void Copy(IntPtr source, float[] array, int index, int count)
        {
            Marshal.Copy(source, array, index, count);
        }
    }
}

