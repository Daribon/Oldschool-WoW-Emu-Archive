﻿namespace RunServer.Common
{
    using System;
    using System.IO;
    using System.Text;

    public class StreamBinReader : BinaryReader
    {
        private byte[] m_data;

        public StreamBinReader(byte[] data) : base(new MemoryStream(data))
        {
            this.m_data = data;
        }

        public StreamBinReader(Stream input) : base(input)
        {
        }

        public StreamBinReader(Stream input, Encoding encoding) : base(input, encoding)
        {
        }

        ~StreamBinReader()
        {
            if (this.m_data != null)
            {
                BufferPool.Instance.ReleaseBuffer(this.m_data);
                this.m_data = null;
            }
        }

        public override string ReadString()
        {
            if (this.BaseStream.Position >= this.BaseStream.Length)
            {
                return string.Empty;
            }
            StringBuilder builder = new StringBuilder();
            while (this.BaseStream.Position < this.BaseStream.Length)
            {
                byte num = this.ReadByte();
                if (num == 0)
                {
                    break;
                }
                builder.Append((char) num);
            }
            return builder.ToString();
        }

        public string ReadString(int maxlen)
        {
            if (maxlen == 0)
            {
                return string.Empty;
            }
            byte[] bytes = new byte[maxlen];
            int index = 0;
            while (index < maxlen)
            {
                bytes[index] = this.ReadByte();
                if (bytes[index] == 0)
                {
                    break;
                }
                index++;
            }
            return Encoding.UTF8.GetString(bytes, 0, index);
        }
    }
}

