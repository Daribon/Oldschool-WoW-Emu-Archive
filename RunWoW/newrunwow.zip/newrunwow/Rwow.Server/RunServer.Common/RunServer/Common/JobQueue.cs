//
namespace RunServer.Common
{
    using System;
    using System.Globalization;
    using System.Threading;

    public class JobQueue
    {
        private bool m_finished = false;
        private bool m_highSpeed;
        private int m_jobBuffer;
        private FastLockQueue<IJob> m_jobQueue;

        public JobQueue(bool highSpeed, int size)
        {
            this.m_highSpeed = highSpeed;
            this.m_jobBuffer = size;
            this.m_jobQueue = new FastLockQueue<IJob>();
        }

        public void Enqueue(IJob job)
        {
            this.m_jobQueue.Enqueue(job);
        }

        private void Slice()
        {
            int count = this.m_jobQueue.Count;
            if (count != 0)
            {
                if (count > this.m_jobBuffer)
                {
                    count = this.m_jobBuffer;
                }
                for (int i = 0; i < count; i++)
                {
                    IJob job = this.m_jobQueue.Dequeue();
                    if (job == null)
                    {
                        return;
                    }
                    RunServer.Common.ThreadHelper.RegisterJob(job.Name);
                    job.Execute(null);
                    Thread.SpinWait(0x7d0);
                }
                Thread.Sleep(1);
            }
        }

        public void Start(CultureInfo culture)
        {
            Thread thread = new Thread(new ThreadStart(this.ThreadMain));
            if (!this.m_highSpeed)
            {
                thread.IsBackground = true;
            }
            else
            {
                thread.Priority = ThreadPriority.AboveNormal;
            }
            thread.CurrentCulture = culture;
            thread.Start();
        }

        public void Stop()
        {
            this.m_finished = true;
        }

        private void ThreadMain()
        {
            RunServer.Common.ThreadHelper.RegisterName(string.Format("JobQueue [{0}{1}]", this.m_jobBuffer, this.m_highSpeed ? ":HS" : ""));
            while (!this.m_finished)
            {
                try
                {
                    while (!this.m_finished)
                    {
                        this.Slice();
                        if (this.m_jobQueue.Count == 0)
                        {
                            Thread.Sleep(this.m_highSpeed ? 1 : 10);
                        }
                    }
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Error at job slice: " + exception);
                }
            }
        }
    }
}

