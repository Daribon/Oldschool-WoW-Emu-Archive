﻿namespace RunServer.Common
{
    using System;

    public enum TypeEnum : byte
    {
        @bool = 13,
        @byte = 1,
        byteArray = 11,
        DateTime = 15,
        @double = 10,
        @float = 9,
        @int = 5,
        @long = 7,
        none = 0,
        @sbyte = 2,
        @short = 3,
        @string = 12,
        type = 14,
        @uint = 6,
        @ulong = 8,
        @ushort = 4
    }
}

