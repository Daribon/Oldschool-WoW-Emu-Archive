//
namespace RunServer.Common
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;
    using System.Security;

    public class ConsoleCtrl : IDisposable
    {
        private ControlEventHandler eventHandler;

        public event ControlEventHandler ControlEvent;

        public ConsoleCtrl()
        {
            this.eventHandler = new ControlEventHandler(this.Handler);
            SetConsoleCtrlHandler(this.eventHandler, true);
        }

        public void Dispose()
        {
            this.Dispose(true);
        }

        private void Dispose(bool disposing)
        {
            if (this.eventHandler != null)
            {
                SetConsoleCtrlHandler(this.eventHandler, false);
                this.eventHandler = null;
            }
        }

        ~ConsoleCtrl()
        {
            this.Dispose(false);
        }

        private void Handler(ConsoleEvent consoleEvent)
        {
            if (this.ControlEvent != null)
            {
                this.ControlEvent(consoleEvent);
            }
        }

        [SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll")]
        private static extern bool SetConsoleCtrlHandler(ControlEventHandler e, bool add);

        public enum ConsoleEvent
        {
            CTRL_C = 0,
            CTRL_BREAK = 1,
            CTRL_CLOSE = 2,
            CTRL_LOGOFF = 5,
            CTRL_SHUTDOWN = 6
        }

        public delegate void ControlEventHandler(ConsoleCtrl.ConsoleEvent consoleEvent);
    }
}

