﻿namespace RunServer.Common
{
    using System;

    public class Vector
    {
        private float m_x;
        private float m_y;
        private float m_z;

        public Vector() : this(0f, 0f, 0f)
        {
            this.m_x = 0f;
            this.m_y = 0f;
            this.m_z = 0f;
        }

        public Vector(Vector other) : this(other.X, other.Y, other.Z)
        {
        }

        public Vector(float x, float y, float z)
        {
            this.m_x = x;
            this.m_y = y;
            this.m_z = z;
        }

        public float Angle(Vector v)
        {
            return (float) Math.Atan2((double) (v.X - this.X), (double) (v.Y - this.Y));
        }

        public float Angle(float x, float y)
        {
            return (float) Math.Atan2((double) (x - this.X), (double) (y - this.Y));
        }

        public bool Behind(float facing, Vector v)
        {
            double d = facing - this.RAngle(v);
            return (Math.Cos(d) <= 0);
        }

        public virtual Vector Clone()
        {
            return new Vector(this);
        }

        public float Distance(Vector v)
        {
            if (v == null)
            {
                return 0f;
            }
            return (float) Math.Sqrt((double) this.DistanceSqrd(v));
        }

        public float DistanceAvr(Vector v)
        {
            if (v == null)
            {
                return 0f;
            }
            return Math.Max(Math.Abs((float) (this.X - v.X)), Math.Abs((float) (this.Y - v.Y)));
        }

        public float DistanceFlat(Vector v)
        {
            if (v == null)
            {
                return 0f;
            }
            return (float) Math.Sqrt((double) this.DistanceFlatSqrd(v));
        }

        public float DistanceFlatSqrd(Vector v)
        {
            if (v == null)
            {
                return 0f;
            }
            float num = this.X - v.X;
            float num2 = this.Y - v.Y;
            return ((num * num) + (num2 * num2));
        }

        public float DistanceSqrd(Vector v)
        {
            if (v == null)
            {
                return 0f;
            }
            float num = this.X - v.X;
            float num2 = this.Y - v.Y;
            float num3 = this.Z - v.Z;
            return (((num * num) + (num2 * num2)) + (num3 * num3));
        }

        public override bool Equals(object obj)
        {
            Vector vector = (Vector) obj;
            if ((this.X == vector.X) && (this.Y == vector.Y))
            {
                return (this.Z == vector.Z);
            }
            return false;
        }

        public override int GetHashCode()
        {
            return (int) ((this.X + this.Y) + this.Z);
        }

        public bool InFront(float facing, Vector v)
        {
            double d = facing - this.RAngle(v);
            return (Math.Cos(d) >= 0);
        }

        public static Vector operator +(Vector v1, Vector v2)
        {
            return new Vector(v1.X + v2.X, v1.Y + v2.Y, v1.Z + v2.Z);
        }

        public static Vector operator /(Vector v1, float d)
        {
            return new Vector(v1.X / d, v1.Y / d, v1.Z / d);
        }

        public static Vector operator *(Vector v1, float d)
        {
            return new Vector(v1.X * d, v1.Y * d, v1.Z * d);
        }

        public static Vector operator -(Vector v1, Vector v2)
        {
            return new Vector(v1.X - v2.X, v1.Y - v2.Y, v1.Z - v2.Z);
        }

        public float RAngle(Vector v)
        {
            return (float) Math.Atan2((double) (v.Y - this.Y), (double) (v.X - this.X));
        }

        public override string ToString()
        {
            return (this.X.ToString() + " " + this.Y.ToString() + " " + this.Z.ToString());
        }

        public virtual float X
        {
            get
            {
                return this.m_x;
            }
            set
            {
                this.m_x = value;
            }
        }

        public virtual float Y
        {
            get
            {
                return this.m_y;
            }
            set
            {
                this.m_y = value;
            }
        }

        public virtual float Z
        {
            get
            {
                return this.m_z;
            }
            set
            {
                this.m_z = value;
            }
        }
    }
}

