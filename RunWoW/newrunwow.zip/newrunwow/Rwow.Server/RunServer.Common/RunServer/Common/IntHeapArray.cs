﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.InteropServices;

    public class IntHeapArray : GenericHeapArray<int>
    {
        public IntHeapArray(int size) : base(size, 4)
        {
        }

        public IntHeapArray(int width, int height) : base(width, height, 4)
        {
        }

        public IntHeapArray(int width, int height, int value) : base(width, height, value, 4)
        {
        }

        protected override void Copy(int[] array, int index, IntPtr target, int count)
        {
            Marshal.Copy(array, index, target, count);
        }

        protected override void Copy(IntPtr source, int[] array, int index, int count)
        {
            Marshal.Copy(source, array, index, count);
        }
    }
}

