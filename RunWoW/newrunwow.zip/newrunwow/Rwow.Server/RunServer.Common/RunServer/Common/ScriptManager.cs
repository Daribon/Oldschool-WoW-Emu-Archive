//
namespace RunServer.Common
{
    using Microsoft.CSharp;
    using Microsoft.VisualBasic;
    using System;
    using System.CodeDom.Compiler;
    using System.Collections.Specialized;
    using System.IO;
    using System.Reflection;
    using System.Runtime.InteropServices;

    public class ScriptManager
    {
        private CompilerParameters m_params = new CompilerParameters();
        private static TempFileCollection s_tempFiles;
        private string TempDir = "./Temp/";

        public ScriptManager()
        {
            this.m_params.GenerateInMemory = false;
            this.m_params.GenerateExecutable = false;
            this.m_params.WarningLevel = 4;
            this.m_params.IncludeDebugInformation = true;
            this.m_params.CompilerOptions = "/nowarn:0465 /nowarn:0618 /nowarn:0429 /nowarn:0162 /d:DOTNET2";
            if (!Directory.Exists(this.TempDir))
            {
                Directory.CreateDirectory(this.TempDir);
            }
            if (s_tempFiles == null)
            {
                s_tempFiles = new TempFileCollection(this.TempDir);
            }
            this.m_params.TempFiles = s_tempFiles;
        }

        private Assembly AddAssembly(CodeDomProvider provider, string path, out string error)
        {
            error = string.Empty;
            string[] files = this.GetFiles(path, "*." + provider.FileExtension);
            if (files.Length == 0)
            {
                return null;
            }
            this.m_params.OutputAssembly = this.TempDir + Path.GetRandomFileName();
            CompilerResults results = this.Compile(provider, files);
            if (results.Errors.Count > 0)
            {
                this.ReportErrors(path, provider.FileExtension + "errors.txt", results, out error);
                return null;
            }
            return results.CompiledAssembly;
        }

        public void AddReference(string module)
        {
            if (!this.m_params.ReferencedAssemblies.Contains(module))
            {
                this.m_params.ReferencedAssemblies.Add(module);
            }
        }

        private CompilerResults Compile(CodeDomProvider provider, string[] files)
        {
            return provider.CompileAssemblyFromFile(this.m_params, files);
        }

        public Assembly CompileFolder(string path, out string error)
        {
            Assembly assembly;
            if (!Directory.Exists(path))
            {
                error = string.Format("Directory {0} not found!", path);
                return null;
            }
            using (CodeDomProvider provider = new CSharpCodeProvider())
            {
                assembly = this.AddAssembly(provider, path, out error);
            }
            if (assembly != null)
            {
                return assembly;
            }
            if (error == string.Empty)
            {
                using (CodeDomProvider provider2 = new VBCodeProvider())
                {
                    assembly = this.AddAssembly(provider2, path, out error);
                }
                if (assembly != null)
                {
                    return assembly;
                }
                if (error != string.Empty)
                {
                    return null;
                }
            }
            return null;
        }

        public static void DeleteAllFiles()
        {
            s_tempFiles.Delete();
        }

        private string[] GetFiles(string path, string searchPattern)
        {
            string[] directories;
            string[] objs;
            CustomArrayList list = new CustomArrayList();
            try
            {
                directories = Directory.GetDirectories(path);
            }
            catch (DirectoryNotFoundException)
            {
                return new string[0];
            }
            foreach (string text in directories)
            {
                list.AddRange(this.GetFiles(text, searchPattern));
            }
            try
            {
                objs = Directory.GetFiles(path, searchPattern);
            }
            catch (Exception)
            {
                objs = new string[0];
            }
            list.AddRange(objs);
            string[] array = new string[list.Count];
            list.CopyTo(array);
            return array;
        }

        private void ReportErrors(string path, string file, CompilerResults results, out string error)
        {
            string text = path;
            if (!text.EndsWith(@"\") && !text.EndsWith("/"))
            {
                text = text + "/";
            }
            text = text + file;
            StreamWriter writer = new StreamWriter(text);
            StringEnumerator enumerator = results.Output.GetEnumerator();
            while (enumerator.MoveNext())
            {
                writer.WriteLine(enumerator.Current);
            }
            writer.Close();
            error = "Scripts under " + path + " had errors. Log saved in " + text;
        }
    }
}

