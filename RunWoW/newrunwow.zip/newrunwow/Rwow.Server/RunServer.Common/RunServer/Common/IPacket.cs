//
namespace RunServer.Common
{
    using System;

    public interface IPacket
    {
        void Aquire();
        void Finish();
        byte[] GetBuffer();
        IntPtr GetHandle();
        void Release();

        bool Empty { get; }

        int Length { get; }
    }
}

