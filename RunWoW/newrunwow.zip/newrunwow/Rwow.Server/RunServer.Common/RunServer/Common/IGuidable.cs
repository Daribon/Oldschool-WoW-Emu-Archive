//
namespace RunServer.Common
{
    using System;

    public interface IGuidable
    {
        ulong GUID { get; }
    }
}

