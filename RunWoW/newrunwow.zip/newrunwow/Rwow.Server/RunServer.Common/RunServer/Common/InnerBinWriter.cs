//
namespace RunServer.Common
{
    using System;
    using System.Collections;
    using System.Runtime.InteropServices;
    using System.Text;

    public class InnerBinWriter : DisposableType
    {
        private byte[] m_buffer;
        private int m_capacity;
        private Encoding m_encoding;
        private int m_index;
        private int m_length;
        private char[] m_SingleCharBuffer;

        public InnerBinWriter() : this(0)
        {
            this.m_buffer = BufferPool.Instance.AquireBuffer();
            this.m_capacity = this.m_buffer.Length;
        }

        protected InnerBinWriter(int bufferLength)
        {
            this.m_SingleCharBuffer = new char[1];
            this.m_buffer = null;
            this.m_capacity = bufferLength;
            this.m_encoding = Encoding.UTF8;
            this.m_length = 0;
            this.m_index = 0;
        }

        protected override void Dispose(bool disposing)
        {
            if (this.m_buffer != null)
            {
                BufferPool.Instance.ReleaseBuffer(this.m_buffer);
                this.m_buffer = null;
            }
        }

        protected virtual void EnsureCapacity(int length)
        {
            if (length > this.m_capacity)
            {
                byte[] src = this.m_buffer;
                this.m_capacity = (length + 0x7ff) & -2048;
                this.m_buffer = BufferPool.Instance.AquireBuffer(this.m_capacity);
                Buffer.BlockCopy(src, 0, this.m_buffer, 0, this.m_length);
                BufferPool.Instance.ReleaseBuffer(src);
            }
        }

        public virtual byte[] GetBuffer()
        {
            return this.m_buffer;
        }

        public void Set(int offset, byte value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.Write(value);
            this.m_index = index;
        }

        public void Set(int offset, short value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.Write(value);
            this.m_index = index;
        }

        public void Set(int offset, int value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.Write(value);
            this.m_index = index;
        }

        public void Set(int offset, sbyte value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.Write(value);
            this.m_index = index;
        }

        public void Set(int offset, string value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.Write(value);
            this.m_index = index;
        }

        public void Set(int offset, ushort value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.Write(value);
            this.m_index = index;
        }

        public void Set(int offset, uint value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.Write(value);
            this.m_index = index;
        }

        public void SetObject(int offset, object value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.WriteObject(value);
            this.m_index = index;
        }

        public void SetVector(int offset, Vector value)
        {
            int index = this.m_index;
            this.m_index = offset;
            this.WriteVector(value);
            this.m_index = index;
        }

        public virtual void Write(bool value)
        {
            this.EnsureCapacity(this.m_index + 1);
            this.m_buffer[this.m_index++] = value ? ((byte) 1) : ((byte) 0);
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual void Write(byte value)
        {
            this.EnsureCapacity(this.m_index + 1);
            this.m_buffer[this.m_index++] = value;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual void Write(char value)
        {
            this.EnsureCapacity(this.m_index + 2);
            this.m_SingleCharBuffer[0] = value;
            int num = this.m_encoding.GetBytes(this.m_SingleCharBuffer, 0, 1, this.m_buffer, this.m_index);
            this.m_index += num;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public void Write(DateTime value)
        {
            this.Write(value.Ticks);
        }

        public virtual unsafe void Write(double value)
        {
            this.EnsureCapacity(this.m_index + 8);
            byte* numPtr = stackalloc byte[(1 * 8)];
            *((double*) numPtr) = value;
            Marshal.Copy((IntPtr) numPtr, this.m_buffer, this.m_index, 8);
            /*fixed (byte* b = m_buffer) *((double*)(b + m_index)) = value;
            this.m_index += 8;*/
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual void Write(short value)
        {
            this.EnsureCapacity(this.m_index + 2);
            this.m_buffer[this.m_index] = (byte) (value % 256);
            this.m_buffer[this.m_index + 1] = (byte) ((value >> 8) % 256);
            this.m_index += 2;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual void Write(int value)
        {
//            this.EnsureCapacity(this.m_index + 4);
//            this.m_buffer[this.m_index] = (byte) (value % 256);
//            this.m_buffer[this.m_index + 1] = (byte) ((value >> 8) % 256);
//            this.m_buffer[this.m_index + 2] = (byte) ((value >> 16) % 256);
//            this.m_buffer[this.m_index + 3] = (byte) ((value >> 24) % 256);
//            this.m_index += 4;
            Write((byte) (value % 256));
            Write((byte) ((value >> 8) % 256));
            Write((byte) ((value >> 16) % 256));
            Write((byte) ((value >> 24) % 256));
//            if (this.m_index > this.m_length)
//            {
//                this.m_length = this.m_index;
//            }
        }

        public void Write(byte[] data)
        {
            this.Write(data, 0, data.Length);
        }

        public virtual void Write(long value)
        {
            this.EnsureCapacity(this.m_index + 8);
            this.m_buffer[this.m_index] = (byte) (value % 256);
            this.m_buffer[this.m_index + 1] = (byte) ((value >> 8) % 256);
            this.m_buffer[this.m_index + 2] = (byte) ((value >> 16) % 256);
            this.m_buffer[this.m_index + 3] = (byte) ((value >> 24) % 256);
            this.m_buffer[this.m_index + 4] = (byte) ((value >> 32) % 256);
            this.m_buffer[this.m_index + 5] = (byte) ((value >> 40) % 256);
            this.m_buffer[this.m_index + 6] = (byte) ((value >> 48) % 256);
            this.m_buffer[this.m_index + 7] = (byte) ((value >> 56) % 256);
            this.m_index += 8;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual void Write(sbyte value)
        {
            this.EnsureCapacity(this.m_index + 1);
            this.m_buffer[this.m_index++] = (byte) value;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual unsafe void Write(float value)
        {
            this.EnsureCapacity(this.m_index + 4);
            byte* numPtr = stackalloc byte[(1 * 4)];
            *((float*) numPtr) = value;
            Marshal.Copy((IntPtr) numPtr, this.m_buffer, this.m_index, 4);
            /*fixed (byte* b = m_buffer) *((float*)(b + m_index)) = value;
            this.m_index += 4;*/
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public void Write(string value)
        {
            if (value.Length > 0)
            {
                byte[] data = Encoding.UTF8.GetBytes(value);
                this.Write(data);
            }
            this.Write((byte) 0);
        }

        public void Write(Type value)
        {
            if (value == typeof(byte))
            {
                this.Write((byte) 1);
            }
            else if (value == typeof(sbyte))
            {
                this.Write((byte) 2);
            }
            else if (value == typeof(bool))
            {
                this.Write((byte) 13);
            }
            else if (value == typeof(short))
            {
                this.Write((byte) 3);
            }
            else if (value == typeof(ushort))
            {
                this.Write((byte) 4);
            }
            else if (value == typeof(int))
            {
                this.Write((byte) 5);
            }
            else if (value == typeof(uint))
            {
                this.Write((byte) 6);
            }
            else if (value == typeof(long))
            {
                this.Write((byte) 7);
            }
            else if (value == typeof(ulong))
            {
                this.Write((byte) 8);
            }
            else if (value == typeof(float))
            {
                this.Write((byte) 9);
            }
            else if (value == typeof(double))
            {
                this.Write((byte) 10);
            }
            else if (value == typeof(byte[]))
            {
                this.Write((byte) 11);
            }
            else if (value == typeof(string))
            {
                this.Write((byte) 12);
            }
            else if (value == typeof(Type))
            {
                this.Write((byte) 14);
            }
            else if (value == typeof(DateTime))
            {
                this.Write((byte) 15);
            }
            else
            {
                if (!value.IsEnum)
                {
                    throw new Exception("Writing object of unknown type " + value.Name);
                }
                this.Write(Enum.GetUnderlyingType(value));
            }
        }

        public virtual void Write(ushort value)
        {
            this.EnsureCapacity(this.m_index + 2);
            this.m_buffer[this.m_index] = (byte) (value % 256);
            this.m_buffer[this.m_index + 1] = (byte) ((value >> 8) % 256);
            this.m_index += 2;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual void Write(uint value)
        {
            this.EnsureCapacity(this.m_index + 4);
            this.m_buffer[this.m_index] = (byte) (value % 256);
            this.m_buffer[this.m_index + 1] = (byte) ((value >> 8) % 256);
            this.m_buffer[this.m_index + 2] = (byte) ((value >> 16) % 256);
            this.m_buffer[this.m_index + 3] = (byte) ((value >> 24) % 256);
            this.m_index += 4;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public virtual void Write(ulong value)
        {
            this.EnsureCapacity(this.m_index + 8);
            this.m_buffer[this.m_index] = (byte) (value % 256);
            this.m_buffer[this.m_index + 1] = (byte) ((value >> 8) % 256);
            this.m_buffer[this.m_index + 2] = (byte) ((value >> 16) % 256);
            this.m_buffer[this.m_index + 3] = (byte) ((value >> 24) % 256);
            this.m_buffer[this.m_index + 4] = (byte) ((value >> 32) % 256);
            this.m_buffer[this.m_index + 5] = (byte) ((value >> 40) % 256);
            this.m_buffer[this.m_index + 6] = (byte) ((value >> 48) % 256);
            this.m_buffer[this.m_index + 7] = (byte) ((value >> 56) % 256);
            this.m_index += 8;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public void Write(byte[] data, int len)
        {
            this.Write(data, 0, len);
        }

        public virtual void Write(byte[] data, int offset, int len)
        {
            this.EnsureCapacity(this.m_index + len);
            Buffer.BlockCopy(data, offset, this.m_buffer, this.m_index, len);
            this.m_index += len;
            if (this.m_index > this.m_length)
            {
                this.m_length = this.m_index;
            }
        }

        public void WriteGuid(ulong value)
        {
            byte[] bytes = BitConverter.GetBytes(value);
            int num = 0;
            int index = 0;
            for (int i = 0; i < 8; i++)
            {
                if (bytes[i] != 0)
                {
                    index++;
                    num |= ((int) 1) << i;
                }
            }
            byte[] data = new byte[index + 1];
            data[0] = (byte) num;
            index = 0;
            for (int j = 0; j < 8; j++)
            {
                if (bytes[j] != 0)
                {
                    index++;
                    data[index] = bytes[j];
                }
            }
            this.Write(data);
        }

        public void WriteObject(object value)
        {
            if (value is byte)
            {
                this.Write((byte) value);
            }
            else if (value is sbyte)
            {
                this.Write((sbyte) value);
            }
            else if (value is short)
            {
                this.Write((short) value);
            }
            else if (value is ushort)
            {
                this.Write((ushort) value);
            }
            else if (value is int)
            {
                this.Write((int) value);
            }
            else if (value is uint)
            {
                this.Write((uint) value);
            }
            else if (value is long)
            {
                this.Write((long) value);
            }
            else if (value is ulong)
            {
                this.Write((ulong) value);
            }
            else if (value is float)
            {
                this.Write((float) value);
            }
            else if (value is double)
            {
                this.Write((double) value);
            }
            else if (value is byte[])
            {
                this.Write((byte[]) value);
            }
            else if (value is string)
            {
                this.Write((string) value);
            }
            else if (value is Type)
            {
                this.Write((Type) value);
            }
            else if (value is DateTime)
            {
                this.Write((DateTime) value);
            }
            else
            {
                if (!value.GetType().IsEnum)
                {
                    throw new Exception("Writing object of unknown type " + value.GetType().Name);
                }
                this.WriteObject(Convert.ChangeType(value, Enum.GetUnderlyingType(value.GetType())));
            }
        }

        public void WriteObjects(ICollection values)
        {
            this.Write(values.Count);
            foreach (object obj2 in values)
            {
                this.WriteObject(obj2);
            }
        }

        public void WriteString(string value)
        {
            if (value.Length > 0)
            {
                byte[] data = this.m_encoding.GetBytes(value);
                this.Write((int) (data.Length + 1));
                this.Write(data);
                this.Write((byte) 0);
            }
            else
            {
                this.Write(0);
            }
        }

        public void WriteVariantDictionary(IDictionary values)
        {
            this.Write(values.Count);
            foreach (DictionaryEntry entry in values)
            {
                this.WriteVariantObject(entry.Key);
                this.WriteVariantObject(entry.Value);
            }
        }

        public void WriteVariantObject(object value)
        {
            if (value is byte)
            {
                this.Write((byte) 1);
                this.Write((byte) value);
            }
            else if (value is sbyte)
            {
                this.Write((byte) 2);
                this.Write((sbyte) value);
            }
            else if (value is bool)
            {
                this.Write((byte) 13);
                this.Write((bool) value);
            }
            else if (value is short)
            {
                this.Write((byte) 3);
                this.Write((short) value);
            }
            else if (value is ushort)
            {
                this.Write((byte) 4);
                this.Write((ushort) value);
            }
            else if (value is int)
            {
                this.Write((byte) 5);
                this.Write((int) value);
            }
            else if (value is uint)
            {
                this.Write((byte) 6);
                this.Write((uint) value);
            }
            else if (value is long)
            {
                this.Write((byte) 7);
                this.Write((long) value);
            }
            else if (value is ulong)
            {
                this.Write((byte) 8);
                this.Write((ulong) value);
            }
            else if (value is float)
            {
                this.Write((byte) 9);
                this.Write((float) value);
            }
            else if (value is double)
            {
                this.Write((byte) 10);
                this.Write((double) value);
            }
            else if (value is byte[])
            {
                this.Write((byte) 11);
                this.Write(((byte[]) value).Length);
                this.Write((byte[]) value);
            }
            else if (value is string)
            {
                this.Write((byte) 12);
                this.Write((string) value);
            }
            else if (value is Type)
            {
                this.Write((byte) 14);
                this.Write((Type) value);
            }
            else if (value is DateTime)
            {
                this.Write((byte) 15);
                this.Write((DateTime) value);
            }
            else
            {
                if (!value.GetType().IsEnum)
                {
                    throw new Exception("Writing object of unknown type " + value.GetType().Name);
                }
                this.WriteVariantObject(Convert.ChangeType(value, Enum.GetUnderlyingType(value.GetType())));
            }
        }

        public void WriteVariantObjectArray(object[][] values)
        {
            this.Write(values.Length);
            foreach (object[] objArray in values)
            {
                this.WriteVariantObjects(objArray);
            }
        }

        public void WriteVariantObjects(ICollection values)
        {
            this.Write(values.Count);
            foreach (object obj2 in values)
            {
                this.WriteVariantObject(obj2);
            }
        }

        public void WriteVector(Vector value)
        {
            this.Write(value.X);
            this.Write(value.Y);
            this.Write(value.Z);
        }

        public InnerBinWriter BaseStream
        {
            get
            {
                return this;
            }
        }

        protected int Capacity
        {
            get
            {
                return this.m_capacity;
            }
            set
            {
                this.m_capacity = value;
            }
        }

        public int Length
        {
            get
            {
                return this.m_length;
            }
            set
            {
                this.m_length = value;
            }
        }

        public int Position
        {
            get
            {
                return this.m_index;
            }
            set
            {
                this.m_index = value;
            }
        }
    }
}

