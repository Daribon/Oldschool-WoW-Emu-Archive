﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.CompilerServices;
    using System.Runtime.InteropServices;

    public class OldSimpleByteQueue
    {
        private byte[] m_buffer;
        private int m_length;
        private volatile bool m_locked;
        private int m_readPos;
        private object m_readSyncRoot;
        private int m_writePos;
        private object m_writeSyncRoot;

        public OldSimpleByteQueue(int size)
        {
            this.m_buffer = BufferPool.Instance.AquireBuffer(size);
            this.m_readSyncRoot = new object();
            this.m_writeSyncRoot = new object();
            this.m_length = this.m_buffer.Length;
            this.m_writePos = 0;
            this.m_readPos = 0;
        }

        public HeapBuffer Dequeue(int count)
        {
            byte[] data = this.Dequeue(count, false);
            if (data == null)
            {
                return null;
            }
            return new HeapBuffer(data, 0, count);
        }

        public byte[] Dequeue(int count, bool precise)
        {
            lock (this.m_readSyncRoot)
            {
                if ((this.m_writePos - this.m_readPos) < count)
                {
                    return null;
                }
                if ((this.m_buffer.Length - this.m_readPos) < count)
                {
                    return null;
                }
                byte[] dst = precise ? new byte[count] : BufferPool.Instance.AquireBuffer(count);
                try
                {
                    Buffer.BlockCopy(this.m_buffer, this.m_readPos, dst, 0, count);
                }
                catch
                {
                    return null;
                }
                this.m_readPos += count;
                return dst;
            }
        }

        public bool Dequeue(byte[] buffer, int count)
        {
            lock (this.m_readSyncRoot)
            {
                if ((this.m_writePos - this.m_readPos) < count)
                {
                    return false;
                }
                Buffer.BlockCopy(this.m_buffer, this.m_readPos, buffer, 0, count);
                this.m_readPos += count;
                return true;
            }
        }

        public void Enqueue(byte[] buffer, int count)
        {
            lock (this.m_writeSyncRoot)
            {
                if ((this.m_writePos + count) > this.m_length)
                {
                    lock (this.m_readSyncRoot)
                    {
                        this.m_locked = true;
                        if (this.m_readPos == this.m_writePos)
                        {
                            this.m_writePos = this.m_readPos = 0;
                        }
                        else if (this.m_readPos > count)
                        {
                            int minSize = this.m_writePos - this.m_readPos;
                            if (this.m_readPos < minSize)
                            {
                                byte[] dst = BufferPool.Instance.AquireBuffer(minSize);
                                Buffer.BlockCopy(this.m_buffer, this.m_readPos, dst, 0, minSize);
                                Buffer.BlockCopy(dst, 0, this.m_buffer, 0, minSize);
                                BufferPool.Instance.ReleaseBuffer(dst);
                            }
                            else
                            {
                                Buffer.BlockCopy(this.m_buffer, this.m_readPos, this.m_buffer, 0, minSize);
                            }
                            this.m_writePos -= this.m_readPos;
                            this.m_readPos = 0;
                        }
                        else
                        {
                            int num2 = this.m_writePos + count;
                            byte[] buffer3 = BufferPool.Instance.AquireBuffer(((num2 / this.m_length) + 1) * this.m_length);
                            Buffer.BlockCopy(this.m_buffer, this.m_readPos, buffer3, this.m_readPos, this.m_writePos - this.m_readPos);
                            BufferPool.Instance.ReleaseBuffer(this.m_buffer);
                            this.m_buffer = buffer3;
                        }
                        this.m_locked = false;
                    }
                }
                Buffer.BlockCopy(buffer, 0, this.m_buffer, this.m_writePos, count);
                this.m_writePos += count;
            }
        }

        public void Enqueue(IntPtr buffer, int count)
        {
            byte[] destination = new byte[count];
            Marshal.Copy(buffer, destination, 0, count);
            this.Enqueue(destination, count);
        }

        ~OldSimpleByteQueue()
        {
            BufferPool.Instance.ReleaseBuffer(this.m_buffer);
        }

        public bool Peek(byte[] buffer, int count)
        {
            lock (this.m_readSyncRoot)
            {
                if ((this.m_writePos - this.m_readPos) < count)
                {
                    return false;
                }
                Buffer.BlockCopy(this.m_buffer, this.m_readPos, buffer, 0, count);
                return true;
            }
        }

        public byte[] Peek(int count, bool precise)
        {
            lock (this.m_readSyncRoot)
            {
                if ((this.m_writePos - this.m_readPos) < count)
                {
                    return null;
                }
                if ((this.m_buffer.Length - this.m_readPos) < count)
                {
                    return null;
                }
                byte[] dst = precise ? new byte[count] : BufferPool.Instance.AquireBuffer(count);
                try
                {
                    Buffer.BlockCopy(this.m_buffer, this.m_readPos, dst, 0, count);
                }
                catch
                {
                    return null;
                }
                return dst;
            }
        }

        public void Skip(int count)
        {
            lock (this.m_readSyncRoot)
            {
                if (((this.m_writePos - this.m_readPos) >= count) && ((this.m_buffer.Length - this.m_readPos) >= count))
                {
                    this.m_readPos += count;
                }
            }
        }

        public byte[] SmartPeek(int count, out int offset)
        {
            lock (this.m_readSyncRoot)
            {
                offset = this.m_readPos;
                if ((this.m_writePos - this.m_readPos) < count)
                {
                    return null;
                }
                if ((this.m_buffer.Length - this.m_readPos) < count)
                {
                    return null;
                }
                return this.m_buffer;
            }
        }

        public int Length
        {
            get
            {
                return (this.m_writePos - this.m_readPos);
            }
        }

        public bool Locked
        {
            get
            {
                return this.m_locked;
            }
        }
    }
}

