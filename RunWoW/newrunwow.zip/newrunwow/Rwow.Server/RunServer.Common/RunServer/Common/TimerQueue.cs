﻿namespace RunServer.Common
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;
    using System.Security;

    public class TimerQueue
    {
        private static Queue m_ChangeQueue = Queue.Synchronized(new Queue());
        private IJobHandler m_jobHandler;
        private static long[] m_NextPriorities = new long[8];
        private static long[] m_PriorityDelays = new long[] { 0, 0x186a0, 0x3d090, 0x7a120, 0x2625a0, 0x989680, 0x2faf080, 0x23c34600 };
        private static Dictionary<long, Timer>[] m_Timers = new Dictionary<long, Timer>[] { new Dictionary<long, Timer>(), new Dictionary<long, Timer>(), new Dictionary<long, Timer>(), new Dictionary<long, Timer>(), new Dictionary<long, Timer>(), new Dictionary<long, Timer>(), new Dictionary<long, Timer>(), new Dictionary<long, Timer>() };
        private static long timerFrequency;
        private static double timerMultiplier;
        private static long timerShift;
        private static long timerTick;

        static TimerQueue()
        {
            QueryPerformanceFrequency(out timerFrequency);
            timerMultiplier = 10000000 / ((double) timerFrequency);
            Console.WriteLine("Working with timer resolution {0} ms", 1000 / ((double) timerFrequency));
            QueryPerformanceCounter(out timerTick);
            timerShift = DateTime.Now.Ticks - ((long) (timerTick * timerMultiplier));
        }

        public TimerQueue(IJobHandler jobHandler)
        {
            this.m_jobHandler = jobHandler;
        }

        public static void AddTimer(Timer timer)
        {
            Change(timer, (int) timer.Priority, true);
        }

        public static void Change(Timer t, int newIndex, bool isAdd)
        {
            m_ChangeQueue.Enqueue(TimerChangeEntry.GetInstance(t, newIndex, isAdd));
        }

        public static long GetTickCount()
        {
            QueryPerformanceCounter(out timerTick);
            return (((long) (timerTick * timerMultiplier)) + timerShift);
        }

        public static void PriorityChange(Timer timer, int newPrio)
        {
            Change(timer, newPrio, false);
        }

        private static void ProcessChangeQueue(long now)
        {
            int count = m_ChangeQueue.Count;
            if (count != 0)
            {
                while (count > 0)
                {
                    TimerChangeEntry entry = (TimerChangeEntry) m_ChangeQueue.Dequeue();
                    Timer timer = entry.m_Timer;
                    int index = entry.m_NewIndex;
                    if (timer.m_List != null)
                    {
                        timer.m_List.Remove(timer.m_ListKey);
                    }
                    if (entry.m_IsAdd)
                    {
                        timer.Next = now + timer.Delay.Ticks;
                        timer.Index = 0;
                    }
                    if (index >= 0)
                    {
                        timer.m_List = m_Timers[index];
                        timer.m_List[timer.m_ListKey] = timer;
                    }
                    else
                    {
                        timer.m_List = null;
                    }
                    entry.Free();
                    count--;
                }
            }
        }

        [SuppressUnmanagedCodeSecurity, DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceCounter(out long lpPerformanceCount);
        [SuppressUnmanagedCodeSecurity, DllImport("Kernel32.dll")]
        private static extern bool QueryPerformanceFrequency(out long lpFrequency);
        public static void RemoveTimer(Timer t)
        {
            Change(t, -1, false);
        }

        public void Slice()
        {
            long ticks = GetTickCount();
            CustomDateTime.UpdateNow(ticks);
            ProcessChangeQueue(ticks);
            for (int i = 0; i < m_Timers.Length; i++)
            {
                if (ticks < m_NextPriorities[i])
                {
                    return;
                }
                m_NextPriorities[i] = ticks + m_PriorityDelays[i];
                foreach (Timer timer in m_Timers[i].Values)
                {
                    if (timer.Queued || (ticks < timer.Next))
                    {
                        continue;
                    }
                    timer.Queued = true;
                    this.m_jobHandler.AddJob(timer);
                    if (((timer.Count > 0) && (++timer.Index >= timer.Count)) || (timer.Interval == TimeSpan.Zero))
                    {
                        timer.QueueStop();
                        continue;
                    }
                    timer.Next = ticks + timer.Interval.Ticks;
                }
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        private struct TimerChangeEntry
        {
            public Timer m_Timer;
            public int m_NewIndex;
            public bool m_IsAdd;
            private static FastLockQueue<TimerQueue.TimerChangeEntry> m_instancePool;
            private TimerChangeEntry(Timer timer, int newIndex, bool isAdd)
            {
                this.m_Timer = timer;
                this.m_NewIndex = newIndex;
                this.m_IsAdd = isAdd;
            }

            public void Free()
            {
                m_instancePool.Enqueue(this);
            }

            public static TimerQueue.TimerChangeEntry GetInstance(Timer timer, int newIndex, bool isAdd)
            {
                if (m_instancePool.Count > 0)
                {
                    TimerQueue.TimerChangeEntry entry = m_instancePool.Dequeue();
                    entry.m_Timer = timer;
                    entry.m_NewIndex = newIndex;
                    entry.m_IsAdd = isAdd;
                    return entry;
                }
                return new TimerQueue.TimerChangeEntry(timer, newIndex, isAdd);
            }

            static TimerChangeEntry()
            {
                m_instancePool = new FastLockQueue<TimerQueue.TimerChangeEntry>();
            }
        }
    }
}

