﻿namespace RunServer.Common
{
    using System;

    public class Helper
    {
        public static bool Assign(ref Vector var, Vector value)
        {
            if (!var.Equals(value))
            {
                Vector vector;
                var = vector = value;
                return value.Equals(vector);
            }
            return false;
        }

        public static bool Assign(ref bool var, bool value)
        {
            if (!var.Equals(value))
            {
                bool flag;
                var = flag = value;
                return (value == flag);
            }
            return false;
        }

        public static bool Assign(ref byte var, byte value)
        {
            if (!((byte) var).Equals(value))
            {
                byte num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref DateTime var, DateTime value)
        {
            if (!var.Equals(value))
            {
                DateTime time;
                var = time = value;
                return (value == time);
            }
            return false;
        }

        public static bool Assign(ref short var, short value)
        {
            if (!((short) var).Equals(value))
            {
                short num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref int var, int value)
        {
            if (!((int) var).Equals(value))
            {
                int num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref long var, long value)
        {
            if (!((long) var).Equals(value))
            {
                long num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref sbyte var, sbyte value)
        {
            if (!((sbyte) var).Equals(value))
            {
                sbyte num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref float var, float value)
        {
            if (!((float) var).Equals(value))
            {
                float num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref string var, string value)
        {
            string text;
            if ((var != null) && var.Equals(value))
            {
                return false;
            }
            var = text = value;
            return (value == text);
        }

        public static bool Assign(ref ushort var, ushort value)
        {
            if (!((ushort) var).Equals(value))
            {
                ushort num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref uint var, uint value)
        {
            if (!((uint) var).Equals(value))
            {
                uint num;
                var = num = value;
                return (value == num);
            }
            return false;
        }

        public static bool Assign(ref ulong var, ulong value)
        {
            if (!((ulong) var).Equals(value))
            {
                ulong num;
                var = num = value;
                return (value == num);
            }
            return false;
        }
    }
}

