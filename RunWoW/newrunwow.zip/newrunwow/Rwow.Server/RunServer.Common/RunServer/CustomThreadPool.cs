//
namespace RunServer
{
    using RunServer.Common;
    using System;
    using System.Collections.Generic;
    using System.Threading;

    public sealed class CustomThreadPool : IDisposable
    {
        private FastLockQueue<WaitQueueItem> m_queue;
        private List<Thread> m_threads;

        public CustomThreadPool(int numThreads)
        {
            if (numThreads <= 0)
            {
                throw new ArgumentOutOfRangeException("numThreads");
            }
            this.m_threads = new List<Thread>(numThreads);
            this.m_queue = new FastLockQueue<WaitQueueItem>();
            for (int i = 0; i < numThreads; i++)
            {
                Thread item = new Thread(new ThreadStart(this.Run));
                item.IsBackground = true;
                this.m_threads.Add(item);
                item.Start();
            }
        }

        public void Dispose()
        {
            if (this.m_threads != null)
            {
                this.m_threads.ForEach(delegate (Thread t) {
                    t.Interrupt();
                });
                this.m_threads = null;
            }
        }

        public void QueueUserWorkItem(WaitCallback callback, object state)
        {
            if (this.m_threads == null)
            {
                throw new ObjectDisposedException(base.GetType().Name);
            }
            if (callback == null)
            {
                throw new ArgumentNullException("callback");
            }
            WaitQueueItem item = new WaitQueueItem();
            item.Callback = callback;
            item.State = state;
            item.Context = ExecutionContext.Capture();
            this.m_queue.Enqueue(item);
        }

        private void Run()
        {
            RunServer.Common.ThreadHelper.RegisterName("CustomThreadPool");
            while (true)
            {
                try
                {
                    this.Slice();
                    Thread.Sleep(1);
                }
                catch (ThreadInterruptedException)
                {
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Error at thread pool slice: " + exception);
                }
            }
        }

        private void Slice()
        {
            int count = this.m_queue.Count;
            if (count != 0)
            {
                if (count > 200)
                {
                    count = 200;
                }
                for (int i = 0; i < count; i++)
                {
                    WaitQueueItem item = this.m_queue.Dequeue();
                    if (item == null)
                    {
                        return;
                    }
                    RunServer.Common.ThreadHelper.RegisterJob(item.State.ToString());
                    ExecutionContext.Run(item.Context, new ContextCallback(item.Callback.Invoke), item.State);
                    Thread.SpinWait(0x7d0);
                }
            }
        }

        private class WaitQueueItem
        {
            public WaitCallback Callback;
            public ExecutionContext Context;
            public object State;
        }
    }
}

