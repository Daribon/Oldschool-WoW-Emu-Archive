//
namespace RunServer.Database
{
    using System;

    public class DBConvert
    {
        public static object ChangeType(object obj, Type type)
        {
            if ((obj == null) || (obj is DBNull))
            {
                if (type == typeof(string))
                {
                    return string.Empty;
                }
                if (type == typeof(DateTime))
                {
                    return DateTime.Now;
                }
                if (type.IsValueType)
                {
                    return Convert.ChangeType(0, type);
                }
                return null;
            }
            if (obj.GetType() == type)
            {
                return obj;
            }
            if ((type == typeof(byte[])) && (obj is string))
            {
                return Convert.FromBase64String((string) obj);
            }
            return Convert.ChangeType(obj, type);
        }

        public static int ToInt32(object obj)
        {
            if (obj is DBNull)
            {
                return 0;
            }
            return Convert.ToInt32(obj);
        }

        public static float ToSingle(object obj)
        {
            if (obj is DBNull)
            {
                return 0f;
            }
            return Convert.ToSingle(obj);
        }

        public static uint ToUInt32(object obj)
        {
            if (obj is DBNull)
            {
                return 0;
            }
            return Convert.ToUInt32(obj);
        }
    }
}

