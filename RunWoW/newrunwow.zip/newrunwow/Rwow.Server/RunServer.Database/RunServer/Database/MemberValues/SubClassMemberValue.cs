﻿namespace RunServer.Database.MemberValues
{
    using RunServer.Database.Attributes;
    using System;
    using System.Reflection;

    public class SubClassMemberValue : MemberValue
    {
        private MemberValue m_classValue;
        private MemberValue m_memberValue;

        public SubClassMemberValue(MemberValue classValue, MemberValue memberValue)
        {
            this.m_classValue = classValue;
            this.m_memberValue = memberValue;
        }

        public override string GetName()
        {
            return (this.m_classValue.GetName() + "_" + this.m_memberValue.GetName());
        }

        public override object GetValue(object obj)
        {
            object obj2 = this.m_classValue.GetValue(obj);
            if (obj2 != null)
            {
                return this.m_memberValue.GetValue(obj2);
            }
            return null;
        }

        public override Type GetValueType()
        {
            return this.m_memberValue.GetValueType();
        }

        public override void SetValue(object obj, object value)
        {
            object obj2 = this.m_classValue.GetValue(obj);
            if (obj2 != null)
            {
                this.m_memberValue.SetValue(obj2, value);
            }
            this.m_classValue.SetValue(obj, obj2);
        }

        public override MemberValueAttribute Attribute
        {
            get
            {
                return this.m_memberValue.Attribute;
            }
            set
            {
                this.m_memberValue.Attribute = value;
            }
        }

        public MemberValueAttribute ClassAttribute
        {
            get
            {
                return this.m_classValue.Attribute;
            }
            set
            {
                this.m_classValue.Attribute = value;
            }
        }

        public override System.Reflection.MemberInfo MemberInfo
        {
            get
            {
                return this.m_memberValue.MemberInfo;
            }
        }
    }
}

