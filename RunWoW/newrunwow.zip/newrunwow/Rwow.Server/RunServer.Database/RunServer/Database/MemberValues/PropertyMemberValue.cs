﻿namespace RunServer.Database.MemberValues
{
    using RunServer.Database.Attributes;
    using System;
    using System.Reflection;

    public class PropertyMemberValue : MemberValue
    {
        private MemberValueAttribute m_attribute;
        protected PropertyInfo m_info;

        public PropertyMemberValue(PropertyInfo info)
        {
            this.m_info = info;
        }

        public override string GetName()
        {
            if (this.m_attribute.Name != string.Empty)
            {
                return this.m_attribute.Name;
            }
            return this.m_info.Name;
        }

        public override object GetValue(object obj)
        {
            return this.m_info.GetValue(obj, null);
        }

        public override Type GetValueType()
        {
            return this.m_info.PropertyType;
        }

        public override void SetValue(object obj, object value)
        {
            this.m_info.SetValue(obj, value, null);
        }

        public override MemberValueAttribute Attribute
        {
            get
            {
                return this.m_attribute;
            }
            set
            {
                this.m_attribute = value;
            }
        }

        public override System.Reflection.MemberInfo MemberInfo
        {
            get
            {
                return this.m_info;
            }
        }
    }
}

