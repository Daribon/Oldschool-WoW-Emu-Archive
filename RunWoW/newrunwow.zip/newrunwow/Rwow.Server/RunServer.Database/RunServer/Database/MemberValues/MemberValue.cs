﻿namespace RunServer.Database.MemberValues
{
    using RunServer.Database.Attributes;
    using System;
    using System.Collections;
    using System.Reflection;

    public abstract class MemberValue
    {
        protected MemberValue()
        {
        }

        private static MemberValue[] __getMemberValues(Type type, Type[] attribTypes, BindingFlags bindingAttribs, bool useIndexers, bool getSubClasses)
        {
            ArrayList list = new ArrayList();
            foreach (System.Reflection.MemberInfo info in type.GetMembers(bindingAttribs))
            {
                if ((info is FieldInfo) || (info is PropertyInfo))
                {
                    Type fieldType;
                    bool isArray = false;
                    if (info is FieldInfo)
                    {
                        FieldInfo info2 = info as FieldInfo;
                        fieldType = info2.FieldType;
                    }
                    else
                    {
                        PropertyInfo info3 = info as PropertyInfo;
                        fieldType = info3.PropertyType;
                    }
                    isArray = fieldType.IsArray;
                    if (isArray)
                    {
                        fieldType = fieldType.GetElementType();
                    }
                    foreach (Type type3 in attribTypes)
                    {
                        object[] objArray = GetCustomAttributes(type, type3, info);
                        if (objArray.Length != 0)
                        {
                            foreach (object obj2 in objArray)
                            {
                                MemberValue value2 = null;
                                if (info is FieldInfo)
                                {
                                    if (fieldType.IsEnum)
                                    {
                                        value2 = new EnumFieldMemberValue(info as FieldInfo);
                                    }
                                    else
                                    {
                                        value2 = new FieldMemberValue(info as FieldInfo);
                                    }
                                }
                                else if (fieldType.IsEnum)
                                {
                                    value2 = new EnumPropertyMemberValue(info as PropertyInfo);
                                }
                                else
                                {
                                    value2 = new PropertyMemberValue(info as PropertyInfo);
                                }
                                value2.Attribute = (MemberValueAttribute) obj2;
                                if (!isSubClass(fieldType))
                                {
                                    if (useIndexers && isArray)
                                    {
                                        MemberValueAttribute attribute = obj2 as MemberValueAttribute;
                                        if (attribute.ArraySize == -1)
                                        {
                                            throw new Exception("ArraySize was not set on " + value2.GetName());
                                        }
                                        if (attribute.ArraySize == 0)
                                        {
                                            list.Add(value2);
                                        }
                                        else
                                        {
                                            for (int i = 0; i < attribute.ArraySize; i++)
                                            {
                                                MemberValue value3 = new IndexMemberValue(value2, i);
                                                list.Add(value3);
                                            }
                                        }
                                    }
                                    else
                                    {
                                        list.Add(value2);
                                    }
                                }
                                else if (!useIndexers || !getSubClasses)
                                {
                                    list.Add(value2);
                                }
                                else
                                {
                                    MemberValue[] valueArray = __getMemberValues(fieldType, attribTypes, bindingAttribs, useIndexers, getSubClasses);
                                    if (valueArray.Length > 0)
                                    {
                                        if (isArray)
                                        {
                                            MemberValueAttribute attribute2 = obj2 as MemberValueAttribute;
                                            if (attribute2.ArraySize == -1)
                                            {
                                                throw new Exception("ArraySize was not set on " + value2.GetName());
                                            }
                                            for (int j = 0; j < attribute2.ArraySize; j++)
                                            {
                                                MemberValue classValue = new IndexMemberValue(value2, j);
                                                foreach (MemberValue value5 in valueArray)
                                                {
                                                    list.Add(new SubClassMemberValue(classValue, value5));
                                                }
                                            }
                                        }
                                        else
                                        {
                                            foreach (MemberValue value6 in valueArray)
                                            {
                                                list.Add(new SubClassMemberValue(value2, value6));
                                            }
                                        }
                                    }
                                    else if (isArray)
                                    {
                                        MemberValueAttribute attribute3 = obj2 as MemberValueAttribute;
                                        if (attribute3.ArraySize == -1)
                                        {
                                            throw new Exception("ArraySize was not set on " + value2.GetName());
                                        }
                                        for (int k = 0; k < attribute3.ArraySize; k++)
                                        {
                                            list.Add(new IndexMemberValue(value2, k));
                                        }
                                    }
                                    else
                                    {
                                        list.Add(value2);
                                    }
                                }
                            }
                            break;
                        }
                    }
                }
            }
            MemberValue[] array = new MemberValue[list.Count];
            if (list.Count > 0)
            {
                list.CopyTo(array);
            }
            return array;
        }

        private static object[] GetCustomAttributes(Type type, Type attribType, System.Reflection.MemberInfo member)
        {
            if (member is FieldInfo)
            {
                return GetFieldCustomAttributes(type, attribType, member.Name);
            }
            if (member is PropertyInfo)
            {
                return GetPropCustomAttributes(type, attribType, member.Name);
            }
            return null;
        }

        private static object[] GetFieldCustomAttributes(Type type, Type attribType, string name)
        {
            foreach (FieldInfo info in type.GetFields(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
            {
                if (info.Name == name)
                {
                    try
                    {
                        object[] customAttributes = info.GetCustomAttributes(attribType, true);
                        if (customAttributes.Length > 0)
                        {
                            return customAttributes;
                        }
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine(exception.Message);
                    }
                }
            }
            if (type.BaseType != typeof(object))
            {
                return GetFieldCustomAttributes(type.BaseType, attribType, name);
            }
            return new object[0];
        }

        public static MemberValue[] GetMemberValues(Type type, Type attribType, bool useIndexers, bool getSubClasses)
        {
            return GetMemberValues(type, new Type[] { attribType }, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance, useIndexers, getSubClasses);
        }

        public static MemberValue[] GetMemberValues(Type type, Type[] attribTypes, bool useIndexers, bool getSubClasses)
        {
            return GetMemberValues(type, attribTypes, BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance, useIndexers, getSubClasses);
        }

        public static MemberValue[] GetMemberValues(Type type, Type attribType, BindingFlags bindingAttribs, bool useIndexers, bool getSubClasses)
        {
            return GetMemberValues(type, new Type[] { attribType }, bindingAttribs, useIndexers, getSubClasses);
        }

        public static MemberValue[] GetMemberValues(Type type, Type[] attribTypes, BindingFlags bindingAttribs, bool useIndexers, bool getSubClasses)
        {
            foreach (Type type2 in attribTypes)
            {
                if (type2 != typeof(MemberValueAttribute))
                {
                    Type baseType = type2.BaseType;
                    do
                    {
                        if (baseType == typeof(MemberValueAttribute))
                        {
                            break;
                        }
                        if (baseType == typeof(object))
                        {
                            throw new Exception("All attributes must inherit MemberValueAttribute");
                        }
                    }
                    while ((baseType = baseType.BaseType) != null);
                }
            }
            return __getMemberValues(type, attribTypes, bindingAttribs, useIndexers, getSubClasses);
        }

        public abstract string GetName();
        private static object[] GetPropCustomAttributes(Type type, Type attribType, string name)
        {
            foreach (PropertyInfo info in type.GetProperties(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
            {
                if (info.Name == name)
                {
                    object[] customAttributes = info.GetCustomAttributes(attribType, true);
                    if (customAttributes.Length > 0)
                    {
                        return customAttributes;
                    }
                }
            }
            if (type.BaseType != typeof(object))
            {
                return GetPropCustomAttributes(type.BaseType, attribType, name);
            }
            return new object[0];
        }

        public abstract object GetValue(object obj);
        public abstract Type GetValueType();
        private static bool isSubClass(Type type)
        {
            return ((((type != typeof(ulong)) && (type != typeof(long))) && ((type != typeof(uint)) && (type != typeof(int)))) && ((((type != typeof(ushort)) && (type != typeof(short))) && ((type != typeof(byte)) && (type != typeof(string)))) && ((type != typeof(float)) && !type.IsEnum)));
        }

        public abstract void SetValue(object obj, object value);

        public abstract MemberValueAttribute Attribute { get; set; }

        public abstract System.Reflection.MemberInfo MemberInfo { get; }
    }
}

