//
namespace RunServer.Database
{
    using RunServer.Database.Attributes;
    using System;
    using System.Collections;
    using System.Reflection;

    public abstract class DataObject : CountedObject
    {
        private DBObjectFlags m_flags = (DBObjectFlags.New | DBObjectFlags.Dirty);
        private uint m_objectId;
        private static Hashtable m_tables = Hashtable.Synchronized(new Hashtable());

        protected DataObject()
        {
        }

        public static MemberInfo FindDataElement(Type type, string name)
        {
            foreach (MemberInfo info in type.GetMembers(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            {
                foreach (DataElementAttribute attribute in info.GetCustomAttributes(typeof(DataElementAttribute), true))
                {
                    if (attribute.Name == name)
                    {
                        return info;
                    }
                }
            }
            return null;
        }

        public static DataTableAttribute GetTableAttribute(Type type)
        {
            if (m_tables[type] == null)
            {
                object[] customAttributes = type.GetCustomAttributes(typeof(DataTableAttribute), true);
                if (customAttributes.Length == 0)
                {
                    throw new Exception("No table attribute!");
                }
                m_tables[type] = customAttributes[0];
            }
            return (DataTableAttribute) m_tables[type];
        }

        public bool Deleted
        {
            get
            {
                return (((byte) (this.m_flags & DBObjectFlags.Deleted)) == 8);
            }
            set
            {
                if (value)
                {
                    this.m_flags = (DBObjectFlags) ((byte) (this.m_flags | DBObjectFlags.Deleted));
                }
                else
                {
                    this.m_flags = (DBObjectFlags) ((byte) (((int) this.m_flags) & 0xf7));
                }
            }
        }

        public bool Dirty
        {
            get
            {
                return (((byte) (this.m_flags & (DBObjectFlags.None | DBObjectFlags.Dirty))) == 1);
            }
            set
            {
                if (value)
                {
                    this.m_flags = (DBObjectFlags) ((byte) (this.m_flags | DBObjectFlags.None | DBObjectFlags.Dirty));
                }
                else
                {
                    this.m_flags = (DBObjectFlags) ((byte) (((int) this.m_flags) & 0xfe));
                }
            }
        }

        public bool New
        {
            get
            {
                return (((byte) (this.m_flags & DBObjectFlags.New)) == 2);
            }
            set
            {
                if (value)
                {
                    this.m_flags = (DBObjectFlags) ((byte) (this.m_flags | DBObjectFlags.New));
                }
                else
                {
                    this.m_flags = (DBObjectFlags) ((byte) (((int) this.m_flags) & 0xfd));
                }
            }
        }

        public uint ObjectId
        {
            get
            {
                return this.m_objectId;
            }
            set
            {
                this.m_objectId = value;
            }
        }

        public bool Resolved
        {
            get
            {
                return (((byte) (this.m_flags & DBObjectFlags.Resolved)) == 4);
            }
            set
            {
                if (value)
                {
                    this.m_flags = (DBObjectFlags) ((byte) (this.m_flags | DBObjectFlags.Resolved));
                }
                else
                {
                    this.m_flags = (DBObjectFlags) ((byte) (((int) this.m_flags) & 0xfb));
                }
            }
        }
    }
}

