//
namespace RunServer.Database.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Class)]
    public class DataTableAttribute : Attribute
    {
        private string m_id = string.Empty;
        private string m_resolveProcedure;
        private Type[] m_resolveTypes;
        private string m_tableName;
        private bool m_useProxy = true;

        public string ID
        {
            get
            {
                return this.m_id;
            }
            set
            {
                this.m_id = value;
            }
        }

        public string ResolveProcedure
        {
            get
            {
                return this.m_resolveProcedure;
            }
            set
            {
                this.m_resolveProcedure = value;
            }
        }

        public Type[] ResolveTypes
        {
            get
            {
                return this.m_resolveTypes;
            }
            set
            {
                this.m_resolveTypes = value;
            }
        }

        public string TableName
        {
            get
            {
                return this.m_tableName;
            }
            set
            {
                this.m_tableName = value;
            }
        }

        public bool UseProxy
        {
            get
            {
                return this.m_useProxy;
            }
            set
            {
                this.m_useProxy = value;
            }
        }
    }
}

