﻿namespace RunServer.Database.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple=true)]
    public class MemberValueAttribute : Attribute
    {
        private int m_arraySize = -1;
        private string m_name = string.Empty;
        private int m_privatestart = -1;
        private bool m_serialize = true;

        public int ArraySize
        {
            get
            {
                return this.m_arraySize;
            }
            set
            {
                this.m_arraySize = value;
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                this.m_name = value;
            }
        }

        public int PrivateStart
        {
            get
            {
                if (this.m_privatestart != -1)
                {
                    return this.m_privatestart;
                }
                return this.ArraySize;
            }
            set
            {
                this.m_privatestart = value;
            }
        }

        public bool Serialize
        {
            get
            {
                return this.m_serialize;
            }
            set
            {
                this.m_serialize = value;
            }
        }
    }
}

