﻿namespace RunServer.Database.Connection
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.Common;
    using System.Text;

    public abstract class GenericConnectionBase<Connection, Command, Transaction> : ConnectionBase where Connection: DbConnection, new() where Command: DbCommand where Transaction: DbTransaction
    {
        private Queue<StringBuilder> m_strings;

        protected GenericConnectionBase(string connectionString) : base(connectionString)
        {
            this.m_strings = new Queue<StringBuilder>();
        }

        protected StringBuilder AllocBuilder()
        {
            return new StringBuilder(this.UseSingleQuery ? 0x1000 : this.MaximumQueryString);
        }

        public override void DeleteObjects(string TableName, ICollection keys, IDictionary fields, string keyField)
        {
            using (Connection local = ((Connection) Activator.CreateInstance(typeof(Connection), new object[] { base.ConnString })))
            {
                local.Open();
                using (Command local2 = ((Command) local.CreateCommand()))
                {
                    local2.CommandTimeout = 0;
                    string format = base.GetDeleteString(TableName, keyField);
                    StringBuilder builder = new StringBuilder();
                    foreach (object obj2 in keys)
                    {
                        builder.AppendFormat("{0}, ", this.ProcessType(obj2));
                    }
                    local2.CommandText = string.Format(format, builder.ToString(0, builder.Length - 2));
                    local2.ExecuteNonQuery();
                }
            }
        }

        public override object GetMaxValue(string TableName, string Field)
        {
            object obj2;
            using (Connection local = ((Connection) Activator.CreateInstance(typeof(Connection), new object[] { base.ConnString })))
            {
                local.Open();
                using (Command local2 = ((Command) local.CreateCommand()))
                {
                    local2.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    local2.CommandText = string.Format(format, string.Format("MAX({0})", this.QuoteObject(Field)), "1=1");
                    obj2 = local2.ExecuteScalar();
                }
            }
            return obj2;
        }

        public override object GetRecordCount(string TableName)
        {
            object obj2;
            using (Connection local = ((Connection) Activator.CreateInstance(typeof(Connection), new object[] { base.ConnString })))
            {
                local.Open();
                using (Command local2 = ((Command) local.CreateCommand()))
                {
                    local2.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    local2.CommandText = string.Format(format, "COUNT(*)", "1=1");
                    obj2 = local2.ExecuteScalar();
                }
            }
            return obj2;
        }

        public override void InsertObjects(string TableName, object[][] objects, IDictionary fields)
        {
            using (Connection local = ((Connection) Activator.CreateInstance(typeof(Connection), new object[] { base.ConnString })))
            {
                local.Open();
                Transaction local2 = (Transaction) local.BeginTransaction();
                try
                {
                    using (Command local3 = ((Command) local.CreateCommand()))
                    {
                        local3.Transaction = local2;
                        local3.CommandTimeout = 0;
                        string template = this.GetInsertString(TableName, fields);
                        StringBuilder buider = this.AllocBuilder();
                        try
                        {
                            for (int i = 0; i < objects.Length; i++)
                            {
                                buider.Append(base.FormatDBString(template, objects[i]));
                                if ((buider.Length > this.MaximumQueryString) || this.UseSingleQuery)
                                {
                                    local3.CommandText = buider.ToString();
                                    local3.ExecuteNonQuery();
                                    buider.Length = 0;
                                }
                            }
                            if (buider.Length > 0)
                            {
                                local3.CommandText = buider.ToString();
                                local3.ExecuteNonQuery();
                            }
                            this.ReleaseBuilder(buider);
                        }
                        catch (Exception exception)
                        {
                            this.ReleaseBuilder(buider);
                            Console.WriteLine("Error in insert statement {0}: {1}", local3.CommandText, exception.Message);
                            throw;
                        }
                    }
                }
                catch
                {
                    local2.Rollback();
                    throw;
                }
                local2.Commit();
            }
        }

        protected void ReleaseBuilder(StringBuilder buider)
        {
            buider.Length = 0;
        }

        public override object[][] SelectObjects(string TableName, IDictionary fields, string where)
        {
            return this.SelectObjects(TableName, base.GetFieldsString(fields, string.Empty), where);
        }

        public override object[][] SelectObjects(string TableName, string query, string where)
        {
            object[][] objArray2;
            using (Connection local = ((Connection) Activator.CreateInstance(typeof(Connection), new object[] { base.ConnString })))
            {
                local.Open();
                using (Command local2 = ((Command) local.CreateCommand()))
                {
                    local2.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    local2.CommandText = string.Format(format, query, (where == string.Empty) ? "1=1" : where);
                    using (IDataReader reader = local2.ExecuteReader())
                    {
                        ArrayList list = new ArrayList();
                        while (reader.Read())
                        {
                            object[] values = new object[reader.FieldCount];
                            reader.GetValues(values);
                            list.Add(values);
                        }
                        objArray2 = (object[][]) list.ToArray(typeof(object[]));
                    }
                }
            }
            return objArray2;
        }

        public override object[][] SelectObjects(string TableName, ICollection keys, IDictionary fields, string keyField)
        {
            object[][] objArray2;
            if (keys.Count == 0)
            {
                Console.WriteLine("Error: Asked to select data from table {0} with 0 keys", TableName);
                return new object[0][];
            }
            using (Connection local = ((Connection) Activator.CreateInstance(typeof(Connection), new object[] { base.ConnString })))
            {
                local.Open();
                using (Command local2 = ((Command) local.CreateCommand()))
                {
                    local2.CommandTimeout = 0;
                    string format = base.GetSelectString(TableName, fields, keyField);
                    StringBuilder builder = new StringBuilder();
                    foreach (object obj2 in keys)
                    {
                        builder.AppendFormat("{0}, ", this.ProcessType(obj2));
                    }
                    local2.CommandText = string.Format(format, builder.ToString(0, builder.Length - 2));
                    using (IDataReader reader = local2.ExecuteReader())
                    {
                        ArrayList list = new ArrayList();
                        while (reader.Read())
                        {
                            object[] values = new object[reader.FieldCount];
                            reader.GetValues(values);
                            list.Add(values);
                        }
                        objArray2 = (object[][]) list.ToArray(typeof(object[]));
                    }
                }
            }
            return objArray2;
        }

        public override void UpdateObjects(string TableName, object[][] objects, IDictionary fields, string keyField)
        {
            using (Connection local = ((Connection) Activator.CreateInstance(typeof(Connection), new object[] { base.ConnString })))
            {
                local.Open();
                using (Command local2 = ((Command) local.CreateCommand()))
                {
                    local2.CommandTimeout = 0;
                    string template = base.GetUpdateString(TableName, fields, keyField);
                    StringBuilder buider = this.AllocBuilder();
                    for (int i = 0; i < objects.Length; i++)
                    {
                        buider.Append(base.FormatDBString(template, objects[i]));
                        if ((buider.Length > this.MaximumQueryString) || this.UseSingleQuery)
                        {
                            local2.CommandText = buider.ToString();
                            local2.ExecuteNonQuery();
                            buider.Length = 0;
                        }
                    }
                    if (buider.Length > 0)
                    {
                        local2.CommandText = buider.ToString();
                        local2.ExecuteNonQuery();
                    }
                    this.ReleaseBuilder(buider);
                }
            }
        }

        protected virtual int MaximumQueryString
        {
            get
            {
                return 0x100000;
            }
        }

        protected virtual bool UseSingleQuery
        {
            get
            {
                return false;
            }
        }
    }
}

