//
namespace RunServer.Database.Connection
{
    using System;
    using System.Collections;
    using System.Data.Odbc;
    using System.Runtime.InteropServices;

    public class ConnectionODBC : GenericConnectionBase<OdbcConnection, OdbcCommand, OdbcTransaction>
    {
        public ConnectionODBC(string connectionString) : base(connectionString)
        {
        }

        public override void CreateTable(string TableName, IDictionary fields, string keyField)
        {
            string text = (string.Empty + "CREATE TABLE ") + this.QuoteObject(TableName) + " ( ";
            IDictionaryEnumerator enumerator = fields.GetEnumerator();
            while (enumerator.MoveNext())
            {
                text = (text + this.QuoteObject(enumerator.Key.ToString()) + " ") + TypeString((Type) enumerator.Value);
                if (enumerator.Key.ToString() == keyField)
                {
                    text = text + " NOT NULL";
                }
                text = text + ", ";
            }
            text = (text + " PRIMARY KEY (" + this.QuoteObject(keyField) + ")") + " ) ";
            using (OdbcConnection connection = new OdbcConnection(base.ConnString))
            {
                connection.Open();
                using (OdbcCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    command.CommandText = text;
                    command.ExecuteNonQuery();
                }
            }
        }

        public static void Init()
        {
            ConnectionHandler.RegisterHandler(ConnectionType.DATABASE_ODBC, typeof(ConnectionODBC));
        }

        public override string QuoteObject(string obj)
        {
            return ("" + obj + "");
        }

        public override string QuoteString(string obj)
        {
            if (obj.StartsWith("'") && obj.EndsWith("'"))
            {
                return obj;
            }
            return ("'" + obj.Replace("'", "''") + "'");
        }

        public override object[][] SelectObjectsPaged(string TableName, IDictionary fields, string where, int pageNum, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        private static string TypeString(Type type)
        {
            if ((((type == typeof(int)) || (type == typeof(uint))) || ((type == typeof(byte)) || (type == typeof(sbyte)))) || ((type == typeof(short)) || (type == typeof(ushort))))
            {
                return "int";
            }
            if ((type == typeof(long)) || (type == typeof(ulong)))
            {
                return "bigint";
            }
            if (((type == typeof(float)) || (type == typeof(double))) || (type == typeof(decimal)))
            {
                return "float";
            }
            if (type == typeof(DateTime))
            {
                return "timestamp";
            }
            if (type == typeof(byte[]))
            {
                return "varchar(2000)";
            }
            return "varchar(100)";
        }
    }
}

