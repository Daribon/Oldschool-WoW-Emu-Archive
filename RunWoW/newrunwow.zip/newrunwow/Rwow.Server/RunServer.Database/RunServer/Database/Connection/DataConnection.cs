//
namespace RunServer.Database.Connection
{
    using System;

    public class DataConnection
    {
        private ConnectionBase m_connection;

        public DataConnection(ConnectionType connType, string connString)
        {
            this.m_connection = ConnectionHandler.CreateConnection(connType, connString);
        }

        public ConnectionBase Connection
        {
            get
            {
                return this.m_connection;
            }
        }
    }
}

