//
namespace RunServer.Database.Connection
{
    using RunServer.Database;
    using System;
    using System.Collections;

    public class ConnectionHandler
    {
        private static Hashtable m_handlers = new Hashtable();

        static ConnectionHandler()
        {
            ConnectionMySQL.Init();
            ConnectionMySQLText.Init();
            ConnectionODBC.Init();
            ConnectionMSSQL.Init();
        }

        public static ConnectionBase CreateConnection(ConnectionType connType, string connString)
        {
            Type type = m_handlers[connType] as Type;
            if (type == null)
            {
                throw new DatabaseException("Unhandled database type " + connType);
            }
            return (ConnectionBase) Activator.CreateInstance(type, new object[] { connString });
        }

        public static void RegisterHandler(ConnectionType connType, Type handler)
        {
            m_handlers[connType] = handler;
        }
    }
}

