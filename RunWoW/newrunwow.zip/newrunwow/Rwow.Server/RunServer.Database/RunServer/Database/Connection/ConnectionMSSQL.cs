//
namespace RunServer.Database.Connection
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Data.SqlClient;
    using System.Runtime.InteropServices;

    public class ConnectionMSSQL : GenericConnectionBase<SqlConnection, SqlCommand, SqlTransaction>
    {
        public ConnectionMSSQL(string connectionString) : base(connectionString)
        {
        }

        public override void CreateTable(string TableName, IDictionary fields, string keyField)
        {
            string text = (string.Empty + "CREATE TABLE ") + this.QuoteObject(TableName) + " ( ";
            IDictionaryEnumerator enumerator = fields.GetEnumerator();
            while (enumerator.MoveNext())
            {
                text = (text + this.QuoteObject(enumerator.Key.ToString()) + " ") + TypeString((Type) enumerator.Value);
                if (enumerator.Key.ToString() == keyField)
                {
                    text = text + " NOT NULL";
                }
                text = text + ", ";
            }
            text = (text + " PRIMARY KEY (" + this.QuoteObject(keyField) + ")") + " ) ";
            using (SqlConnection connection = new SqlConnection(base.ConnString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    command.CommandText = text;
                    try
                    {
                        command.ExecuteNonQuery();
                    }
                    catch (SqlException)
                    {
                        Console.WriteLine("Exception while creating table. SQL: " + text);
                        throw;
                    }
                }
            }
        }

        public static void Init()
        {
            ConnectionHandler.RegisterHandler(ConnectionType.DATABASE_MSSQL, typeof(ConnectionMSSQL));
        }

        public override string QuoteObject(string obj)
        {
            return ("[" + obj + "]");
        }

        public override string QuoteString(string obj)
        {
            return ("'" + obj.Replace("'", "''") + "'");
        }

        public override object[][][] SelectMultipleObjects(string procedureName, IDictionary[] fields, string keyField, object key)
        {
            object[][][] objArray3;
            using (SqlConnection connection = new SqlConnection(base.ConnString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    command.CommandText = procedureName;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new SqlParameter("@" + keyField, key));
                    for (int i = 0; i < fields.Length; i++)
                    {
                        command.Parameters.Add(new SqlParameter("@fields_" + i, base.GetFieldsString(fields[i], string.Empty)));
                    }
                    List<object[]>[] listArray = new List<object[]>[fields.Length];
                    for (int j = 0; j < listArray.Length; j++)
                    {
                        listArray[j] = new List<object[]>();
                    }
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        int index = 0;
                        do
                        {
                            while (reader.Read())
                            {
                                object[] values = new object[reader.FieldCount];
                                reader.GetValues(values);
                                listArray[index].Add(values);
                            }
                            index++;
                        }
                        while (reader.NextResult());
                    }
                    object[][][] objArray2 = new object[fields.Length][][];
                    for (int k = 0; k < objArray2.Length; k++)
                    {
                        objArray2[k] = listArray[k].ToArray();
                    }
                    objArray3 = objArray2;
                }
            }
            return objArray3;
        }

        public override object[][] SelectObjectsPaged(string TableName, IDictionary fields, string where, int pageNum, int pageSize, out int totalRecords)
        {
            object[][] objArray2;
            using (SqlConnection connection = new SqlConnection(base.ConnString))
            {
                connection.Open();
                using (SqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    command.CommandText = string.Format(format, "Count(*)", (where == string.Empty) ? "1=1" : where);
                    totalRecords = (int) command.ExecuteScalar();
                }
                using (SqlCommand command2 = connection.CreateCommand())
                {
                    command2.CommandTimeout = 0;
                    command2.CommandText = "GetPagedList";
                    command2.CommandType = CommandType.StoredProcedure;
                    SqlParameter parameter = new SqlParameter("@PageSize", pageSize);
                    SqlParameter parameter2 = new SqlParameter("@PageNum", pageNum + 1);
                    SqlParameter parameter3 = new SqlParameter("@RecordCount", SqlDbType.Int);
                    parameter3.Value = 0;
                    parameter3.Direction = ParameterDirection.InputOutput;
                    SqlParameter parameter4 = new SqlParameter("@Fields", base.GetFieldsString(fields, string.Empty));
                    SqlParameter parameter5 = new SqlParameter("@From", "FROM " + TableName);
                    SqlParameter parameter6 = new SqlParameter("@Where", (where == string.Empty) ? "" : ("WHERE " + where));
                    SqlParameter parameter7 = new SqlParameter("@Order", "");
                    SqlParameter parameter8 = new SqlParameter("@ID", TableName + "_ID");
                    command2.Parameters.Add(parameter);
                    command2.Parameters.Add(parameter2);
                    command2.Parameters.Add(parameter3);
                    command2.Parameters.Add(parameter7);
                    command2.Parameters.Add(parameter4);
                    command2.Parameters.Add(parameter5);
                    command2.Parameters.Add(parameter6);
                    command2.Parameters.Add(parameter8);
                    using (IDataReader reader = command2.ExecuteReader())
                    {
                        ArrayList list = new ArrayList();
                        while (reader.Read())
                        {
                            object[] values = new object[reader.FieldCount];
                            reader.GetValues(values);
                            list.Add(values);
                        }
                        objArray2 = (object[][]) list.ToArray(typeof(object[]));
                    }
                }
            }
            return objArray2;
        }

        private static string TypeString(Type type)
        {
            if ((((type == typeof(int)) || (type == typeof(uint))) || ((type == typeof(byte)) || (type == typeof(sbyte)))) || (((type == typeof(short)) || (type == typeof(ushort))) || (type == typeof(bool))))
            {
                return "int";
            }
            if ((type == typeof(long)) || (type == typeof(ulong)))
            {
                return "bigint";
            }
            if (((type == typeof(float)) || (type == typeof(double))) || (type == typeof(decimal)))
            {
                return "float";
            }
            if (type == typeof(DateTime))
            {
                return "datetime";
            }
            if (type == typeof(byte[]))
            {
                return "varchar(2000)";
            }
            return "varchar(100)";
        }
    }
}

