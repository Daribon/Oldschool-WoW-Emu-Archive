//
namespace RunServer.Database.Connection
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public abstract class ConnectionBase
    {
        private Dictionary<string, string>[] m_cache;
        private string m_connString;

        public ConnectionBase(string connectionString)
        {
            this.m_connString = connectionString;
            this.m_cache = new Dictionary<string, string>[6];
            for (OpType min = OpType.Min; min < OpType.Max; min = (OpType) ((byte) (((int) min) + 1)))
            {
                this.m_cache[(int) min] = new Dictionary<string, string>();
            }
        }

        protected Dictionary<string, string> Cache(OpType op)
        {
            return this.m_cache[(int) op];
        }

        public abstract void CreateTable(string TableName, IDictionary fields, string keyField);
        public abstract void DeleteObjects(string TableName, ICollection keys, IDictionary fields, string keyField);
        protected string FormatDBString(string template, object[] data)
        {
            string[] textArray = new string[data.Length];
            for (int i = 0; i < data.Length; i++)
            {
                textArray[i] = this.ProcessType(data[i]);
            }
            return string.Format(template, (object[]) textArray);
        }

        protected string GetDeleteString(string TableName, string keyField)
        {
            if (!this.Cache(OpType.Delete).ContainsKey(TableName))
            {
                string text;
                this.Cache(OpType.Delete)[TableName] = text = string.Format("DELETE FROM {0}  WHERE {1} IN ( {{0}} ); ", this.QuoteObject(TableName), this.QuoteObject(keyField));
                return text;
            }
            return this.Cache(OpType.Delete)[TableName];
        }

        protected static int GetFieldIndex(IDictionary fields, string field)
        {
            IEnumerator enumerator = fields.Keys.GetEnumerator();
            for (int i = 0; enumerator.MoveNext(); i++)
            {
                if (enumerator.Current.Equals(field))
                {
                    return i;
                }
            }
            return -1;
        }

        protected string GetFieldsString(IDictionary fields, string sep)
        {
            return this.GetFieldsString(fields, sep, -1);
        }

        protected string GetFieldsString(string TableName, IDictionary fields)
        {
            string text2;
            if (this.Cache(OpType.Fields).ContainsKey(TableName))
            {
                return this.Cache(OpType.Fields)[TableName];
            }
            string text = "(";
            for (int i = 0; i < fields.Count; i++)
            {
                object obj2 = text;
                text = string.Concat(new object[] { obj2, "{", i, "}" });
                if (i < (fields.Count - 1))
                {
                    text = text + ", ";
                }
            }
            text = text + ")";
            this.Cache(OpType.Fields)[TableName] = text2 = text;
            return text2;
        }

        protected string GetFieldsString(IDictionary fields, string sep, int except)
        {
            string text = string.Empty;
            IEnumerator enumerator = fields.Keys.GetEnumerator();
            for (int i = 0; enumerator.MoveNext(); i++)
            {
                if (i != except)
                {
                    text = text + this.QuoteObject((string) enumerator.Current) + string.Format(sep, "{" + i + "}") + ", ";
                }
            }
            return text.Substring(0, text.Length - 2);
        }

        protected virtual string GetInsertString(string TableName, IDictionary fields)
        {
            string text2;
            if (this.Cache(OpType.Insert).ContainsKey(TableName))
            {
                return this.Cache(OpType.Insert)[TableName];
            }
            string text = string.Format("INSERT INTO {0} ( {1} ) VALUES ( ", this.QuoteObject(TableName), this.GetFieldsString(fields, string.Empty));
            for (int i = 0; i < fields.Count; i++)
            {
                object obj2 = text;
                text = string.Concat(new object[] { obj2, "{", i, "}" });
                if (i < (fields.Count - 1))
                {
                    text = text + ", ";
                }
            }
            text = text + " ); ";
            this.Cache(OpType.Insert)[TableName] = text2 = text;
            return text2;
        }

        public abstract object GetMaxValue(string TableName, string Field);
        protected string GetQueryString(string TableName)
        {
            if (!this.Cache(OpType.Query).ContainsKey(TableName))
            {
                string text;
                this.Cache(OpType.Query)[TableName] = text = string.Format("SELECT {{0}} FROM {0} WHERE {{1}}; ", this.QuoteObject(TableName));
                return text;
            }
            return this.Cache(OpType.Query)[TableName];
        }

        public abstract object GetRecordCount(string TableName);
        protected string GetSelectString(string TableName, IDictionary fields, string keyField)
        {
            if (!this.Cache(OpType.Min).ContainsKey(TableName))
            {
                string text;
                this.Cache(OpType.Min)[TableName] = text = string.Format("SELECT {0} FROM {1}  WHERE {2} IN ( {{0}} ); ", this.GetFieldsString(fields, string.Empty), this.QuoteObject(TableName), this.QuoteObject(keyField));
                return text;
            }
            return this.Cache(OpType.Min)[TableName];
        }

        protected string GetUpdateString(string TableName, IDictionary fields, string keyField)
        {
            if (!this.Cache(OpType.Update).ContainsKey(TableName))
            {
                string text;
                int except = GetFieldIndex(fields, keyField);
                this.Cache(OpType.Update)[TableName] = text = string.Format("UPDATE {0} SET {1} WHERE {2} = {{{3}}}; ", new object[] { this.QuoteObject(TableName), this.GetFieldsString(fields, " = {0} ", except), this.QuoteObject(keyField), except });
                return text;
            }
            return this.Cache(OpType.Update)[TableName];
        }

        public abstract void InsertObjects(string TableName, object[][] objects, IDictionary fields);
        public virtual string ProcessType(object data)
        {
            if ((data == null) || (data == DBNull.Value))
            {
                return "NULL";
            }
            if (data.GetType().IsEnum)
            {
                return Convert.ChangeType(data, typeof(int)).ToString();
            }
            if (data.GetType() == typeof(bool))
            {
                int num = ((bool) data) ? 1 : 0;
                return num.ToString();
            }
            if (data.GetType() == typeof(string))
            {
                return this.QuoteString(data.ToString());
            }
            if (data.GetType() == typeof(DateTime))
            {
                DateTime time = (DateTime) data;
                return this.QuoteString(time.ToString("yyyy-MM-dd HH:mm:ss"));
            }
            if (((data.GetType() == typeof(float)) || (data.GetType() == typeof(double))) || (data.GetType() == typeof(decimal)))
            {
                if (data.Equals((float) 1.0 / (float) 0.0))
                {
                    return "0";
                }
                return Math.Round((double) Convert.ChangeType(data, typeof(double)), 3).ToString().Replace(',', '.');
            }
            if (data.GetType() == typeof(byte[]))
            {
                return this.QuoteString(Convert.ToBase64String((byte[]) data));
            }
            return data.ToString();
        }

        public virtual string QuoteObject(string obj)
        {
            return obj;
        }

        public virtual string QuoteString(string obj)
        {
            return ("'" + obj + "'");
        }

        public virtual object[][][] SelectMultipleObjects(string procedureName, IDictionary[] fields, string keyField, object key)
        {
            return null;
        }

        public abstract object[][] SelectObjects(string TableName, IDictionary fields, string where);
        public abstract object[][] SelectObjects(string TableName, string query, string where);
        public abstract object[][] SelectObjects(string TableName, ICollection keys, IDictionary fields, string keyField);
        public abstract object[][] SelectObjectsPaged(string TableName, IDictionary fields, string where, int pageNum, int pageSize, out int totalRecords);
        public abstract void UpdateObjects(string TableName, object[][] objects, IDictionary fields, string keyField);

        protected string ConnString
        {
            get
            {
                return this.m_connString;
            }
        }

        protected enum OpType : byte
        {
            Delete = 3,
            Fields = 5,
            Insert = 2,
            Max = 6,
            Min = 0,
            Query = 4,
            Select = 0,
            Update = 1
        }
    }
}

