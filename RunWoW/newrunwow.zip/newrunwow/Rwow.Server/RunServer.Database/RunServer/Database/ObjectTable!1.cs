//
namespace RunServer.Database
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunServer.Database.Connection;
    using RunServer.Database.MemberValues;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.Specialized;
    using System.Runtime.InteropServices;

    public class ObjectTable<T> : IObjectTable where T: DataObject
    {
        private static int HUGE_LOAD_TRESHOLD;
        private SynchronizedDictionary<uint, T> m_cache;
        private MemberValue[] m_columns;
        private DataConnection m_connection;
        private SynchronizedDictionary<uint, WeakReference> m_dynamicCache;
        private ListDictionary m_fields;
        private DBFlags m_flags;
        private bool m_fullCache;
        private Dictionary<string, MemberValue> m_hashColumns;
        private ListDictionary m_idTable;
        private bool m_indexesResolved;
        private IndexHolder<T> m_indexValues;
        private string m_key;
        private int m_keyIndex;
        private uint m_maxId;
        private IDataProxy m_proxy;
        private ProxyManager m_proxyMan;
        private string m_resolveProcedure;
        private System.Type[] m_resolveTypes;
        private object m_syncRoot;
        private string m_tableName;
        private SynchronizedDictionary<uint, T> m_toDelete;
        private SynchronizedDictionary<uint, T> m_toInsert;
        private SynchronizedDictionary<uint, T> m_toUpdate;
        private System.Type m_type;

        static ObjectTable()
        {
            ObjectTable<T>.HUGE_LOAD_TRESHOLD = 500;
        }

        public ObjectTable(DBFlags Flags, DataConnection Connection, ProxyManager proxyMan)
        {
            this.m_maxId = 0;
            this.m_type = typeof(T);
            this.m_flags = Flags;
            this.m_connection = Connection;
            DataTableAttribute tableAttribute = DataObject.GetTableAttribute(this.m_type);
            this.m_tableName = tableAttribute.TableName;
            this.m_syncRoot = new object();
            this.m_resolveTypes = tableAttribute.ResolveTypes;
            this.m_resolveProcedure = tableAttribute.ResolveProcedure;
            this.m_columns = MemberValue.GetMemberValues(this.m_type, typeof(DataElementAttribute), true, true);
            MemberValue[] fields = MemberValue.GetMemberValues(this.m_type, typeof(IndexAttribute), false, false);
            this.m_fields = new ListDictionary();
            this.m_hashColumns = new Dictionary<string, MemberValue>();
            for (int i = 0; i < this.m_columns.Length; i++)
            {
                string key = this.m_columns[i].GetName();
                this.m_fields.Add(key, this.m_columns[i].GetValueType());
                this.m_hashColumns.Add(key, this.m_columns[i]);
            }
            this.m_key = (tableAttribute.ID == string.Empty) ? (this.m_tableName + "_ID") : tableAttribute.ID;
            this.m_idTable = new ListDictionary();
            this.m_idTable.Add(this.m_key, typeof(uint));
            this.m_fields.Add(this.m_key, typeof(uint));
            this.m_keyIndex = this.m_fields.Count - 1;
            uint recordsCount = 0;
            try
            {
                recordsCount = this.GetRecordsCount();
            }
            catch (Exception exception)
            {
                Console.WriteLine("Cannot get record count for {0} [{1}]. Trying to recreate table", this.m_tableName, exception.Message);
                this.CreateTable();
            }
            if (this.Cached)
            {
                this.m_cache = new SynchronizedDictionary<uint, T>((int) (recordsCount * 1.5));
            }
            if (this.DynCached)
            {
                this.m_dynamicCache = new SynchronizedDictionary<uint, WeakReference>(100);
            }
            if (!this.FlushUpdate)
            {
                if (this.LargeUpdates)
                {
                    this.m_toUpdate = new SynchronizedDictionary<uint, T>(0x3e8);
                    this.m_toInsert = new SynchronizedDictionary<uint, T>(0x3e8);
                    this.m_toDelete = new SynchronizedDictionary<uint, T>(0x3e8);
                }
                else
                {
                    this.m_toUpdate = new SynchronizedDictionary<uint, T>();
                    this.m_toInsert = new SynchronizedDictionary<uint, T>();
                    this.m_toDelete = new SynchronizedDictionary<uint, T>();
                }
            }
            if (!this.NoIndex && (fields.Length > 0))
            {
                this.m_indexValues = new IndexHolder<T>(fields);
            }
            this.m_proxyMan = proxyMan;
            this.m_proxyMan.GenerateProxy(this.Type);
        }

        public void AddNewObject(DataObject subject)
        {
            if (!subject.Deleted)
            {
                if (subject.ObjectId == 0)
                {
                    subject.ObjectId = this.GenerateId();
                }
                else if (!subject.New)
                {
                    this.SaveObject(subject);
                    return;
                }
                subject.New = false;
                subject.Dirty = false;
                if (this.FlushUpdate)
                {
                    this.AddObjects(new T[] { (T) subject });
                }
                else
                {
                    this.m_toInsert[subject.ObjectId] = (T) subject;
                }
                this.CheckIndexes((T) subject);
                if (this.Cached)
                {
                    this.m_cache[subject.ObjectId] = (T) subject;
                }
                else if (this.DynCached)
                {
                    this.m_dynamicCache[subject.ObjectId] = new WeakReference(subject);
                }
            }
        }

        private void AddObjects(ICollection objects)
        {
            this.AddObjectsTo(this.m_connection, objects);
        }

        private void AddObjectsTo(DataConnection connection, ICollection objects)
        {
            object[][] objArray = new object[objects.Count][];
            int index = 0;
            foreach (T local in objects)
            {
                objArray[index] = this.GetObjectValues(local);
                local.New = false;
                local.Dirty = false;
                index++;
            }
            try
            {
                connection.Connection.InsertObjects(this.m_tableName, objArray, this.m_fields);
            }
            catch (Exception exception)
            {
                throw new DatabaseException("Error while inserting objects to table " + this.TableName, exception);
            }
        }

        private void CheckIndexes(T ndo)
        {
            if (this.m_indexValues != null)
            {
                this.m_indexValues.SubmitObject(ndo);
            }
        }

        public void CreateDatabaseTable()
        {
        }

        public bool CreateTable()
        {
            try
            {
                this.m_connection.Connection.CreateTable(this.m_tableName, this.m_fields, this.m_key);
                return true;
            }
            catch (Exception exception)
            {
                Console.WriteLine(exception);
                return false;
            }
        }

        public void DeleteObject(DataObject subject)
        {
            if (!subject.Deleted)
            {
                subject.Deleted = true;
                this.RemoveIndexes((T) subject);
                if (this.FlushUpdate)
                {
                    this.RemoveFromCache(subject.ObjectId);
                    this.DeleteObjects(new T[] { (T) subject });
                }
                else
                {
                    this.m_toDelete[subject.ObjectId] = (T) subject;
                }
            }
        }

        private void DeleteObjects(ICollection objects)
        {
            object[] keys = new object[objects.Count];
            int index = 0;
            foreach (T local in objects)
            {
                keys[index] = local.ObjectId;
                index++;
            }
            try
            {
                this.m_connection.Connection.DeleteObjects(this.m_tableName, keys, this.m_fields, this.m_key);
            }
            catch (Exception exception)
            {
                throw new DatabaseException("Error while deleting objects from table " + this.TableName, exception);
            }
        }

        public void Export(DataConnection connection)
        {
            this.ExportAllObjects(connection);
        }

        private void ExportAllObjects(DataConnection connection)
        {
            object[][] objects = this.m_connection.Connection.SelectObjects(this.m_tableName, this.m_fields, string.Empty);
            Console.WriteLine("Loaded {0} objects from table {1}", objects.Length, this.m_tableName);
            connection.Connection.InsertObjects(this.m_tableName, objects, this.m_fields);
            Console.WriteLine("Exported {0} objects from table {1}", objects.Length, this.m_tableName);
        }

        public void Flush()
        {
            if (!this.FlushUpdate)
            {
                this.m_toDelete.Lock();
                Dictionary<uint, T>.ValueCollection.Enumerator enumerator = this.m_toDelete.Values.GetEnumerator();
                try
                {
                    while (enumerator.MoveNext())
                    {
                        uint key = enumerator.Current.ObjectId;
                        this.m_toInsert.Remove(key);
                        this.m_toUpdate.Remove(key);
                        this.RemoveFromCache(key);
                    }
                }
                finally
                {
                    enumerator.Dispose();
                }
                PooledList<T> objects = new PooledList<T>(this.m_toDelete.Values);
                this.m_toDelete.Clear();
                this.m_toDelete.Unlock();
                if (objects.Count > 0)
                {
                    this.DeleteObjects(objects);
                }
                this.m_toInsert.Lock();
                foreach (T local2 in this.m_toInsert.Values)
                {
                    uint objectId = local2.ObjectId;
                    if (this.m_toUpdate.ContainsKey(objectId))
                    {
                        this.m_toUpdate.Remove(objectId);
                        local2.Dirty = false;
                    }
                }
                objects = new PooledList<T>(this.m_toInsert.Values);
                this.m_toInsert.Clear();
                this.m_toInsert.Unlock();
                if (objects.Count > 0)
                {
                    this.AddObjects(objects);
                }
                this.m_toUpdate.Lock();
                objects = new PooledList<T>(this.m_toUpdate.Values);
                this.m_toUpdate.Clear();
                this.m_toUpdate.Unlock();
                if (objects.Count > 0)
                {
                    this.UpdateObjects(objects);
                }
            }
        }

        public void FlushDynamic()
        {
            if (this.DynCached)
            {
                this.m_dynamicCache.Lock();
                List<uint> list = new List<uint>();
                foreach (KeyValuePair<uint, WeakReference> pair in this.m_dynamicCache)
                {
                    if (!pair.Value.IsAlive)
                    {
                        list.Add(pair.Key);
                    }
                }
                foreach (uint num in list)
                {
                    this.m_dynamicCache.Remove(num);
                }
                this.m_dynamicCache.Unlock();
            }
        }

        private uint GenerateId()
        {
            lock (this.m_syncRoot)
            {
                if (this.m_maxId == 0)
                {
                    object maxValue = this.m_connection.Connection.GetMaxValue(this.m_tableName, this.m_key);
                    this.m_maxId = ((maxValue == null) || (maxValue is DBNull)) ? 0 : ((uint) Convert.ChangeType(maxValue, typeof(uint)));
                }
                return ++this.m_maxId;
            }
        }

        private T[] GetAllObjects()
        {
            object[][] objArray = this.m_connection.Connection.SelectObjects(this.m_tableName, this.m_fields, string.Empty);
            T[] localArray = new T[objArray.Length];
            int index = 0;
            foreach (object[] objArray2 in objArray)
            {
                localArray[index] = (T) Activator.CreateInstance(this.m_type);
                this.GetObjectFromValues(localArray[index], objArray2);
                localArray[index].New = false;
                localArray[index].Dirty = false;
                index++;
            }
            return localArray;
        }

        private T getCached(uint objectId)
        {
            if (this.m_cache.ContainsKey(objectId))
            {
                return this.m_cache[objectId];
            }
            return default(T);
        }

        private MemberValue GetColumn(string field)
        {
            if (!this.m_hashColumns.ContainsKey(field))
            {
                throw new DatabaseException(string.Format("Field {0} not found in {1}", field, this.TableName));
            }
            return this.m_hashColumns[field];
        }

        private T getDelayed(uint objectId)
        {
            if (!this.FlushUpdate)
            {
                if (this.m_toDelete.ContainsKey(objectId))
                {
                    return this.m_toDelete[objectId];
                }
                if (this.m_toUpdate.ContainsKey(objectId))
                {
                    return this.m_toUpdate[objectId];
                }
                if (this.m_toInsert.ContainsKey(objectId))
                {
                    return this.m_toInsert[objectId];
                }
            }
            return default(T);
        }

        private T getDynamic(uint objectId)
        {
            if (this.m_dynamicCache.ContainsKey(objectId) && this.m_dynamicCache[objectId].IsAlive)
            {
                return (T) this.m_dynamicCache[objectId].Target;
            }
            return default(T);
        }

        private object[][] GetFieldIDValues(ListDictionary fields)
        {
            return this.m_connection.Connection.SelectObjects(this.m_tableName, fields, string.Empty);
        }

        public DataObject GetObject(uint objectId)
        {
            T local;
            if (!this.FlushUpdate)
            {
                local = this.getDelayed(objectId);
                if (local != null)
                {
                    return (local.Deleted ? ((DataObject) default(T)) : ((DataObject) local));
                }
            }
            if (this.DynCached)
            {
                local = this.getDynamic(objectId);
                if (local != null)
                {
                    return (local.Deleted ? ((DataObject) default(T)) : ((DataObject) local));
                }
            }
            if (this.Cached)
            {
                local = this.getCached(objectId);
                if (local != null)
                {
                    return (local.Deleted ? ((DataObject) default(T)) : ((DataObject) local));
                }
                if (this.FullCache)
                {
                    return null;
                }
            }
            return this.LoadObject(objectId);
        }

        private void GetObjectFromValues(T obj, object[] values)
        {
            if (this.m_proxy == null)
            {
                this.m_proxy = this.m_proxyMan[obj.GetType()];
            }
            if (this.m_proxy != null)
            {
                this.m_proxy.FillObject(obj, values);
            }
            else
            {
                Console.WriteLine("Warining!! Proxy not found for object type {0}", obj.GetType().Name);
                for (int i = 0; i < this.m_columns.Length; i++)
                {
                    object obj2 = DBConvert.ChangeType(values[i], this.m_columns[i].GetValueType());
                    if (obj2 != null)
                    {
                        this.m_columns[i].SetValue(obj, obj2);
                    }
                }
                obj.ObjectId = DBConvert.ToUInt32(values[this.m_columns.Length]);
            }
        }

        private uint[] GetObjectIds(string query)
        {
            object[][] objArray = this.m_connection.Connection.SelectObjects(this.m_tableName, this.m_idTable, query);
            uint[] numArray = new uint[objArray.Length];
            for (int i = 0; i < objArray.Length; i++)
            {
                numArray[i] = (uint) Convert.ChangeType(objArray[i][0], typeof(uint));
            }
            return numArray;
        }

        public ICollection GetObjects(object[][] n_objects)
        {
            T[] objects = this.GetObjects(n_objects, null);
            if (this.Cached)
            {
                this.m_cache.Lock();
                for (int i = 0; i < objects.Length; i++)
                {
                    if (!this.m_cache.ContainsKey(objects[i].ObjectId))
                    {
                        this.m_cache[objects[i].ObjectId] = objects[i];
                    }
                    else
                    {
                        objects[i] = this.m_cache[objects[i].ObjectId];
                    }
                }
                this.m_cache.Unlock();
            }
            else if (this.DynCached)
            {
                this.m_dynamicCache.Lock();
                for (int j = 0; j < objects.Length; j++)
                {
                    if (!this.m_dynamicCache.ContainsKey(objects[j].ObjectId) || !this.m_dynamicCache[objects[j].ObjectId].IsAlive)
                    {
                        this.m_dynamicCache[objects[j].ObjectId] = new WeakReference(objects[j]);
                    }
                    else
                    {
                        objects[j] = (T) this.m_dynamicCache[objects[j].ObjectId].Target;
                    }
                }
                this.m_dynamicCache.Unlock();
            }
            for (int k = 0; k < objects.Length; k++)
            {
                this.CheckIndexes(objects[k]);
            }
            return objects;
        }

        public ICollection GetObjects(string query)
        {
            int total;
            return this.GetObjects(query, false, 0, 0, out total);
        }

        private T[] GetObjects(Dictionary<uint, uint> ids, Dictionary<uint, T> partialLoaded)
        {
            object[][] objArray = this.m_connection.Connection.SelectObjects(this.m_tableName, ids.Values, this.m_fields, this.m_key);
            return this.GetObjects(objArray, partialLoaded);
        }

        private T[] GetObjects(object[][] n_objects, Dictionary<uint, T> partialLoaded)
        {
            T[] localArray = new T[n_objects.Length];
            int index = 0;
            foreach (object[] objArray in n_objects)
            {
                uint key = (uint) Convert.ChangeType(objArray[this.m_keyIndex], typeof(uint));
                T local = ((partialLoaded != null) && partialLoaded.ContainsKey(key)) ? partialLoaded[key] : ((T) Activator.CreateInstance(this.m_type));
                this.GetObjectFromValues(local, objArray);
                local.New = false;
                local.Dirty = false;
                localArray[index] = local;
                index++;
            }
            return localArray;
        }

        public ICollection GetObjects(string query, bool paged, int pageNum, int pageSize, out int total)
        {
            T[] collection;
            total = 0;
            PooledList<T> result = new PooledList<T>();
            if ((query == string.Empty) && ((this.Cached && (this.m_cache.Count == 0)) || (this.DynCached && (this.m_dynamicCache.Count == 0))))
            {
                collection = this.GetAllObjects();
            }
            else
            {
                if (((query == string.Empty) && this.Cached) && this.FullCache)
                {
                    result.AddRange(this.m_cache.Values);
                    return result;
                }
                DateTime now = DateTime.Now;
                uint[] indexes = paged ? this.GetPagedObjectIds(query, pageNum, pageSize, out total) : this.GetObjectIds(query);
                TimeSpan span = (TimeSpan) (DateTime.Now - now);
                double totalMilliseconds = span.TotalMilliseconds;
                if (totalMilliseconds > 300)
                {
                    Console.WriteLine("Getting IDs from {0} for query {1} for {2}ms", this.TableName, query, totalMilliseconds);
                }
                collection = this.GetObjectsByIds(indexes, query, ref result);
            }
            if ((collection != null) && (collection.Length > 0))
            {
                if (this.Cached)
                {
                    for (int i = 0; i < collection.Length; i++)
                    {
                        this.m_cache[collection[i].ObjectId] = collection[i];
                    }
                }
                else if (this.DynCached)
                {
                    for (int j = 0; j < collection.Length; j++)
                    {
                        this.m_dynamicCache[collection[j].ObjectId] = new WeakReference(collection[j]);
                    }
                }
                for (int k = 0; k < collection.Length; k++)
                {
                    this.CheckIndexes(collection[k]);
                }
                result.AddRange(collection);
            }
            return result;
        }

        public ICollection GetObjectsByField(string field, object key)
        {
            if ((this.m_indexesResolved && (this.m_indexValues != null)) && this.m_indexValues.IndexFields.Contains(field))
            {
                DateTime now = DateTime.Now;
                PooledList<T> result = new PooledList<T>();
                uint[] toGet = null;
                this.m_indexValues.GetObjects(field, key, ref result, ref toGet);
                if ((toGet != null) && (toGet.Length > 0))
                {
                    T[] collection = this.GetObjectsByIds(toGet, field + " = " + ((key is string) ? ("'" + key + "'") : key.ToString()), ref result);
                    if ((collection != null) && (collection.Length > 0))
                    {
                        if (this.Cached)
                        {
                            this.m_cache.Lock();
                            for (int i = 0; i < collection.Length; i++)
                            {
                                this.m_cache[collection[i].ObjectId] = collection[i];
                            }
                            this.m_cache.Unlock();
                        }
                        else if (this.DynCached)
                        {
                            this.m_dynamicCache.Lock();
                            for (int j = 0; j < collection.Length; j++)
                            {
                                this.m_dynamicCache[collection[j].ObjectId] = new WeakReference(collection[j]);
                            }
                            this.m_dynamicCache.Unlock();
                        }
                        for (int k = 0; k < collection.Length; k++)
                        {
                            this.CheckIndexes(collection[k]);
                        }
                        result.AddRange(collection);
                    }
                }
                TimeSpan span = (TimeSpan) (DateTime.Now - now);
                double totalMilliseconds = span.TotalMilliseconds;
                if (totalMilliseconds > 300)
                {
                    Console.WriteLine("Getting indexed {0} objects {1} for query {2} = {3} for {4}ms", new object[] { result.Count, this.TableName, field, key, totalMilliseconds });
                }
                return result;
            }
            if (!this.NoIndex)
            {
                Console.WriteLine("WARNING: Looking for objects of type {0} on non-indexed field {1}!", this.TableName, field);
            }
            if (!this.Cached)
            {
                return null;
            }
            PooledList<T> list2 = new PooledList<T>();
            MemberValue column = this.GetColumn(field);
            this.m_cache.Lock();
            foreach (T local in this.m_cache.Values)
            {
                object obj2 = column.GetValue(local);
                if ((obj2 != null) && obj2.Equals(key))
                {
                    list2.Add(local);
                }
            }
            this.m_cache.Unlock();
            return list2;
        }

        private T[] GetObjectsByIds(uint[] indexes, string query, ref PooledList<T> result)
        {
            Dictionary<uint, T> partialLoaded = new Dictionary<uint, T>(indexes.Length);
            T[] objects = null;
            if (!this.FlushUpdate)
            {
                this.m_toDelete.ReadLock();
                this.m_toInsert.ReadLock();
                this.m_toUpdate.ReadLock();
                for (int i = 0; i < indexes.Length; i++)
                {
                    if (indexes[i] != uint.MaxValue)
                    {
                        T item = this.getDelayed(indexes[i]);
                        if ((item != null) && !item.Deleted)
                        {
                            result.Add(item);
                            indexes[i] = uint.MaxValue;
                        }
                    }
                }
                this.m_toUpdate.ReadUnlock();
                this.m_toInsert.ReadUnlock();
                this.m_toDelete.ReadUnlock();
            }
            if (this.DynCached)
            {
                this.m_dynamicCache.ReadLock();
                for (int j = 0; j < indexes.Length; j++)
                {
                    if (indexes[j] != uint.MaxValue)
                    {
                        T local2 = this.getDynamic(indexes[j]);
                        if ((local2 != null) && !local2.Deleted)
                        {
                            if (this.FlushLoad)
                            {
                                partialLoaded[local2.ObjectId] = local2;
                            }
                            else
                            {
                                result.Add(local2);
                                indexes[j] = uint.MaxValue;
                            }
                        }
                    }
                }
                this.m_dynamicCache.ReadUnlock();
            }
            if (this.Cached)
            {
                this.m_cache.ReadLock();
                for (int k = 0; k < indexes.Length; k++)
                {
                    if (indexes[k] != uint.MaxValue)
                    {
                        T local3 = this.getCached(indexes[k]);
                        if ((local3 != null) && !local3.Deleted)
                        {
                            result.Add(local3);
                            indexes[k] = uint.MaxValue;
                        }
                    }
                }
                this.m_cache.ReadUnlock();
            }
            Dictionary<uint, uint> nids = new Dictionary<uint, uint>();
            for (int m = 0; m < indexes.Length; m++)
            {
                if (indexes[m] != uint.MaxValue)
                {
                    nids[indexes[m]] = indexes[m];
                }
            }
            if (nids.Count > 0)
            {
                DateTime now = DateTime.Now;
                if (nids.Count > ObjectTable<T>.HUGE_LOAD_TRESHOLD)
                {
                    objects = this.GetQueryObjects(nids, query, partialLoaded);
                }
                else
                {
                    objects = this.GetObjects(nids, partialLoaded);
                }
                TimeSpan span = (TimeSpan) (DateTime.Now - now);
                double totalMilliseconds = span.TotalMilliseconds;
                if (totalMilliseconds > 300)
                {
                    Console.WriteLine("Getting {0} objects {1} for query {2} for {3}ms", new object[] { nids.Count, this.TableName, query, totalMilliseconds });
                }
            }
            return objects;
        }

        public ICollection GetObjectsPage(string query, int pageNum, int pageSize, out int total)
        {
            return this.GetObjects(query, true, pageNum, pageSize, out total);
        }

        private object[] GetObjectValues(T obj)
        {
            if (this.m_proxy == null)
            {
                this.m_proxy = this.m_proxyMan[obj.GetType()];
            }
            if (this.m_proxy != null)
            {
                return this.m_proxy.GetValues(obj);
            }
            Console.WriteLine("Warining!! Proxy not found for object type {0}", obj.GetType().Name);
            object[] objArray = new object[this.m_fields.Count];
            for (int i = 0; i < this.m_columns.Length; i++)
            {
                objArray[i] = this.m_columns[i].GetValue(obj);
            }
            objArray[this.m_columns.Length] = obj.ObjectId;
            return objArray;
        }

        private uint[] GetPagedObjectIds(string query, int num, int size, out int total)
        {
            object[][] objArray = this.m_connection.Connection.SelectObjectsPaged(this.m_tableName, this.m_idTable, query, num, size, out total);
            uint[] numArray = new uint[objArray.Length];
            for (int i = 0; i < objArray.Length; i++)
            {
                numArray[i] = (uint) Convert.ChangeType(objArray[i][0], typeof(uint));
            }
            return numArray;
        }

        private T[] GetQueryObjects(Dictionary<uint, uint> nids, string query, Dictionary<uint, T> partialLoaded)
        {
            object[][] objArray = this.m_connection.Connection.SelectObjects(this.m_tableName, this.m_fields, query);
            PooledList<T> list = new PooledList<T>();
            foreach (object[] objArray2 in objArray)
            {
                uint key = (uint) Convert.ChangeType(objArray2[this.m_keyIndex], typeof(uint));
                if ((nids == null) || nids.ContainsKey(key))
                {
                    T local = ((partialLoaded != null) && partialLoaded.ContainsKey(key)) ? partialLoaded[key] : ((T) Activator.CreateInstance(this.m_type));
                    this.GetObjectFromValues(local, objArray2);
                    local.New = false;
                    local.Dirty = false;
                    list.Add(local);
                }
            }
            return list.ToArray();
        }

        private uint GetRecordsCount()
        {
            return (uint) Convert.ChangeType(this.m_connection.Connection.GetRecordCount(this.m_tableName), typeof(uint));
        }

        public object[][][] GetRelatedObjects(IDictionary[] fields, object key)
        {
            return this.m_connection.Connection.SelectMultipleObjects(this.ResolveProcedure, fields, this.m_key, key);
        }

        private T LoadObject(uint ObjectId)
        {
            Dictionary<uint, uint> ids = new Dictionary<uint, uint>();
            ids[ObjectId] = ObjectId;
            T[] objects = this.GetObjects(ids, null);
            T target = (objects.Length != 0) ? objects[0] : default(T);
            if (target != null)
            {
                if (this.Cached)
                {
                    this.m_cache[ObjectId] = target;
                }
                else if (this.DynCached)
                {
                    this.m_dynamicCache[ObjectId] = new WeakReference(target);
                }
                this.CheckIndexes(target);
            }
            return target;
        }

        public string PrepareData(object data)
        {
            return this.m_connection.Connection.ProcessType(data);
        }

        public void ReindexObject(string field, object oldkey, object newkey, uint id)
        {
            if (this.m_indexValues != null)
            {
                this.m_indexValues.ReindexObject(field, oldkey, newkey, id);
            }
        }

        public void ReleaseTable()
        {
            this.Flush();
            this.m_indexesResolved = false;
            this.m_indexValues = null;
            if (this.Cached)
            {
                this.m_cache.Clear();
            }
            if (this.DynCached)
            {
                this.m_dynamicCache.Clear();
            }
            this.m_fullCache = false;
        }

        public DataObject ReloadObject(DataObject obj)
        {
            Dictionary<uint, uint> ids = new Dictionary<uint, uint>();
            ids[obj.ObjectId] = obj.ObjectId;
            Dictionary<uint, T> partialLoaded = new Dictionary<uint, T>();
            partialLoaded[obj.ObjectId] = (T) obj;
            T[] objects = this.GetObjects(ids, partialLoaded);
            obj = (objects.Length != 0) ? ((DataObject) objects[0]) : ((DataObject) default(T));
            if ((obj != null) && this.Cached)
            {
                this.m_cache[obj.ObjectId] = (T) obj;
            }
            return obj;
        }

        private void RemoveFromCache(uint objectId)
        {
            if (this.Cached)
            {
                this.m_cache.Remove(objectId);
            }
            else if (this.DynCached)
            {
                this.m_dynamicCache.Remove(objectId);
            }
        }

        private void RemoveIndexes(T ndo)
        {
            if (this.m_indexValues != null)
            {
                this.m_indexValues.RemoveObject(ndo);
            }
        }

        public void ResolveIndexes()
        {
            if ((!this.m_indexesResolved && (this.m_indexValues != null)) && (this.m_indexValues != null))
            {
                if (this.Cached)
                {
                    foreach (T local in this.m_cache.Values)
                    {
                        this.CheckIndexes(local);
                    }
                }
                else
                {
                    ListDictionary fields = new ListDictionary();
                    fields.Add(this.m_key, typeof(uint));
                    foreach (MemberValue value2 in this.m_indexValues.IndexMemberValues)
                    {
                        fields.Add(value2.GetName(), value2.GetValueType());
                    }
                    long ticks = DateTime.Now.Ticks;
                    object[][] values = this.GetFieldIDValues(fields);
                    this.m_indexValues.SetIndexValues(values);
                    TimeSpan span = TimeSpan.FromTicks(DateTime.Now.Ticks - ticks);
                    Console.WriteLine("Resolving indexes for table {0} on {1} fields took {2}", this.TableName, this.m_indexValues.IndexMemberValues.Length, span);
                }
                this.m_indexesResolved = true;
            }
        }

        public void SaveObject(DataObject subject)
        {
            if (subject.Dirty && !subject.Deleted)
            {
                subject.Dirty = false;
                if (this.FlushUpdate)
                {
                    this.UpdateObjects(new T[] { (T) subject });
                }
                else
                {
                    this.m_toUpdate[subject.ObjectId] = (T) subject;
                }
            }
        }

        public ICollection SelectAllObjects()
        {
            if (!this.Cached || !this.FullCache)
            {
                throw new DatabaseException("Asking to get cache on noncached table");
            }
            return this.m_cache.Values;
        }

        private void UpdateObjects(ICollection objects)
        {
            object[][] objArray = new object[objects.Count][];
            int index = 0;
            foreach (T local in objects)
            {
                objArray[index] = this.GetObjectValues(local);
                local.Dirty = false;
                index++;
            }
            DateTime now = DateTime.Now;
            this.m_connection.Connection.UpdateObjects(this.m_tableName, objArray, this.m_fields, this.m_key);
            TimeSpan span = (TimeSpan) (DateTime.Now - now);
            double totalMilliseconds = span.TotalMilliseconds;
            if (totalMilliseconds > 300)
            {
                Console.WriteLine("Updating {0} objects of type {1} took {2}ms", objects.Count, this.m_tableName, totalMilliseconds);
            }
        }

        public bool Cached
        {
            get
            {
                return (((byte) (this.m_flags & (DBFlags.None | DBFlags.Cached))) == 1);
            }
        }

        public bool DynCached
        {
            get
            {
                return (((byte) (this.m_flags & DBFlags.DynCached)) == 8);
            }
        }

        public IDictionary Fields
        {
            get
            {
                return this.m_fields;
            }
        }

        public bool FlushLoad
        {
            get
            {
                return (((byte) (this.m_flags & DBFlags.FlushLoad)) == 0x40);
            }
        }

        public bool FlushUpdate
        {
            get
            {
                return (((byte) (this.m_flags & DBFlags.FlushUpdate)) == 0x20);
            }
        }

        public bool ForceLoad
        {
            get
            {
                return (((byte) (this.m_flags & (DBFlags.None | DBFlags.ForceLoad))) == 4);
            }
        }

        public bool FullCache
        {
            get
            {
                return this.m_fullCache;
            }
            set
            {
                this.m_fullCache = value;
            }
        }

        public string Key
        {
            get
            {
                return this.m_key;
            }
        }

        public bool LargeUpdates
        {
            get
            {
                return (((byte) (this.m_flags & DBFlags.LargeUpdates)) == 0x10);
            }
        }

        public bool NoIndex
        {
            get
            {
                return (((byte) (this.m_flags & DBFlags.NoIndex)) == 0x80);
            }
        }

        public IDataProxy Proxy
        {
            get
            {
                return this.m_proxy;
            }
            set
            {
                this.m_proxy = value;
            }
        }

        public string ResolveProcedure
        {
            get
            {
                return this.m_resolveProcedure;
            }
        }

        public System.Type[] ResolveTypes
        {
            get
            {
                return this.m_resolveTypes;
            }
        }

        public string TableName
        {
            get
            {
                return this.m_tableName;
            }
        }

        public System.Type Type
        {
            get
            {
                return this.m_type;
            }
        }
    }
}

