using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;
using RunWoW.ServerDatabase;
using RunWoW.DB.DataTables;

namespace RunWoW.ChatCommands
{
	public class BanCommand
	{
		private static ClientBase ValidateUserByString(string _string, ClientBase client)
		{
			ClientData Client = (ClientData) client.Data;
			if (_string.ToLower() != Client.Player.Name.ToLower())
			{
				ClientBase cb_temp = ClientManager.GetClient(_string);

				if (cb_temp == null)
				{
					Chat.System(client, "No client found: '" + _string + "'");
					return null;
				}
				else
				{
					return cb_temp;
				}
			}
			else
			{
				Chat.System(client, "Cannot kick itself, try EXIT button");
				return null;
			}

		}

		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("ban", "USAGE: '.ban [name]' || or choose player and say '.ban'", new ChatCommand(OnBanCommand));
		}

		private static bool OnBanCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.ADMIN)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			Chat.System(client, "-------------------");

			string[] command = s.Split(new char[] {',', ' '});

			if (command.Length >= 2)
			{
				ClientBase client_to_kick = ValidateUserByString(command[1], client);

				if (client_to_kick != null)
				{
					ClientData client_to_kick_cd = (ClientData) client_to_kick.Data;

					if (client_to_kick_cd.Account.AccessLvl < Client.Account.AccessLvl)
					{
						client_to_kick_cd.Account.AccessLvl = 0;

						DBManager.SaveDBObject(client_to_kick_cd.Account);

						Chat.System(client, client_to_kick_cd.Player.Name + " banned");
						client_to_kick.Close("GameMaster [" + Client.Player.Name + "] forced to ban " + client_to_kick_cd.Player.Name);

					}
					else
					{
						Chat.System(client, "Cannot ban him... " + client_to_kick_cd.Player.Name + " Has more accesslevel that your");
					}

					return true;
				}
				else
				{
                    //  try ban offline 
                    DBCharacter offlineChar = (DBCharacter)Database.Instance.FindObjectByField(typeof(DBCharacter), "Name", command[1]);
                    if (offlineChar != null)
                    {
                        DBAccount account = (DBAccount)Database.Instance.FindObjectByKey(typeof(DBAccount), offlineChar.AccountID);

                        if ( account != null && Client.Account.AccessLvl > account.AccessLvl )
                        {
                            account.AccessLvl = ACCESSLEVEL.BANNED;
                            DBManager.SaveDBObject(account);
                            Chat.System(client, "Player " + command[1] + " banned offline.");
                            return true;
                        }
                    }

					//Chat.System(client, "No such player founded...");
					return false;
				}

			}
			else
			{
				if (Client.Player.Selection is PlayerObject)
				{
					ClientBase cb = ClientManager.GetClient(((PlayerObject) Client.Player.Selection).CharacterID);

					if (client != cb)
					{
						ClientData cd = (ClientData) cb.Data;

						if (cd.Account.AccessLvl < Client.Account.AccessLvl)
						{
							cd.Account.AccessLvl = 0;

							DBManager.SaveDBObject(cd.Account);
							
							Chat.System(client, cd.Player.Name + " banned");
							cb.Close("GameMaster [" + Client.Player.Name + "] forced to ban " + cd.Player.Name);
						}
						else
						{
							Chat.System(client, "Cannot ban him... " + cd.Player.Name + " Has more accesslevel that your");
						}
						return true;

					}
					else
					{
						Chat.System(client, "Cannot ban itself");
						return false;
					}
				}
				else
				{
					Chat.System(client, "You may ban only players");
				}
				return false;
			}

			/*
			if (Client.Player.Selection == null)
			{
				Chat.System(client,"No client selected");
				return false;				
			}		
			
			if (Client.Player.Selection is PlayerObject)
			{
				ClientBase cb=Clients.GetClientByCharacterID( (( PlayerObject)Client.Player.Selection).CharacterID );
								
				if (client != cb)
				{
					ClientData cd =(ClientData)cb.Data;
					if (Client.Account.AccessLvl > cd.Account.AccessLvl)
					{
						cd.Account.AccessLvl = 0;
						Chat.System(client, cd.Player.Name + " banned!");
						cd.Player.UpdateData();
						cd.Player.Save();
						cb.Close("Banned");
					}
					else
					{
						Chat.System(client,"You cannot ban this player, because his access level higher that your");
						return false;	
					}
						
				}
				else
					Chat.System(client,"ban itself...?");	
			}
			else
			{
				Chat.System(client,"You cannot ban non-players");
			}
						
			return true;
			*/

		}
	}
}

/*	public enum ACCESSLEVEL : byte 
	{ 
		BANNED=0, 
		NORMAL=2, 
		TEMPGM=5, 
		GM=6, 
		ADMIN=9, 
	}*/