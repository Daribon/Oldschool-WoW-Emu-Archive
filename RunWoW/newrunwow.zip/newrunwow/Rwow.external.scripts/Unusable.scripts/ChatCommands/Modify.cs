//
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.ChatCommands
{
	public class UnitModify
	{
		public static Dictionary<ulong, PooledList<DBMovepoint>> m_pPoints = new Dictionary<ulong, PooledList<DBMovepoint>>();

		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("mod", "No unit selected", new ChatCommand(OnSet));
			ChatManager.RegisterChatCommand("m", "No unit selected", new ChatCommand(OnSet));
		}

		private static bool OnSet(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine(
				"Chat command: " + input + ", Selection: " +
				(Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			//if (Client.Player.Selection == null)
			//    return false;
			ObjectBase o = Client.Player.Selection;
			LivingObject l = o as LivingObject;
			//if (l == null)
			//    return false;
			UnitBase u = o as UnitBase;
			if (u != null && u.Spawn == null)
				u = null;
			PlayerObject p = o as PlayerObject;

			string[] command = input.Split(new char[] {'=', ' '});
			if (command.Length < 2)
			{
				Chat.System(client, "Format: mod <property> value");
				Chat.System(client, "Property can be one of: addspell[as],removespell[rs]");
				return true;
			}

			switch (command[1].ToLower())
			{
				case "spell":
					{
						if (u != null )
						{
							if (u.Spells.Length == 0)
							{
								Chat.System(client,"There is no spells for this mob.");
							}
							else
							{
								int i = 1;
								foreach (DBMonsterSpell mspell in u.Spells)
								{
									if (mspell != null)
									{
										Chat.System(client, i + " : " + mspell.Spell.Name + " , Rank " + mspell.Spell.Rank + " , Offensive = " + mspell.Offensive);
										//mspell.Spell.Name
										i++;
									}
								}
							}
						}
							
						
					}
					return true;
				case "recreature":
				case "rc":
					{
						int creatureID = int.Parse(command[2]);
						Chat.System(client, "Updated: " + ReloadCreatures(creatureID) + " spawns: " + creatureID);
					}
					return true;
					//break;
                case "rego":
                case "rg":
                    {
                        int goID = int.Parse(command[2]);
                        Chat.System(client, "Updated: " + ReloadGameObjects(goID) + " GO spawns: " + goID);
                    }
                    return true;
                case "addspell":
				case "as":
					{
						if (u == null || !(u is NPCBase))
							return false;

						int spellid = int.Parse(command[2]);
						NPCBase n = (NPCBase) u;

						if (n.Train == null)
							n.InitVendor();

						foreach (DBSpell spell in n.Train)
						{
							if (spell.SpellID == spellid)
							{
								Chat.System(client, "Spell already exist in trainer list");
								return false;
							}
						}

						DBSpell nSpell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellid);
						if (nSpell == null)
						{
							Chat.System(client, "Invalid spell ID");
							return false;
						}

						if (nSpell.Effect[0].Type != SPELLEFFECT.TEACH)
						{
							DBSpell trainSpell = (DBSpell) Database.Instance.FindObjectByField(typeof (DBSpell), "Effect_0_Spell", spellid);
							if (trainSpell != null)
							{
								Chat.System(client,
								            "Spell " + spellid + " [" + nSpell.Name + "] is not trainer spell, correct to " + trainSpell.SpellID);
								spellid = trainSpell.SpellID;
								nSpell = trainSpell;
							}
							else
							{
								Chat.System(client, "Spell " + spellid + " [" + nSpell.Name + "] is not trainer spell, and have no train spell.");
								return false;
							}
						}

						DBTrain newTrain = new DBTrain();
						newTrain.GroupID = n.Spawn.TrainGroupID;
						newTrain.TargetID = (uint) spellid;
						DBManager.NewDBObject(newTrain);
						DBManager.SaveDBObject(newTrain);
						n.Train.Add(nSpell);
						Chat.System(client, "Spell " + nSpell.Name + " [" + spellid + "] has been added.");
					}
					break;
				case "removespell":
				case "rs":
					{
						if (u == null || !(u is NPCBase))
							return false;

						int spellid = int.Parse(command[2]);
						NPCBase n = (NPCBase) u;

						if (n.Train == null)
							n.InitVendor();

						foreach (DBSpell spell in n.Train)
						{
							if (spell.SpellID == spellid)
							{
								n.Train.Remove(spell);
								ICollection result =
									Database.Instance.SelectObjects(typeof (DBTrain),
									                                "TrainGroupID=" + n.Spawn.TrainGroupID + " AND TrainTargetID=" + spellid);

								DBTrain train = null;

								if (result != null)
									foreach (DBTrain tr in result)
									{
										train = tr;
										break;
									}

								if (train != null)
								{
									DBManager.EraseDBObject(train);
									Chat.System(client, "Spell " + spell.Name + " [" + spellid + " ] has been removed.");
									return true;
								}
								Chat.System(client, "Removing error");
								return false;
							}
						}
					}
					break;
				case "sethp":
				case "shp":
					{
						if (u == null)
							return false;
						int health = int.Parse(command[2]);
						u.Health = health;
						DBCreature creature = u.Creature;

						float m_coef = 1;
						switch (u.Creature.Elite)
						{
							case 1:
								m_coef *= 1.50F;
								break;
							case 2:
								m_coef *= 2.00F;
								break;
							case 3:
								m_coef *= 6.00F;
								break;
							case 4:
								m_coef *= 5.00F;
								break;
						}

						int m_baseHealth = (int) (((((u.Level*u.Level)*m_coef) + ((u.Level*m_coef)*1.15F)) + 35.00F)*1);
						float newHPL = (float) ((double) health/(double) m_baseHealth);

						creature.HealthPerLevel = newHPL;
						DBManager.SaveDBObject(creature);
						DoRespawn(u, p != null ? p : Client.Player);
					}
					break;
				case "sp":
				case "startpath":
					{
						p = p == null ? Client.Player : p;
						DBMovepoint move = new DBMovepoint();
						move.Position = p.Position.Clone();
						move.Number = 0;
						PooledList<DBMovepoint> points = new PooledList<DBMovepoint>();
						points.Add(move);
						m_pPoints.Add(p.GUID, points);
						Chat.System(client, "Start new path....");
						return true;
					}

					//break;
				case "np":
				case "nextpoint":
					{
						p = p == null ? Client.Player : p;
						if (m_pPoints.ContainsKey(p.GUID))
						{
							DBMovepoint move = new DBMovepoint();
							move.Position = p.Position.Clone();
							move.Number = (byte)m_pPoints[p.GUID].Count;
							m_pPoints[p.GUID].Add(move);
							Chat.System(client, "Create next point: " + m_pPoints[p.GUID].Count);
						}
						else
						{
							Chat.System(client, "You should start path first use .mod startpath");
						}
						return true;
					}
					//break;
				case "finish":
				case "f":
					{
						if (u == null)
						{
							Chat.System(client, "Select mob unit to assign created path.");
							return true;
						}

						p = p == null ? Client.Player : p;

						if (m_pPoints.ContainsKey(p.GUID))
						{
							/*
							DBMovepoint move = new DBMovepoint();
							move.Position = p.Position.Clone();
							move.Number = points.Count;
							points.Add(move);
							*/

							foreach (DBMovepoint point in m_pPoints[p.GUID])
							{
								DBManager.NewDBObject(point);
								DBManager.SaveDBObject(point);
							}

							u.Spawn.Movepoints = m_pPoints[p.GUID];

							u.UpdateData();
							DBManager.SaveDBObject(u.Spawn);
							DBManager.SaveDBObject(u.Creature);
							
							DoRespawn(u, p);
							Chat.System(client, "New path assigned.");
							m_pPoints.Remove(p.GUID);
						}
						else
						{
							Chat.System(client, "You should start path first use .mod startpath");
						}
						return true;
					}
					//break;
				default:
					Chat.System(client, "Unknown propetry");
					return true;
			}

			o.UpdateData();
			DBManager.SaveDBObject(u.Spawn);
			DBManager.SaveDBObject(u.Creature);
			
			if (p != null)
				DBManager.SaveDBObject(p.Character);
			return true;
		}


        public static int ReloadGameObjects(int goID)
        {
            ICollection dbobjects =
                Database.Instance.FindObjectsByField(typeof(DBGameObject), "TemplateID", goID);

            CustomArrayList gobjects = new CustomArrayList();
            foreach (DBGameObject dbgo in dbobjects)
            {
                if (dbgo != null)
                {
                    MapInstance instance = MapManager.GetWorldMap(dbgo.WorldMapID, 0);
                    MapTile tile = instance.GetTileByLoc(dbgo.Position);
                    foreach (GameObject go in tile.GameObjects)
                        if (go != null && go.DBGameObject.ObjectId == dbgo.ObjectId) // bingo
                            gobjects.Add(go);
                }
            }
            
            for (int i = 0; i < gobjects.Count; i++)
            {
                //  refresh DBObjects
                GameObject go = (GameObject)gobjects[i];

                try
                {

                    Database.Instance.ReloadObject(go.DBGameObject);
                    Database.Instance.FindObjectByKey(typeof(DBGameObject), go.DBGameObject.ObjectId);

                    if (go.Loot != null)
                    {
                        foreach (DBGOLoot loot in go.DBGameObject.Loot)
                        {
                            Database.Instance.ReloadObject(loot);
                            Database.Instance.FindObjectByKey(typeof(DBLoot), loot.ObjectId);
                        }
                    }

                    if (go.DBGameObject.EndQuests == null || go.DBGameObject.StartQuests == null)
                        Database.Instance.ResolveRelations(go.DBGameObject, typeof(DBQuest));

                    if (go.DBGameObject.StartQuests.Count> 0)
                    {
                        foreach (DBQuest quest in go.DBGameObject.StartQuests)
                        {
                            if (quest != null)
                            {
                                Database.Instance.ReloadObject(quest);
                                Database.Instance.FindObjectByKey(typeof(DBTrain), quest.ObjectId);
                            }
                        }
                    }
					if (go.DBGameObject.EndQuests.Count > 0)
                    {
                        foreach (DBQuest quest in go.DBGameObject.EndQuests)
                        {
                            if (quest != null)
                            {
                                Database.Instance.ReloadObject(quest);
                                Database.Instance.FindObjectByKey(typeof(DBTrain), quest.ObjectId);
                            }
                        }
                    }
                }
                catch
                {
                    LogConsole.Write(LogLevel.ERROR, "Reload:;  Error in update DB Objects");
                }

                MapInstance instance = go.MapTile.Map;
                instance.Leave(go);
                instance.Enter(go);
                go.UpdateData();
            }
            return gobjects.Count;
        }



        public static int ReloadCreatures(int creatureID)
        {
            ICollection spawns =
                Database.Instance.SelectObjects(typeof(DBSpawn), "CreatureID = " + creatureID);
            CustomArrayList units = new CustomArrayList();
            foreach (DBSpawn spawn in spawns)
            {
                if (spawn != null)
                {
                    MapInstance instance = MapManager.GetWorldMap(spawn.WorldMapID, 0);
                	MapTile tile = instance.GetTileByLoc(spawn.Position);
					foreach (UnitBase unit in tile.Units)
						if (unit != null && unit.Spawn.ObjectId == spawn.ObjectId) // bingo
							units.Add(unit);
                	
					foreach (MapTile atile in tile.Adjacents.Tiles)
					{
						foreach (UnitBase unit in atile.Units)
							if (unit != null && unit.Spawn.ObjectId == spawn.ObjectId) // bingo
								units.Add(unit);
					}
                }
            }

            for (int i = 0; i < units.Count; i++)
            {
                //  refresh DBObjects
                UnitBase unit = (UnitBase)units[i];


				try
				{
					Database.Instance.ReloadObject(unit.Creature);
					Database.Instance.ReloadObject(unit.Spawn);


					unit.DoSleep();
					unit.DoAwake();
				}
				catch
				{
					LogConsole.Write(LogLevel.ERROR, "Reload:;  Error in update DB Objects");
				}

                Database.Instance.FindObjectByKey(typeof(DBCreature), creatureID);
                DBSpawn spawn = (DBSpawn)Database.Instance.FindObjectByKey(typeof(DBSpawn), unit.Spawn.ObjectId);


                if (unit.Spawn.TextID > 0)
                {

                    Database.Instance.ResolveRelations(unit.Spawn, true);
                    if (unit.Spawn.Speech != null)
                    {
                        Database.Instance.ReloadObject(unit.Spawn.Speech);
                        Database.Instance.FindObjectByKey(typeof(DBSpeech), unit.Spawn.TextID);

                        DBDialog dlg = (DBDialog)Database.Instance.FindObjectByKey(typeof(DBDialog), unit.Spawn.Speech.Dialog(CLASS.WARRIOR));
                        if (dlg != null)
                            Database.Instance.ReloadObject(dlg);
                    }

                }

                MapInstance inst = unit.MapTile.Map;
                inst.Leave(unit);
                UnitBase tunit = AIManager.CreateMobile(spawn);
                //Console.WriteLine(unit.Spawn.Position + " , " + tunit.Position);
                inst.Enter(tunit);
                tunit.Redress();
                tunit.UpdateData();
            }

            return units.Count;
        }
			
		

		private static void DoRespawn(UnitBase u, PlayerObject p)
		{
			MapInstance map = u.MapTile.Map;
			DBSpawn spawn = u.Spawn;
			u.Dispose();
			map.Leave(u);
			u = AIManager.CreateMobile(spawn);
			map.Enter(u);
			p.Selection = null;
		}
	}
}