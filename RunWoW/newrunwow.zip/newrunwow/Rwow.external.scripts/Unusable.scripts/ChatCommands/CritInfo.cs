using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;

namespace RunWoW.ExternalScripts.ChatCommands
{
	public class CritInfo
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("critinfo", "critinfo spell_id", new ChatCommand(OnCritInfo));
		}

		private static bool OnCritInfo(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;
			string[] command = input.Split(new char[] { '=', ' ' });

			if (command.Length < 2)
			{
				Chat.System(client, "Format: shoot spell_id");
				return true;
			}

			ushort spellid = 0;
			try
			{
				spellid = ushort.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid spell id!");
				return true;
			}

			DBSpell spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellid);
			
			if (spell == null)
			{
				Chat.System(client, "Not valid spell id!");
				return true;
			}

			float value = Client.Player.MagicCritChance/100f + Client.Player.SpellProcessor.AdditionalCritChance(spell);

			float critBonus = 1.5f + Client.Player.SpellProcessor.AdditionalCritDamage(spell);

			Chat.System(client, string.Format("Crit value for spell {0}[{1}] = {2:0.0%}, bonus {3}", spell.Name, spell.Rank, value, critBonus));

			for(int i=0;i<spell.Effect.Length;i++)
				if (spell.Effect[i].Type == SPELLEFFECT.SCHOOL_DAMAGE || spell.Effect[i].Type == SPELLEFFECT.WEAPON_DAMAGEP || spell.Effect[i].Type == SPELLEFFECT.WEAPON_DAMAGEP1 || spell.Effect[i].Type == SPELLEFFECT.INSTANT_WDAMAGE)
				{
					float minDamage = Client.Player.SpellProcessor.PureDamage(spell, 0);
					float maxDamage = Client.Player.SpellProcessor.FullDamage(spell, 0);

					Chat.System(client,
					            string.Format("Damage: {0} - {1} ({2} - {3})", minDamage, maxDamage, spell.Effect[i].Damage,
					                          spell.Effect[i].Value));
				}

			return true;
		}
	}
}
