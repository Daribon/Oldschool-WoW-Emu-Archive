using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class SetHitsCommand
	{
		private static ClientBase ValidateUserByString(string _string, ClientBase client)
		{
			//ClientData Client = (ClientData)client.Data;

			ClientBase cb_temp = ClientManager.GetClient(_string);

			if (cb_temp == null)
			{
				Chat.System(client, "No client found: '" + _string + "'");
				return null;
			}
			else
			{
				return cb_temp;
			}

		}

		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("sethits", "USAGE: '.sethits' || USAGE: '.sethits [hitpoints]' || USAGE: '.sethits [hits] [player_name]' || or choose player and say '.sethits [hitpoints]'", new ChatCommand(OnSetHitsCommand));
		}

		private static bool OnSetHitsCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			Chat.System(client, "-------------------");


			string[] command = s.Split(new char[] {',', ' '});
			switch (command.Length)
			{
				case 1:
					{
						Client.Player.Health = Client.Player.MaxHealth;
						Chat.System(client, "Your hitpoints have been restored");

						return true;
					}
					;

				case 2:
					{
						if (Client.Player.Selection == null)
						{
							int newhits = 0;

							try
							{
								newhits = int.Parse(command[1]);
							}
							catch (Exception)
							{
								Chat.System(client, "Bad [hitpoints] number");
								return false;
							}

							if (newhits <= Client.Player.MaxHealth)
								Client.Player.Health = newhits;
							else
								Client.Player.Health = Client.Player.MaxHealth;

							Chat.System(client, "Your hitpoints are now: " + Client.Player.Health);

						}
						else
						{
							if (Client.Player.Selection is LivingObject)
							{
								int newhits = 0;

								try
								{
									newhits = int.Parse(command[1]);
								}
								catch (Exception)
								{
									Chat.System(client, "Bad [hitpoints] number");
									return false;
								}

								LivingObject lo = Client.Player.Selection as LivingObject;

								if (newhits <= lo.MaxHealth)
									lo.Health = newhits;
								else
									lo.Health = lo.MaxHealth;

							}
						}

						return true;
					}
					;

				case 3:
					{
						ClientBase client_to_work = ValidateUserByString(command[2], client);

						if (client_to_work != null)
						{
							int newhits = 0;

							try
							{
								newhits = int.Parse(command[1]);
							}
							catch (Exception)
							{
								Chat.System(client, "Bad [hitpoints] number");
								return false;
							}

							ClientData lo = (ClientData) client_to_work.Data;

							if (newhits <= lo.Player.MaxHealth)
								lo.Player.Health = newhits;
							else
								lo.Player.Health = lo.Player.MaxHealth;

						}
						else
						{
							return false;
						}

						return true;
					}

				default:
					return false;
			}
		}
	}
}

/*	public enum ACCESSLEVEL : byte 
	{ 
		BANNED=0, 
		NORMAL=2, 
		TEMPGM=5, 
		GM=6, 
		ADMIN=9, 
	}*/