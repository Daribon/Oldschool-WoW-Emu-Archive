using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Invis
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("invis", "", new ChatCommand(OnInvis));
		}

		private static bool OnInvis(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine(string.Format("Chat command: {0}, Selection: {1}", input, (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name)), Client.Account.Name);
			
			string[] command = input.Split(new char[] { '=', ' ' });

			if (command.Length < 2)
			{
				Client.Player.InvisLevel = Client.Player.InvisLevel == 0 ? Client.Player.SenseInvisLevel : 0;
				Client.Player.MapTile.Map.Reenter(Client.Player);
				Chat.System(client, "Invis level " + Client.Player.InvisLevel);
				return true;
			}
			int level;
			try
			{
				level = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid invis level!");
				return true;
			}
			if (level > Client.Player.SenseInvisLevel)
			{
				Chat.System(client, "No permission to this invis level!");
				return true;
			}

			Client.Player.InvisLevel = level;
			Client.Player.MapTile.Map.Reenter(Client.Player);
			Chat.System(client, "Invis level " + Client.Player.InvisLevel);
			return true;
		}
	}
}