using RunWoW.Accounting;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class AutoIgnore
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("ignore", "", new ChatCommand(OnAutoIgnore));
		}

		private static bool OnAutoIgnore(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			Client.Player.AutoIgnore = !Client.Player.AutoIgnore;
			Chat.System(client, "AutoIgnore mode " + (Client.Player.AutoIgnore ? "on" : "off"));
			return true;
		}
	}
}