using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.World;
using RunServer.Common;
using RunWoW.ServerDatabase;

namespace RunWoW.ChatCommands
{
	public class Respawn
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("respawn", "No target selected", new ChatCommand(OnRespawn));
		}

		private static bool OnRespawn(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			if (Client.Player.Selection == null)
				return false;
			ObjectBase o = Client.Player.Selection;
			if (o.ObjectType == OBJECTTYPE.UNIT)
			{
				UnitBase u = (UnitBase) o;
				MapInstance map = u.MapTile.Map;
				DBSpawn spawn = u.Spawn;

                //  refresh DBObjects // ����� ������.
                try
                {
                    Database.Instance.ReloadObject(u.Creature);
					//if ( u.Loot != null )
					//{
					//    foreach( DBLoot loot in u.Loot )
					//    {
					//        Database.Instance.ReloadObject(loot);
					//    }
					//}
					//if (u is NPCBase)
					//{
					//    NPCBase n = ((NPCBase)u);
					//    foreach (DBTrain train in n.Train )
					//    {
					//        Database.Instance.ReloadObject(train);
					//    }
					//    foreach (DBTrade trade in n.Trade)
					//    {
					//        Database.Instance.ReloadObject(trade);
					//    }

					//    foreach (DBQuest quest in spawn.StartQuests )
					//    {
					//        Database.Instance.ReloadObject(quest);
					//    }

					//    foreach (DBQuest quest in spawn.EndQuests)
					//    {
					//        Database.Instance.ReloadObject(quest);
					//    }
					//}

                }
                catch
                {
                    LogConsole.Write(LogLevel.ERROR, "Respawn:OnRespawn();  Error in update DB Objects");
                }
                
				map.Leave(u);
				u = AIManager.CreateMobile(spawn);
				map.Enter(u);
				Client.Player.Selection = null;
				Chat.System(client, "Spawned mobile: " + u.Name + ", Faction: " + u.Faction + ", NpcFlags: " + u.NPC_Flags + ", Flags: " + u.Flags + ", BehaivorID: " + u.Spawn.BehaivorID);
			}
			return true;
		}
	}
}