//
using System;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class AddSpawn
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("addspawn", "addspawn CreatureID [level] [faction] [behaivor] [flags]", new ChatCommand(OnAddSpawn));
		}

		private static bool OnAddSpawn(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			string[] command = input.Split(new char[] {',', ' '});

/*			if (command.Length<1)
				return false;*/
			int cid, level = -1, behaivor = -1;
			int flags = -1;
			FACTION faction = FACTION.NONE;
			try
			{
				cid = int.Parse(command[1]);
				if (command.Length > 2)
					level = int.Parse(command[2]);
				if (command.Length > 3)
					faction = (FACTION) int.Parse(command[3]);
				if (command.Length > 4)
					behaivor = int.Parse(command[4]);
				if (command.Length > 5)
					flags = int.Parse(command[5]);
			}
			catch (Exception)
			{
				return false;
			}

			DBCreature c = (DBCreature) Database.Instance.FindObjectByKey(typeof (DBCreature), cid);
			if (c == null)
			{
				Chat.System(client, "Unknown CreatureID!");
				return true;
			}
			DBSpawn s = new DBSpawn(c, Client.Player.WorldMapID, Client.Player.Facing, Client.Player.Position);

			if (faction != FACTION.NONE)
				s.Faction = faction;
			if (behaivor != -1)
				s.BehaivorID = (byte) behaivor;
			if (flags != -1)
				s.NpcFlags = (uint) flags;
			if (level != -1)
				s.Level = (byte) level;

			DBManager.NewDBObject(s);

			UnitBase u = AIManager.CreateMobile(s);
			Client.Player.MapTile.Map.Enter(u);
			Client.Player.Selection = null;
			Chat.System(client, "Spawned mobile: " + c.Name + ", Faction: " + u.Faction + ", NpcFlags: " + u.NPC_Flags + ", Flags: " + u.Flags + ", BehaivorID: " + u.Spawn.BehaivorID);
			return true;
		}
	}
}