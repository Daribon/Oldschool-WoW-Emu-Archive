using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Map;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Position
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("pos", "", new ChatCommand(OnPos));
			ChatManager.RegisterChatCommand("position", "", new ChatCommand(OnPos));
		}

		private static bool OnPos(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.NORMAL)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			//LogConsoleGM.WriteLine("Chat command: Position:"+Client.Player.Position+", Facing: "+Client.Player.Facing, Client.Account.Name );
			Chat.System(client, string.Format("Position: {0} {1}, world: {2}, zone {3}, area {4}, instance {5}", Client.Player.Position, Client.Player.Facing, Client.Player.WorldMapID, Client.Player.Zone, Client.Player.Area == null ? 0: Client.Player.Area.ObjectId, Client.Player.MapTile.Map.InstanceID) );
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
				return true;

			/*float water;
			float z;

			z = WorldMap.GetPoint((int) Client.Player.WorldMapID, Client.Player.Position.X, Client.Player.Position.Y, out water);
			Chat.System(client, "Map X,Y,Z: " + z + ", Water Level: " + water);
			z = WorldMap.GetPoint((int) Client.Player.WorldMapID, Client.Player.Position.X + 10, Client.Player.Position.Y, out water);
			Chat.System(client, "Map X+1,Y,Z: " + z + ", Water Level: " + water);
			z = WorldMap.GetPoint((int) Client.Player.WorldMapID, Client.Player.Position.X, Client.Player.Position.Y + 10, out water);
			Chat.System(client, "Map X,Y+1,Z: " + z + ", Water Level: " + water);
			z = WorldMap.GetPoint((int) Client.Player.WorldMapID, Client.Player.Position.X - 10, Client.Player.Position.Y, out water);
			Chat.System(client, "Map X-1,Y,Z: " + z + ", Water Level: " + water);
			z = WorldMap.GetPoint((int) Client.Player.WorldMapID, Client.Player.Position.X, Client.Player.Position.Y - 10, out water);
			Chat.System(client, "Map X,Y-1,Z: " + z + ", Water Level: " + water);*/
			return true;
		}

	}

}