using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.DB.DataTables;
using RunWoW.Misc;

namespace RunWoW.ChatCommands
{
	public class Judgement
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("judgement", "", new ChatCommand(OnJudgement));
		}

		private static bool OnJudgement(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;

			DBAbility ability = Client.Player.Spells[20271];
			if (ability == null)
			{
				Chat.System(client, "You do not have Judgement spell!");
			}

			GamePackets.Spells.DoSpellCast(client, 20271, 2, Client.Player.SelectionGUID, null, null, Client.Player.Selection, CustomDateTime.Now);
			return true;
		}
	}
}