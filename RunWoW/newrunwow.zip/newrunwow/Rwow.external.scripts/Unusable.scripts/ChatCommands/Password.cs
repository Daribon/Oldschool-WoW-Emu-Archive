//
using System.Text.RegularExpressions;
using RunWoW.Accounting;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Password
	{
		private static Regex passCheck = new Regex(@"^[a-z]*$", RegexOptions.Compiled | RegexOptions.IgnoreCase); 
		
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("password", "USAGE: .password newpass  - sets your password", new ChatCommand(OnPassword));
		}

		private static bool OnPassword(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;

			LogConsole.WriteLine(LogLevel.SYSTEM, "Seting password for account " + Client.Account.Name);

			string[] split = input.Split(new char[] {'=', ' '});
			if (split.Length != 2)
				return false;

			if (split[1].Length>12 || !passCheck.IsMatch(split[1]))
			{
				Chat.System(client, "Invalid password");
				return true;
			}
			Client.Account.Password = split[1].ToLower();
			DBManager.SaveDBObject(Client.Account);
			Database.Instance.WriteDatabaseTable(typeof (DBAccount));
			Chat.System(client, "Password set");
			return true;
		}

	}
}