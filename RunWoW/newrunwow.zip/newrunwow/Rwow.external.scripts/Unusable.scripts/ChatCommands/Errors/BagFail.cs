using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.GamePackets;
using RunWoW.Misc;

namespace RunWoW.ChatCommands.Errors
{
	public class BagFail
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("bfail", "bfail <code>", new ChatCommand(OnBagFail));
		}

		private static bool OnBagFail(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] { '=', ' ' });
			
			if (command.Length < 2)
			{
				return false;
			}

			int code = 0;
			try
			{
				code = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid Bag Fail Code!");
				return true;
			}

			Items.SendChangeFail(client, null, null, (BagResponseUpdateFields) code);
			return true;
		}
	}
}
