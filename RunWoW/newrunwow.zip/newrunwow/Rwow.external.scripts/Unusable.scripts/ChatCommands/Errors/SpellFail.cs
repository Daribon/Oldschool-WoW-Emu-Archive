using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Events;
using RunWoW.Misc;

namespace RunWoW.ChatCommands.Errors
{
	public class SpellFail
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("sfail", "sfail <code>", new ChatCommand(OnSpellFail));
		}

		private static bool OnSpellFail(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] { '=', ' ' });
			
			if (command.Length < 2)
			{
				return false;
			}

			int code = 0;
			try
			{
				code = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid Spell Fail Code!");
				return true;
			}

			SpellCastEvent.SpellCastResult(client, 0, (SpellFailedReason)code);
			return true;
		}
	}
}
