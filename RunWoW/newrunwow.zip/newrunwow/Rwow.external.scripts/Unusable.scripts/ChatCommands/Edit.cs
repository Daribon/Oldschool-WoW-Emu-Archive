using System.Collections;
using System.Reflection;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunServer.Common;
using RunWoW.DB.DataTables;
using System;

namespace RunWoW.ChatCommands
{
	public class Set
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("set", "No unit selected", new ChatCommand(OnSet));
		}

		private static bool OnSet(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			if (Client.Player.Selection == null)
				return false;
			ObjectBase o = Client.Player.Selection;
			LivingObject l = o as LivingObject;
			if (l == null)
				return false;
			UnitBase u = o as UnitBase;
			if (u!=null && u.Spawn==null)
				u = null;
			PlayerObject player = o as PlayerObject;

			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 3)
			{
				Chat.System(client, "Format: set <property> value");
				Chat.System(client, "Property can be one of: name, loot, faction, behaivor, behaivorid, creature, creatureid, npcflag, npcflags, level, textid");
				return true;
			}
			Chat.System(client, "Setting property " + command[1] + " to " + command[2]);
			switch (command[1].ToLower())
			{
				/*case "name":
					string nname = command[2];
					for (int i = 3; i < command.Length; i++)
						nname = nname + " " + command[i];
					if (nname == "-" && u != null)
						nname = u.Creature.Name;

					l.Name = nname;

					break;*/
				case "property":
					string nname = command[2];
					string nvalue = command[3];
					PropertyInfo pi = o.GetType().GetProperty(nname);
					if (pi == null)
						Chat.System(client, "Invalid property!");
					else
					{
						try
						{
							pi.SetValue(o, Convert.ChangeType(nvalue, pi.PropertyType), null);
						}
						catch
						{
							Chat.System(client, "Cannot set value!");
						}
					}

					break;
				case "guild":
					if (player != null)
						player.GuildID = uint.Parse(command[2]);
					break;
                case "grank":
                case "guildrank":
                    if (player != null)
                        player.GuildRank = uint.Parse(command[2]);
                    break;
                case "skill":
                    if (player != null && command.Length == 4 )
                    {
                        for (int i = 0; i < player.Skills.Skills.Length; i++)
                        {
                            PlayerSkill playerSkill = player.Skills.Skills[i];
                        	
                            if (playerSkill.SkillID == uint.Parse(command[2]))
                            {
                                try
                                {
                                    int nlevel = int.Parse(command[3]);
                                    playerSkill.Ability.Level = (ushort)(nlevel > playerSkill.MaxLevel?playerSkill.MaxLevel:nlevel);
                                    playerSkill.Load(playerSkill.Ability, player.Level);
									player.Skills.UpdateSkill((SKILL)playerSkill.SkillID);
                                    player.UpdateData();
                                    return true;
                                }
                                catch 
                                {
                                    Chat.System(client, "Invalid skill level!");
                                    return true;
                                }
                            }
                        }
                    }
                    break;
                /*case "title":
                if (u==null)
                    return false;
                u.Spawn.Title=command[2];
                break;*/
				/*case "aura":
					if (l == null)
						return false;
					if (command.Length < 4)
						return false;
					uint num = uint.Parse(command[2]);
					uint value = uint.Parse(command[3]);
					l.Auras.auras[num] = value;
					break;
				case "auraa":
					if (l == null)
						return false;
					if (command.Length < 4)
						return false;
					num = uint.Parse(command[2]);
					value = uint.Parse(command[3]);
					l.Auras.applications[num] = value;
					break;
				case "aural":
					if (l == null)
						return false;
					if (command.Length < 4)
						return false;
					num = uint.Parse(command[2]);
					value = uint.Parse(command[3]);
					l.Auras.levels[num] = value;
					break;
				case "auraf":
					if (l == null)
						return false;
					if (command.Length < 4)
						return false;
					num = uint.Parse(command[2]);
					value = uint.Parse(command[3]);
					l.Auras.flags[num] = value;
					break;
				case "auras":
					if (l == null)
						return false;
					value = uint.Parse(command[2]);
					l.Auras.m_count = value;
					break;*/
				case "shift":
					if (l == null)
						return false;
					byte bvalue = byte.Parse(command[2]);
					l.SShift = bvalue;
					break;
				case "loot":
				case "lootgroup":
				case "lootid":
					if (u == null)
						return false;
					u.Spawn.LootGroupID = uint.Parse(command[2]);
					break;
				case "faction":
					l.Faction = (FACTION) int.Parse(command[2]);
					break;
				case "behaivor":
				case "behaivorid":
					if (u == null)
						return false;
					u.Spawn.BehaivorID = byte.Parse(command[2]);
					break;
				case "creature":
				case "creatureid":
					if (u == null)
						return false;
					u.Spawn.CreatureID = uint.Parse(command[2]);
					break;
				case "npcflag":
				case "npcflags":
					if (u == null)
						return false;
					u.NPC_Flags = uint.Parse(command[2]);
					break;
				case "text":
				case "textid":
					if (u == null)
						return false;
					u.Spawn.TextID = uint.Parse(command[2]);

                    // Try set speech 
                    DBSpeech speech = (DBSpeech)Database.Instance.FindObjectByKey(typeof(DBSpeech), u.Spawn.TextID);
                    if (speech != null)
                    {
                        u.Spawn.Speech = speech;
                    }
					break;
				case "train":
				case "trainid":
				case "traingroupid":
					if (!(u is NPCBase))
						return false;

					((NPCBase)u).ReinitTrain(uint.Parse(command[2]));
					break;
				case "trade":
				case "tradeid":
				case "tradegroupid":
					if (u == null)
						return false;
					
					u.Spawn.TradeGroupID = uint.Parse(command[2]);
					u.Spawn.Trade = null;
					Database.Instance.ResolveRelations(u.Spawn, typeof (DBTrade));
					
					break;
                case "taxi":
                case "taxiid":
                    if (u == null)
                        return false;
                    u.Spawn.TaxiID = uint.Parse(command[2]);
                    break;
                case "flag":
				case "flags":
					if (u != null)
						u.Spawn.Flags = int.Parse(command[2]);
					l.Flags = int.Parse(command[2]);
					break;
				case "sflag":
				case "sflags":
					l.SFlags = byte.Parse(command[2]);
					break;
				case "playerflag":
				case "playerflags":
					if (player == null)
						return false;
					player.PlayerFlags = byte.Parse(command[2]);
					break;
				case "moveflag":
					l.MovementFlags = int.Parse(command[2]);
					break;
				case "pvprank":
				case "rank":
					if (player == null)
						return false;
					player.PVPRank = byte.Parse(command[2]);
					break;
				case "facing":
					if (command[2] != "me")
						l.Facing = float.Parse(command[2]);
					else
						l.Facing = l.Position.Angle(Client.Player.Position);
					if (u != null)
						u.Spawn.Facing = l.Facing;
					break;
				case "dynamicflag":
				case "dynamicflags":
					l.DynamicFlags = uint.Parse(command[2]);
					break;
				case "level":
					if (u != null)
						u.Spawn.Level = byte.Parse(command[2]);
					l.Level = int.Parse(command[2]);
					break;
				case "display":
				case "displayid":
					if (l == null)
						return false;
					if (command.Length < 3)
						return false;
					l.DisplayID = int.Parse(command[2]);
					break;
				case "virtualitem0":
				case "vi0":
					if (u == null)
						return false;
					u.VirtualItemMainhandDisplay = int.Parse(command[2]);
					break;
				case "virtualitem1":
				case "vi1":
					if (u == null)
						return false;
					u.VirtualItemOffhandDisplay = int.Parse(command[2]);
					break;
				case "virtualitem2":
				case "vi2":
					if (u == null)
						return false;
					u.VirtualItemRangedDisplay = int.Parse(command[2]);
					break;
                case "speed":
                    float speed = 1;
                    
                    try { speed = float.Parse(command[2]); } catch (Exception){}
                    speed = speed > 6 ? 6 : speed;
                    PlayerObject targetPlayer = Client.Player.Selection == null ? player : (player.Selection is PlayerObject) ? ((PlayerObject)player.Selection) : null;
					if (targetPlayer != null)
                    {
						targetPlayer.Modifiers.UnregisterAllModifiers(MODIFIER.SPEED_PCT);
						targetPlayer.Modifiers.RegisterModifier(MODIFIER.SPEED_PCT, speed, 0);
						targetPlayer.Redress();
						targetPlayer.UpdateData();
						targetPlayer.ForceUpdateData();
						targetPlayer.Save();
						Chat.System(client, "Set speed to " + command[1] + " for [" + targetPlayer.Name + "]");
                    }
                    else
                    {
                        Chat.System(client, "Format: setspeed <player>");
                        return false;
                    }
                    return true;
				default:
					Chat.System(client, "Unknown propetry");
					return true;
			}
			o.UpdateData();
			if (u != null)
			{
				DBManager.SaveDBObject(u.Spawn);
				DBManager.SaveDBObject(u.Creature);
			}
			if (player != null)
				DBManager.SaveDBObject(player.Character);
			return true;
		}
	}
}