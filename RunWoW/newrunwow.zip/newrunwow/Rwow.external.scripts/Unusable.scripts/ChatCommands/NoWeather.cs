using RunWoW.Accounting;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class NoWeather
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("noweather", "", new ChatCommand(OnNoWeather));
		}

		private static bool OnNoWeather(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;
			Client.Player.NoWeather = !Client.Player.NoWeather;
			Chat.System(client, "No weather mode " + (Client.Player.NoWeather ? "on" : "off"));
			return true;
		}
	}
}