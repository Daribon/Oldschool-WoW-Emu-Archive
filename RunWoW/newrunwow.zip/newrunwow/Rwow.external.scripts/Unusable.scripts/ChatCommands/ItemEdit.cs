using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class ItemEdit
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("itemedit", "<property> value", new ChatCommand(OnItemEdit));
		}

		private static bool OnItemEdit(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.ADMIN)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] { '=', ' ' });
			if (command.Length < 3)
			{
				Chat.System(client, "Format: itemedit <property> value");
				return true;
			}

			ItemObject item = Client.Player.Inventory[INVSLOT.BACKPACK_FIRST];

			if (item == null)
			{
				Chat.System(client, "No item in first slot!");
				return true;
			}
			Chat.System(client, "Setting property " + command[1] + " to " + command[2]);
			switch (command[1].ToLower())
			{
				case "sflags":
					item.StaticFlags = ushort.Parse(command[2]);
					break;
				case "dflags":
					item.DynamicFlags = ushort.Parse(command[2]);
					break;
				case "duration":
					item.Duration = CustomDateTime.Now.AddSeconds(int.Parse(command[2]));
					break;
				case "iduration":
					item.TsDuration = int.Parse(command[2]);
					break;
				default:
					Chat.System(client, "Unknown propetry");
					return true;
			}
			item.UpdateData();
			/*DBManager.SaveDBObject(go.GOTemplate);
			DBManager.SaveDBObject(go.);*/
			return true;
		}
	}
}