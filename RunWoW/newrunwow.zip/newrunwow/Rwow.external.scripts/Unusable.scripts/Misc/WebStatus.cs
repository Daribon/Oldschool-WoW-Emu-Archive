using System;
using System.IO;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.LoginPackets;
using RunWoW.Map;
using RunWoW.Objects;

namespace RunWoW.Misc
{
	public class StatusPage : Event
	{
		public static StatusPage Instance = new StatusPage();
		private static DateTime ServerStart = CustomDateTime.Now;
		private static int MaxPlayers = 0;
		private static int MaxQueue = 0;

		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}

		public StatusPage()
			: base(TimeSpan.FromSeconds(5.0), TimeSpan.FromMinutes(1.0))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			if (!Directory.Exists(Constants.StatusPath))
				Directory.CreateDirectory(Constants.StatusPath);

			using (StreamWriter op = new StreamWriter(Constants.StatusPath + Constants.StatusFile))
			{
				op.WriteLine("<HEAD><META HTTP-EQUIV='Refresh' CONTENT='60' /></HEAD>");
				op.WriteLine("<h2>World of Warcraft Server Status: &nbsp<img src='http://wowserver.wnet.ua/stat.aspx'></h2>");
				op.WriteLine("   <table class='border' width=100% cellspacing=1>");
				op.WriteLine("      <tr class='head'><th colspan=4><center>Server Information</center></th></tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <th>.NET Framework Version</th><td>" + Environment.Version + "</td>");
				op.WriteLine("         <th>Server Version</th><td>" + Constants.Version + "</td>");
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <th>Server uptime</th><td>" + StatusUtility.FormatTimeSpan(CustomDateTime.Now - ServerStart) +
				             "</td>");
				op.WriteLine("         <th>Last page update time</th><td>" + CustomDateTime.Now + "</td>");
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <th>OS Version</th><td>" + Environment.OSVersion + "</td>");
				op.WriteLine("         <th>Memory Used</th><td>" + StatusUtility.FormatByteAmount(GC.GetTotalMemory(false)) +
				             "</td>");
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <th>Total clients online</th><td>" + ClientManager.OnlineCount + "</td>");
				if (ClientManager.OnlineCount > MaxPlayers)
					MaxPlayers = ClientManager.OnlineCount;
				op.WriteLine("         <th>Maximum clients online</th><td>" + MaxPlayers + "</td>");
				op.WriteLine("      </tr>");
				op.WriteLine( "      <tr>" );
				op.WriteLine("         <th>Queue length</th><td>" + AuthQueueEvent.Instance.Count + "</td>");
				if (AuthQueueEvent.Instance.QueueCount > MaxQueue)
					MaxQueue = AuthQueueEvent.Instance.QueueCount;
				op.WriteLine("         <th>Maximum queue length</th><td>" + MaxQueue + "</td>");
				op.WriteLine( "      </tr>" );
				//int workers, ports;
				//ThreadPool.GetAvailableThreads(out workers, out ports);
				//op.WriteLine("      <tr>");
				//op.WriteLine("         <th>Available worker threads</th><td>" + workers + "</td>");
				//op.WriteLine("         <th>Available port threads</th><td>" + ports + "</td>");
				//op.WriteLine("      </tr>");

				op.WriteLine("   </table><br />");
				op.WriteLine("   <table  class='border' width=100% cellspacing=1 cellpadding=2>");
				op.WriteLine("      <tr class='head'>");
				op.WriteLine(
					"         <th width='20%'>Name</th><th width='10%'>Guild</th><th width='10%'>Level</th><th>Class</th><th>Race</th><th>World</th><th>In Group</th><th width='1%'></th>");
				op.WriteLine("      </tr>");

				PooledList<PlayerObject> players = ClientManager.GetPlayerList();

				int count = 0;
				foreach (PlayerObject player in players)
				{
					op.Write("<tr" + ((count++%2 == 1) ? " class='second'>" : ">"));
					op.Write("<td>" + player.Name + "</td>");
					if (player.Character.Guild != null)
						op.Write("<td>" + player.Character.Guild.Name + "</td>");
					else
						op.Write("<td>(none)</td>");
					op.Write("<td>" + player.Level + "</td>");
					op.Write("<td>" + player.Class + "</td>");
					op.Write("<td>" + player.Race + "</td>");
					op.Write("<td>" + ((WorldMap.Worlds)player.WorldMapID) + "</td>");
					op.Write("<td>" + (player.Group == null ? "false" : "true") + "</td>");
					op.Write("<td>" + (player.BackLink != null ? player.BackLink.Client.ToString() : "") + "</td>");
					op.Write("</tr>");
				}
				op.WriteLine("</table>");
			}
		}
	}
}