//
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunServer.Common;
using System.Collections;
using System;
using RunWoW.Misc;
using RunServer.Common.Attributes;

namespace RunWoW.ExternalScripts.ExternalDB
{
	internal class CastManager
	{
		public static Hashtable m_pCasters = Hashtable.Synchronized(new Hashtable());
		public static Hashtable m_pTargets = Hashtable.Synchronized(new Hashtable());
		public static int MAX_CAST_HISTORY = 10;

		public static bool CanCast(ObjectBase caster, ObjectBase target, DBSpell spell, int efnum)
		{
			int m_targetFlag = spell.Effect[efnum].TargetA;
			int m_target = spell.Effect[efnum].TargetB;

			switch ((TARGET) m_target)
			{
				case TARGET.TARGET_NEAR_ENEMIES:
                    if (caster is LivingObject && ((LivingObject)caster).Attackers[target.GUID] == null)
						return false;
					break;
				case TARGET.TARGET_SELF:
					if (spell.Effect[efnum].Type == SPELLEFFECT.AREA_AURA && !caster.Equals(target))
						// Target 1 (self)  and area - means only for party members (checked)
					{
						if (caster is PlayerObject && target is PlayerObject)
						{
							if (((PlayerObject) caster).Group == null || ((PlayerObject) target).Group == null)
								return false;

							if (((PlayerObject) caster).Group.ID != ((PlayerObject) target).Group.ID)
								return false;
						}
						else
							return false;
					}
					else if (!caster.Equals(target))
						return false;
					break;
			}

			return true;
		}

        public static bool IsValidCreatureType(LivingObject target, DBSpell spell)
        {
            if (target is UnitBase)
                return IsValidCreatureType( (CreatureType)((UnitBase) target).CreatureType, spell);
            else if ( target is PlayerObject && ((PlayerObject) target).Race == RACE.UNDEAD )
                return IsValidCreatureType( CreatureType.UNDEAD, spell);
            
            return true;
        }

	    public static bool IsValidCreatureType(CreatureType type, DBSpell spell)
		{
            if ((int)type == 0)  // If creature type is 0 then don`t need check for valid type
                return true;
	        
			if (spell.CreatureType > 0)
			{
				int flag = 1 << ((int)type-1);
				if (flag > 0 && (spell.CreatureType & flag) == flag)
					return true;
				else
					return false;
			} else 
				return true;
		}


		public static LivingObject PureTarget(ObjectBase caster, ObjectBase target, int targetB)
		{
			LivingObject mRet = (LivingObject) target;
			if (caster is PlayerObject && (targetB == (int) TARGET.TARGET_PET || targetB == (int) TARGET.TARGET_MINION) &&
			    ((PlayerObject) caster).Pet != null)
			{
				mRet = ((PlayerObject) caster).Pet;
			}
			else if (targetB == (int) TARGET.TARGET_SELF)
			{
				mRet = (LivingObject) caster;
			}

			return mRet;
		}

		public static void DidCast(LivingObject caster, LivingObject target, DBSpell spell, int effect)
		{
			lock (m_pCasters)
			{
				CustomArrayList cCasters = (CustomArrayList)m_pCasters[caster.GUID];

				if (cCasters == null)
				{
					cCasters = new CustomArrayList();
					m_pCasters.Add(caster.GUID, cCasters);
				}

				if (cCasters.Count > MAX_CAST_HISTORY)
					cCasters.RemoveAt(0);

				cCasters.Add(new CastWrapper(spell, effect));
			}


			lock (m_pTargets)
			{
				CustomArrayList cTargets = (CustomArrayList)m_pTargets[target.GUID];

				if (cTargets == null)
				{
					cTargets = new CustomArrayList();
					m_pTargets.Add(target.GUID, cTargets);
				}


				if (cTargets.Count > MAX_CAST_HISTORY)
					cTargets.RemoveAt(0);

				cTargets.Add(new CastWrapper(spell, effect));
			}
		}

		public static bool HaveCurse(LivingObject caster)
		{
			CustomArrayList cCasters = (CustomArrayList)m_pCasters[caster.GUID];

			if (cCasters != null)
			{
				foreach (CastWrapper cs in cCasters)
				{
					if (cs.Spell.IsCurse && cs.IsAlive)
						return true;
				}
			}
			return false;
		}

		internal static bool HaveSap(LivingObject caster)
		{
			CustomArrayList cCasters = (CustomArrayList)m_pCasters[caster.GUID];

			if (cCasters != null)
			{
				foreach (CastWrapper cs in cCasters)
				{
					if ((cs.Spell.SpellID == 2070 ||
						 cs.Spell.SpellID == 6770 ||
						 cs.Spell.SpellID == 11297)
						 && cs.IsAlive)
						return true;
				}
			}
			return false;
			
		}




		public class CastWrapper
		{
			DBSpell m_spell;
			public long m_castTime;
			int m_effect;


			public bool IsAlive 
			{

				get {
					long tPassed   =  (long)(new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds - m_castTime);
					return m_spell.Duration > tPassed;
					}
			}

			public DBSpell Spell
			{
				get { return m_spell; }
			}

			public CastWrapper(DBSpell spell, int effect)
			{
				m_spell = spell;
				m_effect = effect;
				m_castTime = (long)new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds;
			}
		}



	}


	public class CastHistoryCleanEvent : Event
	{
		private static CastHistoryCleanEvent Instance = new CastHistoryCleanEvent();

		public CastHistoryCleanEvent()
			: base(TimeSpan.FromMinutes(1.0), TimeSpan.FromMinutes(5.0))
			//: base(TimeSpan.FromSeconds(1.0), TimeSpan.FromSeconds(1.0))
		{
			Priority = TimerPriority.OneMinute;
			Primary = false;
			ExecPriority = ExecutionPriority.Separate;
		}

		protected override void OnTick()
		{
			long measure = (long)new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds;
			LogConsole.WriteLine(LogLevel.SYSTEM, "Cast History Clear: Casters-" + CastManager.m_pCasters.Count + ", Targets" + CastManager.m_pTargets.Count);
			CustomArrayList toRemove = new CustomArrayList();
			foreach (object key in CastManager.m_pCasters.Keys)
			{
				CustomArrayList clist = (CustomArrayList)CastManager.m_pCasters[key];
				if (clist != null && clist.Count > 0)
				{
					RunWoW.ExternalScripts.ExternalDB.CastManager.CastWrapper cw = (RunWoW.ExternalScripts.ExternalDB.CastManager.CastWrapper)clist[clist.Count - 1];
					long tPassed = (long)(new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds - cw.m_castTime);
					if (tPassed > 300000)
					{
						clist.Clear();
						toRemove.Add(key);
					}
				}
			}

			for (int i = 0; i < toRemove.Count; i++)
				CastManager.m_pCasters.Remove(toRemove[i]);

			toRemove.Clear();
			foreach (object key in CastManager.m_pTargets.Keys)
			{
				CustomArrayList clist = (CustomArrayList)CastManager.m_pTargets[key];
				if (clist != null && clist.Count > 0)
				{
					RunWoW.ExternalScripts.ExternalDB.CastManager.CastWrapper cw = (RunWoW.ExternalScripts.ExternalDB.CastManager.CastWrapper)clist[clist.Count - 1];
					long tPassed = (long)(new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds - cw.m_castTime);
					if (tPassed > 300000)
					{
						clist.Clear();
						toRemove.Add(key);
					}
				}
			}

			for (int i = 0; i < toRemove.Count; i++)
				CastManager.m_pTargets.Remove(toRemove[i]);

			measure = (long)new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds - measure;
			LogConsole.WriteLine(LogLevel.SYSTEM, "Clean Ok: Casters-" + CastManager.m_pCasters.Count + ", Targets" + CastManager.m_pTargets.Count + " , time: " + measure + " msec.");

		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}

}