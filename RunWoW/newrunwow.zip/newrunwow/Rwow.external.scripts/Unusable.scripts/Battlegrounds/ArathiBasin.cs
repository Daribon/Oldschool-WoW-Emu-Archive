namespace RunWoW.ExternalScripts.Battlegrounds
{
	internal class ArathiBasin : Battleground
	{
		protected override void Join(BGPlayer player,bool action)
		{
		}

		protected override void Leave(BGPlayer player)
		{ 
		}

		public override uint WorldNumberID
		{
			get { return 3; }
		}

		public override uint WorldMapID
		{
			get { return 529; }
		}

		public override uint ZoneID
		{
			get { return 0; }
		}
	}
}
