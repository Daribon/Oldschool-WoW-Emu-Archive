namespace RunWoW.ExternalScripts.Battlegrounds
{
	public enum BG_TYPE : int
	{
		UNKNOWN = -1,
		WARSONG_GULCH = 0,
		ARATHI_BASIN = 1,
		ALTERAC_VALLEY = 2,
	}

	public enum BG_STATUS : int
	{
		UNKNOWN = -1,
		INITIAL = 0,
		PROCESS = 1,
		FINISH = 2,
	}

	public enum BG_FLAG_STATUS : int
	{
		ON_BASE = 0,
		ON_PLAYER = 1,
		ON_GROUND = 2,
	}

	public enum QUEUE_STATUS : int
	{
		NOT_IN_QUEUE = -1,
		WAIT_IN_QUEUE = 1,
		IN_ACTION = 3,
		INVITED = 2,
	}

	public enum SOUND : int
	{
		PVPFlagCapturedAlliance = 8173,
		PVPFlagTakenAlliance = 8174,
		PVPFlagReturnedAlliance = 8192,

		PVPFlagTakenHorde = 8212,
		PVPFlagCapturedHorde = 8213,
		PVPFlagReturnedHorde = 8232,

		PVPWarningAlliance = 8332,
		PVPWarningHorde = 8333,

		PVPVictoryHorde = 8454,
		PVPVictoryAlliance = 8455,
	}

	public enum WORLD_UPDATE_INDEX : byte
	{
		ALLIANCE_FLAG_PICKUP = 9,
		HORDE_FLAG_PICKUP = 10,
		SHOW_SCORE_BOARD = 11,
		FLAGS_TO_FINISH_GAME = 65,
		ALLIANCE_CAPTURE_FLAG = 45,
		HORDE_CAPTURE_FLAG = 46,
	}

	public enum WORLD_STATE_CATEGORIES : byte
	{
		WARSONG_BG = 6,
	}

	public enum BG_TELEPORT_TO : int
	{
		HOME = 1,
		BG_START = 2,
	}


	public static class BGConstants
	{
		public static int WAIT_INVITE_TIME = 60000; // time given to player fo enter to bg after invitation received.

		public static string MSG_CAPTURE_HORDE_FLAG = "$N captured the Horde flag!";
		public static string MSG_CAPTURE_ALLIANCE_FLAG = "$N captured the Alliance flag!";
		public static string MSG_RETURN_ALLIANCE_FLAG = "The Alliance Flag was returned to its base by $n!";
		public static string MSG_RETURN_HORDE_FLAG = "The Horde Flag was returned to its base by $n!";
		public static string MSG_PICKUP_HORDE_FLAG = "The Horde flag was picked up by $n!";
		public static string MSG_PICKUP_ALLIANCE_FLAG = "The Alliance flag was picked up by $n!";
		public static string MSG_DROP_ALLIANCE_FLAG = "The Alliance Flag was dropped by $n!";
		public static string MSG_DROP_HORDE_FLAG = "The Horde Flag was dropped by $n!";
	}
}