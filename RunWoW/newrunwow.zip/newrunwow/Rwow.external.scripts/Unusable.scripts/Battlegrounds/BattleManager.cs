using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.ExternalScripts.Battlegrounds
{
	[PacketHandlerClass]
	internal class BattleManager
	{
		public static int[] BattleFieldInfo = {
		                                      	0,
		                                      	30, // Alterac Valley
		                                      	489, // Warsong Gulch
		                                      	529, // Arathi Basin
		                                      	559, // Nagrand Arena
		                                      	562, // Blade's Edge Arena
		                                      	559, // 559,562 - All Arenas
		                                      	566 // Eye of the Storm
		                                      };


		//  we can`t split same map instances  for different groups , and we can have only one Battleground per map.
		//  Later it can be expanded.
		public static WarsongGulch m_pWarsongInstance = new WarsongGulch();
		//private static WarsongGulch m_pWarsongInstance;


		// List of available BGs
		private static CustomArrayList m_pAvailableBG = new CustomArrayList();

		//  Not implemented
		//private static ArathiBasin m_pArathiInstance	= new ArathiBasin();
		//private static AlteracValley m_pAlteracInstance = new AlteracValley();

		public static int GetPlayerBG(PlayerObject player)
		{
			foreach (Battleground bg in m_pAvailableBG)
			{
				BGPlayer bp = bg.GetPlayer(player);
				if (bp != null)
					return (int) bg.WorldMapID;
			}
			return -1;
		}

		internal static bool IsDeserter(PlayerObject player)
		{
			if (player.Group != null)
			{
				foreach (PlayerObject pmember in player.Group.LivingMembers)
				{
					// 26013 - Deserter aura
					if (pmember.Auras.GetAura(26013) != -1)
						return true;
				}
			}
			else
			{
				if (player.Auras.GetAura(26013) != -1)
					return true;
			}
			return false;
		}

		[PacketHandler(CMSG.BATTLEFIELD_LIST)]
		public static void BattleList(ClientBase client, BinReader data)
		{
			ulong GUID = data.ReadUInt64();

			PlayerObject player = ((ClientData) client.Data).Player;

			/*
			if (Constants.BurningCrusade)
			{
				BinWriter writer = new BinWriter();
				writer.Write(GUID);
				writer.Write(6);
				writer.Write(1);
				BinReader reader = new BinReader(writer.GetBuffer());
				Join1(client, reader);
				return;
			}
			*/

			//  If player or any group member marked as Deserter we should reject join
			if (IsDeserter(player))
			{
				ShortPacket pckReject = new ShortPacket(SMSG.BATTLEFIELD_REJECT);
				pckReject.Write(0xFFFFFFFE);
				client.Send(pckReject);
				return;
			}

			ShortPacket pck = new ShortPacket(SMSG.BATTLEFIELD_LIST);
			pck.Write(GUID);
			if (Constants.BurningCrusade)
			{
				pck.Write(2); // battle field id, 1 - alterac , 2 - warsong, 3 - arathi, 4 - arena, 
				pck.Write((byte) 1);
				pck.Write(1);
				pck.Write(1);
			}
			else
			{
				pck.Write(489); // World Map ID   // TODO: get from BG
				pck.Write((byte) 1); // ???? bg type id 
				pck.Write(1);
				pck.Write(1);
			}
			client.Send(pck);
		}

		[PacketHandler(CMSG.BATTLEFIELD_JOIN)]
		public static void Join(ClientBase client, BinReader data)
		{
			ulong GUID = data.ReadUInt64();
			//Packet SMSG.(null) (793), len: 10
			//0000: 19 03 07 10 51 d0 17 00 00 00		 
		}


		[PacketHandler(CMSG.BATTLEGROUND_LEAVE)]
		public static void LeaveOnFinish(ClientBase client, BinReader data)
		{
			// Leave BG code
			//uint mapID = data.ReadUInt32();
			byte unk0 = data.ReadByte();
			byte bgNum = data.ReadByte();
			byte bgType = data.ReadByte();
			
			foreach (Battleground bg in m_pAvailableBG)
			{
				if (bg.NumberID == bgNum && (int)bg.Type + 2 == bgType)
				{
					PlayerObject player = ((ClientData) client.Data).Player;
					bg.LeavePlayer(player);
				}
			}
		}

		[PacketHandler(CMSG.BATTLEFIELD_LEAVE)]
		public static void Leave(ClientBase client, BinReader data)
		{
			// Leave BG code
			//uint mapID = data.ReadUInt32();
			byte unk0   = data.ReadByte();
			byte bgNum = data.ReadByte();
			byte bgType = data.ReadByte();
			

			byte unk4 = data.ReadByte();
			byte unk5 = data.ReadByte(); 
			byte unk1 = data.ReadByte();
			ushort bgGuid = data.ReadUInt16();
			byte lType = data.ReadByte(); //  0 - Leave BG, 1 - Leave queue - enter to BG

			PlayerObject player = ((ClientData) client.Data).Player;

			foreach (Battleground bg in m_pAvailableBG)
			{
				if (bg.NumberID == bgNum && (int)bg.Type + 2 == bgType )
				{
					BGPlayer bPlayer = bg.GetPlayer(player);
					if (bPlayer != null && bPlayer.Status != QUEUE_STATUS.NOT_IN_QUEUE)
						bg.LeavePlayer(player);

					if (lType == 1)
					{
						// enter to BG as active player
						bg.JoinPlayer(player, true);

						ShortPacket pckg1 = new ShortPacket(SMSG.BATTLEGROUND_PLAYER_JOINED);
						pckg1.Write(player.GUID);
						client.Send(pckg1);
					}
				}
			}

			// Update BG status
			Status(client, data);
		}


		[PacketHandler(CMSG.BATTLEFIELD_JOIN_NEW)]
		public static void Join1(ClientBase client, BinReader data)
		{
			ulong GUID = data.ReadUInt64();

			uint mapID = data.ReadUInt32();
			uint bgID = data.ReadUInt32();

			PlayerObject player = ((ClientData) client.Data).Player;

			if (player.Level < 30)
			{
				Chat.System(client, "Only 30+ players allowed on Warsong BG for testing purpose.");
				return;
			}

			/*
			if (Constants.BurningCrusade)
			{
				foreach (Battleground bg in m_pAvailableBG)
				{
					bg.JoinPlayer(player, false);
					break;
				}
				Status(client, data);
				Chat.System(client, "You have been added to battleground queue");
				return;
			}
			*/

			foreach (Battleground bg in m_pAvailableBG)
			{
				if ( bg.WorldMapID == BattleFieldInfo[mapID] && bg.NumberID == bgID )
				{
					// join player to wait queue
					bg.JoinPlayer(player, false);
				}
			}
			// Update BG status
			Status(client, data);
		}

		public static bool IsAlliance(FACTION faction)
		{
			return
				faction == FACTION.HUMAN || faction == FACTION.GNOME || faction == FACTION.NIGHTELF || faction == FACTION.DWARF;
		}

		public static bool IsHorde(FACTION faction)
		{
			return !IsAlliance(faction);
		}

		[PacketHandler(CMSG.BATTLEFIELD_POSITION)]
		public static void PositionResponse(ClientBase client, BinReader data)
		{
			PlayerObject player = ((ClientData) client.Data).Player;
			foreach (Battleground bg in m_pAvailableBG)
			{
				if (bg.GetPlayer(player) != null)
				{
					try
					{
						ShortPacket pposa = new ShortPacket(SMSG.BATTLEFIELD_POSITION_RESPONSE);
						pposa.Write(0);

						PlayerObject pFlagHolderH = null;
						PlayerObject pFlagHolderA = null;
						int displayCount = 0;

						foreach (BGPlayer plyr in bg.Queue.ActivePlayers)
						{
							if (plyr.Player.Auras.HasAura(23333))
								pFlagHolderH = plyr.Player;
							else if (plyr.Player.Auras.HasAura(23335))
								pFlagHolderA = plyr.Player;
							else if (Faction.SameFaction(player.Faction, plyr.Faction) && player != plyr.Player)
							{
								pposa.Write(plyr.Player.GUID);
								pposa.Write(plyr.Player.Position.X);
								pposa.Write(plyr.Player.Position.Y);
								displayCount++;
							}
						}


						//pposa.Write(flagsCount);


						if (IsAlliance(player.Faction))
						{
							if (pFlagHolderH != null)
							{
								pposa.Write((byte) 1);
								pposa.Write(pFlagHolderH.GUID);
								pposa.Write(pFlagHolderH.Position.X);
								pposa.Write(pFlagHolderH.Position.Y);
							}
							else
								pposa.Write((byte) 0);
						}
						else
						{
							if (pFlagHolderA != null)
							{
								pposa.Write((byte) 1);
								pposa.Write(pFlagHolderA.GUID);
								pposa.Write(pFlagHolderA.Position.X);
								pposa.Write(pFlagHolderA.Position.Y);
							}
							else
								pposa.Write((byte) 0);
						}

						pposa.Set(4, displayCount);
						client.Send(pposa);


						/*
						if (BattleManager.IsAlliance(player.Faction))
						{
							ShortPacket pposa = new ShortPacket(SMSG.BATTLEFIELD_POSITION_RESPONSE);
							pposa.Write(bg.Queue.ActiveAllianceCount);

							PlayerObject pFlagHolderH = null;
							PlayerObject pFlagHolderA = null;
							foreach (BGPlayer plyr in bg.Queue.ActivePlayers)
							{
								if (BattleManager.IsAlliance(player.Faction))
								{
									if (plyr.Player.Auras.HasAura(23333))
										pFlagHolderH = plyr.Player;
									if (plyr.Player.Auras.HasAura(23335))
										pFlagHolderA = plyr.Player;
									pposa.Write(plyr.Player.GUID);
									pposa.Write(plyr.Player.Position.X);
									pposa.Write(plyr.Player.Position.Y);
								} else
								{
								}
							}

							if (pFlagHolderH != null && pFlagHolderA != null )
							{
								pposa.Write((byte)2);
								pposa.Write(pFlagHolderH.GUID);
								pposa.Write(pFlagHolderH.Position.X);
								pposa.Write(pFlagHolderH.Position.Y);
								
								pposa.Write(pFlagHolderA.GUID);
								pposa.Write(pFlagHolderA.Position.X);
								pposa.Write(pFlagHolderA.Position.Y);
							}

							
							if ( pFlagHolderH == null && pFlagHolderA == null )
								pposa.Write((byte)0);
							client.Send(pposa);
						} else {
							ShortPacket pposh = new ShortPacket(SMSG.BATTLEFIELD_POSITION_RESPONSE);
							pposh.Write(bg.Queue.ActiveHordeCount);

							foreach (BGPlayer plyr in bg.Queue.ActivePlayers)
							{
								if (BattleManager.IsHorde(player.Faction))
								{
									pposh.Write(plyr.Player.GUID);
									pposh.Write(plyr.Player.Position.X);
									pposh.Write(plyr.Player.Position.Y);
								}
							}
							pposh.Write((byte)0);
							client.Send(pposh);
						}
						*/

						break;
					}
					catch (Exception e)
					{
						Console.WriteLine("BattleManager:PositionResponse" + e);
					}
				}
			}
		}

		[PacketHandler(CMSG.BATTLEFIELD_STATISTIC)]
		public static void StatisticResponse(ClientBase client, BinReader data)
		{
			PlayerObject player = ((ClientData) client.Data).Player;
			foreach (Battleground bg in m_pAvailableBG)
			{
				if (player != null && bg.GetPlayer(player) != null)
				{
					lock (player) // TODO: Hmm
					{
						ShortPacket pstat = new ShortPacket(SMSG.BATTLEFIELD_STATISTIC_RESPONSE);
						if (bg.GameStatus() == BG_STATUS.FINISH)
						{
							pstat.Write((byte)0); //  Game finished - have winner
							pstat.Write((byte)1); //  Game finished - have winner
							//pstat.Write((byte)(bg.WinnerSide + 0)); // winnerside  (byte)   0 - horde , 1 - alliance
						}
						else
						{
							pstat.Write((byte) 0); // in game (byte)
						}

						pstat.Write( bg.GameStatus() == BG_STATUS.FINISH ? (byte)bg.WinnerSide: (byte)0);  // new

						pstat.Write(bg.Queue.ActivePlayers.Count);

						foreach (BGPlayer plyr in bg.Queue.ActivePlayers)
						{
							pstat.Write(plyr.Player.GUID);
							pstat.Write(plyr.KillingBlows ); // KillingBlows
							pstat.Write(plyr.HonorKills ); // Kills
							pstat.Write(plyr.Deaths ); // Death
							pstat.Write(plyr.GetHonorBonus(bg) ); // Bonus honor / 10
							pstat.Write(1001); // DamageDone
							pstat.Write(2001); // HealingDone
							pstat.Write(200); // ??
							//pstat.Write(plyr.FlagsCaptured+1); //   Flags captured 
							//pstat.Write(plyr.FlagsReturned+2); //	 Flags returns
							pstat.Write(5); //	 Flags returns
							pstat.Write(5); //	 Flags returns
						}
						client.Send(pstat);
					}
					break;
				}
			}
		}

		/* Should be invoked when need show stat screen to player (usualy when BG is over.)
         */

		internal static void SendStatisticUpdate(Battleground bg)
		{
			foreach (BGPlayer plyr in bg.Queue.ActivePlayers)
				StatisticResponse(plyr.Player.BackLink.Client, null);
		}


		[PacketHandler(CMSG.BATTLEFIELD_STATUS)]
		public static void Status(ClientBase client, BinReader data)
		{
			PlayerObject player = ((ClientData) client.Data).Player;

			foreach (Battleground bg in m_pAvailableBG)
			{
				ShortPacket pck1 = new ShortPacket(SMSG.BATTLEFIELD_STATUS_RESPONSE);
				pck1.Aquire();
				pck1.Write((int) bg.Type);
				BGPlayer bPlayer = bg.GetPlayer(player);
				if (bPlayer != null && bPlayer.Status != QUEUE_STATUS.NOT_IN_QUEUE)
				{
					int status = (int) bPlayer.Status;

					if (Constants.BurningCrusade)
					{
						pck1.Write((byte)0); 
						pck1.Write((byte)1); 
						pck1.Write(2);
						pck1.Write((ushort)0xAAAA);  // BG unique ID
						pck1.Write(0);
						pck1.Write((byte)0);
						pck1.Write(status);
						//pck1.Write(bg.WorldNumberID);
					}
					else
					{
						pck1.Write(bg.WorldMapID);
						pck1.Write((byte) 2); //?  started/finished??
						pck1.Write(bg.NumberID);
						pck1.Write(status); // join status -  1 - in queue, > 1 - already in BG
						//pck1.Write( );	// average time in msec..
					}
					int time = 0;
					int wtime = 0;
					switch (bPlayer.Status)
					{
						case QUEUE_STATUS.INVITED:
							pck1.Write((int) BGConstants.WAIT_INVITE_TIME);
							break;
						case QUEUE_STATUS.WAIT_IN_QUEUE:
							pck1.Write(bg.Queue.AverageTime());
							wtime = (int) (new TimeSpan(CustomDateTime.Now.Ticks - bPlayer.JoinTime.Ticks).TotalMilliseconds);
							pck1.Write(wtime);
							break;
						case QUEUE_STATUS.IN_ACTION:
							time = (int) (bg.GameStatus() == BG_STATUS.FINISH
							              	?
							              120000 - (CustomDateTime.Now - bg.FinishTime).TotalMilliseconds
							              	: 0);
							wtime = (int) (CustomDateTime.Now - bg.StartTime).TotalMilliseconds;
							pck1.Write(time);
							pck1.Write(wtime);
							break;
					}
					client.Send(pck1);
				}
				else
				{
					pck1.Write(0);
					pck1.Write(0);
				}
				client.Send(pck1);
				pck1.Release();
			}
		}

		internal static void UpdateStatusAll(Battleground bg)
		{
			foreach (BGPlayer plyr in bg.Queue.ActivePlayers)
				Status(plyr.Player.BackLink.Client, null);
		}


		public static void SendUpdateWorldState(ClientBase client, WORLD_UPDATE_INDEX idx,
		                                        WORLD_STATE_CATEGORIES category, short value)
		{
			ShortPacket pckg = new ShortPacket(SMSG.UPDATE_WORLD_STATE);
			if (Constants.BurningCrusade)
			{
				pckg.Write((byte) idx);
				pckg.Write((byte) category);
				pckg.Write((short)0);
				pckg.Write((int) value);
				client.Send(pckg);
			}
			else
			{
				pckg.Write((byte) idx);
				pckg.Write((byte) category);
				pckg.Write((short) value);
				client.Send(pckg);
			}
		}

		public static void SendInitWorldState(ClientBase client, uint mapId, uint zoneId, WORLD_UPDATE_INDEX[] idx,
		                                      WORLD_STATE_CATEGORIES[] category, short[] value)
		{
			ShortPacket pckg = new ShortPacket(SMSG.INIT_WORLD_STATES);
			pckg.Write(mapId);
			pckg.Write(zoneId);
			pckg.Write((short)idx.Length);

			for (int i = 0; i < idx.Length; i++)
			{
				if (Constants.BurningCrusade)
				{
					pckg.Write((byte) idx[i]);
					pckg.Write((byte) category[i]);
					pckg.Write((short)0);
					pckg.Write((int) value[i]);
				}
				else
				{
					pckg.Write((byte) idx[i]);
					pckg.Write((byte) category[i]);
					pckg.Write((short) value[i]);
				}
			}


			client.Send(pckg);
		}

		public static void SendInitWorldStateToAll(Battleground bg, WORLD_UPDATE_INDEX[] idx,
		                                           WORLD_STATE_CATEGORIES[] category, short[] value)
		{
			foreach (BGPlayer bPlayer in bg.Queue.ActivePlayers)
				SendInitWorldState(bPlayer.Player.BackLink.Client, bg.WorldMapID, bg.ZoneID, idx, category, value);
		}

		public static void SendUpdateWorldStateToAll(Battleground bg, WORLD_UPDATE_INDEX idx,
		                                             WORLD_STATE_CATEGORIES category, short value)
		{
			foreach (BGPlayer bPlayer in bg.Queue.ActivePlayers)
				SendUpdateWorldState(bPlayer.Player.BackLink.Client, idx, category, value);
		}


		internal static bool EnterTrigger(DBAreaTrigger trigger, PlayerObject player)
		{
			bool canPort = true;
			foreach (Battleground bg in m_pAvailableBG)
			{
				bool ret = bg.EnterTrigger(trigger, player);
				canPort = !ret ? false : canPort;
			}
			return canPort;
		}

		internal static void CancelAura(uint Spell, LivingObject m_unit)
		{
			foreach (Battleground bg in m_pAvailableBG)
				bg.CancelAura(Spell, m_unit);
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			m_pAvailableBG.Add(m_pWarsongInstance); // Temporarry disabled
		}
	}
}