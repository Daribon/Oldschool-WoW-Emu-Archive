using System;
using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class SummonNPCSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte effect, ref SpellFinishHandler Linked)
		{
			int num = spell.Effect[effect].AuraParam;
			if (num == 0)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			
			if (caster is IOwnedUnit)
				return SpellFailedReason.SPELL_FAILED_ERROR; // block summon from summons

			DBCreature creature = (DBCreature) Database.Instance.FindObjectByKey(typeof (DBCreature), num);
			if (creature == null)
			{
				LogConsole.WriteLine(LogLevel.SYSTEM, "Summoned creature without template: " + num);
				return SpellFailedReason.SPELL_FAILED_ERROR;
			}

			Vector pos = new Vector(caster.Position.X + (float) Math.Cos(caster.Facing)*2, caster.Position.Y + (float) Math.Sin(caster.Facing)*2, caster.Position.Z);

			UnitBase unit = null;
			switch (spell.Effect[effect].Type)
			{
				case SPELLEFFECT.SUMMON_GUARDIAN:
					LivingObject lcaster = caster as LivingObject;

					if (lcaster == null)
						return SpellFailedReason.SPELL_FAILED_ERROR;

					if (lcaster.Guard != null && lcaster.Guard.AsLiving != null && lcaster.Guard.AsLiving.Entry == creature.Entry)
						return SpellFailedReason.SPELL_FAILED_DONT_REPORT;
						
					unit = new UnitGuard( creature, pos, caster.Facing, lcaster, spell.Duration );
					break;
				case SPELLEFFECT.SUMMON_WILD:
				default:
					if (spell.ObjectId == 12168)
						return SpellFailedReason.SPELL_FAILED_DONT_REPORT;
					
					unit = new MonsterBase(creature, pos, caster.Facing, creature.Defaults.BehaivorId == 8);
					break;
			}
			caster.MapTile.Map.Enter(unit);

			if (spell.Duration > 0)
				unit.MapTile.Map.AddDespawn(unit, spell.Duration / 1000);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_WILD, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_GUARDIAN, new SpellCastOnLiving(Cast));
		}
	}
}