using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class UnstuckSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect,
		                                     ref SpellFinishHandler Linked)
		{
			PlayerObject Player = target as PlayerObject;
			if (Player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			if (Player.Character.WorldMapID == 13 || Player.Character.WorldMapID == 29)
			{
				Chat.System(Player.BackLink.Client, "You cannot escape from the prison!");
				return SpellFailedReason.MAX;
			}

			if (!Player.Dead)
				Player.Dead = true;

			if (!Player.Ghost)
				Player.ReleaseSpirit();
			
			Player.TeleportToHealer();

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.STUCK, new SpellCastOnLiving(Cast));
		}
	}
}