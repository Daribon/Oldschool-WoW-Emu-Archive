using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunWoW.Vendors;

namespace RunWoW.Spells
{
	public class GOOpen
	{
		public static SpellFailedReason Cast(ObjectBase caster, GameObject target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect, ref SpellFinishHandler linked)
		{
			PlayerObject player = caster as PlayerObject;
			if (player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			
			GameObject GO = target;
			if (GO == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			
			LogConsole.WriteLine(LogLevel.ECHO, "Player " + player.Name + " is looting GO " + GO.Name);

			/*if (GO.Loot==null||GO.Loot.Count==0) // empty
				return SpellFailedReason.SPELL_FAILED_CHEST_IN_USE;*/

			if (spell.TempSkill == null || spell.TempSkill.MaxLevel == 1)
			{
				//return SpellFailedReason.SPELL_FAILED_CHEST_IN_USE;
			}
			else
			{
				PlayerSkill skill = player.Skills[(SKILL)spell.TempSkill.SkillID];
				if (skill == null)
					return SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT;
				
				int slevel = skill.Level + skill.Bonus;
				int gLevel = GO.Level;
				DBLock dlock = (DBLock)Database.Instance.FindObjectByKey(typeof(DBLock), GO.Template.Sound[0]);
				if (dlock != null && dlock.Level[1] > 0)
					gLevel = dlock.Level[1] / 5;
				

				if ((slevel < 50 && gLevel > 10) || (slevel > 50 && slevel < gLevel*5))
					return SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT;

				if (Utility.Chance((slevel - (gLevel - 5) * 5f) / 50f)) //raises from 50% to 100% in 25 skill steps
				{
					if (
						GO.Openers[player.GUID] == null &&
						Utility.Chance(slevel < 25 ? 1f : ((gLevel + 10)*5f - slevel)/50f) // falls from 100% to 0% in 50 skill steps
						)
					{
						player.RaiseSkill(skill);
						player.UpdateData();
					}
				}
				else
					return SpellFailedReason.SPELL_FAILED_TRY_AGAIN;
			}

			if (GO.DBGameObject.QuestID != 0)
			{
				if (GO.DBGameObject.EndQuests == null || GO.DBGameObject.StartQuests == null)
					Database.Instance.ResolveRelations(GO.DBGameObject, typeof (DBQuest));

				ICollection<DBQuestLog> qLog = PlayerQuests.GetEndQuestsForPlayer(player, GO.DBGameObject.EndQuests);
				if (qLog != null && qLog.Count > 0)
				{
					foreach (DBQuestLog ql in qLog)
						Quester.SendReward(player.BackLink.Client, GO.GUID, ql.Quest);

					return SpellFailedReason.MAX;
				}

				PooledList<DBQuest> quests;
				if (GO.DBGameObject.StartQuests.Count > 0 &&
				    PlayerQuests.CheckPlayerQuests(player, GO.DBGameObject.StartQuests, out quests) == QuestStatus.Available)
				{
					foreach (DBQuest quest in quests)
					{
						BinWriter tmp = new BinWriter();
						tmp.Write(GO.GUID);
						tmp.Write(quest.ObjectId);
						tmp.Position = 0;
						BinReader read = new BinReader(tmp);
						Quester.QuestDetails(player.BackLink.Client, read);
					}
					//Chat.System(client, "Available quests for this GO " + quests.Length); 
					return SpellFailedReason.MAX;
				}
			}

			if (GO.TypeID == (int)GameObjectType.Goober)  // used in some quests for "killing" GO
			{
				//DBQuestLog[] pQuests = Player.Quests.Fields;
				foreach (PlayerQuest pq in player.Quests.Fields)
				{
					if (pq != null && pq.QuestLog != null )
					{
						if (pq.QuestLog.Quest.Flags == 8)  //  quests for Killing / Slaying
						{
							for(int i=0;i<pq.QuestLog.Quest.Target.Length;i++)
								if (pq.QuestLog.Quest.Target[i].Type == 1 && pq.QuestLog.Quest.Target[i].ID == GO.Template.ObjectId)
									player.Quests.CheckSlain(pq.QuestID, (long)GO.GUID);
						}
					}
				}
			}
			
			GO.Opened(player);

			if (GO.Loot == null)
				GO.GenerateLoot();

			//linked = new SpellFinishHandler(Loot.DoOpenLoot);
			linked = new SpellFinishHandler(RunWoW.GamePackets.Loot.DoOpenLoot);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.OPEN_LOCK, new SpellCastOnObject(Cast));
		}
	}
}