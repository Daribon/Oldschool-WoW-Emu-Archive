using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class DismissPet
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject player = caster as PlayerObject;
			if (player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			PetBase pet = player.Pet;
			if (pet == null)
				return SpellFailedReason.SPELL_FAILED_NO_PET;

			pet.Die();
			pet.Dispose();

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DISMISS_PET, new SpellCastOnLiving(Cast));
		}
	}
}
