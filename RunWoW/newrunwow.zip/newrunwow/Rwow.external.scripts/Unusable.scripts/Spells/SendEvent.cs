using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells
{
	public class SendEvent
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			int auraParam = m_spell.Effect[effect].AuraParam;
			switch (auraParam)
			{
				case 1788: // calls sucubbus
				case 1786:
				case 1134:
				case 1131: // calls voidwalker
				case 1785:
				case 1787:

					PlayerObject player = caster as PlayerObject;
					if (player == null)
						return SpellFailedReason.MAX;

					GameObject circle;

					if (!GamePackets.Spells.NearGO(player, 8, m_spell.SpellFocus, Constants.CraftRange, out circle))
						return SpellFailedReason.SPELL_FAILED_NOT_HERE;

					int creatureID = (auraParam == 1788 || auraParam == 1786 || auraParam == 1134) ? 5677 : 5676;

					DBCreature creature = (DBCreature) Database.Instance.FindObjectByKey(typeof (DBCreature), creatureID);

					UnitBase newUnit = new UnitBase(creature, caster.Level, circle.Position, caster.Facing, 0, 0, (FACTION) 168);

					caster.MapTile.Map.Enter(newUnit);
					break;
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SEND_EVENT, new SpellCastOnLiving(Cast));
		}
	}
}