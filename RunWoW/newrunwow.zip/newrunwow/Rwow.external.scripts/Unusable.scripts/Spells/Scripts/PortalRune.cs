using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells.Scripts
{
	// this spell is not part of World of Warcraft game =)
	public class PortalRune
	{
		private const uint UnmarkedRuneId = 50000;
		private const uint MarkedRuneId = 50001;

		private const uint PortalId = 2000000;

		private const uint RuneSpellId = 25158;

		private static DBItemTemplate MarkedTemplate =
			(DBItemTemplate) Database.Instance.FindObjectByKey(typeof (DBItemTemplate), MarkedRuneId);

		private static DBGOTemplate PortalTemplate =
			(DBGOTemplate) Database.Instance.FindObjectByKey(typeof (DBGOTemplate), PortalId);


		public static SpellFailedReason RuneCast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
		                                         byte effect, ref SpellFinishHandler Linked)
		{

			PlayerObject owner = caster as PlayerObject;
			if (owner == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			ItemObject item = owner.Inventory.FindItem(owner.LastItemCast);

			if (item == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			DBPoint point = null;

			if (item.Enchantments[0].Charges > 0)
				point = (DBPoint) Database.Instance.FindObjectByKey(typeof (DBPoint), item.Enchantments[0].Charges);

			switch (item.Template.ObjectId)
			{
				case UnmarkedRuneId:
					if (point == null)
						point = new DBPoint();

					point.Position = owner.Position;
					point.WorldMapID = owner.WorldMapID;

					if (point.New)
						DBManager.NewDBObject(point);
					else
						DBManager.SaveDBObject(point);

					item.ContainedIn.RemoveItem(item.DBItem.OwnerSlot, false);

					DBItem newItem = new DBItem(MarkedTemplate);
					newItem.Enchantments[0].Charges = (int) point.ObjectId;
					newItem.Enchantments[0].Expires = (int) owner.MapTile.Map.InstanceID;
					owner.AddItem(newItem);
					break;
				case MarkedRuneId:
					if (point == null)
						break;

					DBGameObject obj = new DBGameObject();
					obj.Position = owner.Position;
					obj.TemplateID = PortalId;
					obj.Template = PortalTemplate;
					obj.Facing = owner.Facing;
					obj.WorldMapID = owner.WorldMapID;

					GameObject go = new GameObject(obj, 60000, owner.MapTile.Map);
					go.Creator = owner.GUID;
					go.Faction = owner.Faction;
					go.PortalTarget = point.Position.Clone();
					go.PortalWorld = point.WorldMapID;
					go.PortalInstance = (uint) item.Enchantments[0].Expires;

					break;
			}

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, RuneSpellId, new ScriptSpellCast(RuneCast));
			SpellManager.RegisterTargetPatch(RuneSpellId, TARGET.TARGET_SELF);
		}
	}
}