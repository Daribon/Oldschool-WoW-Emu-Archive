using System;
using System.Collections.Generic;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class WeaponDamageP
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte effect, ref SpellFinishHandler Linked)
		{
			/*if (caster == target || (target is PetBase && ((PetBase)target).Owner == caster) || target.Dead)
				return SpellFailedReason.MAX;*/

			LivingObject lcaster = caster as LivingObject;

			if (lcaster == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			PlayerObject player = caster as PlayerObject;

			int mindamage = spell.Effect[effect].Damage;
			int maxdamage = spell.Effect[effect].Value;

			if (player != null)
				if (spell.Effect[effect].Combo != 0 && player.ComboPoints > 0)
				{
					if (player.ComboTarget != target.GUID)
					{
						player.ComboTarget = 0;
						player.ComboPoints = 0;
					}
					mindamage += (int)(spell.Effect[effect].Combo * player.ComboPoints);
					maxdamage += (int)(spell.Effect[effect].Combo * player.ComboPoints);

					player.ComboPoints = 0;
					player.ComboTarget = 0;
					player.UpdateData();
				}

			if (spell.Category == 8388612 /*&& spell.Flags[2] & 1048576 != 0*/) // 0x800004 - Stab category , 1048576 - Behind
			{
				if (caster is LivingObject)
				{
					LivingObject livCaster = (LivingObject)caster;

					bool inBack = false;
					if (livCaster.Position.InFront(livCaster.Facing, target.Position))
					{
						double tFacing = target.Facing < 0 ? 2 * Math.PI + target.Facing : target.Facing;
						double cFacing = livCaster.Facing < 0 ? 2 * Math.PI + livCaster.Facing : livCaster.Facing;
						if (Math.Abs((cFacing - tFacing)) < 2) // ~ 120 degress in back of target
						{
							mindamage = (int)(lcaster.MinDamage * 1.5);  // 150% damage
							maxdamage = (int)(lcaster.MaxDamage * 1.5);
							inBack = true;
						}
					}
					if (!inBack)
						return SpellFailedReason.SPELL_FAILED_NOT_BEHIND;
				}
			}

			lcaster.LastHit = CustomDateTime.Now;

			if (spell.Ranged && player != null)
			{
				if (player.HasRangedAmmo())
				{
					player.ConsumeRangedAmmo();
					
					/// TODO: We should process different damage types for ranged shoots
					DAMAGETYPE damageType = spell.ObjectId == 5019 ? DAMAGETYPE.MAX : spell.School;

					player.SubmitRangedDamage(target, spell, damageType, mindamage, maxdamage);
					
					if ((spell.Flags[2] & 32) == 32)
						Linked = new SpellFinishHandler(StartAutoShot);
					
					player.AddRangedDelay();
				}
				else
					return SpellFailedReason.SPELL_FAILED_NO_AMMO;
			}
			else
			{
				if ((spell.Flags[2] & 4096) == 4096)
				{
					ICollection<ObjectBase> enemies = SpellManager.GetLivingTargets(caster.MapTile, caster.Position, 5/* spell.Effect[effect].Radius*/, true, caster, false, false, spell.CreatureType);

					int count = 0;
					foreach (LivingObject enemy in enemies)
						if (enemy.Attackable && !enemy.IsDisposed)
						{
							lcaster.SubmitMeleeDamage(enemy, spell, spell.School, mindamage, maxdamage, spell.Effect[effect].Type == SPELLEFFECT.INSTANT_WDAMAGE);
							count++;
							if (count == spell.Effect[effect].NumTargets)
								break;
						}
				} else
					lcaster.SubmitMeleeDamage(target, spell, spell.School, mindamage, maxdamage, spell.Effect[effect].Type == SPELLEFFECT.INSTANT_WDAMAGE);
				
			}
			return SpellFailedReason.MAX;
		}

		public static void StartAutoShot(ObjectBase caster, ObjectBase target, DBSpell spell)
		{
			if (caster is PlayerObject && target is LivingObject)
			{
				int time = ((PlayerObject)caster).RangedAttackTime;
				if (time < 1200)
					time = 1200;
				AutoShot autoShot = new AutoShot((PlayerObject)caster, spell, (LivingObject)target, time);
				autoShot.Start();
			}
		}

		public class AutoShot : Event
		{
			private PlayerObject m_player;
			private LivingObject m_target;
			private DBSpell m_spell;
			private Vector m_position;

			public AutoShot(PlayerObject player, DBSpell spell, LivingObject target, int time)
				: base(TimeSpan.FromMilliseconds(time))
			{
				m_player = player;
				m_player.CastEvent = this;
				m_position = player.Position.Clone();
				m_target = target;
				m_spell = spell;
			}

			protected override void OnTick()
			{
				if (m_player != null && !m_player.IsDisposed)
				{
					if (!m_player.Attacking && !m_target.IsDisposed && m_target.Attackable && m_position.DistanceAvr(m_player.Position) < 0.1f)
					{
						if (m_player.StandState != UNITSTANDSTATE.STANDING)
						{
							SpellCastEvent.SpellCastResult(m_player.BackLink.Client, m_spell.SpellID,
							                               SpellFailedReason.SPELL_FAILED_INTERRUPTED);
							return;
						}

						if (m_player.Position.DistanceFlat(m_target.Position) > m_player.CombatReach + m_target.BoundingRadius &&
						    !m_player.Position.InFront(m_player.Facing, m_target.Position))
						{
							SpellCastEvent.SpellCastResult(m_player.BackLink.Client, m_spell.SpellID,
							                               SpellFailedReason.SPELL_FAILED_UNIT_NOT_INFRONT);
							return;
						}

						m_player.CastEvent = new SingleTargetCast(m_player, m_spell, 0x2, m_target, false);
						m_player.CastEvent.Start();
					} else
						SpellCastEvent.SpellCastResult(m_player.BackLink.Client, m_spell.SpellID,
													   SpellFailedReason.SPELL_FAILED_DONT_REPORT);
				}
			}
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.WEAPON_DAMAGEP, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.WEAPON_DAMAGEP1, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.INSTANT_WDAMAGE, new SpellCastOnLiving(Cast));
		}
	}
}