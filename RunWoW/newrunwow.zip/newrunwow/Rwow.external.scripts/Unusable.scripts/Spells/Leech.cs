using System.Collections.Generic;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class Leech
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			LivingObject lcaster = caster as LivingObject;
			bool manaDrain = m_spell.Effect[effect].Type == SPELLEFFECT.MANA_DRAIN;
			int value = lcaster != null
			            	?
			            lcaster.SpellProcessor.FullDamage(m_spell, effect)
			            	:
			            m_spell.Effect[effect].Damage + m_spell.Effect[effect].RandomDamage;

			if (manaDrain)
			{
				if (lcaster != null && target != null)
				{
					if ((int) target.PowerType != (int) lcaster.PowerType)
						return SpellFailedReason.SPELL_FAILED_ERROR;

					if (target.Power - value < 0)
						value = value - target.Power;
					target.Power -= value;

					// now calc real value for drain power
					value = (int) (value*m_spell.Effect[effect].Percent);

					lcaster.Power += value;
					lcaster.Power = lcaster.Power < 0 ? 0 : lcaster.Power;
					lcaster.Power = lcaster.Power > lcaster.MaxPower ? lcaster.MaxPower : lcaster.Power;
				}
			}
			else
			{
				if (lcaster != null)
				{
					lcaster.SubmitMagicDamage(target, m_spell, m_spell.School, value, value);

					// now calc real value for heal
					value = (int) (value*m_spell.Effect[effect].Percent);
					lcaster.Health += value;
					lcaster.Health = lcaster.Health > lcaster.MaxHealth ? lcaster.MaxHealth : lcaster.Health;
				}
			}

			if (lcaster != null)
			{
				target.Attacked(lcaster);

				ICollection<LivingObject> toAttack = lcaster.Attackers.Values;
				foreach (LivingObject attacker in toAttack)
					attacker.AddThreat(lcaster, value/2, value); // add aggro for leached health
			}

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.HEALTH_LEECH, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.MANA_DRAIN, new SpellCastOnLiving(Cast));
		}
	}
}