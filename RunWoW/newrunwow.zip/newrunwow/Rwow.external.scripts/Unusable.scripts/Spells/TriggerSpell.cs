using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells
{
	public class TriggerSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect,
		                                     ref SpellFinishHandler Linked)
		{
			DBSpell targetSpell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spell.Effect[effect].Spell);
			if (targetSpell == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Trigger spell not found " + spell.Effect[effect].Spell);
				return SpellFailedReason.SPELL_FAILED_UNKNOWN;
			}

			float dist = caster.Position.Distance(target.Position);
			if (dist > spell.MaxRange)
				return SpellFailedReason.SPELL_FAILED_OUT_OF_RANGE;
			else if (dist < spell.MinRange)
				return SpellFailedReason.SPELL_FAILED_TOO_CLOSE;

			SpellManager.Cast(caster, target, targetSpell);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.TRIGGER_SPELL, new SpellCastOnLiving(Cast));
		}
	}
}