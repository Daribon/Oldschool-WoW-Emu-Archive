//
using System;
using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class SummonPetSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject Player = caster as PlayerObject;
			if (Player == null || Player.MapTile == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			int creatureId = m_spell.Effect[effect].AuraParam;
			if (creatureId == 0)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			DBCreature creature = (DBCreature) Database.Instance.FindObjectByKey(typeof (DBCreature), creatureId);
			if (creature == null)
			{
				LogConsole.WriteLine(LogLevel.SYSTEM, "Summoned creature without template: " + creatureId);
				return SpellFailedReason.SPELL_FAILED_ERROR;
			}
			if (Player.Pet != null && !Player.Pet.Dead)
			{
				//return SpellFailedReason.SPELL_FAILED_TOO_MANY_OF_ITEM;				
				Player.Pet.Dispose();
				Player.Pet = null;
			}
			Vector pos = new Vector(Player.Position.X + (float) Math.Cos(Player.Facing)*2, Player.Position.Y + (float) Math.Sin(Player.Facing)*2, Player.Position.Z);
			PetBase pet = null;

			DBPet dbpet = null;
			foreach (DBPet dbPet in Player.Character.PetList)
				if (dbPet.CreatureID == creatureId)
				{
					dbpet = dbPet;
					break;
				}

			bool fixedLevel = creature.CreatureType == 3;
				
			
			if (dbpet==null)
			{
				dbpet = new DBPet();
				dbpet.OwnerID = Player.Character.ObjectId;
				dbpet.CreatureID = (uint)creatureId;
				dbpet.TrueCreatureID = (uint)creatureId;
				dbpet.Happyness = 0;
				dbpet.Level = 1;
				dbpet.Grows = !fixedLevel;
				dbpet.Name = creature.Name;
				DBManager.NewDBObject(dbpet);
				Player.Character.PetList.Add(dbpet);
			} else
                Database.Instance.ResolveRelations(dbpet, true);
			
			if (fixedLevel)
				dbpet.Level = (uint) Player.Level;
			
			if (dbpet.Spells == null || dbpet.Spells.Count == 0)
			switch(creatureId)
			{
				case 416: // Imp
				case 12922:
					DBUtility.SpellOfPet(dbpet,701);
					break;
				case 1860: // Voidwalker
					DBUtility.SpellOfPet(dbpet,3716);
					break;
				case 1863: // Succubus
					DBUtility.SpellOfPet(dbpet,7814);
					break;
				case 417: // Felhunter
					DBUtility.SpellOfPet(dbpet,17012);
					break;
				default:
					//DBUtility.SpellOfPet(dbpet,1604);
					break;
			}
			DBManager.SaveDBObject(dbpet);

			if (dbpet.CreatureID!=dbpet.TrueCreatureID)
				creature = dbpet.Creature;

			pet = new PetBase(creature, m_spell.ObjectId, dbpet, pos, Player.Facing, Player);

			Player.Pet = pet;
			Player.MapTile.Map.Enter(pet);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_PET, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_DEAD_PET, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_CRITTER, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_DEMON, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_POSSESED, new SpellCastOnLiving(Cast));
		}
	}
}