//
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ExternalScripts.Battlegrounds;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class AreaTrigger
	{
		[PacketHandler(CMSG.AREATRIGGER)]
		public static void HandleAreaTrigger(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;
			uint trigger = data.ReadUInt32();
			DBAreaTrigger Trigger = (DBAreaTrigger) Database.Instance.FindObjectByKey(typeof (DBAreaTrigger), trigger);
			if (Client.Account.AccessLvl >= ACCESSLEVEL.SEER)
			{
				if (Trigger == null)
					Chat.System(client, "Not existing trigger " + trigger + "!");
				else
					Chat.System(client, "Entering trigger " + trigger + ",map: " + Trigger.WorldMapID.ToString());
			}

			//LogConsole.WriteLine(LogLevel.SYSTEM,"Trigger "+area+",map: "+(Trigger==null?"null":Trigger.WorldMapID.ToString()));
			if (Trigger == null)
				return;
			/*if (Trigger.Redirect!=0)
			{
				Trigger=(DBAreaTrigger)Database.Instance.FindObjectByKey(typeof(DBAreaTrigger),Trigger.Redirect);
				if (Trigger==null||!Trigger.Enabled)
					return;
			}*/

			Client.Player.Quests.CheckTrigger(trigger,
			                                  Client.Player.Area == null ? Client.Player.Zone : Client.Player.Area.ObjectId,
			                                  Client.Player.MapTile);

			if (MapManager.GetWorldMap(Trigger.WorldMapID, Client.Player.MapInstanceID) == null)
				return;
			if (Trigger.Enabled && Trigger.Facing != 0)
				Client.Player.Facing = Trigger.Facing;

			if (Trigger.Tavern)
			{
				/// TODO: start rest
				if (Client.Player.MountSpell != 0)
					Client.Player.Auras.CancelAuraForce(Client.Player.MountSpell);
				else
					Client.Player.Unmount();
			}
			/*if (Trigger.WorldMapID>1)
				Client.Player.DungeonEntrance = Trigger.Position.Clone();
			else
				Client.Player.DungeonEntrance = null;*/

            if (Client.Player.Dead && Client.Player.DeathWorld >= 0)
            {
                //if (Trigger.WorldMapID != Client.Player.DeathWorld)
                //    return;

				if (Client.Player.DeathWorld == Trigger.WorldMapID && !WorldBase.Worlds.Contains(Trigger.WorldMapID))
                {
                    Client.Player.Dead = false;
                    Client.Player.Health = Client.Player.MaxHealth / 2;
                    if (Client.Player.PowerType != POWERTYPE.RAGE)
                        Client.Player.Power = Client.Player.MaxPower / 2;
                    Client.Player.DamageArmor(1f, 0.10f);
                    Client.Player.DamageWeapon(1f, 0.10f);
                }
            }

			// Notify battleground
			bool canTeleport = BattleManager.EnterTrigger(Trigger, Client.Player);

			if (Trigger.Enabled && canTeleport)
			{
				if (!WorldBase.Worlds.Contains(Trigger.WorldMapID))
				{
					DBWorldMap wmap = (DBWorldMap) Database.Instance.FindObjectByKey(typeof (DBWorldMap), Trigger.WorldMapID);

					if (wmap != null && wmap.EnterLevel <= Client.Player.Level) // temporary close dungeons
						Teleport.TeleportTo(Trigger.Position, Trigger.WorldMapID, Client.Player);
					else
						Chat.System(client, "Your level is not high enough got enter to this instance.");
				}
				else
					Teleport.TeleportTo(Trigger.Position, Trigger.WorldMapID, Client.Player);
			}
		}
	}
} 