using System;
using System.Collections;
using System.Text;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass]
	public class Mail
	{
		//  Time within mail with item  will be delivered.
		public static int MAIL_ITEM_DELIVERY_TIME = 0;

		public static int MAX_MESSAGE_LENGTH = 1023;

		public static DBItemTemplate MailItemTemplate = DBUtility.GetTemplate(8383);

		// Mail return codes
		/*  1 - That`s Bag is Full
         *  2 - You can`t send mail to yourself
         *  3 - You have not enough money.
         *  4 - Can`t find recipient
         *  5 - Recipient is not part of your alliance
         * >5 - Internail game mail database error
         */

		public enum MAIL_RESPONSE
		{
			BAGFULL = 1,
			CANT_SEND_YOURSELF = 2,
			NOT_ENOUGH_MONEY = 3,
			CANT_FIND_RECIPIENT = 4,
			RECIPIENT_IS_ENEMY = 5,
			INTERNAL_ERROR = 6
		}

		public static DBMail[] GetUnreadMail(uint ownerId, bool readAll)
		{
			ICollection pMails = Database.Instance.FindObjectsByField(typeof (DBMail), "OwnerID", ownerId);
			ArrayList result = new ArrayList();
			foreach (DBMail mail in pMails)
			{
				float DaysLeft = MGetMailExpirationTime(mail);
				if (mail.Time < CustomDateTime.Now)
				{
					if (readAll)
						result.Add(mail);
					else if (!MHasRead(mail.ReadStatus) && DaysLeft > 0)
						result.Add(mail);
				}
			}
			return (DBMail[]) result.ToArray(typeof (DBMail));
		}

		[PacketHandler(CMSG.QUERY_NEXT_MAIL_TIME, ExecutionPriority.Pool)]
		public static void OnMailTimeQuery(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			ShortPacket pkg = new ShortPacket(SMSG.QUERY_NEXT_MAIL_TIME);

			// Have no new Mails - no new mail icon
			if (GetUnreadMail(Client.Player.CharacterID, false).Length == 0)
			{
				pkg.Write(0xC7A8C000);
			}
			else //  Have 'New' Mails.
			{
				//pkg.Write((uint)Utility.Timestamp(TimeSpan.FromMinutes(1)));
				pkg.Write((float) 0);
			}

			client.Send(pkg);
			//Console.WriteLine("\r\nMail:[OnMailTimeQuery]:  Check mail: ");
		}

		[PacketHandler(CMSG.GET_MAIL_LIST, ExecutionPriority.Pool)]
		public static void HandleMailList(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			data.ReadInt32();

			DBMail[] pMails = GetUnreadMail(Client.Player.CharacterID, true);
			int mail_count = 0;
			for (int i = 0; i < pMails.Length; i++)
			{
				float DaysLeft = MGetMailExpirationTime(pMails[i]);

				if (DaysLeft > 0)
					mail_count++;
				else
				{
					//  We need return COD mail to owner
					if (pMails[i].COD != 0)
					{
						ReturnCODMail(pMails[i]);
					}
					else
					{
						DBManager.EraseDBObject(pMails[i]);
						DBMailMessage MailMessage =
							(DBMailMessage) Database.Instance.FindObjectByKey(typeof (DBMailMessage), pMails[i].MessageID);
						if (MailMessage != null)
							DBManager.EraseDBObject(MailMessage);
					}
				}
			}

			ShortPacket pkg = new ShortPacket(SMSG.MAIL_LIST_RESULT);
			pkg.Write((byte) mail_count); // Mails count


			for (int i = 0; i < pMails.Length; i++)
			{
				float DaysLeft = MGetMailExpirationTime(pMails[i]);

				if (DaysLeft < 0)
					continue;

				uint item_id = (uint) pMails[i].Item;
				DBItem item = null;
				if (item_id != 0)
				{
					item = (DBItem) Database.Instance.FindObjectByKey(typeof (DBItem), item_id);
					if (item != null)
					{
						item_id = item.TemplateID;
					}
				}

				if (pMails[i].MailType == 0)
				{
					pkg.Write(pMails[i].ObjectId); // Message ID
					pkg.Write((byte) 0);
					pkg.Write(pMails[i].SenderID); // Sender ID  
					pkg.Write(0); // auc code
					pkg.Write(pMails[i].Subject); // Subject 
					pkg.Write(pMails[i].MessageID); // Message Body ID
					pkg.Write(item == null || !Constants.BurningCrusade ? 0 : 2); // ?  2 - show box icon instad of mail stack 
					pkg.Write(41); // ?  0 - plain mess,1 - magic scroll  (changes icon for message body)  62 - from auc
					pkg.Write(item_id); // Item Template ID

					if (Constants.BurningCrusade)
					{
						if (item != null)
						{
							for (int j = 0; j < 7; j++)
							{
								pkg.Write(item.Enchantments[j].ID);
								pkg.Write(item.Enchantments[j].Charges);
							}
							pkg.Write(0);
							pkg.Write(0);
							pkg.Write(0);
							pkg.Write(0);
						}
						else
							pkg.Write(new byte[72]);
					}
					else
						pkg.Write(item != null ? item.Enchantments[0].ID : 0); //  enchant

					pkg.Write(item != null ? item.RandomPropertyID : 0); //  Stats intellect and so on  
					pkg.Write(0); // ?
					pkg.Write((byte) (item != null ? item.StackCount : 0)); // in stack 
					pkg.Write(0xFFFFFFFF); // ?
				}
				else if (pMails[i].MailType == 1) // Auction mail
				{
					// Auction test

					pkg.Write(pMails[i].ObjectId); // Message ID
					pkg.Write((byte) 2); // 2 - auction, 0 - normal mail.
					pkg.Write(pMails[i].SenderID); // Auc Sender: 1-stormwind,  2 - Ironforge,   3-Darnasus,
					//             4-undercity,  5 - Thunderbluff,6-Orgrimmar
					//             7-Goblin
					//if (Constants.BurningCrusade)
					//{
					//    pkg.Write(item_id);
					//    pkg.Write(0);
					//    //pkg.Write(0);
					//}

					pkg.Write(pMails[i].Subject); // Auc subject  ITEM_ID:RANDOM_ENCHANT_ID:FLAG // 
					// flags: 0 - outbid, 1- auc won, 2-auc success, 
					// 3-expired, 4 - cancelled  
					pkg.Write(pMails[i].MessageID); // Message Body ID
					pkg.Write(0xFFFFFFFF);
					pkg.Write(62); // Background& Enviroment
					pkg.Write(item_id); // Item Template ID

					if (Constants.BurningCrusade)
					{
						if (item != null)
						{
							for (int j = 0; j < 6; j++)
							{
								pkg.Write(item.Enchantments[j].ID);
								pkg.Write(item.Enchantments[j].Charges);
								pkg.Write(0);
							}

							/*
							pkg.Write(0);
							pkg.Write(0);
							pkg.Write(0);
							pkg.Write(0);
							*/
						}
						else
							pkg.Write(new byte[72]);
					}
					else
						pkg.Write(item != null ? item.Enchantments[0].ID : 0); //  enchant

					pkg.Write(item != null ? item.RandomPropertyID : 0); //  Stats intellect and so on  
					pkg.Write(0); // ?
					pkg.Write((byte) (item != null ? item.StackCount : 0)); // in stack 
					pkg.Write(92); // ? looks like charges
				}

				pkg.Write(item != null ? item.Template.MaxDurability : 0); // Durability max
				pkg.Write(item != null ? item.Durability : 0); // Durability value
				pkg.Write(pMails[i].Money); // Amount of money 
				pkg.Write(pMails[i].COD); // If COD Mail  0/1
				pkg.Write(pMails[i].ReadStatus); // if already read:  
				pkg.Write(DaysLeft); // Time in days till mail will be deleted
				if (Constants.BurningCrusade)
					pkg.Write(0); // pad

			}
			pkg.Write(0);
			client.Send(pkg);
		}

		public static void ReturnCODMail(DBMail Mail)
		{
			uint pOwnerID = Mail.OwnerID;
			Mail.OwnerID = Mail.SenderID;
			Mail.SenderID = pOwnerID;
			Mail.COD = 0;
			Mail.Subject = Mail.Subject;
			Mail.Time = CustomDateTime.Now;
			MSetRead(Mail, false);
			Mail.ExpirationTime = CustomDateTime.Now.AddDays(MGetMailExpirationTime(Mail));
			DBManager.SaveDBObject(Mail);
			MailNotifyPlayer(Mail.OwnerID);
		}

		/**
         * Send Mail Handler
         */

		[PacketHandler(CMSG.SEND_MAIL, ExecutionPriority.Pool)]
		public static void SendMail(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			PlayerObject pSender = Client.Player;

			data.ReadInt64(); // sender
			string receiver = data.ReadString();
			string subject = data.ReadString();
			subject = UTF8Encoding.UTF8.GetString(data.GetBuffer(), data.Position - subject.Length - 1, subject.Length);
			string message = data.ReadString();
			message = UTF8Encoding.UTF8.GetString(data.GetBuffer(), data.Position - message.Length - 1, message.Length);
			data.ReadInt32();
			data.ReadInt32();
			ulong item_id = (ulong) data.ReadInt64();
			int money = data.ReadInt32();
			int COD = data.ReadInt32();


			if (money < 0)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Cheat:Mail.cs:SendMail: " + pSender.Name + " try sends " + money);
				return;
			}

			if (receiver.Contains("|"))
			{
				string[] mailData = receiver.Split("|".ToCharArray(), StringSplitOptions.RemoveEmptyEntries);

				int mailCount = 1;
				try
				{
					if (mailData.Length > 1)
						mailCount = int.Parse(mailData[1]);
				}
				catch (FormatException)
				{
					SendMailResult(client, 0, 0, (int) MAIL_RESPONSE.CANT_FIND_RECIPIENT);
					return;
				}

				if (mailData.Length > 3)
				{
					SendMailResult(client, 0, 0, (int)MAIL_RESPONSE.CANT_FIND_RECIPIENT);
					return;
				}

				/*DBCharacter cCreator = ClientManager.GetCharacter(mailData[0]);
				if (cCreator == null)*/
				DBCharacter cCreator = pSender.Character;

				DBMailMessage newMailMessage = new DBMailMessage();
				newMailMessage.Body = subject + "\r\n\r\n" + message;

				for (int i = 0; i < mailCount; i++)
				{
					DBItem item = new DBItem(MailItemTemplate);

					if (pSender.Inventory.CanAddItem(item))
					{
						if (newMailMessage.New)
							DBManager.NewDBObject(newMailMessage);
						else
							DBManager.SaveDBObject(newMailMessage);

						item.TextID = (int)newMailMessage.ObjectId;
						item.OwnerID = pSender.CharacterID;
						item.Creator = cCreator.ObjectId;
						DBManager.NewDBObject(item);
						pSender.Character.Items.Add(item);
						pSender.Inventory.AddNewItem(item, true);
						pSender.UpdateData();
						pSender.ForceUpdateData();
						pSender.Save();

						SendMailResult(client, 0, 5, 0);
					}
					else
					{
						Items.SendChangeFail(pSender.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
						break;
					}
				}
				return;
			}

			DBCharacter pReceiver;
			ItemObject pItem = null;

			if (item_id != 0)
			{
				pItem = pSender.Inventory.FindItem(item_id);
			}

			pReceiver = ClientManager.GetCharacter(receiver);

			int retcode = 0;
			if (pReceiver == null)
			{
				retcode = (int) MAIL_RESPONSE.CANT_FIND_RECIPIENT;
			}
			else if (pItem != null && pItem is ContainerObject && ((ContainerObject) pItem).Inventory.ItemCount > 0)
			{
				retcode = (int) MAIL_RESPONSE.BAGFULL;
			}
			else if (pReceiver.ObjectId == pSender.CharacterID && Client.Account.AccessLvl <= ACCESSLEVEL.NORMAL)
			{
				retcode = (int) MAIL_RESPONSE.CANT_SEND_YOURSELF;
			}
			else if (pSender.Money < (money + 30) && Client.Account.AccessLvl <= ACCESSLEVEL.NORMAL)
			{
				retcode = (int) MAIL_RESPONSE.NOT_ENOUGH_MONEY;
			}
			else if (!Faction.SameFaction(pReceiver.Faction, pSender.Faction) && Client.Account.AccessLvl <= ACCESSLEVEL.NORMAL)
			{
				retcode = (int) MAIL_RESPONSE.RECIPIENT_IS_ENEMY;
			}

			if (retcode == 0) // all is fine - go create mail
			{
				message = UTF8Encoding.UTF8.GetBytes(message).Length > MAX_MESSAGE_LENGTH
				          	? message.Substring(0, MAX_MESSAGE_LENGTH)
				          	: message;
				DBMail mail = CreateDBMail(client, pReceiver, subject, message, pItem, money, COD);
				if (mail != null)
				{
					MailNotifyPlayer(receiver);
				}
				else
				{
					retcode = (int) MAIL_RESPONSE.INTERNAL_ERROR;
				}
			}
			SendMailResult(client, 0, 0, retcode);
		}


		public static DBMail CreateDBMail(ClientBase client, DBCharacter pReceiver, string subject, string message,
		                                  ItemObject item, int money, int cod)
		{
			//DBCharacter receiver =  (DBCharacter)Database.Instance.FindObjectsByField(typeof(DBCharacter),"Name",receiver);
			ClientData Client = (ClientData) client.Data;
			PlayerObject pSender = Client.Player;

			if (item != null && item.Soulbound)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Cheat:" + pSender.Name + ": Try send soulbound item via mail.");
				return null;
			}

			int item_id = 0;
			if (item != null)
				item_id = (int) item.DBItem.ObjectId;

			DBMail mail = new DBMail();

			uint messageId = 0;
			if (message.Trim().Length > 0)
			{
				DBMailMessage mail_mesage = new DBMailMessage();
				mail_mesage.Body = message;
				DBManager.NewDBObject(mail_mesage);
				messageId = mail_mesage.ObjectId;
			}

			mail.OwnerID = pReceiver.ObjectId;
			mail.SenderID = pSender.CharacterID;
			mail.Subject = subject;
			mail.Money = money;
			mail.Item = item_id;
			mail.MessageID = messageId;
			mail.COD = cod;
			MEnableReturnButton(mail, (cod > 0) || item_id != 0 || money > 0);
			mail.Time = CustomDateTime.Now.AddMinutes((item_id != 0) ? MAIL_ITEM_DELIVERY_TIME : 0);
			MSetRead(mail, false);

			if (pSender.Money > (money + 30))
			{
				pSender.Money -= (money + 30);
			}
			else
			{
				mail.Money = 0; // Player have not enough money - will not send anything
			}

			mail.ExpirationTime = CustomDateTime.Now.AddSeconds((int) (MGetMailExpirationTime(mail)*3600*24));
			DBManager.NewDBObject(mail);

			// Move item to hidden container and update player.
			HideItem(pSender, item);

			return mail;
		}


		/** Creates Auction-type mail object.  TODO:*/

		public static DBMail CreateAuctionMail( /*DBCharacter */
			uint pReceiver, DBItem item, uint item_id, int money, int type, int house, string report)
		{
			DBMail mail = new DBMail();

			uint messageId = 0;
			if (report.Trim().Length > 0)
			{
				DBMailMessage mail_mesage = new DBMailMessage();
				mail_mesage.Body = report;
				DBManager.NewDBObject(mail_mesage);
				messageId = mail_mesage.ObjectId;
			}

			mail.OwnerID = pReceiver /*.ObjectId*/;
			mail.SenderID = (uint) house;

			mail.Subject = item_id + ":" + (item != null ? item.RandomPropertyID : 0) + ":" + type;
			mail.Money = money;
			mail.Item = item != null ? (int) item.ObjectId : 0;
			mail.MailType = 1;
			mail.MessageID = messageId;
			mail.COD = 0;
			MEnableReturnButton(mail, false);
			MDisableCanTakeAttach(mail, true);
			mail.Time = CustomDateTime.Now;
			MSetRead(mail, false);
			mail.ExpirationTime = CustomDateTime.Now.AddSeconds((int) (MGetMailExpirationTime(mail)*3600*24));
			DBManager.NewDBObject(mail);
			MailNotifyPlayer(mail.OwnerID);
			return mail;
		}

		/**
         *  Handle mail delete packet.
         *  Remove Mail, and MailMessage objects form database.
         */

		[PacketHandler(CMSG.MAIL_DELETE, ExecutionPriority.Pool)]
		public static void DeleteMail(ClientBase client, BinReader data)
		{
			data.ReadInt64(); // mailbox
			int mail_id = data.ReadInt32();

			DBMail mail = (DBMail) Database.Instance.FindObjectByKey(typeof (DBMail), mail_id);
			DoDeleteMail(client,mail,mail_id);
		}
		
		private static void DoDeleteMail(ClientBase client,DBMail mail,int mail_id)
		{
			// No mail object
			if (mail == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Mail.cs:DeleteMail:Request invalid Mail object: " + mail_id);
				return;
			}

			DBMailMessage mailMessage = mail.MessageID == 0 ? null :
				(DBMailMessage)Database.Instance.FindObjectByKey(typeof(DBMailMessage), mail.MessageID);

			// Something wrong, user can`t delete COD mail
			if (mail.COD > 0)
			{
				SendMailResult(client, 0, 0, 6); // send internal error
				return;
			}

			if (mail.Item != 0)
			{
				DBItem pItem = (DBItem)Database.Instance.FindObjectByKey(typeof(DBItem), mail.Item);
				if (pItem != null)
					DBManager.EraseDBObject(pItem);
			}

			DBManager.EraseDBObject(mail);

			if (mailMessage != null)
				DBManager.EraseDBObject(mailMessage);

			SendMailResult(client, mail_id, 4, 0); // remove mail from list and close message window.
		}


		/** 
         * Returns mail to sender
         */

		[PacketHandler(CMSG.MAIL_RETURN_TO_SENDER, ExecutionPriority.Pool)]
		public static void ReturnMail(ClientBase client, BinReader data)
		{
			data.ReadInt64(); // mailbox
			int mail_id = data.ReadInt32();
			DBMail mail = (DBMail) Database.Instance.FindObjectByKey(typeof (DBMail), mail_id);
			if (mail != null)
			{
				ClientData Client = (ClientData) client.Data;
				PlayerObject player = Client.Player;
				mail.OwnerID = mail.SenderID;
				mail.SenderID = player.CharacterID;
				mail.COD = 0;
				MEnableReturnButton(mail, false);
				mail.Subject = mail.Subject;
				mail.Time = CustomDateTime.Now;
				MSetRead(mail, false);
				mail.ExpirationTime = CustomDateTime.Now.AddSeconds((int) (MGetMailExpirationTime(mail)*3600*24));
				SendMailResult(client, mail_id, 3, 0); // remove mail from list and close message window.

				DBManager.SaveDBObject(mail);

				MailNotifyPlayer(mail.OwnerID);

				SendMailResult(client, 0, 0, 0);
			}
		}

		/** 
         * Send mail check notify to Player if he is alive.
         * By player guid
         */

		public static void MailNotifyPlayer(uint guid)
		{
			MailNotify(ClientManager.GetClient(guid));
		}

		/** 
         * Send mail check notify to Player if he is alive.
         * By player name
         */

		public static void MailNotifyPlayer(string name)
		{
			MailNotify(ClientManager.GetClient(name));
		}


		/* Send received mail packet to player if he is online
         */

		private static void MailNotify(ClientBase pClient)
		{
			if (pClient != null) // if recipient is alive - send notification
			{
				ShortPacket pckg = new ShortPacket(SMSG.RECEIVED_MAIL);
				pckg.Write(1);
				pClient.Send(pckg);
			}
		}


		/** 
         * Gets money from mail and add to player.
         */

		[PacketHandler(CMSG.MAIL_TAKE_MONEY, ExecutionPriority.Pool)]
		public static void TakeMoney(ClientBase client, BinReader data)
		{
			data.ReadInt64(); // mailbox
			int mail_id = data.ReadInt32();
			DBMail Mail = (DBMail) Database.Instance.FindObjectByKey(typeof (DBMail), mail_id);

			if (Mail != null && Mail.Money > 0 && Mail.COD == 0)
			{
				ClientData Client = (ClientData) client.Data;
				PlayerObject player = Client.Player;

				player.Money += Mail.Money;

				Mail.Money = 0;
				DBManager.SaveDBObject(Mail);
				player.Redress();
				player.UpdateData();
				player.Save();
				SendMailResult(client, mail_id, 1, 0); // remove money icon from mail.
				if (Mail.MailType == 1)
					DoDeleteMail(client, Mail, mail_id);
			}
		}


		/** 
         * Gets item from mail and add to player.
         */

		[PacketHandler(CMSG.MAIL_TAKE_ITEM, ExecutionPriority.Pool)]
		public static void TakeItem(ClientBase client, BinReader data)
		{
			data.ReadInt64(); // mailbox
			int mail_id = data.ReadInt32();
			DBMail mail = (DBMail) Database.Instance.FindObjectByKey(typeof (DBMail), mail_id);


			// No mail object
			if (mail == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Mail.cs:TakeItem:Request invalid Mail object: " + mail_id);
				return;
			}


			ClientData Client = (ClientData) client.Data;
			PlayerObject player = Client.Player;

			DBItem Item = (DBItem) Database.Instance.FindObjectByKey(typeof (DBItem), mail.Item);

			if (Item == null)
			{
				Items.SendChangeFail(player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_UNKNOWN_ITEM);
				return;
			}

			if (!player.Inventory.CanAddItem(Item))
			{
				Items.SendChangeFail(player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
				SendMailResult(client, mail_id, 6, 0);
				return;
			}

			if (mail.COD > 0 && player.Money < mail.COD)
			{
				// Protect from script users/buggers
				SendMailResult(client, mail_id, 0, 3); // not enough money
				return;
			}
			else if (mail.COD > 0 && player.Money >= mail.COD)
			{
				// Get money for COD ( Cash On Delivery ) mail 
				player.Money -= mail.COD;

				DBMail MailRet = new DBMail();
				MailRet.OwnerID = mail.SenderID;
				MailRet.SenderID = mail.OwnerID;
				MailRet.Subject = Item.Template.Name;
				MailRet.Money = mail.COD;
				MailRet.COD = 0;
				MSetCODPayment(MailRet, true);
				MailRet.MessageID = 0;
				MSetRead(MailRet, false);
				MailRet.Time = CustomDateTime.Now; // Return mail immidiately.
				DBManager.NewDBObject(MailRet);

				DBCharacter dbReceiver = ClientManager.GetCharacter(mail.OwnerID);

				if (dbReceiver != null)
					MailNotifyPlayer(dbReceiver.Name);
			}


			DBItem dbItem = (DBItem) Database.Instance.FindObjectByKey(typeof (DBItem), mail.Item);

			Database.Instance.ReindexObject("OwnerID", dbItem.OwnerID, player.CharacterID, dbItem);

			//dbItem.ContainerID = player.CharacterID;
			//dbItem.OwnerID = player.CharacterID;
			//player.Inventory.AddItem(dbItem, true);
			//Database.Instance.AddObjectToRelations(player.Character, dbItem); // TODO: we must remove item from previous owner relations
			//DBManager.SaveDBObject(dbItem);
			player.AddItem(dbItem);

			mail.Item = 0;
			mail.COD = 0;
			DBManager.SaveDBObject(mail);
			//player.Redress();
			//player.UpdateData();
			
			SendMailResult(client, mail_id, 2, 0); // remove item icon from mail.
			if (mail.MailType == 1)
				DoDeleteMail(client, mail, mail_id);
		}


		[PacketHandler(CMSG.MAIL_CREATE_TEXT_ITEM, ExecutionPriority.Pool)]
		public static void CreateItem(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			PlayerObject player = Client.Player;

			data.ReadInt32();
			data.ReadInt32();
			int mail_id = data.ReadInt32();

			DBMail Mail = (DBMail) Database.Instance.FindObjectByKey(typeof (DBMail), mail_id);

			// No mail object
			if (Mail == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Mail.cs:CreateItem:Request invalid Mail object: " + mail_id);
				return;
			}

			DBMailMessage MailMessage = (DBMailMessage) Database.Instance.FindObjectByKey(typeof (DBMailMessage), Mail.MessageID);
			if (MailMessage != null)
			{
				DBItem item = new DBItem(MailItemTemplate);

				if (player.Inventory.CanAddItem(item))
				{
					DBMailMessage newMailMessage = new DBMailMessage();
					newMailMessage.Body = MailMessage.Body;
					DBManager.NewDBObject(newMailMessage);

					item.TextID = (int) newMailMessage.ObjectId;
					item.OwnerID = player.CharacterID;
					item.Creator = Mail.SenderID;
					DBManager.NewDBObject(item);

					player.Character.Items.Add(item);
					player.Inventory.AddNewItem(item, true);
					player.UpdateData();
					player.ForceUpdateData();
					player.Save();
					SendMailResult(client, mail_id, 5, 0);

					MDisableCanTakeAttach(Mail, true);
					DBManager.SaveDBObject(Mail);
					return;
				}
				else
				{
					Items.SendChangeFail(player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
				}
			}

			SendMailResult(client, mail_id, 0, 1);
		}

		[PacketHandler(CMSG.MAIL_MARK_AS_READ, ExecutionPriority.Pool)]
		public static void MarkAsRead(ClientBase client, BinReader data)
		{
			data.ReadInt32();
			data.ReadInt32();
			int mail_id = data.ReadInt32();
			DBMail Mail = (DBMail) Database.Instance.FindObjectByKey(typeof (DBMail), mail_id);
			if (Mail != null)
			{
				MSetRead(Mail, true);
				DBManager.SaveDBObject(Mail);
			}
			else
			{
				//Console.WriteLine("Mail:[MarkAsRead]:  Client requested mail that didn't exist: " + mail_id);
				return;
			}
		}

		private static void SendMailResult(ClientBase client, int fParam, int sParam, int tParam)
		{
			ShortPacket pckg = new ShortPacket(SMSG.SEND_MAIL_RESULT);
			pckg.Write(fParam);
			pckg.Write(sParam);
			pckg.Write(tParam);
			client.Send(pckg);
		}

		/**  HasRead flags
        */
		// 0   1[Cod/notCod]   1[cancopy/cantcopy]   1[delete/return] 1[read/no]
		public static bool MHasRead(int readStatus)
		{
			return (readStatus & 1) == 1;
		}

		public static void MSetRead(DBMail mail, bool set)
		{
			if ((set && (mail.ReadStatus & 1) != 1) || (!set && (mail.ReadStatus & 1) == 1))
			{
				mail.ReadStatus ^= 1;
			}
		}

		public static bool MHasReturnButton(int readStatus)
		{
			return (readStatus & 2) != 2;
		}

		public static void MEnableReturnButton(DBMail mail, bool set)
		{
			if ((set && (mail.ReadStatus & 2) == 2) || (!set && (mail.ReadStatus & 2) != 2))
			{
				mail.ReadStatus ^= 2;
			}
		}

		public static bool MCanTakeAttachement(int readStatus)
		{
			return (readStatus & 4) == 4;
		}

		public static void MDisableCanTakeAttach(DBMail mail, bool set)
		{
			if ((set && (mail.ReadStatus & 4) != 4) || (!set && (mail.ReadStatus & 4) == 4))
			{
				mail.ReadStatus ^= 4;
			}
		}

		public static bool MIsCOD(DBMail mail)
		{
			return mail.COD > 0;
		}

		public static bool MIsCODPayment(int readStatus)
		{
			return (readStatus & 8) == 8;
		}

		public static void MSetCODPayment(DBMail mail, bool set)
		{
			if ((set && (mail.ReadStatus & 8) != 8) || (!set && (mail.ReadStatus & 8) == 8))
			{
				mail.ReadStatus ^= 8;
			}
		}

		public static float MGetMailExpirationTime(DBMail Mail)
		{
			bool hasRead = MHasRead(Mail.ReadStatus);
			bool isCod = MIsCOD(Mail);
			bool hasItemOrMoney = Mail.Item != 0 || Mail.Money != 0;
			int time = hasRead ? 3 : 10;
			time = isCod ? 2 : time;
			time = (!isCod && hasItemOrMoney && !hasRead) ? 29 : time;
			float daysLeft =
				(float)
				(time - ((new TimeSpan(CustomDateTime.Now.Ticks).TotalDays - new TimeSpan(Mail.Time.Ticks).TotalDays)) + 0.05);
			daysLeft = daysLeft < 0 ? 0 : daysLeft;
			return daysLeft;
		}

		public static void HideItem(PlayerObject player, ItemObject item)
		{
			if (item != null)
			{
				item.ContainedIn.RemoveItem(item.DBItem.OwnerSlot, true);
				item.ContainedIn.UpdateSlot(item.DBItem.OwnerSlot);
				item.DBItem.ContainerID = -1;
				DBManager.SaveDBObject(item.DBItem);
			}

			player.Redress();
			player.Inventory.UpdateInventory();
			player.UpdateData();
			player.ForceUpdateData();
			player.Save();
		}
	}
}