using System;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.ServerScripts.AI.Behaivors;
using RunWoW.Spells;
using RunWoW.Spells.Scripts;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass]
	public class TextEmote
	{
		public static DBSpell PhoenixSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 32345);
		public static DBSpell DrakeSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 3363);
		public static DBSpell FlySpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 34134);

		[PacketHandler(CMSG.TEXT_EMOTE)]
		public static void OnTextEmote(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null || Client.Player.MapTile == null)
				return;

			int emoteTextID = data.ReadInt32();
			data.ReadInt32();
			ulong guid = data.ReadUInt64();
			ObjectBase obj = Client.Player.MapTile.GetObject(guid, OBJECTTYPE.PLAYER);

			if (obj == null)
				obj = Client.Player.MapTile.GetObject(guid, OBJECTTYPE.UNIT);

			if (obj is GuardBase)
			{
				if (Utility.Chance(0.5))
				{
					SpellCastEvent snowball = new SingleTargetCast(obj, Snowball.SnowballSpell, 2, Client.Player, false);
					snowball.Delay = TimeSpan.FromSeconds(2);
					snowball.Start();
				}
				else if (Utility.Chance(0.5))
				{
					SpellCastEvent fireworks = new SingleTargetCast(obj, HeraldAI.FireworksSpell, 2, obj, false);
					fireworks.Delay = TimeSpan.FromSeconds(2);
					fireworks.Start();
				}
			} else
				if (obj is UnitBase && (((UnitBase)obj).Creature.ObjectId == 13444 || ((UnitBase)obj).Creature.ObjectId == 13445))
				{
					if (Utility.Chance(0.5))
						
						if ((CustomDateTime.Now - Client.Player.LastCast).Minutes > 1)
					{
						PhoenixSpell.Duration = 60000;
						DrakeSpell.Duration = 60000;
						FlySpell.Duration = 60000;

						SpellManager.Cast(obj, Client.Player, FlySpell);
						SpellManager.Cast(obj, Client.Player, Utility.Chance(0.5) ? PhoenixSpell : DrakeSpell);
						Client.Player.LastCast = CustomDateTime.Now;
					} else 
							Chat.MonsterSay((UnitBase)obj, Client.Player, "You cannot ride yet. Wait for a while");
				}

			ShortPacket pkg = new ShortPacket(SMSG.TEXT_EMOTE);
			pkg.Write(Client.Player.GUID);
			pkg.Write(emoteTextID);
			pkg.Write(0xFF);
			pkg.WriteString(obj == null ? string.Empty : obj.Name);
			pkg.Write((byte)0);
			Client.Player.MapTile.SendSurrounding(pkg, Client.Player);

			if (emoteTextID < emote_lookup.Length && emote_lookup[emoteTextID] != 0)
			{
				ShortPacket pkg1 = new ShortPacket(SMSG.EMOTE);
				pkg1.Write(emote_lookup[emoteTextID]);
				pkg1.Write(Client.Player.GUID);
				Client.Player.MapTile.SendSurrounding(pkg1, Client.Player);
			}

		}

		private static int[] emote_lookup = {
            0 , 0 , 0 , 14 , 0 , 21 , 24 , 0 , 20 , 0 , 0 , 0 , 24 , 0 , 0 , 0 , 0 , 2 , 0 , 3 , 
            11 , 4 , 19 , 11 , 21 , 6 , 5 , 0 , 0 , 0 , 0 , 18 , 6 , 2 , 10 , 7 , 0 , 7 , 0 , 0 , 
            0 , 23 , 0 , 5 , 0 , 11 , 0 , 11 , 3 , 0 , 0 , 20 , 11 , 3 , 0 , 3 , 0 , 0 , 17 , 68 , 
            11 , 12 , 0 , 0 , 0 , 18 , 274 , 273 , 0 , 0 , 0 , 20 , 25 , 0 , 16 , 15 , 11 , 14 , 66 , 0 , 
            0 , 0 , 22 , 6 , 24 , 0 , 13 , 12 , 0 , 0 , 0 , 0 , 20 , 1 , 5 , 6 , 0 , 1 , 0 , 0 , 
            4 , 3 , 1 , 0 , 0 , 0 , 0 , 6 , 0 , 0 , 0 , 0 , 0 , 14 , 0 , 0 , 0 , 0 , 6 , 0 , 
            6 , 0 , 0 , 0 , 6 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 19 , 0 , 0 , 0 , 
            0 , 26 , 0 , 18 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 14 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 0 , 15 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 21 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 0 , 275 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 22 , 22 , 25 , 22 , 15 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 1 , 1 , 1 , 1 , 25 , 24 , 1 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 21 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 0 , 
            0 , 0 , 0 , 0 ,		                                        
		};
	}
}