//
using System;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class Queries
	{
		[PacketHandler(CMSG.ITEM_NAME_QUERY, ExecutionPriority.Pool)]
		public static void ItemNameQuery(ClientBase client, BinReader data)
		{
			try
			{
				uint itemTemplateID = data.ReadUInt32();

				DBItemTemplate template =
					(DBItemTemplate) Database.Instance.FindObjectByKey(typeof (DBItemTemplate), itemTemplateID);
				if (template != null)
				{
					ShortPacket pckg = new ShortPacket(SMSG.ITEM_NAME_QUERY_RESPONSE);
					pckg.Write(template.ObjectId);
					pckg.Write(template.Name);
				}
			}
			catch (Exception exc)
			{
				LogConsole.WriteLine(LogLevel.ERROR, exc.StackTrace);
			}
		}


		[PacketHandler(CMSG.MEETING_STONE_INFO, ExecutionPriority.Pool)]
		public static void OnMettingStoneQuery(ClientBase client, BinReader data)
		{
			ShortPacket packet = new ShortPacket(SMSG.MEETING_STONE_INFO);
			packet.Write(new byte[8]);
			client.Send(packet);
		}

		[PacketHandler(CMSG.LOOKING_FOR_GROUP, ExecutionPriority.Pool)]
		public static void OnLookingForGroup(ClientBase client, BinReader data)
		{
			ShortPacket packet = new ShortPacket(SMSG.LOOKING_FOR_GROUP);
			packet.Write(0);
			client.Send(packet);
		}

		[PacketHandler(CMSG.CREATURE_QUERY, ExecutionPriority.Pool)]
		public static void OnCreatureQuery(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.MapTile == null)
				return;

			uint id = data.ReadUInt32();
			DBCreature creature = (DBCreature) Database.Instance.FindObjectByKey(typeof (DBCreature), id);
			if (creature == null)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "OnCreatureQuery(): id didn't exists.");
				return;
			}
			ulong GUID = data.ReadUInt64();

			UnitBase unit = (UnitBase) Client.Player.MapTile.GetObject(GUID, OBJECTTYPE.UNIT);

			ShortPacket packet = new ShortPacket(SMSG.CREATURE_QUERY_RESPONSE);
			LogConsole.WriteLine(LogLevel.ECHO, "Querying creature " + creature.Name);
			packet.Write(id);
			packet.Write(creature.Name);
            packet.Write(creature.Name1 == creature.Name ? string.Empty : creature.Name1);
            packet.Write(creature.Name2 == creature.Name ? string.Empty : creature.Name2);
            packet.Write(creature.Name3 == creature.Name ? string.Empty : creature.Name3);
			packet.Write(creature.Title);
			packet.Write(unit == null ? 0 : unit.Flags);
			packet.Write((int)creature.CreatureType);
			packet.Write((int)creature.CreatureFamily);
			packet.Write((int)creature.Elite);
			packet.Write(0); // unknown
			packet.Write(0); // unknown
			packet.Write(creature.DisplayID); // unknown
			packet.Write((short)(unit is NPCBase || unit is GuardBase ? 1 : 0));
			packet.Write((byte) 0);
			client.Send(packet);
		}

		[PacketHandler(CMSG.GAMEOBJECT_QUERY, ExecutionPriority.Pool)]
		public static void OnGOQuery(ClientBase client, BinReader data)
		{
			uint id = data.ReadUInt32();
			DBGOTemplate template = (DBGOTemplate)Database.Instance.FindObjectByKey(typeof(DBGOTemplate), id);
			if (template == null)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "OnGOQuery(): id didn't exists." + id);
				return;
			}
			
			ShortPacket packet = new ShortPacket(SMSG.GAMEOBJECT_QUERY_RESPONSE);

			packet.Write(id);

            packet.Write(template.TypeID);
			packet.Write(template.DisplayID);

			packet.Write(template.Name);
            packet.Write(template.Name1 == template.Name ? string.Empty : template.Name1);
            packet.Write(template.Name2 == template.Name ? string.Empty : template.Name2);
            packet.Write(template.Name3 == template.Name ? string.Empty : template.Name3);
		    
		    //if (Constants.BurningCrusade)
		        packet.Write((byte)0);
		        packet.Write((byte)0);
		        packet.Write((byte)0);

			for(int i=0;i<template.Sound.Length;i++)
				packet.Write(template.Sound[i]);
			
			packet.Write(new byte[24]);

			client.Send(packet);
		}

		[PacketHandler(CMSG.READ_ITEM, ExecutionPriority.Pool)]
		public static void OnItemRead(ClientBase client, BinReader data)
		{
			byte bag = data.ReadByte();
			byte slot = data.ReadByte();
			ClientData Client = (ClientData) client.Data;
			try
			{
				ItemObject obj = Client.Player.Inventory.GetSubContainer(bag).GetItem(slot);
				ulong guid = obj.GUID;
				ShortPacket pkg1 = new ShortPacket(SMSG.READ_ITEM_OK);
				pkg1.Write(guid);
				client.Send(pkg1);
			}
			catch (Exception)
			{
				ShortPacket pkg1 = new ShortPacket(SMSG.READ_ITEM_FAILED);
				pkg1.Write(0);
				client.Send(pkg1);
			}
		}


		[PacketHandler(CMSG.PAGE_TEXT_QUERY, ExecutionPriority.Pool)]
		public static void OnPageQuery(ClientBase client, BinReader data)
		{
			uint id = data.ReadUInt32();
			ulong item_guid = data.ReadUInt64();
			DBPage page = null;
			uint next_page = id;
			do
			{
				ShortPacket pkg = new ShortPacket(SMSG.PAGE_TEXT_QUERY_RESPONSE);
				page = (DBPage) Database.Instance.FindObjectByKey(typeof (DBPage), next_page);
				pkg.Write(next_page);
				if (page != null)
				{
					pkg.Write(page.Text);
					pkg.Write(page.Next);
					next_page = page.Next;
				}
				client.Send(pkg);
			} while (page != null && next_page != 0);

			ShortPacket packet = new ShortPacket(SMSG.READ_ITEM_OK);
			packet.Write(item_guid);
			client.Send(packet);
		}


		[PacketHandler(CMSG.ITEM_TEXT_QUERY, ExecutionPriority.Pool)]
		public static void OnItemTextQuery(ClientBase client, BinReader data)
		{
			uint id = data.ReadUInt32();
			uint item_id = data.ReadUInt32();
			uint text_mode = data.ReadUInt32(); // flags ? [0x70000000  - Mail Body , 0x000A0000  - Item text]
			DBItem item = (DBItem) Database.Instance.FindObjectByKey(typeof (DBItem), item_id);
			if (text_mode == 0x1FB00000 || (item != null && item.TemplateID == 8383)) // Return Mail Message Body 
			{
				ShortPacket pkg = new ShortPacket(SMSG.ITEM_TEXT_QUERY_RESPONSE);
				DBMailMessage message = (DBMailMessage) Database.Instance.FindObjectByKey(typeof (DBMailMessage), id);
				pkg.Write(id);
				pkg.Write(message == null ? string.Empty : message.Body);
				pkg.Write((int) 0);
				client.Send(pkg);
			}
			else
			{
				ShortPacket pkg = new ShortPacket(SMSG.ITEM_TEXT_QUERY_RESPONSE);
				DBPage page;
				pkg.Write(item_id);
				while (id != 0)
				{
					page = (DBPage) Database.Instance.FindObjectByKey(typeof (DBPage), id);
					if (page == null)
					{
						Console.WriteLine("Client requested text page that didn't exist: " + id);
						return;
					}

					//pkg.Write(page.ObjectId);
					pkg.Write(page.Text);
					pkg.Write(page.Next);
					id = page.Next;
				}
				client.Send(pkg);

				ShortPacket pkg1 = new ShortPacket(SMSG.READ_ITEM_OK);
				pkg1.Write(item_id);
				pkg1.Write((int) id);
				client.Send(pkg1);
			}
		}

		[PacketHandler(CMSG.ITEM_QUERY_SINGLE, ExecutionPriority.Pool)]
		public static void OnItemQuerySingle(ClientBase client, BinReader data)
		{
			uint id = data.ReadUInt32();
			//ulong guid = data.ReadUInt64();
			DBItemTemplate template = (DBItemTemplate) Database.Instance.FindObjectByKey(typeof (DBItemTemplate), id);
			if (template == null)
			{
				Console.WriteLine("Client requested an item template that didn't exist: " + id);
				return;
			}
			ShortPacket pkg = new ShortPacket(SMSG.ITEM_QUERY_SINGLE_RESPONSE);
			pkg.Write(id);
			pkg.Write((int) template.Class);
			pkg.Write((int)template.SubClass);
			if (WoWVersion.Version205)
				pkg.Write(-1);
			pkg.Write(template.Name);
			pkg.Write(template.Name1);
			pkg.Write(template.Name2);
			pkg.Write(template.Name3);
			pkg.Write(template.DisplayID);
			
			pkg.Write(template.OverallQuality);
			pkg.Write(template.Flags);
			pkg.Write(template.BuyPrice);
			pkg.Write(template.SellPrice);
			pkg.Write((int) template.InvType);
			pkg.Write(template.AllowableClass);
			if (Constants.BurningCrusade && template.AllowableRace == 511)
				pkg.Write(2047);
			else
				pkg.Write(template.AllowableRace);
			pkg.Write(template.Itemlevel);
			pkg.Write(template.ReqLevel);
			pkg.Write(template.ReqSkill);
			pkg.Write(template.MinReqSkill);
			pkg.Write(template.ReqSpell); // Req Spell!
			pkg.Write(template.Rank);
			pkg.Write(template.CityRank); // ??? 10 = "Requires ", 0 - "Protector of Stormwind"
			pkg.Write(template.Reputation);
			pkg.Write(template.ReputationRank);
			pkg.Write(template.MaxCount);
			pkg.Write(template.MaxStack);
			pkg.Write(template.ContainerSlots);

			foreach (ItemBonus bonus in template.ItemBonuses)
			{
				pkg.Write(bonus.Stat);
				pkg.Write(bonus.Bonus);
			}
			foreach (DamageStat stat in template.DamageStats)
			{
				if (stat.Min > stat.Max)
				{
					pkg.Write(stat.Max);
					pkg.Write(stat.Min);
				}
				else
				{
					pkg.Write(stat.Min);
					pkg.Write(stat.Max);
				}
				pkg.Write(stat.Type);
			}

			pkg.Write(template.Resists.Physical);
			pkg.Write(template.Resists.Holy);
			pkg.Write(template.Resists.Fire);
			pkg.Write(template.Resists.Nature);
			pkg.Write(template.Resists.Frost);
			pkg.Write(template.Resists.Shadow);
			pkg.Write(template.Resists.Arcane);
			pkg.Write(template.WeaponSpeed);
			pkg.Write(template.AmmoType);
			if (Constants.BurningCrusade)
				pkg.Write(template.Range == 0f && template.Ranged ? 100f : template.Range); // shoot range
					
			foreach (SpellStat sstat in template.SpellStat)
			{
				pkg.Write(sstat.ID);
				pkg.Write(sstat.Trigger);
				pkg.Write(sstat.Charges);
				pkg.Write(sstat.Cooldown);
				pkg.Write(sstat.Category);
				pkg.Write(sstat.CategoryCooldown);
			}

			pkg.Write(template.BindType);
			pkg.Write(template.Description);
			pkg.Write(template.PageText);
			pkg.Write(template.LanguageID);
			pkg.Write(template.PageMaterial);
			pkg.Write(template.StartQuestID);
			pkg.Write(template.Lock);
			pkg.Write(template.Material);
			pkg.Write(template.SheathType);
			pkg.Write(template.RandomProperties);
			pkg.Write(template.Unknown9);
			pkg.Write(template.Block);
			pkg.Write(template.SetID);
			pkg.Write(template.MaxDurability);
            pkg.Write(template.Area);
            if (Constants.BurningCrusade)
			{
                pkg.Write(template.World); // World ID. may be this one should be template.Area
                pkg.Write(template.BagType); // bag type
				pkg.Write(template.ToolID);

				foreach (SocketStat socket in template.SocketStats)
				{
					pkg.Write(socket.Type);
						/// 1 - meta socket, 2 - red socket, 3 - meta socket , 4 - yellow socket, 5 - meta socket, 6 - red socket, 7 - meta, 8 - blue, 9 - meta, 10 - red 
						/// so, first bit treated as main. bit 1 - meta, 2 - red, 3 - yellow, 4 - blue

					pkg.Write(socket.Bonus); // ??
				}

				pkg.Write(template.SocketBonus); // socket enchant bonus. 1 - Rockbitter 3, 3 - Flametongue 3, 4 - Flametongue

            } 
			
			client.Send(pkg);
		}

		[PacketHandler(CMSG.CORPSE_QUERY, ExecutionPriority.Pool)]
		public static void OnCorpseQuery(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			if (!Client.Player.Dead)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.CORPSE_QUERY);
			pkg.Write((byte) 1);
			pkg.Write(Client.Player.DeathWorld);
			pkg.WriteVector(Client.Player.DeathPoint);
			pkg.Write(Client.Player.DeathWorld);
			client.Send(pkg);

			pkg = new ShortPacket(SMSG.MINIMAP_PING);
			pkg.Write(Client.Player.GUID);
			pkg.Write(Client.Player.DeathPoint.X);
			pkg.Write(Client.Player.DeathPoint.Y);
			client.Send(pkg);
		}

		[PacketHandler(CMSG.NAME_QUERY, ExecutionPriority.Pool)]
		public static void OnNameQuery(ClientBase client, BinReader data)
		{
			ulong uid = data.ReadUInt64();
		    uint unk = 0;
            if (data.Length - data.Position >= 4)
                unk = data.ReadUInt32();
		    
			ShortPacket pkg = new ShortPacket(SMSG.NAME_QUERY_RESPONSE);

			DBCharacter objCharacter = ClientManager.GetCharacter((uint)uid);

			if (objCharacter != null)
			{
				pkg.Write((ulong) objCharacter.ObjectId);
				pkg.Write(objCharacter.Name);
				if (Constants.BurningCrusade)
				{
					pkg.Write((byte) 0);
					pkg.Write((byte)objCharacter.Race);
					pkg.Write((byte)0);
					pkg.Write((byte)0);
					pkg.Write((byte)0);
					pkg.Write((byte)objCharacter.Gender);
					pkg.Write((byte)0);
					pkg.Write((byte)0);
					pkg.Write((byte)0);
					pkg.Write((byte)objCharacter.Class);
					pkg.Write((byte)0);
					pkg.Write((byte)0);
					pkg.Write((byte)0);
				}
				else
				{
					pkg.Write((int) objCharacter.Race);
					pkg.Write((int) objCharacter.Gender);
					pkg.Write((int) objCharacter.Class);
				}
				client.Send(pkg);
			}
			else
			{
                Console.WriteLine("Requested unknown character uid: {0}, unk {1}", uid, unk);
			}
		}

		[PacketHandler(CMSG.PET_NAME_QUERY, ExecutionPriority.Pool)]
		public static void OnPetNameQuery(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			uint number = data.ReadUInt32();
			ulong guid = data.ReadUInt64();
			ShortPacket pkg = new ShortPacket(SMSG.PET_NAME_QUERY_RESPONSE);

			PetBase unit = null;
			if (Client.Player.Pet != null)
				unit = Client.Player.Pet;
			else
				unit = Client.Player.MapTile.GetObject(guid, OBJECTTYPE.UNIT) as PetBase;

			if (unit == null)
				return;
			
			pkg.Write(number);

			//if (unit == null)
			//{
			//    //Console.WriteLine("Requested unknown pet : " + guid);
			//    if (Client.Player.GM)
			//        Chat.System(client,
			//                    string.Format("Send PET_NAME_QUERY with number {0}, guid 0x{1,16:X16}, self pet: {2}", number, guid,
			//                                  Client.Player.Pet != null ? Client.Player.Pet.Name : "(none)"));
			//    pkg.Write(0);
			//    pkg.Write(0);
			//}
			//else
			//{
			pkg.Write(unit.Name);
			pkg.Write(unit.PetNameTimestamp);
			//}
			client.Send(pkg);
		}

		[PacketHandler(CMSG.QUERY_TIME, ExecutionPriority.Pool)]
		public static void OnTimeQuery(ClientBase client, BinReader data)
		{
			ShortPacket pkg = new ShortPacket(SMSG.QUERY_TIME_RESPONSE);
			pkg.Write(Utility.Timestamp());
			client.Send(pkg);
		}
	}
}