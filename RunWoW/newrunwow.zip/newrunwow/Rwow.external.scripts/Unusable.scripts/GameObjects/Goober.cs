using System.Collections;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.World;
using RunWoW.ExternalScripts.GameObjects;

namespace RunWoW.GameObjects
{
	public class GooberGameObject
	{
		public static Hashtable m_pHandlers = new Hashtable();

		public static void Process(LivingObject user, GameObject go)
		{
			PlayerObject player = (PlayerObject)user;

			if (m_pHandlers[go.DBGameObject.TemplateID] != null)
				((IGoober)m_pHandlers[go.DBGameObject.TemplateID]).GooberSelect(user, go);
		}

		public static void SetHandler( int templateID, IGoober ig)
		{
			m_pHandlers.Add(templateID, ig);
		}

		public static void RemoveHandler(int templateID)
		{
			m_pHandlers.Remove(templateID);
		}


		private static GameObject NearGO(LivingObject unit, int goId, float range)
		{
			float rangesqrd = range * range;
			foreach (MapTile mapTile in unit.MapTile.Adjacents.Tiles)
				if (mapTile != null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection != null)
					{
						foreach (GameObject gameObject in collection)
						{
							if (gameObject != null && gameObject.Template.ObjectId == goId &&
								gameObject.Position.DistanceFlatSqrd(unit.Position) < rangesqrd)
								return gameObject;
						}
					}
				}
			return null;
		}


		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			GOManager.RegisterType(GameObjectType.Goober, new GameObjectAction(Process));
		}
	}
}