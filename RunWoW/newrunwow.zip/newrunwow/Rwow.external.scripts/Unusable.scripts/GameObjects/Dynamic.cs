using System.Collections;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.World;

namespace RunWoW.GameObjects
{
	public class DynamicGameObject
	{
		public static void Process(LivingObject user, GameObject go)
		{
			PlayerObject player = (PlayerObject) user;
			switch (go.DBGameObject.TemplateID)
			{
				case 18901: // Levers for Courtyard Door
				case 101811:
					{
						GameObject door = NearGO(player, 18895, 100);
						if (door != null)
						{
							door.State = door.State == 1 ? 0 : 1;
							door.UpdateData();

							ShortPacket pckg = new ShortPacket(SMSG.GAMEOBJECT_CUSTOM_ANIM);
							pckg.Write(go.GUID);
							pckg.Write(0);
							player.BackLink.Client.Send(pckg);
						}
						break;
					}
			}
		}


		private static GameObject NearGO(LivingObject unit, int goId, float range)
		{
			float rangesqrd = range*range;
			foreach (MapTile mapTile in unit.MapTile.Adjacents.Tiles)
				if (mapTile != null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection != null)
					{
						foreach (GameObject gameObject in collection)
						{
							if (gameObject != null && gameObject.Template.ObjectId == goId &&
							    gameObject.Position.DistanceFlatSqrd(unit.Position) < rangesqrd)
								return gameObject;
						}
					}
				}
			return null;
		}


		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			GOManager.RegisterType(GameObjectType.Dynamic, new GameObjectAction(Process));
		}
	}
}