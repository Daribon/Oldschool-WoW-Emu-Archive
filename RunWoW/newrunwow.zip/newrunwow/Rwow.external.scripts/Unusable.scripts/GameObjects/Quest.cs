using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunWoW.Vendors;

namespace RunWoW.GameObjects
{
	public class QuestGameObject
	{
		public static void Process(LivingObject user, GameObject go)
		{
			PlayerObject player = user as PlayerObject;
			if (player == null || player.IsDisposed)
				return;

			if (go.DBGameObject.EndQuests == null || go.DBGameObject.StartQuests == null)
				Database.Instance.ResolveRelations(go.DBGameObject, typeof(DBQuest));

			ICollection<DBQuestLog> qLog = PlayerQuests.GetEndQuestsForPlayer(player, go.DBGameObject.EndQuests);
			if (qLog != null && qLog.Count > 0)
			{
				foreach (DBQuestLog ql in qLog)
                {
					Quester.SendIncomplete(player.BackLink.Client, go.GUID, ql.Quest);
					//bool canComplete = PlayerQuests.QuestCompleted(player, qLog[i]);

					//ShortPacket pkg = new ShortPacket(SMSG.QUESTGIVER_REQUEST_ITEMS);
					//pkg.Write(go.GUID);
					//pkg.Write(qLog[i].Quest.ObjectId);
					//pkg.Write(qLog[i].Quest.Name);

					//if (canComplete)
					//{
					//    if (qLog[i].Quest.Complete.Length > 0)
					//        pkg.Write(qLog[i].Quest.Complete);
					//    else
					//        pkg.Write(qLog[i].Quest.Description);
					//}
					//else
					//    pkg.Write(qLog[i].Quest.Incomplete);

					//pkg.Write(0);   // Emote 
					//pkg.Write(1);
					//pkg.Write(1);   // Close after cancel
					//pkg.Write(0);  //  Required money

					//int reqCount = 0;
					//for (int k = 0; k < qLog[i].Quest.Target.Length; k++)
					//    if (qLog[i].Quest.Target[k].Type == 2 && qLog[i].Quest.Target[k].ID > 0)
					//        reqCount++;
					//pkg.Write(reqCount);

					//for (int k = 0; k < qLog[i].Quest.Target.Length; k++)
					//{
					//    if (qLog[i].Quest.Target[k].Type == 2 && qLog[i].Quest.Target[k].ID > 0)
					//    {
					//        pkg.Write(qLog[i].Quest.Target[k].ID);
					//        pkg.Write(qLog[i].Quest.Target[k].Count);
					//        DBItemTemplate item = (DBItemTemplate)
					//                              Database.Instance.FindObjectByKey(typeof(DBItemTemplate),
					//                                                                qLog[i].Quest.Target[k].ID);
					//        pkg.Write(item != null ? item.DisplayID : 0);   // Icon ID
					//    }
					//}
                    
					//pkg.Write(2);
					//pkg.Write(canComplete ? 3 : 2);
					//pkg.Write(0x04);
					//pkg.Write(0x08);
					//pkg.Write(0x10);
					//player.BackLink.Client.Send(pkg);

                    //}
                }
				return;
			}


			if (go.DBGameObject.StartQuests.Count == 0)
			{
				Chat.System(player.BackLink.Client, "No quests for this GO");
				return;
			}


			PooledList<DBQuest> quests;
			if (PlayerQuests.CheckPlayerQuests(player, go.DBGameObject.StartQuests, out quests) == QuestStatus.Available)
			{
				foreach(DBQuest quest in quests)
				{
					BinWriter tmp = new BinWriter();
					tmp.Write(go.GUID);
					tmp.Write(quest.ObjectId);
					tmp.Position = 0;
					BinReader read = new BinReader(tmp);
					Quester.QuestDetails(player.BackLink.Client, read);
				}
				//Chat.System(client, "Available quests for this GO " + quests.Length);
			}
			//else
			//		Chat.System(client, "No available quests for this GO");
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			GOManager.RegisterType(GameObjectType.QuestGiver, new GameObjectAction(Process));
		}
	}
}