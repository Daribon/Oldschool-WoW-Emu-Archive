using System;
using System.Collections.Generic;
using System.Text;
using RunWoW.Objects;

namespace RunWoW.ExternalScripts.GameObjects
{
	public interface IGoober
	{
		void GooberSelect(LivingObject user, GameObject go);
	}
}
