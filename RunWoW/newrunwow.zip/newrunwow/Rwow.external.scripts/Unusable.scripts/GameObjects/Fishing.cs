//
using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.GamePackets;
using RunWoW.Objects;
using RunWoW.Objects.Player;

namespace RunWoW.GameObjects
{
	public class FishingGameObject
	{
		public static void Process(LivingObject user, GameObject go)
		{
			PlayerObject player = user as PlayerObject;
			if (player == null || player.IsDisposed)
				return;

			if (!go.Used)
			{
				player.BackLink.Client.Send(new ShortPacket(SMSG.FISH_NOT_HOOKED));
				player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
			}
			else if (go.UseTime + TimeSpan.FromMilliseconds(Constants.FishingDelay) > CustomDateTime.Now)
			{
				go.GenerateLoot();
				PlayerSkill skill = player.Skills[SKILL.FISHING];
				float chance = skill.Level < 25 ? 1f : ((go.Level + 10)*5f - skill.Level)/50f;
				if (Utility.Chance(chance))
				{
					player.RaiseSkill(skill);
					player.UpdateData();
				}

				Loot.DoLoot(go, player);
			}
			else
			{
				player.BackLink.Client.Send(new ShortPacket(SMSG.FISH_ESCAPED));
				player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
			}
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			GOManager.RegisterType(GameObjectType.FishingBobber, new GameObjectAction(Process));
		}
	}
}