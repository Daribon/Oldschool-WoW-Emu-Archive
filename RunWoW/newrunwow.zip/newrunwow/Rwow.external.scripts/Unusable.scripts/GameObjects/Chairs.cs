//
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.GameObjects
{
	public class ChairGameObject
	{
		public static void Process(LivingObject user, GameObject go)
		{
			PlayerObject player = user as PlayerObject;
			if (player == null || player.IsDisposed)
				return;

			player.Facing = go.Facing;
			Teleport.TeleportTo(go.Position, player);
			player.StandState = UNITSTANDSTATE.SITTINGCHAIRLOW;
			player.UpdateData();
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			GOManager.RegisterType(GameObjectType.Chair, new GameObjectAction(Process));
		}
	}
}