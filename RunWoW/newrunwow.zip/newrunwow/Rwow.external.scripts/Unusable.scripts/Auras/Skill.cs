using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects.Player;

namespace RunWoW.SpellAuras
{
	public class SkillAura : BaseAura
	{
		private ushort m_value;
		private SKILL m_skill;
		private bool m_talent;


		protected override bool AuraStart()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return false;

			m_value = (ushort)Caster.SpellProcessor.FullValue(Spell, Effect);
			m_skill = (SKILL) SpellEffect.AuraParam;
			m_talent = SpellEffect.Aura == AURAEFFECT.MOD_SKILL_TALENT;

			PlayerSkill skill = PlayerTarget.Skills[m_skill];

			if (skill == null)
				return false;

			if (m_talent)
				skill.StartBonus += m_value;
			else
				skill.Bonus += m_value;

			PlayerTarget.Skills.UpdateSkill(m_skill);

			return true;
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed || PlayerTarget.Skills == null)
				return;

			PlayerSkill Skill = PlayerTarget.Skills[m_skill];

			if (m_talent)
				Skill.StartBonus -= m_value;
			else
				Skill.Bonus -= m_value;

			PlayerTarget.Skills.UpdateSkill(m_skill);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_SKILL, new AuraCast(Apply<SkillAura>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_SKILL_TALENT, new AuraCast(Apply<SkillAura>));
		}
	}
}