using System.Collections.Generic;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.Spells;

namespace RunWoW.SpellAuras
{
	public class ModAbsorbAura : BaseAura
	{
		private float m_value;
		private int m_type;
		private AbsorbCheckDelegate m_absorbCheck;

		protected override bool AuraStart()
		{
			if (Spell.Name == "Power Word: Shield")
				SpellManager.Cast(Caster, Target, 6788); // Weakened Soul

			if (Spell.Name == "Sacrifice" && LivingCaster != null)
				LivingCaster.Die();

			m_value = SpellEffect.Value;

			if (m_value > 0 && LivingTarget.Attackers != null && LivingCaster != null)
			{
				ICollection<LivingObject> toAttack = LivingTarget.Attackers.Values;

				foreach (LivingObject attacker in toAttack)
				{
					attacker.AddThreat(LivingCaster, m_value / 4);
					if (attacker.Position.Distance(LivingCaster.Position) < Constants.MonsterSightRange * 2)
						attacker.Attacked(LivingCaster);
				}
			}

			m_type = SpellEffect.AuraParam;
			m_absorbCheck = new AbsorbCheckDelegate(AbsorbCheck);
			LivingTarget.OnAbsorbCheck += m_absorbCheck;
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null)
				LivingTarget.OnAbsorbCheck -= m_absorbCheck;
		}

		public void AbsorbCheck(DAMAGETYPE damageType, bool spell, float damage, float resisted, out float absorbed)
		{
			int school = 1 << (int)damageType;

			if ((m_type & school) == school)
			{
				if (m_value > damage - resisted)
				{
					m_value -= damage - resisted;
					absorbed = damage - resisted;
				}
				else
				{
					absorbed = m_value;
					m_value = 0;
				}
			}
			else
				absorbed = 0;
			if (m_value <= 0)
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}


		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_DAMAGE_TAKEN, new AuraCast(Apply<ModAbsorbAura>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_SCHOOL_ABSORB, new AuraCast(Apply<ModAbsorbAura>));
		}
	}
}