using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class SchoolCritAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return false;

			if (LivingTarget.SpellProcessor is SpellModifiers)
				((SpellModifiers) LivingTarget.SpellProcessor).SetSchoolModifier(SPELLMODIFIER.CRIT_CHANCE, Spell.School,
				                                                                 SpellEffect.Value, !Visible);

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return;

			if (LivingTarget.SpellProcessor is SpellModifiers)
				((SpellModifiers) LivingTarget.SpellProcessor).RemoveSchoolModifier(SPELLMODIFIER.CRIT_CHANCE, Spell.School,
				                                                                    SpellEffect.Value, !Visible);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_SPELL_CRIT_CHANCE_SCHOOL, new AuraCast(Apply<SchoolCritAura>));
		}
	}
}