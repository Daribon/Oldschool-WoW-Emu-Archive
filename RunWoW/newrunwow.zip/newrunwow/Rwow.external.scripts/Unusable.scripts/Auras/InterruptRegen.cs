using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class InterruptRegenAura
	{
		public static SpellFailedReason Apply(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell,
		                                      byte efnum)
		{
			PlayerObject player = caster as PlayerObject;
			if (player != null)
				if (m_spell.SpellID == 2687)
				{
					int am = player.MaxHealth/10;
					if (player.Health < am)
						return SpellFailedReason.SPELL_FAILED_CASTER_AURASTATE;
					player.Health -= am;
				}
				else
					LogConsole.WriteLine(LogLevel.SYSTEM, "Casting INTERRUPT_REGEN spell {0}({1})", m_spell.Name, m_spell.ObjectId);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.INTERRUPT_REGEN, new AuraCast(Apply));
		}
	}
}