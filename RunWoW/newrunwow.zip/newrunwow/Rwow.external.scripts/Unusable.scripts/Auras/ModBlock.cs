using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class ModBlockAura : BaseAura
	{
		private ModifierPair m_mod;

		private int m_charges;

		private BlockDelegate m_onBlock;

		protected override bool AuraStart()
		{
			float value = Caster.SpellProcessor.FullValue(Spell, Effect);

			m_mod =
				LivingTarget.Modifiers.RegisterModifier(MODIFIER.BLOCK_PCT, value, !Visible ? UnitModifiers.DefaultKey : EffectKey);

			if (Spell.ProcCharges > 0)
			{
				m_charges = Spell.ProcCharges;
				m_onBlock = new BlockDelegate(OnBlock);
				LivingTarget.OnBlock += m_onBlock;
			}

			Cancelable = value > 0;

			return true;
		}

		private void OnBlock(float value)
		{
			m_charges--;
			if (LivingTarget != null && m_charges <= 0)
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed || LivingTarget.Modifiers == null)
				return;

			LivingTarget.Modifiers.UnregisterModifier(MODIFIER.BLOCK_PCT, m_mod);

			if (m_onBlock != null)
				LivingTarget.OnBlock -= m_onBlock;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_BLOCK_PERCENT, new AuraCast(Apply<ModBlockAura>));
		}
	}
}