using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.SpellAuras
{
	public class TauntAura : BaseAura
	{
		private const float TauntAggroValue = 100000f;

		protected override bool AuraStart()
		{
			if (LivingTarget == null || LivingCaster == null)
				return false;

			LivingTarget.AddThreat(Caster, TauntAggroValue);

			return true;
		}

		protected override void AuraFinish()
		{
			LivingTarget.AddThreat(Caster, -TauntAggroValue);

			base.AuraFinish();
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.TAUNT, new AuraCast(Apply<TauntAura>));
		}
	}
}