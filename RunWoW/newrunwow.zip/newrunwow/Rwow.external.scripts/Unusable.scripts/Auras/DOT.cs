using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Spells;

namespace RunWoW.SpellAuras
{
	public class DOTAura : BaseAura
	{
		private float m_amount;

		protected override bool AuraStart()
		{
			Cancelable = false;

			if (LivingTarget == null || Caster == null)
				return false;

			if (LivingCaster != null)
				LivingTarget.Attacked(LivingCaster);

			int bonus = 0;

			if (Spell.School == DAMAGETYPE.PHYSICAL && PlayerCaster != null)
			{
				if (SpellEffect.Combo != 0 && PlayerCaster.ComboPoints > 0)
				{
					if (PlayerCaster.ComboTarget == Target.GUID)
					{
						bonus += (int) (SpellEffect.Combo*PlayerCaster.ComboPoints);

						if (Spell.Name == "Rupture")
							Recalc(SpellEffect.AuraPeriod, PlayerCaster.SpellProcessor.Duration(Spell) + PlayerCaster.ComboPoints*2000);
					}

					PlayerCaster.ComboPoints = 0;
					PlayerCaster.ComboTarget = 0;
					PlayerCaster.UpdateData();
				}
				float coef = 0.6f;
				switch (Spell.Name)
				{
					case "Rupture":
						coef = 0.24f;
						break;
					case "Garrote":
						coef = 0.18f;
						break;
					case "Rip":
						coef = Spell.Rank*0.6f;
						if (coef > 0.24f)
							coef = 0.24f;
						break;
					case "Rend":
						coef = 0f;
						int mod = Spell.Rank + 2;
						if (mod > 7)
							mod = 7;

						bonus += (int) (0.00743*mod*
										((PlayerCaster.MinDamage + PlayerCaster.MaxDamage) / 2 +
										 PlayerCaster.AttackPower * PlayerCaster.AttackTime / 14000f));
						break;
				}
				if (coef != 0f)
					bonus += (int) (PlayerCaster.AttackPower*coef);
			}

			m_amount = Caster.SpellProcessor.PeriodicDamage(Spell, Effect, Count, bonus);

			if (m_amount < 0)
				m_amount = -m_amount;

			if (Spell.Channeled) // TODO: remake channeled spells
			{
				AuraTick();
				return false;
			}
			
			return true;
		}

		protected override void AuraTick()
		{
			if (LivingTarget == null || !LivingTarget.Attackable || Caster == null)
			{
				Finish();
				return;
			}

			bool alive;

			if (LivingCaster != null)
				alive = LivingCaster.SubmitPeriodicDamage(LivingTarget, Spell, Spell.School, m_amount, m_amount);
			else
				alive = LivingTarget.TakePeriodicDamage(Caster, Spell, Spell.School, m_amount, m_amount);

			if (Spell.ObjectId == 603 && !alive && Utility.Chance(0.1f)) // curse of doom, chance to call Doomguard
				SpellManager.Cast(LivingCaster, LivingCaster, 18662);
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			if (spell.ObjectId == 7914 && (int)target.Faction != 554) // Capture Spirit only on Burning Blade
				return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;


			IAura aura = new DOTAura();
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}
		
		
		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.PERIODIC_DAMAGE, new AuraCast(Apply));
		}
	}
}