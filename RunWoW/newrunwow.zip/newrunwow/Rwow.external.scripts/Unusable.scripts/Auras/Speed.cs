using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class SpeedAura : BaseAura
	{
		private ModifierPair m_mod;
		private bool m_mount;
		private HitDelegate m_canceler;

		protected override bool AuraStart()
		{
			m_mount = Spell.HasAura(AURAEFFECT.MOUNTED);

			float value = Caster.SpellProcessor.FullValue(Spell, Effect) / 100f;

			Cancelable = value > 0;

			LogConsole.WriteLine(LogLevel.ECHO, "Adding Speed aura value: " + value);

			if (LivingTarget.Modifiers == null && LivingTarget is UnitBase)
				((UnitBase) LivingTarget).Awake();

			if (Spell.Duration != 0 && LivingTarget.Modifiers != null)
			{
				m_mod =
					LivingTarget.Modifiers.RegisterModifier(MODIFIER.SPEED_PCT, value,
															!Visible ? UnitModifiers.DefaultKey : EffectKey);

				if (SpellEffect.Aura == AURAEFFECT.MOD_MOUNTED_SPEED || SpellEffect.Aura == AURAEFFECT.MOD_MOUNTED_SPEED_A)
				{
					m_canceler = new HitDelegate(CancelSpeed);
					LivingTarget.OnTakeDamage += m_canceler;
				}

				LivingTarget.Redress();
				LivingTarget.UpdateData();
			}
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed || LivingTarget.Modifiers == null)
				return;

			if (m_mod != null)
				if (m_mount)
					LivingTarget.Modifiers.UnregisterAllModifiers(MODIFIER.SPEED_PCT);
				else
					LivingTarget.Modifiers.UnregisterModifier(MODIFIER.SPEED_PCT, m_mod);

			if (m_canceler != null)
				LivingTarget.OnTakeDamage -= m_canceler;

			LivingTarget.Redress();
			LivingTarget.UpdateData();
			/*
			if ((!Constants.BurningCrusade && m_value <= -0.99f))
			{
				if (m_value <= -0.99f)
					LivingTarget.Flags &= ~4;
			}
			*/

			//if (LivingTarget.Auras != null)
			//    LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		public void CancelSpeed(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			if (damageType != Spell.School && Utility.Chance(damage/(Spell.SpellLevel*Constants.MaximumLevel)))
			{
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
			}
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_DEC_SPEED, new AuraCast(Apply<SpeedAura>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_INC_SPEED, new AuraCast(Apply<SpeedAura>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_MOUNTED_SPEED, new AuraCast(Apply<SpeedAura>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_INCREASE_SPEED_A, new AuraCast(Apply<SpeedAura>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_MOUNTED_SPEED_A, new AuraCast(Apply<SpeedAura>));
//			AuraManager.RegisterAura(AURAEFFECT.MOD_HASTE, new AuraCast(Apply));
		}
	}
}