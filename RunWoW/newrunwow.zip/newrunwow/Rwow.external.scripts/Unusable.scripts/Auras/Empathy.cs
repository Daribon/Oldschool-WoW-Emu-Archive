using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.SpellAuras
{
	public class EmpathyAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerCaster == null || LivingTarget == null)
				return false;

			LivingTarget.DynamicFlags &= 16;

			PlayerCaster.BackLink.Client.Send(
				new CompressedA9Packet(LivingTarget.SingleFieldPacket((int) UNITFIELDS.DYNAMIC_FLAGS)));

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null)
				return;

			LivingTarget.DynamicFlags = (uint) (LivingTarget.DynamicFlags & ~16);
		}


		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.EMPATHY, new AuraCast(Apply<EmpathyAura>));
		}
	}
}