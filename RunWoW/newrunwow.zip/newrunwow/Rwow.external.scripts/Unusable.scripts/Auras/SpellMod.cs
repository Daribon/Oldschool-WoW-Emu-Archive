using System.Collections;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class SpellModAura : BaseAura
	{
		private SPELLMODIFIER m_mod;
		private byte m_modcode;
		private SMSG m_code;


		public SpellModAura(SPELLMODIFIER mod, byte modcode)
		{
			m_mod = mod;
			m_modcode = modcode;
		}

		protected override bool AuraStart()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return false;

			if (LivingTarget.SpellProcessor is SpellModifiers)
				((SpellModifiers) LivingTarget.SpellProcessor).SetModifier((int) SpellEffect.Category, m_mod, Spell.School, SpellEffect.Value,
																		   !Visible, Spell.ObjectId);

			if (PlayerTarget != null)
			{
				m_code = (SpellEffect.Aura == AURAEFFECT.ADD_PCT_MODIFIER)
				         	? SMSG.SET_PCT_SPELL_MODIFIER
				         	: SMSG.SET_FLAT_SPELL_MODIFIER;

				BitArray barr = new BitArray(new int[] {(int) SpellEffect.Category});
				for (byte i = 0; i < 32; i++)
					if (barr[i])
					{
						ShortPacket pkg = new ShortPacket(m_code);
						pkg.Write(i);
						pkg.Write(m_modcode);
						pkg.Write(SpellEffect.Value);
						PlayerTarget.BackLink.Client.Send(pkg);
					}
			}
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return;

			if (LivingTarget.SpellProcessor is SpellModifiers)
				((SpellModifiers) LivingTarget.SpellProcessor).RemoveModifier((int) SpellEffect.Category, m_mod, Spell.School, SpellEffect.Value,
																			  !Visible, Spell.ObjectId);

			if (PlayerTarget != null)
			{
				BitArray barr = new BitArray(new int[] {(int) SpellEffect.Category});
				for (byte i = 0; i < 32; i++)
					if (barr[i])
					{
						ShortPacket pkg = new ShortPacket(m_code);
						pkg.Write(i);
						pkg.Write(m_modcode);
						pkg.Write(0);
						PlayerTarget.BackLink.Client.Send(pkg);
					}
			}
		}

		public static SpellFailedReason Apply(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell,
		                                      byte efnum)
		{
			if (!(target is PlayerObject))
				return SpellFailedReason.MAX;

			SPELLMODIFIER mod = SPELLMODIFIER.MAX;

			switch (spell.Effect[efnum].Aura)
			{
				case AURAEFFECT.ADD_PCT_MODIFIER:
					switch (spell.Effect[efnum].AuraParam)
					{
						case 0:
						case 3:
						case 8:
						case 22:
							mod = SPELLMODIFIER.PCT_DAMAGE;
							break;
						case 1: // duration
							mod = SPELLMODIFIER.PCT_CAST_TIME;
							break;
						case 2: // reduce threat + increase skill??
							break;
						case 5: // increase range
							mod = SPELLMODIFIER.PCT_RANGE;
							break;
						case 9: // chance to avoid interruption
							mod = SPELLMODIFIER.PCT_INTERRUPT;
							break;
						case 10: // reduce cast time (to instant)
							break;
						case 14: // reduce mana cost
							mod = SPELLMODIFIER.PCT_POWER_COST;
							break;
						case 15: // increase crit damage
							mod = SPELLMODIFIER.PCT_CRIT_DAMAGE;
							break;
						case 18: // chance to gain mana after crit
							break;
						case 20: // improve chain heal
							break;
						case 24: // bonus healing of hot
							break;
						case 26: // chance to stun
							break;
					}
					break;
				case AURAEFFECT.ADD_FLAT_MODIFIER:
					switch (spell.Effect[efnum].AuraParam)
					{
						case 1:
							mod = SPELLMODIFIER.DURATION;
							break;
						case 2:
							mod = SPELLMODIFIER.THREAT;
							break;
						case 5:
							mod = SPELLMODIFIER.RANGE;
							break;
						case 6:
							mod = SPELLMODIFIER.RANGE;
							break;
						case 7:
							mod = SPELLMODIFIER.CRIT_CHANCE;
							break;
						case 8:
						case 22:
							mod = SPELLMODIFIER.DAMAGE;
							break;
						case 10:
							mod = SPELLMODIFIER.CAST_TIME;
							break;
						case 11:
							mod = SPELLMODIFIER.COOLDOWN;
							break;
						case 12: // additional speed?
							break;
						case 14:
							mod = SPELLMODIFIER.POWER_COST;
							break;
						case 16: // chance to hit
							break;
						case 18: // chance to proc
							break;
						case 19:
							mod = SPELLMODIFIER.PERIOD;
							break;
						case 21: //
							break;
						case 23: // enslave demon
						case 24: // enslave demon
							break;
						case 26: // chance to stun
							break;
					}
					break;
			}
			
			if (mod==SPELLMODIFIER.MAX)
				return SpellFailedReason.MAX;
			
			IAura aura = new SpellModAura(mod, (byte) spell.Effect[efnum].AuraParam);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.ADD_FLAT_MODIFIER, new AuraCast(Apply));
			AuraManager.RegisterAura(AURAEFFECT.ADD_PCT_MODIFIER, new AuraCast(Apply));
		}
	}
}