using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Auras;

namespace RunWoW.SpellAuras
{
	public class TriggerDamage : BaseAura
	{
		#region static

		public static Dictionary<uint, float> PPMSpells = new Dictionary<uint, float>();

		static TriggerDamage()
		{
			PPMSpells[23578] = 4f; //	Expose Weakness	//	You have a chance whenever you deal ranged damage to apply an Expose Weakness effect to the target. Expose Weakness increases the ranged attack power of all attackers against that target by $23577s1 for $23577d.	
			PPMSpells[29633] = 4f; //	Fire Blast	//	Chance to strike your ranged target with a Fire Blast for $29644s1 Fire damage.	
			PPMSpells[27656] = 4f; //	Flame Lash	//	Chance to bathe your melee target in flames for $27655s1 Fire damage.	
			PPMSpells[28714] = 4f; //	Flamecap	//	Chance to strike a ranged or melee target for $28715s1 fire damage.   Also increases fire spell damage by up to $s1.  Lasts $d.	
			PPMSpells[29625] = 4f; //	Flaming Cannonball	//	Chance to strike your ranged target with a Flaming Cannonball for $29639s1 Fire damage.	
			PPMSpells[29635] = 4f; //	Flaming Shell	//	Chance to strike your ranged target with a Flaming Shell for $29647s1 Fire damage.	
			PPMSpells[37170] = 4f; //	Free Finisher Chance	//	Your attacks have a chance to make your next finishing move cost no energy.	
			PPMSpells[29501] = 4f; //	Frost Arrow	//	Chance to strike your target with a Frost Arrow for $29502s1 Frost damage.	
			PPMSpells[35264] = 4f; //	Frost Attack	//	Enchants your weapon with Frost.  Successful melee attacks have a chance to inflict $35263s1 Frost damage and slow the movement speed of the target by $35263s2% for $35263d.	
			PPMSpells[39086] = 4f; //	Frost Attack	//	Enchants your weapon with Frost.  Successful melee attacks have a chance to inflict $39087s1 Frost damage and slow the movement speed of the target by $39087s2% for $39087d.	
			PPMSpells[15600] = 4f; //	Hand of Justice	//	Chance on melee hit to gain 1 extra attack.	
			PPMSpells[28816] = 4f; //	Invigorate	//	Your normal melee swings have a chance to Invigorate you, healing you for $28817s1.	
			PPMSpells[29637] = 4f; //	Keeper's Sting	//	Chance to strike your ranged target with Keeper's Sting for $29655s1 Nature damage.	
			PPMSpells[21747] = 4f; //	Lawbringer	//	Gives the Paladin a chance on every melee hit to heal your party for $23544s1.	
			PPMSpells[23686] = 4f; //	Lightning Strike	//	Chance to strike your melee target with lightning for $23687s1 Nature damage.	
			PPMSpells[12284] = 4f; //	Mace Specialization	//	Gives your melee attacks a chance to stun your target for $5530d and generate $/10;5530s2 rage when using a Mace.	
			PPMSpells[12701] = 4f; //	Mace Specialization	//	Gives your melee attacks a chance to stun your target for $5530d and generate $/10;5530s2 rage when using a Mace.  More effective than Mace Specialization (Rank 1).	
			PPMSpells[12702] = 4f; //	Mace Specialization	//	Gives your melee attacks a chance to stun your target for $5530d and generate $/10;5530s2 rage when using a Mace.  More effective than Mace Specialization (Rank 2).	
			PPMSpells[12703] = 4f; //	Mace Specialization	//	Gives your melee attacks a chance to stun your target for $5530d and generate $/10;5530s2 rage when using a Mace.  More effective than Mace Specialization (Rank 3).	
			PPMSpells[12704] = 4f; //	Mace Specialization	//	Gives your melee attacks a chance to stun your target for $5530d and generate $/10;5530s2 rage when using a Mace.  More effective than Mace Specialization (Rank 4).	
			PPMSpells[34774] = 4f; //	Magtheridon Melee Trinket	//	Your melee and ranged attacks have a chance to increase your haste rating by $34775s1 for $34775d1.	
			PPMSpells[37555] = 4f; //	Mark of Light	//	Fills the caster with divine light for $d, giving each attack a chance to heal the caster for $27161s1.  Only one Mark can be active on the caster at any one time.	
			PPMSpells[35915] = 4f; //	Molten Armor	//	Causes $34913s1 Fire damage when hit, increases your chance to critically hit with spells by $s3%, and reduces the chance you are critically hit by $s2%.  Only one type of Armor spell can be active on the Mage at any time.  Lasts $d.	
			PPMSpells[16864] = 4f; //	Omen of Clarity	//	Imbues the Druid with natural energy.  Each of the Druid's melee attacks has a chance of causing the caster to enter a Clearcasting state.  The Clearcasting state reduces the Mana, Rage or Energy cost of your next damage or healing spell or offensive abili	
			PPMSpells[4242] = 4f; //	Pester	//	Decreases damage done while granting a chance to silence on hit.	
			PPMSpells[29634] = 4f; //	Quill Shot	//	Chance to strike your ranged target with a Quill Shot for $29646s1 Nature damage.	
			PPMSpells[35080] = 4f; //	Raid Faction Melee Ring	//	Chance on hit to increase your attack power by 160 for 10 seconds.	
			PPMSpells[27787] = 4f; //	Rogue Armor Energize	//	Chance on melee attack to restore 35 energy.	
			PPMSpells[34586] = 4f; //	Romeo's Poison	//	Your melee and ranged attacks have a chance to inject poison into your target dealing $34587s1 Nature damage.	
			PPMSpells[38290] = 4f; //	Santos' Blessing	//	Your ranged attacks have a chance to increase your attack power by 250 for 10 sec.	
			PPMSpells[20375] = 7f; //	Seal of Command	//	Gives the Paladin a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Only one Seal can be active on the Paladin at any one time.  Lasts $d.Unleashing this Seal's energy will judge an enemy, instantly causing $/2;20467s1 Ho	
			PPMSpells[20915] = 7f; //	Seal of Command	//	Gives the Paladin a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Only one Seal can be active on the Paladin at any one time.  Lasts $d.Unleashing this Seal's energy will judge an enemy, instantly causing $/2;20963s1 Ho	
			PPMSpells[20918] = 7f; //	Seal of Command	//	Gives the Paladin a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Only one Seal can be active on the Paladin at any one time.  Lasts $d.Unleashing this Seal's energy will judge an enemy, instantly causing $/2;20964s1 Ho	
			PPMSpells[20919] = 7f; //	Seal of Command	//	Gives the Paladin a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Only one Seal can be active on the Paladin at any one time.  Lasts $d.Unleashing this Seal's energy will judge an enemy, instantly causing $/2;20965s1 Ho	
			PPMSpells[20920] = 7f; //	Seal of Command	//	Gives the Paladin a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Only one Seal can be active on the Paladin at any one time.  Lasts $d.Unleashing this Seal's energy will judge an enemy, instantly causing $/2;20966s1 Ho	
			PPMSpells[27170] = 7f; //	Seal of Command	//	Gives the Paladin a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Only one Seal can be active on the Paladin at any one time.  Lasts $d.Unleashing this Seal's energy will judge an enemy, instantly causing $/2;27171s1 Ho	
			PPMSpells[29385] = 7f; //	Seal of Command	//	Gives the caster a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Lasts $d.	
			PPMSpells[33127] = 7f; //	Seal of Command	//	Gives the Paladin a chance to deal additional Holy damage equal to $20424s1% of normal weapon damage.  Only one Seal can be active on the Paladin at any one time.  Lasts $d.Unleashing this Seal's energy will judge an enemy, instantly causing $/2;27171s1 Ho	
			PPMSpells[20164] = 5f; //	Seal of Justice	//	Fills the Paladin with the spirit of justice for $d, giving each melee attack a chance to stun for $20170d.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20184d, preventing them from flee	
			PPMSpells[31895] = 5f; //	Seal of Justice	//	Fills the Paladin with the spirit of justice for $d, giving each melee attack a chance to stun for $20170d.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20184d, preventing them from flee	
			PPMSpells[20165] = 4f; //	Seal of Light	//	Fills the Paladin with divine light for $d, giving each melee attack a chance to heal the Paladin for $20167s1.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20185d, granting melee attack	
			PPMSpells[20347] = 4f; //	Seal of Light	//	Fills the Paladin with divine light for $d, giving each melee attack a chance to heal the Paladin for $20333s1.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20344d, granting melee attack	
			PPMSpells[20348] = 4f; //	Seal of Light	//	Fills the Paladin with divine light for $d, giving each melee attack a chance to heal the Paladin for $20334s1.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20345d, granting melee attack	
			PPMSpells[20349] = 4f; //	Seal of Light	//	Fills the Paladin with divine light for $d, giving each melee attack a chance to heal the Paladin for $20340s1.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20346d, granting melee attack	
			PPMSpells[27160] = 4f; //	Seal of Light	//	Fills the Paladin with divine light for $d, giving each melee attack a chance to heal the Paladin for $27161s1.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $27162d, granting melee attack	
			PPMSpells[20166] = 4f; //	Seal of Wisdom	//	Fills the Paladin with divine wisdom for $d, giving each melee attack a chance to restore $20168s1 of the Paladin's mana.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20186d, granting at	
			PPMSpells[20356] = 4f; //	Seal of Wisdom	//	Fills the Paladin with divine wisdom for $d, giving each melee attack a chance to restore $20350s1 of the Paladin's mana.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20354d, granting at	
			PPMSpells[20357] = 4f; //	Seal of Wisdom	//	Fills the Paladin with divine wisdom for $d, giving each melee attack a chance to restore $20351s1 of the Paladin's mana.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $20355d, granting at	
			PPMSpells[27166] = 4f; //	Seal of Wisdom	//	Fills the Paladin with divine wisdom for $d, giving each melee attack a chance to restore $27167s1 of the Paladin's mana.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will judge an enemy for $27164d, granting at	
			PPMSpells[29624] = 4f; //	Searing Arrow	//	Chance to strike your ranged target with a Searing Arrow for $29638s1 Fire damage.	
			PPMSpells[29632] = 4f; //	Shadow Shot	//	Chance to strike your ranged target with Shadow Shot for $29641s1 Shadow damage.	
			PPMSpells[29626] = 4f; //	Shadowbolt	//	Chance to strike your ranged target with a Shadowbolt for $29640s1 Shadow damage.	
			PPMSpells[30823] = 4f; //	Shamanistic Rage	//	Gives your successful melee attacks a chance to regenerate mana equal to $s1% of your attack power.  Lasts $d.	
			PPMSpells[35004] = 4f; //	Spore Cloud	//	Diseases an enemy for $d., increasing the damage it takes by $s1. Inflicts nature damage to an enemy every $t1 sec. for $d.  The diseased target has a chance of spreading its illness to one of its nearby allies.	
			PPMSpells[29636] = 4f; //	Venom Shot	//	Chance to strike your ranged target with a Venom Shot for $29653s1 Nature damage.	
			PPMSpells[9452] = 4f; //	Vindication	//	Gives the Paladin's damaging melee attacks a chance to reduce the target's Strength and Agility by $67s1% for $67d.	
			PPMSpells[26016] = 4f; //	Vindication	//	Gives the Paladin's damaging melee attacks a chance to reduce the target's Strength and Agility by $26017s1% for $26017d.	
			PPMSpells[26021] = 4f; //	Vindication	//	Gives the Paladin's damaging melee attacks a chance to reduce the target's Strength and Agility by $26018s1% for $26018d.	
			PPMSpells[27419] = 4f; //	Warrior's Resolve	//	Chance on melee attack to heal you for $27418s1.	
			PPMSpells[25715] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20286s1 Holy damage to an enemy.	
			PPMSpells[25727] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20285s1 Holy damage to an enemy.	
			PPMSpells[25728] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20284s1 Holy damage to an enemy.	
			PPMSpells[25729] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20283s1 Holy damage to an enemy.	
			PPMSpells[25730] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20282s1 Holy damage to an enemy.	
			PPMSpells[25731] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20281s1 Holy damage to an enemy.	
			PPMSpells[25732] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20280s1 Holy damage to an enemy.	
			PPMSpells[25733] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.Unleashing this Seal's energy will cause $20187s1 Holy damage to an enemy.	
			PPMSpells[25734] = 5f; //	zzOLD Seal of Righteousness	//	Fills the Paladin with holy spirit for $d, giving each melee attack a chance to cause $s1 additional Holy damage.  Only one Seal can be active on the Paladin at any one time.	
		}


		#endregion

		private float m_chance;
		private BitArray m_bitflags;

		private DateTime m_lastProc;

		private HitDelegate m_takeDamage;
		private HitDelegate m_placeDamage;

		private TimeSpan m_procDelay;

		private int m_charges;

		protected override bool AuraStart()
		{
			if (Target == null || LivingCaster == null)
				return false;

			m_chance = Spell.ProcChance/100f;

			if (m_chance == 0)
				m_chance = 1f;

			if (PPMSpells.ContainsKey(Spell.ObjectId))
				m_procDelay = TimeSpan.FromSeconds(60/PPMSpells[Spell.ObjectId]);
			else
				m_procDelay = TimeSpan.FromMilliseconds(Constants.SpellProcDelay);

			m_bitflags = new BitArray(new int[] {Spell.ProcFlags});

			LogConsole.WriteLine(LogLevel.ECHO, "Registering proc spell {0}. flags {1}, {2}", Spell, m_bitflags.ToString(),
			                     Spell.ProcFlags);
			/*
			 * 
			 * Burning Crusade Proc Flags
			 * 0 - ??
			 * 1 - none
			 * 2 - on kill
			 * 3:4 - on submit damage (melee)
			 * 4:8 - on take damage (melee)
			 * 5:16 - on submit damage (used with 3)
			 * 6:32 - on take damage (used with 8)
			 * 7:64 - on submit ranged damage
			 * 8:128 - on take randed damage
			 * 9:256 - on submit magic damage
			 * 10:512 - on take magic damage
			 * 11:1024 - combo proc
			 * 12:2048 - none
			 * larger - some complex flags
			 */

			if (m_bitflags[2] || m_bitflags[4] || m_bitflags[6] || m_bitflags[8])
			{
				m_placeDamage = new HitDelegate(OnPlaceHitProc);
				LivingTarget.OnSubmitDamage += m_placeDamage;
			}
			if (m_bitflags[3] || m_bitflags[5] || m_bitflags[7] || m_bitflags[9])
			{
				m_takeDamage = new HitDelegate(OnTakeHitProc);
				LivingTarget.OnTakeDamage += m_takeDamage;
			}

			m_lastProc = CustomDateTime.Now;
			return true;
		}

		protected override void AuraFinish()
		{
            if (LivingTarget != null)
			{
				if (m_placeDamage != null)
                    LivingTarget.OnSubmitDamage -= m_placeDamage;
				if (m_takeDamage != null)
                    LivingTarget.OnTakeDamage -= m_takeDamage;
			}
		}

		public void OnTakeHitProc(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;

			if (m_lastProc + m_procDelay > CustomDateTime.Now)
				return;

			if (
						(m_bitflags[3] && category == DAMAGECATEGORY.MELEE) ||
						(m_bitflags[5] && category == DAMAGECATEGORY.MELEE) ||
						(m_bitflags[7] && category == DAMAGECATEGORY.RANGED) ||
						(m_bitflags[9] && category == DAMAGECATEGORY.MAGIC)
				)
			{
				m_lastProc = CustomDateTime.Now;

                if (Utility.Chance(m_chance /*+ 0.02f * (LivingTarget.Level - enemy.Level)*/))
                {
                    int mindamage = Caster.SpellProcessor.PureDamage(Spell, Effect);
                    int maxdamage = Caster.SpellProcessor.FullDamage(Spell, Effect);

                    LivingTarget.SubmitMagicDamage(lenemy, Spell, Spell.School, mindamage, maxdamage);
                    if (m_charges != 0)
                    {
                        m_charges--;
                        if (m_charges == 0)
                            LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
                    }
                }
			}
		}

		public void OnPlaceHitProc(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;

			if (m_lastProc + m_procDelay > CustomDateTime.Now)
				return;

			if (
						(m_bitflags[2] && category == DAMAGECATEGORY.MELEE) ||
						(m_bitflags[4] && category == DAMAGECATEGORY.MELEE) ||
						(m_bitflags[6] && category == DAMAGECATEGORY.RANGED) ||
						(m_bitflags[8] && category == DAMAGECATEGORY.MAGIC)
				)
			{
				m_lastProc = CustomDateTime.Now;

                if (Utility.Chance(m_chance + 0.02f * (LivingTarget.Level - enemy.Level)))
				{
                    int mindamage = Caster.SpellProcessor.PureDamage(Spell, Effect);
                    int maxdamage = Caster.SpellProcessor.FullDamage(Spell, Effect);

					PlayerObject player = Caster as PlayerObject;

					if (player != null && Spell.Name == "Seal of Righteousness") // it is broken now
					{
						float speedCoef = player.AttackTime/(3000f*SpellEffect.Speed);
						if (player.IsTwoHanded)
							speedCoef *= 1.5f;
						//Console.WriteLine("Seal of Righteousness cast. damage {0}-{1} >> to {2}, {3}, coef {4}", mindamage, maxdamage, (int)(mindamage * speedCoef), (int)(maxdamage * speedCoef), speedCoef);
						mindamage = (int)(mindamage * speedCoef);
						maxdamage = (int) (maxdamage*speedCoef);
					}

					LivingTarget.SubmitMagicDamage(lenemy, Spell, Spell.School, mindamage, maxdamage);
					if (m_charges != 0)
					{
						m_charges--;
						if (m_charges == 0)
							LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
					}
				}
			}
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
            AuraManager.RegisterAura(AURAEFFECT.TRIGGER_DAMAGE, new AuraCast(Apply<TriggerDamage>));

			AuraManager.RegisterAuraEffectPatch(20154, 0, new AuraCast(Apply<TriggerDamage>)); // Seal of Righteousness
			AuraManager.RegisterAuraEffectPatch(20287, 0, new AuraCast(Apply<TriggerDamage>));
			AuraManager.RegisterAuraEffectPatch(20288, 0, new AuraCast(Apply<TriggerDamage>));
			AuraManager.RegisterAuraEffectPatch(20289, 0, new AuraCast(Apply<TriggerDamage>));
			AuraManager.RegisterAuraEffectPatch(20290, 0, new AuraCast(Apply<TriggerDamage>));
			AuraManager.RegisterAuraEffectPatch(20291, 0, new AuraCast(Apply<TriggerDamage>));
			AuraManager.RegisterAuraEffectPatch(20292, 0, new AuraCast(Apply<TriggerDamage>));
			AuraManager.RegisterAuraEffectPatch(20293, 0, new AuraCast(Apply<TriggerDamage>));
			AuraManager.RegisterAuraEffectPatch(27155, 0, new AuraCast(Apply<TriggerDamage>)); // rank 9
			
		}
	}
}