using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ExternalScripts.Battlegrounds;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class ImmunityAura : BaseAura
	{
		private int m_type;
		private ImmuneCheckDelegate m_immuneCheck;

		protected override bool AuraStart()
		{
			m_type = SpellEffect.AuraParam;
			m_immuneCheck = new ImmuneCheckDelegate(ImmuneCheck);
			LivingTarget.OnImmuneCheck += m_immuneCheck;

			if (Spell.ObjectId == 6788)
				Cancelable = false;
			if (Spell.ObjectId == 23333 || Spell.ObjectId == 23335)
				Cancelable = true;

			if (SpellEffect.Aura == AURAEFFECT.MECHANIC_IMMUNITY)
				LivingTarget.Auras.RemoveAuras(SpellEffect.Value, (MechanicDispelType)SpellEffect.AuraParam);

			return true;
		}

		public bool ImmuneCheck(DAMAGETYPE damageType, DAMAGECATEGORY damageCategory, DBSpell spell)
		{
			switch(SpellEffect.Aura)
			{
				case AURAEFFECT.EFFECT_IMMUNITY:
					break;
				case AURAEFFECT.SCHOOL_IMMUNITY:
					int school = 1 << (int) damageType;
					
					if ((m_type & school) == school)
						return true;
					break;
				case AURAEFFECT.MECHANIC_IMMUNITY:
					if (spell != null && spell.MechanicDispelType == (MechanicDispelType)SpellEffect.AuraParam)
						return true;
					break;
			}

			return false;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.Disposed)
				return;

			LivingTarget.OnImmuneCheck -= m_immuneCheck;

			switch (Spell.ObjectId)
			{
				case 23333:
				case 23335:
					BattleManager.CancelAura(Spell.ObjectId, LivingTarget);
					break;
			}
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.EFFECT_IMMUNITY, new AuraCast(Apply<ImmunityAura>));
			AuraManager.RegisterAura(AURAEFFECT.SCHOOL_IMMUNITY, new AuraCast(Apply<ImmunityAura>));
			AuraManager.RegisterAura(AURAEFFECT.DAMAGE_IMMUNITY, new AuraCast(Apply<ImmunityAura>));
			AuraManager.RegisterAura(AURAEFFECT.MECHANIC_IMMUNITY, new AuraCast(Apply<ImmunityAura>));
		}
	}
}