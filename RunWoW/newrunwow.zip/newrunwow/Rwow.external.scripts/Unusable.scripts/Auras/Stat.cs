using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class StatAura : BaseAura
	{
		private ModifierPair m_mod;
		private MODIFIER m_index;

		protected override bool AuraStart()
		{
			float value = Caster.SpellProcessor.FullValue(Spell, Effect);

			Cancelable = value > 0;

			switch (SpellEffect.AuraParam)
			{
				case 0:
					m_index = Cancelable ? MODIFIER.STR_POS : MODIFIER.STR_NEG;
					break;
				case 1:
					m_index = Cancelable ? MODIFIER.AGL_POS : MODIFIER.AGL_NEG;
					break;
				case 2:
					m_index = Cancelable ? MODIFIER.STA_POS : MODIFIER.STA_NEG;
					break;
				case 3:
					m_index = Cancelable ? MODIFIER.INT_POS : MODIFIER.INT_NEG;
					break;
				case 4:
					m_index = Cancelable ? MODIFIER.SPI_POS : MODIFIER.SPI_NEG;
					break;
				case -1:
					m_index = Cancelable ? MODIFIER.ALLSTAT_POS : MODIFIER.ALLSTAT_NEG;
					break;
				default:
					LogConsole.WriteLine(LogLevel.ERROR, "Unknown stat type " + SpellEffect.AuraParam);
					return false;
			}
			LogConsole.WriteLine(LogLevel.ECHO, "Adding stat aura value: {0}, stat: {1}, m_index: {2}", value,
			                     SpellEffect.AuraParam, m_index);

			m_mod =
				LivingTarget.Modifiers.RegisterModifier(m_index, value,
				                                       !Visible ? UnitModifiers.DefaultKey : EffectKey);

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed || LivingTarget.Modifiers == null)
				return;

			LivingTarget.Modifiers.UnregisterModifier(m_index, m_mod);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_STAT, new AuraCast(Apply<StatAura>));
		}
	}
}