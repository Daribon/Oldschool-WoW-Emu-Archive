using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class ConfuseAura : BaseAura
	{
		private HitDelegate m_canceler;

		protected override bool AuraStart()
		{
			if (LivingTarget == null)
				return false;

			Cancelable = false;

			if (Target is UnitBase)
				LivingTarget.Pacified = true;
			else
				LivingTarget.NoControl = true;

			LivingTarget.Flags |= 4;
			LivingTarget.MovementFlags |= ~31; // =)

			m_canceler = new HitDelegate(Cancel);
			LivingTarget.OnTakeDamage += m_canceler;

			if (PlayerTarget != null)
				PlayerTarget.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null)
				return;

			if (Target is UnitBase)
				LivingTarget.Pacified = false;
			else
				LivingTarget.NoControl = false;
			LivingTarget.Flags &= ~4;
			LivingTarget.MovementFlags = 0;

			LivingTarget.OnTakeDamage -= m_canceler;
		}

		public void Cancel(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy,
		                   bool critical)
		{
			if (LivingTarget != null && LivingTarget.Auras != null)
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			if (target is PlayerObject && ((PlayerObject) target).IsFeralForm)
				return SpellFailedReason.SPELL_FAILED_TARGET_AURASTATE;

			IAura aura = new ConfuseAura();
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.CONFUSE, new AuraCast(Apply));
		}
	}
}