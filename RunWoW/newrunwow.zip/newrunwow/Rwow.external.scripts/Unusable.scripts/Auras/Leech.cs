using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class LeechAura : BaseAura
	{
		private float m_amount = 0;
		private bool m_manaLeech = false;

		private LeechAura(bool manaLeech)
		{
			m_manaLeech = manaLeech;
		}

		protected override bool AuraStart()
		{
			Cancelable = false;

			if (LivingTarget == null || LivingCaster == null)
				return false;

			LivingTarget.Attacked(LivingCaster);

			m_amount = Caster.SpellProcessor.PeriodicDamage(Spell, Effect, Count, 0);

			if (m_amount < 0)
				m_amount = -m_amount;

			if (Spell.Channeled) // TODO: remake channeled spells
			{
				AuraTick();
				return false;
			}

			return true;
		}

		protected override void AuraTick()
		{
			if (LivingTarget == null || !LivingTarget.Attackable || LivingCaster == null || !LivingCaster.Attackable)
			{
				Finish();
				return;
			}

			int value = (int) m_amount;

			if (m_manaLeech)
			{
				if (value > LivingTarget.Power)
				{
					value = LivingTarget.Power;
                    if (value == 0)
                    {
                        Finish();
                        return;
                    }
				}

				LivingTarget.Power -= value;
				LivingCaster.Power += value;

				if (LivingCaster.Power > LivingCaster.MaxPower)
					LivingCaster.Power = LivingCaster.MaxPower;
			}
			else
			{
				if (value > LivingTarget.Health)
				{
					value = LivingTarget.Health;
                    if (value == 0)
                    {
                        Finish();
                        return;
                    }
				}

				LivingCaster.SubmitPeriodicDamage(LivingTarget, Spell, Spell.School, value, value);
				LivingCaster.Health += value;

				if (LivingCaster.Health > LivingCaster.MaxHealth)
					LivingCaster.Health = LivingCaster.MaxHealth;
			}

			LivingCaster.UpdateData();
			LivingTarget.UpdateData();

			// Generate agro
			if (LivingCaster != null && !LivingTarget.Dead)
			{
				LivingTarget.AddThreat(LivingCaster, value / 2, value);
				LivingTarget.Attacked(LivingCaster);
			}
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			bool manaLeech = spell.Effect[efnum].Aura == AURAEFFECT.PERIODIC_MANA_LEECH;

			if (manaLeech)
			{
				if (target.PowerType != POWERTYPE.MANA)
					return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
				if (target.Power <= 0)
					return SpellFailedReason.SPELL_FAILED_TARGET_AURASTATE;
			}
			else if (target.Health <= 0)
				return SpellFailedReason.SPELL_FAILED_TARGET_AURASTATE;


			IAura aura = new LeechAura(manaLeech);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.PERIODIC_MANA_LEECH, new AuraCast(Apply));
			AuraManager.RegisterAura(AURAEFFECT.PERIODIC_LEECH, new AuraCast(Apply));
		}
	}
}