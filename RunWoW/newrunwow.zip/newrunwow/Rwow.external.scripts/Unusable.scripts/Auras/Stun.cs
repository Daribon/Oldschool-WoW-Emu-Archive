using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class StunAura : BaseAura
	{
		private HitDelegate m_canceler;
		private bool m_interrupts;
		private int m_duration;

		private StunAura(int duration, bool interrupts)
		{
			m_duration = duration;
			m_interrupts = interrupts;
		}

		protected override bool AuraStart()
		{
			if (LivingTarget == null || LivingTarget.Stunned)
				return false;
			
			Cancelable = false;

			Recalc(SpellEffect.AuraPeriod, m_duration);

			LivingTarget.Flags |= 0x40004;
			LivingTarget.Stunned = true;
			LivingTarget.MovementFlags &= ~31;

			if (PlayerTarget != null)
			{
				if (Constants.BurningCrusade)
				{
					//int timePos;
					//ShortPacket pkg = Movement.MakeMovement(SMSG.MOVE_ROOT, PlayerTarget, 0, out timePos);

					//    /*new ShortPacket(SMSG.MOVE_ROOT);
					//pkg.WriteGuid(PlayerTarget.GUID);
					//pkg.Write(PlayerTarget.MovementFlags);
					//int timePos = pkg.BaseStream.Position;
					//pkg.Write(Utility.PreciseTimestamp());
					//pkg.WriteVector(PlayerTarget.Position);
					//pkg.Write(PlayerTarget.Facing);
					//pkg.Write(0);*/

					//PlayerTarget.MapTile.SendSurroundingTimed(pkg, PlayerTarget, null, timePos);
				}
				else
				{
					ShortPacket pkg = new ShortPacket(SMSG.MOVE_ROOT);
					pkg.Write(PlayerTarget.GUID);
					pkg.Write(2);
					PlayerTarget.BackLink.Client.Send(pkg);
				}
			} else
				MonsterMove.FixPosition(LivingTarget);

			if (m_interrupts)
			{
				m_canceler = new HitDelegate(Cancel);
				LivingTarget.OnTakeDamage += m_canceler;
			}
			
			if (PlayerTarget != null)
				PlayerTarget.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED); // cancel cast

			if (PlayerCaster != null && (PlayerCaster.Flags & 0x2000000) == 0x2000000) // cancel caster stealth
				PlayerCaster.Auras.CancelAuraForce(PlayerCaster.MountSpell);

			return true;
		}

		private void Cancel(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
			if (Spell.Channeled && LivingCaster.Casting)
				LivingCaster.CastEvent.Finish(EventResult.COMPLETED);
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return;

			if (PlayerTarget != null)
			{
				if (Constants.BurningCrusade)
				{
					//int timePos;
					//ShortPacket pkg = Movement.MakeMovement(SMSG.MOVE_UNROOT, PlayerTarget, 0, out timePos);

					///*ShortPacket pkg = new ShortPacket(SMSG.MOVE_UNROOT);
					//pkg.WriteGuid(PlayerTarget.GUID);
					//pkg.Write(PlayerTarget.MovementFlags);
					//int timePos = pkg.BaseStream.Position;
					//pkg.Write(0);
					//pkg.WriteVector(PlayerTarget.Position);
					//pkg.Write(PlayerTarget.Facing);
					//pkg.Write(0);
					//*/
					//PlayerTarget.MapTile.SendSurroundingTimed(pkg, PlayerTarget, null, timePos);
				}
				else
				{
					ShortPacket pkg = new ShortPacket(SMSG.MOVE_UNROOT);
					pkg.Write(PlayerTarget.GUID);
					PlayerTarget.BackLink.Client.Send(pkg);
				}
			}

			LivingTarget.Flags &= ~0x40004;
			LivingTarget.Stunned = false;

			if (m_canceler != null)
				LivingTarget.OnTakeDamage -= m_canceler;
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			//if (target.Stunned)
			//    return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;

			//  Some spells have duration = 0 , and it cause stun for ever..

			if (target is UnitBase && target.Level > 60 && ((UnitBase)target).Creature.Elite>0)
				return SpellFailedReason.SPELL_FAILED_IMMUNE;

			int duration = spell.Duration <= 0 ? 500 : spell.Duration;
			
			bool interrupts = spell.Interrupts;

			// Flags_0 & 262160    Flags_1 & 512  seems used for combo but not enough info, TODO:
			switch (spell.SpellID)
			{
				case 408: // Kidney shot - stuns enemy for time in sec depends from combo points.
				case 8643:
					if (caster is PlayerObject)
					{
						PlayerObject player = (PlayerObject) caster;
						if (player.ComboPoints == 0)
							return SpellFailedReason.SPELL_FAILED_NO_COMBO_POINTS;
						duration = (player.ComboPoints + (spell.SpellID == 8643 ? 1 : 0))*1000;
						player.ComboPoints = 0;
						player.UpdateData();
					}
					break;

				// TODO:  Need to find flags where this interrupts defined.
				case 19386:
				case 24132:
				case 24133:
					interrupts = true;
					break;

				// seduction
				case 6358:
				case 29490:
				case 30850:
				case 31865:
					interrupts = true;
					break;
			}

			IAura aura = new StunAura(duration, interrupts);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.STUN, new AuraCast(Apply));
		}
	}
}