using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class RegenHealthAura : BaseAura
	{
		private float m_amount;

		protected override bool AuraStart()
		{
			if (LivingTarget == null || Caster == null)
				return false;

			if (SpellEffect.AuraPeriod == 0)
			{
				Recalc(1000, Spell.Duration);
				m_amount = SpellEffect.Value/5;
				m_amount = Caster.SpellProcessor.ProcessDamage(Spell, m_amount, Count);
			} else
			{
				Recalc(SpellEffect.AuraPeriod, Spell.Duration);

				m_amount = Caster.SpellProcessor.PeriodicDamage(Spell, Effect, Count, 0);
			}

			if (m_amount <= 0)
				m_amount = 1;

			if (Spell.Food &&
			    (LivingTarget.StandState == UNITSTANDSTATE.STANDING || LivingTarget.StandState == UNITSTANDSTATE.KNEEL)
				)
			{
				LivingTarget.StandState = UNITSTANDSTATE.SITTING;
				LivingTarget.UpdateData();
			}

			if (Spell.Channeled) // TODO: remake channeled spells
			{
				AuraTick();
				return false;
			}

			LogConsole.WriteLine(LogLevel.ECHO, "Starting regen for {0} steps and amount {1}", Count, m_amount);

			return true;
		}

		protected override void AuraTick()
		{
			if (LivingTarget == null || !LivingTarget.Attackable)
			{
				Finish();
				return;
			}

			if (Spell.Food &&
			    (LivingTarget.StandState == UNITSTANDSTATE.STANDING || LivingTarget.StandState == UNITSTANDSTATE.KNEEL)
				)
			{
				Finish();
				return;
			}

			int value = (int) m_amount;
			if (value + LivingTarget.Health > LivingTarget.MaxHealth)
				value = LivingTarget.MaxHealth - LivingTarget.Health;

			// Hunter:  Some time unit.Attackers is null. I add checking and make log..
			if (value > 0 && LivingTarget.Attackers != null && LivingCaster != null)
			{
				ICollection<LivingObject> toAttack = LivingTarget.Attackers.Values;

				foreach (LivingObject attacker in toAttack)
					attacker.AddThreat(LivingCaster, value/2);
			}

			if (value > 0)
				LivingTarget.Health += value;

			if (Spell.Food && Count % 5 == 0 && PlayerTarget != null && !PlayerTarget.IsDisposed)
			{
				ShortPacket pkg = new ShortPacket(SMSG.PLAY_SPELL_VISUAL);
				pkg.Write(Target.GUID);
				pkg.Write(406);
				PlayerTarget.BackLink.Client.Send(pkg);
			}
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_REGEN, new AuraCast(Apply<RegenHealthAura>));
			AuraManager.RegisterAura(AURAEFFECT.PERIODIC_HEAL, new AuraCast(Apply<RegenHealthAura>));
		}
	}
}