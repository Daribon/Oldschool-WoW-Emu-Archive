using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.ServerDatabase;

namespace RunWoW.ExternalScripts.MiscPackets
{
	[PacketHandlerClass()]
	public class TutorialHandler
	{
		[PacketHandler(CMSG.TUTORIAL_FLAG)]
		public static void HandleTutorialFlag(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Character == null)
				return;

			int flag = data.ReadInt32();

			Client.Character.TutorialFlags[flag / 32] |= 1 << (flag % 32);
			Client.Character.Dirty = true;
			
			DBManager.SaveDBObject(Client.Character);
		}

		[PacketHandler(CMSG.TUTORIAL_CLEAR)]
		public static void HandleTutorialClear(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Character == null)
				return;
			for (int i = 0; i < Client.Character.TutorialFlags.Length; i++)
				Client.Character.TutorialFlags[i] = -1;
			Client.Character.Dirty = true;
			
			DBManager.SaveDBObject(Client.Character);
		}

		[PacketHandler(CMSG.TUTORIAL_RESET)]
		public static void HandleTutorialReset(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Character == null)
				return;
			for (int i = 0; i < Client.Character.TutorialFlags.Length; i++)
				Client.Character.TutorialFlags[i] = 0;
			Client.Character.Dirty = true;

			DBManager.SaveDBObject(Client.Character);
		}
	}
}