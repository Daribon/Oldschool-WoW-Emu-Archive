using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.MiscPackets;
using RunWoW.ServerDatabase;

namespace RunWoW.ExternalScripts.MiscPackets
{
	public class AuctionNotifyEvent : Event
	{
		private static AuctionNotifyEvent Instance = new AuctionNotifyEvent();

		public AuctionNotifyEvent() : base(TimeSpan.FromMinutes(1.0), TimeSpan.FromMinutes(10.0))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			long timein = CustomDateTime.Now.Ticks;
			ICollection auctions =
				Database.Instance.SelectObjects(typeof (DBAuction),
				                                "ExpirationTime <= " +
				                                Database.Instance.PrepareData(typeof (DBAuction), CustomDateTime.Now));

			foreach (DBAuction auction in auctions)
			{
				DBItem item = (DBItem) Database.Instance.FindObjectByKey(typeof (DBItem), auction.ItemID);

				if (item == null)  // Item does not exist - need remove auction
				{
					ICollection bids = Database.Instance.FindObjectsByField(typeof(DBBid), "AuctionID", auction.ObjectId);
					foreach (DBBid bid in bids)
						DBManager.EraseDBObject(bid);
					DBManager.EraseDBObject(auction);
					continue;
				}

				if (auction.LastBid == 0) // Auction have no bids - auction expired
				{
					// Create return money to bidder via mail 

					Mail.CreateAuctionMail(auction.OwnerID, item, item.TemplateID, 0, (int) AuctionHouse.AUCTION_MAIL_TYPE.EXPIRED,
					                       (int) auction.House, "");

					AuctionHouse.NotifyOwner(auction.ObjectId, auction.OwnerID, 0, item);
					DBManager.EraseDBObject(auction);
				}
				else //  auction succes - send money to owner  - send item to winner.
				{
					ICollection bids = Database.Instance.FindObjectsByField(typeof (DBBid), "AuctionID", auction.ObjectId);

					if (bids.Count == 0)
					{
						LogConsole.WriteLine(LogLevel.ERROR,
						                     "AuctionNotifyEvent:OnTick(): auction have bid value but have no active bids.");
						// Even if error happen we need return item to owner
						Mail.CreateAuctionMail(auction.OwnerID, item, item.TemplateID, 0, (int) AuctionHouse.AUCTION_MAIL_TYPE.EXPIRED,
						                       (int) auction.House, "");

						AuctionHouse.NotifyOwner(auction.ObjectId, auction.OwnerID, 0, item);
						DBManager.EraseDBObject(auction);
						return;
					}

					DBBid highBid = null;

					// Determine high bidder 
					foreach (DBBid bid in bids)
						if (highBid == null || bid.BidAmount > highBid.BidAmount)
							highBid = bid;

					foreach (DBBid bid in bids)
					{
						if (bid.ObjectId == highBid.ObjectId)
						{
							// Normal situation , derive Item to winner and money to owner.

							int bidAmount = (int) highBid.BidAmount;
							int house = (int) auction.House;

							// Auction Won mail for winner.
							string m_breport =
								string.Format("          {0}:{1}:{2}", auction.OwnerID.ToString("x"), bidAmount, auction.BuyOutPrice);
							//    seller:sale_price:buy_type:deposit:auction_cut
							Mail.CreateAuctionMail(highBid.BidderID, item, item.TemplateID, 0, (int) AuctionHouse.AUCTION_MAIL_TYPE.WON,
							                       house, m_breport);
							AuctionHouse.NotifyBidder(auction.ObjectId, highBid.BidderID, 0, item);

							// Auction success mail for seller.
							// Calc Cut Fee
							int cut = AuctionHouse.CalcCutFee(auction, house, bidAmount);
							int deposit = AuctionHouse.CalcDeposit(item.Template.SellPrice, (int) auction.TradeTime, house);
							int winmoney = bidAmount - cut + deposit;

							string m_report =
								string.Format("          {0}:{1}:{2}:{3}:{4}", highBid.BidderID.ToString("x"), bidAmount, auction.BuyOutPrice,
								              deposit, cut); //    seller:sale_price:buy_type:deposit:auction_cut

							Mail.CreateAuctionMail(auction.OwnerID, null, item.TemplateID, winmoney,
							                       (int) AuctionHouse.AUCTION_MAIL_TYPE.SUCCESS, house, m_report);

							DBManager.EraseDBObject(auction);
							AuctionHouse.NotifyOwner(auction.OwnerID, auction.OwnerID, bidAmount, item);
						}
						else
						{
							// Create return money to bidder via mail 
							Mail.CreateAuctionMail(bid.BidderID, null, item.TemplateID, (int) bid.BidAmount,
							                       (int) AuctionHouse.AUCTION_MAIL_TYPE.OUTBID, (int) auction.House, "");
							AuctionHouse.NotifyBidder(auction.ObjectId, bid.BidderID, (int) highBid.BidAmount, item);
						}

						DBManager.EraseDBObject(bid);
					}
				}
			}
			Console.WriteLine("AuctionNotifyEvent:OnTick() - execution time: {0}",
			                  new TimeSpan(CustomDateTime.Now.Ticks - timein).TotalMilliseconds);
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}
}