using System;
using System.IO;
using RunServer.Common;
using RunWoW.Accounting;

namespace RunWoW.Misc
{
	public class StatusTxt : Event
	{
		private static string TXTStatusFile = Constants.StatusPath + Constants.StatusTxtFile;
		public static StatusTxt Instance = new StatusTxt();

		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}

		public StatusTxt()
			: base(TimeSpan.FromSeconds(5.0), TimeSpan.FromSeconds(60.0))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			using (StreamWriter op = new StreamWriter(TXTStatusFile))
			{
				op.Write(ClientManager.OnlineCount);
			}
		}
	}
}