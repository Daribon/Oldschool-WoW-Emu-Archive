//
using System;
using System.Collections.Generic;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunServer.Common;
using RunWoW.ServerDatabase;

namespace RunWoW.World
{
	[PacketHandlerClass()]
	public class MapManager
	{
		private static Dictionary<uint, MapInstance> m_worldMaps = new Dictionary<uint, MapInstance>();

		private static Dictionary<uint, Dictionary<uint, MapInstance>> m_instances = new Dictionary<uint, Dictionary<uint, MapInstance>>();

		public static void InitWorldMap(DBWorldMap map)
		{
			m_worldMaps[map.ObjectId] = new MapInstance(map, 0);
		}

		public static void InitInstanceMap(DBWorldMap map)
		{
			if (!m_instances.ContainsKey(map.ObjectId))
				m_instances[map.ObjectId] = new Dictionary<uint, MapInstance>();

			foreach (DBSpawn spawn in map.Spawns)
			{
				if (spawn.CreatureID == map.SpiritHealerID)
				{
					spawn.BehaivorID = 9;
					spawn.Flags = 0x200166;
					DBManager.SaveDBObject(spawn);
					Database.Instance.ResolveRelations(spawn, typeof(DBSpeech));
				}
				else
					Database.Instance.ResolveRelations(spawn, true);
			}

			foreach (DBGameObject gameObject in map.GameObjects)
				Database.Instance.ResolveRelations(gameObject, typeof(DBGOLoot));
		}

		public static MapInstance GetWorldMap(uint id, uint instanceId)
		{
			if (WorldBase.Worlds.Contains(id))
				return m_worldMaps.ContainsKey(id) ? m_worldMaps[id] : null;

			if (!m_instances.ContainsKey(id))
				return null;

			lock (m_instances[id])
			{
				if (m_instances[id].ContainsKey(instanceId))
					return m_instances[id][instanceId];

				DBWorldMap map = (DBWorldMap) Database.Instance.FindObjectByKey(typeof (DBWorldMap), id);
				if (map == null)
					return null;

				return m_instances[id][instanceId] = new MapInstance(map, instanceId);
			}
		}


		[PacketHandler(CMSG.MOVE_WORLDPORT_ACK)]
		public static void OnWorldPortAck(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Player.MapTile != null)
			{
				Client.Player.MapTile.Map.Leave(Client.Player);
				Client.Player.MapTile = null;
			}
			PreparePlayerObject(Client.Player);
		}

		public static void PlayerEnterWorld(ClientData client)
		{
			DBCharacter character = client.Character;
			if (character == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Failed to enter world - missing Character object");
				return;
			}
			MapInstance map = GetWorldMap(character.WorldMapID, client.Player.MapInstanceID);
			if (map == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Unknown map " + character.WorldMapID);
				client.Client.Close("Unknown map");
				return;
			}
			PreparePlayerObject(client.Player);
		}

		private static void PreparePlayerObject(PlayerObject player)
		{
			DateTime time = CustomDateTime.Now;

			MapInstance map = GetWorldMap(player.WorldMapID, player.MapInstanceID);
			map.SetObjectPositionInBounds(player);
			player.CreatePlayerObject();
			LogConsole.WriteLine(LogLevel.SYSTEM, "-- Object created in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

			ShortPacket pkg = new ShortPacket(SMSG.TIMESTAMP_REQUEST);
			pkg.Write(0);
			player.BackLink.Client.Send(pkg);

			map.CreateTransports(player);
			if (player.MapTile == null)
				map.Enter(player);
			else 
				map.PlayerReenter(player);
			LogConsole.WriteLine(LogLevel.SYSTEM, "-- Map entered in {0}", (CustomDateTime.Now - time).TotalMilliseconds);
			player.WorldChange = WCHANGESTATE.CHANGED;
			player.Init();
			player.Auras.UpdateAuras();
			player.ResummonPet();
			player.ContinueRide();
			player.UpdateData();
			LogConsole.WriteLine(LogLevel.SYSTEM, "-- Done in {0}", (CustomDateTime.Now - time).TotalMilliseconds);
		}
	}
}