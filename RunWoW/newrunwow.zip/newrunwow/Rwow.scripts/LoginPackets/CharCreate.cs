//
using System;
using System.Text.RegularExpressions;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunWoW.WoWRaces;

namespace RunWoW.LoginPackets
{
	[PacketHandlerClass()]
	public class CharCreate
	{
		private static Regex nameCheck = new Regex(@"^[A-Z{1}][a-z]*$", RegexOptions.Compiled);

		[PacketHandler(CMSG.CHAR_CREATE, ExecutionPriority.Pool)]
		public static void HandleCharCreate(ClientBase client, BinReader data)
		{
			string Name = data.ReadString();

			ShortPacket pkg = new ShortPacket(SMSG.CHAR_CREATE);
			ClientData Client = (ClientData) client.Data;

			if (!nameCheck.IsMatch(Name))
			{
				pkg.Write((byte) 0x31);
				client.Send(pkg);
				return;
			}

			if (Database.Instance.FindObjectByField(typeof (DBCharacter), "Name", Name) != null)
			{
				pkg.Write((byte) 0x31);
				client.Send(pkg);
				return;
			}
			
			byte Race = data.ReadByte();
			byte Class = data.ReadByte();
			byte Gender = data.ReadByte();
			byte Skin = data.ReadByte();
			byte Face = data.ReadByte();
			byte HairStyle = data.ReadByte();
			byte HairColor = data.ReadByte();
			byte FacialHairStyle = data.ReadByte();
			/*byte OutfitId = */data.ReadByte(); //??
			
			if (Client.Account.AccessLvl < ACCESSLEVEL.FEATURED)
			{
				FACTION oldFaction = FACTION.NONE;

				int count = 0;
				
				if (Client.Account.Characters != null)
					foreach (DBCharacter character in Client.Account.Characters)
						if (character.Active == 1)
						{
							oldFaction = character.Faction;
							count++;
							//Console.WriteLine("Found char {0} with faction {1}", character.Name, character.Faction);
						}

				if (count == 10)
				{
					if (Constants.BurningCrusade)
						pkg.Write((byte)0x35);
					else
						pkg.Write((byte)0x2E);
					client.Send(pkg);
				}
				
				if (oldFaction != FACTION.NONE)
					if (!Faction.SameFaction(Races.Instance[(RACE)Race].Faction, oldFaction))
					{
						pkg.Write((byte)0x33);
						client.Send(pkg);
						return;
					}
			}
			
			DBCharacter dbCharacter =
				Races.Instance[(RACE) Race].Create(Name, Client.Account.ObjectId, (CLASS) Class, Gender,
				                                   Skin, Face, HairColor, HairStyle, FacialHairStyle);
			if (dbCharacter.Outfit[0] == 0)
			{
				dbCharacter.Outfit[0] = -1;
			}
			LogConsole.WriteLine(LogLevel.TRACE, "Created character: {0}[{1}], ID: {2}", Name, (RACE) Race, dbCharacter.ObjectId);
			DBManager.SaveDBObject(dbCharacter);
			
			//Database.Instance.AddObjectToRelations(Client.Account, c);
			Client.Account.Characters.Add(dbCharacter);

			pkg.Write((byte)0x2E);
			client.Send(pkg);
			return;
		}
	}
}