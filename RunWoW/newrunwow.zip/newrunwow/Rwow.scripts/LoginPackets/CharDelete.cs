//
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.LoginPackets
{
	[PacketHandlerClass()]
	public class CharDelete
	{
		[PacketHandler(CMSG.CHAR_DELETE, ExecutionPriority.Pool)]
		public static void HandleCharDelete(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client.Account.Characters == null)
				return;
			ulong id = data.ReadUInt64();
			ShortPacket pkg = new ShortPacket(SMSG.CHAR_DELETE);
			foreach (DBCharacter c in Client.Account.Characters)
				if (id == c.ObjectId)
				{
					c.Active = 0;
					c.GuildID = 0;
					c.Name = "deleted_" + c.Name;
					DBManager.SaveDBObject(c);

					pkg.Write((byte)0x3A);
					client.Send(pkg);
					return;
				}
			pkg.Write((byte)0x3B);
			client.Send(pkg);
			//client.Close(Client.Account.Name + " tried to delete a character that didn't belong to him.");
		}
	}
}