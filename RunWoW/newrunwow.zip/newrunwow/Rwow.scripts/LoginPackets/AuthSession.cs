//
using System;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;

namespace RunWoW.LoginPackets
{
	[PacketHandlerClass()]
	public class AuthSession
	{
		[PacketHandler(CMSG.AUTH_SESSION, ExecutionPriority.Pool)]
		public static void HandleAuthSession(ClientBase client, BinReader data)
		{
			int version = data.ReadInt32();
			/*int unk = */data.ReadInt32();
			string name = data.ReadString().ToLower();
			if (name.Length < 2)
			{
				client.Close("Too short account name");
				return;
			}

			/*int seed = */data.ReadInt32();
			/*byte[] digest = */data.ReadBytes(20);

			/*Console.WriteLine("Account {0}, version {1}, unk {2}, seed {3}, digest {4}", name, version, unk, seed,
			                  Hexdump.ToString(digest, 20));*/

			ClientData Client = (ClientData)client.Data;
			if (Client == null)
				return;
			ShortPacket packet = new ShortPacket(SMSG.AUTH_RESPONSE);
			if (Client.Account != null)
			{
				if (Client.Account.Name != name)
				{
					packet.Write((byte)0x0D);
					client.Send(packet);
					client.Close(Client.Account.Name + " tried to log in again as " + name);
				}
				return;
			}
			DBAccount account = null;
			{
				try
				{
					account = (DBAccount)Database.Instance.FindObjectByField(typeof(DBAccount), "Name", name.ToLower());
				}
				catch (Exception e)
				{
					LogConsole.WriteLine(LogLevel.ERROR, "Error loading account: " + e);
				}
			}
			if (account == null)
			{
				packet.Write((byte)0x15);
				client.Send(packet);
				client.Close("Unknown account " + name);
				return;
			}
			if ((int)account.AccessLvl < Constants.MinAccessLevel)
			{
				packet.Write((byte)0x16);
				client.Send(packet);
				client.Close("Tried to login with banned account: " + name);
				return;
			}
			Client.Account = account;
			if (account.SessionKey != null)
			{
				bool isnull = true;
				for (int i = 0; i < account.SessionKey.Length; i++)
					if (account.SessionKey[i] != 0)
					{
						isnull = false;
						break;
					}
				client.DataArray[1] = isnull ? null : account.SessionKey;
			}
			else
				client.DataArray[1] = null;

			client.Authenticated = true;

			Client.ClientVersion = version;
			
			int addons = data.ReadInt32();
			if (addons > 0)
			{
				((ClientData)client.Data).AddonsLength = addons;
				((ClientData)client.Data).Addons = data.ReadBytes(data.BaseStream.Length - data.BaseStream.Position);
			}

			Database.Instance.ResolveRelations(account, true);
			
			LogConsole.WriteLine(LogLevel.TRACE, "Account {0} logged in from {1}", name, client.RemoteEndPoint);

			if (ClientManager.OnlineCount >= Constants.MaximumOnline && ((ClientData)client.Data).Account.AccessLvl < ACCESSLEVEL.FEATURED)
			{
				bool noQueue = false;

				/*if (Client.Account.Characters == null)
					Database.Instance.ResolveRelations(Client.Account, true);*/
				
				if (client.RemoteEndPoint.Address.ToString() == Constants.NoQueueIP)
					noQueue = true;
				else
				foreach (DBCharacter chr in account.Characters)
				{
					if (
						(Constants.NoQueueGuild1 != 0 && chr.GuildID == Constants.NoQueueGuild1) ||
						(Constants.NoQueueGuild2 != 0 && chr.GuildID == Constants.NoQueueGuild2) ||
						(Constants.NoQueueGuild3 != 0 && chr.GuildID == Constants.NoQueueGuild3)
						)
					{
						noQueue = true;
						break;
					}
				}

				if (!noQueue)
				{
					AuthQueueEvent.AddToQueue(client);
					return;
				}
			}
/*                        packet.Write((byte)0);
                        packet.Write((int)0);
                        packet.Write((byte)0);
                        packet.Write((int)0);
                        packet.Write((byte)1);//burning crusade?*/
			AcceptClient(client, packet);
		}

		public static void AcceptClient(ClientBase client, ShortPacket packet)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null)
				return;

			if (packet == null)
				packet = new ShortPacket(SMSG.AUTH_RESPONSE);

			packet.Write((byte)0x0C);

//			foreach (DBCharacter chr in Client.Account.Characters)
//				if (chr.Race == RACE.BLOODELF || chr.Race == RACE.DRAENEI)
//				{
//					packet.Write((byte)0x00);
//					packet.Write((byte)0x35);
//					packet.Write((byte)0x78);
//					packet.Write((byte)0);
//					packet.Write((byte)0);
//					packet.Write((byte)0);
//					packet.Write((byte)0);
//					packet.Write((byte)0);
//					packet.Write((byte)0);
//					packet.Write((byte)1);
			packet.Write((int)0); //random
			packet.Write((byte)0);
			packet.Write((int)0); //always 0
			packet.Write((byte)(Constants.BurningCrusade ? 1 : 0));
//					break;
//				}
			client.Send(packet);
		}
	}

	public class AuthQueueEvent : Event
	{
		private static AuthQueueEvent Instance = new AuthQueueEvent();

		private Queue<ClientBase> m_loginQueue = new Queue<ClientBase>();

		public AuthQueueEvent()
			: base(TimeSpan.FromSeconds(0), TimeSpan.FromSeconds(5.0))
		{
			Priority = TimerPriority.OneSecond;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		public static void AddToQueue(ClientBase client)
		{
			Instance.Enqueue(client);
			//for (int i = 0; i < m_loginQueue.Count; i++)
			//{
			//    ClientBase clientBase = (ClientBase) m_loginQueue[i];
			//    if (clientBase.Closed)
			//    {
			//        m_loginQueue.Remove(clientBase);
			//        i--;
			//        if (m_loginQueue.Count <= (i + 1))
			//            break;
			//    }
			//}
			//if (!m_loginQueue.Contains(client))
			//{
			//    m_loginQueue.Add(client);
			//    ShortPacket packet = new ShortPacket(SMSG.AUTH_RESPONSE);
			//    packet.Write((byte) 0x1B);
			//    packet.Write((int) m_loginQueue.IndexOf(client));
			//    client.Send(packet);
			//}
		}

		private void Enqueue(ClientBase client)
		{
			int position = 0;
			lock (m_loginQueue)
			{

				foreach (ClientBase oldClient in m_loginQueue)
				{
					if (oldClient.Closed)
						continue;
					if (oldClient == client)
						return;
					if (((ClientData) client.Data).Account.Name == ((ClientData) oldClient.Data).Account.Name)
						oldClient.Close("Same account already in queue");
					position++;
				}

				m_loginQueue.Enqueue(client);
			}
			ShortPacket packet = new ShortPacket(SMSG.AUTH_RESPONSE);
			packet.Write((byte) 0x1B);
			packet.Write(position);
			client.Send(packet);
		}


		protected override void OnTick()
		{
			List<ClientBase> toAccept = new List<ClientBase>();
			List<KeyValuePair<ClientBase, int>> toInform = new List<KeyValuePair<ClientBase, int>>();

			lock (m_loginQueue)
			{
				while (m_loginQueue.Count > 0 && ClientManager.OnlineCount < Constants.MaximumOnline)
				{
					ClientBase client = m_loginQueue.Dequeue();
					if (!client.Closed)
						toAccept.Add(client);
				}

				int pos = 0;
				foreach (ClientBase client in m_loginQueue)
					if (!client.Closed)
						toInform.Add(new KeyValuePair<ClientBase, int>(client, pos++));

			}

			foreach (ClientBase client in toAccept)
				AuthSession.AcceptClient(client, null);

			foreach (KeyValuePair<ClientBase, int> pair in toInform)
			{
				ShortPacket packet = new ShortPacket(SMSG.AUTH_RESPONSE);
				packet.Write((byte) 0x1B);
				packet.Write(pair.Value);
				pair.Key.Send(packet);
			}
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}
}