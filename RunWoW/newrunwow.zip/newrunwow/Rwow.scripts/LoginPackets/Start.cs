//
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;

namespace RunWoW.LoginPackets
{
	[ServerHandlerClass()]
	internal class StartClass
	{
		[ServerHandler(IMSG.CLIENT_CONNECTED)]
		public static void StartDialog(ClientBase client)
		{
			//LogConsole.WriteLine(LogLevel.SYSTEM,"Scripts: Client conneted");
			client.Data = new ClientData(client);
			/*ShortPacket pkg= new ShortPacket(SMSG.AUTH_CHALLENGE);
			pkg.Write((byte)1);
			pkg.Write((byte)2);
			pkg.Write((byte)3);
			pkg.Write((byte)4);
			client.Send(pkg);*/
		}
	}
}