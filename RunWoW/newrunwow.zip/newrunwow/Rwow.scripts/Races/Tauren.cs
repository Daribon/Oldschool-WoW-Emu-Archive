using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Tauren : BaseRace
	{
		public class TaurenWarrior : Warrior
		{
			public TaurenWarrior() : base(80)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2361, INVSLOT.MAINHAND); // Battleworn Hammer
				//AddItem(139, INVSLOT.LEGS); // Brawler's Pants
				//AddItem(6125, INVSLOT.BODY); // Brawler's Harness
				//AddItem(4540, INVSLOT.BACKPACK_SLOT00, 4); //  Tough Hunk of Bread

				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // Axes
				AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
				AddSkill(SPELLSKILL.TWOHANDBLUNT, SKILL.TWOHANDBLUNT, 1, 300); // Maces
			}
		}

		public class TaurenDruid : Druid
		{
			public TaurenDruid() : base(74, 67)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(35, INVSLOT.MAINHAND); // Bent Staff
				//AddItem(6139, INVSLOT.CHEST); // Novice's Robe
				//AddItem(6124, INVSLOT.LEGS); // Novice's Pants
				//AddItem(4536, INVSLOT.BACKPACK_SLOT00, 2); // Shiny Red Apple
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water

				AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
			}
		}

		public class TaurenHunter : Hunter
		{
			public TaurenHunter() : base(76, 80)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(37, INVSLOT.MAINHAND); // Worn Axe
				//AddItem(2508, INVSLOT.RANGED); // Old Blunderbuss
				//AddItem(127, INVSLOT.BODY); // Trapper's Shirt
				//AddItem(6126, INVSLOT.LEGS); // Trapper's Pants
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
				//AddItem(2516, INVSLOT.BACKPACK_SLOT02, 100); // Light Shot

				AddSpell(7918, 2); // Shoot gun
				AddSkill(266, 46, 1, 300); // Guns
				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // Axes
			}
		}

		public class TaurenRogue : Rogue
		{
			public TaurenRogue() : base(76)
			{
			}
		}

		public class TaurenShaman : Shaman
		{
			public TaurenShaman() : base(77, 71)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // Worn Mace
				//AddItem(153, INVSLOT.LEGS); // Primitive Kilt
				//AddItem(154, INVSLOT.BODY); // Primitive Mantle
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 2); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // refreshing spring water
			}
		}

		public Tauren()
			: base(new Vector(-2917.58f, -257.98f, 52.9968f), 1, 215, 141)
		{
			addClass(new TaurenWarrior());
			addClass(new TaurenDruid());
			addClass(new TaurenHunter());
			addClass(new TaurenShaman());
			addClass(new TaurenRogue()); // for druid form

			BaseStrength = 25;
			BaseAgility = 15;
			BaseStamina = 22;
			BaseIntellect = 15;
			BaseSpirit = 22;
		}

		public override RACE Race
		{
            get { return RACE.TAUREN; }
		}

		public override FACTION Faction
		{
			get { return FACTION.TAUREN; }
		}

		public override float Scale
		{
			get { return 1.3f;  }
		}

		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(20549); // War Stomp
			AddSpell(20550); // Endurance
			AddSpell(20552); // Cultivation
			AddSpell(20551); // Nature Resistance

			AddSkill(669, 109, 300, 300); // lang orcish
			AddSkill(670, 115, 300, 300); // lang taurane
		}
	}
}