//
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class BloodElf : BaseRace
	{
		public class BloodElfPaladin : Paladin
		{
			public BloodElfPaladin()
				: base(58, 80)
			{
			}

			public override void InitNewbie()
			{
				AddSpell(20154, 2); // Seal
				AddSpell(635, 3); // Holy Light
				AddSpell(SPELLSKILL.BLOCK); // Block

				AddSkill(0, 184, 1, 1); // Combat
				AddSkill(0, 56, 1, 1); // Holy
				AddSkill(0, 257, 1, 1); // Protection
				AddSkill(SPELLSKILL.TWOHANDSWORD, SKILL.TWOHANDSWORD, 1, 300);
				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300);
				AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
				AddSkill(SPELLSKILL.LEATHER, SKILL.LEATHER, 1, 1); // Leather
				AddSkill(SPELLSKILL.MAIL, SKILL.MAIL, 1, 1); // Mail
				AddSkill(SPELLSKILL.SHIELD, SKILL.SHIELD, 1, 1); // Shield 
			}
		}


		public class BloodElfRogue : Rogue
		{
			public BloodElfRogue() : base(45)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(49, INVSLOT.BODY); // Footpad's Shirt
				//AddItem(48, INVSLOT.LEGS); // Footpad's Pants
				//AddItem(47, INVSLOT.FEET); // Footpad's Shoes
				//AddItem(2947, INVSLOT.RANGED, 100); // Small Throwing Knife
				//AddItem(4540, INVSLOT.BACKPACK_SLOT00, 4); //  Tough Hunk of Bread
			}
		}

		public class BloodElfPriest : Priest
		{
			public BloodElfPriest() : base(51, 160)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(51, INVSLOT.FEET); // neophytes's boots
				//AddItem(52, INVSLOT.LEGS); // neophytes's pants
				//AddItem(6119, INVSLOT.CHEST); // neophyte's robe
				//AddItem(53, INVSLOT.BODY); // neophyte's shirt
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 2); // Darnassian Bleu
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class BloodElfHunter : Hunter
		{
			public BloodElfHunter() : base(46, 85)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(2504, INVSLOT.RANGED); // Worn Shortbow
				//AddItem(148, INVSLOT.BODY); // Rugged Trapper's Shirt
				//AddItem(147, INVSLOT.LEGS); // Rugged Trapper's Pants
				//AddItem(129, INVSLOT.FEET); // Rugged Trapper's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
				//AddItem(2512, INVSLOT.BACKPACK_SLOT02, 100); // Rough Arrow

				AddSpell(2480, 2); // Shoot bow
				AddSkill(SPELLSKILL.BOW, SKILL.BOW, 1, 300); // Bows
				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			}
		}

		public class BloodElfWarlock : Warlock
		{
			public BloodElfWarlock()
				: base(43, 185)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn dagger
				//AddItem(59, INVSLOT.FEET); // Acolyte's shoes
				//AddItem(1396, INVSLOT.LEGS); // Acolyte's pants
				//AddItem(57, INVSLOT.CHEST); // Acolyte's robe
				//AddItem(6097, INVSLOT.BODY); // Acolyte's shirt
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 2); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class BloodElfMage : Mage
		{
			public BloodElfMage()
				: base(51, 210)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(35, INVSLOT.MAINHAND); // bent staff
				//AddItem(55, INVSLOT.FEET); // Apprentices Boots
				//AddItem(1395, INVSLOT.LEGS); // Apprentices Pants
				//AddItem(6140, INVSLOT.CHEST); // Apprentices Robe
				//AddItem(6096, INVSLOT.BODY); // Apprentices Shirt
				//AddItem(4536, INVSLOT.BACKPACK_SLOT00, 2); // Shiny Red Apple
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}
		
		public BloodElf()
			: base(new Vector(10349.6f, -6357.29f, 33.4026f), 530, 3430, 162)
		/// TODO: The blood elves start in the Eversong ForestEversong Forest
		{
			addClass(new BloodElfPaladin());
			addClass(new BloodElfRogue());
			addClass(new BloodElfHunter());
			addClass(new BloodElfPriest());
			addClass(new BloodElfMage());
			addClass(new BloodElfWarlock());

			BaseStrength = 17;
			BaseAgility = 25;
			BaseStamina = 19;
			BaseIntellect = 20;
			BaseSpirit = 20;
		}

		public override RACE Race
		{
            get { return RACE.BLOODELF; }
		}

		public override FACTION Faction
		{
			get { return FACTION.BLOODELF; }
		}
		
		public override void InitNewbie()
		{
			base.InitNewbie();
			
			AddSpell(28734); // Mana Tap
			AddSpell(28730); // Arcane Torrent 
			//AddSpell(25046); // Arcane Torrent 
			AddSpell(28877); // Arcane Affinity
			AddSpell(822); // Magic Resistance

			AddSkill(669, 109, 300, 300); // lang orcish
			AddSkill(813, 137, 300, 300); // lang Thalassian
		}
	}
}