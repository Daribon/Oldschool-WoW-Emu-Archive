using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Draenei : BaseRace
	{
		public class DraeneiWarrior : Warrior
		{
			public DraeneiWarrior() : base(50)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(25, INVSLOT.MAINHAND); // Worn Shortsword
				//AddItem(2362, INVSLOT.OFFHAND); // Worn Wooden Shield
				//AddItem(6120, INVSLOT.BODY); // Recruit's Shirt
				//AddItem(6121, INVSLOT.LEGS); // Recruit's Pants
				//AddItem(6122, INVSLOT.FEET); // Recruit's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky

				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
				AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300); // Swords
			}
		}

		public class DraeneiPriest : Priest
		{
			public DraeneiPriest() : base(51, 160)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(51, INVSLOT.FEET); // neophytes's boots
				//AddItem(52, INVSLOT.LEGS); // neophytes's pants
				//AddItem(6119, INVSLOT.CHEST); // neophyte's robe
				//AddItem(53, INVSLOT.BODY); // neophyte's shirt
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 2); // Darnassian Bleu
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class DraeneiHunter : Hunter
		{
			public DraeneiHunter() : base(46, 85)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(2504, INVSLOT.RANGED); // Worn Shortbow
				//AddItem(148, INVSLOT.BODY); // Rugged Trapper's Shirt
				//AddItem(147, INVSLOT.LEGS); // Rugged Trapper's Pants
				//AddItem(129, INVSLOT.FEET); // Rugged Trapper's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
				//AddItem(2512, INVSLOT.BACKPACK_SLOT02, 100); // Rough Arrow

				AddSpell(2480, 2); // Shoot bow
				AddSkill(SPELLSKILL.BOW, SKILL.BOW, 1, 300); // Bows
				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300);
			}
		}

		public class DraeneiPaladin : Paladin
		{
			public DraeneiPaladin()
				: base(58, 80)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2361, INVSLOT.MAINHAND); // Battleworn Hammer
				//AddItem(45, INVSLOT.BODY); // Squire's Shirt
				//AddItem(44, INVSLOT.LEGS); // Squire's Pants
				//AddItem(43, INVSLOT.FEET); // Squire's Boots
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 4); // Darnassian Bleu
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
			}
		}

		public class DraeneiShaman : Shaman
		{
			public DraeneiShaman()
				: base(77, 73)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // Worn Mace
				//AddItem(153, INVSLOT.LEGS); // Primitive Kilt
				//AddItem(154, INVSLOT.BODY); // Primitive Mantle
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 2); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // refreshing spring water
			}
		}

		public class DraeneiMage : Mage
		{
			public DraeneiMage()
				: base(62, 119)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(35, INVSLOT.MAINHAND); // bent staff
				//AddItem(55, INVSLOT.FEET); // Apprentices Boots
				//AddItem(1395, INVSLOT.LEGS); // Apprentices Pants
				//AddItem(6140, INVSLOT.CHEST); // Apprentices Robe
				//AddItem(6096, INVSLOT.BODY); // Apprentices Shirt
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 2); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}
		
		public Draenei()
			: base(new Vector(-4004.2f, -11878.4f, -1f), 530, 14, 163)
		///  TODO: The draenei start in Ammen Vale, situated on Azuremyst Isle
		{
			addClass(new DraeneiWarrior());
			addClass(new DraeneiPaladin());
			addClass(new DraeneiShaman());
			addClass(new DraeneiMage());
			addClass(new DraeneiHunter());
			addClass(new DraeneiPriest());

			BaseStrength = 24;
			BaseAgility = 17;
			BaseStamina = 21;
			BaseIntellect = 22;
			BaseSpirit = 34;
		}

		public override RACE Race
		{
            get { return RACE.DRAENEI; }
		}

		public override FACTION Faction
		{
			get { return FACTION.DRAENEI; }
		}
		
		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(28880); // (!Blessing) Gift of the Naaru 
//			AddSpell(28878); // (!Heroic) Inspiring Presence
			AddSpell(6562); // Heroic Presence
			AddSpell(28875); // Gemcutting 
			AddSpell(20579); // Shadow Resistance
			
			AddSkill(29932, 759, 300, 300); // lang (!Eredun) Draenli
			AddSkill(668, 98, 300, 300); // lang common
		}
	}
}