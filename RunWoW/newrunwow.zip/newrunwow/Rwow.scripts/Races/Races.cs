//
using System.Collections;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Races
	{
		public static Races Instance = new Races();
		
		private Hashtable m_races = new Hashtable();

		public void Add(BaseRace race)
		{
			m_races[race.Race] = race;
		}

		public BaseClass GetRaceClass(RACE nrace, CLASS nclass)
		{
			return GetRace(nrace).GetClass(nclass);
		}

		public BaseRace GetRace(RACE race)
		{
			return m_races[race] as BaseRace;
		}

		public BaseRace this[RACE race]
		{
			get { return GetRace(race); }
		}

		[InitializeHandler(InitPass.Fourth)]
		public static void Initialize()
		{
			Instance.Add(new Dwarf());
			Instance.Add(new Gnome());
			Instance.Add(new Human());
			Instance.Add(new Nightelf());
			Instance.Add(new Orc());
			Instance.Add(new Tauren());
			Instance.Add(new Troll());
			Instance.Add(new Undead());
			Instance.Add(new BloodElf());
			Instance.Add(new Draenei());

			ICollection outfits = Database.Instance.SelectAllObjects(typeof(DBStartOutfit));
			foreach (DBStartOutfit outfit in outfits)
				if (Instance.m_races.ContainsKey(outfit.Race))
				{
					BaseRace race = (BaseRace)Instance.m_races[outfit.Race];
					BaseClass baseClass = race.GetClass(outfit.Class);

					if (baseClass != null)
						for (int i = 0; i < outfit.Item.Length; i++)
							if (outfit.Item[i] != 0)
								baseClass.AddExternalItem(outfit.Item[i], outfit.Gender);
				}
		}
	}
}