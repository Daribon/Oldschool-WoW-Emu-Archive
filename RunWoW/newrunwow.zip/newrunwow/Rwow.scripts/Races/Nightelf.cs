using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Nightelf : BaseRace
	{
		public class NightelfWarrior : Warrior
		{
			public NightelfWarrior() : base(50)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(25, INVSLOT.MAINHAND); // Worn Shortsword
				//AddItem(2362, INVSLOT.OFFHAND); // Worn Wooden Shield
				//AddItem(6120, INVSLOT.BODY); // Recruit's Shirt
				//AddItem(6121, INVSLOT.LEGS); // Recruit's Pants
				//AddItem(6122, INVSLOT.FEET); // Recruit's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky

				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
				AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300); // Swords
			}
		}

		public class NightelfDruid : Druid
		{
			public NightelfDruid() : base(53, 100)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(3661, INVSLOT.MAINHAND); // Handcrafted Staff
				//AddItem(6123, INVSLOT.CHEST); // Novice's Robe
				//AddItem(6124, INVSLOT.LEGS); // Novice's Pants
				//AddItem(4536, INVSLOT.BACKPACK_SLOT00, 2); // Shiny Red Apple
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water

				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			}
		}

		public class NightelfRogue : Rogue
		{
			public NightelfRogue() : base(45)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(49, INVSLOT.BODY); // Footpad's Shirt
				//AddItem(48, INVSLOT.LEGS); // Footpad's Pants
				//AddItem(47, INVSLOT.FEET); // Footpad's Shoes
				//AddItem(2947, INVSLOT.RANGED, 100); // Small Throwing Knife
				//AddItem(4540, INVSLOT.BACKPACK_SLOT00, 4); //  Tough Hunk of Bread
			}
		}

		public class NightelfPriest : Priest
		{
			public NightelfPriest() : base(51, 160)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(51, INVSLOT.FEET); // neophytes's boots
				//AddItem(52, INVSLOT.LEGS); // neophytes's pants
				//AddItem(6119, INVSLOT.CHEST); // neophyte's robe
				//AddItem(53, INVSLOT.BODY); // neophyte's shirt
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 2); // Darnassian Bleu
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class NightelfHunter : Hunter
		{
			public NightelfHunter() : base(46, 85)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(2504, INVSLOT.RANGED); // Worn Shortbow
				//AddItem(148, INVSLOT.BODY); // Rugged Trapper's Shirt
				//AddItem(147, INVSLOT.LEGS); // Rugged Trapper's Pants
				//AddItem(129, INVSLOT.FEET); // Rugged Trapper's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
				//AddItem(2512, INVSLOT.BACKPACK_SLOT02, 100); // Rough Arrow

				AddSpell(2480, 2); // Shoot bow
				AddSkill(SPELLSKILL.BOW, SKILL.BOW, 1, 300); // Bows
				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			}
		}

		public Nightelf()
			: base(new Vector(10311.3f, 832.463f, 1326.41f), 1, 14, 61)
		{
			addClass(new NightelfWarrior());
			addClass(new NightelfRogue());
			addClass(new NightelfDruid());
			addClass(new NightelfHunter());
			addClass(new NightelfPriest());

			BaseStrength = 17;
			BaseAgility = 25;
			BaseStamina = 19;
			BaseIntellect = 20;
			BaseSpirit = 20;
		}

		public override RACE Race
		{
            get { return RACE.NIGHTELF; }
		}

		public override FACTION Faction
		{
			get { return FACTION.NIGHTELF; }
		}
		
		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(20580); // shadowmeld
			AddSpell(20582); // quickness
			AddSpell(20583); // nature resistance
			AddSpell(20585); // wisp spirit

			AddSkill(668, 98, 300, 300); // lang common
			AddSkill(671, 113, 300, 300); // lang darnassian
		}
	}
}