using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Undead : BaseRace
	{
		public class UndeadWarrior : Warrior
		{
			public UndeadWarrior() : base(60)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(25, INVSLOT.MAINHAND); // Worn Shortsword
				//AddItem(2362, INVSLOT.OFFHAND); // Worn Wooden Shield
				//AddItem(139, INVSLOT.LEGS); // Brawler's Pants
				//AddItem(6125, INVSLOT.BODY); // Brawler's Harness
				//AddItem(140, INVSLOT.FEET); // Brawler's Boots
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 4); // Forest Mushroom Cap

				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300); // Swords
				AddSkill(SPELLSKILL.TWOHANDSWORD, SKILL.TWOHANDSWORD, 1, 300); // 2H Swords
			}
		}

		public class UndeadRogue : Rogue
		{
			public UndeadRogue() : base(65)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(2105, INVSLOT.BODY); // Thug Shirt
				//AddItem(120, INVSLOT.LEGS); // Thug Pants
				//AddItem(121, INVSLOT.FEET); // Thug Boots
				//AddItem(2947, INVSLOT.RANGED, 100); // Small Throwing Knife
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 4); // Forest Mushroom Cap
			}
		}

		public class UndeadWarlock : Warlock
		{
			public UndeadWarlock() : base(63, 110)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn dagger
				//AddItem(59, INVSLOT.FEET); // Acolyte's shoes
				//AddItem(1396, INVSLOT.LEGS); // Acolyte's pants
				//AddItem(6129, INVSLOT.CHEST); // Acolyte's robe
				//AddItem(6097, INVSLOT.BODY); // Acolyte's shirt
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 2); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class UndeadPriest : Priest
		{
			public UndeadPriest() : base(62, 130)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(51, INVSLOT.FEET); // neophytes's boots
				//AddItem(52, INVSLOT.LEGS); // neophytes's pants
				//AddItem(6144, INVSLOT.CHEST); // neophyte's robe
				//AddItem(53, INVSLOT.BODY); // neophyte's shirt
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 2); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class UndeadMage : Mage
		{
			public UndeadMage() : base(62, 135)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(35, INVSLOT.MAINHAND); // bent staff
				//AddItem(55, INVSLOT.FEET); // Apprentices Boots
				//AddItem(1395, INVSLOT.LEGS); // Apprentices Pants
				//AddItem(6140, INVSLOT.CHEST); // Apprentices Robe
				//AddItem(6096, INVSLOT.BODY); // Apprentices Shirt
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 2); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public Undead()
			: base(new Vector(1676.35f, 1677.45f, 121.67f), 0, 85, 2)
		{
			addClass(new UndeadMage());
			addClass(new UndeadPriest());
			addClass(new UndeadRogue());
			addClass(new UndeadWarlock());
			addClass(new UndeadWarrior());

			BaseStrength = 19;
			BaseAgility = 18;
			BaseStamina = 21;
			BaseIntellect = 18;
			BaseSpirit = 25;
		}

		public override RACE Race
		{
            get { return RACE.UNDEAD; }
		}

		public override FACTION Faction
		{
			get { return FACTION.UNDEAD; }
		}
		
		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(20577); // cannibalize
			AddSpell(20579); // shadow resistance
			AddSpell(5227); // underwater breathing
			AddSpell(7744); // will of the forsaken

			AddSkill(669, 109, 300, 300); // lang orcish
			AddSkill(17737, 637, 300, 300); // lang gutterspeak
		}
	}
}