using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Dwarf : BaseRace
	{
		public class DwarfWarrior : Warrior
		{
			public DwarfWarrior() : base(90)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(5777, INVSLOT.MAINHAND); // Worn Battleaxe
				//AddItem(39, INVSLOT.LEGS); // Recruits Pants
				//AddItem(38, INVSLOT.BODY); // Recruits Shirt
				//AddItem(40, INVSLOT.FEET); // Recruits Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky

				AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // One-handed Axes
				AddSkill(SPELLSKILL.TWOHANDAXE, SKILL.TWOHANDAXE, 1, 300); // Two-handed Axes
			}

		}

		public class DwarfPaladin : Paladin
		{
			public DwarfPaladin() : base(88, 79)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2361, INVSLOT.MAINHAND); // Battleworn Hammer
				//AddItem(6117, INVSLOT.BODY); // Squire's Shirt
				//AddItem(6118, INVSLOT.LEGS); // Squire's Pants
				//AddItem(43, INVSLOT.FEET); // Squire's Boots
				//AddItem(4540, INVSLOT.BACKPACK_SLOT00, 4); //  Tough Hunk of Bread
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
			}
		}

		public class DwarfRogue : Rogue
		{
			public DwarfRogue() : base(85)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(49, INVSLOT.BODY); // Footpad's Shirt
				//AddItem(48, INVSLOT.LEGS); // Footpad's Pants
				//AddItem(47, INVSLOT.FEET); // Footpad's Shoes
				//AddItem(3111, INVSLOT.RANGED, 100); // Crude Throwing Knife
				//AddItem(4540, INVSLOT.BACKPACK_SLOT00, 4); // Tough Hunk of Bread
			}
		}

		public class DwarfHunter : Hunter
		{
			public DwarfHunter() : base(86, 84)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(37, INVSLOT.MAINHAND); // Worn Axe
				//AddItem(2508, INVSLOT.RANGED); // Old Blunderbuss
				//AddItem(147, INVSLOT.LEGS); // Rugged Trapper's Pants
				//AddItem(148, INVSLOT.BODY); // Rugged Trapper's Shirt
				//AddItem(129, INVSLOT.FEET); // Rugged Trapper's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
				//AddItem(2516, INVSLOT.BACKPACK_SLOT02, 100); // Light Shot

				AddSpell(7918, 2); // Shoot gun
				AddSkill(266, 46, 1, 300); // Guns
				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // Axes
				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			}
		}

		public class DwarfPriest : Priest
		{
			public DwarfPriest() : base(82, 79)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(51, INVSLOT.FEET); // neophytes's boots
				//AddItem(52, INVSLOT.LEGS); // neophytes's pants
				//AddItem(6098, INVSLOT.CHEST); // neophyte's robe
				//AddItem(53, INVSLOT.BODY); // neophyte's shirt
				//AddItem(4540, INVSLOT.BACKPACK_SLOT00, 2); //  Tough Hunk of Bread
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}


		public Dwarf()
			: base(new Vector(-6240.32f, 331.033f, 382.758f), 0, 1, 41)
		{
			addClass(new DwarfWarrior());
			addClass(new DwarfRogue());
			addClass(new DwarfHunter());
			addClass(new DwarfPaladin());
			addClass(new DwarfPriest());

			BaseStrength = 22;
			BaseAgility = 16;
			BaseStamina = 23;
			BaseIntellect = 19;
			BaseSpirit = 19;
		}

		public override RACE Race
		{
            get { return RACE.DWARF; }
		}

		public override FACTION Faction
		{
			get { return FACTION.DWARF; }
		}

		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(2481); // find treasure
			AddSpell(20596); // frost resistance
			AddSpell(20595); // gun specialization
			AddSpell(20594); // stoneform

			AddSkill(668, 98, 300, 300); // lang common
			AddSkill(672, 111, 300, 300); // lang dwarven
		}
	}
}