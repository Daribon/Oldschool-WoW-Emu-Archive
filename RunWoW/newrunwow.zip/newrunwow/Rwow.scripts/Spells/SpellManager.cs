//
using System;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.Spells
{
	public delegate void SpellFinishHandler(ObjectBase caster, ObjectBase target, DBSpell spell);

	public delegate SpellFailedReason SpellCastOnLiving(
		ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum, ref SpellFinishHandler Linked);

	public delegate SpellFailedReason SpellCastOnObject(
		ObjectBase caster, GameObject target, ObjectBase castTarget, DBSpell spell, byte efnum, ref SpellFinishHandler Linked);

	public delegate SpellFailedReason SpellCastOnItem(
		ObjectBase caster, ItemObject target, ObjectBase castTarget, DBSpell spell, byte efnum, ref SpellFinishHandler Linked);

	public delegate SpellFailedReason ScriptSpellCast(
		ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell, byte efnum, ref SpellFinishHandler Linked);

	public class SpellManager
	{
		private static Dictionary<SPELLEFFECT, object> m_handlers = new Dictionary<SPELLEFFECT, object>();
		private static Dictionary<SPELLEFFECT, Dictionary<uint, ScriptSpellCast>> m_scriptHandlers = new Dictionary<SPELLEFFECT, Dictionary<uint, ScriptSpellCast>>();
		private static Dictionary<uint, TARGET> m_targetPatches = new Dictionary<uint, TARGET>();

		public static void RegisterSpell(SPELLEFFECT effect, SpellCastOnLiving handler)
		{
			m_handlers[effect] = handler;
		}

		public static void RegisterSpell(SPELLEFFECT effect, SpellCastOnObject handler)
		{
			m_handlers[effect] = handler;
		}

		public static void RegisterSpell(SPELLEFFECT effect, SpellCastOnItem handler)
		{
			m_handlers[effect] = handler;
		}

		public static void RegisterSpell(SPELLEFFECT effect, uint spellId, ScriptSpellCast handler)
		{
			if (!m_scriptHandlers.ContainsKey(effect))
				m_scriptHandlers[effect] = new Dictionary<uint, ScriptSpellCast>();

			m_scriptHandlers[effect][spellId] = handler;
		}

		public static void RegisterTargetPatch(uint spellId, TARGET target)
		{
			m_targetPatches[spellId] = target;
		}

		public static SpellFailedReason ProcessSpell(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell, byte effnum, ref SpellFinishHandler linked)
		{
			if (target is LivingObject && ((LivingObject)target).IsImmune(spell.School, DAMAGECATEGORY.MAGIC, spell))
				return SpellFailedReason.SPELL_FAILED_IMMUNE;

			SPELLEFFECT effect = spell.Effect[effnum].Type;
			if (effect == SPELLEFFECT.NONE)
				return SpellFailedReason.MAX;

			if (m_scriptHandlers.ContainsKey(effect) && m_scriptHandlers[effect].ContainsKey(spell.ObjectId))
				return m_scriptHandlers[effect][spell.ObjectId](caster, target, castTarget, spell, effnum, ref linked);

			if (!m_handlers.ContainsKey(effect))
				LogConsole.WriteLine(LogLevel.ERROR, "Unhandled effect type {0}, spell: {1}", effect, spell.SpellID);
			else
			{
				if (m_handlers[effect] is SpellCastOnLiving)
					return ((SpellCastOnLiving)m_handlers[effect])(caster, target as LivingObject, castTarget, spell, effnum, ref linked);
				else if (m_handlers[effect] is SpellCastOnObject)
					return ((SpellCastOnObject)m_handlers[effect])(caster, target as GameObject, castTarget, spell, effnum, ref linked);
				else if (m_handlers[effect] is SpellCastOnItem)
					return ((SpellCastOnItem)m_handlers[effect])(caster, target as ItemObject, castTarget, spell, effnum, ref linked);
			}

			return SpellFailedReason.MAX;
		}

		#region Casters

		public static void SelfCast(ObjectBase caster, DBSpell Spell)
		{
			Cast(caster, caster, Spell);
		}

		public static void Cast(ObjectBase caster, ObjectBase target, DBSpell spell)
		{
			SpellFinishHandler linked = null;
			for (byte i = 0; i < 3; i++)
				if (spell.Effect[i].Type != 0)
					ProcessSpell(caster, target, target, spell, i, ref linked);
			if (linked != null)
				linked(caster, target, spell);
		}

		public static void Cast(ObjectBase caster, ObjectBase target, int spell)
		{
			DBSpell dbSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), spell);
			if (dbSpell != null)
				Cast(caster, target, dbSpell);
			else
				LogConsole.WriteLine(LogLevel.ERROR, "Asked to cast non-existing spell " + spell);
		}

		#endregion

		#region Helpers

		public static ICollection<ObjectBase> GetLivingTargets(MapTile tile, Vector point, float radius, bool isEnemy, ObjectBase caster, bool inFront, bool inParty, int creatureType)
		{
			Dictionary<ulong, ObjectBase> targets = new Dictionary<ulong, ObjectBase>();

			//MapTile mapTile = tile.Map.GetTileByLoc(point);

			foreach (MapTile mTile in tile.GetNearestTiles(point))
				if (mTile != null)
				{
					if (mTile.Players != null && (creatureType == 0 || creatureType == 64)) // all targets or humanoids
						for (int i = 0; i < mTile.Players.Last; i++)
						{
							try
							{
								PlayerObject player = mTile.Players.InnerArray[i];

								if (player == null || player.IsDisposed || !player.Attackable)
									continue;

								if (caster != null)
								{
									if (Faction.SameFaction(player, caster) == isEnemy)
										continue;

									if (inParty && !player.SameGroup(caster))
										continue;


									if (inFront)
										if (!caster.Position.InFront(caster.Facing, player.Position))
											continue;
								}

								if (radius > 0 && player.Position.Distance(point) > radius)
									continue;

								targets[player.GUID] = player;
							}
							catch (Exception ex)
							{
								LogConsole.WriteLine(LogLevel.ERROR, "Exception at GetLivingTargets: {0}", ex);
							}
						}

					//if (!inParty)
					if (mTile.Units != null)
						for (int i = 0; i < mTile.Units.Last; i++)
						{
							try
							{
								UnitBase unit = mTile.Units.InnerArray[i];
								if (unit == null || unit.IsDisposed || !unit.Attackable)
									continue;

								if (creatureType != 0)
								{
									int ctype = 1 << (unit.CreatureType - 1);

									if ((creatureType & ctype) != ctype)
										continue;
								}

								if (caster != null)
								{
									if (Faction.SameFaction(unit, caster) == isEnemy)
										continue;

									if (inFront)
										if (!caster.Position.InFront(caster.Facing, unit.Position))
											continue;

									if (inParty)
									{
										if (!(unit is IOwnedUnit))
											continue;

										PlayerObject owner = ((IOwnedUnit)unit).Owner as PlayerObject;

										if (owner == null || !owner.SameGroup(caster))
											continue;
									}
								}

								if (radius > 0 && unit.Position.Distance(point) > radius)
									continue;

								targets[unit.GUID] = unit;
							}
							catch (Exception ex)
							{
								LogConsole.WriteLine(LogLevel.ERROR, "Exception at GetLivingTargets: {0}", ex);
							}
						}
				}
			return targets.Values;
		}

		public static ICollection<ObjectBase> SpellTargets(MapTile tile, ObjectBase caster, ObjectBase target, Vector point, DBSpell spell, byte effect, out SpellFailedReason reason, bool forceArea)
		{
			reason = SpellFailedReason.MAX;

			TARGET implicitTarget = (TARGET)spell.Effect[effect].TargetB;

			if (forceArea && implicitTarget == TARGET.TARGET_SELF)
				implicitTarget = TARGET.TARGET_AREA_PARTY;

			if (m_targetPatches.ContainsKey(spell.ObjectId))
				implicitTarget = m_targetPatches[spell.ObjectId];

			switch (implicitTarget)
			{
				case TARGET.TARGET_PET:
					if (caster is PlayerObject && ((PlayerObject)caster).Pet != null)
						return new ObjectBase[] { ((PlayerObject)caster).Pet };
					else
						reason = SpellFailedReason.SPELL_FAILED_NO_PET;
					break;
				case TARGET.TARGET_SELF_FISHING:
				case TARGET.TARGET_SELF:
				case TARGET.TARGET_MINION: // summons minion
					return new ObjectBase[] { caster };
				case TARGET.TARGET_AREA_ENEMY_TARGET:
					if (target != null)
						return GetLivingTargets(tile, target.Position, spell.Effect[effect].Radius, true, caster, false, false, spell.CreatureType);
					else
						reason = SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
					break;
				case TARGET.TARGET_AREA_ENEMY:
				case TARGET.TARGET_AREA_ENEMY_CHANNEL:
				case TARGET.TARGET_AREA_ENEMY_INSTANT:
					return GetLivingTargets(tile, point, spell.Effect[effect].Radius, true, caster, false, false, spell.CreatureType);
				case TARGET.TARGET_NEAR_ENEMIES:
					return GetLivingTargets(tile, caster.Position, spell.Effect[effect].Radius, true, caster, false, false, spell.CreatureType);
				case TARGET.TARGET_INFRONT_ENEMIES:
					return GetLivingTargets(tile, caster.Position, spell.Effect[effect].Radius, true, caster, true, false, spell.CreatureType);
				case TARGET.TARGET_AREA_PARTY:
				case TARGET.TARGET_AREA_PARTY2:
					return GetLivingTargets(tile, caster.Position, spell.Effect[effect].Radius, false, caster, false, true, spell.CreatureType);
				case TARGET.TARGET_SINGLE_ALLY:
				case TARGET.TARGET_SINGLE_FRIEND:
				case TARGET.TARGET_SINGLE_FRIEND2:
					if (target != null && Faction.SameFaction(caster, target))
						return new ObjectBase[] { target };
					else
						reason = SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
					break;
				case TARGET.TARGET_SINGLE_PARTY:
					if
						(
							(target is PlayerObject && ((PlayerObject)target).SameGroup(caster)) ||
							(caster is PlayerObject && ((PlayerObject)caster).SameGroup(target))
						)
						return new ObjectBase[] { target };
					else
						reason = SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
					break;
				case TARGET.TARGET_SINGLE_ENEMY:
					if (target != null && !Faction.SameFaction(caster, target))
						return new ObjectBase[] { target };
					else
						reason = SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
					break;
				case TARGET.TARGET_SINGLE_ENEMY2: // allow not-enemy casts
					if (target != null && (caster is PlayerObject || !Faction.SameFaction(caster, target)))
						return new ObjectBase[] { target };
					else
						reason = SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
					break;
				default:
					if (target != null)
						return new ObjectBase[] { target };
					else
						if (caster != null)
							return new ObjectBase[] { caster };
					//reason = SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
					break;
			}
			return null;
		}

		public static bool HarmfulCast(DBSpell spell, byte effect)
		{
			TARGET implicitTarget = (TARGET) spell.Effect[effect].TargetB;

			if (m_targetPatches.ContainsKey(spell.ObjectId))
				implicitTarget = m_targetPatches[spell.ObjectId];

			switch (implicitTarget)
			{
				case TARGET.TARGET_PET:
				case TARGET.TARGET_SELF_FISHING:
				case TARGET.TARGET_SELF:
				case TARGET.TARGET_MINION:
				case TARGET.TARGET_AREA_PARTY:
				case TARGET.TARGET_AREA_PARTY2:
				case TARGET.TARGET_SINGLE_ALLY:
				case TARGET.TARGET_SINGLE_FRIEND:
				case TARGET.TARGET_SINGLE_FRIEND2:
				case TARGET.TARGET_SINGLE_PARTY:
					return false;
				default:
				case TARGET.TARGET_AREA_ENEMY_TARGET:
				case TARGET.TARGET_AREA_ENEMY:
				case TARGET.TARGET_AREA_ENEMY_CHANNEL:
				case TARGET.TARGET_AREA_ENEMY_INSTANT:
				case TARGET.TARGET_NEAR_ENEMIES:
				case TARGET.TARGET_INFRONT_ENEMIES:
				case TARGET.TARGET_SINGLE_ENEMY:
				case TARGET.TARGET_SINGLE_ENEMY2: // allow not-enemy casts
					return true;
			}
		}


		public static bool CheckResist(ObjectBase caster, ObjectBase target, DBSpell spell)
		{
			if (caster as LivingObject == null || target as LivingObject == null || caster == target || Faction.SameFaction(caster, target))
				return false;

			if (spell.School == DAMAGETYPE.PHYSICAL && spell.NextAttackSpell)
				return false;

			bool pvp = caster is PlayerObject && target is PlayerObject;

			int levelDiff = target.Level - caster.Level;

			float resistChance = 0.01f;

			if (levelDiff >= 0)
			{
				if (levelDiff <= 2)
					resistChance = 0.04f + levelDiff*0.01f;
				else
				{
					resistChance = 0.06f;
					if (pvp)
						resistChance += (levelDiff - 2)*0.07f;
					else
						resistChance += (levelDiff - 2)*0.11f;
				}
			}

			if (resistChance > 0.96f)
				resistChance = 0.96f;

			if ((target is UnitBase) && target.Level > 100 && resistChance > 0.8f)
				resistChance = 0.8f;

			if (resistChance < 0.01f)
				resistChance = 0.01f;

			if (spell.IsBinary && spell.School != DAMAGETYPE.PHYSICAL)
			{
				int targetResist = ((LivingObject)target).GetResist(spell.School);
				resistChance *= ((float)Math.Round(3f * targetResist / (caster.Level * 5f)) / 4f);
			}

			if (Utility.Chance(resistChance))
				return true;

			/*if (!spell.IsDamage)
			{
				int targetResist = ((LivingObject)target).GetResist(spell.School);

				float resistChance = (float)Math.Round(3f * targetResist / (caster.Level * 5f)) / 4f;

				if (resistChance > 0.75f)
					resistChance = 0.75f;

				if (Utility.Chance(resistChance))
					return true;
			}*/

			return false;
		}

		#endregion
	}
}