using System;
using RunWoW.World;

namespace RunWoW.Objects.Misc
{
	public class ObjectReference : WeakReference
	{
		private string m_name;
		private ulong m_guid;
		private bool m_valid;

		public ObjectReference(ObjectBase obj)
			: base(obj, false)
		{
			m_valid = obj != null;
			if (obj != null)
			{
				m_guid = obj.GUID;
				m_name = obj.Name;
			}
		}

		public new ObjectBase Target
		{
			get { return IsAlive ? (ObjectBase) base.Target : null; }
		}

		public ulong GUID
		{
			get { return m_guid; }
		}

		public override bool IsAlive
		{
			get
			{
				if (!m_valid || !base.IsAlive)
					return false;
				ObjectBase target = ((ObjectBase) base.Target);
				return target != null && !target.Disposed;
			}
		}


		public string Name
		{
			get { return m_name; }
		}

		public MapTile MapTile
		{
			get { return IsAlive ? Target.MapTile : null; }
		}

		#region Checkers

		public bool IsPlayer
		{
			get { return Target is PlayerObject; }
		}

		public bool IsLiving
		{
			get { return Target is LivingObject; }
		}

		public bool IsGO
		{
			get { return Target is GameObject; }
		}

		public bool IsUnit
		{
			get { return Target is UnitBase; }
		}

		public bool IsItem
		{
			get { return Target is ItemObject; }
		}

		#endregion

		#region Convertors

		public PlayerObject AsPlayer
		{
			get { return Target as PlayerObject; }
		}

		public LivingObject AsLiving
		{
			get { return Target as LivingObject; }
		}

		public GameObject AsGO
		{
			get { return Target as GameObject; }
		}

		public UnitBase AsUnit
		{
			get { return Target as UnitBase; }
		}

		public ItemObject AsItem
		{
			get { return Target as ItemObject; }
		}

		#endregion
	}

	public class UnitReference : ObjectReference
	{
		public UnitReference(UnitBase obj)
			: base(obj)
		{
		}

		public UnitReference(ObjectReference other)
			: base(other.Target)
		{
		}

		public UnitBase Unit
		{
			get { return IsAlive ? base.Target as UnitBase : null; }
		}
	}

	public class PlayerReference : ObjectReference
	{
		public PlayerReference(PlayerObject obj)
			: base(obj)
		{
		}

		public PlayerReference(ObjectReference other)
			: base(other.Target)
		{
		}

		public new PlayerObject Target
		{
			get { return IsAlive ? base.Target as PlayerObject : null; }
		}
	}

	public class ItemReference : ObjectReference
	{
		public ItemReference(ItemObject obj)
			: base(obj)
		{
		}

		public ItemReference(ObjectReference other)
			: base(other.Target)
		{
		}

		public new ItemObject Target
		{
			get { return IsAlive ? base.Target as ItemObject : null; }
		}
	}

	public class LivingReference : ObjectReference
	{
		public LivingReference(LivingObject obj)
			: base(obj)
		{
		}

		public LivingReference(ObjectReference other)
			: base(other.Target)
		{
		}

		public new LivingObject Target
		{
			get { return IsAlive ? base.Target as LivingObject : null; }
		}
	}

	public class GOReference : ObjectReference
	{
		public GOReference(GameObject obj)
			: base(obj)
		{
		}

		public GOReference(ObjectReference other)
			: base(other.Target)
		{
		}

		public new GameObject Target
		{
			get { return IsAlive ? base.Target as GameObject : null; }
		}
	}
}