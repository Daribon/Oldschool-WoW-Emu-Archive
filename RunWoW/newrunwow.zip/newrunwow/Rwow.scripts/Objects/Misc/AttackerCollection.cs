using System.Collections.Generic;
using RunServer.Common;
using RunWoW.AI;
using RunWoW.GamePackets;

namespace RunWoW.Objects.Misc
{
	public class AttackerObject : LivingReference
	{
		private float m_aggro;
		private float m_damage;
		private Group m_group;

		public float Aggro
		{
			get { return m_aggro; }
			set { m_aggro = value; }
		}

		public float Damage
		{
			get { return m_damage; }
			set { m_damage = value; }
		}

		public Group Group
		{
			get
			{
				if (!IsAlive)
					return m_group;

				if (IsPlayer)
					return AsPlayer.Group;

				if (Target is IOwnedUnit && ((IOwnedUnit)Target).Owner is PlayerObject)
					return  ((PlayerObject)((IOwnedUnit)Target).Owner).Group;

				return null;
			}
		}

		public AttackerObject(LivingObject obj)
			: base(obj)
		{
			if (obj is PlayerObject)
				m_group = ((PlayerObject)obj).Group;
			else
				if (obj is IOwnedUnit && ((IOwnedUnit)obj).Owner is PlayerObject)
					m_group = ((PlayerObject)((IOwnedUnit)obj).Owner).Group;
		}

		public bool IsGuard
		{
			get { return Target is GuardBase; }
		}
	}

	public class AttackerCollection
	{
		private ulong m_first;
		private bool m_hasGuards;
		private LivingObject m_owner;
		private Dictionary<ulong, AttackerObject> m_attackers = new Dictionary<ulong, AttackerObject>();

		private object m_syncRoot = new object();

		#region Properties

		public ulong FirstAttacker
		{
			get { return m_first; }
		}

		public bool HasGuards
		{
			get { return m_hasGuards; }
		}

		public AttackerObject this[ulong guid]
		{
			get
			{
				lock (SyncRoot)
					return m_attackers.ContainsKey(guid) ? m_attackers[guid] : null;
			}
		}

		public int LivingCount
		{
			get
			{
				return Values.Count;
			}
		}

		public ICollection<LivingObject> Values
		{
			get
			{
				List<LivingObject> result = new List<LivingObject>();

				if (m_owner == null || m_owner.MapTile == null || m_owner.IsDisposed)
					return result;

				List<ulong> toRemove = new List<ulong>();

				lock (m_syncRoot)
				{
					bool firstRemoved = false;
					foreach (AttackerObject attacker in m_attackers.Values)
						if (attacker.IsAlive && attacker.MapTile != null)
							if (
								attacker.MapTile.Map != m_owner.MapTile.Map ||
								!attacker.Target.Attackable ||
								attacker.Target.Position.DistanceAvr(m_owner.Position) > Constants.ExpMaximumRange
								)
							{
								toRemove.Add(attacker.GUID);
								if (attacker.GUID == m_first)
									firstRemoved = true;
							}
							else
								result.Add(attacker.Target);

					foreach (ulong guid in toRemove)
						m_attackers.Remove(guid);

					if (firstRemoved)
					{
						if (m_attackers.Count == 0)
							m_first = 0;
						else
						{
							IEnumerator<AttackerObject> e = m_attackers.Values.GetEnumerator();
							e.MoveNext();
							m_first = e.Current.GUID;
						}

					}
				}

				return result;
			}
		}

		public LivingObject MostAggressive
		{
			get
			{
				float maxAggro = -1f;

				LivingObject result = null;

				lock (SyncRoot)
					foreach (AttackerObject attacker in m_attackers.Values)
						if (
							attacker.IsAlive &&
							attacker.IsLiving &&
							!attacker.Target.IsDisposed &&
							attacker.Aggro > maxAggro &&
							!attacker.AsLiving.NoControl &&
							!attacker.AsLiving.Rooted &&
							!attacker.AsLiving.Stunned &&
							attacker.Target.Position.DistanceAvr(m_owner.Position) < Constants.ExpMaximumRange
							)
						{
							maxAggro = attacker.Aggro;
							result = attacker.AsLiving;
						}


				return result;
			}
		}

		public object SyncRoot
		{
			get { return m_syncRoot; }
		}

		#endregion

		public AttackerCollection(LivingObject owner)
		{
			m_owner = owner;
			Clean();
		}

		public void AddAttacker(ObjectBase enemy)
		{
			AddThreat(enemy, 0f, 0f);
		}

		public void AddThreat(ObjectBase enemy, float aggro, float damage)
		{
			if (enemy == null || enemy.MapTile == null)
				return;

			if (enemy == m_owner)
				return;

			if (!(enemy is LivingObject))
				return;

			AttackerObject attacker;
			lock (SyncRoot)
			{
				bool first = m_attackers.Count == 0;

				if (first || !m_attackers.ContainsKey(enemy.GUID))
					m_attackers.Add(enemy.GUID, attacker = new AttackerObject((LivingObject) enemy));
				else
					attacker = m_attackers[enemy.GUID];

				if (first)
					m_first = enemy.GUID;
			}

			attacker.Aggro += aggro;
			attacker.Damage += damage;

			if (attacker.IsGuard)
				m_hasGuards = true;
		}

		public void Remove(ObjectBase enemy)
		{
			lock (SyncRoot)
				m_attackers.Remove(enemy.GUID);
		}

		public void Clean()
		{
			lock (SyncRoot)
				m_attackers.Clear();

			m_first = 0;
			m_hasGuards = false;
		}

		public bool Contains(ulong guid)
		{
			lock (SyncRoot)
				return m_attackers.ContainsKey(guid);
		}

		public bool Compare(ulong first, ulong second, Vector position)
		{
			AttackerObject one = this[first]; // current enemy
			AttackerObject another = this[second]; // most aggressive

			if (one == null || another == null)
				return true; // do switch

			if (one.AsLiving.NoControl || one.AsLiving.Stunned || one.AsLiving.Rooted)
				return true;

			if (another.Aggro > one.Aggro*1.3f)
				return true; // force switch if aggro more than 30%

			if (another.AsLiving.Position.DistanceAvr(position) < 10 && another.Aggro > one.Aggro*1.1f)
				return true;

			return false;
		}
	}
}