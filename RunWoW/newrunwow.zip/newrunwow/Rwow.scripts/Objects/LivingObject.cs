//
using System;
using System.Collections;
using System.Collections.Generic;
using System.Threading;
using RunServer.Common;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects.Misc;

namespace RunWoW.Objects
{
	public enum UNITSTANDSTATE : byte
	{
		STANDING = 0,
		SITTING = 1,
		SITTINGCHAIR = 2,
		SLEEPING = 3,
		SITTINGCHAIRLOW = 4,
		SITTINGCHAIRMEDIUM = 5,
		SITTINGCHAIRHIGH = 6,
		DEAD = 7,
		KNEEL = 8
	} ;

	public delegate void HitDelegate(
		DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical);

	public delegate void AbsorbCheckDelegate(
		DAMAGETYPE damageType, bool spell, float damage, float resisted, out float absorbed);

	public delegate bool ImmuneCheckDelegate(DAMAGETYPE damageType, DAMAGECATEGORY category, DBSpell spell);

	public delegate bool MoveDelegate(DateTime time);

	public delegate void DodgeDelegate();

	public delegate void BlockDelegate(float value);

	public delegate void HealDelegate(float value, DBSpell spell, ObjectBase healer, bool critical);

	public delegate void CastDelegate(DBSpell spell, ObjectBase enemy);

	public delegate bool DeathDelegate(LivingObject owner, ObjectBase enemy);

	public abstract class LivingObject : ObjectBase
	{
		#region Fields

		///  TODO: change these 5 field to private
		protected float m_combatreach = 1.0f;

		protected float m_bounding = 1.0f;
		protected ulong m_summon = 0;
		protected ulong m_summonedBy = 0;
		protected uint m_createdBySpell = 0;

		protected float m_mindamage = 1;
		protected float m_maxdamage = 1;
		protected float m_minoffhanddamage = 1;
		protected float m_maxoffhanddamage = 1;
		protected float m_minrangeddamage = 1;
		protected float m_maxrangeddamage = 1;
		protected uint m_dynamicflags = 0;
		protected int m_flags = 0;

		protected int m_mountDisplayID = 0;
		protected byte m_sheathed = 0;
		protected byte m_sshift = 0;
		protected byte m_sflags = 0;
		protected byte m_runPose = 0;
		protected UNITSTANDSTATE m_standState = 0;
		protected ulong m_persuaded = 0;

		private int m_attacktime = 2000;
		private int m_offhandattacktime = 2000;
		private int m_rangedattacktime = 2000;

		//private bool m_attacking = false;
		protected int m_exp;
		protected int m_nextLevelExp;

		protected float m_speedmod_base = 1.0f;
		protected float m_speedmod = 1.0f;
		protected float m_coef = 1.0f;

		private ulong m_allowedLooter;
		private uint m_allowedLootGroup;

		protected LivingObject m_enemy;
		private uint m_transformSpell;
		private int m_lastCastPower;

		protected int m_stunned = 0;
		protected int m_rooted = 0;
		protected int m_noControl = 0;
		protected int m_pacified = 0;
		protected int m_silenced = 0;

		private int m_movementFlags;

		private int m_invisLevel;

		private bool m_logDamage = false;
		private bool m_noWeather = false;

		protected UnitAuras m_auras;

		protected UnitModifiers m_modifiers;

		protected SpellModifiers m_spellModifiers;

		private ObjectReference m_guard;

		public AttackerCollection Attackers;

		public DateTime LastHit = CustomDateTime.Now;
		public DateTime LastCast = CustomDateTime.Now;

		public Event CastEvent = null;

		private BaseCombatEvent m_fightEvent = null;

		#endregion

		#region Events

		public event HitDelegate OnTakeDamage;
		public event HitDelegate OnSubmitDamage;

		public event MoveDelegate OnMove;

//		public event AbsorbCheckDelegate OnAbsorbCheck;
		public event ImmuneCheckDelegate OnImmuneCheck;

		public event DodgeDelegate OnDodge;

		public event BlockDelegate OnBlock;

		public event DeathDelegate OnDeath;

		public event CastDelegate OnCast;

//		public event HealDelegate OnHeal;

		#endregion

		#region Properties

		public BaseCombatEvent FightEvent
		{
			get { return m_fightEvent; }
			protected set { m_fightEvent = value; }
		}

		public bool LogDamage
		{
			get { return m_logDamage; }
			set { m_logDamage = value; }
		}

		public bool NoWeather
		{
			get { return m_noWeather; }
			set { m_noWeather = value; }
		}

		public bool Casting
		{
			get { return CastEvent != null && !CastEvent.Finished; }
		}

		public override int MovementFlags
		{
			get { return m_movementFlags; }
			set { m_movementFlags = value; }
		}

		public override float RunningSpeed
		{
			get { return base.RunningSpeed*m_speedmod; }
			set { }
		}

		public override float WalkSpeed
		{
			get { return base.WalkSpeed*m_speedmod; }
			set { }
		}

		public override float RunBackSpeed
		{
			get { return base.RunBackSpeed*m_speedmod; }
			set { }
		}

		//public override float SwimSpeed
		//{
		//    get { return base.SwimSpeed*m_speedmod; }
		//    set
		//    {
		//    }
		//}

		//public override float SwimBackSpeed
		//{
		//    get { return base.SwimBackSpeed*m_speedmod; }
		//    set
		//    {
		//    }
		//}

		public ulong AllowedLooter
		{
			get { return m_allowedLooter; }
			set { m_allowedLooter = value; }
		}

		public uint AllowedLootGroup
		{
			get { return m_allowedLootGroup; }
			set { m_allowedLootGroup = value; }
		}

		public uint TransformSpell
		{
			get { return m_transformSpell; }
			set { m_transformSpell = value; }
		}

		public int LastCastPower
		{
			get { return m_lastCastPower; }
			set { m_lastCastPower = value; }
		}

		public int InvisLevel
		{
			get { return m_invisLevel; }
			set { m_invisLevel = value; }
		}

		public virtual int Exp
		{
			get { return m_exp; }
			set { m_exp = value; }
		}

		public virtual int NextLevelExp
		{
			get { return m_nextLevelExp; }
			set { m_nextLevelExp = value; }
		}

		public bool Attacking
		{
			/*get { return m_attacking; }
			set
			{
				if (value)
					Flags |= 0x80000;
				else
					Flags &= ~0x80000;
				m_attacking = value;
			}*/

			get { return FightEvent != null && !FightEvent.Finished; }
		}

/*		public virtual bool Attacking
		{
			get { return m_attacking; }
			set { m_attacking = value; }
		}*/

		public override SpellProcessor SpellProcessor
		{
			get { return m_spellModifiers; }
		}

		/*public LivingObject Enemy
		{
			get { return m_enemy; }
			set { m_enemy = value; }
		}*/

		public bool Stunned
		{
			get { return m_stunned > 0; }
			set { Interlocked.Add(ref m_stunned, value ? 1 : -1); }
		}

		public bool Rooted
		{
			get { return m_rooted > 0; }
			set { Interlocked.Add(ref m_rooted, value ? 1 : -1); }
		}

		public bool NoControl
		{
			get { return m_noControl > 0; }
			set { Interlocked.Add(ref m_noControl, value ? 1 : -1); }
		}

		public bool Pacified
		{
			get { return m_pacified > 0; }
			set { Interlocked.Add(ref m_pacified, value ? 1 : -1); }
		}

		public bool Silenced
		{
			get { return m_silenced > 0; }
			set { Interlocked.Add(ref m_silenced, value ? 1 : -1); }
		}

		#region UpdateFields

		[UpdateValue(UNITFIELDS.MOUNTDISPLAYID)]
		public int MountDisplayID
		{
			get { return m_mountDisplayID; }
			set
			{
				m_mountDisplayID = value;
				UpdateValue(UNITFIELDS.MOUNTDISPLAYID);
			}
		}

		[UpdateValue(UNITFIELDS.FLAGS)]
		public int Flags
		{
			get { return m_flags; }
			set
			{
				if (m_flags != value)
				{
					m_flags = value;
					UpdateValue(UNITFIELDS.FLAGS);
				}
			}
		}

		[UpdateValue(UNITFIELDS.PERSUADED)]
		public ulong Persuaded
		{
			get { return m_persuaded; }
			set
			{
				m_persuaded = value;
				UpdateValue(UNITFIELDS.PERSUADED);
			}
		}

		[UpdateValue(UNITFIELDS.DYNAMIC_FLAGS)]
		public uint DynamicFlags
		{
			get { return m_dynamicflags; }
			set
			{
				m_dynamicflags = value;
				UpdateValue(UNITFIELDS.DYNAMIC_FLAGS);
			}
		}

		[UpdateValue(UNITFIELDS.MINDAMAGE, Private = true)]
		public virtual float MinDamage
		{
			get { return m_mindamage; }
			set
			{
				m_mindamage = value;
				UpdateValue(UNITFIELDS.MINDAMAGE);
			}
		}

		[UpdateValue(UNITFIELDS.MAXDAMAGE, Private = true)]
		public virtual float MaxDamage
		{
			get { return m_maxdamage; }
			set
			{
				m_maxdamage = value;
				UpdateValue(UNITFIELDS.MAXDAMAGE);
			}
		}

		[UpdateValue(UNITFIELDS.MINOFFHANDDAMAGE, Private = true)]
		public virtual float MinOffhandDamage
		{
			get { return m_minoffhanddamage; }
			set
			{
				m_minoffhanddamage = value;
				UpdateValue(UNITFIELDS.MINOFFHANDDAMAGE);
			}
		}

		[UpdateValue(UNITFIELDS.MAXOFFHANDDAMAGE, Private = true)]
		public virtual float MaxOffhandDamage
		{
			get { return m_maxoffhanddamage; }
			set
			{
				m_maxoffhanddamage = value;
				UpdateValue(UNITFIELDS.MAXOFFHANDDAMAGE);
			}
		}

		[UpdateValue(UNITFIELDS.MINRANGEDDAMAGE, Private = true)]
		public virtual float MinRangedDamage
		{
			get { return m_minrangeddamage; }
			set
			{
				m_minrangeddamage = value;
				UpdateValue(UNITFIELDS.MINRANGEDDAMAGE);
			}
		}

		[UpdateValue(UNITFIELDS.MAXRANGEDDAMAGE, Private = true)]
		public virtual float MaxRangedDamage
		{
			get { return m_maxrangeddamage; }
			set
			{
				m_maxrangeddamage = value;
				UpdateValue(UNITFIELDS.MAXRANGEDDAMAGE);
			}
		}

		[UpdateValue(UNITFIELDS.BASEATTACKTIME)]
		public int AttackTime
		{
			get { return m_attacktime; }
			set
			{
				m_attacktime = value;
				UpdateValue(UNITFIELDS.BASEATTACKTIME);
			}
		}

		[UpdateValue(UNITFIELDS.OFFHANDATTACKTIME)]
		public int OffHandAttackTime
		{
			get { return m_offhandattacktime; }
			set
			{
				m_offhandattacktime = value;
				UpdateValue(UNITFIELDS.OFFHANDATTACKTIME);
			}
		}

		[UpdateValue(UNITFIELDS.RANGEDATTACKTIME)]
		public int RangedAttackTime
		{
			get { return m_rangedattacktime; }
			set
			{
				m_rangedattacktime = value;
				UpdateValue(UNITFIELDS.RANGEDATTACKTIME);
			}
		}

		[UpdateValue(UNITFIELDS.BYTES_1, BytesIndex = 0)]
		public UNITSTANDSTATE StandState
		{
			get { return m_standState; }
			set
			{
				m_standState = value;
				UpdateValue(UNITFIELDS.BYTES_1);
			}
		}

		//private uint m_bytes2 = 4008635904;
		//[UpdateValue(UNITFIELDS.BYTES_2)]
		//public uint Bytes2
		//{
		//    get { return m_bytes2; }
		//    set
		//    {
		//        m_bytes2 = value;
		//        UpdateValue(UNITFIELDS.BYTES_2);
		//    }
		//}

		[UpdateValue(UNITFIELDS.BYTES_2, BytesIndex = 0)]
		public byte Sheathed
		{
			get { return m_sheathed; }
			set
			{
				m_sheathed = value;
				UpdateValue(UNITFIELDS.BYTES_2);
			}
		}

		[UpdateValue(UNITFIELDS.BYTES_1, BytesIndex = 3)]
		public byte RunPose
		{
			get { return m_runPose; }
			set
			{
				m_runPose = value;
				UpdateValue(UNITFIELDS.BYTES_1);
			}
		}

		[UpdateValue(UNITFIELDS.BYTES_1, BytesIndex = 2)]
		public byte SShift
		{
			get { return m_sshift; }
			set
			{
				m_sshift = value;
				UpdateValue(UNITFIELDS.BYTES_1);
			}
		}

		[UpdateValue(UNITFIELDS.BYTES_1, BytesIndex = 1)]
		public byte SFlags
		{
			get { return m_sflags; }
			set
			{
				m_sflags = value;
				UpdateValue(UNITFIELDS.BYTES_1);
			}
		}

		[UpdateValue(UNITFIELDS.COMBATREACH)]
		public float CombatReach
		{
			get { return m_combatreach; }
		}

		[UpdateValue(UNITFIELDS.BOUNDINGRADIUS)]
		public float BoundingRadius
		{
			get { return m_bounding; }
		}

		[UpdateValue(UNITFIELDS.SUMMON)]
		public ulong Summon
		{
			get { return m_summon; }
		}

		[UpdateValue(UNITFIELDS.SUMMONEDBY)]
		public ulong SummonedBy
		{
			get { return m_summonedBy; }
		}

		[UpdateValue(UNITFIELDS.CREATED_BY_SPELL)]
		public uint CreatedBySpell
		{
			get { return m_createdBySpell; }
		}

		[UpdateValue]
		public UnitAuras Auras
		{
			get { return m_auras; }
		}

		#endregion

		public UnitModifiers Modifiers
		{
			get { return m_modifiers; }
		}

		public ObjectReference Guard
		{
			get { return m_guard; }
			set { m_guard = value; }
		}

		#endregion

		#region Abstract properties

		public abstract bool Dead { get; set; }

		public abstract bool Attackable { get; }
		public abstract int Defence { get; }
		public abstract bool InWater { get; set; }

		[UpdateValue(UNITFIELDS.HEALTH)]
		public abstract int Health { get; set; }

		[UpdateValue(UNITFIELDS.MAX_HEALTH)]
		public abstract int MaxHealth { get; set; }

		[UpdateValue(UNITFIELDS.BYTES_0, BytesIndex = 3)]
		public abstract POWERTYPE PowerType { get; set; }

		[UpdateValue(UNITFIELDS.MANA)]
		[UpdateValue(UNITFIELDS.RAGE)]
		[UpdateValue(UNITFIELDS.FOCUS)]
		[UpdateValue(UNITFIELDS.ENERGY)]
		[UpdateValue(UNITFIELDS.POWER5)]
		public abstract int Power { get; set; }

		[UpdateValue(UNITFIELDS.MAX_MANA)]
		[UpdateValue(UNITFIELDS.MAX_RAGE)]
		[UpdateValue(UNITFIELDS.MAX_FOCUS)]
		[UpdateValue(UNITFIELDS.MAX_ENERGY)]
		[UpdateValue(UNITFIELDS.MAX_POWER5)]
		public abstract int MaxPower { get; set; }

		[UpdateValue(UNITFIELDS.STRENGTH, Private = true)]
		public abstract int Strength { get; set; }

		[UpdateValue(UNITFIELDS.AGILITY, Private = true)]
		public abstract int Agility { get; set; }

		[UpdateValue(UNITFIELDS.STAMINA, Private = true)]
		public abstract int Stamina { get; set; }

		[UpdateValue(UNITFIELDS.INTELLECT, Private = true)]
		public abstract int Intellect { get; set; }

		[UpdateValue(UNITFIELDS.SPIRIT, Private = true)]
		public abstract int Spirit { get; set; }


		[UpdateValue(UNITFIELDS.LEVEL)]
		public override int Level
		{
			get { return 0; }
			set { }
		}

		[UpdateValue(UNITFIELDS.FACTION)]
		public abstract override FACTION Faction { get; set; }

		[UpdateValue(UNITFIELDS.DISPLAYID)]
		public abstract int DisplayID { get; set; }

		[UpdateValue(UNITFIELDS.NATIVEDISPLAYID)]
		public virtual int NativeDisplayID
		{
			get { return DisplayID; }
		}

		[UpdateValue(UNITFIELDS.TARGET, Private = true)]
		public abstract ulong Target { get; set; }

		[UpdateValue(UNITFIELDS.RESIST_PHYSICAL, Private = true)]
		public abstract int Resist_Physical { get; set; }

		[UpdateValue(UNITFIELDS.RESIST_HOLY, Private = true)]
		public abstract int Resist_Holy { get; set; }

		[UpdateValue(UNITFIELDS.RESIST_FIRE, Private = true)]
		public abstract int Resist_Fire { get; set; }

		[UpdateValue(UNITFIELDS.RESIST_NATURE, Private = true)]
		public abstract int Resist_Nature { get; set; }

		[UpdateValue(UNITFIELDS.RESIST_FROST, Private = true)]
		public abstract int Resist_Frost { get; set; }

		[UpdateValue(UNITFIELDS.RESIST_SHADOW, Private = true)]
		public abstract int Resist_Shadow { get; set; }

		[UpdateValue(UNITFIELDS.RESIST_ARCANE, Private = true)]
		public abstract int Resist_Arcane { get; set; }

		[UpdateValue(UNITFIELDS.ATTACK_POWER, Private = true)]
		public abstract int AttackPower { get; set; }

		[UpdateValue(UNITFIELDS.ATTACK_POWER_MOD, Private = true)]
		public abstract int AttackPowerModifier { get; set; }

		[UpdateValue(UNITFIELDS.RANGED_ATTACK_POWER, Private = true)]
		public abstract int RangedAttackPower { get; set; }

		[UpdateValue(UNITFIELDS.RANGED_ATTACK_POWER_MOD, Private = true)]
		public abstract int RangedAttackPowerModifier { get; set; }

		#endregion

		protected LivingObject()
			: this(false)
		{
		}

		protected LivingObject(bool partial)
		{
			if (!partial)
				Init();
		}

		protected void Init()
		{
			if (m_spellModifiers == null)
			{
				m_spellModifiers = new SpellModifiers();
				m_modifiers = new UnitModifiers(this);
				m_auras = new UnitAuras(this);

				//Redress();
			}
		}

		protected void InitAttackers()
		{
			if (Attackers == null)
				Attackers = new AttackerCollection(this);
		}


		protected void Deinit()
		{
			m_spellModifiers = null;
			m_modifiers = null;
			if (m_auras != null)
				m_auras.RemoveAllAuras();
			m_auras = null;
		}

		public virtual int GetResist(DAMAGETYPE DamageType)
		{
			int Resist;
			switch (DamageType)
			{
				case DAMAGETYPE.PHYSICAL:
					Resist = Resist_Physical;
					break;
				case DAMAGETYPE.ARCANE:
					Resist = Resist_Arcane;
					break;
				case DAMAGETYPE.FIRE:
					Resist = Resist_Fire;
					break;
				case DAMAGETYPE.FROST:
					Resist = Resist_Frost;
					break;
				case DAMAGETYPE.HOLY:
					Resist = Resist_Holy;
					break;
				case DAMAGETYPE.SHADOW:
					Resist = Resist_Shadow;
					break;
				default:
					Resist = 0;
					break;
			}
			return Resist;
		}

		public virtual void Redress()
		{
			/*for (int i = 0; i < (int) DAMAGETYPE.MAX; i++)
				ModDamage[i] = Modifiers.GetFloat(MODIFIER.ALL_DAMAGE) +
				               (i != (int) DAMAGETYPE.PHYSICAL ? Modifiers.GetFloat(MODIFIER.SPELL_DAMAGE) : 0f);*/

			if (Modifiers == null || Disposed || Dead)
				return;
		}

		public A9Packet DynamicPacket()
		{
			return SingleFieldPacket((int) UNITFIELDS.DYNAMIC_FLAGS);
		}

		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);
			CreateValue(UNITFIELDS.HEALTH, array);
			CreateValue(UNITFIELDS.MAX_HEALTH, array);
			CreateValue((UNITFIELDS) ((int) (UNITFIELDS.MANA)) + (int) PowerType, array);
			CreateValue((UNITFIELDS) ((int) (UNITFIELDS.MAX_MANA)) + (int) PowerType, array);
			CreateValue(UNITFIELDS.LEVEL, array);
			CreateValue(UNITFIELDS.FACTION, array);
			CreateValue(UNITFIELDS.DISPLAYID, array);
			CreateValue(UNITFIELDS.BYTES_0, array);
			CreateValue(UNITFIELDS.BYTES_1, array);
			CreateValue(UNITFIELDS.BYTES_2, array);

			CreateValue(UNITFIELDS.FLAGS, array);
			CreateValue(UNITFIELDS.DYNAMIC_FLAGS, array);
			CreateValue(UNITFIELDS.NATIVEDISPLAYID, array);
			CreateValue(UNITFIELDS.MOUNTDISPLAYID, array);
			CreateValue(UNITFIELDS.BOUNDINGRADIUS, array);
			CreateValue(UNITFIELDS.COMBATREACH, array);
			CreateValue(UNITFIELDS.BASEATTACKTIME, array);
			CreateValue(UNITFIELDS.OFFHANDATTACKTIME, array);
			CreateValue(UNITFIELDS.RANGEDATTACKTIME, array);
		}

		#region Leveling

		public static float HitChance(float baseChance, int weaponLevel, int enemyDefence)
		{
			return (baseChance + (weaponLevel - enemyDefence)/25f)/100f;
		}

		public static int ExperienceForLevel(int level)
		{
			switch (level)
			{
				case 60:
					return 581700;
				case 61:
					return 663460;
				case 62:
					return 703640;
				case 63:
					return 744380;
				case 64:
					return 785820;
				case 65:
					return 827820;
				case 66:
					return 870380;
				case 67:
					return 913640;
				case 68:
					return 957600;
				case 69:
					return 1002120;
			}
			return (int) Math.Round(
		              ( (8*level + LevelDiff(level)) * ( 45 + level*5 ) )/100f)*100;
		}

		private static int LevelDiff(int level)
		{
			if (level <= 28)
				return 0;
			if (level == 29)
				return 1;
			if (level == 30)
				return 3;
			if (level == 31)
				return 6;
			return 5*(level - 30);
		}

		public int CalculateExp()
		{
			return (int) ((45 + Level*5)*m_coef);
		}

		public abstract void LevelUp();

		#endregion

		public virtual void Mount(int dispID)
		{
			Flags |= 0x3000;
			MountDisplayID = dispID;
			UpdateData();
		}

		public void Unmount()
		{
			MountDisplayID = 0;
			Flags &= ~0x3000;
			UpdateData();
		}

		#region Ranged Helpers

		public virtual bool HasRangedAmmo()
		{
			return false;
		}

		public virtual void ConsumeRangedAmmo()
		{
		}

		public virtual void AddRangedDelay()
		{
		}

		#endregion

		#region Combat

		protected abstract void StartFightEvent(LivingObject enemy);

		public virtual void Attacked(LivingObject enemy)
		{
		}

		public virtual void StartCombat(LivingObject targetObject)
		{
			if (targetObject == null || !targetObject.Attackable)
				return;

			if (FightEvent != null && !FightEvent.Finished && FightEvent.Target == targetObject)
				return;

			StartFightEvent(targetObject);

			Target = targetObject.GUID;

			Flags |= 0x80000;
			ShortPacket pkg = new ShortPacket(SMSG.ATTACKSTART);
			pkg.WriteGuid(GUID);
			pkg.WriteGuid(Target);
			MapTile.SendSurrounding(pkg, this);
			UpdateData();
		}

		public virtual void StopCombat()
		{
			Flags &= ~0x80000;
			if (MapTile != null)
			{
				ShortPacket pkg2 = new ShortPacket(SMSG.ATTACKSTOP);
				pkg2.WriteGuid(GUID);
				pkg2.WriteGuid(Target);
//				pkg2.Write((uint) 0);
				MapTile.SendSurrounding(pkg2, this);
			}

			Target = 0;

			if (FightEvent != null)
			{
				BaseCombatEvent ev = FightEvent;
				FightEvent = null;
				ev.Finish();
			}
			//Enemy = null;

			UpdateData();
		}

		#endregion

		protected PooledList<LivingObject> m_killers = null;

		protected PooledList<LivingObject> GetKillers()
		{
			if (m_killers != null)
				return m_killers;

			m_killers = new PooledList<LivingObject>();

			if (Attackers != null && Attackers.FirstAttacker != 0)
			{
				AttackerObject attacker = Attackers[Attackers.FirstAttacker];

				if (attacker != null)
					if (attacker.Group == null)
					{
						AllowedLooter = Attackers.FirstAttacker;
						AllowedLootGroup = 0;

						LivingObject living = attacker.Target;
						m_killers.Add(living);

						if (living is IOwnedUnit)
							m_killers.Add(((IOwnedUnit)living).Owner);
					}
					else
					{
						AllowedLootGroup = (uint) attacker.Group.ID;
						AllowedLooter = 0;

						foreach (PlayerObject member in attacker.Group.LivingMembers)
							m_killers.Add(member);

					}

				Attackers.Clean();
			}

			return m_killers;
		}

		protected void ClearKillers()
		{
			m_killers = null;
		}

		public virtual void Die()
		{
			Dead = true;
			RemoveFromAttackers();

			ClearKillers();

			if (Attackers == null)
				return;

			if (Attackers.HasGuards || this is IOwnedUnit)
			{
				Attackers.Clean();
				return;
			}

			GetKillers();

			foreach (LivingObject enemy in m_killers)
				if (enemy != null && enemy.Position.DistanceAvr(Position) < Constants.ExpMaximumRange)
				{
					int mexp = XPCalculator.CalcXP(enemy, this);
					if (mexp <= 0)
						m_exp = 0;
					else if (enemy.Dead && enemy.Exp + mexp > enemy.NextLevelExp)
						mexp = enemy.NextLevelExp - enemy.Exp - 1; // do not allow levelups while dead

					int value = enemy.KillExperience(this, mexp);

					if (value > 0)
					{
						enemy.Exp += value;

						enemy.LevelUp();
					}
					if (value != -1)
						enemy.UpdateData();

					if (enemy is PlayerObject)
						((PlayerObject) enemy).Quests.CheckSlain(Entry, (long) GUID);
				}

			UpdateData();
		}

		protected virtual int KillExperience(LivingObject victim, int exp /*., int levelGap*/)
		{
			return exp;
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				//if (Name!=null)
				//    Console.WriteLine("Called SaveAndRemove for living {0}", Name);
				if (m_auras != null)
				{
					try
					{
						m_auras.SaveAndRemove();
					}
					catch (Exception e)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Error while removing auras: " + e);
					}
				}
				m_auras = null;
				m_modifiers = null;
				m_spellModifiers = null;
				if (Attackers != null)
					Attackers.Clean();
				Attackers = null;
				ClearKillers();
			}
			base.Dispose(disposing);
		}

		#region Damage Submitters

		public virtual bool SubmitMeleeDamage(LivingObject enemy)
		{
			return enemy.TakeMeleeDamage(this, null, DAMAGETYPE.PHYSICAL, MinDamage, MaxDamage,
			                             HitChance(95f, Level*5, enemy.Defence),
			                             HitChance(5f, Level*5, enemy.Defence), false);
		}

		public virtual bool SubmitMeleeDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float minDamage,
		                                      float maxDamage, bool instant)
		{
			return enemy.TakeMeleeDamage(this, spell, damageType, MinDamage + minDamage, MaxDamage + maxDamage,
			                             HitChance(95f, Level*5, enemy.Defence),
			                             HitChance(5f, Level*5, enemy.Defence), false);
		}

		public virtual bool SubmitMeleeDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float percent)
		{
			return enemy.TakeMeleeDamage(this, spell, damageType, MinDamage*percent, MaxDamage*percent,
			                             HitChance(95f, Level*5, enemy.Defence),
			                             HitChance(5f, Level*5, enemy.Defence), false);
		}

		public virtual bool SubmitRangedDamage(LivingObject enemy, DBSpell spell)
		{
			return
				enemy.TakeRangedDamage(this, spell, DAMAGETYPE.PHYSICAL, MinRangedDamage, MaxRangedDamage,
				                       HitChance(95f, Level*5, enemy.Defence),
				                       HitChance(5f, Level*5, enemy.Defence));
		}

		public virtual bool SubmitRangedDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float minDamage,
		                                       float maxDamage)
		{
			return
				enemy.TakeRangedDamage(this, spell, damageType, MinRangedDamage + minDamage, MaxRangedDamage + maxDamage,
				                       HitChance(95f, Level*5, enemy.Defence),
				                       HitChance(5f, Level*5, enemy.Defence));
		}

		public virtual bool SubmitRangedDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float percent)
		{
			return
				enemy.TakeRangedDamage(this, spell, damageType, MinRangedDamage*percent,
				                       MaxRangedDamage*percent,
				                       HitChance(95f, Level*5, enemy.Defence),
				                       HitChance(5f, Level*5, enemy.Defence));
		}

		public virtual bool SubmitMagicDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float minDamage,
		                                      float maxDamage)
		{
			return enemy.TakeMagicDamage(this, spell, damageType, minDamage, maxDamage, 0.95f, 0.10f);
		}

		public virtual bool SubmitPeriodicDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE DamageType,
		                                         float minDamage, float maxDamage)
		{
			return enemy.TakePeriodicDamage(this, spell, DamageType, minDamage, maxDamage);
		}

		#endregion

		# region Damage Takers

		public virtual bool TakeMeleeDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage,
		                                    float maxDamage,
		                                    float hitChance, float critChance, bool offhand)
		{
			return
				DoTakeDamage(enemy, DamageType, DAMAGECATEGORY.MELEE, minDamage, maxDamage, hitChance, critChance, 0.0f,
				             0.0f, Defence/2500f, spell, offhand);
		}

		public virtual bool TakeRangedDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage,
		                                     float maxDamage, float hitChance, float critChance)
		{
			return
				DoTakeDamage(enemy, DamageType, DAMAGECATEGORY.RANGED, minDamage, maxDamage, hitChance, critChance, 0.0f,
				             0.0f, Defence/2500f, spell, false);
		}

		public virtual bool TakeMagicDamage(ObjectBase enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage,
		                                    float maxDamage, float hitChance, float critChance)
		{
			return
				DoTakeDamage(enemy, DamageType, DAMAGECATEGORY.MAGIC, minDamage, maxDamage, hitChance, critChance, 0.0f,
				             0.0f, 0.0f, spell, false);
		}

		public virtual bool TakePeriodicDamage(ObjectBase enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage,
		                                       float maxDamage)
		{
			return
				DoTakeDamage(enemy, DamageType, DAMAGECATEGORY.PERIODIC, minDamage, maxDamage, 1.0f, 0.0f, 0.0f, 0.0f,
				             0.0f, spell, false);
		}

		public virtual bool TakeEnvironmentDamage(ObjectBase enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage,
		                                          float maxDamage)
		{
			return
				DoTakeDamage(enemy, DamageType, DAMAGECATEGORY.ENVIRONMENTAL, minDamage, maxDamage, 1.0f, 0.0f, 0.0f,
				             0.0f, 0.0f, spell, false);
		}

		#endregion

		public bool IsImmune(DAMAGETYPE damageType, DAMAGECATEGORY category, DBSpell spell)
		{
			return OnImmuneCheck != null && OnImmuneCheck(damageType, category, spell);
		}

		public virtual bool DoTakeDamage(
			ObjectBase enemy,
			DAMAGETYPE damageType,
			DAMAGECATEGORY damageCategory,
			float minDamage,
			float maxDamage,
			float hitChance,
			float critChance,
			float blockChance,
			float parryChance,
			float dodgeChance,
			DBSpell spell,
			bool offhand
			)
		{
			if (Health <= 0)
				return true;

			VICTIMSTATE victimState;

			float damage = Utility.Random(minDamage, maxDamage);

			float resisted;
			float absorbed = 0f;
			float blocked = 0f;

			float levelDiff = 0.002f*(enemy.Level - Level);

			bool critical = false; // critical damage
			bool forceHit = false; // no dodge/crit/parry on that damage (magic, periodic, env, etc.)
			bool canMiss = true;
			bool forceMiss = false; // fully resisted or dodged/parried

			if (this is PlayerObject && LogDamage)
				Chat.System(((PlayerObject) this).BackLink.Client,
				            string.Format("Taking Damage: {0}, School {1}, value {2}, level diff {3}", damageCategory, damageType,
				                          damage, levelDiff));

			if (enemy is PlayerObject && ((PlayerObject) enemy).LogDamage)
				Chat.System(((PlayerObject) enemy).BackLink.Client,
				            string.Format("Placing Damage: {0}, School {1}, value {2}, level diff {3}", damageCategory, damageType,
				                          damage, levelDiff));

			float multiplier = 1f;

			switch (damageCategory)
			{
				case DAMAGECATEGORY.MELEE:
					if (critical = Utility.Chance(critChance + levelDiff))
						multiplier = 2.0f;
					if (spell != null && !spell.NextAttackSpell)
						forceHit = true;
					break;
				case DAMAGECATEGORY.RANGED:
					if (critical = Utility.Chance(critChance + levelDiff))
						multiplier = 2.0f;
					forceHit = true;
					canMiss = false;
					break;
				case DAMAGECATEGORY.MAGIC:
					if (critical = Utility.Chance(critChance + levelDiff))
						multiplier = 1.5f;
					forceHit = true;
					canMiss = false;
					break;
				case DAMAGECATEGORY.ENVIRONMENTAL:
				case DAMAGECATEGORY.PERIODIC:
					critical = false;
					forceHit = true;
					canMiss = false;
					break;
			}

			if (critical && spell != null && enemy is LivingObject)
				multiplier += enemy.SpellProcessor.AdditionalCritDamage(spell);

			damage = damage*multiplier;

			#region Resist calculation

			float Resist = GetResist(damageType);
			float ResistPercent;

			if (Resist == -1)
				ResistPercent = 1f;
			else
			{
				if (damageType == DAMAGETYPE.PHYSICAL)
				{
					ResistPercent = Resist/(Resist + 85.0f*enemy.Level + 400.0f);
					if (ResistPercent > 0.75f)
						ResistPercent = 0.75f;
				}
				else
				{
					if (spell == null || !spell.IsBinary)
					{
						ResistPercent = (float) Math.Round(3*Resist/(enemy.Level*5))/4f;
						if (ResistPercent > 1f)
							ResistPercent = 1f;
					}
					else
						ResistPercent = 0f;
				}
			}

			resisted = ResistPercent*damage;

			#endregion

			//LogConsole.WriteLine(LogLevel.TRACE, "Submitting damage type " + damageType + ", Magic: " + Magic + ", value: " + Damage + ", absorb: " + Absorbed);

			HITINFO hitFlag = HITINFO.NORMALSWING2 | HITINFO.NOSOUND;
			if (offhand)
				hitFlag |= HITINFO.LEFTSWING;

			int swingFlag = 1;

			if (Resist == -1 || resisted >= damage || IsImmune(damageType, damageCategory, spell)) // immune or resisted
			{
				victimState = VICTIMSTATE.DEFLECT;
				forceMiss = true;
                hitFlag = HITINFO.RESIT;
			}
			else if (critical)
			{
                victimState = VICTIMSTATE.NORMAL;

				if (enemy is UnitBase && this is PlayerObject && Level < enemy.Level - Constants.MonsterFriendlyLevel &&
				    Utility.Chance(0.1))
				{
					damage *= 1.2f;
					hitFlag |= HITINFO.CRUSHING;
					hitFlag &= ~HITINFO.NORMALSWING2;
				}
				else
				{
					hitFlag |= HITINFO.CRITICALHIT;
					hitFlag &= ~HITINFO.NORMALSWING2;
				}
				/*if (enemy != this && enemy is LivingObject)
					if (((LivingObject) enemy).OnSubmitCrit != null)
						((LivingObject)enemy).OnSubmitCrit(damageType, damageCategory, damage, spell, this);

				if (OnTakeCrit != null)
					OnTakeCrit(damageType, damageCategory, damage, spell, enemy);*/
			}
			else if (!forceHit && dodgeChance > 0 && Utility.Chance(dodgeChance - levelDiff)) // self dodge chance
			{
				victimState = VICTIMSTATE.DODGE;
				forceMiss = true;
				if (OnDodge != null)
					OnDodge();
			}
			else if (!forceHit && blockChance > 0 && Utility.Chance(blockChance - levelDiff)) // self block chance
			{
				victimState = VICTIMSTATE.BLOCK;
				blocked = Utility.Random(0f, damage - absorbed - resisted);
				if (OnBlock != null)
					OnBlock(blocked);
			}
			else if (!forceHit && parryChance > 0 && Utility.Chance(parryChance - levelDiff)) // self parry chance
			{
				victimState = VICTIMSTATE.PARRY;
				forceMiss = true;
			}
			else if (!canMiss || Utility.Chance(hitChance + levelDiff))
			{
				victimState = VICTIMSTATE.NORMAL;
			}
			else // miss
			{
				hitFlag = HITINFO.MISS;
				forceMiss = true;
				victimState = VICTIMSTATE.NONE;
			}

			float ResultDamage;
			if (forceMiss)
			{
				ResultDamage = damage = absorbed = resisted = 0f;
			}
			else
			{
/*				if (victimState == VICTIMSTATE.WOUND && resisted < damage && OnAbsorbCheck != null)
				{
					Delegate[] list = OnAbsorbCheck.GetInvocationList();

					foreach (AbsorbCheckDelegate absorber in list)
					{
						float abs;
						absorber(damageType,
						         damageCategory == DAMAGECATEGORY.MAGIC || damageCategory == DAMAGECATEGORY.PERIODIC,
						         damage - absorbed, resisted, out abs);
						absorbed += abs;
					}
				}
*/

				ResultDamage = damage - absorbed - resisted - blocked;
				if (ResultDamage < 0)
					ResultDamage = 0;
			}

			ShortPacket damageLog = null;
			switch (damageCategory)
			{
				case DAMAGECATEGORY.MELEE:
					if (spell != null) // TODO: modify Melee log
						damageLog =
							DamageLog.Magic(GUID, enemy.GUID, spell.ObjectId, damageType, ResultDamage, absorbed, resisted, blocked,
                                            critical, victimState);
					else
						damageLog =
							DamageLog.Melee(GUID, enemy.GUID, damageType, (uint) hitFlag, (byte) swingFlag, damage, absorbed,
                                            resisted, blocked, victimState, critical);
					break;
				case DAMAGECATEGORY.MAGIC:
				case DAMAGECATEGORY.RANGED:
					damageLog =
						DamageLog.Magic(GUID, enemy.GUID, spell.ObjectId, damageType, ResultDamage, absorbed, resisted, blocked,
						                critical, victimState);
					break;
				case DAMAGECATEGORY.PERIODIC:
					damageLog = DamageLog.Periodic(GUID, enemy.GUID, spell.ObjectId, damageType, ResultDamage, resisted);
					break;
				case DAMAGECATEGORY.ENVIRONMENTAL:
					damageLog =
						DamageLog.Environment(GUID, enemy.GUID, spell == null ? 0 : spell.ObjectId, damageType, ResultDamage, absorbed);
					break;
			}
			if (damageLog != null && MapTile != null)
				MapTile.SendSurrounding(damageLog, this);

			if (enemy != this)
			{
				AddThreat(enemy, damage + 1f, ResultDamage);
				if (enemy is IOwnedUnit)
					AddThreat(((IOwnedUnit) enemy).Owner, 1f, 0f);
			}

			Health -= (int) (ResultDamage);

			if (enemy is LivingObject)
				if (((LivingObject) enemy).OnSubmitDamage != null)
					((LivingObject) enemy).OnSubmitDamage(damageType, damageCategory, damage, spell, this, critical);


			bool result = true;

			if (Health <= 0)
			{
				StopCombat();

				if (OnDeath == null || OnDeath(this, enemy))
				{
					Die();
					result = false;
				}
			}
			else if (OnTakeDamage != null)
				OnTakeDamage(damageType, damageCategory, ResultDamage, spell, enemy, critical);

			UpdateData();

			if ( /*!enemy.IsDisposed && */!(this is PlayerObject))
			{
				/*CompressedA9Packet update = new CompressedA9Packet(UpdatePacketSmall);
				update.Aquire();*/

				/*PlayerObject player = enemy as PlayerObject;
				if (player != null)
					player.BackLink.Client.Send(update);*/
				if (MapTile != null)
					MapTile.SendCompressed(new DelayedCompressedA9Packet(UpdatePacketSmall), this);

				//update.Release();
			}
			/*else
				UpdateData();*/

			return result;
		}

		public virtual bool Moved(DateTime time, bool positionChanged)
		{
			if (OnMove != null && positionChanged)
				return OnMove(time);
			return true;
		}

		#region Aggro and Damage count

		private void CheckAttackers()
		{
			if (Attackers.LivingCount > 0)
				DynamicFlags = (uint) (DynamicFlags | 4);
			else
				DynamicFlags = (uint) (DynamicFlags & ~4);
		}

		public void AddThreat(ObjectBase enemy, float aggro)
		{
			AddThreat(enemy, aggro, 0f);
		}

		public void AddThreat(ObjectBase enemy, float aggro, float damage)
		{
			Attackers.AddThreat(enemy, aggro, damage);
			if ((DynamicFlags & 4) == 0)
				CheckAttackers();

			//LivingObject lenemy = enemy as LivingObject;
		}

		public void RemoveAttacker(LivingObject enemy)
		{
			Attackers.Remove(enemy);
			CheckAttackers();
		}

		public void RemoveFromAttackers()
		{
			if (Attackers != null)
			{
				ICollection<LivingObject> toRemove = Attackers.Values;

				foreach (LivingObject attacker in toRemove)
					attacker.RemoveAttacker(this);
			}
		}

		public void ClearAttackers()
		{
			DynamicFlags = (uint) (DynamicFlags & ~4);
			if (Attackers != null)
				Attackers.Clean();
		}

		#endregion

		public void Cast(DBSpell spell, ICollection<ObjectBase> values)
		{
			if (OnCast != null)
				foreach (ObjectBase obj in values)
					OnCast(spell, obj);
		}
	}
}