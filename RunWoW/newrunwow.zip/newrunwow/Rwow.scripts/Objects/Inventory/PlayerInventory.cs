//
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.Objects.Inventory
{
	public class PlayerInventory : BaseInventory
	{
		public PlayerInventory(PlayerObject owner)
			: base(owner, (int)PLAYERFIELDS.INV_SLOTS, (int)INVSLOT.PLAYER_INVENTORY_SLOTS)
		{
			CustomArrayList in_bags = new CustomArrayList();

			if (owner.Character.Items != null)
				foreach (DBItem item in owner.Character.Items)
					if ((ulong) item.ContainerID != owner.GUID && item.ContainerID != 0)
						in_bags.Add(item);
					else if (CreateItem(item, false) == null)
						DBManager.EraseDBObject(item);

			foreach (DBItem item in in_bags)
			{
				if (item.ContainerID == -1)
					continue;
				ContainerObject ibag = FindBag((ulong) item.ContainerID) as ContainerObject;
				if (ibag == null)
				{
					LogConsole.WriteLine(LogLevel.ERROR, "Bag not find for object " + item.Template.Name);
					DBManager.EraseDBObject(item);
					continue;
				}
				if (ibag.Inventory.CreateItem(item, false) == null)
					DBManager.EraseDBObject(item);
			}
			
			in_bags.Dispose();
		}

		public override PlayerObject Owner
		{
			get { return (PlayerObject) m_owner; }
		}

		/*public ItemObject GetItem(INVSLOT slot)
		{
			return GetItem((int)slot);
		}*/

		/*public ItemObject this[INVSLOT slot]
		{
			get { return GetItem((int)slot);}
		}*/

		public ItemObject FindBag(ulong GUID)
		{
			for (byte i = (byte) INVSLOT.BAGFIRST; i <= (byte) INVSLOT.BAGLAST; i++)
				if (m_invObjects[i] != null && m_slots[i] == GUID)
					return m_invObjects[i];
			for (byte i = (byte) INVSLOT.BANKBAG_FIRST; i <= (byte) INVSLOT.BANKBAG_LAST; i++)
				if (m_invObjects[i] != null && m_slots[i] == GUID)
					return m_invObjects[i];
			return null;
		}

		public override BaseInventory GetSubContainer(byte num)
		{
			if (num == 255)
				return this;
			/*if (num<5)
			{*/
			ItemObject bag = this[num];
			return bag == null ? null : ((ContainerObject) bag).Inventory;
			/*}
			if (num==5) // bank
				return this;
			return null;*/
		}

		/*public override bool ISSubContainer(byte slot)
		{
			return slot>=(byte)INVSLOT.BAGFIRST&&slot<=(byte)INVSLOT.BAGLAST;
		}*/
		/*public override void InitCreateFields()
		{
			for(int i = 0;i <= (int)INVSLOT.MAX;i++)
				if(m_slots[i] != 0)
					UpdateSlot(i);
		}*/

		public override byte SubFirst
		{
			get { return (byte) INVSLOT.BAGFIRST; }
		}

		public override byte SubLast
		{
			get { return (byte) INVSLOT.BAGLAST; }
		}

		public override byte Divider
		{
			get { return (byte) INVSLOT.BACKPACK_FIRST; }
		}

		public override byte Last
		{
			get { return (byte) INVSLOT.BACKPACK_LAST + 1; }
		}

		public override bool Visible(int slot)
		{
			return false; /*slot<=(int)INVSLOT.EQUIPPEDLAST;*/
		}

		public override bool Equipment(int slot)
		{
			return slot <= (int) INVSLOT.EQUIPPEDLAST;
		}
	}
}