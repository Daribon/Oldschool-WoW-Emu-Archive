//
using System;
using System.Collections;
using System.Collections.Specialized;
using RunServer.Common;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects.Misc;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.Objects
{
	[UpdateObject(MaxFields=(int) GAMEOBJECTFIELDS.MAX)]
	public class GameObject : ObjectBase, ILootable
	{
		private UpdateVector m_position;

		private float m_facing;
		private uint m_flags;
		private int m_level;
		private FACTION m_faction;
		private int m_timestamp;
		private int m_state;
		private int m_dynflags;
		private float[] m_rotation;
		private DBGameObject m_go;
		private volatile bool m_used;
		private DateTime m_use_time;
		private Event m_onremove;
		private ulong m_creator;

		private PooledList<LootHolder> m_loot;
		private PooledList<PlayerReference> m_looters;

		public HybridDictionary Openers = null;
		private SpellProcessor m_spellProcessor;

		private Vector m_portalTarget;
		private uint m_portalWorld;
		private uint m_portalInstance;

		#region Custom portal

		public Vector PortalTarget
		{
			get { return m_portalTarget; }
			set { m_portalTarget = value; }
		}

		public uint PortalWorld
		{
			get { return m_portalWorld; }
			set { m_portalWorld = value; }
		}

		public uint PortalInstance
		{
			get { return m_portalInstance; }
			set { m_portalInstance = value; }
		}

		#endregion

		public bool Used
		{
			get { return m_used; }
			set { m_used = value; }
		}

		
		[UpdateValue(GAMEOBJECTFIELDS.POS)]
		public UpdateVector NPosition
		{
			get { return m_position; }
		}

		public GameObject(DBGameObject go)
			: this(go, -1, null)
		{
		}

		public GameObject(DBGameObject go, int time, MapInstance map)
		{
			m_go = go;
			m_position = new UpdateVector(go.Position);
			m_facing = go.Facing;
			m_rotation = go.Rotation;
			m_faction = go.Faction;
			m_level = go.Level;
			m_flags = go.Flags;
			m_state = 1; //go.State;
			m_used = false;
			m_onremove = null;
			m_timestamp = Utility.Timestamp();
			m_dynflags = 1;

			m_guid = ObjectManager.NextGUID();
			m_guid += 0xE000000000000;

			Openers = new HybridDictionary();

			if (map != null)
			{
				map.Enter(this);
				ShortPacket pkg = new ShortPacket(SMSG.GAMEOBJECT_SPAWN_ANIM);
				pkg.Write(m_guid);
				MapTile.SendSurrounding(pkg, this);

				if (time != -1)
				{
					map.AddDespawn(this, time/1000);
				}
			}

			m_spellProcessor = new SpellProcessor();
		}

		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);

			CreateValue(GAMEOBJECTFIELDS.CREATEDBY, array);
			CreateValue(GAMEOBJECTFIELDS.DISPLAYID, array);
			CreateValue(GAMEOBJECTFIELDS.FLAGS, array);
			CreateValue(GAMEOBJECTFIELDS.POS, array);
			CreateValue(GAMEOBJECTFIELDS.STATE, array);
			CreateValue(GAMEOBJECTFIELDS.FACING, array);
			CreateValue(GAMEOBJECTFIELDS.DYN_FLAGS, array);
			CreateValue(GAMEOBJECTFIELDS.ROTATION, array);
			CreateValue(GAMEOBJECTFIELDS.ROTATION + 1, array);
			CreateValue(GAMEOBJECTFIELDS.ROTATION + 2, array);
			CreateValue(GAMEOBJECTFIELDS.ROTATION + 3, array);
			CreateValue(GAMEOBJECTFIELDS.FACTION, array);
			CreateValue(GAMEOBJECTFIELDS.LEVEL, array);
			CreateValue(GAMEOBJECTFIELDS.TYPE_ID, array);
		}

		#region OBJECTFIELDS

		public override HIER_OBJECTTYPE HierType
		{
			get { return HIER_OBJECTTYPE.GAMEOBJECT; }
		}

		public override uint Entry
		{
			get { return Template.ObjectId; }
		}

		public override float Scale
		{
			get { return Template.Scale > 0 ? Template.Scale : 1f; }
		}

		#endregion

		#region Object Properties

		public PooledList<LootHolder> Loot
		{
			get { return m_loot; }
			set { m_loot = value; }
		}

		public PooledList<PlayerReference> Looters
		{
			get { return m_looters; }
			set { m_looters = value; }
		}

		public int Money
		{
			get { return 0; }
		}

		public override OBJECTTYPE ObjectType
		{
			get { return OBJECTTYPE.GAMEOBJECT; }
		}

		[UpdateValue(GAMEOBJECTFIELDS.CREATEDBY)]
		public ulong Creator
		{
			get { return m_creator; }
			set
			{
				m_creator = value;
				UpdateValue(GAMEOBJECTFIELDS.CREATEDBY);
			}
		}

		public override Vector Position
		{
			get { return m_position; }
			set
			{
				m_position = new UpdateVector(value);
				//UpdateValue(GAMEOBJECTFIELDS.POS);
			}
		}

		[UpdateValue(GAMEOBJECTFIELDS.FACING)]
		public override float Facing
		{
			get { return m_facing; }
			set
			{
				m_facing = value;
				UpdateValue(GAMEOBJECTFIELDS.FACING);
			}
		}

		[UpdateValue(GAMEOBJECTFIELDS.ROTATION, ArraySize=4)]
		public float[] Rotation
		{
			get { return m_rotation; }
			set
			{
				m_rotation = value;
				UpdateValue(GAMEOBJECTFIELDS.ROTATION);
			}
		}

		#endregion

		#region GAMEOBJECTFIELDS

		[UpdateValue(GAMEOBJECTFIELDS.DISPLAYID)]
		public int DisplayID
		{
			get { return Template.DisplayID; }
		}

		[UpdateValue(GAMEOBJECTFIELDS.TYPE_ID)]
		public int TypeID
		{
			get { return Template.TypeID; }
		}

		[UpdateValue(GAMEOBJECTFIELDS.FACTION)]
		public override FACTION Faction
		{
			get { return m_faction; }
			set
			{
				m_faction = value;
				UpdateValue(GAMEOBJECTFIELDS.FACTION);
			}
		}

		[UpdateValue(GAMEOBJECTFIELDS.FLAGS)]
		public uint Flags
		{
			get { return m_flags; }
			set
			{
				m_flags = value;
				UpdateValue(GAMEOBJECTFIELDS.FLAGS);
			}
		}

		[UpdateValue(GAMEOBJECTFIELDS.LEVEL)]
		public override int Level
		{
			get { return m_level > 100 ? m_level - 100 : m_level; }
			set
			{
				m_level = value;
				UpdateValue(GAMEOBJECTFIELDS.LEVEL);
			}
		}

//#if !BURNING_CRUSADE
//		[UpdateValue(GAMEOBJECTFIELDS.TIMESTAMP)]
//#endif
			public int Timestamp
		{
			get { return m_timestamp; }
			set
			{
				m_timestamp = value;
//#if !BURNING_CRUSADE
//				UpdateValue(GAMEOBJECTFIELDS.TIMESTAMP);
//#endif
			}
		}

		[UpdateValue(GAMEOBJECTFIELDS.STATE)]
		public int State
		{
			get { return m_state; }
			set
			{
				m_state = value;
				UpdateValue(GAMEOBJECTFIELDS.STATE);
			}
		}

		[UpdateValue(GAMEOBJECTFIELDS.DYN_FLAGS)]
		public int DynamicFlags
		{
			get { return m_dynflags; }
			set
			{
				m_dynflags = value;
				UpdateValue(GAMEOBJECTFIELDS.DYN_FLAGS);
			}
		}

		#endregion

		protected override int UpdatePacketFlags(bool isPrivate)
		{
			if (Constants.BurningCrusade)
				return 0x58;
			else
				return 0x50;
		}

		public override SpellProcessor SpellProcessor
		{
			get { return m_spellProcessor; }
		}

		public DBGameObject DBGameObject
		{
			get { return m_go; }
		}

		public DBGOTemplate Template
		{
			get { return m_go.Template; }
		}

		public override string Name
		{
			get { return m_go.Template.Name; }
			set { }
		}

		public DateTime UseTime
		{
			get { return m_use_time; }
			set { m_use_time = value; }
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_onremove != null)
					m_onremove.Start();
				if (MapTile != null)
				{
					ShortPacket pkg = new ShortPacket(SMSG.GAMEOBJECT_DESPAWN_ANIM);
					pkg.Write(m_guid);
					MapTile.SendSurrounding(pkg, this);
					MapTile.Map.Leave(this);
				}
				if (Openers != null)
					Openers.Clear();
				m_loot = null;
				m_looters = null;
			}
			base.Dispose(disposing);
		}

		public void UpdateValue(GAMEOBJECTFIELDS field)
		{
			UpdateValue((int) field);
		}

		public void CreateValue(GAMEOBJECTFIELDS field, BitArray array)
		{
			CreateValue((int) field, array);
		}

		public A9Packet DynamicPacket()
		{
			return SingleFieldPacket((int) GAMEOBJECTFIELDS.DYN_FLAGS);
		}

		public static void Initialize()
		{
			UpdateManager.Instance.Register(typeof (GameObject));
		}

		public bool AllowLoot(PlayerObject looter)
		{
			return true;
		}

		public void GenerateLoot()
		{
			if (m_loot != null || m_go == null)
				return;
			
			if (m_go.Loot == null)
				Database.Instance.ResolveRelations(m_go, typeof(DBGOLoot));

			m_loot = new PooledList<LootHolder>();

			if (m_go.Loot.Count == 0)
			{
				LogConsole.WriteLine(LogLevel.SYSTEM, "No go loot for object {0}, loot group {1}", m_go.ObjectId, m_go.LootGroupID);
				return;
			}

			try
			{
				foreach (DBGOLoot loot in m_go.Loot)
				{
					if (loot == null)
						continue;
					bool chance = Utility.Chance(loot.Percentage/100.0f);
					if (!chance)
						continue;

					DBItemTemplate template = loot.Target;
					if (template == null)
					{
						Console.WriteLine("Unknown item in loot: " + loot.TargetID);
						continue;
					}

					int count = 1;
					switch (loot.Category)
					{
						case LootCategory.ITEM:
						case LootCategory.LOOT:
							count = template.MaxStack > 1 ? Utility.Random(1, 3) : 1;
							break;
						case LootCategory.QUEST:

							bool drop = false;

							foreach (PlayerObject player in Openers.Values)
								if (player != null && player.Quests.NeedGather(loot.TargetID, ref count))
								{
									drop = true;
									break;
								}

							if (!drop && template.StartQuestID != 0)
								foreach (PlayerObject player in Openers.Values)
									if (
										player != null &&
										!player.Quests.Has((uint) template.StartQuestID) &&
										!player.Quests.HasOld((uint) template.StartQuestID) &&
										player.Inventory.FindItem(loot.TargetID) == null
										)
									{
										drop = true;
										break;
									}
							if (!drop)
								continue;
							break;
						default:
							LogConsole.WriteLine(LogLevel.ECHO,
							                     "Wrong loot category " + loot.Category + " for GameObject");
							break;
					}

					DBItem item = new DBItem(template);
					item.StackCount = count;
					Loot.Add(new LootHolder(item));
				}
			}
			catch
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error generating loot for " + Name);
			}
		}

		public bool FireTrap(LivingObject victim)
		{
			int spellid = Template.Sound[3];
			DBSpell spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellid);
			if (spell != null)
				//SpellManager.Cast(this, victim, spell);
			{
				SingleTargetCast cast = new SingleTargetCast(this, spell, 0x2, victim, true);
				cast.Start();
			}
			else
				LogConsole.WriteLine(LogLevel.ERROR, "Empty spell for trap " + Name);
			if (m_go.New) // handmade trap
			{
				/*DespawnEvent despawn = new DespawnEvent(this, 0);
				despawn.Start();*/
				return true;
			}
			return false;
		}

		public virtual bool SubmitEnvironmentDamage(LivingObject Enemy, DBSpell spell, DAMAGETYPE DamageType,
		                                            float minDamage, float maxDamage)
		{
			return Enemy.TakeEnvironmentDamage(this, spell, DamageType, minDamage, maxDamage);
		}

		public virtual bool SubmitMagicDamage(LivingObject Enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage,
		                                      float maxDamage)
		{
			//Console.WriteLine("GO hitting " + Enemy.Name + " for " + minDamage + "-" + maxDamage);
			return Enemy.TakeMagicDamage(this, spell, DamageType, minDamage, maxDamage, 0.95f, 0.10f);
		}

		public virtual bool SubmitPeriodicDamage(LivingObject Enemy, DBSpell spell, DAMAGETYPE DamageType,
		                                         float minDamage, float maxDamage)
		{
			return Enemy.TakePeriodicDamage(this, spell, DamageType, minDamage, maxDamage);
		}

		public void Opened(PlayerObject obj)
		{
			Openers[obj.GUID] = obj;
			if (!m_used)
			{
				m_used = true;
				MapTile.Map.AddGORespawn(m_go, (Utility.Random(Constants.GoRespawnTime, Constants.GoRespawnTime*m_level)));
			}
		}

		public static void Respawn(MapInstance map, DBGameObject param)
		{
			new GameObject(param, -1, map);
		}
	}
}