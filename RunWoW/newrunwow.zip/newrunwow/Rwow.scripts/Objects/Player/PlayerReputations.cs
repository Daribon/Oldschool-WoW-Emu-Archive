//
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.Objects.Player
{
	public struct Reputation
	{
		public FACTION Faction;
		public byte State;
		public int Value;
		public int Standing;

		public Reputation(FACTION faction, byte state, int value, int standing)
		{
			Faction = faction;
			Value = value;
			State = state;
			Standing = standing;
		}
	}

	public class PlayerReputations
	{
		private PlayerObject m_owner;
		///  TODO: db persistance
		private Reputation[] m_reputations = new Reputation[64];

		public Reputation[] Reputations
		{
			get { return m_reputations; }
		}

		public PlayerReputations(PlayerObject owner)
		{
			m_owner = owner;

			/// TODO: do this only on first run
			switch (m_owner.Race)
			{
				case RACE.HUMAN:
				case RACE.DWARF:
				case RACE.NIGHTELF:
				case RACE.GNOME:
				case RACE.DRAENEI:
					Set(FACTION.STORMWIND, 17, 0);
					Set(FACTION.IRONFORGE, 17, 0);
					Set(FACTION.GNOMEREGAN_EXILES, 17, 0);
					Set(FACTION.DARNASSUS, 17, 0);
                    
					if (Constants.BurningCrusade)
						Set(FACTION.EXODAR, 17, 0);
					break;
				case RACE.ORC:
				case RACE.TROLL:
				case RACE.UNDEAD:
				case RACE.TAUREN:
				case RACE.BLOODELF:
					Set(FACTION.ORGRIMMAR, 17, 0);
					Set(FACTION.DARSPEAR_TROLLS, 17, 0);
					Set(FACTION.UNDERCITY, 17, 0);
					Set(FACTION.THUNDER_BLUFF, 17, 0);
                    
					if (Constants.BurningCrusade)
						Set(FACTION.SILVERMOON, 17, 0);
					break;
			}
		}

		public void Set(FACTION faction, byte state, int value)
		{
			int reputation = Faction.GetFactionReputationID(faction);
            
			if (reputation == -1)
				return;
            
			m_reputations[reputation].Faction = faction;
			m_reputations[reputation].State = state;
			m_reputations[reputation].Value = value;
		}

		public void Contacted(LivingObject target)
		{
			if (target is PlayerObject)
				return;

			int reputation = Faction.GetFactionReputationID(target.Faction);

			if (reputation == -1)
				return;

			if (m_reputations[reputation].Faction != 0)
				return;

			m_reputations[reputation].Faction = target.Faction;

			m_reputations[reputation].State = 1;

			if (Faction.ShouldAttackPlayer(target.Faction, m_owner.Faction))
				m_reputations[reputation].State |= 2;

			m_reputations[reputation].Value = 0;

			ShortPacket packet = new ShortPacket(SMSG.SET_FACTION_STANDING);
			packet.Write(m_reputations[reputation].Value);
			packet.Write(reputation);
			packet.Write(m_reputations[reputation].State);
			m_owner.BackLink.Client.Send(packet);
		}

		public void Clear(int reputation)
		{
			m_reputations[reputation].Faction = 0;
			m_reputations[reputation].State = 0;
			m_reputations[reputation].Value = 0;
		}

		public Reputation this[int reputation]
		{
			get { return m_reputations[reputation]; }
		}
	}
}
