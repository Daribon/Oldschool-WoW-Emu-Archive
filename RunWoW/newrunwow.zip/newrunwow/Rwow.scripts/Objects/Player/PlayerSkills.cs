//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.Objects.Player
{
	public class PlayerSkill
	{
		private ushort m_maxlevel;
		private ushort m_startBonus;
		private ushort m_bonus;
		private int m_plevel;
		private DBAbility m_ability;

		public PlayerSkill(DBAbility ability, int playerLevel)
		{
			m_ability = ability;
			m_maxlevel = ability.MaxLevel;
			m_bonus = 0;
			m_startBonus = 0;
			m_plevel = playerLevel;
		}

		public PlayerSkill()
		{
			m_plevel = 0;
			m_ability = null;
			m_maxlevel = 0;
			m_plevel = 0;
			m_bonus = 0;
			m_startBonus = 0;
		}

		public void Load(DBAbility ability, int playerLevel)
		{
			m_ability = ability;
			m_maxlevel = ability.MaxLevel;
			m_startBonus = 0;
			m_bonus = 0;
			m_plevel = playerLevel;
		}

		public void Clear()
		{
			m_plevel = 0;
			m_ability = null;
			m_maxlevel = 0;
			m_plevel = 0;
			m_bonus = 0;
			m_startBonus = 0;
		}
		
		public bool Empty
		{
			get { return m_ability == null; }
		}

		[UpdateValue(Field=0, ShortsIndex=0)]
		public ushort SkillID
		{
			get { return Empty ? (ushort)0 : m_ability.SkillID; }
		}

		[UpdateValue(Field=1, ShortsIndex=0)]
		public ushort Level
		{
			get { return Empty ? (ushort)0 : m_ability.Level; }
			set { m_ability.Level = value; }
		}

		[UpdateValue(Field=1, ShortsIndex=1)]
		public ushort MaxLevel
		{
			get
			{
				return Empty
				       	? (ushort) 0
				       	: (
				       	  	(m_maxlevel > 1 && Craft != 1)
				       	  		? Level > m_maxlevel ? Level : (ushort) ((m_maxlevel/60)*m_plevel)
				       	  		: m_maxlevel);
			}
		}

		[UpdateValue(Field=2, ShortsIndex=0)]
		public ushort Bonus
		{
			get { return m_bonus; }
			set { m_bonus = value; }
		}

		[UpdateValue(Field = 2, ShortsIndex = 1)]
		public ushort StartBonus
		{
			get { return m_startBonus; }
			set { m_startBonus = value; }
		}

		[UpdateValueAttribute(Field = 0, ShortsIndex = 1)]
		public ushort Craft
		{
			get { return Empty ? (ushort)0 : m_ability.Craft; }
		}

		public int PlayerLevel
		{
			set { m_plevel = value; }
		}

		public double RaiseChance
		{
			get { return (MaxLevel - Level)/((double) MaxLevel*3); }
		}

		public bool Raise()
		{
			if (Level < MaxLevel)
			{
				Level++;
			}
			else
				return false;
			return true;
		}

		public DBAbility Ability
		{
			get { return m_ability; }
			set { m_ability = value; }
		}

		public int Value
		{
			get { return m_startBonus + Bonus + Level; }
		}
	}

	public class SkillPool : GenericPool<PlayerSkill>
	{
		public static SkillPool Instance = new SkillPool();
		
		public SkillPool()
			: base(500, 1000, 120)
		{
		}
	}

	public class PlayerSkills
	{
		private PlayerObject m_owner;
		
		[UpdateValue(PLAYERFIELDS.SKILL_INFO, ArraySize=120, NumSubFields=3, Private=true)]
		public PlayerSkill[] Skills/* = new PlayerSkill[120]*/;
		
		public PlayerSkills(PlayerObject owner)
		{
			m_owner = owner;

			Skills = SkillPool.Instance.AquireBuffer(120);

			for (int i = 0; i < Skills.Length; i++)
				if (Skills[i] == null)
					Skills[i] = new PlayerSkill();
				else
					if (!Skills[i].Empty)
						Skills[i].Clear();
			//Skills[i] = new PlayerSkill();
			
			foreach (DBAbility ability in m_owner.Character.Abilities)
				if (ability != null)
					AddSkill(ability);
			
			UpdateSkills();
		}

		public void AddSkill(DBAbility ability)
		{
			if (ability == null)
				return;
			
			if (ability.Type != ABILITYTYPE.SKILL)
				return;
			
			if (findSkill((SKILL) ability.SkillID) != null)
				return;

			bool added = false;
			for(int i=0;i<Skills.Length;i++)
				if (Skills[i].Empty)
				{
					Skills[i].Load(ability, m_owner.Level);
					UpdateSkill(i);
					added = true;
					break;
				}
			
			if (added == false)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "No space for skill {0}", ability.SkillID);
			}

			ability.OwnerID = m_owner.CharacterID;

			if (ability.New)
				DBManager.NewDBObject(ability);
			else
				DBManager.SaveDBObject(ability);
		}

		public void LoadSkill(DBAbility ability)
		{
			if (ability == null)
				return;
			
			if (ability.Type != ABILITYTYPE.SKILL)
				return;

			if (findSkill((SKILL)ability.SkillID) == null)
			{
				AddSkill(ability);
				return;
			}

			for(int i=0;i<Skills.Length;i++)
				if (Skills[i].Empty && Skills[i].SkillID == ability.SkillID)
				{
					Skills[i].Load(ability, m_owner.Level);
					UpdateSkill(i);
					break;
				}
			
			ability.OwnerID = m_owner.CharacterID;

			if (ability.New)
				DBManager.NewDBObject(ability);
			else
				DBManager.SaveDBObject(ability);
		}

		public void RemoveSkill(SKILL skill)
		{
			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty && Skills[i].SkillID == (ushort) skill)
				{
					DBManager.EraseDBObject(Skills[i].Ability);
					
					Skills[i].Clear();

					UpdateSkill(i);
					break;
				}
		}

		public void Save()
		{
			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty)
					DBManager.SaveDBObject(Skills[i].Ability);
		}

		public void Dispose()
		{
			m_owner = null;
			
			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty)
					Skills[i].Clear();
			
			SkillPool.Instance.ReleaseBuffer(Skills);
			Skills = null;
		}

		public void UpdateLevel()
		{
			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty && Skills[i].Craft != 1)
				{
					Skills[i].PlayerLevel = m_owner.Level;
					UpdateSkill(i);
				}
		}

		public int SkillLevel(SKILL skillId)
		{
			PlayerSkill skill = findSkill(skillId);
			return skill == null ? 0 : skill.Value;
		}

		public void UpdateSkills()
		{
			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty)
				{
					m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + i*3);
					m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + i*3 + 1);
					m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + i*3 + 2);
				}
		}

		public void UpdateProficiencies()
		{
			Dictionary<byte, int> profs = new Dictionary<byte, int>();

			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty)
				{
					DBAbility ability = Skills[i].Ability;
					
					if (ability.Spell != null && ability.Spell.HasEffect(SPELLEFFECT.PROFICIENCY) && ability.Spell.RequiredItemClass > 0 &&
					    ability.Spell.RequiredItemSubclass > 0)
					{
						//Console.WriteLine("Prof {0}", ab.Spell.Name);
						if (!profs.ContainsKey((byte) ability.Spell.RequiredItemClass))
							profs[(byte) ability.Spell.RequiredItemClass] = 0;
						profs[(byte) ability.Spell.RequiredItemClass] |= ability.Spell.RequiredItemSubclass;
					}
				}

			foreach (KeyValuePair<byte, int> proff in profs)
			{
				ShortPacket prof = new ShortPacket(SMSG.SET_PROFICIENCY);
				prof.Write(proff.Key);
				prof.Write(proff.Value);

				if (m_owner.BackLink == null || m_owner.BackLink.Client == null)
					Console.WriteLine("Empty owner!!");
				else
					m_owner.BackLink.Client.Send(prof);
			}
		}

		public void CreateSkills(BitArray array)
		{
			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty)
				{
					ObjectBase.CreateValue(PLAYERFIELDS.SKILL_INFO + i * 3, array);
					ObjectBase.CreateValue(PLAYERFIELDS.SKILL_INFO + i * 3 + 1, array);
					ObjectBase.CreateValue(PLAYERFIELDS.SKILL_INFO + i * 3 + 2, array);
				}
		}

		//public void UpdateSkill(PlayerSkill skill)
		//{
		//    int num;

		//    for (num = 0; num < m_m_skills.Length; num++)
		//        if (Skills[num] == skill)
		//            break;
			
		//    m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + num*3);
		//    m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + num*3 + 1);
		//    m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + num*3 + 2);
			
		//    if (num == SkillCount)
		//    {
		//        Skills[SkillCount] = skill;
		//        SkillCount++;
		//        m_owner.Redress();
		//    }
		//}

		private void UpdateSkill(int num)
		{
			m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + num*3);
			m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + num*3 + 1);
			m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + num*3 + 2);
		}

		public void UpdateSkill(SKILL skillId)
		{
			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty && Skills[i].SkillID == (ushort) skillId)
				{
					m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + i*3);
					m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + i*3 + 1);
					m_owner.UpdateValue(PLAYERFIELDS.SKILL_INFO + i*3 + 2);
				}
		}

		private PlayerSkill findSkill(SKILL skillId)
		{
			if (skillId == SKILL.NONE)
				return null;

			for (int i = 0; i < Skills.Length; i++)
				if (!Skills[i].Empty && Skills[i].SkillID == (ushort) skillId)
				{
					switch (skillId)
					{
						case SKILL.PLATEMAIL:
							if (m_owner.Level < 40)
								return null;
							break;
						case SKILL.MAIL:
							if (m_owner.Level < 40 && (m_owner.Class == CLASS.HUNTER || m_owner.Class == CLASS.SHAMAN))
								return null;
							break;
					}
					return Skills[i];
				}
			return null;
		}

		//public PlayerSkill SkillSpell(ushort spellId)
		//{
		//    if (spellId == 0)
		//        return null;
		//    for (int i = 0; i < Skills.Length; i++)
		//        if (!Skills[i].Empty && Skills[i].Ability.SpellID == spellId)
		//            return Skills[i];
		//    return null;
		//}

		public PlayerSkill this[SKILL num]
		{
			get { return findSkill(num); }
		}

		public PlayerSkill SkillForItem(ItemObject item)
		{
			return findSkill(GetSkillForItemTemplate(item.DBItem.Template));
		}

		public static SKILL GetSkillForItemTemplate(DBItemTemplate it)
		{
			if (it.ReqSkill != 0)
				return (SKILL) it.ReqSkill;
			switch (it.Class)
			{
				case ITEMCLASS.WEAPON:
					return GetSkillForWeaponSubClass(it.WeaponSubClass);
				case ITEMCLASS.ARMOUR:
					return GetSkillForArmourSubclass(it.ArmourSubClass);
				default:
					break;
			}
			return SKILL.NONE;
		}

		public static SKILL GetSkillForArmourSubclass(ARMOURSUBCLASS subclass)
		{
			switch (subclass)
			{
				case ARMOURSUBCLASS.CLOTH:
					return SKILL.CLOTH;
				case ARMOURSUBCLASS.LEATHER:
					return SKILL.LEATHER;
				case ARMOURSUBCLASS.MAIL:
					return SKILL.MAIL;
				case ARMOURSUBCLASS.PLATE:
					return SKILL.PLATEMAIL;
				case ARMOURSUBCLASS.BUCKLER: // obsolete
				case ARMOURSUBCLASS.SHIELD:
					return SKILL.SHIELD;
				default:
					return SKILL.NONE;
			}
		}

		public static SKILL GetSkillForWeaponSubClass(WEAPONSUBCLASS subclass)
		{
			switch (subclass)
			{
				case WEAPONSUBCLASS.DAGGER:
					return SKILL.DAGGER;
				case WEAPONSUBCLASS.TWOHANDSWORD:
					return SKILL.TWOHANDSWORD;
				case WEAPONSUBCLASS.ONEHANDSWORD:
					return SKILL.ONEHANDSWORD;
				case WEAPONSUBCLASS.ONEHANDAXE:
					return SKILL.ONEHANDAXE;
				case WEAPONSUBCLASS.TWOHANDAXE:
					return SKILL.TWOHANDAXE;
				case WEAPONSUBCLASS.ONEHANDBLUNT:
					return SKILL.ONEHANDBLUNT;
				case WEAPONSUBCLASS.TWOHANDBLUNT:
					return SKILL.TWOHANDBLUNT;
				case WEAPONSUBCLASS.SPEAR:
				case WEAPONSUBCLASS.POLEARM:
					return SKILL.POLEARMS;
				case WEAPONSUBCLASS.STAFF:
					return SKILL.STAFF;
				case WEAPONSUBCLASS.WAND:
					return SKILL.WAND;
				case WEAPONSUBCLASS.BOW:
					return SKILL.BOW;
				case WEAPONSUBCLASS.GUN:
					return SKILL.GUN;
				case WEAPONSUBCLASS.UNARMED:
					return SKILL.UNARMED;
				case WEAPONSUBCLASS.THROWN:
					return SKILL.THROWN;
				case WEAPONSUBCLASS.CROSSBOW:
					return SKILL.CROSSBOWS;
				case WEAPONSUBCLASS.FISHING:
					return SKILL.FISHING;
				case WEAPONSUBCLASS.ONEHANDEXOTIC:
				case WEAPONSUBCLASS.TWOHANDEXOTIC:
				default:
					return SKILL.NONE; //?
			}
		}
	}
}