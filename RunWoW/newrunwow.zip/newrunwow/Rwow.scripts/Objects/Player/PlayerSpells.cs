using System;
using System.Collections.Specialized;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.Objects.Player
{
	public class PlayerSpells
	{
		private PlayerObject m_owner;
		public HybridDictionary Spells;

		public PlayerSpells(PlayerObject owner)
		{
			m_owner = owner;
			Spells = new HybridDictionary();
			foreach (DBAbility ability in m_owner.Character.Abilities)
				if (ability != null)
					AddSpell(ability);
		}

		public DBAbility AddSpell(DBAbility ability)
		{
			if (ability == null)
				return null;
			if (this[(ushort) ability.SpellID] != null)
				return null;
			if (ability.SpellID == 0)
				return null;
			if (ability.ObjectId == 0 && ability.Type == ABILITYTYPE.SPELL)
			{
				ability.OwnerID = m_owner.CharacterID;
				DBManager.NewDBObject(ability);
				//Owner.Character.Abilities=null;
				m_owner.Save();
				LogConsole.WriteLine(LogLevel.ECHO, "Added new spell " + ability.SpellID + " to char " + m_owner.Name);
			}
			Spells[(ushort) ability.SpellID] = ability;
			return ability;
		}

		public DBAbility AddSpell(ushort spellId)
		{
			DBAbility spell = DBUtility.SpellOfChar(m_owner.Character, spellId);
			AddSpell(spell);
			return spell;
		}

		public DBAbility AddSpell(SPELLSKILL spellId)
		{
			DBAbility spell = DBUtility.SpellOfChar(m_owner.Character, spellId);
			AddSpell(spell);
			return spell;
		}

		public void RemoveSpell(ushort spellId)
		{
			DBAbility ability = this[spellId];
			if (ability == null)
				return;
			DBManager.EraseDBObject(ability);
			m_owner.Character.Abilities.Remove(ability);
			Spells.Remove(spellId);
		}

		public DBAbility this[ushort num]
		{
			get { return (DBAbility) Spells[num]; }
		}

		public DBAbility this[SPELLSKILL num]
		{
			get { return this[(ushort) num]; }
		}

		public void SetCooldown(DBAbility ability, int value)
		{
			DateTime cooldown = CustomDateTime.Now + TimeSpan.FromMilliseconds(value);
			if (m_owner != null && m_owner.Character != null)
				foreach (DBAbility nability in m_owner.Character.Abilities)
					if (nability == ability || (nability.Spell != null && nability.Spell.Name == ability.Spell.Name))
						nability.Cooldown = cooldown;
		}

		public void SetCooldown(DBSpell spell, int value)
		{
			DateTime cooldown = CustomDateTime.Now + TimeSpan.FromMilliseconds(value);
			if (m_owner != null && m_owner.Character != null)
				foreach (DBAbility nability in m_owner.Character.Abilities)
					if (nability.Spell == spell || (nability.Spell != null && nability.Spell.Name == spell.Name))
						nability.Cooldown = cooldown;
		}

		public void Dispose()
		{
			Spells.Clear();
			Spells = null;
			m_owner = null;
		}
	}
}