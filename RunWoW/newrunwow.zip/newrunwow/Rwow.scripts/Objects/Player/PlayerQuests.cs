//
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.Objects.Player
{
	public class PlayerQuest
	{
		private const int QuestCounters = 5;
		
		private uint m_questid;
		private byte[] m_count = new byte[QuestCounters];
		private uint m_state;
		private DBQuestLog m_log;

		public PlayerQuest()
		{
		}

		public PlayerQuest(DBQuestLog log)
		{
			Load(log);
		}

		public void Clear()
		{
			m_log = null;
			m_questid = 0;
			m_count = new byte[QuestCounters];
			m_state = 0;
		}

		public void Load(DBQuestLog log)
		{
			m_log = log;
			m_questid = log.QuestID;
			Update();
		}

		public void Update()
		{
			m_state = (uint)m_log.Status;
			int count = 0;
			for (int i = 0; i < m_log.Quest.Target.Length; i++)
				if (m_log.Quest.Target[i].ID != 0 && (m_log.Quest.Target[i].Type == 1 || m_log.Quest.Target[i].Type == 0 || m_log.Quest.Target[i].Type == 4)) // slain or gather
				{
					if (count == QuestCounters)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Quest counters count is {0}!", count);
						return;
					}
					m_count[count] = (byte)m_log.Target[i];
					count++;
				}
		}

		[UpdateValue(Field=0)]
		public uint QuestID
		{
			get { return m_questid; }
		}

		public byte[] Count
		{
			get { return m_count; }
		}

		[UpdateValue(Field = 1)]
		public int NCount
		{
			get { return (m_count[0] | m_count[1] << 6 | m_count[2] << 12 | m_count[3] << 18 | m_count[4] << 24); }
		}

		[UpdateValue(Field = 2)]
		public uint State
		{
			get { return m_state; }
		}

		public DBQuestLog QuestLog
		{
			get { return m_log; }
		}
	}

	public class QuestPoint
	{
		private MapTile m_tile;
		private DBQuestLog m_log;
		private uint m_area;

		public MapTile Tile
		{
			get { return m_tile; }
		}
		
		public DBQuestLog QuestLog
		{
			get { return m_log; }
		}
		
		public uint AreaId
		{
			get { return m_area; }
		}

		public QuestPoint(DBQuestLog log, uint areaId)
		{
			m_log = log;
			m_area = areaId;

			MapInstance map = MapManager.GetWorldMap(log.Quest.WorldMapID, 0);
			if (map != null)
				m_tile = map.GetTileByLoc((int) log.Quest.PositionX, (int) log.Quest.PositionY);
		}
	}

	public class PlayerQuests
	{
		private const int MaxQuestCount = /*Constants.BurningCrusade ? */ 25 /* : 20*/;

		private PlayerQuest[] m_fields = new PlayerQuest[MaxQuestCount];

		[UpdateValue(PLAYERFIELDS.QUEST_LOG, ArraySize = MaxQuestCount, NumSubFields = 3, Private = true)]
		public PlayerQuest[] Fields
		{
			get { return m_fields; }
		}

		private Hashtable m_quests = new Hashtable();

		private Dictionary<uint, DBQuestLog> m_toSlain = new Dictionary<uint, DBQuestLog>();
		private Dictionary<uint, DBQuestLog> m_toGather = new Dictionary<uint, DBQuestLog>();

		private List<QuestPoint> m_toVisit = new List<QuestPoint>();

		private PlayerObject m_owner;

		public PlayerQuests(PlayerObject owner)
		{
			m_owner = owner;

			for (int i = 0; i < MaxQuestCount; i++)
				m_fields[i] = new PlayerQuest();

			foreach (DBQuestLog qlog in m_owner.Character.QuestLog)
				AddQuest(qlog);

			InitQuests();
		}

		private bool AddQuest(DBQuestLog qlog)
		{
			if (qlog == null)
				return false;
			if (qlog.Status != QUESTSTATUS.STARTED && qlog.Status != QUESTSTATUS.COMPLETED)
				return false;
			if (Has(qlog.QuestID))
				return false;
			if (m_quests.Count >= MaxQuestCount)
				return false;
			m_quests[qlog.QuestID] = qlog;

			for (int i = 0; i < qlog.Quest.Target.Length; i++)
			{
				uint targetId = qlog.Quest.Target[i].ID;
				if (targetId != 0)
				{
					qlog.Target[i] = 0;

					switch (qlog.Quest.Target[i].Type)
					{
						case 0:
						case 4: // gather
							m_toGather[targetId] = qlog;
							break;
						case 1: // slain
							m_toSlain[targetId] = qlog;
							break;
						case 7: // visit
							QuestPoint point = new QuestPoint(qlog, targetId);
							if (point.Tile != null)
								m_toVisit.Add(point);
							else
								LogConsole.WriteLine(LogLevel.ERROR, "Quest {0} has wrong point coords!", qlog.Quest.Name);
							break;
					}
				}
			}

			return true;
		}

		public bool Full
		{
			get
			{
				for (int i = 0; i < MaxQuestCount; i++)
					if (m_fields[i].QuestID == 0)
						return false;
				return true;
			}
		}

		public bool NewQuest(DBQuest quest)
		{
			DBQuestLog questLog = new DBQuestLog();
			questLog.Status = QUESTSTATUS.STARTED;
			questLog.QuestID = quest.ObjectId;
			questLog.OwnerID = m_owner.CharacterID;
			questLog.Quest = quest;
			bool result = AddQuest(questLog);

			if (result)
			{
				DBManager.NewDBObject(questLog);
				m_owner.Character.QuestLog.Add(questLog);

				for (int i = 0; i < MaxQuestCount; i++)
					if (m_fields[i].QuestID == 0)
					{
						m_fields[i].Load(questLog);
						UpdateQuestField(i);
						break;
					}
			}
			return result;
		}

		public void Save()
		{
			foreach (DBQuestLog qlog in m_quests.Values)
				DBManager.SaveDBObject(qlog);
		}

		public void Dispose()
		{
			//Save();
			m_owner = null;
			m_quests.Clear();
			m_toSlain.Clear();
			m_toGather.Clear();
		}


		public void UpdateQuests()
		{
			for (int i = 0; i < MaxQuestCount; i++)
				if (m_fields[i].QuestLog != null)
					UpdateQuestField(i);
		}

		public void CreateQuests(BitArray array)
		{
			for (int i = 0; i < MaxQuestCount; i++)
				if (m_fields[i].QuestLog != null)
				{
					ObjectBase.CreateValue(PLAYERFIELDS.QUEST_LOG + i * 3 + 0, array);
					ObjectBase.CreateValue(PLAYERFIELDS.QUEST_LOG + i * 3 + 1, array);
					ObjectBase.CreateValue(PLAYERFIELDS.QUEST_LOG + i * 3 + 2, array);
				}
		}

		public void InitQuests()
		{
			IEnumerator e = m_quests.Values.GetEnumerator();
			int count = 0;
			while (e.MoveNext() && count < MaxQuestCount)
			{
				m_fields[count].Load(e.Current as DBQuestLog);
				count++;
			}
			UpdateQuests();
		}

		public DBQuestLog this[uint id]
		{
			get { return m_quests[id] as DBQuestLog; }
		}

		public bool Has(uint id)
		{
			return m_quests.ContainsKey(id);
		}

		public bool HasOld(uint id) // checks if player has this quest early
		{
			foreach (DBQuestLog qlog in m_owner.Character.QuestLog)
				if (qlog.QuestID == id)
					return true;
			return false;
		}

		public bool HasOldCompleted(uint id) // checks if player completed this quest early
		{
			foreach (DBQuestLog qlog in m_owner.Character.QuestLog)
				if (qlog.QuestID == id && qlog.Status == QUESTSTATUS.FINISHED)
					return true;

			return false;
		}

		private void RemoveFromLists(DBQuestLog ql)
		{
			foreach (KeyValuePair<uint, DBQuestLog> pair in m_toSlain)
				if (pair.Value == ql)
				{
					m_toSlain.Remove(pair.Key);
					break;
				}

			foreach (KeyValuePair<uint, DBQuestLog> pair in m_toGather)
				if (pair.Value == ql)
				{
					m_toGather.Remove(pair.Key);
					break;
				}

			m_quests.Remove(ql.QuestID);
		}

		public void Complete(uint id)
		{
			DBQuestLog ql = m_quests[id] as DBQuestLog;
			if (ql == null)
				return;
			RemoveFromLists(ql);

			ClearQuestField(ql);

			if (ql.Quest.Repeatable)
			{
				DBManager.EraseDBObject(ql);
			}
			else
			{
				ql.Status = QUESTSTATUS.FINISHED;
				DBManager.SaveDBObject(ql);
			}
		}

		public void Fail(uint id)
		{
			DBQuestLog ql = m_quests[id] as DBQuestLog;
			if (ql == null)
				return;
			RemoveFromLists(ql);

			ClearQuestField(ql);

			ql.Status = QUESTSTATUS.FAILED;
			DBManager.SaveDBObject(ql);
		}

		public bool Fail(byte num)
		{
			DBQuestLog questLog = m_fields[num].QuestLog;
			if (questLog == null)
				return false;
			if (questLog.Status != QUESTSTATUS.STARTED)
				return false;
			RemoveFromLists(questLog);

			m_fields[num].Clear();
			UpdateQuestField(num);

			m_owner.Character.QuestLog.Remove(questLog);
			DBManager.EraseDBObject(questLog);
			return true;
		}

		private void UpdateQuestField(DBQuestLog ql)
		{
			for (int i = 0; i < MaxQuestCount; i++)
				if (m_fields[i].QuestLog == ql)
				{
					m_fields[i].Update();
					UpdateQuestField(i);
					break;
				}
		}

		private void ClearQuestField(DBQuestLog ql)
		{
			for (int i = 0; i < MaxQuestCount; i++)
				if (m_fields[i].QuestLog == ql)
				{
					m_fields[i].Clear();
					UpdateQuestField(i);
					break;
				}
		}

		private void UpdateQuestField(int num)
		{
			m_owner.UpdateValue(PLAYERFIELDS.QUEST_LOG + num*3 + 0);
			m_owner.UpdateValue(PLAYERFIELDS.QUEST_LOG + num*3 + 1);
			m_owner.UpdateValue(PLAYERFIELDS.QUEST_LOG + num*3 + 2);
		}

		#region static methods

		public static bool QuestCompleted(PlayerObject Player, DBQuestLog qLog)
		{
			for (int i = 0; i < qLog.Target.Length; i++)
				if (qLog.Quest.Target[i].ID != 0)
					switch (qLog.Quest.Target[i].Type)
					{
						case 0: // gather items
						case 2: // deliver items
						case 4: // has items
							if ((qLog.Target[i] = (uint)Player.Inventory.CountItems(qLog.Quest.Target[i].ID)) < qLog.Quest.Target[i].Count)
								return false;
							break;
						case 3: // given items not required
							break;
						case 5: // gold
							if ((qLog.Target[i] = (uint)Player.Money) < qLog.Quest.Target[i].Count)
								return false;
							break;
						case 6: // has spell
                            if ((qLog.Target[i] = (Player.Spells[(ushort)qLog.Quest.Target[i].ID] == null ? (uint)0 : (uint)1)) == 0)
								return false;
							break;
						case 1: // monster slain
							if (qLog.Target[i] < qLog.Quest.Target[i].Count)
								return false;
							break;
						case 7: // visit
							if (qLog.Target[i] == 0)
								return false;
							break;
					}
			return true;
		}
		
		public static QuestStatus AcceptQuest(PlayerObject Player, DBQuest quest)
		{
			int charClass = 1 << ((int)Player.Character.Class - 1);
			int charRace = 1 << ((int)Player.Character.Race - 1);

			// TODO: remove this
			if (Constants.DruidQuestFix && Player.Character.Class == CLASS.DRUID)
				charClass = 512;
	        
			QuestStatus result = QuestStatus.None;
	        
			LogConsole.WriteLine(LogLevel.ECHO, "Checking quest " + quest.Name);
			if (Player.Quests.Has(quest.ObjectId))
				return result; // now completing

			if (Player.Quests.HasOldCompleted(quest.ObjectId))
				return result; // already done it

			if (quest.RaceFlag != 0 && (quest.RaceFlag & charRace) != charRace)
				return result; // wrong race

			if (quest.ClassFlag != 0 && (quest.ClassFlag & charClass) != charClass)
				return result; // wrong class

			for (int i = 0; i < quest.Requires.Length; i++)
				if (quest.Requires[i] != 0 && !Player.Quests.HasOldCompleted(quest.Requires[i]))
					return result; // previous quest incomplete


			if (quest.MinLevel != 0 && Player.Character.Level < quest.MinLevel - 1)
			{
				result = QuestStatus.LowLevel; // do not override new quest flag
				return result; // player level too low
			}
			//if (quest.MaxLevel != 0 && Player.Character.Level > quest.MaxLevel + 10)
			//    return result; // player level to high

			return quest.Repeatable ? QuestStatus.AvailableRep : QuestStatus.Available;
		}

		public static QuestStatus CheckPlayerQuests(PlayerObject Player, ICollection<DBQuest> quests, out PooledList<DBQuest> rquests)
		{
			LogConsole.WriteLine(LogLevel.ECHO, "Getting start quests for player {0}, total npc quests: {1}", Player.Name, quests.Count);
			QuestStatus result = QuestStatus.None;

			rquests = new PooledList<DBQuest>();

			foreach (DBQuest quest in quests)
			{
				QuestStatus status = AcceptQuest(Player, quest);

				if (result == QuestStatus.None && status == QuestStatus.LowLevel)
					result = QuestStatus.LowLevel; // do not override new quest flag

				if (status == QuestStatus.Available)
				{
					rquests.Add(quest);
					if (result != QuestStatus.AvailableRep)
						result = status;
				}

				if (status == QuestStatus.AvailableRep)
				{
					rquests.Add(quest);
					result = status;
				}

			}
			return result;
		}

		public static PooledList<DBQuestLog> GetEndQuestsForPlayer(PlayerObject Player, ICollection<DBQuest> quests)
		{
			if (quests == null)
				return null;

			PooledList<DBQuestLog> lql = new PooledList<DBQuestLog>();
			
			foreach (DBQuest quest in quests)
			{
				DBQuestLog ql = Player.Quests[quest.ObjectId];
				if (ql != null)
					lql.Add(ql);
			}
			return lql.Count > 0 ? lql : null;
		}

		#endregion

		#region Quest Targets

		public void CheckSlain(uint id, long GUID)
		{
			if (!m_toSlain.ContainsKey(id))
				return;

			DBQuestLog ql = m_toSlain[id];
			if (ql.Status != QUESTSTATUS.STARTED)
				return;

			for (int i = 0; i < ql.Quest.Target.Length; i++)
			{
				TypedElementPair questTarget = ql.Quest.Target[i];

				if (questTarget.ID == id && questTarget.Type == 1 && ql.Target[i] < questTarget.Count)
				{
					ql.Target[i]++;
					ql.Dirty = true;
					DBManager.SaveDBObject(ql);

					ShortPacket slog = new ShortPacket(SMSG.QUESTUPDATE_ADD_KILL);
					slog.Write(ql.QuestID);
					slog.Write(id);
					slog.Write(ql.Target[i]);
					slog.Write(questTarget.Count);
					slog.Write(GUID);
					m_owner.BackLink.Client.Send(slog);

					LogConsole.WriteLine(LogLevel.ECHO, "Added slain " + id);
					if (QuestCompleted(m_owner, ql))
						ql.Status = QUESTSTATUS.COMPLETED;
					UpdateQuestField(ql);

					return;
				}
			}
		}

		public bool NeedGather(uint id, ref int count)
		{
			if (!m_toGather.ContainsKey(id))
				return false;

			DBQuestLog ql = m_toGather[id];

			for (int i = 0; i < ql.Quest.Target.Length; i++)
			{
				TypedElementPair questTarget = ql.Quest.Target[i];

				if (questTarget.ID == id && (questTarget.Type == 0 || questTarget.Type == 4) && ql.Target[i] < questTarget.Count)
				{
					count = (int)(questTarget.Count - ql.Target[i]);
					count = Utility.Random(1, count > 3 ? 3 : count);
					return true;
				}
			}
			return false;
		}

		public void CheckGather(uint id, int num)
		{
			if (!m_toGather.ContainsKey(id))
				return;

			DBQuestLog ql = m_toGather[id];

			if (ql.Status != QUESTSTATUS.STARTED && ql.Status != QUESTSTATUS.COMPLETED)
				return;

			for (int i = 0; i < ql.Quest.Target.Length; i++)
			{
				TypedElementPair questTarget = ql.Quest.Target[i];

				if (questTarget.ID == id && (questTarget.Type == 0 || questTarget.Type == 4) && ql.Target[i] < questTarget.Count)
				{
                    ql.Target[i] += (uint)num;
					ql.Dirty = true;
					if (ql.Target[i] > questTarget.Count)
					{
						num -= (int)(ql.Target[i] - questTarget.Count);
						ql.Target[i] = questTarget.Count;
					}
					DBManager.SaveDBObject(ql);

					ShortPacket slog = new ShortPacket(SMSG.QUESTUPDATE_ADD_ITEM);
					slog.Write(id);
					slog.Write(num);
					m_owner.BackLink.Client.Send(slog);
					LogConsole.WriteLine(LogLevel.ECHO, "Added gather " + id);

					if (ql.Status != QUESTSTATUS.COMPLETED && QuestCompleted(m_owner, ql))
					{
						ql.Status = QUESTSTATUS.COMPLETED;
						UpdateQuestField(ql);
					}

					return;
				}
			}
		}

		public void CheckArea(uint area, MapTile tile)
		{
			foreach (QuestPoint point in m_toVisit)
				if (point.AreaId == area)
			{
				if (point.QuestLog.Status != QUESTSTATUS.STARTED && point.QuestLog.Status != QUESTSTATUS.COMPLETED)
					continue;

				if (point.Tile != tile)
					continue;

				for (int i = 0; i < point.QuestLog.Quest.Target.Length; i++)
				{
					TypedElementPair questTarget = point.QuestLog.Quest.Target[i];

					if (questTarget.ID == point.AreaId && questTarget.Type == 7 && point.QuestLog.Target[i] == 0)
					{
						point.QuestLog.Target[i] = 1;
						point.QuestLog.Dirty = true;
						DBManager.SaveDBObject(point.QuestLog);
						break;
					}
				}

				ShortPacket packet = new ShortPacket(SMSG.EXPLORATION_EXPERIENCE);
				packet.Write(area);
				packet.Write(0);

				m_owner.BackLink.Client.Send(packet);

				if (point.QuestLog.Status != QUESTSTATUS.COMPLETED && QuestCompleted(m_owner, point.QuestLog))
				{
					point.QuestLog.Status = QUESTSTATUS.COMPLETED;
					UpdateQuestField(point.QuestLog);
				}
			}
		}

		#endregion
	}
}