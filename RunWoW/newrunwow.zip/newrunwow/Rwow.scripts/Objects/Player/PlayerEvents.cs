//
using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.LoginPackets;
using RunWoW.Objects.Misc;
using RunWoW.ServerDatabase;
using RunWoW.Misc;
using RunWoW.Map;

namespace RunWoW.Objects.Player
{
	public class ReleaseSpiritEvent : Event
	{
		private PlayerReference m_player;

		public ReleaseSpiritEvent(PlayerObject player)
			: base(TimeSpan.FromMinutes(5))
		{
			m_player = new PlayerReference(player);
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			if (m_player.IsAlive && m_player.Target.Dead)
				m_player.Target.ReleaseSpirit();
		}
	}

	public class LogoutEvent : Event
	{
		private ClientBase m_client;

		public LogoutEvent(ClientBase client)
			: base(TimeSpan.FromSeconds(20))
		{
			m_client = client;
			Priority = TimerPriority.OneSecond;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			if (m_client == null || m_client.Data == null)
				return;

			PlayerLogin.OnPlayerLogout(m_client, null);
		}

		protected override void OnFinish()
		{
			base.OnFinish();
			if (m_client == null || m_client.Data == null || Result != EventResult.TERMINATED)
				return;
			
			PlayerLogin.OnLogoutCancel(m_client, null);
		}
	}

	public class PVPEvent : Event
	{
		private PlayerReference m_player;

		public PVPEvent(PlayerObject player)
			: base(TimeSpan.FromMinutes(5))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
			m_player = new PlayerReference(player);
		}

		protected override void OnTick()
		{
			if (m_player.IsAlive && m_player.Target.PvP)
			{
				m_player.Target.PvP = false;
				m_player.Target.UpdateData();
			}
		}
	}

	public class PlayerSaveEvent : Event
	{
		private static PlayerSaveEvent Instance = new PlayerSaveEvent();

		private PlayerSaveEvent()
			: base(TimeSpan.FromMinutes(1.0), TimeSpan.FromSeconds(Constants.PlayerSaveInterval))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparateSecond;
		}

		protected override void OnTick()
		{
			PooledList<PlayerObject> players = ClientManager.GetPlayerList();

			foreach (PlayerObject player in players)
				player.Save();
			
			Database.Instance.FlushTables();
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}

	public class PlayerRegenEvent : Event
	{
		private static PlayerRegenEvent Instance = new PlayerRegenEvent();
		private static DateTime m_lastTick;

		private PlayerRegenEvent()
			: base(TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(2))
		{
			Priority = TimerPriority.OneSecond;
			ExecPriority = ExecutionPriority.QCritical;
			m_lastTick = CustomDateTime.Now;
		}

		private static void RegenPlayer(PlayerObject player, float timeRange)
		{
			if (player == null || player.IsDisposed || player.BackLink == null)
				return;

			if (player.Dead || player.Health == 0)
				return;

			int healthRegen = 0;
			if (player.Health != player.MaxHealth)
			{
				float nRegenRate = player.HealthRegenRate;
				switch (player.StandState)
				{
					case UNITSTANDSTATE.SLEEPING:
						nRegenRate *= 1.5f;
						break;
					case UNITSTANDSTATE.SITTINGCHAIR:
					case UNITSTANDSTATE.SITTINGCHAIRHIGH:
					case UNITSTANDSTATE.SITTINGCHAIRLOW:
					case UNITSTANDSTATE.SITTINGCHAIRMEDIUM:
					case UNITSTANDSTATE.SITTING:
						nRegenRate *= 1.2f;
						break;
					case UNITSTANDSTATE.DEAD: // never happens
						nRegenRate = 0;
						break;
					default:
						break;
				}
				if (player.Attacking)
					nRegenRate *= 0.15f;

				healthRegen = (int)Math.Round(timeRange * nRegenRate);
				if (player.Health + healthRegen > player.MaxHealth)
					healthRegen = player.MaxHealth - player.Health;
			}

			int powerRegen = 0;
			switch (player.PowerType)
			{
				case POWERTYPE.RAGE:
					if (player.Power == 0)
						break;
					if (player.Attacking)
						break;
					powerRegen = (int)Math.Round(timeRange * player.PowerRegenRate);
					if (player.Power + powerRegen < 0)
						powerRegen = -player.Power;
					break;
				case POWERTYPE.ENERGY:
					if (player.Power == player.MaxPower)
						break;
					powerRegen = (int)Math.Round(timeRange * player.PowerRegenRate);
					if (player.Power + powerRegen > player.MaxPower)
						powerRegen = player.MaxPower - player.Power;
					break;
				default:
					if (player.Casting)
						break;
					if (player.LastCastPower > 0 && player.LastCast + TimeSpan.FromSeconds(5) > CustomDateTime.Now)
						break;
					float nRegenRate = player.PowerRegenRate;
					//if (player.Attacking)
					//    nRegenRate *= 0.15f;

					powerRegen = (int)Math.Round(timeRange * nRegenRate);
					if (player.Power + powerRegen > player.MaxPower)
						powerRegen = player.MaxPower - player.Power;
					break;
			}
			
			int hiddenPowerRegen = 0;

			if (player.IsFeralForm && player.bOriginalClass != null && player.PowerType != player.bOriginalClass.PowerType)
			{
				float nRegenRate = player.bOriginalClass.CalculatePRegen(player.Level, player.Spirit);
				hiddenPowerRegen = (int)Math.Round(timeRange * nRegenRate);
			}
			
			int drunkRegen = 0;
			if (player.Drunk > 0)
			{
				drunkRegen = -1;
				switch (player.StandState)
				{
					case UNITSTANDSTATE.SLEEPING:
						drunkRegen *= 3;
						break;
					case UNITSTANDSTATE.SITTINGCHAIR:
					case UNITSTANDSTATE.SITTINGCHAIRHIGH:
					case UNITSTANDSTATE.SITTINGCHAIRLOW:
					case UNITSTANDSTATE.SITTINGCHAIRMEDIUM:
					case UNITSTANDSTATE.SITTING:
						drunkRegen *= 2;
						break;
				}
			}
			if (healthRegen != 0 || powerRegen != 0 || drunkRegen != 0)
			{
				player.Health += healthRegen;
				player.Power += powerRegen;
				player.Drunk = (byte)(player.Drunk + drunkRegen);
				player.ForceUpdateData();
			}

			if (hiddenPowerRegen != 0)
				player.HiddenPower += hiddenPowerRegen;

			if (player.InWater && player.SShift != (byte)ShapeshiftForm.FORM_AQUA)
			{
				int breathTime = player.Character.Race == RACE.UNDEAD
				                 	? Constants.UndeadBreathTime
				                 	: Constants.UnderwaterBreathTime;
				if (CustomDateTime.Now - player.LastAir > TimeSpan.FromMilliseconds(breathTime))
				{
					float damage = Constants.UnderwaterBreathDamage * player.MaxHealth;
					player.TakeEnvironmentDamage(player, null, (DAMAGETYPE)1, damage, damage + 5);
				}
			}
			
			if (!player.InWater && player.SShift == (byte)ShapeshiftForm.FORM_AQUA)
			{
				player.Auras.CancelAuraForce(player.MountSpell);
			}
		}

		protected override void OnTick()
		{
			float timeRange = (float)(CustomDateTime.Now - m_lastTick).TotalSeconds / 2f;

			PooledList<PlayerObject> players = ClientManager.GetPlayerList();

			foreach (PlayerObject player in players)
			{
				RegenPlayer(player, timeRange);
			}
			
			m_lastTick = CustomDateTime.Now;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}

	public class PlayerSwimEvent : Event
	{
		private static PlayerSwimEvent Instance = new PlayerSwimEvent();

		private PlayerSwimEvent()
			: base(TimeSpan.FromSeconds(1), TimeSpan.FromSeconds(1))
		{
			Priority = TimerPriority.OneSecond;
			ExecPriority = ExecutionPriority.QCriticalSecond;
		}

		private static void CheckPlayer(PlayerObject player)
		{
			if (player.Disposed || player.Dead || player.BackLink == null || player.Health == 0 || player.Invul || player.BreathUnderwater)
				return;

			float water;
			int area;

			if (WorldMap.HasMap((int)player.WorldMapID))
				WorldMap.GetPoint((int)player.WorldMapID, player.Position.X,
				                  player.Position.Y, out water, out area, true);
			else
				return;

			bool inWater = player.Position.Z + 2 <= water;
			if (player.SShift != (byte)ShapeshiftForm.FORM_AQUA)
			{
				if (!player.InWater && inWater)
				{
					if (player.MountSpell != 0)
						player.Auras.CancelAuraForce(player.MountSpell);

					int breathTime = player.Character.Race == RACE.UNDEAD
					                 	? Constants.UndeadBreathTime
					                 	: Constants.UnderwaterBreathTime;

					ShortPacket pkg = new ShortPacket(SMSG.START_MIRROR_TIMER);
					pkg.Write(1); // type
					pkg.Write(breathTime); // value
					pkg.Write(breathTime); // max
					pkg.Write(-1);
					pkg.Write(0); // color ?
					pkg.Write((byte)0);
					player.BackLink.Client.Send(pkg);
					player.LastAir = CustomDateTime.Now;
				}
				else if (player.InWater && !inWater)
				{
					ShortPacket pkg = new ShortPacket(SMSG.STOP_MIRROR_TIMER);
					pkg.Write(1);
					player.BackLink.Client.Send(pkg);
				}
			}
			else if (!player.InWater && player.TransformSpell != 0)
				player.Auras.CancelAuraForce(player.TransformSpell);

			player.InWater = inWater;

			if (area == 0)
				area = (int)player.Zone;

			if (player.Area == null || player.Area.ObjectId != area)
				player.Area = (DBArea)Database.Instance.FindObjectByKey(typeof(DBArea), area);
			
			//if (area != 0 && (player.Area == null || player.Area.ObjectId!=area))
			//{
				
			//}
		}

		protected override void OnTick()
		{
			PooledList<PlayerObject> players = ClientManager.GetPlayerList();

			foreach (PlayerObject player in players)
			{
				if (!player.IsDisposed && player.MapTile != null)
				{
					player.MapTile.Map.Move(player);
					if ((player.MovementFlags & 0x31) != 0 && (CustomDateTime.Now - player.BackLink.LastMovement).TotalSeconds > 2)
					{
						player.MovementFlags = 0;
						int timePos;
						ShortPacket pkg = Movement.MakeMovement(SMSG.MOVE_FALL_LAND, player, 0, out timePos);
						player.MapTile.SendSurroundingTimed(pkg, player, player, timePos);
					}
				}
				CheckPlayer(player);
			}
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}
}