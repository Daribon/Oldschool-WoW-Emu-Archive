using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.DB.DataTables;

namespace RunWoW.ServerDatabase
{
	public class TaxiBase
	{
		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			DBFlags cacheFlag = Constants.NoInnerCache ? DBFlags.None : DBFlags.Cached;

			Database.Instance.RegisterDataObject<DBTaxiPathNode>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBTaxiPath>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBTaxiNode>(cacheFlag, 1);
		}

		[InitializeHandler(InitPass.Fourth)]
		public static void CoInitialize()
		{
			try
			{
				Database.Instance.LoadDatabaseTable(typeof(DBTaxiPathNode));
				Database.Instance.LoadDatabaseTable(typeof(DBTaxiPath));
				Database.Instance.LoadDatabaseTable(typeof(DBTaxiNode));
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error: " + e);
			}
		}
	}
}