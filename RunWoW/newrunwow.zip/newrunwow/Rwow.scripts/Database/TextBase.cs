//
using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.DB.DataTables;

namespace RunWoW.ServerDatabase
{
	public class TextBase
	{
		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			DBFlags cacheFlag = Constants.NoInnerCache ? DBFlags.None : DBFlags.Cached;

			Database.Instance.RegisterDataObject<DBPage>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBText>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBDialog>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBSpeech>(cacheFlag, 1);
		}

		[InitializeHandler(InitPass.Fourth)]
		public static void CoInitialize()
		{
			try
			{
				Database.Instance.LoadDatabaseTable(typeof(DBPage));
				Database.Instance.LoadDatabaseTable(typeof(DBText));
				Database.Instance.LoadDatabaseTable(typeof(DBDialog));
				Database.Instance.LoadDatabaseTable(typeof(DBSpeech));
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error: " + e);
			}
		}
	}
}