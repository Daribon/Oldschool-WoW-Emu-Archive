//
using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.DB.DataTables;

namespace RunWoW.ServerDatabase
{
	public class OtherBase
	{
		public static DBSpell GhostSpell, GhostWispSpell;
		public static DBSpell ResSicknessSpell, SpiritResDummy, SpiritResSpell;
		public static DBSpell BindSpell;
		public static DBSpell DazeSpell;

		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			DBFlags cacheFlag = Constants.NoInnerCache ? DBFlags.None : DBFlags.Cached;

			Database.Instance.RegisterDataObject<DBSpell>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBSpellCost>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBLoot>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBGOLoot>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBTrain>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBTrade>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBTalent>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBNSkill>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBSSkill>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBDisenchant>(cacheFlag, 1);
//			Database.Instance.RegisterDataObject<DBEnchantment>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBRepair>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBPoint>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBLock>(cacheFlag, 1);

			Database.Instance.RegisterDataObject<DBFaction>(DBFlags.None, 1);
			Database.Instance.RegisterDataObject<DBStartOutfit>(DBFlags.None, 1);
		}

		[InitializeHandler(InitPass.Fourth)]
		public static void CoInitialize()
		{
			try
			{
				Database.Instance.LoadDatabaseTable(typeof(DBTalent));
				Database.Instance.LoadDatabaseTable(typeof(DBSSkill));
				Database.Instance.LoadDatabaseTable(typeof(DBDisenchant));
//				Database.Instance.LoadDatabaseTable(typeof(DBEnchantment));
				Database.Instance.LoadDatabaseTable(typeof(DBRepair));
				Database.Instance.LoadDatabaseTable(typeof(DBPoint));

				GhostSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 8326);
				GhostWispSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 20584);

				ResSicknessSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 15007);
				SpiritResSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 22012);
				SpiritResDummy = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 17251);

				DazeSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 1604);

				BindSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 3286);
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error: " + e);
			}
		}
	}
}