//
using System;
using RunServer.Common;
using RunServer.Database;

namespace RunWoW.ServerDatabase
{
	public class DBManager
	{
		public static void SaveDBObject(DataObject obj)
		{
			if (obj == null)
				return;
			try
			{
				Database.Instance.SaveObject(obj);
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "Error saving object: " + e);
			}
		}

		public static void EraseDBObject(DataObject obj)
		{
			if (obj == null)
				return;
			try
			{
				Database.Instance.DeleteObject(obj);
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "Error deleting object: " + e);
			}
		}

		public static void NewDBObject(DataObject obj)
		{
			if (obj == null)
				return;
			try
			{
				Database.Instance.AddNewObject(obj);
				Database.Instance.ResolveRelations(obj);
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "Error creating object: " + e);
			}
		}
	}
}