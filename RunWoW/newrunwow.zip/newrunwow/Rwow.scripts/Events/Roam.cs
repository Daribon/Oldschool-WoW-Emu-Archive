//
using System;
using RunWoW.Map;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.Events
{
	public class RoamEvent : Event
	{
		private LivingObject m_mover;
		private bool nostart = false;
		private Vector m_target;

		public RoamEvent(LivingObject mover, Vector position)
			: base(TimeSpan.Zero/*, TimeSpan.FromMilliseconds(Utility.Random(Constants.MobileRoamDelay, Constants.MobileRoamDelay*5))*/)
		{
			m_mover = mover;
			//int count = 0;
			//while (v == null && count++ < 3)
			{
				float x = position.X + Utility.Random(Constants.MobileRoamMinRange, Constants.MobileRoamMaxRange);
				float y = position.Y + Utility.Random(Constants.MobileRoamMinRange, Constants.MobileRoamMaxRange);
				float z = position.Z;// WorldMap.GetPoint((int)mover.MapTile.Map.MapID, x, y);
				/*if (z == float.NaN || Math.Abs(z - position.Z) > 10f)
					continue;*/
				m_target = new Vector(x, y, z);
			}
			if (m_target == null)
			{
				nostart = true; //Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}

			Interval = TimeSpan.FromMilliseconds(MonsterMove.GetTime(m_mover, m_target, false) +
				                          Utility.Random(Constants.MobileRoamDelay, Constants.MobileRoamDelay*2));
			
			//Priority = TimerPriority.OneSecond;
			//Primary = false;
			ExecPriority = ExecutionPriority.Pool;
		}

		protected override bool OnStart()
		{
			if (nostart)
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return false;
			}
			MonsterMove.MoveTo(m_mover, m_target, false, false, true);
			
			bool result = base.OnStart();
			if (result && m_mover is UnitBase)
				((UnitBase)m_mover).Moving = true;
			return result;
		}

		protected override void OnFinish()
		{
			base.OnFinish();
			if (m_mover is UnitBase)
				((UnitBase)m_mover).Moving = false;
			m_mover = null;
			m_target = null;
		}
		
		protected override void OnTick()
		{
			if (!CheckObjects(m_mover))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}
			if (m_mover.Dead)
			{
				Finish(EventResult.OWNER_DEAD);
				return;
			}
			if (m_mover.Stunned || m_mover.Pacified || m_mover.NoControl)
			{
				Finish(EventResult.CANCELED);
				return;
			}

			if (m_mover.Health < m_mover.MaxHealth)
			{
				m_mover.Health += (int) (Constants.MonsterRegen*m_mover.MaxHealth);
				if (m_mover.Health > m_mover.MaxHealth)
					m_mover.Health = m_mover.MaxHealth;
				m_mover.UpdateData();
			}
			if (m_mover.Power < m_mover.MaxPower)
			{
				m_mover.Power += (int) (Constants.MonsterRegen*m_mover.MaxPower);
				if (m_mover.Power > m_mover.MaxPower)
					m_mover.Power = m_mover.MaxPower;
				m_mover.UpdateData();
			}
			Finish(EventResult.COMPLETED);
		}
	}
}