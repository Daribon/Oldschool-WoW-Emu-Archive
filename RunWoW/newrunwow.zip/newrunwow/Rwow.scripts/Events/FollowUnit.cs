//
using System;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Misc.Pathing;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.Events
{
	public class FollowUnitEvent : Event
	{
		private LivingObject m_mover;
		private LivingObject m_target;
		private bool m_run;

		private int time_per_step;

		private BasePath m_path;
		private DateTime m_last;

		private DateTime m_startTime;

		//private float m_range;
		private bool m_water;
		private float m_speed;

		private int m_aggressive;

		private bool m_near = false;
		private MapInstance m_map;

		public bool Near
		{
			get { return m_near; }
		}

		public TimeSpan Elapsed
		{
			get { return CustomDateTime.Now - m_startTime;  }
		}

		public FollowUnitEvent(LivingObject mover, LivingObject living, TimeSpan elapsedShift, bool run, int aggressive)
			: base(TimeSpan.Zero, TimeSpan.FromMilliseconds(Constants.MonsterMoveUpdateTime))
		{
			//Primary = false;
			m_mover = mover;
			m_target = living;
			m_run = run;
			m_aggressive = aggressive;
			m_map = mover.MapTile.Map;

			//m_range = (m_aggressive ? Constants.MobileStopFollowRangeFar : Constants.MobileStopFollowRangeNear);
			m_startTime = CustomDateTime.Now - elapsedShift;
			//Primary = false;
			ExecPriority = ExecutionPriority.Pool;
		}

		protected override bool OnStart()
		{
			if (!CheckObjects(m_mover, m_target) || m_map == null)
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				//Console.WriteLine("Cannot start follow event event");
				return false;
			}

			m_speed = m_run ? m_mover.RunningSpeed : m_mover.WalkSpeed;
			m_water = m_target.InWater;
			time_per_step = (int) Math.Round(Constants.MonsterMoveStepRange*1000/m_speed);

			m_path =
				new DirectPath(m_mover.Position, null, Constants.MonsterMoveStepRange, m_mover.CombatReach + m_target.BoundingRadius, Utility.Random(-1f, 1f));
			
			m_last = CustomDateTime.Now;

			bool result = base.OnStart();
			if (result && m_mover is UnitBase)
				((UnitBase)m_mover).Moving = true;
			return result;
		}

		protected override void OnFinish()
		{
			base.OnFinish();
			if (m_mover is UnitBase)
				((UnitBase)m_mover).Moving = false;
			m_mover = null;
			m_target = null;
		}

		protected override void OnTick()
		{
			if (!CheckObjects(m_mover, m_target))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				//Console.WriteLine("Cannot start follow event event");
				return;
			}
			if (m_mover.Stunned || m_mover.Rooted || m_mover.Pacified || m_mover.NoControl)
			{
				MonsterMove.FixPosition(m_mover);
				Finish(EventResult.CANCELED);
				return;
			}
			if (!m_mover.Attackable)
			{
				//if (!m_path.Finished)
				//	MonsterMove.MoveTo(m_mover, m_mover.Position, m_run, m_mover.Facing, true); // fixes corpse sliding bug ?
				m_mover.Position = m_path.Current;
				m_map.Move(m_mover);
				MonsterMove.FixPosition(m_mover);
				Finish(EventResult.OWNER_DEAD);
				return;
			}
			if (!m_target.Attackable)
			{
				Finish(EventResult.TARGET_DEAD);
				return;
			}
			if (m_target.InWater != m_water) // gone into water
			{
				Finish(EventResult.TARGET_TO_FAR);
				return;
			}

			if (Math.Abs(m_speed - (m_run ? m_mover.RunningSpeed : m_mover.WalkSpeed)) > 0.1)
			{
				Finish(EventResult.NEED_RECALC);
				//Console.WriteLine("Sped changed in follow event event");
				return;
			}

			if (m_path.Recalc(m_target.Position) && !m_path.Finished)
			{
				//LogConsole.WriteLine(LogLevel.ECHO, "FollowUnit: Got Target: " + m_path.To);
				MonsterMove.MoveTo(m_mover, m_path.Path, m_run, m_path.Direction, true);
				//LogConsole.WriteLine(LogLevel.ECHO, "FollowUnit: Distance: " + m_path.Distance + ", steps: " + m_path.Steps);
			}
			
			if (m_path.Finished)
			{
				m_mover.Position = m_path.Current;
				MonsterMove.MoveTo(m_mover, m_mover.Position, false, time_per_step, false);
				if (m_aggressive > 0)
				{
					//CombatEvent.HitOnce(m_mover, m_target);
					m_near = true;
				}
				else
				{
					Finish(EventResult.COMPLETED);
				}
				//Console.WriteLine("Done follow event event");
				return;
			}

			m_near = false;
			
			if (m_last + TimeSpan.FromMilliseconds(time_per_step) > CustomDateTime.Now)
				return;
			
			int steps = (int) ((CustomDateTime.Now - m_last).TotalMilliseconds/time_per_step);
			if (m_path.Advance(steps) == 0)
			{
			    m_mover.Position = m_path.Current;
				MonsterMove.MoveTo(m_mover, m_mover.Position, false, time_per_step, false);
				Finish(EventResult.COMPLETED);
			//    //Console.WriteLine("Done follow event event");
			    return;
			}

			if (m_path.Path.Count > 0)
				foreach (Vector npoint in m_path.Path)
				{
					m_mover.Position = npoint.Clone();
					break;
				}
			else
				m_mover.Position = m_path.Current;

			m_map.Move(m_mover);
			m_last = CustomDateTime.Now;
			UnitBase unit = m_mover as UnitBase;

			if (unit == null)
				return;

			if (unit.Creature.Elite > 0 && !WorldBase.Worlds.Contains(unit.MapTile.Map.MapID))
				return; // elites always follow in instances

			switch(m_aggressive)
			{
				case 1:
					if (Elapsed.TotalSeconds > Constants.MobileStopFollowTime + (m_mover.Level - m_target.Level)/4)
					{
						Finish(EventResult.TARGET_TO_FAR);
						return;
					}
					if (unit.Spawn != null && unit.Spawn.Position.DistanceAvr(unit.Position) > Constants.MobileWakeRange/2 + (m_mover.Level - m_target.Level))
					{
						Finish(EventResult.TARGET_TO_FAR);
						return;
					}
					break;
				case 2:
					if (Elapsed.TotalSeconds > Constants.MobileStopFollowTimeAgrr)
					{
						Finish(EventResult.TARGET_TO_FAR);
						return;
					}
					if (unit.Spawn != null && unit.Spawn.Position.DistanceAvr(unit.Position) > Constants.MobileWakeRange / 2 * Utility.Random(1f, 2f))
					{
						Finish(EventResult.TARGET_TO_FAR);
						return;
					}
					break;
			}
		}
	}
}