//
using System;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.Events
{
	public abstract class BaseCombatEvent: Event
	{
		public abstract LivingObject Target
		{
			get;
		}

		protected BaseCombatEvent(TimeSpan delay) : base(delay)
		{
		}

		protected BaseCombatEvent(TimeSpan delay, TimeSpan interval) : base(delay, interval)
		{
		}

		public abstract void ChangeTarget(LivingObject target);

		public static void HitOnce(LivingObject attacker, LivingObject target)
		{
			if (attacker == null || target == null)
				return;
			if (!attacker.Attackable)
				return;
			if (attacker.Casting || attacker.Stunned || attacker.Pacified || attacker.NoControl)
				return;
			if (!target.Attackable)
				return;
			if (attacker.LastHit + TimeSpan.FromMilliseconds(attacker.AttackTime) > CustomDateTime.Now)
				return;
			
			float distance = attacker.Position.Distance(target.Position);

			if (distance > attacker.CombatReach + target.BoundingRadius + 3.5f)
				return;

			PlayerObject player = attacker as PlayerObject;

			if (player != null && distance > target.BoundingRadius &&
			    !attacker.Position.InFront(attacker.Facing, target.Position))
				return;
			attacker.LastHit = CustomDateTime.Now;

			if (player != null && player.NextHitSpell != null)
				CastNextHit(player, target);
			else
				attacker.SubmitMeleeDamage(target);
		}

		public static bool InCombatDistance(LivingObject attacker, LivingObject target)
		{
			float targetDistance = attacker.CombatReach + target.BoundingRadius + 3.5f;
			
			if (attacker.Position.DistanceAvr(target.Position) >= targetDistance)
				return false;

			return attacker.Position.Distance(target.Position) <= targetDistance;
		}

		public static void CastNextHit(PlayerObject player, LivingObject target)
		{
			DBSpell spell = player.NextHitSpell;
			player.NextHitSpell = null;
			try
			{
				int power = player.SpellProcessor.PowerCost(spell, player.Level, player.MaxPower);

				if (power > player.Power)
					SpellCastEvent.SpellCastResult(player.BackLink.Client, spell.ObjectId,
												   SpellFailedReason.SPELL_FAILED_NO_POWER);
				else
				{
					SpellCastEvent cast = new SingleTargetCast(player, spell, 0x2, target, false);
					player.CastEvent = cast;
					cast.Start();
				}
			}
			catch (Exception ex)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error while casting next attack spell {0} for {1}: {2}",
									 player.NextHitSpell.Name, player.Name, ex);
			}

		}


	}
}