using System;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Misc.Pathing;
using RunWoW.Objects;

namespace RunWoW.Events
{
	public class RangeUnitEvent : Event
	{
		private LivingObject m_mover;
		private LivingObject m_target;
		private bool m_run;

		private int time_per_step;

		private BasePath m_path;
		private DateTime m_last;

		private float m_stopRange;
		private float m_range;
		private bool m_water;
		private float m_speed;

		public RangeUnitEvent(LivingObject mover, LivingObject target, bool run, bool force, float range)
			: base(TimeSpan.Zero, TimeSpan.FromMilliseconds(Constants.MonsterMoveUpdateTime))
		{
			//Primary = false;
			m_mover = mover;
			m_target = target;
			m_run = run;
			m_range = range;

			m_speed = m_run ? m_mover.RunningSpeed : m_mover.WalkSpeed;
			m_water = m_target.InWater;
			m_stopRange = (force ? 100f : 50f);
			//Primary = false;
			ExecPriority = ExecutionPriority.Pool;
		}

		protected override bool OnStart()
		{
			if (!CheckObjects(m_mover, m_target))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return false;
			}
			time_per_step = (int) Math.Round(Constants.MonsterMoveStepRange*1000/m_speed);
			m_path = new DirectPath(m_mover.Position, null, Constants.MonsterMoveStepRange, m_range, 0f);
			m_last = CustomDateTime.Now;

			bool result = base.OnStart();
			if (result && m_mover is UnitBase)
				((UnitBase)m_mover).Moving = true;
			return result;
		}

		protected override void OnFinish()
		{
			base.OnFinish();
			if (m_mover is UnitBase)
				((UnitBase)m_mover).Moving = false;
			m_mover = null;
			m_target = null;
		}

		protected override void OnTick()
		{
			if (!CheckObjects(m_mover, m_target))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}
			if (m_mover.Stunned || m_mover.Rooted || m_mover.Pacified || m_mover.NoControl)
			{
				MonsterMove.FixPosition(m_mover);
				Finish(EventResult.CANCELED);
				return;
			}
			if (!m_mover.Attackable)
			{
				if (!m_path.Finished)
					MonsterMove.MoveTo(m_mover, m_mover.Position, m_run, m_mover.Facing, true); // fixes corpse sliding bug ?
				Finish(EventResult.OWNER_DEAD);
				return;
			}
			if (!m_target.Attackable)
			{
				Finish(EventResult.TARGET_DEAD);
				return;
			}
			if (m_target.InWater != m_water) // gone into water
			{
				// TODO: swimming creatures check
				Finish(EventResult.TARGET_TO_FAR);
				return;
			}

			if (m_path.Recalc(m_target.Position))
			{
				LogConsole.WriteLine(LogLevel.ECHO, "FollowUnit: Got Target: {0}", m_path.To);
				MonsterMove.MoveTo(m_mover, m_path.Path, m_run, m_path.Direction, true);
				LogConsole.WriteLine(LogLevel.ECHO, "FollowUnit: Distance: {0} steps: {1}", m_path.Distance, m_path.Steps);
			}

			if (m_path.Finished)
			{
				Finish(EventResult.COMPLETED);
				return;
			}

			if (m_path.Distance > m_stopRange)
			{
				Finish(EventResult.TARGET_TO_FAR);
				return;
			}

			if (m_last + TimeSpan.FromMilliseconds(time_per_step) > CustomDateTime.Now)
				return;

			int steps = (int) ((CustomDateTime.Now - m_last).TotalMilliseconds/time_per_step);
			if (m_path.Advance(steps) == 0)
			{
				Finish(EventResult.COMPLETED);
				return;
			}
			m_mover.Position = m_path.Current.Clone();
			m_mover.MapTile.Map.Move(m_mover);
			m_last = CustomDateTime.Now;
		}
	}
}