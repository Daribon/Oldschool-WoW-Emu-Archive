//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.Vendors;

namespace RunWoW.Accounting
{
	internal class PlayerHolder
	{
		private DateTime m_expireTime;
		private PlayerObject m_player;
		private string m_name;

		public string Name
		{
			get { return m_name; }
		}

		public PlayerHolder(PlayerObject player)
		{
			m_player = player;
			m_name = player == null ? "(unknown)" : player.Name;
			Update();
		}

		public void Update()
		{
			m_expireTime = m_player == null ? CustomDateTime.Now : (CustomDateTime.Now.AddMinutes(3));
			if (m_player != null && m_player.CastEvent is Taxi.RideEvent && !m_player.CastEvent.Finished)
				m_expireTime = CustomDateTime.Now.AddMilliseconds(((Taxi.RideEvent)m_player.CastEvent).TotalTime + 5000);
		}

		public PlayerObject Player
		{
			get { return m_player; }
		}

		public bool Expired
		{
			get { return m_expireTime < CustomDateTime.Now || m_player == null || m_player.Disposed; }
		}

		public void Cleanup()
		{
			if (m_player != null)
				m_player.Dispose();
		}
	}

	public class ClientManager : Event
	{
		private static Dictionary<uint, PlayerObject> m_online = new Dictionary<uint, PlayerObject>();
		private static Dictionary<uint, PlayerHolder> m_offline = new Dictionary<uint, PlayerHolder>();

		private static ClientManager Instance = new ClientManager();

		private static PooledList<PlayerObject> m_onlineList = null;
		private static int m_listVersion = 0;
		private static int m_onlineVersion = 0;

		private static object m_syncRoot = new object();

		public static int OnlineCount
		{
			get { lock (m_syncRoot) return m_online.Count; }
		}

		public static int OfflineCount
		{
			get { lock (m_syncRoot) return m_offline.Count; }
		}

		public static PlayerObject RegisterPlayer(DBCharacter character, ClientData owner)
		{
			if (character == null)
				return null;
			uint id = character.ObjectId;

			if (IsOnline(id))
				return m_online[id];

			lock (m_syncRoot)
			{
				PlayerObject player = null;

				if (m_offline.ContainsKey(id))
				{
					PlayerHolder holder = m_offline[id];
					m_offline.Remove(id);
					if (!holder.Expired)
						player = holder.Player;
				}

				if (player != null)
					player.Reconnect(owner);
				else
					player = new PlayerObject(character, owner);


				m_onlineVersion++;
				m_online[id] = player;
				return player;
			}
		}

		public static void UnregisterPlayer(PlayerObject player, bool force)
		{
			if (player == null)
				return;
			uint id = player.CharacterID;
			if (!IsOnline(id) && !IsOffline(id))
			{
				LogConsole.WriteLine(LogLevel.SYSTEM, "Player " + player.Name + " not found in online/offlie lists!");
				player.Dispose();
				return;
			}

			player.Save();

			lock (m_syncRoot)
			{
				if (force)
					m_offline.Remove(id);
				else
					if (!m_offline.ContainsKey(id))
						m_offline[id] = new PlayerHolder(player);
					else
						m_offline[id].Update();

				m_onlineVersion++;
				m_online.Remove(id);
			}
		}

		public static bool IsOnline(uint id)
		{
			lock (m_syncRoot)
				return m_online.ContainsKey(id);
		}

		public static bool IsOffline(uint id)
		{
			lock (m_syncRoot)
				return m_offline.ContainsKey(id);
		}

		#region Getters

		public static PlayerObject GetPlayer(ulong GUID)
		{
			return GetPlayer((uint) GUID);
		}

		public static PlayerObject GetPlayer(uint characterID)
		{
			lock (m_syncRoot)
				if (m_online.ContainsKey(characterID))
					return m_online[characterID];

			return null;
		}

		public static PlayerObject GetPlayer(string name)
		{
			lock (m_syncRoot)
			{
				IEnumerator e = m_online.Values.GetEnumerator();
				while (e.MoveNext())
				{
					PlayerObject player = (PlayerObject) e.Current;
					if (player.Name.ToLower() == name.ToLower())
						return player;
				}
			}
			return null;
		}

		public static DBCharacter GetCharacter(uint characterID)
		{
			PlayerObject player = GetPlayer(characterID);
			if (player != null && player.Character != null)
				return player.Character;
			return (DBCharacter) Database.Instance.FindObjectByKey(typeof (DBCharacter), characterID);
		}

		public static DBCharacter GetCharacter(string name)
		{
			PlayerObject player = GetPlayer(name);
			if (player != null && player.Character != null)
				return player.Character;
			return (DBCharacter)Database.Instance.FindObjectByField(typeof(DBCharacter), "Name", name);
		}

		public static ClientBase GetClient(string name)
		{
			PlayerObject player = GetPlayer(name);
			return player != null ? player.BackLink != null ? player.BackLink.Client : null : null;
		}

		public static ClientBase GetClient(uint characterID)
		{
			PlayerObject player = GetPlayer(characterID);
			return player != null ? player.BackLink != null ? player.BackLink.Client : null : null;
		}

		public static PooledList<PlayerObject> GetPlayerList()
		{
			lock (m_syncRoot)
			{
				if (m_onlineList == null || m_listVersion < m_onlineVersion)
					return m_onlineList = new PooledList<PlayerObject>(m_online.Values);
				else
					return m_onlineList;
			}
		}

		#endregion

		private ClientManager()
			: base(TimeSpan.FromMinutes(1), TimeSpan.FromMinutes(1))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			lock (m_syncRoot)
			{
				List<uint> toRemove = new List<uint>();
				foreach (KeyValuePair<uint, PlayerHolder> pair in m_offline)
					if (pair.Value.Expired)
					{
						toRemove.Add(pair.Key);
						Console.WriteLine("Player {0} cleaned", pair.Value.Name);
						pair.Value.Cleanup();
					}

				foreach (uint key in toRemove)
					m_offline.Remove(key);

				m_onlineList = null;
			}
		}

		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}
}