//
using System.Collections.Specialized;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.AI
{
	internal delegate UnitBase MobileConstructor(DBSpawn spawn);

	public class AIManager
	{
		private static HybridDictionary m_AIs = new HybridDictionary();

		internal static void RegisterAI(byte ID, MobileConstructor Constructor)
		{
			m_AIs[ID] = Constructor;
		}

		public static UnitBase CreateMobile(DBSpawn spawn)
		{
			//return new CritterBase(spawn);
			MobileConstructor constructor = (MobileConstructor) m_AIs[spawn.BehaivorID];
			if (constructor == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Spawning mobile {0} with undefined behaivor!", spawn.ObjectId);
				return new MonsterBase(spawn, true);
			}
			return constructor(spawn);
			//return (UnitBase)Activator.CreateInstance((Type)m_AIs[spawn.BehaivorID],new Object[]{spawn});
		}
	}
}