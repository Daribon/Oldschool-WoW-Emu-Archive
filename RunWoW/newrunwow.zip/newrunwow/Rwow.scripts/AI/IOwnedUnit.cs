//
using RunWoW.Objects;

namespace RunWoW.AI
{
	public interface IOwnedUnit
	{
		LivingObject Owner { get; }
	}
}
