//
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerScripts.AI.Behaivors;
using RunServer.Common;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class GuardBase : UnitBase
	{
		private Behaivor m_behaivor;
		private bool m_roaming;

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(GuardBase));
			AIManager.RegisterAI(4, new MobileConstructor(CreateRoaming));
			AIManager.RegisterAI(6, new MobileConstructor(CreateStanding));
			AIManager.RegisterAI(5, new MobileConstructor(CreateStanding));
		}

		public static UnitBase CreateStanding(DBSpawn spawn)
		{
			return new GuardBase(spawn, false);
		}

		public static UnitBase CreateRoaming(DBSpawn spawn)
		{
			return new GuardBase(spawn, true);
		}

		public GuardBase(DBSpawn spawn, bool roaming)
			: base(spawn)
		{
			m_roaming = roaming;
			m_speedmod_base = 1.2f;
			m_speedmod = m_speedmod_base;
			MinDamage *= 2;
			MaxDamage *= 2;
			Flags = 0x1800;
			//NPC_Flags = 1;
		}

		public GuardBase(DBCreature creature, Vector position, float facing, bool roaming)
			: base(
				creature, creature.Defaults.Level, position, facing, creature.Defaults.Flags, creature.Defaults.NpcFlags,
				creature.Defaults.Faction)
		{
			m_roaming = roaming;
			m_speedmod_base = 1.3f;
			m_speedmod = m_speedmod_base;
			MinDamage *= 2;
			MaxDamage *= 2;
			Flags = 0x1800;
			//NPC_Flags = 1;
		}

		protected override void StartFightEvent(LivingObject enemy)
		{
			Init();
			DoAwake();
			if (!Attacking && Utility.Chance(0.5))
				if (Spawn.Speech != null && Spawn.Speech.AttackedText != null)
					Chat.MonsterSay(this, null, Spawn.Speech.AttackedText.Text);
			base.StartFightEvent(enemy);
		}

		public override void Attacked(LivingObject enemy)
		{
			Init();
			DoAwake();
			m_behaivor.Attacked(enemy);
		}

		public override void DoSleep()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.Finish(EventResult.COMPLETED);
			
			if (Position.DistanceSqrd(Spawn.Position) > 25f)
			{
				Position = Spawn.Position;
				MapTile.Map.Move(this);
			}
		}

		public override void DoAwake()
		{
			if (m_behaivor == null)
				if (m_roaming)
					m_behaivor = new RoamingGuardAI(this);
				else
					m_behaivor = new StandingGuardAI(this);
			m_behaivor.Start();
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_behaivor != null && !m_behaivor.Finished)
					m_behaivor.Finish(EventResult.COMPLETED);
			}
			base.Dispose(disposing);
		}
		public override void BehaivorTick()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.OnTick();
		}

		public override void GenerateLoot()
		{
			return;
		}
	}
}