using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerScripts.AI.Behaivors;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class HeraldBase : UnitBase
	{
		private Behaivor m_behaivor;

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(HeraldBase));
			AIManager.RegisterAI(12, new MobileConstructor(Create));
		}

		public static UnitBase Create(DBSpawn spawn)
		{
			return new HeraldBase(spawn);
		}

		public HeraldBase(DBSpawn spawn)
			: base(spawn)
		{
			MaxHealth = 100;
			Health = 100;
			Level = 1;
			Money = 0;
		}

		public override void Attacked(LivingObject enemy)
		{
			Die();
		}

		public override void DoSleep()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.Finish(EventResult.COMPLETED);
		}

		public override void DoAwake()
		{
			if (m_behaivor == null)
				m_behaivor = new HeraldAI((this));
			m_behaivor.Start();
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_behaivor != null && !m_behaivor.Finished)
					m_behaivor.Finish(EventResult.COMPLETED);
			}
			base.Dispose(disposing);
		}

		public override void GenerateLoot()
		{
			return;
		}

		public override void BehaivorTick()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.OnTick();
		}
	}
}