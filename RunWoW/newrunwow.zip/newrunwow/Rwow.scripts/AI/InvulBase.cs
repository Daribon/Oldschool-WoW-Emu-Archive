//
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class InvulBase : UnitBase
	{
		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(InvulBase));
			AIManager.RegisterAI(10, new MobileConstructor(Create));
		}

		public static UnitBase Create(DBSpawn spawn)
		{
			return new InvulBase(spawn);
		}

		public InvulBase(DBSpawn spawn)
			: base(spawn)
		{
			MaxHealth = 100;
			Health = 100;
			Money = 0;
		}

		public override bool Attackable
		{
			get { return false; }
		}
	}
}