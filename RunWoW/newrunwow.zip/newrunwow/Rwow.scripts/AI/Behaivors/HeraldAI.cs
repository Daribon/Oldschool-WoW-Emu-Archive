//
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public class HeraldAI : Behaivor
	{
		public static uint FireworksSpellId = 11543;
		public static DBSpell FireworksSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), FireworksSpellId);

		public HeraldAI(UnitBase unit)
			: base(unit)
		{
		}

		public override void Attacked(LivingObject enemy)
		{
			m_unit.Die();
		}

		protected override void Calculate()
		{
			if (m_unit.Spawn.Speech != null && m_unit.Spawn.Speech.AttackedText != null)
				if (Utility.Chance(0.05f))
					Chat.MonsterYell(m_unit, m_unit.Spawn.Speech.AttackedText.Text);
				else if (Utility.Chance(0.1f))
					Chat.MonsterYell(m_unit, m_unit.Spawn.Speech.FleeText.Text);

			if (Utility.Chance(0.05f))
			{
				SpellCastEvent fireworks = new SingleTargetCast(m_unit, FireworksSpell, 2, m_unit, false);
				fireworks.Start();
			}
		}
	}
}