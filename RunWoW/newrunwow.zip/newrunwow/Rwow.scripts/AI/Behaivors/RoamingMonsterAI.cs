//
using System;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public class RoamingMonsterAI : Behaivor
	{
		protected override bool ShouldAttackMonster(LivingObject unit)
		{
			return
				unit != null &&
				unit.Attackable &&
				unit.Level <= m_unit.Level &&
				!Faction.SameFaction(m_unit, unit) &&
				Faction.ShouldAttackMonster(m_unit.Faction, unit.Faction) &&
				Utility.Chance(0.15) &&
				Math.Abs(unit.Position.Z - m_unit.Position.Z) <= Constants.MonsterZSightRange &&
				unit.Position.DistanceAvr(m_unit.Position) <= Constants.MonsterSightRange;
		}

		protected override bool ShouldAttackPlayer(LivingObject er)
		{
			PlayerObject player = er as PlayerObject;

			if (player == null || !player.Attackable)
				return false;

			if (player == Enemy)
				return true;

			if (m_unit.Attackers.Contains(player.GUID))
				return true;

			if (!Faction.ShouldAttackPlayer(m_unit.Faction, player.Faction))
				return false;

			if (Math.Abs(player.Position.Z - m_unit.Position.Z) > Constants.MonsterZSightRange)
				return false;

			float distance = player.Position.DistanceAvr(m_unit.Position);

			if (!player.Stealth && distance < 3f)
				return true;

			float sightRange = Constants.MonsterSightRange + m_unit.Level - player.Level;

			if (sightRange < 3f)
				return false;

			if (sightRange > 45f)
				sightRange = 45f;

			if (m_unit.Level >= 60 && m_unit.Creature.Elite > 0)
				sightRange *= 2f;

			if (!m_unit.Position.InFront(m_unit.Facing, player.Position))
				if (player.Stealth)
					return false;
				else
					sightRange /= 2;

			return distance <= sightRange;
		}

		public RoamingMonsterAI(UnitBase unit)
			: base(unit)
		{
		}

		private void DoAttack(LivingObject enemy)
		{
			/*if (enemy.Position.DistanceAvr(m_unit.Position) > m_unit.CombatReach + enemy.BoundingRadius)
				SetState(MonsterState.AggrMovingToEnemy, enemy);
			else*/
			if (enemy != Enemy)
				SetState(MonsterState.Attacking, enemy);
		}

		public override void Attacked(LivingObject enemy)
		{
			if (m_unit == null)
				return;

			LivingObject aggroer = m_unit.Attackers.MostAggressive;
			if (aggroer == Enemy && m_unit.Attacking)
				return;
			
			if (m_unit.Attacking && Enemy != null && aggroer != null) // should we switch targets, or still attack old one?
				if (!m_unit.Attackers.Compare(Enemy.GUID, aggroer.GUID, m_unit.Position))
					return;

			if (aggroer != null)
				DoAttack(aggroer);
			else
				if (enemy != null/* && State != MonsterState.Attacking*/)
					DoAttack(enemy);
		}

		private bool CanCast()
		{
			if (m_unit.Stunned || m_unit.Pacified || m_unit.Silenced || m_unit.NoControl)
				return false;
			if (m_unit.Spells == null || m_unit.Level <= 5 || !Utility.Chance(0.10f))
				return false;
			for (int i = 0; i < m_unit.Spells.Length; i++)
				if (m_unit.Spells[i].AutoCast && m_unit.Spells[i].Spell.PowerCost < m_unit.Power)
					return true;
			return false;
		}

		private void IdleMode()
		{
			if (m_unit.Stunned || m_unit.Rooted || m_unit.NoControl)
			{
				SetState(MonsterState.Roaming, null);
				return; // do nothing and roll idle or roaming mode
			}

			if (!m_unit.Pacified)
			{
				/*Attacked(null);

				if (Enemy != null)
					return;*/

				if (Search()) // if there is no enemies or we are pacified (sheep, etc.) - return to spawn
					return;
			}

			if (m_unit.Spawn != null && m_unit.Position.DistanceAvr(m_unit.Spawn.Position) > Constants.MobileMaxOffspawnRange)
			{
				SetState(MonsterState.Returning, null);
				return;
			}
			else
			{
				SetState(MonsterState.Roaming, null);
				return;
			}
		}

		protected override void Calculate()
		{
			switch (State)
			{
				case MonsterState.Attacking:
					switch (AttackState())
					{
						case EventResult.NOT_FINISHED:
						case EventResult.ERROR:
							if (Enemy != null && Enemy.Attackable && !Enemy.IsDisposed)
							{
								if (m_unit.Position.Distance(Enemy.Position) > m_unit.CombatReach + Enemy.BoundingRadius + 2f)
									SetState(MonsterState.AggrMovingToEnemy, Enemy, true);
								else 
									if (AttackState() == EventResult.ERROR)
										SetState(State, Enemy, true);

							}
							else
								IdleMode();
							break;
						default:
							IdleMode();
							break;
					}

					break;

				case MonsterState.AggrMovingToEnemy:
				case MonsterState.MovingToEnemy:
					switch (ActionState())
					{
						case EventResult.NOT_FINISHED:
							if (Event is FollowUnitEvent && ((FollowUnitEvent) Event).Near)
								if (CanCast())
									SetState(MonsterState.Casting, Enemy);
								else
									SetState(MonsterState.Attacking, Enemy);
							break;
						case EventResult.COMPLETED:
							if (CanCast())
								SetState(MonsterState.Casting, Enemy);
							else
								SetState(MonsterState.Attacking, Enemy);
							break;
						case EventResult.NEED_RECALC:
							SetState(State, Enemy, true);
							break;
						case EventResult.CANCELED:
							if (m_unit.Pacified || m_unit.NoControl)
								SetState(MonsterState.Roaming, null);
							else if (CanCast())
								SetState(MonsterState.Casting, Enemy);
							else
								SetState(MonsterState.Idle, null);
							break;
						default:
							SetState(MonsterState.Idle, null);
							break;
					}
					break;
				case MonsterState.Casting:
					if (Event == null || Event.Finished)
						SetState(MonsterState.Attacking, Enemy);
					break;
				case MonsterState.Returning:
					switch (ActionState())
					{
						case EventResult.ERROR:
							SetState(MonsterState.Returning, null, true);
							break;
						case EventResult.COMPLETED:
							IdleMode();
							break;
						default:
							Search();
							break;
					}
					break;
				case MonsterState.Roaming:
				case MonsterState.Idle:
				default:
					IdleMode();
					break;
			}
		}
	}
}