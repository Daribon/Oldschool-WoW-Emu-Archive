using System;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public class TotemAI : Behaivor
	{
		private LivingObject m_master;
		private bool m_offensive;
		private DateTime m_despawnTime;

		public TotemAI(UnitBase unit, LivingObject master, bool offensive, int duration)
			: base(unit)
		{
			m_master = master;
			m_offensive = offensive;

			if (duration <= 0)
				m_despawnTime = DateTime.MaxValue;
			else
				m_despawnTime = CustomDateTime.Now.AddMilliseconds(duration);
		}

		protected override bool ShouldAttackMonster(LivingObject unit)
		{
			return
				unit != null &&
				unit.Attackable &&
				unit.Position.DistanceAvr(m_unit.Position) <= Constants.MonsterSightRange &&
				(
					unit == Enemy ||
					m_master.Attackers.Contains(unit.GUID) ||
					(!Faction.SameFaction(m_unit, unit) && Faction.ShouldAttackMonster(m_unit.Faction, unit.Faction))
				);
		}

		protected override bool ShouldAttackPlayer(LivingObject player)
		{
			if (player.Position.DistanceAvr(player.Position) <= Constants.TotemSightRange)
				return false;

			if (player == Enemy)
				return true;
			
			if (m_master.Attackers.Contains(player.GUID))
				return true;

			if (m_unit.Attackers.Contains(player.GUID))
				return true;

			if (!Faction.ShouldAttackPlayer(m_unit.Faction, player.Faction))
				return false;

			return true;
		}
		
		public override void Attacked(LivingObject enemy)
		{
			SetState(MonsterState.TotemCasting, enemy);
		}

		protected override void Calculate()
		{
			if (m_master == null || m_master.Dead || m_master.Position.DistanceAvr(m_unit.Position) > Constants.PetMaxRange || m_despawnTime < CustomDateTime.Now)
			{
				m_unit.Die();
				return;
			}
			
			if (!m_offensive)
			{
				if (Event == null || Event.Finished)
					SetState(MonsterState.TotemCasting, null, true);
				return;
			}

			if ((Event == null || Event.Finished))
				if (ShouldAttackMonster(Enemy))
					SetState(MonsterState.TotemCasting, Enemy, true);
				else
					if (!Search(MonsterState.TotemCasting))
						SetState(MonsterState.TotemCasting, null, true);
		}
	}
}