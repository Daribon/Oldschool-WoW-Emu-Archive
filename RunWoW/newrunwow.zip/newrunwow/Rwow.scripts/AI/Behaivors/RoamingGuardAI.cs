//
using System;
using RunServer.Common;
using RunWoW.AI;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.World;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public class RoamingGuardAI : Behaivor
	{
		private DateTime m_helpCalled;
		private bool m_yelled;

		protected override bool ShouldAttackMonster(LivingObject p)
		{
			return
				p != null &&
				p.Attackable &&
				p.FightEvent != null &&
				!Faction.SameFaction(m_unit, p) &&
				Math.Abs(p.Position.Z - m_unit.Position.Z) <= Constants.GuardZSightRange &&
				p.Position.DistanceAvr(m_unit.Position) <= Constants.GuardSightRange;
		}

		protected override bool ShouldAttackPlayer(LivingObject p)
		{
			return
				p != null &&
				p.Attackable &&
				!Faction.SameFaction(m_unit, p) &&
				(/*(p.OnAttackers. is PlayerObject) || */Faction.ShouldAttackPlayer(m_unit.Faction, p.Faction)) &&
				Math.Abs(p.Position.Z - m_unit.Position.Z) <= Constants.GuardZSightRange &&
				p.Position.DistanceAvr(m_unit.Position) <= Constants.GuardSightRange;
		}


		protected override MonsterState DefaultSearchState
		{
			get { return MonsterState.AggrMovingToEnemy; }
		}

		public RoamingGuardAI(UnitBase unit)
			: base(unit)
		{
		}

		private void CallForHelp(LivingObject enemy)
		{
			/*try
			{*/
				if (enemy == null)
					return;
				if (m_helpCalled + TimeSpan.FromSeconds(Constants.MobileAIRecalcLong) > CustomDateTime.Now)
					return;
				m_helpCalled = CustomDateTime.Now;

				PlayerObject player = enemy as PlayerObject;
				if (player != null)
				{
					if (Faction.IsHorde(m_unit.Faction) || Faction.IsAlliance(m_unit.Faction))
						Chat.LocalDefenceMessage(player.Area == null ? player.Zone : player.Area.ObjectId, m_unit, player);
					if (!m_yelled)
					{
						if (Faction.IsHorde(m_unit.Faction))
							Chat.MonsterSay(m_unit, player, "Victory to The Horde!");
						else if (Faction.IsAlliance(m_unit.Faction))
							Chat.MonsterSay(m_unit, player, "For The Alliance!");
						else
							Chat.MonsterSay(m_unit, player, "You'll see my wrath, scum!");

						m_yelled = true;
					}
				}

				int count = 0;
				if (m_unit.MapTile != null)
					foreach (MapTile mapTile in m_unit.MapTile.Adjacents.Tiles)
						if (mapTile != null)
							for (int i = 0; i < mapTile.Units.Last; i++)
							{
								UnitBase unit = mapTile.Units.InnerArray[i] as GuardBase;
								if (unit != null && !unit.IsDisposed && unit.Attackable && !unit.Attacking &&
									Faction.SameFaction(m_unit, unit) &&
									unit.Position.DistanceAvr(m_unit.Position) < Constants.GuardSightRange
									)
								{
									unit.Attacked(enemy);
									count++;
								}
								if (count > 3)
									return;
							}
			/*}
			catch(Exception ex)
			{
			}*/
		}

		private void DoAttack(LivingObject enemy)
		{
			if (enemy != Enemy)
				SetState(MonsterState.AggrMovingToEnemy, enemy);
			//SetState(MonsterState.AggrMovingToEnemy, enemy);
		}

		public override void Attacked(LivingObject enemy)
		{
			if (enemy == null)
				return;
			if (State != MonsterState.Attacking)
				DoAttack(enemy);
			else
			{
				LivingObject aggroer = m_unit.Attackers.MostAggressive;
				if (aggroer == Enemy)
					return;
				if (aggroer != null)
					DoAttack(aggroer);
				else if (State != MonsterState.Attacking)
					DoAttack(enemy);
			}
			CallForHelp(enemy);
		}

		private bool CanCast()
		{
			if (m_unit.Stunned || m_unit.Pacified || m_unit.Silenced || m_unit.NoControl)
				return false;
			if (m_unit.Spells == null || m_unit.Spells.Length == 0)
				return false; //Console.WriteLine("Guard " + m_unit.Name + " has no spells!");
			if (m_unit.Spells == null || !Utility.Chance(0.50f))
				return false;
			for (int i = 0; i < m_unit.Spells.Length; i++)
				if (m_unit.Spells[i].AutoCast && m_unit.Spells[i].Spell.PowerCost < m_unit.Power)
					return true;
			return false;
		}

		private void IdleMode()
		{
			if (m_unit.Stunned || m_unit.Rooted || m_unit.NoControl)
			{
				SetState(MonsterState.Roaming, null);
				return; // do nothing and roll idle or roaming mode
			}

			if (!m_unit.Pacified)
				if (Search()) // if there is no enemies or we are pacified (sheep, etc.) - return to spawn
					return;

			if (m_unit.Spawn != null && m_unit.Position.DistanceAvr(m_unit.Spawn.Position) > Constants.MobileMaxOffspawnRange)
			{
				SetState(MonsterState.Returning, null);
				return;
			}
			else
			{
				SetState(MonsterState.Roaming, null);
				return;
			}
		}

		protected override void Calculate()
		{
			switch (State)
			{
				case MonsterState.Attacking:
					switch (AttackState())
					{
						case EventResult.NOT_FINISHED:
						case EventResult.ERROR:
							if (Enemy != null && !Enemy.Dead && !Enemy.IsDisposed && Enemy.Attackable)
							{
								if (m_unit.Position.DistanceAvr(Enemy.Position) > m_unit.CombatReach + Enemy.BoundingRadius)
									SetState(MonsterState.AggrMovingToEnemy, Enemy);
							}
							else
								IdleMode();
							break;
						default:
							IdleMode();
							break;
					}

					break;

				case MonsterState.AggrMovingToEnemy:
				case MonsterState.MovingToEnemy:
					switch (ActionState())
					{
						case EventResult.NOT_FINISHED:
							if (Event is FollowUnitEvent && ((FollowUnitEvent) Event).Near && CanCast())
								SetState(MonsterState.Casting, Enemy);
							break;
						case EventResult.COMPLETED:
							if (CanCast())
								SetState(MonsterState.Casting, Enemy);
							else
								SetState(MonsterState.Attacking, Enemy);
							break;
						case EventResult.NEED_RECALC:
							SetState(State, Enemy, true);
							break;
						case EventResult.CANCELED:
							if (m_unit.Pacified || m_unit.NoControl)
								SetState(MonsterState.Roaming, null);
							else if (CanCast())
								SetState(MonsterState.Casting, Enemy);
							else
								SetState(MonsterState.Idle, null);
							break;
						default:
							SetState(MonsterState.Idle, null);
							break;
					}
					break;
				case MonsterState.Roaming:
				case MonsterState.Idle:
				case MonsterState.Returning:
				default:
					IdleMode();
					break;
			}
		}
	}
}