using RunWoW.Objects;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public class RoamingInvulAI : Behaivor
	{
		public RoamingInvulAI(UnitBase unit)
			: base(unit)
		{
		}

		public override void Attacked(LivingObject enemy)
		{
		}

		protected override void Calculate()
		{
			if (Event == null || Event.Finished)
				SetState(MonsterState.Roaming, null);
		}
	}
}