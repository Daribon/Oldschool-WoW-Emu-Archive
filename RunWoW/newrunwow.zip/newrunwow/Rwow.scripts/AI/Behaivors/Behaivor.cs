//
using System;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public enum MonsterState
	{
		Idle,
		Roaming,
		MovingToEnemy,
		MovingToEnemyRange,
		AggrMovingToEnemy,
		AggrMovingToEnemyRange,
		Attacking,
		Looking,
		Returning,
		Casting,
		Following,
		TotemCasting
	}

	public abstract class Behaivor // : Event
	{
		protected UnitBase m_unit;
		private LivingObject m_enemy;
		public Event Event = null;

		private bool m_finished = false;

		public MonsterState State = MonsterState.Idle;

		private DateTime m_lastSearch = CustomDateTime.Now;

		protected uint m_lastSpell;

		//protected Vector m_position;

		protected int m_point = 0;
		protected int m_pdir = 1;

		//private EventFinishHandler m_onEventFinished;



		public Behaivor(UnitBase unit)
		{

			//m_onEventFinished = new EventFinishHandler(eventFinished);
			m_unit = unit;
		}

		//public Behaivor(UnitBase unit, bool slow)
		//    //: base(TimeSpan.Zero, TimeSpan.FromMilliseconds(slow ? Constants.MobileAIRecalcLong : Constants.MobileAIRecalcShort))
		//{
		//    m_unit = unit;
		//    //Priority = TimerPriority.TwoFiftyMS;
		//    //Primary = false;
		//}

		#region Properties

		public LivingObject Enemy
		{
			get { return m_enemy; }
			set { m_enemy = value; }
		}

		public bool Finished
		{
			get { return m_finished; }
		}

		#endregion

		public virtual void Attacked(LivingObject enemy)
		{
			m_unit.StartCombat(enemy);
		}

		protected abstract void Calculate();

		public EventResult ActionState()
		{
			if (Event != null && !Event.Finished)
				return EventResult.NOT_FINISHED;

			if (Event == null)
				return EventResult.ERROR;

			return Event.Result;
		}

		public EventResult AttackState()
		{
			if (m_unit.FightEvent != null && !m_unit.FightEvent.Finished)
				return EventResult.NOT_FINISHED;

			if (m_unit.FightEvent == null)
				return EventResult.ERROR;

			return m_unit.FightEvent.Result;
		}

		protected void SetState(MonsterState state, LivingObject enemy)
		{
			SetState(state, enemy, null, false);
		}

		protected void SetState(MonsterState state, LivingObject enemy, bool force)
		{
			SetState(state, enemy, null, force);
		}

		protected void SetState(MonsterState state, LivingObject enemy, DBMonsterSpell spell, bool force)
		{
			if (!Event.CheckObjects(m_unit))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}

			if (!force && (state == State) && (enemy == Enemy))
				return;

			TimeSpan eventStartDelay = TimeSpan.Zero;

			if (Event is FollowUnitEvent/* && !Event.Finished*/)
				eventStartDelay = ((FollowUnitEvent)Event).Elapsed;

			if (Event != null)
			{
				if (Event is SpellCastEvent)
					m_unit.CastEvent = null;

				//Event.OnEventFinished -= m_onEventFinished;
				Event.Finish();
				Event.Dispose();
				Event = null;
			}
			//base.TimerName = string.Format("{0}: from {1} to {2}", GetType().Name, State, state);
			State = state;

			DateTime time = CustomDateTime.Now;
			int type = 0;

			switch (state)
			{
				case MonsterState.Roaming:
					if (Constants.BurningCrusade || m_unit.Spawn == null || m_unit.Spawn.Movepoints == null || m_unit.Spawn.Movepoints.Count == 0)
					/*if (WorldMap.HasMap((int)m_unit.MapTile.Map.MapID))
					{
						Event = new RoamEvent(m_unit, m_position);
						type = 1;
					}
					else*/
					{
						type = 2;
					}
					else
					{
						Vector position = null;
						foreach (DBMovepoint mp in m_unit.Spawn.Movepoints)
							if (mp.Number == m_point)
							{
								position = mp.Position.Clone();
								type = 3;
								break;
							}

						if (type == 3)
						{
							if (m_point + m_pdir == m_unit.Spawn.Movepoints.Count || m_point + m_pdir == -1)
							{
								if (
									m_unit.Spawn.Movepoints[0].Position.DistanceAvr(
										m_unit.Spawn.Movepoints[m_unit.Spawn.Movepoints.Count - 1].Position) == 0)
								{
									if (m_point + m_pdir == m_unit.Spawn.Movepoints.Count)
										m_point = -1;
									else if (m_point + m_pdir == -1)
										m_point = m_unit.Spawn.Movepoints.Count;
								}
								else
								{
									if (m_point + m_pdir == m_unit.Spawn.Movepoints.Count)
										m_pdir = -1;
									else if (m_point + m_pdir == -1)
										m_pdir = 1;
								}
							}
							m_point += m_pdir;
							Event = new MoveToEvent(m_unit, position, false);
						}
						else
							type = 4;
					}
					break;
				case MonsterState.Casting:

					/*CustomArrayList spells = new CustomArrayList();

					for (int i = 0; i < m_unit.Spells.Length; i++)
						if (m_unit.Spells[i].AutoCast && m_unit.Spells[i].Spell.PowerCost <= m_unit.Power &&
							m_unit.Spells[i].Cooldown < CustomDateTime.Now)
							spells.Add(m_unit.Spells[i]);

					if (spells.Count == 0)
					{
						spells.Dispose();
						break;
					}

					DBMonsterSpell spell = (DBMonsterSpell)spells[Utility.Random(0, spells.Count - 1)];
					*/
					if (spell == null || spell.Spell.PowerCost > m_unit.Power || spell.Cooldown > CustomDateTime.Now)
						goto case MonsterState.Attacking;

					DBSpell Spell = spell.Spell;
					/*m_unit.Power -= Spell.PowerCost;
					m_unit.UpdateData();*/

					int cooldown = m_unit.SpellProcessor.Cooldown(Spell);

					if (cooldown <= 0)
						cooldown = 1000;

					spell.Cooldown = CustomDateTime.Now + TimeSpan.FromMilliseconds(cooldown);

					//if (spell.Offensive)
						m_unit.CastEvent = Event = new SingleTargetCast(m_unit, Spell, (ushort)0x2, enemy, false);
					/*else
						m_unit.CastEvent = Event = new SingleTargetCast(m_unit, Spell, (ushort)0x2, null, false);*/

					//spells.Dispose();
					break;

				case MonsterState.TotemCasting:

					if (m_unit.Spells == null || m_unit.Spells.Length == 0)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Totem {0} has no spells!", m_unit.Name);
						break;
					}

					DBMonsterSpell totemSpell = m_unit.Spells[0];

					if (totemSpell.Spell == null)
						Database.Instance.ResolveRelations(totemSpell);

					/*if (totemSpell.Offensive && enemy == null)
						break;*/

					DBSpell dbSpell = totemSpell.Spell;
					m_unit.Power -= dbSpell.PowerCost;
					m_unit.UpdateData();

					int totemCooldown = m_unit.SpellProcessor.Cooldown(dbSpell);

					if (totemCooldown <= 0)
						totemCooldown = 1000;
					if (totemCooldown > 0)
						totemSpell.Cooldown = CustomDateTime.Now + TimeSpan.FromMilliseconds(totemCooldown);

					//if (totemSpell.Offensive)
					m_unit.CastEvent = Event = new SingleTargetCast(m_unit, dbSpell, (ushort)0x2, enemy, false);
					/*else
						m_unit.CastEvent = Event = new SingleTargetCast(m_unit, dbSpell, (ushort) 0x2, null);*/

					break;

				case MonsterState.Following:
					Event = new FollowUnitEvent(m_unit, enemy, eventStartDelay, true, 0);
					break;

				case MonsterState.AggrMovingToEnemy:
					m_unit.StartCombat(enemy);
					Event = new FollowUnitEvent(m_unit, enemy, eventStartDelay, true, 2);
					break;

				case MonsterState.MovingToEnemy:
					Event = new FollowUnitEvent(m_unit, enemy, eventStartDelay, true, 1);
					break;

				case MonsterState.MovingToEnemyRange:
					Event = new RangeUnitEvent(m_unit, enemy, true, false, Constants.RangedMonsterRange);
					break;

				case MonsterState.AggrMovingToEnemyRange:
					Event = new RangeUnitEvent(m_unit, enemy, true, true, Constants.RangedMonsterRange);
					break;

				case MonsterState.Returning:
					if (m_unit.Spawn != null)
						Event = new MoveToEvent(m_unit, m_unit.Spawn.Position, true);
					break;

				case MonsterState.Attacking:
					/*if (m_unit.FightEvent is MobileCombatEvent && !m_unit.FightEvent.Finished)
						((MobileCombatEvent)m_unit.FightEvent).ChangeTarget(enemy);
					else
						m_unit.StartFightEvent(enemy);*/
					m_unit.StartCombat(enemy);
					break;

				case MonsterState.Looking:
					Event = new LookEvent(m_unit, enemy);
					break;

				case MonsterState.Idle:
					if (m_unit.Health < m_unit.MaxHealth)
					{
						m_unit.Health += (int)(Constants.MonsterRegen * m_unit.MaxHealth);
						if (m_unit.Health > m_unit.MaxHealth)
							m_unit.Health = m_unit.MaxHealth;
						m_unit.UpdateData();
					}
					else
						m_unit.ClearAttackers();

					if (m_unit.Power < m_unit.MaxPower)
					{
						m_unit.Power += (int)(Constants.MonsterRegen * m_unit.MaxPower);
						if (m_unit.Power > m_unit.MaxPower)
							m_unit.Power = m_unit.MaxPower;
						m_unit.UpdateData();
					}
					break;

				default:
					LogConsole.WriteLine(LogLevel.ERROR, "Creature received wrong state " + state);
					return;
			}

			double ms = (CustomDateTime.Now - time).TotalMilliseconds;
			if (ms > 300)
				Console.WriteLine("Behaivor set state {2} for unit {0} took {1} ms. type {3}", m_unit.Name, ms, State, type);

			LogConsole.WriteLine(LogLevel.ECHO, "NPC " + m_unit.Name + " is now " + State);

			Enemy = enemy;

			if (Event != null)
			{
				//Event.OnEventFinished += m_onEventFinished;
				Event.Start();
			}
		}

		#region Search
		protected virtual MonsterState DefaultSearchState
		{
			get { return MonsterState.MovingToEnemy; }
		}

		protected bool Search()
		{
			LivingObject living = m_unit.Attackers.MostAggressive;
			if (living != null)
			{
				Attacked(living);
				return true;
			}
			return Search(DefaultSearchState);
		}

		protected bool Search(MonsterState targetState)
		{
			DateTime time = CustomDateTime.Now;
			if (time - m_lastSearch < TimeSpan.FromMilliseconds(Constants.MobileSearchDelay))
				return false;

			m_lastSearch = time;

			bool foundPlayer = true;

			LivingObject enemy = SearchMobile(OBJECTTYPE.PLAYER, true);

			if (enemy == null)
			{
				enemy = SearchMobile(OBJECTTYPE.UNIT, false);
				foundPlayer = false;
			}

			if (enemy != null)
			{
				SetState(targetState, enemy, true);
				return true;
			}
			double ms = (CustomDateTime.Now - time).TotalMilliseconds;
			if (ms > 300)
				Console.WriteLine(
					"Enemy search for unit {0} took {1} ms. Enemy found: {2}, player found {3}, players in tile {4}, units in tile {5}",
					m_unit.Name, ms, enemy != null, foundPlayer, m_unit.MapTile.CountObjects(OBJECTTYPE.PLAYER),
					m_unit.MapTile.CountObjects(OBJECTTYPE.UNIT));
			return false;
		}

		protected LivingObject SearchMobile(OBJECTTYPE otype, bool players)
		{
			if (!Event.CheckObjects(m_unit))
				return null;

			foreach (MapTile mapTile in m_unit.MapTile.GetNearestTiles(m_unit.Position))
				if (mapTile != null)
				{
					if (players)
					{
						if (mapTile.Players != null)
							for (int i = 0; i < mapTile.Players.Last; i++)
							{
								PlayerObject player = mapTile.Players.InnerArray[i];
								if (player != null && !player.IsDisposed && ShouldAttackPlayer(player))
									return player;
							}
					}
					else
					{
						if (mapTile.Units != null)
							for (int i = 0; i < mapTile.Units.Last; i++)
							{
								UnitBase unit = mapTile.Units.InnerArray[i];
								if (unit != null && !unit.IsDisposed && ShouldAttackMonster(unit))
									return unit;
							}
					}
					/*ICollection collection = mapTile.GetObjects(otype);
					if (collection != null)
						foreach (LivingObject mobile in collection)
							if (mobile != null && mobile != m_unit && player ? ShouldAttackPlayer(mobile) : ShouldAttackMonster(mobile))
								return mobile;*/
				}
			return null;
		}

		protected virtual bool ShouldAttackMonster(LivingObject unit)
		{
			return false;
		}

		protected virtual bool ShouldAttackPlayer(LivingObject er)
		{
			return false;
		}

		#endregion

		public void OnTick()
		{
			if (!Check())
				return;

			try
			{
				Calculate();
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error while processing AI: " + e + ", current state: " + State);
				Finish(EventResult.ERROR);
				return;
			}
		}

		public void Finish(EventResult Result)
		{
			if (Event != null)
				Event.Finish();
			if (Event != null)
				Event.Dispose();
			Event = null;

			if (Result != EventResult.COMPLETED)
				m_unit = null;

			m_finished = true;
			//base.OnFinish();
			//Dispose();
		}

		public void Start()
		{
			m_finished = false;
		}

		protected bool Check()
		{
			if (!Event.CheckObjects(m_unit))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return false;
			}

			if (m_unit.Dead)
			{
				Finish(EventResult.OWNER_DEAD);
				return false;
			}

			if (!m_unit.MapTile.HasAjPlayers)
			{
				Finish(EventResult.COMPLETED);
				m_unit.Sleep();
				return false;
			}

			/*if (m_position == null)
				m_position = m_unit.Position.Clone();*/

			return true;
		}
	}
}