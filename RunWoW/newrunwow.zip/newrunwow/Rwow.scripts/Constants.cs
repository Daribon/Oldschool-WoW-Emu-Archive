using System;
using Encom.ConfigReader;

namespace RunWoW
{
	public sealed class Constants
	{
		public static String ConfigPath
		{
			get	{ return @".\"; }
		}
		public static String Greetings
		{
			get	{ return (String)getConfigData("greetings",typeof(String),@"Constants.xml"); }
		}
		public static String Server
		{
			get	{ return (String)getConfigData("server",typeof(String),@"Constants.xml"); }
		}
		public static String Version
		{
			get	{ return (String)getConfigData("version",typeof(String),@"Constants.xml"); }
		}
		public static String Online
		{
			get	{ return (String)getConfigData("online",typeof(String),@"Constants.xml"); }
		}
		public static String NoPassword
		{
			get	{ return (String)getConfigData("noPassword",typeof(String),@"Constants.xml"); }
		}
		public static String AdditionalInfo
		{
			get	{ return (String)getConfigData("additionalInfo",typeof(String),@"Constants.xml"); }
		}
		public static String MoreInfo
		{
			get	{ return (String)getConfigData("moreInfo",typeof(String),@"Constants.xml"); }
		}
		public static String StatusPath
		{
			get	{ return (String)getConfigData("statusPath",typeof(String),@"Constants.xml"); }
		}
		public static String MapPath
		{
			get	{ return (String)getConfigData("mapPath",typeof(String),@"Constants.xml"); }
		}
		public static String StatusFile
		{
			get	{ return (String)getConfigData("statusFile",typeof(String),@"Constants.xml"); }
		}
		public static String StatusXMLFile
		{
			get	{ return (String)getConfigData("statusXMLFile",typeof(String),@"Constants.xml"); }
		}
		public static String StatusTxtFile
		{
			get	{ return (String)getConfigData("statusTxtFile",typeof(String),@"Constants.xml"); }
		}
		public static String ThreadStatusFile
		{
			get	{ return (String)getConfigData("threadStatusFile",typeof(String),@"Constants.xml"); }
		}
		public static String WdbPath
		{
			get	{ return (String)getConfigData("wdbPath",typeof(String),@"Constants.xml"); }
		}
		public static Single MobileOffSpawnRange
		{
			get	{ return (Single)getConfigData("mobileOffSpawnRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MobileWakeRange
		{
			get	{ return (Single)getConfigData("mobileWakeRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MonsterSightRange
		{
			get	{ return (Single)getConfigData("monsterSightRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MonsterZSightRange
		{
			get { return (Single)getConfigData("monsterZSightRange", typeof(Single), @"Constants.xml"); }
		}
		public static Single GuardZSightRange
		{
			get { return (Single)getConfigData("guardZSightRange", typeof(Single), @"Constants.xml"); }
		}
		public static Single TotemSightRange
		{
			get	{ return (Single)getConfigData("totemSightRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MonsterStealthSightRange
		{
			get	{ return (Single)getConfigData("monsterStealthSightRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single GuardSightRange
		{
			get	{ return (Single)getConfigData("guardSightRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single PetMaxRange
		{
			get	{ return (Single)getConfigData("petMaxRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single VendorSightRange
		{
			get	{ return (Single)getConfigData("vendorSightRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single VendorSightMinRange
		{
			get	{ return (Single)getConfigData("vendorSightMinRange",typeof(Single),@"Constants.xml"); }
		}
		public static Int32 MobileStopFollowTime
		{
			get { return (Int32)getConfigData("mobileStopFollowTime", typeof(Int32), @"Constants.xml"); }
		}
		public static Int32 MobileStopFollowTimeAgrr
		{
			get { return (Int32)getConfigData("mobileStopFollowTimeAgrr", typeof(Int32), @"Constants.xml"); }
		}
		public static Single MobileMaxOffspawnRange
		{
			get	{ return (Single)getConfigData("mobileMaxOffspawnRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single CraftRange
		{
			get	{ return (Single)getConfigData("craftRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MonsterMoveStepRange
		{
			get	{ return (Single)getConfigData("monsterMoveStepRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single RangedMonsterRange
		{
			get	{ return (Single)getConfigData("rangedMonsterRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single CorpseRange
		{
			get	{ return (Single)getConfigData("corpseRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MobileRoamMinRange
		{
			get	{ return (Single)getConfigData("mobileRoamMinRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MobileRoamMaxRange
		{
			get	{ return (Single)getConfigData("mobileRoamMaxRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single FearRunMinRange
		{
			get	{ return (Single)getConfigData("fearRunMinRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single FearRunMaxRange
		{
			get	{ return (Single)getConfigData("fearRunMaxRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single ExpMaximumRange
		{
			get	{ return (Single)getConfigData("expMaximumRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single FallDamageMinHeightConst
		{
			get	{ return (Single)getConfigData("fallDamageMinHeightConst",typeof(Single),@"Constants.xml"); }
		}
		public static Single MinSpawnRange
		{
			get	{ return (Single)getConfigData("minSpawnRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MinGOSpawnRange
		{
			get	{ return (Single)getConfigData("minGOSpawnRange",typeof(Single),@"Constants.xml"); }
		}
		public static Single MobileZShift
		{
			get	{ return (Single)getConfigData("mobileZShift",typeof(Single),@"Constants.xml"); }
		}
		public static Int32 MobileRandomWalkDelay
		{
			get	{ return (Int32)getConfigData("mobileRandomWalkDelay",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MobileRoamDelay
		{
			get	{ return (Int32)getConfigData("mobileRoamDelay",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MobileLookDelay
		{
			get	{ return (Int32)getConfigData("mobileLookDelay",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MobileSearchDelay
		{
			get	{ return (Int32)getConfigData("mobileSearchDelay",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MobileAIRecalcLong
		{
			get	{ return (Int32)getConfigData("mobileAIRecalcLong",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MonsterMoveUpdateTime
		{
			get	{ return (Int32)getConfigData("monsterMoveUpdateTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 CombatUpdateTime
		{
			get	{ return (Int32)getConfigData("combatUpdateTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 ChatUpdateTime
		{
			get	{ return (Int32)getConfigData("chatUpdateTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MapTileUpdateTime
		{
			get	{ return (Int32)getConfigData("mapTileUpdateTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 AuraUpdateInterval
		{
			get	{ return (Int32)getConfigData("auraUpdateInterval",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 PlayerSaveInterval
		{
			get	{ return (Int32)getConfigData("playerSaveInterval",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 FishingUpdateTime
		{
			get	{ return (Int32)getConfigData("fishingUpdateTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 FishingStart
		{
			get	{ return (Int32)getConfigData("fishingStart",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 FishingDelay
		{
			get	{ return (Int32)getConfigData("fishingDelay",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 FallDamageTime
		{
			get	{ return (Int32)getConfigData("fallDamageTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MillisecondsPerRPoint
		{
			get	{ return (Int32)getConfigData("millisecondsPerRPoint",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 UndeadBreathTime
		{
			get	{ return (Int32)getConfigData("undeadBreathTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 UnderwaterBreathTime
		{
			get	{ return (Int32)getConfigData("underwaterBreathTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 SpellProcDelay
		{
			get	{ return (Int32)getConfigData("spellProcDelay",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MobileCorpseDespawnTime
		{
			get	{ return (Int32)getConfigData("mobileCorpseDespawnTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 PlayerCorpseDespawnTime
		{
			get	{ return (Int32)getConfigData("playerCorpseDespawnTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MobileRespawnTime
		{
			get	{ return (Int32)getConfigData("mobileRespawnTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 GoDespawnTime
		{
			get	{ return (Int32)getConfigData("goDespawnTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 GoRespawnTime
		{
			get	{ return (Int32)getConfigData("goRespawnTime",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 GoRespawnTimeLong
		{
			get	{ return (Int32)getConfigData("goRespawnTimeLong",typeof(Int32),@"Constants.xml"); }
		}
		public static Single MonsterRegen
		{
			get	{ return (Single)getConfigData("monsterRegen",typeof(Single),@"Constants.xml"); }
		}
		public static Single PetRegen
		{
			get	{ return (Single)getConfigData("petRegen",typeof(Single),@"Constants.xml"); }
		}
		public static Single FallDamageConst
		{
			get	{ return (Single)getConfigData("fallDamageConst",typeof(Single),@"Constants.xml"); }
		}
		public static Single UnderwaterBreathDamage
		{
			get	{ return (Single)getConfigData("underwaterBreathDamage",typeof(Single),@"Constants.xml"); }
		}
		public static Boolean BurningCrusade
		{
			get { return (Boolean)getConfigData("BurningCrusade", typeof(Boolean), @"Constants.xml"); }
		}
		public static Int32 MaximumRPoints
		{
			get	{ return (Int32)getConfigData("maximumRPoints",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MaximumObjectsPerPacket
		{
			get	{ return (Int32)getConfigData("maximumObjectsPerPacket",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MinAccessLevel
		{
			get	{ return (Int32)getConfigData("minAccessLevel",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MaximumLoot
		{
			get	{ return (Int32)getConfigData("maximumLoot",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MaximumLevel
		{
			get { return (Int32)getConfigData("maximumLevel", typeof(Int32), @"Constants.xml"); }
		}
		public static Int32 MaxVendorItems
		{
			get	{ return (Int32)getConfigData("maxVendorItems",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 PricePerSpell
		{
			get	{ return (Int32)getConfigData("pricePerSpell",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 DebuffLevelShift
		{
			get	{ return (Int32)getConfigData("debuffLevelShift",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MonsterFriendlyLevel
		{
			get	{ return (Int32)getConfigData("monsterFriendlyLevel",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 MaximumOnline
		{
			get	{ return (Int32)getConfigData("maximumOnline",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 NoQueueGuild1
		{
			get	{ return (Int32)getConfigData("noQueueGuild1",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 NoQueueGuild2
		{
			get	{ return (Int32)getConfigData("noQueueGuild2",typeof(Int32),@"Constants.xml"); }
		}
		public static Int32 NoQueueGuild3
		{
			get	{ return (Int32)getConfigData("noQueueGuild3",typeof(Int32),@"Constants.xml"); }
		}
		public static String NoQueueIP
		{
			get { return (String)getConfigData("noQueueIP", typeof(String), @"Constants.xml"); }
		}
		public static Boolean DruidQuestFix
		{
			get { return (Boolean)getConfigData("druidQuestFix", typeof(Boolean), @"Constants.xml"); }
		}
		public static Boolean ExternalIndexes
		{
			get { return (Boolean)getConfigData("externalIndexes", typeof(Boolean), @"Constants.xml"); }
		}
		public static Boolean NoInnerCache
		{
			get { return (Boolean)getConfigData("noInnerCache", typeof(Boolean), @"Constants.xml"); }
		}
		public static Boolean ForceFlushUpdates
		{
			get { return (Boolean)getConfigData("forceFlushUpdates", typeof(Boolean), @"Constants.xml"); }
		}
		public static Boolean AutoFixTrainers
		{
			get { return (Boolean)getConfigData("autoFixTrainers", typeof(Boolean), @"Constants.xml"); }
		}
		public static Boolean UseRepeatingUpdater
		{
			get { return (Boolean)getConfigData("useRepeatingUpdater", typeof(Boolean), @"Constants.xml"); }
		}
		public static Int32 LootLevelFilter
		{
			get { return (Int32)getConfigData("lootLevelFilter", typeof(Int32), @"Constants.xml"); }
		}
		public static Int32 WorldLootGroupID
		{
			get { return (Int32)getConfigData("worldLootGroupID", typeof(Int32), @"Constants.xml"); }
		}
		public static Single WorldLootDivider
		{
			get { return (Single)getConfigData("worldLootDivider", typeof(Single), @"Constants.xml"); }
		}
		public static String ChatServer
		{
			get	{ return (String)getConfigData("chatServer",typeof(String),@"Constants.xml"); }
		}
		public static String ChatPort
		{
			get	{ return (String)getConfigData("chatPort",typeof(String),@"Constants.xml"); }
		}
		public static String MainConnectionString
		{
			get	{ return (String)getConfigData("mainConnectionString",typeof(String),@"dbconfig.xml"); }
		}
		public static Int32 MainConnectionType
		{
			get	{ return (Int32)getConfigData("mainConnectionType",typeof(Int32),@"dbconfig.xml"); }
		}
		public static String DynamicConnectionString
		{
			get	{ return (String)getConfigData("dynamicConnectionString",typeof(String),@"dbconfig.xml"); }
		}
		public static Int32 DynamicConnectionType
		{
			get	{ return (Int32)getConfigData("dynamicConnectionType",typeof(Int32),@"dbconfig.xml"); }
		}


	#region Config data getters
	public static String MainConfig
	{
	get	{ return @"Constants.xml"; }
	}
	private static Object getConfigData(String keyName, Type type, String file)
	{
		return ConfigReader.SafeConfigValue(ConfigPath + file, "config", keyName, type);
	}
	#endregion
	}
}
