using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Priest : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.PRIEST; }
		}

		public Priest(int BHealth, int BPower)
			: base(0.3f, 0.3f, 0.4f, 1.3f, 1.39f, POWERTYPE.MANA, BHealth, BPower, 2000, 2000, 2.0f, 4.0f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(585, 4); // Smite
			AddSpell(2050, 3); // Lesser Heal
			AddSpell(SPELLSKILL.SHOOT, 2); // Shoot

			AddSkill(0, 613, 1, 1); // Discipline
			AddSkill(0, 56, 1, 1); // Holy
			AddSkill(0, 78, 1, 1); // Shadow Magic
			AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
			AddSkill(SPELLSKILL.WAND, SKILL.WAND, 1, 300); // Wands
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Str - 10;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 22 ? 15 : level - 6);
		}

		public override short PowerGain(int level)
		{
			return (short) (level <= 33 ? level + 22 : 54);
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return 12.5f + Spr/4f;
		}
	}
}