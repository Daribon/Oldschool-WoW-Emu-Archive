using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Rogue : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.ROGUE; }
		}

		public Rogue(int BHealth /*,int BPower*/)
			: base(0.83f, 1.5f, 0.78f, 0.22f, 0.42f, POWERTYPE.ENERGY, BHealth, /*BPower*/100, 2900, 2000, 6.0f, 7.0f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(SPELLSKILL.PARRY); // Parry
			AddSpell(SPELLSKILL.THROW, 2); // Throw

			AddSpell(1752, 3); // Sinister Strike
			AddSpell(2098, 4); // Eviscerate

			AddSkill(0, 253, 1, 1); // Assasination
			AddSkill(0, 83, 1, 1); // Combat
			AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			AddSkill(SPELLSKILL.THROWN, SKILL.THROWN, 1, 300); // Thrown
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
			AddSkill(SPELLSKILL.LEATHER, SKILL.LEATHER, 1, 1); // Leather
			AddSpell(674); // Dual Weild 
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Level*2 + Str + Ag - 20;
		}

		public override int CalculateRangedAP(int Level, int Str, int Ag)
		{
			return Level + Ag*2 - 20;
		}

		public override float CalculateDodge(int Level, int Agi)
		{
			return (float) Agi/((float) Level*0.226f + 0.838f); // /14.5 for 60
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return 20f;
		}

		public override short MaxPower(short power)
		{
			return 100;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 15 ? 17 : level + 2);
		}

		public override short PowerGain(int level)
		{
			return 0;
		}
	}
}