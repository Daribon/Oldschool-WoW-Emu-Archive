//
using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Warrior : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.WARRIOR; }
		}

		public Warrior(int BHealth /*,int BPower*/)
			: base(1.2f, 0.81f, 1.1f, 0.2f, 0.3f, POWERTYPE.RAGE, BHealth, /*BPower*/1000, 2000, 2000, 5.0f, 7.0f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(2457); // Battle stance
			AddSpell(78, 3); // Heroic Strike
			AddSpell(SPELLSKILL.BLOCK); // Block

			AddSkill(0, 26, 1, 1); // Arms
			AddSkill(0, 257, 1, 1); // Protection
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth

			AddSkill(SPELLSKILL.LEATHER, SKILL.LEATHER, 1, 1); // Leather
			AddSkill(SPELLSKILL.MAIL, SKILL.MAIL, 1, 1); // Mail
			AddSkill(SPELLSKILL.PLATEMAIL, SKILL.PLATEMAIL, 1, 1); // PlateMail
			AddSkill(SPELLSKILL.SHIELD, SKILL.SHIELD, 1, 1); // Shield  
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Level*3 + Str*2 - 20;
		}

		public override int CalculateRangedAP(int Level, int Str, int Ag)
		{
			return Level + Ag*2 - 20;
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return -20f;
		}

		public override short MaxPower(short power)
		{
			return 1000;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 14 ? 19 : level + 10);
		}

		public override short PowerGain(int level)
		{
			return 0;
		}
	}
}