using System;
using System.Collections;
using RunWoW.Objects;

namespace RunWoW.Misc
{
	public class XPCalculator
	{
		private static object[] m_zeroDifference = new object[]
			{
				new int[] {5, 1, 7},
				new int[] {6, 8, 9},
				new int[] {7, 10, 11},
				new int[] {8, 12, 15},
				new int[] {9, 16, 19},
				new int[] {11, 20, 29},
				new int[] {12, 30, 39},
				new int[] {13, 40, 44},
				new int[] {14, 45, 49},
				new int[] {15, 50, 54},
				new int[] {16, 55, 59},
				new int[] {17, 60, 64},
				new int[] {18, 65, 69},
				new int[] {19, 70, 70}
			};

		private static float[] m_groupXpModifier = new float[] {0, 1, 1, 1.166f, 1.3f, 1.4f};

		private static int basicXP(LivingObject killer, LivingObject victim)
		{
			return basicXP(killer, victim, true);
		}


		/**  if trimGray 'false' then  do not trim XP to 0 for gray mobs
		 **/

		private static int basicXP(LivingObject killer, LivingObject victim, bool trimGray)
		{
			int xp = 0;
			int chrLevel = killer.Level;
			int mobLevel = victim.Level;

			// Set cap level 
			mobLevel = mobLevel > (chrLevel + 5) ? chrLevel + 5 : mobLevel;

			//grayCap 
			if (mobLevel <= GrayLevel(chrLevel) && !trimGray)
				chrLevel = !trimGray ? mobLevel + 5 : chrLevel; // if higher player too high for mob - use minimal  gray level

			if (mobLevel >= chrLevel)
				xp = (int)((chrLevel * 5 + 45) * (1 + 0.05 * (mobLevel - chrLevel)));
			else if (!trimGray || mobLevel > GrayLevel(chrLevel))
			{
				int zd = zeroDifference(killer.Level);
				xp = (int)((chrLevel * 5 + 45) * (1 - (chrLevel - mobLevel) / (float)zd) + .5);
			}


			UnitBase unit = victim as UnitBase;

			//  twice XP for elite mob
			//  "elite" gain the 2x bonus as described. Mobs classified as "normal" and "rare" 
			//  do not. The other two classes are unknown at this time. 
			//  (elites in instances give 2.5 * XP when solo-ed; untested for normal mobs in instances)
			if (unit != null && unit.Spawn != null && (unit.Creature.Elite == 2 || unit.Creature.Elite == 1))
			{
				if (unit.Spawn.WorldMapID > 1)
					xp = (int)(2.5f * xp);
				else
					xp *= 2;
			}

			return xp;
		}

		private static int GroupXP(PlayerObject member, LivingObject victim)
		{
			int xp = 0;
			PlayerObject pHigher = null;
			int levelSumm = 0;

			ICollection members = member.Group.LivingMembers;
			foreach (PlayerObject player in members)
			{
				pHigher = (pHigher == null || player.Level > pHigher.Level) ? player : pHigher;
				levelSumm += player.Level;
			}

			if (pHigher != null)
			{
				int maxXp = basicXP(pHigher, victim, false);
				float mod = members.Count <= 5 ? m_groupXpModifier[members.Count] : 1.5f;
				xp = (int)(maxXp * (member.Level / (float)levelSumm) * mod);
				if (GrayLevel(member.Level) > victim.Level)
					xp = 0;
			}

			//pHigher = null;

			return xp;
		}


		/** Returns full XP for killing mob **/

		public static int CalcXP(LivingObject killer, LivingObject victim)
		{
			int xp;
			if (killer is PlayerObject && ((PlayerObject)killer).Group != null)
				xp = GroupXP((PlayerObject)killer, victim);
			else
				xp = basicXP(killer, victim);

			//  Rest modifier here
			//  ................

			return xp;
		}

		/** For a given character level, the amount of XP given by lower-level mobs 
		 *	is a linear function of the Mob Level. The amount of experience reaches zero 
		 *  when the difference between the Char Level and Mob Level reaches a certain point. 
		 *  This is called the Zero Difference value, and is given by:		 
		 **/

		private static int zeroDifference(int level)
		{
			foreach (int[] range in m_zeroDifference)
			{
				if (level >= range[1] && level <= range[2])
					return range[0];
			}
			return 1; // if shit happens we do not need divide by zero :)
		}


		/** Determine "gray" mob level for given player level.
		 * */

		public static int GrayLevel(int level)
		{
			if (level <= 5)
				return 0;
			else if (level <= 39)
				return (int) (level - 5 - Math.Floor(level/10f));
			else
				return (int) (level - 1 - Math.Floor(level/5f));
		}
	}
}