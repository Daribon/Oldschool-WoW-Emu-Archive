using System;
using System.Collections;
using System.IO;
using System.Text;
using RunServer.Common;

namespace RunWoW.ServerScripts.Misc
{
	public class CustomLog
	{
		private static Hashtable m_logs = Hashtable.Synchronized(new Hashtable());

		private static StreamWriter getLog(string name, string path)
		{
			string logPath = Path.Combine(path, name);

			if (m_logs[logPath] != null)
				return m_logs[logPath] as StreamWriter;

			if (!Directory.Exists(logPath))
				Directory.CreateDirectory(logPath);

			StreamWriter result = new StreamWriter(Path.Combine(logPath, CustomDateTime.Now.ToShortDateString()), true, Encoding.GetEncoding(1251));
			result.AutoFlush = true;
			result.WriteLine("Log started on {0} for {1}\n", CustomDateTime.Now, name);
			
			m_logs[logPath] = result;
			return result;
		}

		public static void WriteLine(string text, string name, string path)
		{
			StreamWriter writer = getLog(name, path);
			writer.WriteLine("[{0}] {1}", CustomDateTime.Now, text);
		}

		public static void DoFinalize()
		{
			IEnumerator e = m_logs.Values.GetEnumerator();
			while (e.MoveNext())
			{
				StreamWriter m_Output = e.Current as StreamWriter;
				if (m_Output != null)
					m_Output.Close();
			}
		}
	}
}
