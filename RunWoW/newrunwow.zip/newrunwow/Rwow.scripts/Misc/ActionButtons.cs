//
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.Misc
{
	[PacketHandlerClass]
	public class ActionButtons
	{
		private DBCharacter owner;

		public ActionButtons(DBCharacter character)
		{
			owner = character;
		}

		public void SetStartActions()
		{
			if (owner.Abilities != null && (owner.Actions == null || owner.Actions.Count == 0))
				foreach (DBAbility abil in owner.Abilities)
					if (abil != null && abil.Slot != 0xffff)
						DBUtility.ActionButtonOfChar(owner, (byte) (abil.Slot - 1), (ushort) abil.SpellID, 0, 0);
		}

		public ShortPacket InitialActions()
		{
			ShortPacket result = new ShortPacket(SMSG.ACTION_BUTTONS);
			if (owner.Actions == null)
				Database.Instance.ResolveRelations(owner, typeof (DBActionButton));
			if (owner.Actions.Count == 0)
				result.Write(new byte[480]);
			else
			{
				DBActionButton[] sorted = new DBActionButton[120];
				foreach (DBActionButton butt in owner.Actions)
					sorted[butt.Slot] = butt;

				for (int i = 0; i < 120; i++)
					if (sorted[i] != null)
					{
						result.Write((ushort) sorted[i].Action);
						result.Write((byte) sorted[i].Misc);
						result.Write((byte) sorted[i].Type);
					}
					else
						result.Write(0);
			}
			return result;
		}

		[PacketHandler(CMSG.SET_ACTION_BUTTON)]
		public static void OnSetAction(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			byte butt = data.ReadByte();
			ushort action = data.ReadUInt16();
			byte misc = data.ReadByte();
			byte type = data.ReadByte();

			if (type == 64 || type == 0)
				DBUtility.ActionButtonOfChar(Client.Character, butt, action, type, misc);
		}
	}
}