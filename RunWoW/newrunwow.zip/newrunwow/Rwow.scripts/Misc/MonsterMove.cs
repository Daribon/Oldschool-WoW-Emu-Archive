//
using System;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.GamePackets;
using RunWoW.Objects;

namespace RunWoW.Misc
{
	public class MonsterMove
	{
		public static void WalkToVector(LivingObject living, Vector point, int time, bool run, bool forced)
		{
			WalkToVector(living, new Vector[] {point}, time, run, forced);
		}

		public static void WalkToVector(LivingObject living, ICollection<Vector> points, int time, bool run, bool forced)
		{
			ShortPacket pkg = new ShortPacket(SMSG.MONSTER_MOVE);
			pkg.WriteGuid(living.GUID);
			pkg.WriteVector(living.Position);
			int timePos = pkg.BaseStream.Position;
			pkg.Write(Utility.PreciseTimestamp());
			pkg.Write((byte) 0);	//type
			pkg.Write(run ? 0x100 : 0x000);
			pkg.Write(time);
			pkg.Write(points.Count);
			foreach (Vector point in points)
				pkg.WriteVector(point);

			living.MapTile.SendSurroundingTimed(pkg, living, null, timePos);
		}

		public static void FixPosition(LivingObject unit)
		{
			FixPosition(unit, 0);
		}

		public static void FixPosition(LivingObject unit, int delay)
		{
			if (unit == null || unit.MapTile == null)
				return;
			int timePos;
			ShortPacket pkg = Movement.MakeMovement(SMSG.MOVE_TELEPORT, unit, 0, out timePos);
			/*ShortPacket pkg = new ShortPacket(SMSG.MOVE_TELEPORT);
			pkg.WriteGuid(living.GUID);
			pkg.Write(living.MovementFlags);
			int timePos = pkg.BaseStream.Position;
			pkg.Write(Utility.PreciseTimestamp() + delay);
			pkg.WriteVector(living.Position);
			pkg.Write(living.Facing);*/
			unit.MapTile.SendSurroundingTimed(pkg, unit, null, timePos, delay);
		}

		public static int MoveTo(LivingObject living, ICollection<Vector> v, bool run, float facing, bool forced)
		{
			int time = GetTime(living.Position, v, (run ? living.RunningSpeed : living.WalkSpeed));
			WalkToVector(living, v, time, run, forced);
			
			return time;
		}

		public static int MoveTo(LivingObject living, Vector point, bool run, bool forced, bool assign)
		{
			int time = GetTime(living, point, run);
			WalkToVector(living, point, time, run, forced);
			if (assign)
			{
				living.Facing = living.Position.Angle(point);
				living.Position = point;
				living.MapTile.Map.Move(living);
			}
			return time;
		}

		public static void MoveTo(LivingObject living, Vector point, bool run, int time, bool forced)
		{
			living.Facing = living.Position.Angle(point);
			living.Position = point;
			WalkToVector(living, point, time, run, forced);
			living.MapTile.Map.Move(living);
		}

		public static void MoveTo(LivingObject living, Vector point, bool run, int time, float facing, bool forced)
		{
			WalkToVector(living, point, time, run, forced);
			living.Facing = facing;
			living.Position = point;
			living.MapTile.Map.Move(living);
		}

		public static void MoveTo(LivingObject living, Vector point, bool run, float facing, bool forced)
		{
			int time = GetTime(living, point, run);
			living.Facing = facing; // wrong
			WalkToVector(living, point, time, run, forced);
			living.MapTile.Map.Move(living);
		}

		public static int GetTime(LivingObject living, Vector point, bool run)
		{
			float distance = living.Position.Distance(point);
			return (int)(distance * 1100f / (run ? living.RunningSpeed : living.WalkSpeed)); // 110% for lag compensation
		}

		public static int GetTime(LivingObject living, float distance, bool run)
		{
			return (int)(distance * 1100f / (run ? living.RunningSpeed : living.WalkSpeed)); // 110% for lag compensation
		}

		public static int GetTime(Vector from, ICollection<Vector> points, float speed)
		{
			float distance = 0;
			foreach(Vector point in points)
			{
				distance += from.Distance(point);
				from = point;
			}
			return (int) (distance*1100f/speed); // 110% for lag compensation
		}

		public static int GetSteps(LivingObject living, Vector point, float step)
		{
			return (int) Math.Round(living.Position.Distance(point)/step);
		}

		public static void RotateTo(LivingObject living, Vector point, bool forced)
		{
			float angle = living.Position.RAngle(point);
			if (living.Facing == angle)
				return;
			living.Facing = angle;
			FixPosition(living);
		}
	}
}