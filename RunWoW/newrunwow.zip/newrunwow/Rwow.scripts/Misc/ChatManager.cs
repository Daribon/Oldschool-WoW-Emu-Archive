//!!! MAY BE NEED TO BE REWRITTEN !!!
using System;
using System.Collections;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.ServerScripts.Misc;
using RunWoW.World;

namespace RunWoW.Misc
{
	public delegate bool ChatCommand(ClientBase client, string input);

	[PacketHandlerClass()]
	public class ChatManager
	{
		private static string GuildLogPath = "GuildChatLogs";

		private class chatCommand
		{
			public string cmd;
			public string usage;
			public ChatCommand func;
		}

		private static Hashtable cmds = new Hashtable();

		public static void RegisterChatCommand(string cmd, string usage, ChatCommand func)
		{
			chatCommand chatcmd = new chatCommand();
			chatcmd.cmd = cmd.ToLower();
			chatcmd.usage = usage;
			chatcmd.func = func;
			cmds[chatcmd.cmd] = chatcmd;
		}

		internal static void ClearChatCmds()
		{
			cmds.Clear();
		}

		private static bool OnChatCommand(ClientBase client, string msg)
		{
			string[] split = msg.Split(' ');
			string cmd = split[0].ToLower();
			chatCommand chatcmd = (chatCommand) cmds[cmd];
			if (chatcmd == null)
				return false;
			if (chatcmd.func(client, msg) == false)
			{
				Chat.System(client, chatcmd.usage);
			}
			return true;
		}

		[PacketHandler(CMSG.MESSAGECHAT, ExecutionPriority.Pool)]
		public static void OnMessageChat(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			//Hexdump.ToConsole(data);
			CHATMESSAGETYPE type = (CHATMESSAGETYPE) data.ReadInt32();

			uint language = data.ReadUInt32();
			
			SKILL skill = SKILL.NONE;

			if (Client.Player.GM)
				language = 0;
			else
			switch(language)
			{
				case 1:
					skill = SKILL.LANGUAGE_ORCISH;
					break;
				case 2:
					skill = SKILL.LANGUAGE_DARNASSIAN;
					break;
				case 3:
					skill = SKILL.LANGUAGE_TAURAHE;
					break;
				case 6:
					skill = SKILL.LANGUAGE_DWARVEN;
					break;
				case 7:
					skill = SKILL.LANGUAGE_COMMON;
					break;
				case 8:
					skill = SKILL.LANGUAGE_DEMON;
					break;
				case 9:
					skill = SKILL.LANGUAGE_TITAN;
					break;
				case 10:
					skill = SKILL.LANGUAGE_THALASSIAN;
					break;
				case 11:
					skill = SKILL.LANGUAGE_DRACONIC;
					break;
				//case 12:
				//    skill = SKILL.LANGUAGE_KALIMAG;
				//    break;
				case 13:
					skill = SKILL.LANGUAGE_GNOMISH;
					break;
				case 14:
					skill = SKILL.LANGUAGE_TROLL;
					break;
				case 33:
					skill = SKILL.LANGUAGE_GUTTERSPEAK;
					break;
				case 35:
					skill = SKILL.LANGUAGE_DRAENEI;
					break;
				case 0:
				default:
					skill = SKILL.NONE;
					break;
			}

			if (skill != SKILL.NONE)
				if (Client.Player.Skills[skill] == null)
				{
					Console.WriteLine("Cheater {0} is trying to speak unknown language {1}", Client.Player.Name, language);
					if (Client.Player.AccessLvl <= ACCESSLEVEL.FEATURED)
						return;
				}
			
			string target;

			switch (type)
			{
				case CHATMESSAGETYPE.SAY:
				case CHATMESSAGETYPE.YELL:
				case CHATMESSAGETYPE.RAID:
				case CHATMESSAGETYPE.GUILD:
				case CHATMESSAGETYPE.OFFICER:
				case CHATMESSAGETYPE.PARTY:
					target = string.Empty;
					break;
				default:
					target = data.ReadString((int) (data.BaseStream.Length - data.BaseStream.Position));
					break;
			}
			string msg = data.ReadString((int) (data.BaseStream.Length - data.BaseStream.Position));
			LogConsole.WriteLine(LogLevel.ECHO, "Chat: " + msg);

			if (msg.StartsWith("!") || msg.StartsWith("%") || msg.StartsWith("/") || msg.StartsWith("."))
			{
				OnChatCommand(client, msg.Substring(1));
				return;
			}
			switch (type)
			{
				case CHATMESSAGETYPE.EMOTE:
				case CHATMESSAGETYPE.SAY:
					{
						Chat.AreaMessage(type, Client.Player, msg, language, 25.0f);
						break;
					}
				case CHATMESSAGETYPE.PARTY:
				case CHATMESSAGETYPE.RAID:
					{
						Chat.PartyMessage(Client.Player, msg, language, type == CHATMESSAGETYPE.RAID);
						break;
					}
				case CHATMESSAGETYPE.GUILD:
				case CHATMESSAGETYPE.OFFICER:
					{
						if (Client.Player.Character.Guild != null)
							CustomLog.WriteLine(string.Format("[{0}]: {1}", Client.Player.Name, msg), Client.Player.Character.Guild.Name,
							                    GuildLogPath);
						Chat.GuildMessage(Client.Player, msg, language, type == CHATMESSAGETYPE.OFFICER);
						break;
					}
				case CHATMESSAGETYPE.YELL:
					{
						Chat.AreaMessage(type, Client.Player, msg, language, 50.0f);
						break;
					}
				case CHATMESSAGETYPE.WHISPER:
					{
						/*ClientBase targetClient = ClientManager.GetClient(target);
						if (targetClient == null || targetClient.BackLink == null)
						{
							Chat.System(client, "That player is not online.");
							return;
						}*/
					
						PlayerObject targetPlayer = ClientManager.GetPlayer(target);
						if (targetPlayer == null || targetPlayer.IsDisposed)
						{
							Chat.System(client, "That player is not online.");
							return;
						}

						if (AllowWisper(Client.Player, targetPlayer))
							Chat.Whisper(Client.Player, targetPlayer, msg, language);
						else
							Chat.Ignored(Client.Player, targetPlayer);
						/*if (
							(targetPlayer.GuildID != 0 && targetPlayer.GuildID != Client.Player.GuildID) ||
							(targetPlayer.Group != null && targetPlayer.Group != Client.Player.Group) ||
							)*/
						
						break;
					}
				case CHATMESSAGETYPE.CHANNEL:
#if USE_IRC
	if (Client.Chat != null)
					{
						Client.Chat.Message(msg, target);
					}
#endif
					Chat.ChatMessage(client, Client.Player, msg, target);
					Chat.System(client, "In-game IRC chat is now disabled");
					break;
				default:
					//Chat.System(client, "Received " + type + ": " + msg);
					Chat.Message(type, Client.Player, null, msg, language, 25.0f, null);
					break;
			}
			return;
		}

		private static bool AllowWisper(PlayerObject player, PlayerObject targetPlayer)
		{
			if (player.GM)
				return true;
			if (player.GuildID != 0 && player.GuildID == targetPlayer.GuildID)
				return true;
			if (player.SameGroup(targetPlayer))
				return true;

			if (targetPlayer.AutoIgnore && targetPlayer.Character.Friends != null)
				foreach(DBFriendList friend in targetPlayer.Character.Friends)
					if (friend.Friend_ID == player.CharacterID)
						return true;

			return !targetPlayer.AutoIgnore;
		}


		[PacketHandler(CMSG.JOIN_CHANNEL)]
		public static void OnJoinChannel(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;
			string channel = data.ReadString(256);
#if USE_IRC
	if (Client.Chat != null)
				Client.Chat.JoinChannel(channel);
#endif
			ShortPacket pkg = new ShortPacket(SMSG.CHANNEL_NOTIFY);
			pkg.Write((byte) 2); // enter
			pkg.Write(channel);
			pkg.Write(1); // number
			client.Send(pkg);
			if (channel.IndexOf("LocalDefense") != -1)
				Client.LocalDefenseChannel = channel;
			//Chat.System(client,"You have entered "+channel+" channel");
		}

		[PacketHandler(CMSG.LEAVE_CHANNEL)]
		public static void OnLeaveChannel(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;
			string channel = data.ReadString(256);
#if USE_IRC
	if (Client.Chat != null)
				Client.Chat.PartChannel(channel);
#endif
			ShortPacket pkg = new ShortPacket(SMSG.CHANNEL_NOTIFY);
			pkg.Write((byte) 3); // leave
			pkg.Write(channel);
			client.Send(pkg);
		}
	}

	public class Chat
	{
		public static void Message(CHATMESSAGETYPE type, object from, PlayerObject to, string msg, uint language, float radius,
		                           string channel)
		{
			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte) type);
			pkg.Write(language);

			if (channel != null && channel != string.Empty)
				pkg.Write(channel);

			if (from == null)
				pkg.Write((ulong) 0);
			else if (from is PlayerObject)
				pkg.Write(((PlayerObject) from).GUID);
			else if (from is string)
				pkg.WriteString((string) from);
			else if (from is long)
				pkg.Write((long) from);

			if (to != null && channel != null)
				pkg.Write(to.GUID);
			else if (channel == string.Empty)
				pkg.Write((ulong) 0);

			pkg.WriteString(msg);
			pkg.Write((byte) 0);

			//Hexdump.ToConsole("Sending chat packet ", pkg.GetBuffer(), (int) pkg.Length);

			if (to != null)
				to.BackLink.Client.Send(pkg);
			else
				((ObjectBase) from).MapTile.SendSurrounding(pkg, (ObjectBase) from);
/*			if (radius!=0f&&from!=null&&from is ObjectBase)*/
/*			else
				Multicast.Broadcast(pkg);*/
		}

		public static void ChatMessage(ClientBase to, ObjectBase from, string msg, string channel)
		{
			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte) CHATMESSAGETYPE.CHANNEL);
			pkg.Write(0); // language
			pkg.Write(channel);
			pkg.Write(0); //?
			pkg.Write(from == null ? (long) 0 : from.GUID);
			pkg.WriteString(msg);
			pkg.Write((byte) 0);
			to.Send(pkg);
		}

		public static void TargetMessage(CHATMESSAGETYPE type, ulong GUID, ClientBase to, string msg, uint language)
		{
			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte) type);
			pkg.Write(language);
			pkg.Write(GUID);
			pkg.WriteString(msg);
			pkg.Write((byte) 0);
			to.Send(pkg);
		}

		public static void MonsterMessage(CHATMESSAGETYPE type, string Name, ClientBase to, string msg)
		{
			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte) type);
			pkg.Write(0); // language
			pkg.WriteString(Name);
			pkg.Write((long) 0);
			pkg.WriteString(msg);
			pkg.Write((byte) 0);
			to.Send(pkg);
		}

		public static void AreaMessage(CHATMESSAGETYPE type, ObjectBase from, string msg, uint language, float radius)
		{
			float radiussqrd = radius*radius;

			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte) type);
			pkg.Write(language);
			pkg.Write(from.GUID);
			pkg.Write(from.GUID);
			pkg.WriteString(msg);
			pkg.Write((byte) 0);


			pkg.Aquire();
			foreach (MapTile mapTile in from.MapTile.GetNearestTiles(from.Position))
				if (mapTile != null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.PLAYER);
					if (collection != null)
						foreach (PlayerObject playerObject in collection)
							if (playerObject != null && !playerObject.IsDisposed &&
							    playerObject.Position.DistanceFlatSqrd(from.Position) <= radiussqrd)
								playerObject.BackLink.Client.Send(pkg);
				}
			pkg.Release();
		}

		public static void Whisper(PlayerObject from, PlayerObject to, string msg, uint language)
		{
			TargetMessage(CHATMESSAGETYPE.WHISPER, from.GUID, to.BackLink.Client, msg, language);
			TargetMessage(CHATMESSAGETYPE.WHISPER_INFORM, to.GUID, from.BackLink.Client, msg, language);
		}

		public static void Ignored(PlayerObject from, PlayerObject to)
		{
			TargetMessage(CHATMESSAGETYPE.IGNORED, to.GUID, from.BackLink.Client, string.Empty, 0);
		}

		public static void System(string msg)
		{
			PooledList<PlayerObject> players = ClientManager.GetPlayerList();

			foreach (PlayerObject player in players)
				if (player != null && !player.IsDisposed)
					System(player.BackLink.Client, msg);
		}

		public static void System(ClientBase client, string msg)
		{
			Message(CHATMESSAGETYPE.SYSTEM, null, ((ClientData) client.Data).Player, msg, 0, 0f, null /*string.Empty*/);
		}

		public static void MonsterSay(UnitBase monster, PlayerObject to, string msg)
		{
			MonsterMessage(CHATMESSAGETYPE.MONSTER_EMOTE /*MONSTER_SAY*/, string.Format("[{0}] says: ", monster.Name),
			               to.BackLink.Client, msg);
		}

		//public static void MonsterYell(UnitBase monster, PlayerObject to, string msg)
		//{
		//    MonsterMessage(CHATMESSAGETYPE.MONSTER_EMOTE /*MONSTER_YELL*/, string.Format("[{0}] yells: ", monster.Name),
		//                   to.BackLink.Client, msg);
		//}

		public static void MonsterYell(UnitBase monster, string msg)
		{
			float radiussqrd = 50f * 50f;

			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte)CHATMESSAGETYPE.MONSTER_YELL);
			pkg.Write(0);
			pkg.Write(monster.GUID);
			pkg.WriteString(monster.Name);
			pkg.Write((ulong)0);
			pkg.WriteString(msg);
			pkg.Write((byte)0);


			pkg.Aquire();
			foreach (MapTile mapTile in monster.MapTile.GetNearestTiles(monster.Position))
				if (mapTile != null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.PLAYER);
					if (collection != null)
						foreach (PlayerObject playerObject in collection)
							if (playerObject != null && !playerObject.IsDisposed &&
								playerObject.Position.DistanceFlatSqrd(monster.Position) <= radiussqrd)
								playerObject.BackLink.Client.Send(pkg);
				}
			pkg.Release();
		}

		public static void MonsterEmote(UnitBase monster, PlayerObject to, string msg)
		{
			MonsterMessage(CHATMESSAGETYPE.MONSTER_EMOTE, monster.Name, to.BackLink.Client, msg);
		}

		public static void PartyMessage(PlayerObject from, string msg, uint language, bool raid)
		{
			if (from.Group == null)
				return;
			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte)(raid ? CHATMESSAGETYPE.RAID : CHATMESSAGETYPE.PARTY));
			pkg.Write(language);
			pkg.Write(from.GUID);
			if (!raid)
				pkg.Write(from.GUID);
			pkg.WriteString(msg);
			pkg.Write((byte) 0);

			if (raid)
				from.Group.Send(pkg);
			else
				from.Group.SendGroup(pkg);
		}

		public static void GuildMessage(PlayerObject from, string msg, uint language, bool officer)
		{
			if (from.GuildID == 0)
				return;
			ShortPacket pkg = new ShortPacket(SMSG.MESSAGECHAT);
			pkg.Write((byte)(officer ? CHATMESSAGETYPE.OFFICER : CHATMESSAGETYPE.GUILD));
			pkg.Write(0 /*language*/);
			pkg.Write(from.GUID);
			//pkg.Write(from.GUID);
			pkg.WriteString(msg);
			pkg.Write((byte)0);

			PooledList<PlayerObject> list = ClientManager.GetPlayerList();

			pkg.Aquire();
			
			foreach (PlayerObject player in list)
			{
				if (player != null && !player.IsDisposed && player.GuildID == from.GuildID)
					/*if (!officer)*/
						player.BackLink.Client.Send(pkg);
					/*else
						if (player.Character.Guild.)*/
			}
			
			pkg.Release();
		}

		public static void LocalDefenceMessage(uint areaID, UnitBase sender, PlayerObject enemy)
		{
			DBArea area = (DBArea)Database.Instance.FindObjectByKey(typeof(DBArea), areaID);
			if (area == null)
				return;

			bool alliance = Faction.IsAlliance(sender.Faction);
			PooledList<PlayerObject> list = ClientManager.GetPlayerList();

			ShortPacket pkg = new ShortPacket(SMSG.ZONE_UNDER_ATTACK);
			pkg.Write(areaID);

			pkg.Aquire();
			
			foreach (PlayerObject player in list)
				if (player != null && !player.IsDisposed && player.Zone == areaID &&
					(Faction.IsAlliance(player.Faction) == alliance || player.GM) &&
					player.BackLink.LastLocalDefense + TimeSpan.FromSeconds(25) < CustomDateTime.Now)
				{
					player.BackLink.LastLocalDefense = CustomDateTime.Now;
					player.BackLink.Client.Send(pkg);

					ChatMessage(player.BackLink.Client, null /*sender*/,
					            string.Format("[{0}] {2} spotted at {1}!", sender.Name, area.Name, enemy.Name),
					            player.BackLink.LocalDefenseChannel);
				}
			
			pkg.Release();
		}
	}
}