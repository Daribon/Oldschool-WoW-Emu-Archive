//
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.ServerDatabase;

namespace RunWoW.Misc
{
	public abstract class ISContainer
	{
		#region Inner Classes

		private class InnerItem
		{
			private int m_count;
			private INVSLOT m_slot;
			private DBItemTemplate m_template;
			private bool m_correct;

			public bool Correct
			{
				get { return m_correct; }
			}

			public InnerItem(int ID, INVSLOT Slot, int Count)
			{
				m_template = DBUtility.GetTemplate((uint) ID);
				m_count = Count;
				m_slot = Slot;
				m_correct = m_template != null && Count > 0;
				
				if (!m_correct)
					LogConsole.WriteLine(LogLevel.ERROR, "Start outfit error: no item for template {0}, count {1}", ID, Count);
			}

			public InnerItem(DBItemTemplate template, INVSLOT Slot, int Count)
			{
				m_template = template;
				m_count = Count;
				m_slot = Slot;
				m_correct = m_template != null && Count > 0;

				if (!m_correct)
					LogConsole.WriteLine(LogLevel.ERROR, "Start outfit error: no item for template {0}, count {1}", ID, Count);
			}

			public DBItem ItemOfChar(DBCharacter Character)
			{
				if (!m_correct)
					return null;

				DBItem item = new DBItem(m_template);
				item.OwnerID = Character.ObjectId;
				item.ContainerID = Character.ObjectId;
				item.OwnerSlot = (byte) m_slot;
				item.StackCount = m_count;

				Character.Items.Add(item);

				if (item.OwnerSlot <= (byte)INVSLOT.EQUIPPEDLAST)
					Character.Outfit[item.OwnerSlot] = m_template.DisplayID;
                
				return item;
				//DBUtility.ItemOfChar(Character, m_template, m_slot, m_count);
			}

			public uint ID
			{
				get { return m_template.ObjectId; }
			}
		}

		private class InnerSpell
		{
			private ushort m_spellid;
			private ushort m_slot;

			public InnerSpell(ushort SpellId, ushort slot)
			{
				m_spellid = SpellId;
				m_slot = slot;
			}

			public DBAbility SpellOfChar(DBCharacter character)
			{
                DBAbility spell = new DBAbility();
                spell.OwnerID = character.ObjectId;
                spell.SpellID = m_spellid;
                spell.Slot = m_slot;
                spell.Type = ABILITYTYPE.SPELL;
			    
			    return spell;
			}

			public ushort ID
			{
				get { return m_spellid; }
			}

			public ushort Slot
			{
				set { m_slot = value; }
			}
		}

		private class InnerSkill
		{
			private ushort m_spellid;
			private ushort m_skillid;
			private ushort m_level;
			private ushort m_maxlevel;
			private ushort m_slot;
			private byte m_craft;

			public InnerSkill(ushort SpellId, ushort SkillID, ushort Level, ushort MaxLevel, byte Craft, ushort slot)
			{
				m_spellid = SpellId;
				m_skillid = SkillID;
				m_level = Level;
				m_maxlevel = MaxLevel;
				m_craft = Craft;
				m_slot = slot;
			}

			public DBAbility SkillOfChar(DBCharacter Character)
			{
                DBAbility skill = new DBAbility();
                skill.OwnerID = Character.ObjectId;
                skill.SpellID = m_spellid;
                skill.Slot = m_slot;
                skill.SkillID = m_skillid;
                skill.Level = m_level;
                skill.MaxLevel = m_maxlevel;
                skill.Craft = m_craft;
                skill.Type = ABILITYTYPE.SKILL;
			    
			    return skill;
                //DBUtility.SkillOfChar(Character, m_spellid, m_skillid, m_level, m_maxlevel, m_craft, m_slot);
			}

			public ushort ID
			{
				get { return m_spellid; }
			}

			public ushort Slot
			{
				set { m_slot = value; }
			}
		}

		#endregion

		#region Lists

		private CustomArrayList MaleItems = new CustomArrayList();
		private CustomArrayList FemaleItems = new CustomArrayList();
		
		private CustomArrayList Spells = new CustomArrayList();
		private CustomArrayList Skills = new CustomArrayList();

		#endregion

		#region Adders

		public void AddExternalItem(uint ID, byte gender)
		{
			DBItemTemplate template = DBUtility.GetTemplate(ID);

			if (template == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Start outfit error: no item for template {0}", ID);
				return;
			}

			int count = 1;

			INVSLOT slot = Items.GetInventorySlot(template);
			
			if(slot == INVSLOT.OFFHAND && template.WeaponSubClass == WEAPONSUBCLASS.DAGGER)
				slot = INVSLOT.MAINHAND;

			if (template.Class == ITEMCLASS.PROJECTILE)
				count = 100;
			else
				if (slot <= INVSLOT.BACKPACK_FIRST)
					switch (ID)
					{
						case 2070:
							count = 4; // Darnassian Bleu
							break;
						case 159:
							count = 2; // Refreshing Spring Water
							break;
						case 4540:
							count = 4; //  Tough Hunk of Bread
							break;
						case 117:
							count = 4; // Tough Jerky
							break;
						case 4604:
							count = 2; // Forest Mushroom Cap
							break;
						case 4536:
							count = 4; // Shiny Red Apple
							break;
						case 2516:
							count = 100; // Light Shot
							break;
					}

			InnerItem item = new InnerItem(template, slot, count);

			if (item.Correct)
				if (gender == 0)
					MaleItems.Add(item);
				else
					FemaleItems.Add(item);
		}

		protected void AddSpell(ushort SpellId, ushort Slot)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Spells.Add(new InnerSpell(SpellId, Slot));
		}

		protected void AddSpell(SPELLSKILL SpellId, ushort Slot)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Spells.Add(new InnerSpell((ushort) SpellId, Slot));
		}

		protected void AddSpell(ushort SpellId)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Spells.Add(new InnerSpell(SpellId, 0xffff));
		}

		protected void AddSpell(SPELLSKILL SpellId)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Spells.Add(new InnerSpell((ushort) SpellId, 0xffff));
		}

		protected void AddSkill(ushort SpellId, ushort SkillID, ushort Level, ushort MaxLevel, byte Craft)
		{
			if (FindSkill(SpellId) != null)
				return;
			Skills.Add(new InnerSkill(SpellId, SkillID, Level, MaxLevel, Craft, 0xffff));
		}

		protected void AddSkill(SPELLSKILL SpellId, SKILL SkillID, ushort Level, ushort MaxLevel, byte Craft)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Skills.Add(new InnerSkill((ushort) SpellId, (ushort) SkillID, Level, MaxLevel, Craft, 0xffff));
		}

		protected void AddSkill(ushort SpellId, ushort SkillID, ushort Level, ushort MaxLevel)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Skills.Add(new InnerSkill(SpellId, SkillID, Level, MaxLevel, 0, 0xffff));
		}

		protected void AddSkill(SPELLSKILL SpellId, SKILL SkillID, ushort Level, ushort MaxLevel)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Skills.Add(new InnerSkill((ushort) SpellId, (ushort) SkillID, Level, MaxLevel, 0, 0xffff));
		}

		protected void AddSkill(ushort SpellId, ushort SkillID, ushort Level, ushort MaxLevel, byte Craft, ushort Slot)
		{
			if (FindSkill(SpellId) != null)
				return;
			Skills.Add(new InnerSkill(SpellId, SkillID, Level, MaxLevel, Craft, Slot));
		}

		protected void AddSkill(SPELLSKILL SpellId, SKILL SkillID, ushort Level, ushort MaxLevel, byte Craft, ushort Slot)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Skills.Add(new InnerSkill((ushort) SpellId, (ushort) SkillID, Level, MaxLevel, Craft, Slot));
		}

		protected void AddSkill(ushort SpellId, ushort SkillID, ushort Level, ushort MaxLevel, ushort Slot)
		{
			if (FindSkill(SpellId) != null)
				return;
			Skills.Add(new InnerSkill(SpellId, SkillID, Level, MaxLevel, 0, Slot));
		}

		protected void AddSkill(SPELLSKILL SpellId, SKILL SkillID, ushort Level, ushort MaxLevel, ushort Slot)
		{
			if (FindSkill((ushort) SpellId) != null)
				return;
			Skills.Add(new InnerSkill((ushort) SpellId, (ushort) SkillID, Level, MaxLevel, 0, Slot));
		}

		protected void AddSkill(DBNSkill NSkill, ushort slot)
		{
			AddSpell((ushort) NSkill.SpellID);
			return;
/*		if (NSkill.Craft==2||NSkill.Craft==3)
		{
			AddSpell((ushort)NSkill.SpellID);
			return;
		}
		if (FindSkill((ushort)NSkill.SpellID)!=null)
			return;
        	Skills.Add(new InnerSkill((ushort)NSkill.SpellID,(ushort)NSkill.SkillID,(ushort)NSkill.Level,(ushort)NSkill.MaxLevel,NSkill.Craft,slot));
		if (NSkill.Level==1)
			foreach(DBSSkill sspell in NSkill.Spells)
				AddSpell((ushort)sspell.SpellID);*/
		}

		protected void AddSkill(int NSkillID, ushort slot)
		{
			DBNSkill NSkill = (DBNSkill) Database.Instance.FindObjectByKey(typeof (DBNSkill), NSkillID);
			if (NSkill != null)
				AddSkill(NSkill, slot);
		}

		protected void AddSkill(int NSkillID)
		{
			DBNSkill NSkill = (DBNSkill) Database.Instance.FindObjectByKey(typeof (DBNSkill), NSkillID);
			if (NSkill != null)
				AddSkill(NSkill, 0xffff);
		}

		private InnerSpell FindSpell(ushort spellid)
		{
			foreach (InnerSpell spell in Spells)
				if (spell.ID == spellid)
					return spell;
			return null;
		}

		private InnerSkill FindSkill(ushort spellid)
		{
			foreach (InnerSkill skill in Skills)
				if (skill.ID == spellid)
					return skill;
			return null;
		}

		protected void SetSlot(ushort spellid, ushort slot)
		{
			InnerSpell spell = FindSpell(spellid);
			if (spell != null)
			{
				spell.Slot = slot;
				return;
			}
			InnerSkill skill = FindSkill(spellid);
			if (skill != null)
			{
				skill.Slot = slot;
				return;
			}
		}

		protected void SetSlot(SPELLSKILL spellid, ushort slot)
		{
			SetSlot((ushort) spellid, slot);
		}

		#endregion

		#region Finishers

		public void AddItems(DBCharacter character)
		{
			PooledList<DBItem> items;
            
			if (character.Items == null)
				items = new PooledList<DBItem>(10);
			else
				items = character.Items;

			if (character.Gender == 0)
			{
				foreach (InnerItem item in MaleItems)
					if (item.Correct)
						items.Add(item.ItemOfChar(character));
			}
			else
			{
				foreach (InnerItem item in FemaleItems)
					if (item.Correct)
						items.Add(item.ItemOfChar(character));
			}

			character.Items = items;
		}

		public void AddSpells(DBCharacter character)
		{
			PooledList<DBAbility> abilities;

            if (character.Abilities == null)
				abilities = new PooledList<DBAbility>(20);
            else
				abilities = character.Abilities;
		    
            foreach (InnerSpell spell in Spells)
                abilities.Add(spell.SpellOfChar(character));

            character.Abilities = abilities;
		}

		public void AddSkills(DBCharacter character)
		{
			PooledList<DBAbility> abilities;

            if (character.Abilities == null)
				abilities = new PooledList<DBAbility>(20);
            else
				abilities = character.Abilities;

            foreach (InnerSkill skill in Skills)
				abilities.Add(skill.SkillOfChar(character));

            character.Abilities = abilities;
		}

		#endregion
	}
}