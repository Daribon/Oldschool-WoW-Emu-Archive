//
using System.Collections.Generic;
using RunServer.Common;

namespace RunWoW.Misc.Pathing
{
	public abstract class BasePath
	{
		protected Vector m_from;
		protected Vector m_pos;
		protected Vector m_to;
		protected float m_step;
		protected int m_steps;

		protected BasePath()
		{
			m_to = null;
			m_from = null;
		}

		public BasePath(Vector from, Vector to, float step)
		{
			m_from = from.Clone();
			m_pos = from.Clone();
			m_to = to.Clone();
			m_step = step;
		}

		public bool Finished
		{
			get { return Steps == 0; }
		}

		public int Steps
		{
			get { return m_steps; }
		}

		public Vector From
		{
			get { return m_from; }
		}

		public Vector Current
		{
			get { return m_pos; }
		}

		public Vector To
		{
			get { return m_to; }
		}

		public abstract int Advance(int steps);

		public abstract bool Recalc(Vector to);

		public abstract float Distance { get; }

		public abstract ICollection<Vector> Path { get; }

		public abstract float Direction { get; }
	}
}