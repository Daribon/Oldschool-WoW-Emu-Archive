//
using System;
using System.Collections;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Inventory;
using RunWoW.ServerDatabase;
using RunWoW.World;
using RunServer.Common;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class Spells
	{
		public static bool NearGO(LivingObject unit, int type, int code, float range, out GameObject go)
		{
			float rangesqrd = range * range;

			go = null;
			foreach (MapTile mapTile in unit.MapTile.Adjacents.Tiles)
				if (mapTile != null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection != null)
						foreach (GameObject gameObject in collection)
							if (gameObject != null && gameObject.TypeID == type && gameObject.Template.Sound[0] == code &&
								gameObject.Position.DistanceFlatSqrd(unit.Position) < rangesqrd)
							{
								go = gameObject;
								return true;
							}
				}
			return false;
		}

		[PacketHandler(CMSG.CAST_SPELL)]
		public static void Cast(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null || Client.Player == null)
				return;

			if (!Client.Player.GM && (Client.Player.Character.WorldMapID == 13 || Client.Player.Character.WorldMapID == 29))
				return;

			ushort spellId = data.ReadUInt16();
			/*ushort junk = */
			data.ReadUInt16();
			ushort flags = data.ReadUInt16();

			ulong target = 0;
			Vector sourcePoint = null, targetPoint = null;
			ObjectBase targetObject = null;

			if (Client.Player.GM)
			{
				Chat.System(client,
				            string.Format("Start casting spell {0}, time elapsed {1}", spellId,
				                          (CustomDateTime.Now - data.InnerTime).TotalMilliseconds));
			}

			if ((flags & 0x2) == 0x2 || (flags & 0x800) == 0x800 || (flags & 0x8000) == 0x8000) // one target
			{
				target = Utility.ReadGuid(data);

				if (target == Client.Player.SelectionGUID && Client.Player.Selection != null)
					targetObject = Client.Player.Selection;
				else
					targetObject = Client.Player.MapTile.GetFarObject(target);

				if (targetObject == null)
				{
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NOT_INFRONT);
					return;
				}
			}
			if ((flags & 0x10) == 0x10) // item target
			{
				target = Utility.ReadGuid(data);
				targetObject = Client.Player.Inventory.FindItem(target);
			}
			if ((flags & 0x1000) == 0x1000) // trade item target
			{
				//int slot = data.ReadInt32();

				//if (slot != 6)
				//{
				//	SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_ITEM_ALREADY_ENCHANTED);
				//	return;
				//}

				if (Client.Player.TradeHelper != null)
				{
					PlayerObject other = Client.Player.TradeHelper.Opponent(Client.Player);
					if (other != null)
						targetObject = Client.Player.TradeHelper[other].Items[6/*slot*/];
				}
			}
			if ((flags & 0x20) == 0x20) // source location
			{
				sourcePoint = data.ReadVector();
			}
			if ((flags & 0x40) == 0x40) // dest location
			{
				targetPoint = data.ReadVector();
			}
			if ((flags & 02000) == 0x2000) // unk?
			{
			}

			DoSpellCast(client, spellId, flags, target, sourcePoint, targetPoint, targetObject, data.InnerTime);
		}

		public static void DoSpellCast(ClientBase client, ushort spellId, ushort flags, ulong target, Vector sourcePoint, Vector targetPoint, ObjectBase targetObject, DateTime time)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null)
				return;

			DBAbility ability = Client.Player.Spells[spellId];
			if (ability == null)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NOT_KNOWN);
				LogConsole.WriteLine(LogLevel.ERROR, "Ability not found " + spellId);
				return;
			}
			DBSpell Spell = ability.Spell;
			if (Spell == null)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NOT_KNOWN);
				LogConsole.WriteLine(LogLevel.ERROR, "Casting unknown spell " + spellId);
				return;
			}

			if (Client.Player.Silenced && !Spell.HasEffect(SPELLEFFECT.DISPEL_MECHANIC))
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_SILENCED);
				return;
			}

			if (Client.Player.Stunned && !Spell.HasEffect(SPELLEFFECT.DISPEL_MECHANIC))
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_STUNNED);
				return;
			}

			if (Client.Player.NoControl && !Spell.HasEffect(SPELLEFFECT.DISPEL_MECHANIC))
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_CONFUSED);
				return;
			}

			/*if ((Client.Player.MovementFlags & 0x31) != 0 && Client.Player.SpellProcessor.CastTime(Spell) > 0)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_MOVING);
				return;
			}*/
				
			if (Client.Player.MountDisplayID != 0)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NOT_MOUNTED);
				return;
			}

			if (ability.Cooldown > CustomDateTime.Now)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NOT_READY);
				return;
			}

			if (Spell.ObjectId == 24239 || Spell.ObjectId == 24274 || Spell.ObjectId == 24275 || Spell.ObjectId == 27180)
			{
				if (targetObject is LivingObject && ((LivingObject)targetObject).Health > ((LivingObject)targetObject).MaxHealth/5)
				{
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_CASTER_AURASTATE);
					return;
				}
			}

			//int TargetLevel = 0;
			//TargetLevel = targetObject is LivingObject?((LivingObject)targetObject).Level:((GameObject)targetObject).Level;
			if ((targetObject is LivingObject || targetObject is GameObject) && (targetObject != Client.Player))
				if ((Client.Player.Position.DistanceFlat(targetObject.Position) >
					 Client.Player.CombatReach + (targetObject is LivingObject ? ((LivingObject)targetObject).BoundingRadius : 2f)) &&
					!Client.Player.Position.InFront(Client.Player.Facing, targetObject.Position))
				{
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_UNIT_NOT_INFRONT);
					return;
				}
			if ((targetObject is LivingObject) && Spell.CreatureType != 0)
			{
				int ctype = targetObject is UnitBase ? 1 << (((UnitBase)targetObject).CreatureType - 1) : 64;
				if ((Spell.CreatureType & ctype) != ctype)
				{
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_BAD_TARGETS);
					return;
				}
			}

			CancelCast(client, null);
			if (!Client.Player.Attackable)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_CASTER_DEAD);
				return;
			}
			/*if (Client.Player.Casting || Client.Player.LastCast > CustomDateTime.Now + TimeSpan.FromMilliseconds(500) )
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_DONT_REPORT);
				return;
			}*/
			if (Client.Player.Level < Spell.PlayerLevel && Spell.PlayerLevel <= 60)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_LOW_CASTLEVEL);
				return;
			}
			if (Spell.PetCast)
				if (Client.Player.Pet == null)
				{
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NO_PET);
					return;
				}
				else
				{
					targetObject = Client.Player.Pet;
					flags = 0x2;
				}

			//int coolDown = Client.Player.SpellModifiers.Cooldown(Spell);
			if (Client.Player.LastSpell == spellId && Client.Player.LastCast/* + TimeSpan.FromMilliseconds(1500) */> CustomDateTime.Now)
			{
				SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_DONT_REPORT);
				return;
			}

			Client.Player.LastSpell = spellId;

			for (int i = 0; i < Spell.Tools.Length; i++)
				if (Spell.Tools[i] != 0 && Client.Player.Inventory.CountItems((uint)Spell.Tools[i]) < 1)
				{
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_REAGENTS);
					return;
				}

			for (int i = 0; i < Spell.CraftReqs.Length; i++)
				if (
					Spell.CraftReqs[i].ItemTemplateID != 0 &&
					Client.Player.Inventory.CountItems((uint)Spell.CraftReqs[i].ItemTemplateID) < Spell.CraftReqs[i].Quantity
					)
				{
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_REAGENTS);
					return;
				}

			if (Spell.SpellFocus != 0)
			{
				if (Client.Player.GM)
					Chat.System(client, "Looking for focus GO " + Spell.SpellFocus);

				GameObject go;
				if (!NearGO(Client.Player, 8, Spell.SpellFocus, Constants.CraftRange, out go))
				{
					//Chat.System(client, "You must smith near the anvil");
					SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_REQUIRES_SPELL_FOCUS, Spell.SpellFocus);
					return;
				}
			}

			if (Spell.NextAttackSpell)
			{
				Client.Player.NextHitSpell = Spell;
				return;
			}

			SpellCastEvent cast;
			if (targetObject == null)
				if (sourcePoint == null && targetPoint == null) // self cast
					cast = new SingleTargetCast(Client.Player, Spell, 0x02, null, false);
				else
					cast = new RegionCast(Client.Player, Spell, flags, sourcePoint, targetPoint, false);
			else
				cast = new SingleTargetCast(Client.Player, Spell, flags, targetObject, false);

			//Client.Player.StopCombat();
			Client.Player.CastEvent = cast;
			Client.Player.CastStart = time;

			if (Client.Player.LogDamage)
			{
				Chat.System(client,
							string.Format("Start processing spell {0}:{1}, time elapsed {2}", spellId, Spell.Name,
										  (CustomDateTime.Now - time).TotalMilliseconds));
			}

			if (!cast.Start()) // instant
				Client.Player.UpdateData();
		}

		[PacketHandler(CMSG.CANCEL_CHANNELLING)]
		[PacketHandler(CMSG.CANCEL_CAST)]
		public static void CancelCast(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null || Client.Player == null)
				return;
			Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);
		}

		[PacketHandler(CMSG.CANCEL_AUTO_REPEAT_SPELL)]
		public static void CancelAutoCast(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null)
				return;
			Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
		}

		[PacketHandler(CMSG.USE_ITEM)]
		public static void CastItem(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null || Client.Player == null)
				return;

			if (!Client.Player.GM && (Client.Player.Character.WorldMapID == 13 || Client.Player.Character.WorldMapID == 29))
				return;

			byte pack = data.ReadByte();
			byte slot = data.ReadByte();
			byte spell = data.ReadByte();
			ushort flags = data.ReadUInt16();

			ulong target;
			Vector sourcePoint = null, targetPoint = null;
			ObjectBase targetObject = null;

			if ((flags & 0x2) == 0x2 || (flags & 0x800) == 0x800 || (flags & 0x8000) == 0x8000) // one target
			{
				target = Utility.ReadGuid(data);

				if (target == Client.Player.SelectionGUID && Client.Player.Selection != null)
					targetObject = Client.Player.Selection;
				else
					targetObject = Client.Player.MapTile.GetFarObject(target);

				if (targetObject == null)
				{
					SpellCastEvent.SpellCastResult(client, 0, SpellFailedReason.SPELL_FAILED_NOT_KNOWN);
					return;
				}
			}
			if ((flags & 0x10) == 0x10 || (flags & 0x1000) == 0x1000) // item target
			{
				target = Utility.ReadGuid(data);
				targetObject = Client.Player.Inventory.FindItem(target);
				if (targetObject == null && Client.Player.TradeHelper != null)
				{
					PlayerObject other = Client.Player.TradeHelper.Opponent(Client.Player);
					if (other != null)
						targetObject = other.Inventory.FindItem(target);
				}
			}
			if ((flags & 0x20) == 0x20) // source location
			{
				sourcePoint = data.ReadVector();
			}
			if ((flags & 0x40) == 0x40) // dest location
			{
				targetPoint = data.ReadVector();
			}
			if ((flags & 02000) == 0x2000) // unk?
			{
			}

			BaseInventory inv = Client.Player.Inventory.GetSubContainer(pack);
			ItemObject Item = inv[slot];
			if (Item == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Casting from unknown item, slot " + slot + ", pack: " + pack);
				return;
			}

			DoCastItem(client, Item, spell, flags, targetObject, sourcePoint, targetPoint, data.InnerTime);
		}

		public static void DoCastItem(ClientBase client, ItemObject item, byte spell, ushort flags, ObjectBase targetObject,
									  Vector SourcePoint, Vector TargetPoint, DateTime time)
		{
			ClientData Client = (ClientData)client.Data;

			SpellStat Stat = item.Template.getSpellStat(spell);

			DBSpell Spell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), Stat.ID);
			if (Spell == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Casting unknown spell " + Stat.ID);
				return;
			}
			if (!Client.Player.Attackable)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_CASTER_DEAD);
				return;
			}
			if (Client.Player.Attacking)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_AFFECTING_COMBAT);
				return;
			}
			if (Client.Player.Casting)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_DONT_REPORT);
				return;
			}
			if (item.Cooldown > CustomDateTime.Now)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_ITEM_NOT_READY);
				return;
			}
			if (item.Template.ReqLevel > Client.Player.Level)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT);
				return;
			}

			if ( /*Client.Player.LastSpell==Stat.ID&&*/Client.Player.LastCast /*+TimeSpan.FromMilliseconds(1500)*/> CustomDateTime.Now)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_DONT_REPORT);
				return;
			}

			if (Client.Player.Silenced)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_SILENCED);
				return;
			}

			if (Client.Player.Stunned)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_STUNNED);
				return;
			}

			if (Client.Player.NoControl)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_CONFUSED);
				return;
			}

			if (Client.Player.MountDisplayID != 0)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_NOT_MOUNTED);
				return;
			}

			if (item.Template.Rank > 0 || item.Template.Reputation > 0 || item.Template.ReputationRank > 0 || item.Template.CityRank > 0)
			{
				SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_CANNOT_USE_NEW);
				return;
			}

			//if (item.Name.IndexOf("Grimoire") != -1 || Spell.PetCast)
			//    if (Client.Player.Pet == null)
			//    {
			//        SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_NO_PET);
			//        return;
			//    }
			//    else
			//    {
			//        targetObject = Client.Player.Pet;
			//        flags = 0x2;
			//    }
			//int TargetLevel = 0;
			if ((targetObject is LivingObject || targetObject is GameObject) && (targetObject != Client.Player))
			{
				if (!Client.Player.Position.InFront(Client.Player.Facing, targetObject.Position))
				{
					SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_UNIT_NOT_INFRONT);
					return;
				}
				//TargetLevel = targetObject is LivingObject?((LivingObject)targetObject).Level:((GameObject)targetObject).Level;
			}

			if (Spell.SpellFocus != 0)
			{
				if (Client.Player.GM)
					Chat.System(client, "Looking for focus GO " + Spell.SpellFocus);

				GameObject go;
				if (!NearGO(Client.Player, 8, Spell.SpellFocus, Constants.CraftRange, out go))
				{
					SpellCastEvent.SpellCastResult(client, Stat.ID, SpellFailedReason.SPELL_FAILED_NOT_HERE);
					return;
				}
			}

			Client.Player.LastSpell = Stat.ID;
			Client.Player.LastItemCast = item.GUID;

			int charges = item.DBItem.SpellCharges[spell];
			if (charges != 0)
			{
				if (charges != -1)
				{
					item.DBItem.SpellCharges[spell] = charges - 1;
					item.DBItem.Dirty = true;
				}
				if (charges <= 0) // was -1 or 1
					Client.Player.ConsumeItem(item);
			}
			for (int i = 0; i < Spell.CraftReqs.Length; i++)
				if (Spell.CraftReqs[i].ItemTemplateID != 0)
					Client.Player.Inventory.ConsumeItems(Spell.CraftReqs[i].ItemTemplateID, Spell.CraftReqs[i].Quantity);

			int cooldown = Stat.Cooldown > Spell.CoolDown ? Stat.Cooldown : Spell.CoolDown;
			if (Stat.CategoryCooldown > cooldown)
				cooldown = Stat.CategoryCooldown;

			if (cooldown > 0 && !Spell.Food)
			{
				DateTime ccooldown = CustomDateTime.Now + TimeSpan.FromMilliseconds(cooldown);

				foreach (ItemObject itm in Client.Player.Inventory.GetItems(item.Entry))
				{
					itm.Cooldown = ccooldown;
					SpellCastEvent.SendCoolDownEvent(client, itm.GUID, Spell.SpellID);
				}
			}

			SpellCastEvent cast;
			if (targetObject == null)
				if (SourcePoint == null && TargetPoint == null) // self cast
					cast = new SingleTargetCast(Client.Player, Spell, 0x02, Client.Player, true);
				else
					cast = new RegionCast(Client.Player, Spell, flags, SourcePoint, TargetPoint, true);
			else
				cast = new SingleTargetCast(Client.Player, Spell, flags, targetObject, true);

			if ((item.Template.BindType == 3) && !item.Soulbound)
			{
				item.Soulbound = true;
				item.UpdateData();
			}

			Client.Player.CastEvent = cast;
			Client.Player.CastStart = time;

			if (!cast.Start()) // instant
				Client.Player.UpdateData();
		}
	}
}