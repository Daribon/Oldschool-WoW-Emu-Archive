//
using System.Collections.Generic;
using System.Threading;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Misc;

namespace RunWoW.GamePackets
{
	public enum GroupType : byte
	{
		GROUP = 0,
		RAID = 1
	};
	
	public class Group
	{
		public readonly uint GroupID;
		public const int MaximumGroupPlayers = 5;

		private Dictionary<ulong, PlayerReference> m_members;

		private ulong m_leader;
		private ulong m_groupLooter;
		private byte m_lootMode;
		private byte m_lootTresh;
		private byte m_dungeonDifficulty;
		private byte m_raidIcon;
		private GroupType m_groupType;


		private byte m_raidNumber;
		private Raid m_raid;

		private object m_syncRoot;

		#region Properties

		internal ICollection<PlayerReference> Members
		{
			get { return m_members.Values; }
		}

		public byte RaidNumber
		{
			get { return m_raidNumber; }
			set { m_raidNumber = value; }
		}

		public GroupType GroupType
		{
			get { return m_groupType; }
		}

		public bool Full
		{
			get { return m_members.Count >= MaximumGroupPlayers; }
		}

		public bool RaidFull
		{
			get { return m_raid == null || m_raid.Full; }
		}

		public bool RaidGroupFull
		{
			get { return m_raid == null || m_raid.GroupFull; }
		}

		public bool OnlyOne
		{
			get { return m_members.Count == 1; }
		}
		
		public bool OnlyTwo
		{
			get { return m_members.Count == 2; }
		}

		public int ID
		{
			get { return (int) GroupID; }
		}

		public PooledList<PlayerObject> LivingMembers
		{
			get { return m_raid != null ? m_raid.LivingMembers : pureLivingMembers; }
		}

		internal PooledList<PlayerObject> pureLivingMembers
		{
			get
			{
				PooledList<PlayerObject> result = new PooledList<PlayerObject>();

				lock (m_syncRoot)
					foreach (PlayerReference plr in m_members.Values)
						if (plr.IsAlive)
							result.Add(plr.Target);
				return result;
			}
		}

		public ulong Leader
		{
			get { return m_raid != null ? m_raid.MainGroup.m_leader : m_leader; }
			set { m_leader = value; }
		}

		public ulong GroupLooter
		{
			get { return m_raid != null ? m_raid.MainGroup.m_groupLooter : m_groupLooter; }
			set { m_groupLooter = value; }
		}

		public byte LootMode
		{
			get { return m_raid != null ? m_raid.MainGroup.m_lootMode: m_lootMode; }
			set { m_lootMode = value; }
		}

		public byte LootTresh
		{
			get { return m_raid != null ? m_raid.MainGroup.m_lootTresh : m_lootTresh; }
			set { m_lootTresh = value; }
		}

		public byte DungeonDifficulty
		{
			get { return m_raid != null ? m_raid.MainGroup.m_dungeonDifficulty : m_dungeonDifficulty; }
			set { m_dungeonDifficulty = value; }
		}

		public byte RaidIcon
		{
			get { return m_raidIcon; }
			set { m_raidIcon = value; }
		}

		#endregion

		public Group(PlayerObject leader, uint id)
		{
			m_members = new Dictionary<ulong, PlayerReference>();

			m_leader = leader.GUID;
			GroupID = id;
			m_lootMode = 0;
			m_lootTresh = 2;
			m_dungeonDifficulty = 0;
			m_raidIcon = 0;
			m_groupType = GroupType.GROUP;
			m_raid = null;

			m_syncRoot = new object();

			AddMember(leader);
		}

		public bool AddMember(PlayerObject member)
		{
			lock (m_syncRoot)
			{
				if (Contains(member.GUID))
					return true;

				if (Full)
					return false;

				m_members[member.GUID] = member.Reference;
			}

			member.Group = this;

			SendExcept(new CompressedA9Packet(member.CreatePacketSmall), member);

			/*foreach (PlayerObject plr in LivingMembers)
				if (plr != member && !plr.IsDisposed && plr.MapTile.IsAdjacent(member.MapTile) == ADJACENT.NONE)
					member.BackLink.Client.Send(new CompressedA9Packet(plr.CreatePacketSmall));*/

			return true;
		}

		public bool UpdateMember(PlayerObject member)
		{
			lock (m_syncRoot)
			{
				if (!m_members.ContainsKey(member.GUID))
					return false;

				m_members[member.GUID] = member.Reference;
			}

			SendExcept(new CompressedA9Packet(member.CreatePacketSmall), member);

			/*foreach (PlayerObject plr in LivingMembers)
				if (plr != member && !plr.IsDisposed && plr.MapTile.IsAdjacent(member.MapTile) == ADJACENT.NONE)
					member.BackLink.Client.Send(new CompressedA9Packet(plr.CreatePacketSmall));*/

			return true;
		}

		public void RemoveMember(PlayerObject member)
		{
			lock (m_syncRoot)
			{
				if (!m_members.ContainsKey(member.GUID))
					return;

				m_members.Remove(member.GUID);
			}

			member.Group = null;

			SendExcept(member.DestroyPacket, member);

			/*foreach (PlayerObject plr in LivingMembers)
				if (plr.MapTile.IsAdjacent(member.MapTile) == ADJACENT.NONE)
					member.BackLink.Client.Send(plr.DestroyPacket);*/
		}

		public void RemoveMember(ulong GUID)
		{
			lock (m_syncRoot)
			{
				if (!m_members.ContainsKey(GUID))
					return;

				m_members.Remove(GUID);
			}
		}

		public void ChangeLeader(PlayerObject leader)
		{
			if (!Contains(leader.GUID))
				return;
			m_leader = leader.GUID;
			ShortPacket pkg = new ShortPacket(SMSG.GROUP_SET_LEADER);
			pkg.Write(leader.Name);
			Send(pkg);
		}

		internal void RemoveAllMembers()
		{
			lock (m_syncRoot)
			{
				foreach (PlayerReference plr in m_members.Values)
					if (plr.IsAlive)
						plr.Target.Group = null;
				
				m_members.Clear();
			}
		}

		public void Update()
		{
			if (m_raid != null)
				m_raid.Update();
			else
			foreach (PlayerReference player in m_members.Values)
				if (player.IsAlive)
				{
					ShortPacket pkg = new ShortPacket(SMSG.GROUP_LIST);
					pkg.Write((byte)m_groupType);
					pkg.Write((byte)0);
					pkg.Write((byte)0);

					pkg.Write(m_members.Count - 1);

					foreach (PlayerReference plr in m_members.Values)
						if (plr.GUID != player.GUID)
						{
							pkg.Write(plr.Name);
							pkg.Write(plr.GUID);
							pkg.Write((byte)(plr.IsAlive && !plr.Target.IsDisposed ? 1 : 0));
							pkg.Write((byte)0);
						}

					pkg.Write(m_leader);
					pkg.Write(m_lootMode);
					pkg.Write(m_groupLooter);
					pkg.Write(m_lootTresh);
					pkg.Write(m_dungeonDifficulty);
					pkg.Write(m_raidIcon);
					pkg.Write((ulong)0);
					//Send(pkg);
					player.Target.BackLink.Client.Send(pkg);
				}
		}

		public void Send(ShortPacket pkg)
		{
			PooledList<PlayerObject> targets = LivingMembers;

			pkg.Aquire();

			foreach (PlayerObject plr in targets)
				if (!plr.IsDisposed)
					plr.BackLink.Client.Send(pkg);

			pkg.Release();
		}

		public void SendGroup(ShortPacket pkg)
		{
			PooledList<PlayerObject> targets = pureLivingMembers;

			pkg.Aquire();

			foreach (PlayerObject plr in targets)
				if (!plr.IsDisposed)
					plr.BackLink.Client.Send(pkg);

			pkg.Release();
		}

		public void SendExcept(IPacket pkg, PlayerObject eplr)
		{
			PooledList<PlayerObject> targets = LivingMembers;

			pkg.Aquire();

			foreach (PlayerObject plr in targets)
				if (!plr.IsDisposed &&
				    plr != eplr &&
				    plr.MapTile != eplr.MapTile)
					plr.BackLink.Client.Send(pkg);

			pkg.Release();
		}

		#region Raid Operations

		public void ConvertToRaid(Raid raid)
		{
			if (m_groupType != GroupType.GROUP)
				return;

			m_groupType = GroupType.RAID;

			m_raid = raid == null ? new Raid(this) : raid;
		}

		public void ConvertToGroup()
		{
			if (m_groupType != GroupType.RAID)
				return;

			m_groupType = GroupType.GROUP;

			m_raid.RemoveGroup(this);

			m_raid = null;

			Update();
		}

		public void AddRaidGroup(Group group)
		{
			if (m_groupType != GroupType.RAID)
				return;

			group.ConvertToRaid(m_raid);
			m_raid.AddGroup(group);
		}

		public void AddRaidMember(PlayerObject player)
		{
			if (m_groupType != GroupType.RAID)
				return;

			if (!Full)
				AddMember(player);
			else
				m_raid.AddMember(player);
		}

		#endregion

		public bool Contains(ulong guid)
		{
			if (m_groupType == GroupType.RAID)
				return m_raid.Contains(guid);
			else
				return pureContains(guid);
		}

		internal bool pureContains(ulong guid)
		{
			lock(m_syncRoot)
				return m_members.ContainsKey(guid);
		}
	}

	public class Raid
	{
		public const int RaidMaximumGroups = 8;

		private PooledList<Group> m_groups;
		private object m_syncRoot;

		public bool Full
		{
			get
			{
				lock (m_syncRoot)
				{
					if (!GroupFull)
						return false;

					foreach (Group group in m_groups)
						if (!group.Full)
							return false;
				}

				return true;
			}
		}

		public bool GroupFull
		{
			get
			{
				lock (m_syncRoot)
					return m_groups.Count >= RaidMaximumGroups;
			}
		}

		public PooledList<PlayerObject> LivingMembers
		{
			get
			{
				PooledList<PlayerObject> result = new PooledList<PlayerObject>();

				lock (m_syncRoot)
					foreach (Group group in m_groups)
						result.AddRange(group.pureLivingMembers);

				return result;
			}
		}

		public Group MainGroup
		{
			get { return m_groups[0]; }
		}

		public Raid(Group creator)
		{
			m_groups = new PooledList<Group>();
			m_syncRoot = new object();
			AddGroup(creator);
		}

		public void AddGroup(Group group)
		{
			lock (m_syncRoot)
			{
				if (m_groups.Contains(group))
					return;
				group.RaidNumber = (byte)m_groups.Count;

				m_groups.Add(group);
			}

			Update();
		}

		public void RemoveGroup(Group group)
		{
			lock (m_syncRoot)
			{
				if (!m_groups.Contains(group))
					return;

				m_groups.Remove(group);

			}
			if (m_groups.Count > 0)
				Update();
		}

		public void Update()
		{
			lock (m_syncRoot)
			{
				foreach (Group group in m_groups)
					foreach (PlayerReference player in group.Members)
						if (player.IsAlive && !player.Target.IsDisposed)
						{
							ShortPacket pkg = new ShortPacket(SMSG.GROUP_LIST);
							pkg.Write((byte)group.GroupType);
							pkg.Write((byte)group.RaidNumber);
							pkg.Write((byte)0);

							int countpos = pkg.Position;
							int count = 0;
							pkg.Write(count);
							foreach (Group otherGroup in m_groups)
								foreach (PlayerReference otherPlayer in otherGroup.Members)
									if (otherPlayer.GUID != player.GUID)
									{
										pkg.Write(otherPlayer.Name);
										pkg.Write(otherPlayer.GUID);
										pkg.Write((byte)(otherPlayer.IsAlive ? 1 : 0));
										pkg.Write((byte)otherGroup.RaidNumber);
										count++;
									}

							pkg.Set(countpos, count);

							pkg.Write(group.Leader);
							pkg.Write(group.LootMode);
							pkg.Write(group.GroupLooter);
							pkg.Write(group.LootTresh);
							pkg.Write(group.DungeonDifficulty);
							pkg.Write(group.RaidIcon);
							player.Target.BackLink.Client.Send(pkg);
						}
			}
		}

		public void AddMember(PlayerObject player)
		{
			lock (m_syncRoot)
			{
				foreach (Group group in m_groups)
					if (!group.Full)
					{
						group.AddMember(player);
						return;
					}

				if (GroupFull)
					return;

				Group newGroup = GroupManager.AddGroup(player);
				newGroup.ConvertToRaid(this);
				AddGroup(newGroup);
			}
		}

		public bool Contains(ulong guid)
		{
			lock (m_syncRoot)
				foreach (Group group in m_groups)
					if (group.pureContains(guid))
						return true;
			return false;
		}
	}

	public class GroupManager
	{
		#region Static
		private static PooledList<Group> Groups = new PooledList<Group>();

		private static int m_lastGroup = 1;

		public static Group AddGroup(PlayerObject leader)
		{
			if (leader.Group != null)
				return leader.Group;

			int id = Interlocked.Increment(ref m_lastGroup);
			Group result = new Group(leader, (uint) id);
			Groups.Add(result);
			return result;
		}

		public static void DismissGroup(Group group)
		{
			group.RemoveAllMembers();
			group.ConvertToGroup();
			Groups.Remove(group);
		}

		public static Group FindGroup(uint num)
		{
			foreach (Group grp in Groups)
				if (grp.ID == num)
					return grp;
			return null;
		}

		public static Group CreateGroup(ICollection<PlayerObject> players)
		{
			if (players.Count < 2)
				return null;

			IEnumerator<PlayerObject> enumerator = players.GetEnumerator();
			enumerator.MoveNext();
			PlayerObject first = enumerator.Current;

			Group result = AddGroup(first);
			if (players.Count > Group.MaximumGroupPlayers)
				result.ConvertToRaid(null);

			while (enumerator.MoveNext())
				if (result.GroupType == GroupType.RAID)
					result.AddRaidMember(enumerator.Current);
				else
					result.AddMember(enumerator.Current);

			return result;
		}

		#endregion		
	}

	[PacketHandlerClass()]
	public class GroupHandler
	{
		public static void PartyResult(ClientBase client, string name, int code)
		{
			ShortPacket pkg = new ShortPacket(SMSG.PARTY_COMMAND_RESULT);
			pkg.Write(0);
			if (name != null)
				pkg.Write(name);
			else
				pkg.Write((byte) 0);
			pkg.Write(code);
			client.Send(pkg);
		}


		[PacketHandler(CMSG.GROUP_INVITE)]
		public static void GroupInvite(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			
			string name = data.ReadString();
			if (name == Client.Player.Name) // ??
				return;
			
			PlayerObject player = ClientManager.GetPlayer(name);
			if (player == null) // not online
			{
				//LogConsole.WriteLine(LogLevel.SYSTEM, string.Format("Player {0} is not online", name));
				PartyResult(client, name, 1);
				return;
			}

			if (player.Group != null) // already in group
			{
				if (Client.Player.Group == null || Client.Player.Group.GroupType == GroupType.GROUP || Client.Player.SameGroup(player))
				{
					PartyResult(client, name, 4);
					return;
				}
				else
					if (Client.Player.Group.RaidGroupFull)
					{
						PartyResult(client, name, 4);
						return;
					}
			}

			if ((player.GroupInvite != null && player.GroupInvite.IsAlive)) // already has an invite
			{
				if (player.GroupInvite.GUID == Client.Player.GUID)
					Chat.System(client, name + " already invited to your group");
				else
					Chat.System(client, name + " already invited to a group");
				return;
			}

			if (!Faction.SameFaction(Client.Player.Faction, player.Faction)) // enemy
			{
				//LogConsole.WriteLine(LogLevel.ECHO, "Inviting enemy player");
				PartyResult(client, null, 8);
				return;
			}

			if (Client.Player.Group != null)  // invite to existing group
			{
				if (Client.Player.Group.Leader != Client.Player.GUID) // only leader can invite
				{
					//LogConsole.WriteLine(LogLevel.ECHO, "Not leader inviting");
					PartyResult(client, null, 6);
					return;
				}

				if (Client.Player.Group.GroupType == GroupType.GROUP)
				{
					if (Client.Player.Group.Full) // group is full
					{
						//LogConsole.WriteLine(LogLevel.ECHO, "Group is full");
						PartyResult(client, null, 3);
						return;
					}
				}
				else
					if (Client.Player.Group.RaidFull) // group is full
					{
						PartyResult(client, null, 3);
						return;
					}
			}

			player.GroupInvite = Client.Player.Reference;

			LogConsole.WriteLine(LogLevel.SYSTEM, "Invite send");

			ShortPacket pkg = new ShortPacket(SMSG.GROUP_INVITE);
			pkg.Write(Client.Player.Name);
			player.BackLink.Client.Send(pkg);

			PartyResult(client, name, 0);
		}

		[PacketHandler(CMSG.GROUP_ACCEPT)]
		public static void GroupAccept(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;

			if (Client.Player.GroupInvite == null || !Client.Player.GroupInvite.IsAlive)
				return;
			
			Group group = Client.Player.GroupInvite.Target.Group;
			
			if (group == null)
				group = GroupManager.AddGroup(Client.Player.GroupInvite.Target);

			if (group.GroupType == GroupType.GROUP)
			{
				if (group.Full)
				{
					Chat.System(client, "Group is already full");
					Client.Player.GroupInvite = null;
					return;
				}
				group.AddMember(Client.Player);
			}
			else
			{
				if (Client.Player.Group != null)
				{
					if (group.RaidGroupFull)
					{
						Chat.System(client, "Raid is already full");
						Client.Player.GroupInvite = null;
						return;
					}
					group.AddRaidGroup(Client.Player.Group);
				}
				else
				{
					if (group.RaidFull)
					{
						Chat.System(client, "Raid is already full");
						Client.Player.GroupInvite = null;
						return;
					}
					group.AddRaidMember(Client.Player);
				}
			}
			group.Update();

			Client.Player.GroupInvite = null;
		}

		[PacketHandler(CMSG.GROUP_DECLINE)]
		public static void GroupDecline(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			
			if (Client.Player.GroupInvite == null || !Client.Player.GroupInvite.IsAlive)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.GROUP_DECLINE);
			pkg.Write(Client.Player.Name);
			Client.Player.GroupInvite.Target.BackLink.Client.Send(pkg);
			Client.Player.GroupInvite = null;
		}

		[PacketHandler(CMSG.GROUP_UNINVITE)]
		public static void GroupUninvite(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			string name = data.ReadString();

			PlayerObject player;
			DBCharacter character;

			if (name == Client.Player.Name)
			{
				player = Client.Player;
				character = Client.Player.Character;
			}
			else
			{
				player = ClientManager.GetPlayer(name);

				if (player != null && !player.IsDisposed)
					character = player.Character;
				else
					character = ClientManager.GetCharacter(name);
			}

			removePlayer(Client.Player, player, character, Client.Player.Group);
		}

		private static void removePlayer(PlayerObject master, PlayerObject player, DBCharacter character, Group group)
		{
			if (master == player)
			{
				if (group.Leader == master.GUID) // I'm a leader
				{
					if (group.OnlyTwo)
					{
						group.Send(new ShortPacket(SMSG.GROUP_DESTROYED));
						GroupManager.DismissGroup(group);
					} else
						PartyResult(master.BackLink.Client, null, 6); 
					return;
				}

				group.RemoveMember(player);

				if (!group.OnlyOne)
				{
					master.BackLink.Client.Send(new ShortPacket(SMSG.GROUP_UNINVITE));
				}
				else
				{
					GroupManager.DismissGroup(group);
					master.BackLink.Client.Send(new ShortPacket(SMSG.GROUP_DESTROYED));
				}	
				//if (group.OnlyTwo)
				//{
				//    group.Send(new ShortPacket(SMSG.GROUP_DESTROYED));
				//    GroupManager.DismissGroup(group);
				//} else 
				//    master.BackLink.Client.Send(new ShortPacket(SMSG.GROUP_UNINVITE));
			} else
			{
				if (group.Leader != master.GUID) // I'm not a leader
				{
					PartyResult(master.BackLink.Client, null, 6);
					return;
				}
				
				if (character.GroupID != group.ID)
				{
					PartyResult(master.BackLink.Client, character.Name, 2);
					return;
				}

				if (player != null)
				{
					group.RemoveMember(player);
					player.BackLink.Client.Send(new ShortPacket(SMSG.GROUP_UNINVITE));
				}
				else
					group.RemoveMember(character.ObjectId);

				if (!group.OnlyOne)
					group.Update();
				else
				{
					GroupManager.DismissGroup(group);
					master.BackLink.Client.Send(new ShortPacket(SMSG.GROUP_DESTROYED));
				}				
			}
		}
		
		[PacketHandler(CMSG.GROUP_UNINVITE_GUID)]
		public static void GroupUninviteGuid(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			ulong GUID = data.ReadUInt64();
			
			PlayerObject player;
			DBCharacter character;

			if (GUID == Client.Player.GUID)
			{
				player = Client.Player;
				character = Client.Player.Character;
			}
			else
			{
				player = ClientManager.GetPlayer(GUID);

				if (player != null && !player.IsDisposed)
					character = player.Character;
				else
					character = ClientManager.GetCharacter((uint) GUID);
			}

			removePlayer(Client.Player, player, character, Client.Player.Group);
		}

		[PacketHandler(CMSG.GROUP_DISBAND)]
		public static void GroupDisband(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			Group group = Client.Player.Group;

			removePlayer(Client.Player, Client.Player, null, group);
			Client.Player.Group = null;
			/*if (group.Leader != Client.Player.GUID) // leader cannot leave
			{
				PartyResult(client, null, 6);
				return;
			}

			group.Send(new ShortPacket(SMSG.GROUP_DESTROYED));
			GroupManager.DismissGroup(group);
			//client.Send(new ShortPacket(SMSG.GROUP_DESTROYED));*/
		}

		[PacketHandler(CMSG.GROUP_SET_LEADER)]
		public static void GroupLeader(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			if (Client.Player.Group.Leader != Client.Player.GUID) // only leader can do that
			{
				PartyResult(client, null, 6);
				return;
			}

			string name = data.ReadString();
			
			PlayerObject player = ClientManager.GetPlayer(name);
			if (player == null) // not online
			{
				PartyResult(client, name, 1);
				return;
			}
			if (Client.Player.Group != player.Group) // not my group
			{
				PartyResult(client, name, 2);
				return;
			}
			Client.Player.Group.ChangeLeader(player);
			Client.Player.Group.Update();
		}

		[PacketHandler(CMSG.GROUP_RAID_CONVERT)]
		public static void RaidConvert(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			if (Client.Player.Group.Leader != Client.Player.GUID) // only leader can do that
			{
				PartyResult(client, null, 6);
				return;
			}

			Client.Player.Group.ConvertToRaid(null);
		}

		[PacketHandler(CMSG.REQUEST_RAID_INFO)]
		public static void RaidInfo(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.RAID_INSTANCE_INFO);
			pkg.Write(0);
			client.Send(pkg);
		}

		[PacketHandler(CMSG.REQUEST_PARTY_MEMBER_STATS)]
		public static void PartyStats(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			ulong guid = data.ReadUInt64();

			DBCharacter character = ClientManager.GetCharacter((uint)guid);

			if (character == null)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.PARTY_MEMBER_STATS);
			pkg.WriteGuid(guid);
			pkg.Write((byte)0x10);
			pkg.Write((byte)0x10);
			pkg.Write((short)0);
			pkg.Write((short)21);
			pkg.Write(1);
			pkg.Write((short)24244);
			pkg.Write((byte)0);
			client.Send(pkg);
		}


		[PacketHandler(CMSG.LOOT_METHOD)]
		public static void GroupLoot(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Group == null)
				return;

			if (Client.Player.Group.Leader != Client.Player.GUID) // only leader can do that
			{
				PartyResult(client, null, 6);
				return;
			}
			
			Client.Player.Group.LootTresh = (byte) data.ReadUInt32();
			Client.Player.Group.GroupLooter = data.ReadUInt64();
			Client.Player.Group.LootMode = (byte) data.ReadUInt32();
			Client.Player.Group.Update();
		}
	}
}