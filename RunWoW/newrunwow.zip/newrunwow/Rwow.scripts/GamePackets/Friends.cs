//
using System;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class Friends
	{
		[PacketHandler(CMSG.FRIEND_LIST, ExecutionPriority.Pool)]
		public static void FriendList(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Character == null)
				return;
			ShortPacket flist = new ShortPacket(SMSG.FRIEND_LIST);
			if (Client.Character.Friends == null)
				flist.Write((byte) 0);
			else
			{
				flist.Write((byte) Client.Character.Friends.Count);
				foreach (DBFriendList friend in Client.Character.Friends)
				{
					flist.Write((ulong) friend.Friend_ID);

					PlayerObject Friend = ClientManager.GetPlayer(friend.Friend_ID);
					if (Friend != null)
					{
						flist.Write((byte) 1); // online
						flist.Write((int) Friend.Zone);
						flist.Write((int) Friend.Level);
						flist.Write((int) Friend.Class);
					}
					else
						flist.Write((byte) 0);
				}
			}
			client.Send(flist);
		}

		[PacketHandler(CMSG.DEL_FRIEND, ExecutionPriority.Pool)]
		public static void RemoveFriend(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			uint fnum = data.ReadUInt32();
			foreach (DBFriendList Friend in Client.Character.Friends)
				if (Friend.Friend_ID == fnum)
				{
					try
					{
						DBManager.EraseDBObject(Friend);

						DBCharacter Character = ClientManager.GetCharacter(Friend.Friend_ID);
							//(DBCharacter) Database.Instance.FindObjectByKey(typeof (DBCharacter), Friend.Friend_ID);

						Client.Character.Friends = null;
						Database.Instance.ResolveRelations(Client.Character, typeof (DBFriendList));
						Character.OnFriends = null;
						Database.Instance.ResolveRelations(Character, typeof (DBFriendList));
					}
					catch (Exception e)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Deleting Friend failed! " + e);
					}
					ShortPacket packet = new ShortPacket(SMSG.FRIEND_STATUS);
					packet.Write((byte) FRIENDSTATUS.REMOVED);
					packet.Write((ulong) fnum);
					client.Send(packet);

					break;
				}
		}

		[PacketHandler(CMSG.ADD_FRIEND, ExecutionPriority.Pool)]
		public static void AddFriend(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;

			string friend = data.ReadString();

			ShortPacket FriendStatus = new ShortPacket(SMSG.FRIEND_STATUS);
			DBCharacter character = null;
			try
			{
				PlayerObject player = ClientManager.GetPlayer(friend);
				if (player != null)
					character = player.Character;
				else
					character = (DBCharacter) Database.Instance.FindObjectByField(typeof (DBCharacter), "Name", friend);
			}
			catch (Exception e)
			{
				FriendStatus.Write((byte) FRIENDSTATUS.DB_ERROR);
				client.Send(FriendStatus);
				LogConsole.WriteLine(LogLevel.SYSTEM, "Failed friend search: " + e);
				return;
			}
			if (character == null)
			{
				FriendStatus.Write((byte) FRIENDSTATUS.NOT_FOUND);
				client.Send(FriendStatus);
				return;
			}
			if (character == Client.Character)
			{
				FriendStatus.Write((byte) FRIENDSTATUS.SELF);
				client.Send(FriendStatus);
				return;
			}
			if (!Faction.SameFaction(character.Faction, Client.Character.Faction))
			{
				FriendStatus.Write((byte) FRIENDSTATUS.ENEMY);
				client.Send(FriendStatus);
				return;
			}
			if (Client.Character.Friends != null)
				foreach (DBFriendList Friend in Client.Character.Friends)
					if (Friend.Friend_ID == character.ObjectId)
					{
						FriendStatus.Write((byte) FRIENDSTATUS.ALREADY);
						client.Send(FriendStatus);
						return;
					}
			DBFriendList newentry = new DBFriendList();
			newentry.Owner_ID = Client.Character.ObjectId;

			newentry.Friend_ID = character.ObjectId;
			DBManager.NewDBObject(newentry);

			Client.Character.Friends = null;
			Database.Instance.ResolveRelations(Client.Character, typeof (DBFriendList));
			character.OnFriends = null;
			Database.Instance.ResolveRelations(character, typeof (DBFriendList));

			if (ClientManager.GetPlayer(character.ObjectId) != null)
			{
				FriendStatus.Write((byte) FRIENDSTATUS.ADDED_ONLINE);
				FriendStatus.Write((ulong) character.ObjectId);
				FriendStatus.Write((int) character.Zone);
				FriendStatus.Write((int) character.Level);
				FriendStatus.Write((int) character.Class);
			}
			else
			{
				FriendStatus.Write((byte) FRIENDSTATUS.ADDED_OFFLINE);
				FriendStatus.Write((ulong) character.ObjectId);
			}
			client.Send(FriendStatus);
		}

		public static void FriendsState(FRIENDSTATUS state, DBCharacter character)
		{
			if (character == null || character.OnFriends == null)
				return;
			
			foreach (DBFriendList friend in character.OnFriends)
			{
				PlayerObject playerObject = ClientManager.GetPlayer(friend.Owner_ID);
				if (playerObject != null && !playerObject.IsDisposed && playerObject.GuildID != character.GuildID)
				{
					ShortPacket pkg = new ShortPacket(SMSG.FRIEND_STATUS);
					pkg.Write((byte) state);
					pkg.Write((ulong)character.ObjectId);
					playerObject.BackLink.Client.Send(pkg);
				}
			}
		}
	}
}