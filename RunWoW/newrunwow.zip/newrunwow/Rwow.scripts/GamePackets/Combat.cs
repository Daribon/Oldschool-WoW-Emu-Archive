//
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Events;
using RunWoW.Objects;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class Combat
	{
		public static void Fail(PlayerObject Player, SMSG reason)
		{
			Player.BackLink.Client.Send(new ShortPacket(reason));
			switch (reason)
			{
				case SMSG.ATTACKSWING_CANT_ATTACK:
				case SMSG.ATTACKSWING_DEADTARGET:
				case SMSG.ATTACKSWING_NOTSTANDING:
					Player.StopCombat();
					break;
			}
		}

		[PacketHandler(CMSG.ATTACKSWING)]
		public static void OnAttackSwing(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.MapTile == null)
				return;
			//if (Client.Player.Casting)
			//	Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED_COMBAT);

			ulong target = data.ReadUInt64();
			LivingObject targetObject;

			if (target == Client.Player.SelectionGUID && Client.Player.Selection is LivingObject)
                		targetObject = (LivingObject)Client.Player.Selection;
			else
				targetObject = (LivingObject)Client.Player.MapTile.GetObject(target, OBJECTTYPE.UNIT);
			if (targetObject == null)
			{
				Fail(Client.Player, SMSG.ATTACKSWING_CANT_ATTACK);
				return;
			}
			if (!Client.Player.Attackable)
			{
				Fail(Client.Player, SMSG.ATTACKSWING_DEADTARGET);
				return;
			}
			if (!targetObject.Attackable)
			{
				Fail(Client.Player, SMSG.ATTACKSWING_DEADTARGET);
				return;
			}
			if (Client.Player.StandState != UNITSTANDSTATE.STANDING)
			{
				Fail(Client.Player, SMSG.ATTACKSWING_NOTSTANDING);
				return;
			}
			/*float distance = Client.Player.Position.DistanceSqrd(targetObject.Position);
			float hitDistance = Client.Player.CombatReach + targetObject.BoundingRadius + 3;
			hitDistance = hitDistance * hitDistance;
			if (distance > hitDistance)
			{
				Fail(Client.Player, SMSG.ATTACKSWING_NOTINRANGE);
				if (distance < 15f && !targetObject.Attacking)
					targetObject.StartCombat(Client.Player.GUID);
				return;
			}

			if (distance > targetObject.BoundingRadius && !Client.Player.Position.InFront(Client.Player.Facing, targetObject.Position))
			{
				Fail(Client.Player, SMSG.ATTACKSWING_BADFACING);
				if (distance < 15f && !targetObject.Attacking)
					targetObject.StartCombat(Client.Player.GUID);
				return;
			}*/


			if (Client.Player.Casting)
				Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);
			if (BaseCombatEvent.InCombatDistance(Client.Player, targetObject))
				targetObject.Attacked(Client.Player);

			Client.Player.Reputations.Contacted(targetObject);
			Client.Player.StartCombat(targetObject);
			
			//if (targetObject is UnitBase)
			//{
			//    if (!targetObject.Attacking)
			//        targetObject.StartCombat(Client.Player);
			//    else
			//        targetObject.StartFightEvent(Client.Player);
			//}
			//if (targetObject is PlayerObject)
			//{
			//    PlayerObject targetPlayer = targetObject as PlayerObject;
			//    if (targetPlayer.PvP)
			//    {
			//        Client.Player.PvP = true;
			//        //Chat.System(targetPlayer.BackLink.client, Client.Player.Name+" has attacked you!");
			//        if (Client.Player.Casting)
			//            Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);
			//        if (!targetPlayer.Attacking)
			//            targetPlayer.StartCombat(Client.Player);
					
			//        //Client.Player.StartCombat(targetObject);
			//    }
			//    else
			//    {
			//        Fail(Client.Player, SMSG.ATTACKSWING_CANT_ATTACK);
			//        return;
			//    }
			//}

			//if (Client.Player.FightEvent is BaseCombatEvent)
			//    ((BaseCombatEvent)Client.Player.FightEvent).ChangeTarget(targetObject);
			//else
			//    Client.Player.StartCombat(targetObject);
		}

		[PacketHandler(CMSG.ATTACKSTOP)]
		public static void OnAttackStop(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			Client.Player.StopCombat();
		}
	}
}