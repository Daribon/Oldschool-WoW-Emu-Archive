//
using System;
using System.Collections;
using System.IO;
using RunServer.Common;

namespace RunWoW.Map
{
	public class WorldMap
	{
		private const int MaxTiles = 64;

		private static string MapPath = Constants.MapPath;

		public enum Worlds
		{
//#if BURNING_CRUSADE
			Azeroth = 0,
			Kalimdor = 1,
			test = 13,
			ScottTest = 25,
			Test = 29,
			PVPZone01 = 30,
			Shadowfang = 33,
			StormwindJail = 34,
			StormwindPrison = 35,
			DeadminesInstance = 36,
			PVPZone02 = 37,
			Collin = 42,
			WailingCaverns = 43,
			Monastery = 44,
			RazorfenKraulInstance = 47,
			Blackfathom = 48,
			Uldaman = 70,
			GnomeragonInstance = 90,
			SunkenTemple = 109,
			RazorfenDowns = 129,
			EmeraldDream = 169,
			MonasteryInstances = 189,
			TanarisInstance = 209,
			BlackRockSpire = 229,
			BlackrockDepths = 230,
			OnyxiaLairInstance = 249,
			CavernsOfTime = 269,
			SchoolofNecromancy = 289,
			Zulgurub = 309,
			Stratholme = 329,
			Mauradon = 349,
			DeeprunTram = 369,
			OrgrimmarInstance = 389,
			MoltenCore = 409,
			DireMaul = 429,
			AlliancePVPBarracks = 449,
			HordePVPBarracks = 450,
			development = 451,
			BlackwingLair = 469,
			PVPZone03 = 489,
			AhnQiraj = 509,
			PVPZone04 = 529,
			Expansion01 = 530,
			AhnQirajTemple = 531,
			Karazahn = 532,
			StratholmeRaid = 533,
			HyjalPast = 534,
			HellfireMilitary = 540,
			HellfireDemon = 542,
			HellfireRampart = 543,
			HellfireRaid = 544,
			CoilfangPumping = 545,
			CoilfangMarsh = 546,
			CoilfangDraenei = 547,
			CoilfangRaid = 548,
			TempestKeepRaid = 550,
			TempestKeepArcane = 552,
			TempestKeepAtrium = 553,
			TempestKeepFactory = 554,
			AuchindounShadow = 555,
			AuchindounDemon = 556,
			AuchindounEthereal = 557,
			AuchindounDraenei = 558,
			PVPZone05 = 559,
			HillsbradPast = 560,
			bladesedgearena = 562,
			BlackTemple = 564,
/*#else
            DireMaul = 429,
            PVPZone03 = 489,
            PVPZone04 = 529,
            EmeraldDream = 169,
            TanarisInstance = 209,
            Zulgurub = 309,
            Stratholme = 329,
            DeeprunTram = 369,
            OrgrimmarInstance = 389,
            Azeroth = 0,
            Kalimdor = 1,
            test = 13,
            ScottTest = 25,
            Test = 29,
            Shadowfang = 33,
            StormwindJail = 34,
            StormwindPrison = 35,
            DeadminesInstance = 36,
            PVPZone02 = 37,
            Collin = 42,
            WailingCaverns = 43,
            Monastery = 44,
            RazorfenKraulInstance = 47,
            Blackfathom = 48,
            SunkenTemple = 109,
            Uldaman = 70,
            GnomeragonInstance = 90,
            RazorfenDowns = 129,
            OnyxiaLairInstance = 249,
            SchoolofNecromancy = 289,
            MoltenCore = 409,
            BlackwingLair = 469,
            MonasteryInstances = 189,
            CavernsOfTime = 269,
            BlackRockSpire = 229,
            BlackrockDepths = 230,
            Mauradon = 349,
            AlliancePVPBarracks = 449,
            HordePVPBarracks = 450,
            development = 451,
            AhnQiraj = 509,
            PVPZone01 = 30,
#endif*/
		}

		private static Hashtable m_tileCache = new Hashtable();
		private static Hashtable m_exists = new Hashtable();
	    
		private static string getWorldName(int number)
		{
			return ((Worlds) number).ToString();
		}

		public static int LoadedTiles
		{
			get
			{
                lock (m_tileCache.SyncRoot)
				{
					CustomArrayList toRemove = new CustomArrayList();
					
					foreach (DictionaryEntry entry in m_tileCache)
						if (((TileReference) entry.Value).Expired)
							toRemove.Add(entry.Key);

					foreach (object key in toRemove)
						m_tileCache.Remove(key);
					
					toRemove.Dispose();
					
					return m_tileCache.Count;
				}
			}
		}

		public static bool HasMap(int world)
		{
            lock (m_exists.SyncRoot)
			{
				if (m_exists[world] != null)
					return m_exists[world].Equals(true);

				bool exists = Directory.Exists(MapPath + getWorldName(world));
				m_exists[world] = exists;
				return exists;
			}
		}

		public static float GetPoint(int world, float x, float y)
		{
			float water;
			int area;
			float result = GetPoint(world, x, y, out water, out area, false);
			return result;
		}

		public static float GetPoint(int world, float x, float y, out bool underwater)
		{
			float water;
			int area;
			float result = GetPoint(world, x, y, out water, out area, true);
			underwater = result < water;
			return result;
		}

		public static float GetPoint(int world, float x, float y, out float water, out int area, bool seekWater)
		{
            unchecked
            {
                x -= WorldMapTile.TILESIZE - 33;
                y -= WorldMapTile.TILESIZE - 33;

                water = float.NaN;
                area = 0;

                int nx = (int)Math.Floor(32 - x / WorldMapTile.TILESIZE) - 1;
                int ny = (int)Math.Floor(32 - y / WorldMapTile.TILESIZE) - 1;

                if (nx >= MaxTiles || nx < 0 || ny >= MaxTiles || ny < 0)
                    return float.NaN;

                WorldMapTile tile = GetTile(world, nx, ny);

                if (tile == null || !tile.Correct)
                    return float.NaN;

                float sx = -x + tile.BaseX;
                float sy = -y + tile.BaseY;

                if (sx < 0 || sy < 0 || sx > WorldMapTile.TILESIZE || sy > WorldMapTile.TILESIZE)
                {
                    if (sx < 0)
                        nx--;
                    if (sy < 0)
                        ny--;
                    if (sx > WorldMapTile.TILESIZE)
                        nx++;
                    if (sy > WorldMapTile.TILESIZE)
                        ny++;

                    tile = GetTile(world, nx, ny);

                    if (tile == null || !tile.Correct)
                        return float.NaN;

                    sx = -x + tile.BaseX;
                    sy = -y + tile.BaseY;
                }

				if (seekWater)
					water = tile.WaterLevel(sx, sy);
                int xn = (int)Math.Floor(sx * 16 / WorldMapTile.TILESIZE);
                int yn = (int)Math.Floor(sy * 16 / WorldMapTile.TILESIZE);
                area = tile.AreaID[xn][yn];
                return tile.GetBilinear(sx, sy);
            }
		}

		private static WorldMapTile GetTile(int world, int nx, int ny)
		{
			if (!HasMap(world))
				return null;

			string key = string.Format("{0}_{1}_{2}", getWorldName(world), ny, nx);

			TileReference reference;

			lock (m_tileCache.SyncRoot)
			{
				reference = (TileReference) m_tileCache[key];

				if (reference != null)
				{
					reference.KeepAlive();
					if (reference.Tile != null)
						return reference.Tile;

					if (reference.Broken)
						return null;
				} else
					m_tileCache[key] = reference = new TileReference();
			}

			lock (reference.LoadLock)
			{
				if (reference.Tile != null)
					return reference.Tile;

				if (reference.Broken)
					return null;

				WorldMapTile tile = LoadTile(world, key);
				if (tile == null)
				{
					reference.Broken = true;
					return null;
				}

				return reference.Tile = tile;
			}
		}

		private static WorldMapTile LoadTile(int world, string key)
		{
			string dir = MapPath + getWorldName(world);
			if (!Directory.Exists(dir))
				return null;
			string file = string.Format("{0}\\{1}.adt", dir, key);
			if (!File.Exists(file))
				return null;
			return new WorldMapTile(file);
		}
	}

	internal class TileReference
	{
		private DateTime m_expireTime;
		private WorldMapTile m_tile;
		private object m_loadLock;
		private bool m_broken;
		
		public WorldMapTile Tile
		{
			get { return m_tile; }
			set { m_tile = value; }
		}

		public object LoadLock
		{
			get { return m_loadLock; }
		}

		public bool Broken
		{
			get { return m_broken; }
			set { m_broken = value; }
		}

		public bool Expired
		{
			get { return m_expireTime < CustomDateTime.Now; }
		}

		public TileReference(WorldMapTile tile)
		{
			m_tile = tile;
			m_loadLock = new object();
			KeepAlive();
		}

		public TileReference()
			: this(null)
		{
		}

		public void KeepAlive()
		{
			m_expireTime = CustomDateTime.Now.AddMinutes(4);
		}
	}
}
