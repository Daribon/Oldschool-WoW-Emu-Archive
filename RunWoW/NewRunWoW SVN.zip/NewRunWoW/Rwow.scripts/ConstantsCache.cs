using System;

namespace RunWoW
{
	public class ConstantsCache
	{
		public static float MonsterSightRangeSqrd = (float) Math.Sqrt(Constants.MonsterSightRange);
		public static float MonsterStealthSightRangeSqrd = (float) Math.Sqrt(Constants.MonsterStealthSightRange);
		public static float GuardSightRangeSqrd = (float) Math.Sqrt(Constants.GuardSightRange);
		public static float VendorSightRangeSqrd = (float) Math.Sqrt(Constants.VendorSightRange);
		public static float MinSpawnRangeSqrd = (float) Math.Sqrt(Constants.MinSpawnRange);
		public static float MinGOSpawnRangeSqrd = (float) Math.Sqrt(Constants.MinGOSpawnRange);
		public static float PetMaxRangeSqrd = (float) Math.Sqrt(Constants.PetMaxRange);
		public static float CorpseRangeSqrd = (float) Math.Sqrt(Constants.CorpseRange);
	}
}