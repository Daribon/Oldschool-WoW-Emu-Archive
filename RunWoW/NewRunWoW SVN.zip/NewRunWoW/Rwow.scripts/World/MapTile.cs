#define _DOTNET2

#if _DOTNET2
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.Objects;
#endif

namespace RunWoW.World
{
#if _DOTNET2
	using TrapCollection = Dictionary<ulong, Trap>;
#else
	using TrapCollection = Hashtable;
#endif

	public enum ADJACENT
	{
		TOPLEFT,
		TOP,
		TOPRIGHT,
		LEFT,
		SAME,
		RIGHT,
		LOWERLEFT,
		LOWER,
		LOWERRIGHT,
		NONE,
	}

	public struct Trap
	{
		private GameObject GO;
		private float Radius;
		private DateTime Last;
		private int Period;

		public ulong GUID
		{
			get { return GO.GUID; }
		}

		public Trap(GameObject trap, float radius, int period)
		{
			Last = CustomDateTime.Now;
			GO = trap;
			Radius = radius * radius;
			Period = period;
		}

		public bool Check(LivingObject mover)
		{
			if (GO == null || GO.MapTile == null)
				return false;
			if (GO.Creator == mover.GUID)
				return false;
			if (mover.Position.Distance(GO.Position) > Radius)
				return false;
			if (Last + TimeSpan.FromMilliseconds(Period) > CustomDateTime.Now)
				return false;
			LogConsole.WriteLine(LogLevel.ECHO, "Object " + mover.Name + " entered trap " + GO.Name);
			Last = CustomDateTime.Now;
			return GO.FireTrap(mover);
		}
	}

	public class MapTile
	{
		#region private variables

		private FastCollection<PlayerObject> m_players = new FastCollection<PlayerObject>();
		private FastCollection<UnitBase> m_units = new FastCollection<UnitBase>();
		private FastCollection<GameObject> m_gameObjects = new FastCollection<GameObject>();
		
//		private Queue m_packets = Queue.Synchronized(new Queue());

		private TrapCollection m_traps = new Dictionary<ulong, Trap>();
		private object m_trapsLock = new object();

		private MapInstance m_map = null;
		private bool m_has_updates = false;
		private bool m_awaken = false;
		private int m_x;
		private int m_y;
		private MapAdjacentsArray m_adjacents;

		#endregion

		#region public properties

		public MapInstance Map
		{
			get { return m_map; }
		}

		public FastCollection<PlayerObject> Players
		{
			get { return m_players; }
		}

		public FastCollection<UnitBase> Units
		{
			get { return m_units; }
		}

		public FastCollection<GameObject> GameObjects
		{
			get { return m_gameObjects; }
		}

		public MapAdjacentsArray Adjacents
		{
			get { return m_adjacents; }
		}

		public bool HasAjPlayers
		{
			get
			{
				foreach (MapTile tile in m_adjacents.Tiles)
					if (tile != null && tile.HasPlayers)
						return true;
				return false;
			}
		}

		public bool HasPlayers
		{
            get { return m_players != null && m_players.Count > 0; }
		}

		public int CountAjPlayers
		{
			get
			{
				int result = 0;
				foreach (MapTile tile in m_adjacents.Tiles)
					if (tile != null && tile.Players != null)
						result += tile.Players.Count;
				return result;
			}
		}

		public bool HasUpdates
		{
			get { return m_has_updates; }
			set
			{
				if (value && !m_has_updates && HasAjPlayers)
					Awake();
				m_has_updates = value;
			}
		}

		public bool Awaken
		{
			get { return m_awaken; }
		}

		public int X
		{
			get { return m_x; }
			set { m_x = value; }
		}

		public int Y
		{
			get { return m_y; }
			set { m_y = value; }
		}

		#endregion

		public override string ToString()
		{
			return string.Format("{0}, {1}", m_x, m_y);
		}

		public MapTile(MapInstance map, MapAdjacentsArray adjacents, int x, int y)
		{
			m_map = map;
			m_x = x;
			m_y = y;
			m_adjacents = adjacents;
		}

		#region Adjacent operations

		public ADJACENT IsAdjacent(MapTile tile)
		{
			if (m_adjacents == null || tile == null)
				return ADJACENT.NONE;
			if (m_adjacents[(int)ADJACENT.TOPLEFT] == tile) return ADJACENT.TOPLEFT;
			if (m_adjacents[(int)ADJACENT.TOP] == tile) return ADJACENT.TOP;
			if (m_adjacents[(int)ADJACENT.TOPRIGHT] == tile) return ADJACENT.TOPRIGHT;
			if (m_adjacents[(int)ADJACENT.LEFT] == tile) return ADJACENT.LEFT;
			if (m_adjacents[(int)ADJACENT.SAME] == tile) return ADJACENT.SAME;
			if (m_adjacents[(int)ADJACENT.RIGHT] == tile) return ADJACENT.RIGHT;
			if (m_adjacents[(int)ADJACENT.LOWERLEFT] == tile) return ADJACENT.LOWERLEFT;
			if (m_adjacents[(int)ADJACENT.LOWER] == tile) return ADJACENT.LOWER;
			if (m_adjacents[(int)ADJACENT.LOWERRIGHT] == tile) return ADJACENT.LOWERRIGHT;
			return ADJACENT.NONE;
		}

		public void AdjacentCreateObject(ADJACENT adj, ObjectBase obj, ref IPacket packet, List<A9Packet> packets)
		{
			//Console.WriteLine("Adjanced create " + adj + " for " + obj.Name);
			if (m_adjacents[(int)adj] != null)
				m_adjacents[(int)adj].SendCreate(obj, ref packet, packets);
		}


		public void AdjacentDestroyObject(ADJACENT adj, ObjectBase obj, ref IPacket packet, List<ulong> guids)
		{
			//Console.WriteLine("Adjanced destroy " + adj + " for " + obj.Name);
			if (m_adjacents[(int)adj] != null)
				m_adjacents[(int)adj].SendDestroy(obj, ref packet, guids);
		}

		#endregion

		public ICollection GetObjects(OBJECTTYPE type)
		{
			switch (type)
			{
				case OBJECTTYPE.PLAYER:
					return m_players == null ? null : m_players.InnerArray;
				case OBJECTTYPE.GAMEOBJECT:
					return m_gameObjects == null ? null : m_gameObjects.InnerArray;
				case OBJECTTYPE.UNIT:
					return m_units == null ? null : m_units.InnerArray;
			}
			return null;
		}

		public int CountTileObjects(OBJECTTYPE type)
		{
			switch (type)
			{
				case OBJECTTYPE.PLAYER:
					return m_players == null ? 0 : m_players.Count;
				case OBJECTTYPE.GAMEOBJECT:
					return m_gameObjects == null ? 0 : m_gameObjects.Count;
				case OBJECTTYPE.UNIT:
					return m_units == null ? 0 : m_units.Count;
			}

			return 0;
		}
		public int CountObjects(OBJECTTYPE type)
		{
			int result = 0;
			foreach (MapTile tile in m_adjacents.Tiles)
				if (tile != null)
					result += tile.CountTileObjects(type);
			return result;
		}

		public ObjectBase GetTileObject(ulong GUID, OBJECTTYPE type)
		{
			switch (type)
			{
				case OBJECTTYPE.PLAYER:
					return m_players == null ? null : m_players[GUID];
				case OBJECTTYPE.GAMEOBJECT:
					return m_gameObjects == null ? null : m_gameObjects[GUID];
				case OBJECTTYPE.UNIT:
					return m_units == null ? null : m_units[GUID];
			}

			return null;
		}

		public ObjectBase GetObject(ulong GUID, OBJECTTYPE type)
		{
			ObjectBase result = GetTileObject(GUID, type);
			if (result == null)
				foreach (MapTile tile in m_adjacents.Tiles)
					if (tile != null && tile != this && (result = tile.GetTileObject(GUID, type)) != null)
						break;
			return result;
		}

		public ObjectBase GetNearObject(ulong GUID, OBJECTTYPE type, Vector position)
		{
			ObjectBase result = GetTileObject(GUID, type);
			if (result == null)
				foreach (MapTile tile in GetNearestTiles(position))
					if (tile != null && tile != this && (result = tile.GetTileObject(GUID, type)) != null)
						break;
			return result;
		}

		public ObjectBase GetObject(ulong GUID)
		{
			ObjectBase result = GetTileObject(GUID);
			if (result == null)
				foreach (MapTile tile in m_adjacents.Tiles)
					if (tile != null && tile != this && (result = tile.GetTileObject(GUID)) != null)
						break;
			return result;
		}

		public MapTile[] GetNearestTiles(Vector position)
		{
			MapTile[] result = new MapTile[4];

			int shiftx = (int)position.X % Map.TileSize > Map.HalfTileSize ? 1 : -1;
			int shifty = (int)position.Y % Map.TileSize > Map.HalfTileSize ? 1 : -1;

			result[0] = this;
			result[1] = Map.GetTile(m_x + shiftx, m_y);
			result[2] = Map.GetTile(m_x + shiftx, m_y + shifty);
			result[3] = Map.GetTile(m_x, m_y + shifty);

			return result;
		}

		
		public ObjectBase GetNearObject(ulong GUID, Vector position)
		{
			ObjectBase result = GetTileObject(GUID);

			if (result == null)
				foreach (MapTile tile in GetNearestTiles(position))
					if (tile != null && tile != this && (result = tile.GetTileObject(GUID)) != null)
						break;

			return result;
			//return GetObject(GUID);

			//if (result == null)
			//{
			//    int checkX = (int)(Map.TileSize * m_x + Map.HalfTileSize - position.X);
			//    int checkY = (int)(Map.TileSize * m_y + Map.HalfTileSize - position.Y);

			//    if (checkX == 0 && checkY == 0)
			//        return null;

			//    if (result == null && checkX < 0 && Adjacents[(int)ADJACENT.LEFT] != null)
			//        result = Adjacents[(int)ADJACENT.LEFT].GetTileObject(GUID);

			//    if (result == null && checkY < 0 && Adjacents[(int)ADJACENT.TOP] != null)
			//        result = Adjacents[(int)ADJACENT.TOP].GetTileObject(GUID);

			//    if (result == null && checkX > 0 && Adjacents[(int)ADJACENT.RIGHT] != null)
			//        result = Adjacents[(int)ADJACENT.RIGHT].GetTileObject(GUID);

			//    if (result == null && checkY > 0 && Adjacents[(int)ADJACENT.LOWER] != null)
			//        result = Adjacents[(int)ADJACENT.LOWER].GetTileObject(GUID);

			//    if (result == null && checkX < 0 && checkY < 0 && Adjacents[(int)ADJACENT.TOPLEFT] != null)
			//        result = Adjacents[(int)ADJACENT.TOPLEFT].GetTileObject(GUID);

			//    if (result == null && checkX < 0 && checkY > 0 && Adjacents[(int)ADJACENT.LOWERLEFT] != null)
			//        result = Adjacents[(int)ADJACENT.LOWERLEFT].GetTileObject(GUID);

			//    if (result == null && checkX > 0 && checkY < 0 && Adjacents[(int)ADJACENT.TOPRIGHT] != null)
			//        result = Adjacents[(int)ADJACENT.TOPRIGHT].GetTileObject(GUID);

			//    if (result == null && checkX > 0 && checkY > 0 && Adjacents[(int)ADJACENT.LOWERRIGHT] != null)
			//        result = Adjacents[(int)ADJACENT.LOWERRIGHT].GetTileObject(GUID);
			//}
			//return result;
		}
		public ObjectBase GetFarObject(ulong GUID)
		{
			ObjectBase result = GetTileObject(GUID);

			if (result != null)
				return result;

			MapTile[,] tiles = Map.GetBorderTiles(m_x, m_y, 2);

			if (result == null && tiles[1, 2] != null)
				result = tiles[1, 2].GetTileObject(GUID);

			if (result == null && tiles[2, 1] != null)
				result = tiles[2, 1].GetTileObject(GUID);

			if (result == null && tiles[3, 2] != null)
				result = tiles[3, 2].GetTileObject(GUID);

			if (result == null && tiles[2, 3] != null)
				result = tiles[2, 3].GetTileObject(GUID);

			if (result == null && tiles[1, 1] != null)
				result = tiles[1, 1].GetTileObject(GUID);

			if (result == null && tiles[3, 1] != null)
				result = tiles[3, 1].GetTileObject(GUID);

			if (result == null && tiles[3, 3] != null)
				result = tiles[3, 3].GetTileObject(GUID);

			if (result == null && tiles[1, 3] != null)
				result = tiles[1, 3].GetTileObject(GUID);

			if (result == null && tiles[0, 2] != null)
				result = tiles[0, 2].GetTileObject(GUID);

			if (result == null && tiles[2, 0] != null)
				result = tiles[2, 0].GetTileObject(GUID);

			if (result == null && tiles[4, 2] != null)
				result = tiles[4, 2].GetTileObject(GUID);

			if (result == null && tiles[2, 4] != null)
				result = tiles[2, 4].GetTileObject(GUID);

			if (result == null && tiles[1, 0] != null)
				result = tiles[1, 0].GetTileObject(GUID);

			if (result == null && tiles[3, 0] != null)
				result = tiles[3, 0].GetTileObject(GUID);

			if (result == null && tiles[4, 1] != null)
				result = tiles[4, 1].GetTileObject(GUID);

			if (result == null && tiles[4, 3] != null)
				result = tiles[4, 3].GetTileObject(GUID);

			if (result == null && tiles[3, 4] != null)
				result = tiles[3, 4].GetTileObject(GUID);

			if (result == null && tiles[1, 4] != null)
				result = tiles[1, 4].GetTileObject(GUID);

			if (result == null && tiles[0, 3] != null)
				result = tiles[0, 3].GetTileObject(GUID);

			if (result == null && tiles[0, 1] != null)
				result = tiles[0, 1].GetTileObject(GUID);


			return result;
		}

		public ObjectBase GetTileObject(ulong GUID)
		{
			ObjectBase result = null;
			if (result == null && m_units != null)
				result = m_units[GUID];
			if (result == null && m_players != null)
				result = m_players[GUID];
			if (result == null && m_gameObjects != null)
				result = m_gameObjects[GUID];
			return result;
		}

		#region Senders

		public void SendSurrounding(IPacket pkg, ObjectBase obj)
		{
			SendSurrounding(pkg, obj, null);
		}

		public void SendSurrounding(IPacket pkg, ObjectBase obj, PlayerObject except)
		{
			pkg.Aquire();
			
			foreach (MapTile tile in m_adjacents.Tiles)
				if (tile != null && tile.Players != null)
					for (int i = 0; i < tile.Players.Last; i++)
						{
							PlayerObject player = tile.Players.InnerArray[i];
							if (player != null && !player.IsDisposed && player != except && player.CanSee(obj))
								player.BackLink.Client.Send(pkg);
						}
			
			pkg.Release();
		}

		public void SendSurroundingTimed(ShortPacket pkg, ObjectBase obj, PlayerObject except, int timePos)
		{
			SendSurroundingTimed(pkg, obj, except, timePos, 0);
		}

		public void SendSurroundingTimed(ShortPacket pkg, ObjectBase obj, PlayerObject except, int timePos, int shift)
		{
			pkg.Aquire();
			
			foreach (MapTile tile in m_adjacents.Tiles)
				if (tile != null && tile.Players != null)
					for (int i = 0; i < tile.Players.Last; i++)
						{
							PlayerObject player = tile.Players.InnerArray[i];
							if (player != null && !player.IsDisposed && player != except && player.CanSee(obj))
							{
								/*int timestamp = player.BackLink.OwnTimestamp + shift;
								pkg.Set(timePos, timestamp);
								player.BackLink.Client.Send(pkg);*/
								/*if (player.GM && player.SelectionGUID == obj.GUID)
									Chat.System(player.BackLink.Client, string.Format("Send timed packet {0}, time {1}, shift {2}", pkg.MsgID, timestamp, shift));*/
								player.BackLink.AddMovementPacket(pkg, shift, timePos);
							}
						}
			
			pkg.Release();
		}

		public void SendCompressed(DelayedCompressedA9Packet pkg, ObjectBase obj)
		{
			SendCompressed(pkg, obj, null);
		}

		public void SendCompressed(DelayedCompressedA9Packet pkg, ObjectBase obj, PlayerObject except)
		{
			foreach (MapTile tile in m_adjacents.Tiles)
				if (tile != null && tile.Players != null)
					for (int i = 0; i < tile.Players.Last; i++)
						{
							PlayerObject player = tile.Players.InnerArray[i];
							if (player != null && !player.IsDisposed && player != except && player.CanSee(obj))
								player.BackLink.Client.Send(pkg.InnerPacket);
						}
			pkg.Release();
		}

		#endregion

		public void EnterTile(ObjectBase obj)
		{
			OBJECTTYPE type = obj.ObjectType;

			bool do_awake = (type == OBJECTTYPE.PLAYER) && !m_awaken;

			switch (type)
			{
				case OBJECTTYPE.PLAYER:
					if (m_players == null)
						m_players = new FastCollection<PlayerObject>();
					//if (m_players[obj.GUID] != null)
					//{
					//    Console.WriteLine("Warning! Player {0} entering tile second time!", obj.Name);
					//    return;
					//}
					m_players.Add((PlayerObject)obj);
					break;
				case OBJECTTYPE.GAMEOBJECT:
					if (m_gameObjects == null)
						m_gameObjects = new FastCollection<GameObject>();
					//if (m_gameObjects[obj.GUID] != null)
					//{
					//    Console.WriteLine("Warning! Game Object {0} entering tile second time!", obj.Name);
					//    return;
					//}
					m_gameObjects.Add((GameObject)obj);
					break;
				case OBJECTTYPE.UNIT:
					if (m_units == null)
						m_units = new FastCollection<UnitBase>();
					//if (m_units[obj.GUID] != null)
					//{
					//    Console.WriteLine("Warning! Unit {0} entering tile second time!", obj.Name);
					//    return;
					//}
					m_units.Add((UnitBase)obj);
					break;
				default:
					throw new ApplicationException("Unknown object type " + type);
			}

			if (do_awake)
				foreach (MapTile tile in m_adjacents.Tiles)
					if (tile != null)
						tile.Awake();

			if (type == OBJECTTYPE.GAMEOBJECT && ((GameObject)obj).TypeID == 6)
			{
				lock (m_trapsLock)
				{
					if (m_traps == null)
						m_traps = new TrapCollection();

					m_traps[obj.GUID] = new Trap((GameObject) obj, 1.7f, 10000);
				}
				//LogConsole.WriteLine(LogLevel.SYSTEM,"Registered trap " + obj.Name);
			}
		}

		public void LeaveTile(ObjectBase obj)
		{
			if (obj == null)
				return;
			
			OBJECTTYPE type = obj.ObjectType;

			switch (type)
			{
				case OBJECTTYPE.PLAYER:
					if (m_players == null)
						return;
					m_players.Remove((PlayerObject)obj);
                    //if (m_players.Count == 0)
                    //    m_players = null;
					break;
				case OBJECTTYPE.GAMEOBJECT:
					if (m_gameObjects == null)
						return;
					m_gameObjects.Remove((GameObject)obj);
                    //if (m_gameObjects.Count == 0)
                    //    m_gameObjects = null;
					break;
				case OBJECTTYPE.UNIT:
					if (m_units == null)
						return;
					m_units.Remove((UnitBase)obj);
                    //if (m_units.Count == 0)
                    //    m_units = null;
					break;
				default:
					throw new ApplicationException("Unknown object type " + type);
			}

			if (type == OBJECTTYPE.GAMEOBJECT && ((GameObject)obj).TypeID == 6 && m_traps != null)
			{
				lock (m_trapsLock)
				{
					if (m_traps != null)
					{
						m_traps.Remove(obj.GUID);
						if (m_traps.Count == 0)
							m_traps = null;
					}
				}
			}

			bool do_sleep = (type == OBJECTTYPE.PLAYER) && !HasAjPlayers;

			if (do_sleep)
				foreach (MapTile tile in m_adjacents.Tiles)
					if (tile != null)
						tile.Sleep();
		}

		public void OnMove(ObjectBase obj)
		{
			if (m_traps != null && obj is LivingObject)
			{
				lock (m_trapsLock)
				{
					if (m_traps != null)
					{
						List<ulong> toRemove = new List<ulong>();
						foreach (Trap trap in m_traps.Values)
							if (trap.Check((LivingObject) obj))
								toRemove.Add(trap.GUID);

						foreach (ulong key in toRemove)
							m_traps.Remove(key);

						if (m_traps.Count == 0)
							m_traps = null;
					}
				}
			}
		}

		public void Awake()
		{
			if (m_awaken)
				return;

			if (m_units != null)
				for (int i = 0; i < m_units.Last; i++)
				{
					UnitBase unit = m_units.InnerArray[i];
					if (unit != null && !unit.IsDisposed)
						unit.Awake();
				}

			m_awaken = true;
		}

		public void Sleep()
		{
			if (m_awaken == false)
				return;
			if (HasAjPlayers)
				return;
			//m_updater.Finish(EventResult.TERMINATED);
			m_awaken = false;

			m_adjacents.Clear();

			if (m_units != null)
				for (int i = 0; i < m_units.Last; i++)
				{
					UnitBase unit = m_units.InnerArray[i];
					if (unit != null && !unit.IsDisposed)
						unit.Sleep();
				}
		}

		#region SendCreate

		/*public void SendCreate(ObjectBase obj)
		{
			SendCreate(obj, new CompressedA9Packet(obj.CreatePacketSmall));
		}*/

		public void SendCreate(ObjectBase obj, ref IPacket packet, List<A9Packet> packets)
		{
			if (obj is PlayerObject)
				CreateObjects((PlayerObject)obj, packets);

			if (m_players != null)
				for (int i = 0; i < m_players.Last; i++)
				{
					PlayerObject player = m_players.InnerArray[i];
                    if (player != null && !player.IsDisposed && player.CanSee_Create(obj))
                    {
                        if (packet == null)
                        {
                            packet = new CompressedA9Packet(obj.CreatePacketSmall);
                            packet.Aquire();
                        }
                        
                        player.BackLink.Client.Send(packet);
                    }
				}
		}

		#endregion

		#region SendDestroy

		public void SendDestroy(ObjectBase obj, ref IPacket packet, List<ulong> guids)
		{
			if (obj is PlayerObject)
				DestroyObjects((PlayerObject)obj, guids);

			if (m_players != null)
				for (int i = 0; i < m_players.Last; i++)
				{
					PlayerObject player = m_players.InnerArray[i];
                    if (player != null && !player.IsDisposed && player.CanSee_Destroy(obj))
                    {
                        if (packet == null)
                        {
                            packet = obj.DestroyPacket;
                            packet.Aquire();
                        	//Console.WriteLine("Created destroy packet for " + obj.Name);
                        }
                        
                        player.BackLink.Client.Send(packet);
                    }
				}
		}

		#endregion

		#region CreateObjects

		public void CreateObjects(PlayerObject plr, List<A9Packet> toSend)
		{
			if (plr == null || plr.IsDisposed)
				return;

			if (m_units != null)
				for (int i = 0; i < m_units.Last; i++)
				{
					UnitBase unit = m_units.InnerArray[i];
					if (unit != null && !unit.IsDisposed && plr.CanSee_Create(unit))
						toSend.Add(unit.CreatePacketSmall);
				}

			if (m_gameObjects != null)
				for (int i = 0; i < m_gameObjects.Last; i++)
				{
					GameObject gameObject = m_gameObjects.InnerArray[i];
					if (gameObject != null && !gameObject.IsDisposed && plr.CanSee_Create(gameObject))
						toSend.Add(gameObject.CreatePacketSmall);
				}

			/*if (toSend.Count > 0)
				plr.BackLink.Client.Send(new CompressedA9Packet(toSend));*/

			if (m_players != null)
				for (int i = 0; i < m_players.Last; i++)
				{
					PlayerObject player = m_players.InnerArray[i];
					if (player != null && !player.IsDisposed && plr.CanSee_Create(player))
						plr.BackLink.Client.Send(new CompressedA9Packet(player.CreatePacketSmall));
						//toSend.Add(player.CreatePacketSmall);
				}


		}

		#endregion

		#region DestroyObjects

		public void DestroyObjects(PlayerObject plr, List<ulong> guids)
		{
			if (plr.BackLink == null)
				return;
			
			//List<ulong> guids = new List<ulong>();
			//List<ShortPacket> toSend = new List<ShortPacket>();

			if (m_units != null)
				for (int i = 0; i < m_units.Last; i++)
				{
					UnitBase unit = m_units.InnerArray[i];
					if (unit != null && !unit.IsDisposed && plr.CanSee_Destroy(unit))
						guids.Add(unit.GUID);
						//toSend.Add(unit.DestroyPacket);
				}

			if (m_gameObjects != null)
				for (int i = 0; i < m_gameObjects.Last; i++)
				{
					GameObject gameObject = m_gameObjects.InnerArray[i];
					if (gameObject != null && !gameObject.IsDisposed && plr.CanSee_Destroy(gameObject))
						guids.Add(gameObject.GUID);
						//toSend.Add(gameObject.DestroyPacket);
				}
			
			/*if (toSend.Count > 0)
				plr.BackLink.Client.Send(toSend);
			
			toSend.Clear();*/

			if (m_players != null)
				for (int i = 0; i < m_players.Last; i++)
				{
					PlayerObject player = m_players.InnerArray[i];
					if (player != null && !player.IsDisposed && plr.CanSee_Destroy(player))
						guids.Add(player.GUID);
						//toSend.Add(player.DestroyPacket);
				}

			//if (toSend.Count > 0)
				//plr.BackLink.Client.Send(toSend);
		}

		#endregion

		public int ProcessBehaivors()
		{
			if (!m_awaken)
				return 0;

			int active = 0;
			if (m_units != null)
				for (int i = 0; i < m_units.Last; i++)
				{
					UnitBase unit = m_units.InnerArray[i];
					if (unit != null && !unit.IsDisposed)
					{
						unit.BehaivorTick();
						active++;
					}
				}
			return active;
		}

		public int ProcessUpdates()
		{
			if (!m_awaken)
				return 0;

			if (!HasAjPlayers)
			{
				Sleep();
				return 0;
			}
			int active = 0;

			if (HasUpdates)
			{
				List<A9Packet> toSend = new List<A9Packet>();

				if (m_units != null)
					for (int i = 0; i < m_units.Last; i++)
						if (m_units.InnerArray[i] != null && !m_units.InnerArray[i].IsDisposed)
						{
							if (m_units.InnerArray[i].HasPublicUpdates)
							{
								/*if (m_units.InnerArray[i].Attacking)
									SendCompressed(new DelayedCompressedA9Packet(m_units.InnerArray[i].UpdatePacketSmall), m_units.InnerArray[i]);
								else*/
									toSend.Add(m_units.InnerArray[i].UpdatePacketSmall);
								active++;
							}
						}
						else
						m_units.RemoveAt(i);

				if (m_gameObjects != null)
					for (int i = 0; i < m_gameObjects.Last; i++)
						if (m_gameObjects.InnerArray[i] != null && !m_gameObjects.InnerArray[i].IsDisposed)
						{
							if (m_gameObjects.InnerArray[i].HasPublicUpdates)
								toSend.Add(m_gameObjects.InnerArray[i].UpdatePacketSmall);
						}
				else
					m_gameObjects.RemoveAt(i);



				for (int i = 0; i < m_players.InnerArray.Length; i++)
					if (m_players.InnerArray[i] != null && !m_players.InnerArray[i].IsDisposed)
					{
						if (m_players.InnerArray[i].HasUpdates)
							m_players.InnerArray[i].UpdateData(toSend);
					}
					else
						m_players.RemoveAt(i);

				if (toSend.Count > 0)
					SendCompressed(new DelayedCompressedA9Packet(toSend), null);

				//toSend.Clear();

				//if (toSend.Count > 0)
				//    SendCompressed(new DelayedCompressedA9Packet(toSend), null);
			}

			//if (m_players != null)
			//{
			//    for (int i = 0; i < m_players.InnerArray.Length; i++)
			//        if (m_players.InnerArray[i] != null)
			//        {
			//            PlayerObject player = m_players.InnerArray[i];
			//            if (!player.IsDisposed)
			//                player.ForceUpdateData();
			//            else
			//                m_players.RemoveAt(i);
			//        }
			//}

			//#region Player Update bug fix

			//ICollection players = GetObjects(OBJECTTYPE.PLAYER);
			//if (players != null)
			//    lock(players)
			//        foreach (PlayerObject plr in players)
			//            if (!plr.IsDisposed && plr.HasUpdates)
			//                plr.ForceUpdateData();

			//#endregion

			//int count = m_packets.Count;
			//while (count-- > 0)
			//    SendSurrounding((ObjectPacket)m_packets.Dequeue());

			HasUpdates = false;
			return active;
		}
	}
}