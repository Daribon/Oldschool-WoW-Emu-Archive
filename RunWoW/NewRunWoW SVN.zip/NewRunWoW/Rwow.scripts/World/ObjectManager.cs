//
using System.Threading;

namespace RunWoW.World
{
	public class ObjectManager
	{
		private static long m_currentGUID = 4000000;
		
		public static ulong NextGUID()
		{
			return (ulong) Interlocked.Increment(ref m_currentGUID);
		}
	}
}