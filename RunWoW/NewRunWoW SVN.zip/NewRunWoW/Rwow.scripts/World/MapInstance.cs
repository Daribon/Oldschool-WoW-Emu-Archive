//
using System;
using System.Collections;
using System.Collections.Generic;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.World
{
	#region AdjArray
	public class MapAdjacentsArray
	{
		private int m_x;
		private int m_y;
		private MapTileArray m_array;
		private MapTile[] m_tiles;

		public MapAdjacentsArray(MapTileArray array, int x, int y)
		{
			m_x = x;
			m_y = y;
			m_array = array;
		}
		
		private void initTiles()
		{
			m_tiles = new MapTile[9];
			m_tiles[0] = m_array[m_x - 1, m_y + 1];
			m_tiles[1] = m_array[m_x, m_y + 1];
			m_tiles[2] = m_array[m_x + 1, m_y + 1];

			m_tiles[3] = m_array[m_x - 1, m_y];
			m_tiles[4] = m_array[m_x, m_y];
			m_tiles[5] = m_array[m_x + 1, m_y];

			m_tiles[6] = m_array[m_x - 1, m_y - 1];
			m_tiles[7] = m_array[m_x, m_y - 1];
			m_tiles[8] = m_array[m_x + 1, m_y - 1];
		}
		
		public MapTile [] Tiles
		{
			get
			{
				if (m_tiles != null)
					return m_tiles;

				initTiles();
				
				return m_tiles;
			}
		}
		
		public void Clear()
		{
			//m_tiles = null;
		}

		public MapTile this[int aj]
		{
			get { return this[(ADJACENT)aj]; }
		}
		
		public MapTile this[ADJACENT aj]
		{
			get
			{
				if (m_tiles != null)
					return m_tiles[(int) aj];	
				
				switch (aj)
				{
					case ADJACENT.SAME:
						return m_array[m_x, m_y];
					case ADJACENT.LEFT:
						return m_array[m_x - 1, m_y];
					case ADJACENT.RIGHT:
						return m_array[m_x + 1, m_y];
					case ADJACENT.TOP:
						return m_array[m_x, m_y + 1];
					case ADJACENT.LOWER:
						return m_array[m_x, m_y - 1];
					case ADJACENT.TOPLEFT:
						return m_array[m_x - 1, m_y + 1];
					case ADJACENT.TOPRIGHT:
						return m_array[m_x + 1, m_y + 1];
					case ADJACENT.LOWERLEFT:
						return m_array[m_x - 1, m_y - 1];
					case ADJACENT.LOWERRIGHT:
						return m_array[m_x + 1, m_y - 1];
					default:
					case ADJACENT.NONE:
						return null;
				}
			}
		}
	}
	#endregion

	#region MapTileArray
	public class MapTileArray
	{
		private MapTile[,] m_array;
		private int m_maxx;
		private int m_maxy;
		private MapInstance m_map;

		public MapTileArray(MapInstance map, int x, int y)
		{
			m_array = new MapTile[x, y];
			m_maxx = x;
			m_maxy = y;
			m_map = map;
		}

		public MapTile this[int x, int y]
		{
			get
			{
				if (x < 0 || y < 0 || x >= m_maxx || y >= m_maxy)
					return null;

				MapTile result;
				
				if (m_array[x, y] == null)
					result = m_array[x, y] = new MapTile(m_map, new MapAdjacentsArray(this, x, y), x, y);
				else
					result = (MapTile) m_array[x, y];

				return result;
			}
		}

		public bool HasTile(int x, int y)
		{
			return m_array[x, y] != null;
		}
	}
#endregion

	public class MapInstance
	{
		private int m_bottomX;
		private int m_bottomY;
		private int m_topX;
		private int m_topY;
		private int m_tileSize;
		private int m_halfTileSize;
		private MapTileArray m_mapTiles;
		private int m_rows;
		private int m_columns;
		//private DBWorldMap m_map;

		//private CustomArrayList m_transports;
		private CustomArrayList m_healers;

		private int m_ressurectWorld;
		private Vector m_ressurectPoint;

		private uint m_mapId;
		private uint m_shId;

		private MapUpdater m_updater;
		private MapMaintainer m_maintainer;

		private InterlockedInt m_players = new InterlockedInt();

		private uint m_instanceId;
		//private bool m_awaken;


		#region Properties
		
		public uint SpiritHealer
		{
			get { return m_shId; }
		}

		public uint MapID
		{
			get { return m_mapId; }
		}

		public uint InstanceID
		{
			get { return m_instanceId; }
		}

		public CustomArrayList SpiritHealers
		{
			get { return m_healers; }
		}

		public int RessurectWorld
		{
			get { return m_ressurectWorld; }
		}

		public Vector RessurectPoint
		{
			get { return m_ressurectPoint; }
		}

		public MapUpdater Updater
		{
			get { return m_updater; }
		}

		public MapUpdater Behaivor
		{
			get { return m_updater; }
		}
		
		//public MapBehaivor Behaivor
		//{
		//    get { return m_behaivor; }
		//}

		public int TileSize
		{
			get { return m_tileSize; }
		}
		
		public int HalfTileSize
		{
			get { return m_halfTileSize; }
		}

		public int BottomX
		{
			get { return m_bottomX; }
		}

		public int BottomY
		{
			get { return m_bottomY; }
		}
		
		#endregion

		internal MapTile GetTile(int x, int y)
		{
			return m_mapTiles[x, y];
		}

		public MapInstance(DBWorldMap map, uint instanceId)
		{
			//m_map = map;
			m_mapId = map.ObjectId;
			m_instanceId = instanceId;
			m_shId = (uint) map.SpiritHealerID;
			m_ressurectWorld = map.RessurectWorld;
			m_ressurectPoint = map.RessurectPosition;
			m_bottomX = map.BottomX;
			m_bottomY = map.BottomY;
			m_topX = map.TopX;
			m_topY = map.TopY;
			m_tileSize = map.TileSize;
			m_halfTileSize = map.TileSize/2;
			m_columns = (int) Math.Round((m_topX - m_bottomX)/(double) m_tileSize);
			m_rows = (int) Math.Round((m_topY - m_bottomY)/(double) m_tileSize);
			
			m_mapTiles = new MapTileArray(this, m_columns, m_rows);
				//new MapTile[m_columns,m_rows];
			
			//m_transports = new CustomArrayList();
			m_healers = new CustomArrayList();
			//for (int i = 0; i < m_columns; i++)
			//    for (int j = 0; j < m_rows; j++)
			//        m_mapTiles[i, j] = new MapTile(this, i, j);
			
			//for (int x = 0; x < m_columns; x++)
			//    for (int y = 0; y < m_rows; y++)
			//    {
			//        MapTile tile = m_mapTiles[x, y];
			//        tile.Adjacents[0] = GetTile(x - 1, y + 1);
			//        tile.Adjacents[1] = GetTile(x, y + 1);
			//        tile.Adjacents[2] = GetTile(x + 1, y + 1);

			//        tile.Adjacents[3] = GetTile(x - 1, y);
			//        tile.Adjacents[4] = tile;
			//        tile.Adjacents[5] = GetTile(x + 1, y);

			//        tile.Adjacents[6] = GetTile(x - 1, y - 1);
			//        tile.Adjacents[7] = GetTile(x, y - 1);
			//        tile.Adjacents[8] = GetTile(x + 1, y - 1);
			//    }
			bool hasSpawns = InitSpawns(map);
			bool hasGOSpawns = InitGameObjects(map);
			if (!hasSpawns && !hasGOSpawns && m_tileSize < 1000)
				Console.WriteLine("World {0} has {1} tiles (tile size {2}) and no spawns!", m_mapId, m_columns*m_rows, m_tileSize);

			if ((hasSpawns || hasGOSpawns) && m_tileSize > 200)
				Console.WriteLine("World {0} has {1} tiles (tile size {2}) and some spawns!", m_mapId, m_columns*m_rows, m_tileSize);

			m_updater = new MapUpdater(this);
			m_maintainer = new MapMaintainer(this);
			m_maintainer.Start();
			//m_behaivor = new MapBehaivor(this);
		}
		
		private bool InitSpawns(DBWorldMap map)
		{
			if (map.Spawns == null)
				return false; // empty map
			int spawned = 0, skipped = 0, failed = 0;
			LogConsole.WriteLine(LogLevel.TRACE, "Creating spawns for map " + map.ObjectId);

			Dictionary<uint, bool> nspawns = new Dictionary<uint, bool>();

			foreach (DBSpawn spawn in map.Spawns)
				if (spawn != null)
				{
					if (spawn.Creature == null)
					{
						//Console.WriteLine("Creature {0} not found for spawn {1}", spawn.CreatureID, spawn.ObjectId);
						skipped++;
						continue;
					}
					if (/*spawn.Creature.Spawns > 0 && */spawn.Creature.Named && nspawns.ContainsKey(spawn.CreatureID) /*Title.Length>0*/)
					{
						//Console.WriteLine("Creature {0}<{1}> spawned more than once!", spawn.Creature.Name, spawn.Creature.Title);
						skipped++;
						continue;
					}
					try
					{
						MapTile tile = GetTileByLoc(spawn.Position);
						if (tile == null)
						{
							LogConsole.WriteLine(LogLevel.WARNING,
							                     string.Format("Creature {0} spawning with incorrect position for spawn {1}", spawn.CreatureID, spawn.ObjectId));
							skipped++;
							continue;
						}

						bool skip = false;

						foreach (MapTile mapTile in tile.Adjacents.Tiles)
							if (mapTile != null)
							{
								ICollection collection = mapTile.GetObjects(OBJECTTYPE.UNIT);
								if (collection != null)
									foreach (UnitBase ounit in collection)
										if (ounit != null)
										{
											double distance = ounit.Position.DistanceFlat(spawn.Position);
											if ((distance < Constants.MinSpawnRange && ((ounit.Entry == spawn.Creature.Entry || ounit.Creature.Name == spawn.Creature.Name))) || distance < 1f)
											{
												LogConsole.WriteLine(LogLevel.TRACE, string.Format("Skipping spawn {0} dye to to high population", spawn.ObjectId));
												skipped++;
												skip = true;
												Database.Instance.ResolveRelations(spawn, typeof (DBMovepoint));
												//if (distance < 2)
												{
													//Database.Instance.FillObjectRelation(spawn,typeof(DBMovepoint));
													foreach (DBMovepoint mp in spawn.Movepoints)
														DBManager.EraseDBObject(mp);
													DBManager.EraseDBObject(spawn);
												}
												break;
											}
										}
							}

						if (skip)
							continue;

						if (spawn.Creature.Named)
							nspawns[spawn.CreatureID] = true;
						//spawn.Creature.Spawns++;
						
						if (spawn.CreatureID == SpiritHealer)
						{
							if (spawn.Speech == null)
							{
								spawn.BehaivorID = 9;
								spawn.Flags = 0x200166;
								DBManager.SaveDBObject(spawn);
								Database.Instance.ResolveRelations(spawn, typeof (DBSpeech));
							}
						}
						else
							if (spawn.Loot == null)
								Database.Instance.ResolveRelations(spawn, true);

						UnitBase unit = AIManager.CreateMobile(spawn);
						//LogConsole.WriteLine("Spawning: " + unit.Name + "(" + unit.Level + ") at " + unit.Position.X + " " + unit.Position.Y + " " + unit.Position.Z);

						spawned++;
						EnterNocreate(unit);
						spawn.Active = true;
						if (unit.Entry == SpiritHealer)
							SpiritHealers.Add(unit);
					}
					catch (Exception e)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Error while initializing spawn " + spawn.ObjectId + ": " + e);
						failed++;
						continue;
					}
				}
			LogConsole.WriteLine(LogLevel.TRACE,
			                     string.Format("Spawned {0}, skipped {1}, failed {2} mobiles", spawned, skipped, failed));
			return spawned > 0;
		}

		private bool InitGameObjects(DBWorldMap map)
		{
			if (map.GameObjects == null)
				return false; // empty map
			int spawned = 0, skipped = 0, failed = 0;
			LogConsole.WriteLine(LogLevel.TRACE, "Creating game objects for map " + map.ObjectId);
			foreach (DBGameObject go in map.GameObjects)
				if (go != null)
				{
					if (go.Template == null)
					{
						LogConsole.WriteLine(LogLevel.WARNING, string.Format("Template {0} not found for go spawn {1}", go.TemplateID, go.ObjectId));
						skipped++;
						continue;
					}
					//if (go.Template.Transport)
					//{
					//    m_transports.Add(new GameObject(go));
					//    continue;
					//}
					try
					{
						MapTile tile = GetTileByLoc(go.Position);
						if (tile == null)
						{
							LogConsole.WriteLine(LogLevel.WARNING,
							                     "Game object " + go.TemplateID + " spawning with incorrect position for spawn " +
							                     go.ObjectId);
							skipped++;
							continue;
						}
						bool skip = false;

						foreach (MapTile mapTile in tile.Adjacents.Tiles)
							if (mapTile != null)
							{
								ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
								if (collection != null)
									foreach (GameObject ogo in collection)
										if (ogo != null && ogo.Entry == go.TemplateID)
										{
											double distance = ogo.Position.DistanceAvr(go.Position);
											/*if (distance < 1)
                                            {
                                                DBManager.EraseDBObject(go);
                                                break;
                                            }
                                            if (ogo.Entry != go.TemplateID)
                                                continue;*/
											if (distance < Constants.MinGOSpawnRange)
											{
												LogConsole.WriteLine(LogLevel.TRACE, "Skipping go spawn " + go.ObjectId + " dye to to high population");
												skipped++;
												skip = true;
												if (distance < 3)
													DBManager.EraseDBObject(go);
												break;
											}
										}
							}

						if (skip)
							continue;


						Database.Instance.ResolveRelations(go, typeof(DBGOLoot));
						
						GameObject obj = new GameObject(go);
						//LogConsole.WriteLine("Spawning: " + unit.Name + "(" + unit.Level + ") at " + unit.Position.X + " " + unit.Position.Y + " " + unit.Position.Z);

						spawned++;
						go.Active = true;
						EnterNocreate(obj);
					}
					catch (Exception e)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Error while initializing go spawn " + go.ObjectId + ": " + e);
						failed++;
						continue;
					}
				}
			LogConsole.WriteLine(LogLevel.TRACE,
			                     "Placed " + spawned + ", skipped " + skipped + ", failed " + failed + " game objects");
			return spawned > 0;
		}

		public MapTile GetTileByLoc(Vector Position)
		{
			return GetTileByLoc((int) Position.X, (int) Position.Y);
		}

		public MapTile GetTileByLoc(int x, int y)
		{
			unchecked
			{
				int column = (x - m_bottomX) / m_tileSize;
				int row = (y - m_bottomY) / m_tileSize;
				if (column >= m_columns)
					column = m_columns - 1;
				if (row >= m_rows)
					row = m_rows - 1;
				if (column < 0)
					column = 0;
				if (row < 0)
					row = 0;
				return m_mapTiles[column, row];
			}
		}

		public MapTile[] GetNearestTiles(Vector position)
		{
			MapTile[] result = new MapTile[4];

			int shiftx = (int)position.X % TileSize > HalfTileSize ? 1 : -1;
			int shifty = (int)position.Y % TileSize > HalfTileSize ? 1 : -1;

			result[0] = GetTileByLoc((int)position.X, (int)position.Y);
			result[1] = GetTile(result[0].X + shiftx, result[0].Y);
			result[2] = GetTile(result[0].X + shiftx, result[0].Y + shifty);
			result[3] = GetTile(result[0].X, result[0].Y + shifty);

			return result;
		}
		//public MapTile[] GetBorderTilesByCount(Vector Position, int borderCount)
		//{
		//    return GetBorderTilesByCount((int) Position.X, (int) Position.Y, borderCount);
		//}

		public MapTile[,] GetBorderTiles(int column, int row, int borderCount)
		{
			int startX = column - borderCount;
			int startY = row - borderCount;
			int endX = column + borderCount + 1;
			int endY = row + borderCount + 1;
			MapTile[,] tiles = new MapTile[(borderCount + 1)* 2, (borderCount + 1)* 2];
			for (int i = startX; i < endX; i++)
				for (int j = startY; j < endY; j++)
					tiles[i - startX, j - startY] = (i>= 0 && i<m_columns && j>=0 && j<m_rows) ? m_mapTiles[i, j] : null;
			return tiles;
		}

		//public MapTile[] GetBorderTilesByRange(Vector Position, int range)
		//{
		//    return GetBorderTilesByCount((int) Position.X, (int) Position.Y, range/m_tileSize);
		//}

		//public MapTile[] GetBorderTilesByRange(int xPos, int yPos, int range)
		//{
		//    return GetBorderTilesByCount(xPos, yPos, range/m_tileSize);
		//}

		//public MapTile[] GetTilesInRange(Vector Position, int range)
		//{
		//    return GetTilesInRange((int) Position.X, (int) Position.Y, range);
		//}

		//public MapTile[] GetTilesInRange(int xPos, int yPos, int range)
		//{
		//    xPos -= m_bottomX;
		//    yPos -= m_bottomY;
		//    int startX = (xPos - range)/m_tileSize;
		//    int startY = (yPos - range)/m_tileSize;
		//    int endX = ((xPos + range)/m_tileSize) + 1;
		//    int endY = ((yPos + range)/m_tileSize) + 1;
		//    if (endX > m_columns) endX = m_columns;
		//    if (endY > m_rows) endY = m_rows;
		//    int xTiles = endX - startX;
		//    int yTiles = endY - startY;
		//    MapTile[] Tiles = new MapTile[xTiles*yTiles];
		//    for (int i = 0; i < xTiles; i++)
		//        for (int j = 0; j < yTiles; j++)
		//            Tiles[i*yTiles + j] = m_mapTiles[startX + i, startY + j];
		//    return Tiles;
		//}

		//		public void Send(MapTile tile, ShortPacket pkg, Vector position, float range)
		//		{
		//			float range_sqrd = range*range;
		//			foreach (MapTile mapTile in tile.Adjacents)
		//			if (mapTile!=null)
		//			{
		//				ICollection coll = mapTile.GetObjects(OBJECTTYPE.PLAYER);
		//				if (coll!=null)
		//					foreach (PlayerObject player in coll)
		//					if (player != null && position.DistanceSqrd(player.Position) <= range_sqrd)
		//						player.BackLink.Client.Send(pkg);
		//			}
		//		}

		/*public ICollection[] GetNearestObjects(MapTile Tile, OBJECTTYPE type)
        {
            ICollection [] result;
            if (Tile != null)
            {
                int count = 0;
                foreach (MapTile tile in Tile.Adjacents)
                    if (tile != null && tile.CountObjects(type)>0)
                        count ++;

                result = new ICollection[count];
                int i = 0;
                foreach (MapTile tile in Tile.Adjacents)
                    if (tile != null)
                    {
                        ICollection objects = tile.GetObjects(type);
                        if (objects.Count>0)
                        {
                            result[i] = objects;
                            i++;
                        }
                    }
                return result;
            }
            return new ICollection[0];
        }*/

		/// <summary>
		/// 
		/// </summary>
		/// <param name="obj"></param>
		/// <returns>Returns true if position was changed</returns>
		public bool SetObjectPositionInBounds(ObjectBase obj)
		{
			return SetObjectPositionInBounds(obj, 0);
		}

		public bool SetObjectPositionInBounds(ObjectBase obj, int Gap)
		{
			float x = obj.Position.X;
			float y = obj.Position.Y;
			bool retval = false;
			if (x < m_bottomX + Gap)
			{
				x = m_bottomX + Gap;
				retval = true;
			}
			else if (x > m_topX - Gap)
			{
				x = m_topX - Gap;
				retval = true;
			}
			if (y < m_bottomY + Gap)
			{
				y = m_bottomY + Gap;
				retval = true;
			}
			else if (y > m_topY - Gap)
			{
				y = m_topY - Gap;
				retval = true;
			}
			if (retval)
				obj.Position = new Vector(x, y, obj.Position.Z);
			return retval;
		}

		public sbyte FlipHorizontal(ObjectBase obj, MapInstance Left, MapInstance Right, int Gap)
		{
			sbyte retval = 0;
			float x = obj.Position.X;
			float y = obj.Position.Y;
			if (obj.MapTile.Map.MapID == Left.MapID && x >= Left.m_topX - Gap)
			{
				x = Right.m_bottomX + Gap;
				retval = 1;
			}
			if (obj.MapTile.Map.MapID == Right.MapID && x <= Right.m_bottomX + Gap)
			{
				x = Left.m_topX - Gap;
				retval = -1;
			}
			if (retval != 0)
				obj.Position = new Vector(x, y, obj.Position.Z + 10);
			return retval;
		}

		public sbyte FlipVertical(ObjectBase obj, MapInstance Top, MapInstance Bottom, int Gap, ref Vector teleTo)
		{
			sbyte retval = 0;
			//float x = obj.Position.X;
			float y = obj.Position.Y;
			if (obj.MapTile.Map.MapID == Top.MapID && y <= Top.m_bottomY + Gap)
			{
				y = Bottom.m_topY - Gap;
				retval = 1;
			}
			if (obj.MapTile.Map.MapID == Bottom.MapID && y >= Bottom.m_topY - Gap)
			{
				y = Top.m_bottomY + Gap;
				retval = -1;
			}
			if (retval != 0)
			{
				teleTo.Y = y;
				LogConsole.WriteLine(LogLevel.SYSTEM, "Teleport y = " + y);
			}
			teleTo.Z = obj.Position.Z + 10;
			return retval;
		}

		public void EnterNocreate(ObjectBase obj)
		{
			MapTile mapTile = GetTileByLoc(obj.Position);

			if (obj.MapTile == mapTile)
				return;
			if (obj.MapTile != null)
				LogConsole.WriteLine(LogLevel.ERROR, "Warning, entering tile {0}, while last tile is {1}", mapTile, obj.MapTile);

			obj.MapTile = mapTile;

			mapTile.EnterTile(obj);
		}
		
		public void PlayerReenter(PlayerObject player)
		{
			List<A9Packet> packets = new List<A9Packet>();

			foreach (MapTile tile in player.MapTile.Adjacents.Tiles)
				if (tile != null)
					tile.CreateObjects(player, packets);

			if (packets.Count > 0)
				player.BackLink.Client.Send(new CompressedA9Packet(packets));
		}

		public void Enter(ObjectBase obj)
		{
			MapTile mapTile = GetTileByLoc(obj.Position);

			if (obj.MapTile == mapTile)
				return;
			/*if (obj.MapTile != null)
				LogConsole.WriteLine(LogLevel.ERROR, "Warning, entering tile {0}, while last tile is {1}", mapTile, obj.MapTile);*/
			
			obj.MapTile = mapTile;

			bool isPlayer = obj is PlayerObject;

			IPacket create = null;
			List<A9Packet> packets = isPlayer ? new List<A9Packet>() : null;

			foreach (MapTile tile in obj.MapTile.Adjacents.Tiles)
				if (tile != null)
					tile.SendCreate(obj, ref create, packets);

            if (create != null)
                create.Release();

			if (isPlayer && packets.Count > 0)
				((PlayerObject) obj).BackLink.Client.Send(new CompressedA9Packet(packets));
		    
		    mapTile.EnterTile(obj);

			if (isPlayer)
				m_players.Add(1);

			if ((int)m_players > 0/* && !m_awaken*/)
			{
				m_updater.Start();
				//m_behaivor.Start();
				//m_awaken = true;
			}
		}

		//public void LoggedEnter(ObjectBase obj, DateTime time)
		//{
		//    MapTile mapTile = GetTileByLoc(obj.Position);

		//    if (obj.MapTile == mapTile)
		//        return;
		//    if (obj.MapTile != null)
		//        LogConsole.WriteLine(LogLevel.ERROR, "Warning, entering tile {0}, while last tile is {1}", mapTile, obj.MapTile);
			
		//    obj.MapTile = mapTile;

		//    IPacket create = null;


		//    //Console.WriteLine("-- Compressed create created in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

		//    foreach (MapTile tile in obj.MapTile.Adjacents.Tiles)
		//        if (tile != null)
		//            tile.SendCreate(obj, ref create);
		//    //Console.WriteLine("-- Adjanced tiles processed in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

		//    if (create is CompressedA9Packet)
		//        ((CompressedA9Packet)create).Body.Release();
		    
		//    mapTile.EnterTile(obj);

		//    Console.WriteLine("-- Tile entered in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

		//    if (obj is PlayerObject)
		//        m_players.Add(-1);

		//    if ((int)m_players > 0/* && !m_awaken*/)
		//    {
		//        m_updater.Start();
		//        //m_behaivor.Start();
		//        //Console.WriteLine("-- Updater started entered in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

		//        //m_awaken = true;
		//    }
		//}

		public void Leave(ObjectBase obj)
		{
			Leave(obj, false);
		}

		public void Leave(ObjectBase obj, bool noClear)
		{
			if (obj == null || obj.MapTile == null)
				return;
			
			obj.MapTile.LeaveTile(obj);

			//Console.WriteLine("Object " + obj.Name + " leaving tile");

			IPacket pkg = null;// obj.DestroyPacket;

			bool isPlayer = obj is PlayerObject;
			List<ulong> guids = isPlayer ? new List<ulong>() : null;

			foreach (MapTile tile in obj.MapTile.Adjacents.Tiles)
				if (tile != null)
					tile.SendDestroy(obj, ref pkg,guids);

			if (pkg != null)
				pkg.Release();

			if (isPlayer && guids.Count > 0)
				((PlayerObject)obj).BackLink.Client.Send(new CompressedA9Packet(ObjectBase.CreateDestroyPacket(guids)));

			if (!noClear)
				obj.MapTile = null;

			if (obj is PlayerObject)
			{
				m_players.Add(-1);

				if ((int) m_players <= 0)
				{
					m_updater.Finish(EventResult.TERMINATED);
					//m_behaivor.Finish(EventResult.TERMINATED);
				}
			}
		}

		public void CreateTransports(PlayerObject Player)
		{
			//CustomArrayList toSend = new CustomArrayList();
			//foreach (GameObject go in m_transports)
			//    toSend.AddRange(go.CreatePacketSmall);

			//if (toSend.Count > 0)
			//    Player.BackLink.Client.Send(new CompressedA9Packet(toSend));
			//toSend.Dispose();
		}

		public void DeleteTransports(PlayerObject Player)
		{
			//foreach (GameObject go in m_transports)
			//    Player.BackLink.Client.Send(go.DestroyPacket);
		}

		public void Reenter(ObjectBase obj)
		{
			Leave(obj, false);
			Enter(obj);
		}

		internal void Move(ObjectBase obj)
		{
			MapTile newTile;
			/*try
			{*/
			newTile = GetTileByLoc(obj.Position);
			/*}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR,
				                     "Error while getting location for " + obj.Position + ", world " + MapID + ", object " + obj +
				                     ": " + e.ToString());
				obj.MapTile = null; // drop it
				return;
			}*/

			MapTile oldTile = obj.MapTile;
			if (newTile == oldTile)
			{
				oldTile.OnMove(obj);
				return;
			}

			if (newTile == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Object {0} gone to empty tile", obj.Name);
				Leave(obj);
				//obj.MapTile = null; // drop it
				return;
			}

			ADJACENT adj = oldTile.IsAdjacent(newTile);
			if (adj == ADJACENT.NONE)
			{
				Reenter(obj);
				return;
			}

			oldTile.LeaveTile(obj);
			obj.MapTile = newTile;
			newTile.EnterTile(obj);

			IPacket cPacket = null;// new CompressedA9Packet(obj.CreatePacketSmall);
			IPacket dPacket = null;//  obj.DestroyPacket;

			bool isPlayer = obj is PlayerObject;

			List<A9Packet> packets = isPlayer ? new List<A9Packet>() : null;
			List<ulong> guids = isPlayer ? new List<ulong>() : null;

			switch (adj)
			{
				case ADJACENT.TOPLEFT:
					oldTile.AdjacentDestroyObject(ADJACENT.TOPRIGHT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.RIGHT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERRIGHT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWER, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERLEFT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.TOPRIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOP, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOPLEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWERLEFT, obj, ref cPacket, packets);
					break;
				case ADJACENT.TOP:
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWER, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERRIGHT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.TOPLEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOP, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOPRIGHT, obj, ref cPacket, packets);
					break;
				case ADJACENT.TOPRIGHT:
					oldTile.AdjacentDestroyObject(ADJACENT.TOPLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWER, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERRIGHT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.TOPLEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOP, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOPRIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.RIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWERRIGHT, obj, ref cPacket, packets);
					break;
				case ADJACENT.LEFT:
					oldTile.AdjacentDestroyObject(ADJACENT.TOPRIGHT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.RIGHT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERRIGHT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.TOPLEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWERLEFT, obj, ref cPacket, packets);
					break;
				case ADJACENT.RIGHT:
					oldTile.AdjacentDestroyObject(ADJACENT.TOPLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERLEFT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.TOPRIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.RIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWERRIGHT, obj, ref cPacket, packets);
					break;
				case ADJACENT.LOWERLEFT:
					oldTile.AdjacentDestroyObject(ADJACENT.TOPLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.TOP, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.TOPRIGHT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.RIGHT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERRIGHT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.LOWERRIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWER, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWERLEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOPLEFT, obj, ref cPacket, packets);
					break;
				case ADJACENT.LOWER:
					oldTile.AdjacentDestroyObject(ADJACENT.TOPLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.TOP, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.TOPRIGHT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.LOWERLEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWER, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWERRIGHT, obj, ref cPacket, packets);
					break;
				case ADJACENT.LOWERRIGHT:
					oldTile.AdjacentDestroyObject(ADJACENT.LOWERLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.LEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.TOPLEFT, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.TOP, obj, ref dPacket, guids);
					oldTile.AdjacentDestroyObject(ADJACENT.TOPRIGHT, obj, ref dPacket, guids);

					newTile.AdjacentCreateObject(ADJACENT.LOWERLEFT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWER, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.LOWERRIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.RIGHT, obj, ref cPacket, packets);
					newTile.AdjacentCreateObject(ADJACENT.TOPRIGHT, obj, ref cPacket, packets);
					break;
			}

			if (cPacket != null)
				cPacket.Release();

			if (dPacket != null)
				dPacket.Release();

			if (isPlayer)
			{
				if (guids.Count > 0)
					((PlayerObject)obj).BackLink.Client.Send(new CompressedA9Packet(ObjectBase.CreateDestroyPacket(guids)));

				if (packets.Count>0)
					((PlayerObject)obj).BackLink.Client.Send(new CompressedA9Packet(packets));
			}

			//Console.WriteLine("Enter new tile");
			//Console.WriteLine("Tile Entered");
		}

		public void AddDespawn(ObjectBase objectBase, int time)
		{
			m_maintainer.EnqueueDespawn(objectBase, time);
		}

		public void AddUnitRespawn(DBSpawn spawn, int time)
		{
			m_maintainer.EnqueueUnitRespawn(spawn, time);
		}

		public void AddGORespawn(DBGameObject go, int time)
		{
			m_maintainer.EnqueueGORespawn(go, time);
		}

		public class MapUpdater : Event
		{
			private static int UpdateTime = Constants.MapTileUpdateTime;

			private int m_active = 0;
			private int m_behaivorsActive = 0;
			private DateTime m_lastTick = CustomDateTime.Now;
			
			private MapInstance m_map;

			public int Active
			{
				get { return m_active; }
			}

			public int BehaivorsActive
			{
				get { return m_behaivorsActive; }
			}

			public MapUpdater(MapInstance map)
				: base(TimeSpan.FromMilliseconds(UpdateTime))
			{
				if (!Constants.UseRepeatingUpdater)
					Interval = TimeSpan.FromMilliseconds(UpdateTime);
				m_map = map;
				ExecPriority = ExecutionPriority.QCriticalSecond;
				Priority = TimerPriority.TwoFiftyMS;
			}

			protected override void OnTick()
			{
				if (m_map == null)
				{
					Finish(EventResult.ERROR);
					return;
				}

				try
				{
					if (m_lastTick + Delay <= CustomDateTime.Now)
					{
						int active = 0;
						int behaivorsActive = 0;

						for (int i = 0; i < m_map.m_columns; i++)
							for (int j = 0; j < m_map.m_rows; j++)
								if (m_map.m_mapTiles.HasTile(i, j))
								{
									MapTile tile = m_map.m_mapTiles[i, j];
									if (tile != null/* && tile.Awaken*/)
									{
										try
										{
                                            active+=tile.ProcessUpdates();
										}
										catch (Exception ex)
										{
											LogConsole.WriteLine(LogLevel.ERROR, "Updates failed for tile {0},{1}: {2}", i, j, ex);
										}

										try
										{
											behaivorsActive += tile.ProcessBehaivors();
										}
										catch (Exception ex)
										{
											LogConsole.WriteLine(LogLevel.ERROR, "Behaivors failed for tile {0},{1}: {2}", i, j, ex.Message);
										}
									}
								}

						m_active = active;
						m_behaivorsActive = behaivorsActive;
						m_lastTick = CustomDateTime.Now;
					}
				}
				finally
				{
					//m_map.m_updater = new MapUpdater(m_map);
					//m_map.m_updater.Start();
					if (Constants.UseRepeatingUpdater)
						Restart();
				}
			}
		}

		public class MapMaintainer : Event
		{
			private static int UpdateTime = 15000;

			private DateTime m_lastTick = CustomDateTime.Now;

			private MapInstance m_map;

			private SynchronizedDictionary<ObjectBase, DateTime> m_toDespawn;
			private SynchronizedDictionary<DBSpawn, DateTime> m_toUnitRespawn;
			private SynchronizedDictionary<DBGameObject, DateTime> m_toGORespawn;

			public MapMaintainer(MapInstance map)
				: base(TimeSpan.FromMilliseconds(UpdateTime), TimeSpan.FromMilliseconds(UpdateTime))
			{
				m_map = map;
				ExecPriority = ExecutionPriority.QSeparateSecond;
				Priority = TimerPriority.FiveSeconds;
				m_toDespawn = new SynchronizedDictionary<ObjectBase, DateTime>();
				m_toUnitRespawn = new SynchronizedDictionary<DBSpawn, DateTime>();
				m_toGORespawn = new SynchronizedDictionary<DBGameObject, DateTime>();
			}

			protected override void OnTick()
			{
				if (m_map == null)
				{
					Finish(EventResult.ERROR);
					return;
				}

				if (m_lastTick + Delay <= CustomDateTime.Now)
				{
					List<ObjectBase> toDespawn = new List<ObjectBase>();
					m_toDespawn.Lock();
					foreach (KeyValuePair<ObjectBase, DateTime> pair in m_toDespawn)
						if (pair.Value < CustomDateTime.Now)
							toDespawn.Add(pair.Key);
					m_toDespawn.Unlock();

					List<DBSpawn> toUnitRespawn = new List<DBSpawn>();
					m_toUnitRespawn.Lock();
					foreach (KeyValuePair<DBSpawn, DateTime> pair in m_toUnitRespawn)
						if (pair.Value < CustomDateTime.Now)
							toUnitRespawn.Add(pair.Key);
					m_toUnitRespawn.Unlock();


					List<DBGameObject> toGORespawn = new List<DBGameObject>();
					m_toGORespawn.Lock();
					foreach (KeyValuePair<DBGameObject, DateTime> pair in m_toGORespawn)
						if (pair.Value < CustomDateTime.Now)
							toGORespawn.Add(pair.Key);
					m_toGORespawn.Unlock();

					foreach (ObjectBase obj in toDespawn)
					{
						m_toDespawn.Remove(obj);
						obj.Dispose();
					}

					foreach (DBSpawn spawn in toUnitRespawn)
					{
						m_toUnitRespawn.Remove(spawn);
						UnitBase.Respawn(m_map, spawn);
					}

					foreach (DBGameObject go in toGORespawn)
					{
						m_toGORespawn.Remove(go);
						GameObject.Respawn(m_map, go);
					}

					m_lastTick = CustomDateTime.Now;
				}
			}

			public void EnqueueDespawn(ObjectBase obj, int time)
			{
				m_toDespawn[obj] = CustomDateTime.Now.AddSeconds(time);
			}

			public void EnqueueUnitRespawn(DBSpawn spawn, int time)
			{
				m_toUnitRespawn[spawn] = CustomDateTime.Now.AddSeconds(time);
			}

			public void EnqueueGORespawn(DBGameObject go, int time)
			{
				m_toGORespawn[go] = CustomDateTime.Now.AddSeconds(time);
			}
		}
		
	}
}