//
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.Objects;

namespace RunWoW.GameObjects
{
	public delegate void GameObjectAction(LivingObject user, GameObject target);

	public class GOManager
	{
		private static Hashtable m_goTypes = new Hashtable();

		public static void RegisterType(GameObjectType type, GameObjectAction handler)
		{
			m_goTypes[type] = handler;
		}

		public static void ProcessGOUse(LivingObject user, GameObject target)
		{
			GameObjectType type = (GameObjectType) target.Template.TypeID;

			if (m_goTypes.ContainsKey(type))
				((GameObjectAction) m_goTypes[type])(user, target);
			else
				LogConsole.WriteLine(LogLevel.SYSTEM, "Unhandled GO use type: " + type);
		}
	}
}