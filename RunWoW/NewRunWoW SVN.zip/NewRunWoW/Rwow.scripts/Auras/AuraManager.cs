using System.Collections.Generic;
using System.Collections.Specialized;
using RunServer.Common;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public delegate SpellFailedReason AuraCast(
		ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum);

	public class AuraManager
	{
		private static HybridDictionary m_auras = new HybridDictionary();
		private static AuraCast DefaultAura = new AuraCast(BaseAura.Apply<BaseAura>);
		private static Dictionary<uint, Dictionary<byte, AuraCast>> m_auraEffectPatches = new Dictionary<uint, Dictionary<byte, AuraCast>>();

		public static void RegisterAura(AURAEFFECT ID, AuraCast handler)
		{
			m_auras[ID] = handler;
		}

		public static void RegisterAuraEffectPatch(uint spellId, byte effect, AuraCast handler)
		{
			if (!m_auraEffectPatches.ContainsKey(spellId))
				m_auraEffectPatches[spellId] = new Dictionary<byte, AuraCast>();

			m_auraEffectPatches[spellId][effect] = handler;
		}

		public static SpellFailedReason ProcessAura(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte effnum)
		{
			if (caster == null || target == null || spell == null)
				return SpellFailedReason.MAX;
			
			AURAEFFECT effect = spell.Effect[effnum].Aura;

			AuraCast handler;
			
			if (m_auraEffectPatches.ContainsKey(spell.ObjectId) && m_auraEffectPatches[spell.ObjectId].ContainsKey(effnum))
				handler = m_auraEffectPatches[spell.ObjectId][effnum];
			else
				handler = (AuraCast) m_auras[effect];
			
			if (handler == null)
			{
				LogConsole.WriteLine(LogLevel.TRACE, "Not handled Aura type: " + effect);
				handler = DefaultAura;
			}
			return handler(caster, target, castTarget, spell, effnum);
		}
	}
}