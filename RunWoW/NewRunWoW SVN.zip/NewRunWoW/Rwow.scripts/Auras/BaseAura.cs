using System;
using System.Threading;
using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Objects.Misc;
using RunWoW.SpellAuras;
using RunWoW.Spells;

namespace RunWoW.Auras
{
	public class BaseAura : CountedObject, IAura
	{
		public static int TotalAuras;
		
		ObjectReference m_caster;
		ObjectReference m_target;
		ObjectReference m_castTarget;
		DBSpell m_spell;
		byte m_effect;
		bool m_finished;
		bool m_cleaned;

		private int m_interval;
		private int m_count;
		private int m_forceVisible;

		private DateTime m_lastTick;
		
		private long m_id;

		private int m_auraNumber;
		
		private bool m_cancelable;

		private int m_castNumber;
		
		#region Properties

		public ObjectBase Caster
		{
			get { return m_caster.Target; }
		}
		
		public ulong CasterGUID
		{
			get { return m_caster.GUID;  }
		}
		
		public LivingObject LivingCaster
		{
			get { return m_caster.AsLiving;  }
		}

		public PlayerObject PlayerCaster
		{
			get { return m_caster.AsPlayer;  }
		}

		public ObjectBase Target
		{
			get { return m_target.Target; }
		}

		public LivingObject LivingTarget
		{
			get { return m_target.AsLiving; }
		}
		
		public PlayerObject PlayerTarget
		{
			get { return m_target.AsPlayer; }
		}
		
		public ObjectBase CastTarget
		{
			get { return m_castTarget == null ? null : m_castTarget.Target; }
		}

		public DBSpell Spell
		{
			get { return m_spell; }
		}
		
		public SpellEffect SpellEffect
		{
			get { return m_spell.Effect[m_effect];  }
		}

		public byte Effect
		{
			get { return m_effect; }
		}

		public bool Visible
		{
			get { return m_forceVisible != -1 ? m_forceVisible == 1 : !m_spell.Passive; }
			set { m_forceVisible = value ? 1 : 0; }
		}

		public bool Finished
		{
			get { return m_finished; }
		}

		public long ID
		{
			get { return m_id; }
			set { m_id = value; }
		}
		
		public int Interval
		{
			get { return m_interval; }
		}

		public int Count
		{
			get { return m_count; }
		}

		public bool Cancelable
		{
			get { return m_cancelable; }
			protected set { m_cancelable = value; }
		}

		public int Number
		{
			get { return m_auraNumber; }
		}

		public int CastNumber
		{
			get { return m_castNumber; }
		}

		public DateTime LastTick
		{
			get { return m_lastTick; }
			set { m_lastTick = value; }
		}

		public int AuraKey
		{
			get
			{
				int result = 0;
				
				if (m_spell.IsCurse)
					result |= 1;
				
				if (m_spell.IsAspect)
					result |= 2;
				
				if (m_spell.IsSeal)
					result |= 4;
				
				if (m_spell.IsTrack)
					result |= 8;

				if (m_spell.IsShapeshift)
					result |= 16;
				
				if (m_spell.HasAura(AURAEFFECT.SCALE))
					result |= 32;

				if (m_spell.IsBlessing)
					result |= 64;
				
				if (m_spell.IsPaladinAura)
					result |= 128;
				
				if (m_spell.IsSting)
					result |= 256;
				
				return result;
			}
		}

		public long EffectKey
		{
			get
			{
				return
					((int) CasterGUID) << 32 + ((byte) Caster.HierType) << 24 + ((byte) SpellEffect.Aura) <<
					16 + ((short) SpellEffect.AuraParam);
			}
		}
		#endregion
		
		/*private static readonly HandleCollector AuraHandleCollector =
			new HandleCollector("BaseAura", 3000, 10000);
		*/
		public BaseAura()
		{
			Interlocked.Increment(ref TotalAuras);
		//	AuraHandleCollector.Add();
		}

		~BaseAura()
		{
		//	AuraHandleCollector.Remove();
			Interlocked.Decrement(ref TotalAuras);
		}

		protected virtual bool AuraStart()
		{
			return true;
		}

		protected virtual void AuraTick()
		{

		}

		protected virtual void AuraFinish()
		{

		}

		public void Init(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte effect)
		{
			m_caster = caster.Reference;
			m_target = target.Reference;
			m_castTarget = castTarget == null ? null : castTarget.Reference;
			m_spell = spell;
			m_effect = effect;
			m_finished = false;
			m_cancelable = !SpellManager.HarmfulCast(Spell, Effect);
			m_cleaned = false;
			m_forceVisible = caster is ItemObject ? 0 : -1;

			m_castNumber = caster.CastCount;

			if (caster.SpellProcessor == null)
				Recalc(SpellEffect.AuraPeriod, Spell.Duration);
			else
				Recalc(SpellEffect.AuraPeriod, caster.SpellProcessor.Duration(spell));
		}
		
		protected void Recalc(int period, int duration)
		{
			m_count = period == 0 ? 1 : duration / period;
			m_interval = period == 0 ? duration : period;
			if (m_interval <= 0)
				m_interval = 0;
		}

		public bool DoStart()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed || LivingTarget.Auras == null)
				return false;

			if (Visible)
				LivingTarget.Auras.UnregisterByGroup(CasterGUID, Spell.SpellGroup, m_castNumber); // unregister all other castable spells from same group

			if (AuraKey != 0)
				LivingTarget.Auras.UnregisterByAuraKey(CasterGUID, AuraKey, m_castNumber); // unregister all other castable spells from same group

			bool result = AuraStart();

			if (result)
			{
				if (Visible)
				{
					m_auraNumber = LivingTarget.Auras.AddAura(m_spell.ObjectId, 0, (byte)m_spell.Rank, 15, m_cancelable);
					if (m_spell.Duration > 0)
						LivingTarget.Auras.SetDuration(m_auraNumber, m_spell.Duration);
				}
				else
					m_auraNumber = -1;

				LivingTarget.Auras.Register(this);
				LivingTarget.Redress();
				LivingTarget.UpdateData();
			}
			
			return result;
		}
		
		public void DoFinish(bool unregister)
		{
			if (!m_cleaned)
			{
				AuraFinish();
				m_cleaned = true;
			}

			if (unregister && LivingTarget != null)
			{
				
				if (LivingTarget.Auras != null)
					LivingTarget.Auras.Unregister(CasterGUID, Spell.ObjectId);

				LivingTarget.Redress();
				LivingTarget.UpdateData();
			}
		}
		
		public void DoTick()
		{
			if (Finished)
				return;
			
			AuraTick();
			
			if (m_count != -1)
			{
				m_count--;
				if (m_count == 0)
					Finish();
			}
		}
		
		protected void Finish()
		{
			m_finished = true;
		}
		
		#region Static
		
		public static SpellFailedReason Apply<AuraClass>
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
			where AuraClass : IAura, new()
		{
			IAura aura = new AuraClass();
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.DUMMY, new AuraCast(Apply<BaseAura>));
		}

		#endregion

	}
}
