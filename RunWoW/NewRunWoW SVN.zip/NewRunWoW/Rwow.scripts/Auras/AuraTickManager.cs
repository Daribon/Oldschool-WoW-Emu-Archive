using System;
using System.Collections.Generic;
using System.Threading;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Misc;

namespace RunWoW.Auras
{
	public class AuraTickManager : Event
	{
		#region static
		
		private static TimeSpan UpdateTime = TimeSpan.FromMilliseconds(1000);

		private static AuraTickManager s_instance = new AuraTickManager();

		private static long s_auraId = 0;

		public static AuraTickManager Instance
		{
			get { return s_instance; }
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			s_instance.Start();
		}

		public static void DoFinalize()
		{
			if (s_instance != null)
				s_instance.Finish();
		}

		#endregion
		
		class DateAurasPair
		{
			public DateTime LastTick;
			public Dictionary<long, IAura> Auras;
			public int Interval;
			public int CheckInterval;

			public DateAurasPair(int interval)
			{
				Interval = interval;
				CheckInterval = interval/10;
				if (CheckInterval < 500)
					CheckInterval = 500;
				if (CheckInterval > 2000)
					CheckInterval = 2000;
				LastTick = CustomDateTime.Now;
				Auras = new Dictionary<long, IAura>();
			}
		}

		private DateAurasPair [] m_auras;

		private IAura[] m_toProcess;

		public AuraTickManager()
			: base(UpdateTime, UpdateTime)
		{
			m_auras = new DateAurasPair[50];
			m_toProcess = new IAura[5000];
			ExecPriority = ExecutionPriority.QCritical;
		}

		protected override void OnTick()
		{
			DateTime now = CustomDateTime.Now;

			int processCount = 0;

			for (int i = 0; i < m_auras.Length;i++ )
				if (m_auras[i] != null && m_auras[i].Interval > 0)
				{
					int elapsed = (int) (now - m_auras[i].LastTick).TotalMilliseconds;

					if (elapsed < m_auras[i].CheckInterval)
						continue;

					/*if (m_auras[i].Interval >= 1000 && elapsed > m_auras[i].Interval * 1.5)
						LogConsole.WriteLine(LogLevel.ERROR, "Very large delay in AuraTickManager: elapsed {0} for interval {1}", elapsed,
											 m_auras[i].Interval);*/

					lock (m_auras[i].Auras)
						foreach (IAura aura in m_auras[i].Auras.Values)
						{
							int aelapsed = (int)(now - aura.LastTick).TotalMilliseconds;

							if (aelapsed < aura.Interval)
								continue;
							
							m_toProcess[processCount++] = aura;
						}


					m_auras[i].LastTick = CustomDateTime.Now;
				}

			if (processCount > 0)
				for (int i = 0; i < processCount; i++)
				{
					try
					{
						m_toProcess[i].DoTick();
					}
					catch (Exception ex)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Error at aura tick {0}", ex);
					}

					if (m_toProcess[i].Finished)
						Unregister(m_toProcess[i], true);
					else
						m_toProcess[i].LastTick = CustomDateTime.Now;

					m_toProcess[i] = null;
				}
		}


		public void Register(IAura aura)
		{
			if (!aura.DoStart())
				return;

			aura.LastTick = CustomDateTime.Now;
			
			aura.ID = Interlocked.Increment(ref s_auraId);

			int index = -1;
			for(int i=0; i < m_auras.Length;i++ )
				if (m_auras[i] != null && m_auras[i].Interval == aura.Interval)
				{
					index = i;
					break;
				}
			
			if (index == -1)
				for (int i = 0; i < m_auras.Length; i++)
					if (m_auras[i] == null)
					{
						index = i;
						m_auras[index] = new DateAurasPair(aura.Interval);
						break;
					}

			lock (m_auras[index].Auras)
				m_auras[index].Auras[aura.ID] = aura;
		}

		public void Unregister(IAura aura, bool unregister)
		{
			//Console.WriteLine("Got unregister for aura {0}, interval {1}, do unregister: {2}", aura.ID, aura.Interval, unregister);
			int index = -1;
			
			for(int i=0; i < m_auras.Length;i++ )
				if (m_auras[i] != null && m_auras[i].Interval == aura.Interval)
				{
					index = i;
					break;
				}

			if (index != -1)
				lock (m_auras[index].Auras)
					if (m_auras[index].Auras.ContainsKey(aura.ID))
						m_auras[index].Auras.Remove(aura.ID);
			
			aura.DoFinish(unregister);
		}
	}
}
