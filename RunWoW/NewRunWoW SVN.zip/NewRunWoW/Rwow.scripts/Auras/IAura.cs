using System;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Auras
{
	public interface IAura
	{
		void Init(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte effect);
		
		bool DoStart();
		void DoTick();
		void DoFinish(bool unregister);

		bool Finished{ get; }
		int Interval{ get; }
		DateTime LastTick { get; set; }
		
		long ID { get; set; }
	}
}