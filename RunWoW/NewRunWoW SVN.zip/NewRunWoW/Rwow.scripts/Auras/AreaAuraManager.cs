using System;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Misc;
using RunWoW.Spells;

namespace RunWoW.Auras
{
	public abstract class AreaAuraHolder
	{
		private ObjectReference m_caster;
		private DBSpell m_spell;
		private byte m_effectNumber;
		private DateTime m_endTime;
		private DateTime m_nextTick;
		private TimeSpan m_interval;
		private bool m_forceFinish;
		private Dictionary<ulong, ObjectReference> m_targets = null;

		public ObjectReference Caster
		{
			get { return m_caster; }
		}

		public DBSpell Spell
		{
			get { return m_spell; }
		}

		public byte EffectNumber
		{
			get { return m_effectNumber; }
		}

		public virtual bool Finished
		{
			get { return m_forceFinish || CustomDateTime.Now > m_endTime; }
			set { m_forceFinish = value;  }
		}
		
		protected AreaAuraHolder(ObjectReference caster, DBSpell spell, byte effectNumber)
		{
			m_caster = caster;
			m_spell = spell;
			m_effectNumber = effectNumber;

			if (m_spell.Duration <= 0)
				m_endTime = DateTime.MaxValue;
			else
				m_endTime = CustomDateTime.Now.AddMilliseconds(m_spell.Duration);

			m_interval = spell.Effect[effectNumber].AuraPeriod == 0 ? TimeSpan.FromSeconds(1) : TimeSpan.FromSeconds(spell.Effect[effectNumber].AuraPeriod);
			
			m_nextTick = CustomDateTime.Now;
			
			m_forceFinish = false;
		}

		public abstract void ProcessCast();

		protected void doProcessCast(Vector point)
		{
			if (Caster == null || Caster.MapTile == null || Caster.Target == null || Caster.Target.IsDisposed || Caster.Target.SpellProcessor == null)
			{
				Finished = true;
				return;
			}
			
			if (CustomDateTime.Now < m_nextTick)
				return;

			Caster.Target.CastCount++;
			
			SpellFailedReason dresult;

			ICollection<ObjectBase> ltargets = SpellManager.SpellTargets(Caster.MapTile.Map.GetTileByLoc(point), Caster.Target, Caster.Target, point, Spell, EffectNumber, out dresult, true);

			Dictionary<ulong, bool> resisted = new Dictionary<ulong, bool>();

			Dictionary<ulong, ObjectReference> affected = new Dictionary<ulong, ObjectReference>();

			if (dresult == SpellFailedReason.MAX && ltargets != null)
			{
				foreach (ObjectBase ltarget in ltargets)
					if (ltarget != null && !ltarget.IsDisposed)
					{
						if (ltarget is LivingObject && !((LivingObject)ltarget).Attackable && !Spell.CastOnDead)
							continue;

						if (!Faction.SameFaction(ltarget, Caster.Target))
						{
							if (!resisted.ContainsKey(ltarget.GUID))
								resisted[ltarget.GUID] = SpellManager.CheckResist(Caster.Target, ltarget, Spell);

							if (resisted[ltarget.GUID])
								continue;
						}
						
						if (ltarget is LivingObject && ((LivingObject)ltarget).Auras.HasAura(Spell.ObjectId))
							affected.Add(ltarget.GUID, ltarget.Reference); // do not recast spell if aura is active
						else
						{
							SpellFinishHandler linked = null;
							SpellFailedReason sresult = SpellManager.ProcessSpell(Caster.Target, ltarget, ltarget, Spell, EffectNumber, ref linked);
							if (sresult == SpellFailedReason.MAX)
							{
								affected.Add(ltarget.GUID, ltarget.Reference);

								if (ltarget is UnitBase && SpellManager.HarmfulCast(Spell, EffectNumber))
									((UnitBase)ltarget).AddThreat(Caster.Target, 1f);
							}
						}
					}
			}

			if (m_targets != null)
				foreach (KeyValuePair<ulong, ObjectReference> pair in m_targets)
					if (!affected.ContainsKey(pair.Key) && pair.Value.AsLiving != null)
						pair.Value.AsLiving.Auras.CancelAuraForce(Spell.ObjectId);
			
			m_targets = affected;

			m_nextTick = CustomDateTime.Now + m_interval;
		}
		
		public void Cleanup()
		{
			if (m_targets != null)
				foreach (KeyValuePair<ulong, ObjectReference> pair in m_targets)
					if (pair.Value.IsAlive && pair.Value.AsLiving != null && pair.Value.AsLiving.Auras != null)
						pair.Value.AsLiving.Auras.CancelAuraForce(Spell.ObjectId);
		}
		
	}
	
	public class LivingAreaAuraHolder : AreaAuraHolder
	{
		
		public override bool Finished
		{
			get
			{
				return base.Finished || Caster == null || !Caster.IsAlive || Caster.AsLiving.Dead;
			}
		}
		
		public LivingAreaAuraHolder(LivingObject caster, DBSpell spell, byte effectNumber)
			: base(caster.Reference, spell, effectNumber)
		{
		}

		public override void ProcessCast()
		{
			if (Caster == null || !Caster.IsAlive || Caster.AsLiving.Dead)
				return;
			doProcessCast(Caster.Target.Position);
		}
	}

	public class ObjectAreaAuraHolder : AreaAuraHolder
	{

		public ObjectAreaAuraHolder(ObjectBase caster, DBSpell spell, byte effectNumber)
			: base(caster.Reference, spell, effectNumber)
		{
		}

		public override void ProcessCast()
		{
			if (Caster == null || !Caster.IsAlive)
				return;

			doProcessCast(Caster.Target.Position);
		}
	}

	public class PersistentAreaAuraHolder : AreaAuraHolder
	{
		private Vector m_point;
		
		public PersistentAreaAuraHolder(ObjectBase caster, DBSpell spell, byte effectNumber, Vector point)
			: base(caster.Reference, spell, effectNumber)
		{
			m_point = point;
		}

		public override void ProcessCast()
		{
			if (Caster == null || !Caster.IsAlive)
				return;

			doProcessCast(m_point);
		}
	}

	public class AreaAuraManager : Event
	{
		private static int UpdateTime = 1000;//Constants.MobileAIRecalcLong; /// TODO: Separate key
		
		private static AreaAuraManager m_instance = new AreaAuraManager();
		
		private Dictionary<ulong, List<AreaAuraHolder>> m_auras;

		public AreaAuraManager()
			: base(TimeSpan.FromMilliseconds(UpdateTime),
				   TimeSpan.FromMilliseconds(UpdateTime))
		{
			m_auras = new Dictionary<ulong, List<AreaAuraHolder>>();
			ExecPriority = ExecutionPriority.QCritical;
		}

		protected override void OnTick()
		{
			lock (m_auras)
			{
				List<ulong> toErase = new List<ulong>();
				foreach (KeyValuePair<ulong, List<AreaAuraHolder>> pair in m_auras)
				{
					if (pair.Value == null || pair.Value.Count == 0)
					{
						toErase.Add(pair.Key);
						continue;
					}

					List<AreaAuraHolder> toRemove = new List<AreaAuraHolder>();
					lock (pair.Value)
					{
						foreach (AreaAuraHolder holder in pair.Value)
							if (holder.Finished)
							{
								holder.Cleanup();
								toRemove.Add(holder);
							}
							else
							{
								try
								{
									holder.ProcessCast();
								}
								catch (Exception ex)
								{
									LogConsole.WriteLine(LogLevel.ERROR, "Error at area aura manager: " + ex);
									toRemove.Add(holder);
								}
							}

						foreach (AreaAuraHolder holder in toRemove)
							pair.Value.Remove(holder);
					}
				}
				foreach (ulong key in toErase)
					m_auras.Remove(key);
			}
		}
		
		private static void Register(ulong key, AreaAuraHolder holder)
		{
			lock (m_instance.m_auras)
			{
				if (!(m_instance.m_auras).ContainsKey(key) || m_instance.m_auras[key] == null)
					m_instance.m_auras[key] = new List<AreaAuraHolder>();

				lock (m_instance.m_auras[key])
					m_instance.m_auras[key].Add(holder);
			}
		}
		
		private static void Unregister(ulong key, uint spellId)
		{
			lock (m_instance.m_auras)
			{
				if (!(m_instance.m_auras).ContainsKey(key) || m_instance.m_auras[key] == null)
					return;

				lock (m_instance.m_auras[key])
					foreach (AreaAuraHolder holder in m_instance.m_auras[key])
						if (holder.Spell.ObjectId == spellId)
							holder.Finished = true;
			}
		}
		
		public static void RegisterLivingAreaArea(LivingObject caster, DBSpell spell, byte effect)
		{
			Register(caster.GUID, new LivingAreaAuraHolder(caster, spell, effect));
		}

		public static void RegisterObjectAreaArea(ObjectBase caster, DBSpell spell, byte effect)
		{
			Register(caster.GUID, new ObjectAreaAuraHolder(caster, spell, effect));
		}

		public static void RegisterPersistentAreaArea(ObjectBase caster, DBSpell spell, byte effect, Vector point)
		{
			Register(caster.GUID, new PersistentAreaAuraHolder(caster, spell, effect, point));
		}
		
		public static void CancelAreaAura(ObjectBase caster, uint spellId)
		{
			Unregister(caster.GUID, spellId);
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			m_instance.Start();
		}

		public static void DoFinalize()
		{
			if (m_instance != null)
				m_instance.Finish();
		}
		
	}
}
