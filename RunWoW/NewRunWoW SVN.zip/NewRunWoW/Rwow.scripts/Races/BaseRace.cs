//
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public abstract class BaseRace : ISContainer
	{
		private static int[] male_models = { 0, 49, 51, 53, 55, 57, 59, 1563, 1478, 6894, 15476, 16125, 17402, 17576, 17578 };
		private static int[] female_models = { 0, 50, 52, 54, 56, 58, 60, 1564, 1479, 6895, 15475, 16126, 17403, 17577, 17579 };
		
		// 6894/6895 - goblin
		// 17402/17403 - naga

		protected Hashtable m_classes = new Hashtable();
		
		public readonly Vector StartPosition;
		public readonly uint StartWorld;
		public readonly uint StartZone;
		public readonly int IntroMovie;
		
		protected int BaseSpirit;
		protected int BaseIntellect;
		protected int BaseStamina;
		protected int BaseStrength;
		protected int BaseAgility;

		protected void addClass(BaseClass baseClass)
		{
			m_classes[baseClass.ClassID] = baseClass;
			baseClass.InitSpells(Race);
			baseClass.InitNewbie();
		}

		public BaseRace(Vector position, uint world, uint zone, int movie)
		{
			StartPosition = position;
			StartWorld = world;
			StartZone = zone;
			IntroMovie = movie;
			InitNewbie();
		}

		public abstract RACE Race { get; }
		public abstract FACTION Faction { get; }

		public virtual float Scale
		{
			get { return 1.0f; }
		}

		public virtual DBCharacter Create(string Name, uint AccountId, CLASS nClass, byte Gender, byte Skin, byte Face,
		                                  byte HairColor, byte HairStyle, byte FacialHairStyle)
		{
			DBCharacter character = new DBCharacter();
			character.Name = Name;
			character.AccountID = AccountId;
			character.Race = Race;
			character.Faction = Faction;
			character.Class = nClass;
			character.OriginalClass = nClass;
			character.Gender = Gender;
			character.Skin = Skin;
			character.Face = Face;
			character.HairStyle = HairStyle;
			character.HairColor = HairColor;
			character.FacialHairStyle = FacialHairStyle;
			character.Money = 0;
			character.Exp = 0;
			character.Level = 1;
			character.Facing = 0.0f;
			character.Scale = Scale;
			character.Position = StartPosition.Clone();
			character.Zone = StartZone;
			character.WorldMapID = StartWorld;
			character.ProfPoints = 2;

			character.DisplayID = (short) (Gender == 0 ? male_models[(byte) Race] : female_models[(byte) Race]);

			Complete(character);

			return character;
		}

		public void CheckModel(DBCharacter character)
		{
			int did = character.Gender == 0 ? male_models[(byte) Race] : female_models[(byte) Race];
			if (did != character.DisplayID)
				character.DisplayID = (short) did;
		}

		public void FixClass(DBCharacter character)
		{
			if ((character.OriginalClass != character.Class) ||
			    (character.Class == CLASS.DRUID && character.PowerType != POWERTYPE.MANA))
			{
				character.Class = character.OriginalClass;
				Stats(character);
			}
		}

		public void FixFaction(DBCharacter character)
		{
			character.Faction = Faction;
		}

		public void Stats(DBCharacter character)
		{
			BaseClass nClass = (BaseClass) m_classes[character.Class];
			character.Strength = (short) (BaseStrength + nClass.StrengthValue(character.Level));
			character.Agility = (short) (BaseAgility + nClass.AgilityValue(character.Level));
			character.Stamina = (short) (BaseStamina + nClass.StaminaValue(character.Level));
			character.Intellect = (short) (BaseIntellect + nClass.IntellectValue(character.Level));
			character.Spirit = (short) (BaseSpirit + nClass.SpiritValue(character.Level));
			character.MaxHealth = (short) (nClass.BaseHealth + (character.Stamina - BaseStamina)*10 +
			                               nClass.HealthForLevel(character.Level));
			character.PowerType = nClass.PowerType;
			if (character.PowerType != POWERTYPE.RAGE && character.PowerType != POWERTYPE.ENERGY)
			{
				character.MaxPower = (short) (nClass.BasePower + (character.Intellect - BaseIntellect)*10 +
				                              nClass.PowerForLevel(character.Level));
				character.Power = character.MaxPower;
			}
			else
			{
				character.MaxPower = (short) nClass.BasePower;
				character.Power = 0;
			}
		}

		protected void Complete(DBCharacter character)
		{
			Stats(character);
			BaseClass nClass = (BaseClass) m_classes[character.Class];

			character.Health = character.MaxHealth;

			DBManager.NewDBObject(character);

			AddItems(character);
			nClass.AddItems(character);

			foreach (DBItem item in character.Items)
				Database.Instance.AddNewObject(item);
		}

		public BaseClass GetClass(CLASS nClass)
		{
			return m_classes[nClass] as BaseClass;
		}

		public virtual void InitNewbie()
		{
			//AddItem(6948, INVSLOT.BACKPACK_SLOT03);
			AddSkill(SPELLSKILL.UNARMED, SKILL.UNARMED, 1, 300); // Unarmed
			AddSpell(SPELLSKILL.ATTACK, 1); // Attack			
			AddSpell(SPELLSKILL.DODGE); // Dodge
			AddSkill(SPELLSKILL.NONE, SKILL.DEFENCE, 1, 300); // Defence
		}
	}
}