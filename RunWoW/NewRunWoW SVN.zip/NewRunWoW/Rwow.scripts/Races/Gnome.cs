using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Gnome : BaseRace
	{
		public class GnomeWarrior : Warrior
		{
			public GnomeWarrior() : base(50)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(25, INVSLOT.MAINHAND); // Worn Shortsword
				//AddItem(2362, INVSLOT.OFFHAND); // Worn Wooden Shield
				//AddItem(39, INVSLOT.LEGS); // Recruits Pants
				//AddItem(38, INVSLOT.BODY); // Recruits Shirt
				//AddItem(40, INVSLOT.FEET); // Recruits Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky

				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
				AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300); // Swords
			}
		}

		public class GnomeRogue : Rogue
		{
			public GnomeRogue() : base(45)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(49, INVSLOT.BODY); // Footpad's Shirt
				//AddItem(48, INVSLOT.LEGS); // Footpad's Pants
				//AddItem(47, INVSLOT.FEET); // Footpad's Shoes
				//AddItem(2947, INVSLOT.RANGED, 100); // Small Throwing Knife
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
			}
		}

		public class GnomeWarlock : Warlock
		{
			public GnomeWarlock() : base(43, 185)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn dagger
				//AddItem(59, INVSLOT.FEET); // Acolyte's shoes
				//AddItem(1396, INVSLOT.LEGS); // Acolyte's pants
				//AddItem(57, INVSLOT.CHEST); // Acolyte's robe
				//AddItem(6097, INVSLOT.BODY); // Acolyte's shirt
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 2); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class GnomeMage : Mage
		{
			public GnomeMage() : base(51, 210)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(35, INVSLOT.MAINHAND); // bent staff
				//AddItem(55, INVSLOT.FEET); // Apprentices Boots
				//AddItem(1395, INVSLOT.LEGS); // Apprentices Pants
				//AddItem(6140, INVSLOT.CHEST); // Apprentices Robe
				//AddItem(6096, INVSLOT.BODY); // Apprentices Shirt
				//AddItem(4536, INVSLOT.BACKPACK_SLOT00, 2); // Shiny Red Apple
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public Gnome()
			: base(new Vector(-6240.32f, 331.033f, 382.758f), 0, 1, 101)
		{
			addClass(new GnomeWarrior());
			addClass(new GnomeRogue());
			addClass(new GnomeMage());
			addClass(new GnomeWarlock());

			BaseStrength = 15;
			BaseAgility = 23;
			BaseStamina = 19;
			BaseIntellect = 23;
			BaseSpirit = 20;
		}

		public override RACE Race
		{
			get { return RACE.GNOME;}
		}

		public override FACTION Faction
		{
			get { return FACTION.GNOME; }
		}

		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(20589); // Escape Artist
			AddSpell(20591); // Expansive Mind
			AddSpell(20592); // Arcane Resistance
			AddSpell(20593); // Technologist

			AddSkill(668, 98, 300, 300); // lang common
			AddSkill(7340, 313, 300, 300); // lang gnomish
		}
	}
}