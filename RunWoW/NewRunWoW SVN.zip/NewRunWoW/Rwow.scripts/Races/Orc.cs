using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Orc : BaseRace
	{
		public class OrcWarrior : Warrior
		{
			public OrcWarrior() : base(80)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(5777, INVSLOT.MAINHAND); // Worn Battleaxe
				//AddItem(139, INVSLOT.LEGS); // Brawler's Pants
				//AddItem(6125, INVSLOT.BODY); // Brawler's Harness
				//AddItem(140, INVSLOT.FEET); // Brawler's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky

				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300); // Swords
				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // One-handed Axes
				AddSkill(SPELLSKILL.TWOHANDAXE, SKILL.TWOHANDAXE, 1, 300); // Two-handed Axes
			}
		}

		public class OrcRogue : Rogue
		{
			public OrcRogue() : base(75)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(2105, INVSLOT.BODY); // Thug Shirt
				//AddItem(120, INVSLOT.LEGS); // Thug Pants
				//AddItem(121, INVSLOT.FEET); // Thug Boots
				//AddItem(3111, INVSLOT.RANGED, 100); // Crude Throwing Knife
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
			}
		}

		public class OrcWarlock : Warlock
		{
			public OrcWarlock() : base(73, 109)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn dagger
				//AddItem(59, INVSLOT.FEET); // Acolyte's shoes
				//AddItem(1396, INVSLOT.LEGS); // Acolyte's pants
				//AddItem(6129, INVSLOT.CHEST); // Acolyte's robe
				//AddItem(6097, INVSLOT.BODY); // Acolyte's shirt
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 2); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class OrcHunter : Hunter
		{
			public OrcHunter() : base(76, 82)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(37, INVSLOT.MAINHAND); // Worn Axe
				//AddItem(2504, INVSLOT.RANGED); // Worn Shortbow
				//AddItem(127, INVSLOT.BODY); // Trapper's Shirt
				//AddItem(6126, INVSLOT.LEGS); // Trapper's Pants
				//AddItem(6127, INVSLOT.FEET); // Trapper's Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
				//AddItem(2512, INVSLOT.BACKPACK_SLOT02, 100); // Rough Arrow

				AddSpell(2480, 2); // Shoot bow
				AddSkill(SPELLSKILL.BOW, SKILL.BOW, 1, 300); // Bows
				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // Axes
				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			}
		}

		public class OrcShaman : Shaman
		{
			public OrcShaman() : base(77, 73)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // Worn Mace
				//AddItem(153, INVSLOT.LEGS); // Primitive Kilt
				//AddItem(154, INVSLOT.BODY); // Primitive Mantle
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 2); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // refreshing spring water
			}
		}

		public Orc()
			: base(new Vector(-618.518f, -4251.67f, 38.718f), 1, 14, 21)
		{
			addClass(new OrcHunter());
			addClass(new OrcRogue());
			addClass(new OrcShaman());
			addClass(new OrcWarlock());
			addClass(new OrcWarrior());

			BaseStrength = 23;
			BaseAgility = 17;
			BaseStamina = 22;
			BaseIntellect = 17;
			BaseSpirit = 23;
		}

		public override RACE Race
		{
            get { return RACE.ORC; }
		}

		public override FACTION Faction
		{
			get { return FACTION.ORC; }
		}

		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(20572); // Blood Fury
			AddSpell(20573); // Hardiness
			AddSpell(20575); // Command
			AddSpell(20574); // Axe Specialization

			AddSkill(669, 109, 300, 300); // lang orcish
		}
	}
}