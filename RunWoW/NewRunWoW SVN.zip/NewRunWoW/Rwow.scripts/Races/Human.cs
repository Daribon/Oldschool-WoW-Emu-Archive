//
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Human : BaseRace
	{
		public class HumanWarrior : Warrior
		{
			public HumanWarrior() : base(60)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(25, INVSLOT.MAINHAND); // Worn Shortsword
				//AddItem(2362, INVSLOT.OFFHAND); // Worn Wooden Shield
				//AddItem(39, INVSLOT.LEGS); // Recruits Pants
				//AddItem(38, INVSLOT.BODY); // Recruits Shirt
				//AddItem(40, INVSLOT.FEET); // Recruits Boots
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky

				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // Axes
				AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
				AddSkill(SPELLSKILL.ONEHANDSWORD, SKILL.ONEHANDSWORD, 1, 300); // Swords
			}
		}

		public class HumanPaladin : Paladin
		{
			public HumanPaladin() : base(58, 80)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2361, INVSLOT.MAINHAND); // Battleworn Hammer
				//AddItem(45, INVSLOT.BODY); // Squire's Shirt
				//AddItem(44, INVSLOT.LEGS); // Squire's Pants
				//AddItem(43, INVSLOT.FEET); // Squire's Boots
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 4); // Darnassian Bleu
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
			}
		}

		public class HumanRogue : Rogue
		{
			public HumanRogue() : base(52)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(49, INVSLOT.BODY); // Footpad's Shirt
				//AddItem(48, INVSLOT.LEGS); // Footpad's Pants
				//AddItem(47, INVSLOT.FEET); // Footpad's Shoes
				//AddItem(2947, INVSLOT.RANGED, 100); // Small Throwing Knife
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 4); // Darnassian Bleu
			}
		}

		public class HumanPriest : Priest
		{
			public HumanPriest() : base(55, 160)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(51, INVSLOT.FEET); // neophytes's boots
				//AddItem(52, INVSLOT.LEGS); // neophytes's pants
				//AddItem(6098, INVSLOT.CHEST); // neophyte's robe
				//AddItem(53, INVSLOT.BODY); // neophyte's shirt
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 2); // Darnassian Bleu
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class HumanWarlock : Warlock
		{
			public HumanWarlock() : base(53, 185)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn dagger
				//AddItem(59, INVSLOT.FEET); // Acolyte's shoes
				//AddItem(1396, INVSLOT.LEGS); // Acolyte's pants
				//AddItem(57, INVSLOT.CHEST); // Acolyte's robe
				//AddItem(6097, INVSLOT.BODY); // Acolyte's shirt
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 2); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class HumanMage : Mage
		{
			public HumanMage() : base(52, 165)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(35, INVSLOT.MAINHAND); // bent staff
				//AddItem(55, INVSLOT.FEET); // Apprentices Boots
				//AddItem(1395, INVSLOT.LEGS); // Apprentices Pants
				//AddItem(56, INVSLOT.CHEST); // Apprentices Robe
				//AddItem(6096, INVSLOT.BODY); // Apprentices Shirt
				//AddItem(2070, INVSLOT.BACKPACK_SLOT00, 2); // Darnassian Bleu
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public Human()
			: base(new Vector(-8949.95f, -132.493f, 83.5312f), 0, 12, 81)
		{
			addClass(new HumanWarrior());
			addClass(new HumanPaladin());
			addClass(new HumanRogue());
			addClass(new HumanPriest());
			addClass(new HumanMage());
			addClass(new HumanWarlock());

			BaseStrength = 20;
			BaseAgility = 20;
			BaseStamina = 20;
			BaseIntellect = 20;
			BaseSpirit = 20;
		}

		public override RACE Race
		{
            get { return RACE.HUMAN; }
		}

		public override FACTION Faction
		{
			get { return FACTION.HUMAN; }
		}

		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(20599); // diplomacy
			AddSpell(20864); // mace specialization
			AddSpell(20600); // perception
			AddSpell(20597); // sword specialization
			AddSpell(20598); // human spirit

			AddSkill(668, 98, 300, 300); // lang common
		}
	}
}