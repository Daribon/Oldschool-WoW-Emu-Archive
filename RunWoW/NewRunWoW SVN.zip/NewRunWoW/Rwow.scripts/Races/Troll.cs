using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.WoWClasses;

namespace RunWoW.WoWRaces
{
	public class Troll : BaseRace
	{
		public class TrollWarrior : Warrior
		{
			public TrollWarrior() : base(70)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(37, INVSLOT.MAINHAND); // Worn Axe
				//AddItem(2362, INVSLOT.OFFHAND); //Worn Wooden Shield
				//AddItem(139, INVSLOT.LEGS); // Brawler's Pants
				//AddItem(6125, INVSLOT.BODY); // Brawler's Harness
				//AddItem(3111, INVSLOT.RANGED, 100); // Crude Throwing Axe
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky

				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // Axes
				AddSkill(SPELLSKILL.THROWN, SKILL.THROWN, 1, 300); // Thrown
			}
		}

		public class TrollShaman : Shaman
		{
			public TrollShaman() : base(67, 72)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(6135, INVSLOT.LEGS); // Primitive Kilt
				//AddItem(6134, INVSLOT.BODY); // Primitive Mantle
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 2); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class TrollPriest : Priest
		{
			public TrollPriest() : base(62, 128)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(36, INVSLOT.MAINHAND); // worn mace
				//AddItem(52, INVSLOT.LEGS); // neophytes's pants
				//AddItem(6144, INVSLOT.CHEST); // neophyte's robe
				//AddItem(53, INVSLOT.BODY); // neophyte's shirt
				//AddItem(4540, INVSLOT.BACKPACK_SLOT00, 2); //  Tough Hunk of Bread
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class TrollMage : Mage
		{
			public TrollMage() : base(62, 119)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(35, INVSLOT.MAINHAND); // bent staff
				//AddItem(55, INVSLOT.FEET); // Apprentices Boots
				//AddItem(1395, INVSLOT.LEGS); // Apprentices Pants
				//AddItem(6140, INVSLOT.CHEST); // Apprentices Robe
				//AddItem(6096, INVSLOT.BODY); // Apprentices Shirt
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 2); // Tough Jerky
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 4); // Refreshing Spring Water
			}
		}

		public class TrollRogue : Rogue
		{
			public TrollRogue() : base(65)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(2092, INVSLOT.MAINHAND); // Worn Dagger
				//AddItem(6137, INVSLOT.LEGS); // Thug Pants
				//AddItem(6136, INVSLOT.CHEST); // Thug Shirt
				//AddItem(6138, INVSLOT.FEET); // Thug Boots
				//AddItem(3111, INVSLOT.RANGED, 100); // Crude Throwing Knife
				//AddItem(117, INVSLOT.BACKPACK_SLOT00, 4); // Tough Jerky
			}
		}

		public class TrollHunter : Hunter
		{
			public TrollHunter() : base(66, 81)
			{
			}

			public override void InitNewbie()
			{
				base.InitNewbie();
				//AddItem(37, INVSLOT.MAINHAND); // Worn Axe
				//AddItem(2504, INVSLOT.RANGED); // Worn Shortbow
				//AddItem(127, INVSLOT.BODY); // Trapper's Shirt
				//AddItem(6126, INVSLOT.LEGS); // Trapper's Pants
				//AddItem(4604, INVSLOT.BACKPACK_SLOT00, 4); // Forest Mushroom Cap
				//AddItem(159, INVSLOT.BACKPACK_SLOT01, 2); // Refreshing Spring Water
				//AddItem(2512, INVSLOT.BACKPACK_SLOT02, 100); // RoughArrow

				AddSpell(2480, 2); // Shoot bow
				AddSkill(SPELLSKILL.BOW, SKILL.BOW, 1, 300); // Bows
				AddSkill(SPELLSKILL.ONEHANDAXE, SKILL.ONEHANDAXE, 1, 300); // Axes
				AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			}
		}

		public Troll()
			: base(new Vector(-618.518f, -4251.67f, 38.718f), 1, 14, 121)
		{
			addClass(new TrollHunter());
			addClass(new TrollMage());
			addClass(new TrollPriest());
			addClass(new TrollRogue());
			addClass(new TrollShaman());
			addClass(new TrollWarrior());

			BaseStrength = 21;
			BaseAgility = 22;
			BaseStamina = 21;
			BaseIntellect = 16;
			BaseSpirit = 21;
		}

		public override RACE Race
		{
            get { return RACE.TROLL; }
		}

		public override FACTION Faction
		{
			get { return FACTION.TROLL; }
		}

		public override void InitNewbie()
		{
			base.InitNewbie();
			AddSpell(20557); // beast slaying
			AddSpell(20554); // berserking
			AddSpell(20555); // regeneration
			AddSpell(20558); // throwing specialization

			AddSkill(669, 109, 300, 300); // lang orcish
			AddSkill(7341, 315, 300, 300); // lang troll
		}
	}
}