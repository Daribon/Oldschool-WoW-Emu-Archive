#define USE_HEAP_ARRAY

using System;
using System.IO;
using System.Text;
#if USE_HEAP_ARRAY
using RunServer.Common;
#endif

namespace RunWoW.Map
{
	public class WorldMapTile
	{
		internal const float TILESIZE = 1600f/3f;
		internal const float UNITSIZE = TILESIZE/256.0f;

		private int[][] m_id = new int[16][];

		private bool m_correct;
#if USE_HEAP_ARRAY
		private FloatHeapArray m_points = null;
		private FloatHeapArray m_water = null;
#else
		private float [,] m_points = null;
		private float [,] m_water = null;
#endif

		private float m_baseX;
		private float m_baseY;
		private float m_baseZ;

		public bool Correct
		{
			get { return m_correct; }
		}

		public float BaseX
		{
			get { return m_baseX; }
		}

		public float BaseY
		{
			get { return m_baseY; }
		}

		public float BaseZ
		{
			get { return m_baseZ; }
		}

		public int[][] AreaID
		{
			get { return m_id; }
		}

		public WorldMapTile(string file)
		{
			if (!File.Exists(file))
				return;
			using (FileStream fs = new FileStream(file, FileMode.Open))
			using (BinaryReader sr = new BinaryReader(fs))
			{
				int[] mcnk_offsets = null;
				int[] mcnk_sizes = null;
				while (fs.Position < fs.Length)
				{
					byte[] bytes = sr.ReadBytes(4);
					Array.Reverse(bytes);
					string fourcc = Encoding.ASCII.GetString(bytes, 0, 4);

					int nextpos = sr.ReadInt32() + (int) fs.Position;
					switch (fourcc)
					{
						case "MCIN": // mapchunk offsets/sizes
							mcnk_offsets = new int[256];
							mcnk_sizes = new int[256];
							for (int i = 0; i < 256; i++)
							{
								mcnk_offsets[i] = sr.ReadInt32();
								mcnk_sizes[i] = sr.ReadInt32();
								fs.Position += 8;
							}
							break;
						case "MWMO": // model instance data
							break;
						case "MODF": // wmo instance data
							break;
					}
					fs.Position = nextpos;
				}

#if USE_HEAP_ARRAY
				m_points = new FloatHeapArray(257, 257, float.NaN);
#else
				m_points = new float[257, 257];
#endif

				m_baseX = float.MaxValue;
				m_baseY = float.MaxValue;
				m_baseZ = float.MaxValue;

				if (mcnk_offsets != null)
                    for (int j = 0; j < 16; j++)
                    {
                        m_id[j] = new int[16];
                        for (int i = 0; i < 16; i++)
                        {
                            long pos = fs.Position = mcnk_offsets[j * 16 + i] + 4;

                            int flags = sr.ReadInt32();

                            int shifty = i * 16;
                            int shiftx = j * 16;

                            int wshifty = i * 8;
                            int wshiftx = j * 8;

                            fs.Position += 0x14;
                            int h_off = sr.ReadInt32();

                            fs.Position += 0x18;
                            fs.Position += 4;
                            m_id[j][i] = sr.ReadInt32();
                            int holes = sr.ReadInt32();

                            fs.Position += 0x24;

                            int liq_off = sr.ReadInt32();
                            int liq_size = sr.ReadInt32();

                            float xbase = sr.ReadSingle();
                            float ybase = sr.ReadSingle();
                            float zbase = sr.ReadSingle();

                            if (xbase < m_baseX)
                                m_baseX = xbase;
                            if (ybase < m_baseY)
                                m_baseY = ybase;
                            if (zbase < m_baseZ)
                                m_baseZ = zbase;

                            fs.Position = pos + h_off + 4;

                            for (int ni = 0; ni < 17; ni++)
                                for (int nj = 0; nj < ((ni % 2) == 1 ? 8 : 9); nj++)
                                {
                                    float zpos = sr.ReadSingle() + zbase;
                                    int xpos = ni + shiftx;
                                    int ypos = nj * 2 + ((ni % 2 == 1) ? 1 : 0) + shifty;
                                    m_points[xpos, ypos] = zpos;
                                }
                            m_correct = true;

                            fs.Position = pos + liq_off + 4;
                            byte[] nbytes = sr.ReadBytes(4);
                            Array.Reverse(nbytes);
                            string nfourcc = Encoding.ASCII.GetString(nbytes, 0, 4);
                            switch (nfourcc)
                            {
                                case "MCSE":
                                    break;
                                default:
									if (m_water == null)
#if USE_HEAP_ARRAY
										m_water = new FloatHeapArray(129, 129, float.MinValue);
#else
										m_water = new float[129,129];
#endif

                                    fs.Position -= 4;
                                    float wlevel = sr.ReadSingle();
                                    float mlevel = sr.ReadSingle();
                                    float[,] points = new float[9, 9];
                                    for (int ni = 0; ni < 9; ni++)
                                        for (int nj = 0; nj < 9; nj++)
                                        {
                                            fs.Position += 4;
                                            float zpos = sr.ReadSingle();
                                            points[ni, nj] = zpos < 100000 ? zpos : wlevel;
                                        }
                                    for (int ni = 0; ni < 8; ni++)
                                        for (int nj = 0; nj < 8; nj++)
                                        {
                                            byte flag = sr.ReadByte();
                                            if ((flag & 8) == 0)
                                            {
                                                m_water[ni + wshiftx, (nj + wshifty)] = (points[ni, nj] +
                                                                                         points[ni + 1, nj] +
                                                                                         points[ni, nj + 1] +
                                                                                         points[ni + 1, nj + 1]) / 4;
                                            }
                                        }
                                    break;
                            }
                        }
                    }
			}
			Dither();
		}

		public void Dither()
		{
			if (!Correct)
				return;
			// bilinear dither
			unchecked
			{
				for (int i = 0; i < 256; i++)
					for (int j = 0; j < 256; j++)
						if ((i + j)%2 == 1)
						{
							int cnt = 0;
							float val = 0f;
							if (i > 0)
							{
								val += m_points[i - 1, j];
								cnt++;
							}
							if (j > 0)
							{
								val += m_points[i, j - 1];
								cnt++;
							}
							if (i < 256)
							{
								val += m_points[i + 1, j];
								cnt++;
							}
							if (j < 256)
							{
								val += m_points[i, j + 1];
								cnt++;
							}
							m_points[i, j] = val/cnt;
						}
			}
		}

		public float GetBilinear(float x, float y)
		{
			unchecked
			{
				float nx = x/UNITSIZE;
				float ny = y/UNITSIZE;

				int fx = (int) nx;
				int fy = (int) ny;

				if (fx == 255 || fy == 255)
					return m_points[fx, fy];

				float fracX = nx - fx;
				float fracY = ny - fy;

#if USE_HEAP_ARRAY
				float[] quad = m_points.GetQuad(fx, fy);

				return
					quad[0]*(1f - fracX)*(1f - fracY) +
					quad[1]*fracX*(1f - fracY) +
					quad[2]*(1f - fracX)*fracY +
					quad[3]*fracX*fracY;
#else
				return
					m_points[fx, fy + 1] * (1f - fracX) * fracY +
					m_points[fx, fy] * (1f - fracX) * (1f - fracY) +
					m_points[fx + 1, fy + 1] * fracX * fracY +
					m_points[fx + 1, fy] * fracX * (1f - fracY);
#endif
			}
		}

		public float GetNearest(float x, float y)
		{
			unchecked
			{
				int nx = (int) (x/UNITSIZE);
				int ny = (int) (y/UNITSIZE);
				return m_points[nx, ny];
			}
		}

		public float WaterLevel(float x, float y)
		{
			if (m_water == null)
				return float.MinValue;
			
			unchecked
			{
				int nx = (int) (x/(UNITSIZE*2));
				int ny = (int) (y/(UNITSIZE*2));
				return m_water[nx, ny];
			}
		}
	}
    


}