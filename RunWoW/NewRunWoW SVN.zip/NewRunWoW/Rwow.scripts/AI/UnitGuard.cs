//
using System;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerScripts.AI.Behaivors;
using RunServer.Common;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class UnitGuard : UnitBase, IOwnedUnit
	{
		private Behaivor m_behaivor;
		private LivingObject m_owner;
		private DateTime m_expire;

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(UnitGuard));
		}

		public LivingObject Owner
		{
			get { return m_owner; }
		}

		public UnitGuard(DBCreature creature, Vector position, float facing, LivingObject master, int time)
			: base(
				creature, creature.Defaults.Level == 0 ? master.Level : creature.Defaults.Level, 
				position, facing, creature.Defaults.Flags, creature.Defaults.NpcFlags,
				creature.Defaults.Faction)
		{
			m_owner = master;
			m_owner.Guard = this.Reference;
			m_behaivor = new UnitGuardAI(this, m_owner);
			m_behaivor.Start();
			m_expire = time >= 0 ? DateTime.Now.AddMilliseconds(time) : DateTime.MaxValue;
		}

		public override void Attacked(LivingObject enemy)
		{
			m_behaivor.Attacked(enemy);
		}

		public override void DoSleep()
		{
			if (MapTile.GetObject(m_owner.GUID) == null)
				Dead = true;
		}

		public override void DoAwake()
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_behaivor != null && !m_behaivor.Finished)
					m_behaivor.Finish(EventResult.COMPLETED);
				m_owner = null;
			}
			base.Dispose(disposing);
		}
		
		public override void BehaivorTick()
		{
			if (m_expire != DateTime.MinValue && m_expire < CustomDateTime.Now)
			{
				Dead = true;
				return;
			}
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.OnTick();
		}
	}
}