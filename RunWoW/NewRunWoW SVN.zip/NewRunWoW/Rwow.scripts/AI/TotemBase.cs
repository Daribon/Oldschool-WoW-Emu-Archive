using System.Collections;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerScripts.AI.Behaivors;
using RunServer.Common;
using RunServer.Common.Attributes;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class TotemBase : UnitBase, IOwnedUnit
	{
		private TotemAI m_behaivor;
		private LivingObject m_owner;


		#region Properties

		public LivingObject Owner
		{
			get { return m_owner; }
		}

		#endregion

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(TotemBase));
		}

		public TotemBase(DBCreature creature, uint SpellID, Vector position, float facing, LivingObject owner, ushort totemSpellId, bool offensive, int duration, int life)
			: base(creature, owner.Level, position, facing, 0x0, 0x0, owner.Faction)
		{
			m_owner = owner;
			m_summonedBy = m_owner.GUID;
			m_createdBySpell = SpellID;
			m_behaivor = new TotemAI(this, m_owner, offensive, duration);
			m_behaivor.Start();

			MaxPower = Power = m_basePower = owner.Level * 50;
			Health = MaxHealth = m_baseHealth = life <= 0 ? owner.Level : life;
			
			PowerType = POWERTYPE.MANA;

			Spells = new DBMonsterSpell[] { new DBMonsterSpell(totemSpellId, offensive) };

			if (owner is PlayerObject)
				((PlayerObject)owner).AddTotem(this);
		}
		
		public override void Die()
		{
			if (m_owner is PlayerObject)
				((PlayerObject)m_owner).RemoveTotem(this);
			base.Die();
		}

		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);
			CreateValue(UNITFIELDS.SUMMONEDBY, array);
			CreateValue(UNITFIELDS.CREATED_BY_SPELL, array);
		}

		public override void Attacked(LivingObject enemy)
		{
			m_behaivor.Attacked(enemy);
		}

		public override void DoSleep()
		{
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_behaivor != null && !m_behaivor.Finished)
					m_behaivor.Finish(EventResult.COMPLETED);
				m_owner = null;
			}
			base.Dispose(disposing);
		}
		
		public override void BehaivorTick()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.OnTick();
		}
	}
}