//
using System.Collections.Generic;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.AI
{
	public delegate bool SecretaryDelegate(SecretaryBase secretary, PlayerObject player, ItemObject item);

	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class SecretaryBase : NPCBase
	{
		private static Dictionary<string, SecretaryDelegate> LetterSubjects = new Dictionary<string, SecretaryDelegate>();

		public static void RegisterSecretarySubject(string subject, SecretaryDelegate handler)
		{
			LetterSubjects[subject] = handler;
		}

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof (SecretaryBase));
			AIManager.RegisterAI(13, new MobileConstructor(Create));
		}

		public new static UnitBase Create(DBSpawn spawn)
		{
			return new SecretaryBase(spawn);
		}

		public SecretaryBase(DBSpawn spawn)
			: base(spawn)
		{
		}

		public void AnalyzeItems()
		{
		}

		public bool AddItem(PlayerObject player, ItemObject item)
		{
			if (item.Template.ObjectId == 8383)
			{
				DBMailMessage message = (DBMailMessage) Database.Instance.FindObjectByKey(typeof (DBMailMessage), item.ItemTextID);


				if (message == null)
				{
					Chat.System(player.BackLink.Client, "I can't read this letter");
					return false;
				}

				int pos = message.Body.IndexOf("\r\n\r\n");

				if (pos == -1)
				{
					Chat.System(player.BackLink.Client, "Letter is not properly formatted");
					return false;
				}

				string subject = message.Body.Substring(0, message.Body.IndexOf("\r\n\r\n"));

				if (!LetterSubjects.ContainsKey(subject))
				{
					Chat.System(player.BackLink.Client, "We don't process such letters");
					return false;
				}

				return LetterSubjects[subject](this, player, item);
			}
			else if (item.Template.Class == ITEMCLASS.TRADEGOODS && item.Template.SubClass == 4)
			{
				Chat.System(player.BackLink.Client, "Oh, thank you!");
				return true;
			}

			Chat.System(player.BackLink.Client, "I don't need that item");
			return false;
			//if (item.Template.ObjectId != 8383 && item.Template.Class != ITEMCLASS.TRADEGOODS && item.Template.SubClass != 4)
			//{
			//    Chat.System(client, "You can't sell this!");
			//    pkg.Write(0x02);
			//    client.Send(pkg);
			//    return;
			//}
		}
	}
}