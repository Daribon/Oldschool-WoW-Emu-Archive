//
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.ServerScripts.AI.Behaivors;
using RunServer.Common;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class NPCBase : UnitBase
	{
		private Behaivor m_behaivor;

		private PooledList<DBSpell> m_train;
		private PooledList<TradeItem> m_trade;

		public class TradeItem
		{
			private uint m_itemId;
			private int m_displayId;
			private int m_quantity;
			private int m_price;
			private int m_randomId;
			private int m_count;

			private DBItemTemplate m_template;

			#region Properties

			public uint ItemID
			{
				get { return m_itemId; }
			}

			public int DisplayID
			{
				get { return m_displayId; }
			}

			public int Quantity
			{
				get { return m_quantity; }
				set { m_quantity = value; }
			}

			public int Price
			{
				get { return m_price; }
			}

			public int RandomID
			{
				get { return m_randomId; }
			}

			public int Count
			{
				get { return m_count; }
			}

			public DBItemTemplate Template
			{
				get { return m_template; }
			}

			#endregion

			public TradeItem(DBTrade trade)
			{
				m_itemId = trade.TargetID;
				m_displayId = trade.Target.DisplayID;
				m_price = trade.Target.BuyPrice;
				m_quantity = trade.Quantity;
				m_count = trade.Count;
				m_randomId = trade.RandomID;
				m_template = trade.Target;
			}

			public TradeItem(DBItem item)
			{
				m_itemId = item.TemplateID;
				m_displayId = item.Template.DisplayID;
				m_price = item.Template.BuyPrice;
				m_quantity = 1;
				m_count = item.StackCount;
				m_randomId = item.RandomPropertyID;
				m_template = item.Template;
			}
		}

		#region Properties

		public PooledList<TradeItem> Trade
		{
			get { return m_trade; }
		}

		public PooledList<DBSpell> Train
		{
			get { return m_train; }
		}

		public bool Talker
		{
			get { return (NPC_Flags & 1) == 1; }
		}

		public bool Quester
		{
			get { return (NPC_Flags & 2) == 2; }
		}

		public bool Trader
		{
			get { return (NPC_Flags & 4) == 4; }
		}

		public bool Taxi
		{
			get { return (NPC_Flags & 8) == 8; }
		}

		public bool Trainer
		{
			get { return (NPC_Flags & 16) == 16; }
		}

		public bool Storage
		{
			get { return (NPC_Flags & 65536) == 65536; }
		}

		public bool Secretary
		{
			get { return (NPC_Flags & 131072) == 131072; }
		}

		#endregion

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(NPCBase));
			AIManager.RegisterAI(2, new MobileConstructor(Create));
			AIManager.RegisterAI(3, new MobileConstructor(Create));
		}

		public static UnitBase Create(DBSpawn spawn)
		{
			return new NPCBase(spawn);
		}

		public NPCBase(DBSpawn spawn) : base(spawn)
		{
		}

		public override void DoSleep()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.Finish(EventResult.COMPLETED);

			if (m_train != null)
				m_train = null;
			/*if (m_trade != null)
				m_trade = null;*/

			if (Position.DistanceSqrd(Spawn.Position) > 5f)
			{
				Position = Spawn.Position;
				MapTile.Map.Move(this);
			}
		}

		public override void DoAwake()
		{
			if (m_behaivor == null)
				m_behaivor = new StandingInvulAI(this);

			m_behaivor.Start();
		}

		/*public override bool Attackable
		{
			get
			{
				return false;
			}
		}*/

		protected override void StartFightEvent(LivingObject enemy)
		{
			Init();
			DoAwake();
			base.StartFightEvent(enemy);
		}
		public override void Attacked(LivingObject enemy)
		{
			Init();
			DoAwake();
			m_behaivor.Attacked(enemy);
		}

		private void DoGenerateTrade()
		{
			if (m_trade != null)
				return;

			if (m_spawn.Trade == null)
				Database.Instance.ResolveRelations(m_spawn, typeof (DBTrade));

			m_trade = new PooledList<TradeItem>();
			foreach(DBTrade trade in m_spawn.Trade)
				m_trade.Add(new TradeItem(trade));
		}

		private void DoGenerateTrain()
		{
			if (m_train != null)
				return;
			if (m_spawn.Train == null)
				Database.Instance.ResolveRelations(m_spawn, typeof (DBTrain));
						
			m_train = new PooledList<DBSpell>();
			foreach (DBTrain train in m_spawn.Train)
				m_train.Add(train.Target);
		}
		
		public void ReinitTrain(uint group)
		{
			m_spawn.TrainGroupID = group;
			m_spawn.Train = null;
			m_train = null;
			DoGenerateTrain();
		}


		public void InitVendor()
		{
			DoGenerateTrain();
			DoGenerateTrade();
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_train != null)
					m_train = null;
				if (m_trade != null)
					m_trade = null;
				if (m_behaivor != null && !m_behaivor.Finished)
					m_behaivor.Finish(EventResult.COMPLETED);
			}
			base.Dispose(disposing);
		}
		public override void BehaivorTick()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.OnTick();
		}
	}
}