using System;
using RunServer.Common;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public class StandingInvulAI : Behaivor
	{
		public static uint SnowballSpellId = 21343;
		public static DBSpell SnowballSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), SnowballSpellId);

		private DateTime m_helpCalled;
		private bool m_yelled;


		protected override bool ShouldAttackPlayer(LivingObject p)
		{
			return
				p != null &&
				p.Attackable &&
				p.Position.DistanceFlatSqrd(m_unit.Position) <= 15f &&
				Utility.Chance(0.04);
		}


		public StandingInvulAI(UnitBase unit)
			: base(unit)
		{
		}

		private void CallForHelp(LivingObject enemy)
		{
			if (m_helpCalled + TimeSpan.FromSeconds(Constants.MobileAIRecalcLong) > CustomDateTime.Now)
				return;
			m_helpCalled = CustomDateTime.Now;

			PlayerObject player = enemy as PlayerObject;
			if (player != null)
			{
				Chat.LocalDefenceMessage(player.Area == null ? player.Zone : player.Area.ObjectId, m_unit, player);
				if (!m_yelled)
				{
					Chat.MonsterYell(m_unit, "Somebody, help me!");
					m_yelled = true;
				}
			}

			if (m_unit.MapTile != null)
				foreach (MapTile mapTile in m_unit.MapTile.Adjacents.Tiles)
					if (mapTile != null)
						for (int i = 0; i < mapTile.Units.Last; i++)
						{
							UnitBase unit = mapTile.Units.InnerArray[i] as GuardBase;
							if (unit != null && !unit.IsDisposed && !unit.Dead && !unit.Attacking &&
							    Faction.SameFaction(m_unit, unit))
								unit.Attacked(enemy);
						}
		}

		public override void Attacked(LivingObject enemy)
		{
			if (enemy != Enemy)
				SetState(MonsterState.Attacking, enemy);
			/*if (State != MonsterState.AggrMovingToEnemy)
				SetState(MonsterState.AggrMovingToEnemy, enemy);*/
			CallForHelp(enemy);
		}

		protected override void Calculate()
		{
			//if (m_position == null)
			//    m_position = new Vector(m_unit.Position.X, m_unit.Position.Y, m_unit.Position.Z);

			switch (State)
			{
				case MonsterState.Attacking:
					if (Enemy != null && !Enemy.Dead && Enemy.MapTile != null)
					{
						if (Enemy.Position.DistanceAvr(m_unit.Position) > m_unit.CombatReach + Enemy.BoundingRadius)
							SetState(MonsterState.AggrMovingToEnemy, Enemy);
					}
					else
						SetState(MonsterState.Idle, null);
					break;
/*					if (Event == null || Event.Finished)
						switch (Event == null ? EventResult.ERROR : Event.Result)
						{
							case EventResult.TARGET_TO_FAR:
								SetState(MonsterState.MovingToEnemy, Enemy);
								break;
							default:
								SetState(MonsterState.Idle, null);
								break;
						}
					break;*/
				case MonsterState.AggrMovingToEnemy:
					if (Event == null || Event.Finished)
						switch (Event == null ? EventResult.ERROR : Event.Result)
						{
							case EventResult.COMPLETED:
								SetState(MonsterState.Attacking, Enemy);
								break;
							case EventResult.NEED_RECALC:
								SetState(State, Enemy, true);
								break;
							default:
								SetState(MonsterState.Idle, null);
								break;
						}
					break;
				case MonsterState.Returning:
					if ((Event == null || Event.Finished))
						SetState(MonsterState.Idle, null);
					break;
					/*case MonsterState.Looking:
					if ( Event.Finished )
						SetState(MonsterState.Idle,null);
					break;*/
				case MonsterState.Idle:
				default:
					if (Weather.Cristmas && Utility.Chance(0.3))
					{
						PlayerObject enemy = SearchMobile(OBJECTTYPE.PLAYER, true) as PlayerObject;
						if (enemy != null)
						{
							SpellCastEvent snowball = new SingleTargetCast(m_unit, SnowballSpell, 2, enemy, false);
							snowball.Start();
							Chat.MonsterSay(m_unit, enemy, "� ����� �����! :)");
						}
					}

					if (m_unit.Position.DistanceAvr(m_unit.Position) > Constants.MobileMaxOffspawnRange)
						SetState(MonsterState.Returning, null);
					break;
			}
		}
	}
}