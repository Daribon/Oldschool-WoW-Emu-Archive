using System;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	public class RoamingRangedAI : Behaivor
	{
		protected override bool ShouldAttackMonster(LivingObject unit)
		{
			return
				unit != null &&
				unit.Attackable &&
				unit.Level <= m_unit.Level &&
				!Faction.SameFaction(m_unit, unit) &&
				Faction.ShouldAttackMonster(m_unit.Faction, unit.Faction) &&
				Utility.Chance(0.08) &&
				Math.Abs(unit.Position.Z - m_unit.Position.Z) <= Constants.MonsterZSightRange &&
				unit.Position.DistanceAvr(m_unit.Position) <= Constants.MonsterSightRange;
		}

		protected override bool ShouldAttackPlayer(LivingObject er)
		{
			PlayerObject player = er as PlayerObject;

			if (player == null || !player.Attackable)
				return false;

			if (player == Enemy)
				return true;

			if (m_unit.Attackers.Contains(player.GUID))
				return true;

			if (!Faction.ShouldAttackPlayer(m_unit.Faction, player.Faction))
				return false;

			if (Math.Abs(player.Position.Z - m_unit.Position.Z) > Constants.MonsterZSightRange)
				return false;

			float distance = player.Position.DistanceAvr(m_unit.Position);

			if (!player.Stealth && distance < 5f)
				return true;

			float sightRange = Constants.MonsterSightRange + m_unit.Level - player.Level;

			if (sightRange < 5f)
				return false;

			if (sightRange > 45f)
				sightRange = 45f;

			if (m_unit.Level >= 60 && m_unit.Creature.Elite > 0)
				sightRange *= 2f;

			if (!m_unit.Position.InFront(m_unit.Facing, player.Position))
				if (player.Stealth)
					return false;
				else
					sightRange /= 2;

			return distance <= sightRange;
		}

		protected override MonsterState DefaultSearchState
		{
			get { return MonsterState.AggrMovingToEnemy/*Range*/; }
		}
		
		public RoamingRangedAI(UnitBase unit) : base(unit)
		{
		}

		//public override void Attacked(LivingObject enemy)
		//{
			///*if (enemy == null)
			//    return;
			//if (State != MonsterState.Attacking)
			//    if (CanCast())
			//        SetState(MonsterState.Casting, enemy);
			//    else
			//        SetState(MonsterState.AggrMovingToEnemy, enemy);
			//else*/
			//if (m_unit == null || State == MonsterState.AggrMovingToEnemy)
			//    return;
			//{
			//    LivingObject aggroer = m_unit.Attackers.MostAggressive(m_unit);
			//    if (aggroer == Enemy)
			//        return;
			//    if (aggroer != null)
			//        if (ShouldCast(aggroer))
			//            SetState(MonsterState.Casting, aggroer);
			//        else
			//            SetState(MonsterState.AggrMovingToEnemy, aggroer);
			//    else if (enemy != null && State != MonsterState.Attacking)
			//        SetState(MonsterState.AggrMovingToEnemy, enemy);
			//}

		private void DoAttack(LivingObject enemy)
		{
			/*if (enemy.Position.DistanceAvr(m_unit.Position) > m_unit.CombatReach + enemy.BoundingRadius)
				SetState(MonsterState.AggrMovingToEnemy, enemy);
			else*/
			if (enemy != Enemy)
				SetState(MonsterState.Attacking, enemy);
		}

		public override void Attacked(LivingObject enemy)
		{
			if (m_unit == null)
				return;

			LivingObject aggroer = m_unit.Attackers.MostAggressive;
			if (aggroer == Enemy && m_unit.Attacking)
				return;

			if (m_unit.Attacking && Enemy != null && aggroer != null) // should we switch targets, or still attack old one?
				if (!m_unit.Attackers.Compare(Enemy.GUID, aggroer.GUID, m_unit.Position))
					return;

			if (aggroer != null)
				DoAttack(aggroer);
			else
				if (enemy != null/* && State != MonsterState.Attacking*/)
					DoAttack(enemy);
		}

		private bool ShouldCast(LivingObject enemy, out DBMonsterSpell spell)
		{
			spell = null;
			if (enemy == m_unit)
				return false;

			if (enemy.IsDisposed || !enemy.Attackable)
				return false;

			if (m_unit.Spells == null)
				return false;

			if (m_unit.Pacified || m_unit.Silenced || m_unit.NoControl || m_unit.Stunned/* || m_unit.Rooted*/)
				return false;

			/*if (m_unit.WalkSpeed < 1 || m_unit.Rooted)
				return true;*/

			if (m_unit.Position.DistanceAvr(enemy.Position) < m_unit.CombatReach)
				return false;

			if (Utility.Chance(0.3f))
				return false;

			float distance = m_unit.Position.DistanceAvr(enemy.Position);

			for (int i = 0; i < m_unit.Spells.Length; i++)
				if (
					m_unit.Spells[i].AutoCast &&
					m_unit.Spells[i].Spell.PowerCost < m_unit.Power &&
					m_unit.Spells[i].Cooldown < CustomDateTime.Now &&
					!enemy.Auras.HasAura(m_unit.Spells[i].SpellID) &&
					(m_unit.Spells[i].Spell.MaxRange == 0 || m_unit.Spells[i].Spell.MaxRange < distance) &&
					m_lastSpell != m_unit.Spells[i].SpellID
					)
				{
					spell = m_unit.Spells[i];
					m_lastSpell = m_unit.Spells[i].SpellID;
					return true;
				}

			return false;
		}

		private void IdleMode()
		{
			if (m_unit.Stunned || m_unit.Rooted || m_unit.NoControl)
			{
				SetState(MonsterState.Roaming, null);
				return; // do nothing and roll idle or roaming mode
			}

			if (!m_unit.Pacified)
			{
				/*Attacked(null);

				if (Enemy != null)
					return;*/

				if (Search()) // if there is no enemies or we are pacified (sheep, etc.) - return to spawn
					return;
			}

			if (m_unit.Spawn != null && m_unit.Position.DistanceAvr(m_unit.Spawn.Position) > Constants.MobileMaxOffspawnRange)
			{
				SetState(MonsterState.Returning, null);
				return;
			}
			else
			{
				SetState(MonsterState.Roaming, null);
				return;
			}
		}


		protected override void Calculate()
		{
			/*if (Enemy != null && Enemy.Attackable && !Enemy.IsDisposed)
				if (ShouldCast(Enemy))
					SetState(MonsterStat			 * e.Casting, Enemy);*/

			DBMonsterSpell spell;

			switch (State)
			{
				case MonsterState.Attacking:
					switch (AttackState())
					{
						case EventResult.NOT_FINISHED:
						case EventResult.ERROR:
							if (Enemy != null && Enemy.Attackable && !Enemy.IsDisposed)
							{
								if (m_unit.Position.Distance(Enemy.Position) > m_unit.CombatReach + Enemy.BoundingRadius + 2f)
									if (ShouldCast(Enemy, out spell))
										SetState(MonsterState.Casting, Enemy, spell, false);
									else
										SetState(MonsterState.AggrMovingToEnemy, Enemy, true);
								else 
									if (AttackState() == EventResult.ERROR)
										SetState(State, Enemy, true);
								/*else
									if (ShouldCast(Enemy))
										SetState(MonsterState.Casting, Enemy);*/

							}
							else
								IdleMode();
							break;
						default:
							IdleMode();
							break;
					}

					break;
/*				case MonsterState.Attacking:
					if (m_unit.FightEvent == null || m_unit.FightEvent.Finished)
						SetState(MonsterState.Idle, null);
					else
						if (Enemy != null && !Enemy.Dead && Enemy.MapTile != null)
					{
						if (ShouldCast(Enemy))
							SetState(MonsterState.Casting, Enemy, true);
						else
						if (Enemy.Position.DistanceAvr(m_unit.Position) > m_unit.CombatReach + Enemy.BoundingRadius)
							SetState(MonsterState.AggrMovingToEnemy, Enemy);
					}
					else
						SetState(MonsterState.Idle, null);
					break;*/
/*
					if (Event == null || Event.Finished)
						switch (Event == null ? EventResult.ERROR : Event.Result)
						{
							case EventResult.TARGET_TO_FAR:
								if (ShouldCast(Enemy))
									SetState(MonsterState.Casting, Enemy, true);
								else
									SetState(MonsterState.AggrMovingToEnemy, Enemy);
								//SetState(MonsterState.MovingToEnemyRange,Enemy); else
								break;
							default:
								SetState(MonsterState.Idle, null);
								break;
						}
					break;*/
				case MonsterState.AggrMovingToEnemy:
				case MonsterState.AggrMovingToEnemyRange:
				case MonsterState.MovingToEnemy:
				case MonsterState.MovingToEnemyRange:
					switch (ActionState())
					{
						case EventResult.NOT_FINISHED:
							if (Event is FollowUnitEvent && ((FollowUnitEvent)Event).Near && ShouldCast(Enemy, out spell))
								SetState(MonsterState.Casting, Enemy, spell, false);
							break;
						case EventResult.COMPLETED:
							if (Enemy != null && Enemy.Attackable && !Enemy.IsDisposed)
								if (ShouldCast(Enemy, out spell))
									SetState(MonsterState.Casting, Enemy, spell, false);
								else
									SetState(MonsterState.Attacking, Enemy);
							else 
								IdleMode();
							break;
						case EventResult.NEED_RECALC:
							if (Enemy != null && Enemy.Attackable && !Enemy.IsDisposed)
								SetState(State, Enemy, true);
							else
								IdleMode();
							break;
						case EventResult.CANCELED:
							if (m_unit.Pacified || m_unit.NoControl)
								SetState(MonsterState.Roaming, null);
							else
								if (Enemy != null && Enemy.Attackable && !Enemy.IsDisposed)
									if (ShouldCast(Enemy, out spell))
										SetState(MonsterState.Casting, Enemy, spell, false);
									else
										SetState(MonsterState.Attacking, Enemy);
								else
									IdleMode();
							break;
						case EventResult.TARGET_TO_FAR:
							SetState(MonsterState.Returning, null, true);
							break;
						default:
							IdleMode();
							break;
					}
					break;
				case MonsterState.Casting:
						switch (ActionState())
						{
							case EventResult.NOT_FINISHED:
								break;
							default:
								if (Enemy != null && Enemy.Attackable && !Enemy.IsDisposed)
									if (ShouldCast(Enemy, out spell))
										SetState(MonsterState.Casting, Enemy, spell, true);
									else
									{
										m_lastSpell = 0;
										SetState(MonsterState.Attacking, Enemy);
									}
								else
								{
									m_lastSpell = 0;
									IdleMode();
								}
								break;
						}
					break;
				case MonsterState.Returning:
					switch (ActionState())
					{
						case EventResult.ERROR:
							SetState(MonsterState.Returning, null, true);
							break;
						case EventResult.COMPLETED:
							IdleMode();
							break;
						default:
							Search();
							break;
					}
					break;
				case MonsterState.Roaming:
				case MonsterState.Idle:
				default:
					IdleMode();
					break;
			}
		}
	}
}