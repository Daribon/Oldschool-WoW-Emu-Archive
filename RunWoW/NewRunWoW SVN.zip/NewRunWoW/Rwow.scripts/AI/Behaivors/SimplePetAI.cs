//
using System;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.ServerScripts.AI.Behaivors
{
	[Flags]
	public enum PETFLAGS : int
	{
		NONE = 0,
		AGGRESSIVE = 1,
		FOLLOW = 2,
		DEFENSIVE = 4
	} ;

	public class SimplePetAI : Behaivor
	{
		private LivingObject m_master;
		private PETFLAGS flags;

		public void SetPassive()
		{
			flags = flags & (~PETFLAGS.AGGRESSIVE);
			flags = flags & (~PETFLAGS.DEFENSIVE);
			LogConsole.WriteLine(LogLevel.ECHO, "Pet flags is now " + flags);
		}

		public void SetAggressive()
		{
			flags = flags | (PETFLAGS.AGGRESSIVE);
			flags = flags & (~PETFLAGS.DEFENSIVE);
			LogConsole.WriteLine(LogLevel.ECHO, "Pet flags is now " + flags);
		}

		public void SetFollow()
		{
			flags = flags | (PETFLAGS.FOLLOW);
			SetState(MonsterState.Following, m_master);
			LogConsole.WriteLine(LogLevel.ECHO, "Pet flags is now " + flags);
		}

		public void SetStay()
		{
			flags = flags & (~PETFLAGS.FOLLOW);
			SetState(MonsterState.Idle, null);
			LogConsole.WriteLine(LogLevel.ECHO, "Pet flags is now " + flags);
		}

		public void SetDefensive()
		{
			flags = flags | (PETFLAGS.DEFENSIVE);
			flags = flags & (~PETFLAGS.AGGRESSIVE);
			LogConsole.WriteLine(LogLevel.ECHO, "Pet flags is now " + flags);
		}

		public SimplePetAI(UnitBase unit, LivingObject master) : base(unit)
		{
			m_master = master;
			flags = PETFLAGS.NONE;
		}

		public override void Attacked(LivingObject enemy)
		{
			if (((flags & PETFLAGS.DEFENSIVE) == PETFLAGS.DEFENSIVE) || ((flags & PETFLAGS.AGGRESSIVE) == PETFLAGS.AGGRESSIVE))
				SetState(MonsterState.Attacking, enemy);
			//SetState(MonsterState.AggrMovingToEnemy, Enemy);
		}

		public void Attack(LivingObject enemy)
		{
			SetState(MonsterState.AggrMovingToEnemy, enemy);
		}

		private bool CanCast()
		{
			if (m_unit.Spells == null)
				return false;
			for (int i = 0; i < m_unit.Spells.Length; i++)
				if (m_unit.Spells[i].AutoCast && m_unit.Spells[i].Spell.PowerCost < m_unit.Power)
					return true;
			return false;
		}

		protected override void Calculate()
		{
			if (m_master == null || m_master.Dead || m_master.Position.DistanceAvr(m_unit.Position) > Constants.PetMaxRange)
			{
				m_unit.Die();
				return;
			}

			switch (State)
			{
				case MonsterState.Attacking:
					if (Enemy != null && !Enemy.Dead && Enemy.MapTile != null)
					{
						if (Enemy.Position.DistanceAvr(m_unit.Position) > m_unit.CombatReach + Enemy.BoundingRadius)
							SetState(MonsterState.AggrMovingToEnemy, Enemy);
					}
					else
						SetState(MonsterState.Idle, null);
					break;
/*					if (Event == null || Event.Finished)
						switch (Event == null ? EventResult.ERROR : Event.Result)
						{
							case EventResult.TARGET_TO_FAR:
								SetState(MonsterState.AggrMovingToEnemy, Enemy);
								break;
							default:
								SetState(MonsterState.Idle, null);
								break;
						}
					break;*/
				case MonsterState.Following:
					if (Event == null || Event.Finished || ((flags & PETFLAGS.FOLLOW) != PETFLAGS.FOLLOW))
						SetState(MonsterState.Idle, null);
					break;
				case MonsterState.Casting:
					if (Event == null || Event.Finished)
						SetState(MonsterState.Attacking, Enemy);
					break;
				case MonsterState.AggrMovingToEnemy:
				case MonsterState.MovingToEnemy:
					if (Event == null || Event.Finished)
						switch (Event == null ? EventResult.ERROR : Event.Result)
						{
							case EventResult.COMPLETED:
								if (CanCast())
									SetState(MonsterState.Casting, Enemy);
								else
									SetState(MonsterState.Attacking, Enemy);
								break;
							default:
								SetState(MonsterState.Idle, null);
								break;
						}
					break;
				case MonsterState.Idle:
				default:
					if (((flags & PETFLAGS.AGGRESSIVE) == PETFLAGS.AGGRESSIVE))
					{
						LivingObject aggr = m_master.Attackers.MostAggressive;
						if (aggr != null && !Faction.SameFaction(m_master, aggr))
						{
							SetState(MonsterState.AggrMovingToEnemy, aggr);
							break;
						}
					}
					if (((flags & PETFLAGS.FOLLOW) == PETFLAGS.FOLLOW) &&
					    m_unit.Position.DistanceFlatSqrd(m_master.Position) > ConstantsCache.PetMaxRangeSqrd)
					{
						SetState(MonsterState.Following, m_master);
						break;
					}

					if (m_unit.Health < m_unit.MaxHealth)
					{
						int grow = (int) (Constants.PetRegen*m_unit.MaxHealth);
						if (grow < 1) grow = 1;
						m_unit.Health += grow;	//TODO: add formula
						if (m_unit.Health > m_unit.MaxHealth)
							m_unit.Health = m_unit.MaxHealth;
						m_unit.UpdateData();
					}
					if (m_unit.Power < m_unit.MaxPower)
					{
						int grow = (int) (Constants.PetRegen*m_unit.MaxPower);
						if (grow < 1) grow = 1;
						m_unit.Power += grow;	//TODO: add formula
						if (m_unit.Power > m_unit.MaxPower)
							m_unit.Power = m_unit.MaxPower;
						m_unit.UpdateData();
					}

					break;
			}
		}
	}
}