//
using System.Collections;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerScripts.AI.Behaivors;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class PetBase : UnitBase, IOwnedUnit
	{
		private SimplePetAI m_behaivor;
		private LivingObject m_owner;
		private string m_cname = string.Empty;
		private bool m_grow;
		private DBPet m_dbPet;

		private int m_strength = 0;
		private int m_agility = 0;
		private int m_stamina = 0;
		private int m_intellect = 0;
		private int m_spirit = 0;

		private int m_resist_Physical = 0;
		private int m_resist_Holy = 0;
		private int m_resist_Fire = 0;
		private int m_resist_Nature = 0;
		private int m_resist_Frost = 0;
		private int m_resist_Shadow = 0;
		private int m_resist_Arcane = 0;

		//public Event CastEvent;

		#region Properties

		public LivingObject Owner
		{
			get { return m_owner; }
		}

		public string CustomName
		{
			get { return m_cname; }
			set { m_cname = value; }
		}

		[UpdateValue(UNITFIELDS.PETEXPERIENCE)]
		public override int Exp
		{
			get { return m_exp; }
			set
			{
				m_exp = value;
				/*if (m_owner is PlayerObject && m_grow)
                    ((PlayerObject) m_owner).PetExp = value;*/
				UpdateValue(UNITFIELDS.PETEXPERIENCE);
			}
		}

		[UpdateValue(UNITFIELDS.PETNEXTLEVELEXP)]
		public override int NextLevelExp
		{
			get { return m_nextLevelExp; }
			set
			{
				m_nextLevelExp = value;
				/*if (m_owner is PlayerObject && m_grow)
                    ((PlayerObject) m_owner).PetNextLevelExp = value;*/
				UpdateValue(UNITFIELDS.PETNEXTLEVELEXP);
			}
		}

		[UpdateValue(UNITFIELDS.PETNUMBER)]
		public uint PetNumber
		{
			get { return (uint) GUID; }
		}

		[UpdateValue(UNITFIELDS.PET_NAME_TIMESTAMP)]
		public int PetNameTimestamp
		{
			get { return 4; }
			set { UpdateValue(UNITFIELDS.PET_NAME_TIMESTAMP); }
		}

		public bool Grow
		{
			get { return m_grow; }
		}

		public DBPet DBPet
		{
			get { return m_dbPet; }
		}

		public override int Strength
		{
			get { return m_strength; }
			set
			{
				m_strength = value;
				UpdateValue(UNITFIELDS.STRENGTH);
			}
		}

		public override int Agility
		{
			get { return m_agility; }
			set
			{
				m_agility = value;
				UpdateValue(UNITFIELDS.AGILITY);
			}
		}


		public override int Stamina
		{
			get { return m_stamina; }
			set
			{
				m_stamina = value;
				UpdateValue(UNITFIELDS.STAMINA);
			}
		}


		public override int Intellect
		{
			get { return m_intellect; }
			set
			{
				m_intellect = value;
				UpdateValue(UNITFIELDS.INTELLECT);
			}
		}


		public override int Spirit
		{
			get { return m_spirit; }
			set
			{
				m_spirit = value;
				UpdateValue(UNITFIELDS.SPIRIT);
			}
		}


		public override int Resist_Physical
		{
			get { return m_resist_Physical; }
			set
			{
				m_resist_Physical = value;
				UpdateValue(UNITFIELDS.RESIST_PHYSICAL);
			}
		}

		public override int Resist_Holy
		{
			get { return m_resist_Holy; }
			set
			{
				m_resist_Holy = value;
				UpdateValue(UNITFIELDS.RESIST_HOLY);
			}
		}

		public override int Resist_Fire
		{
			get { return m_resist_Fire; }
			set
			{
				m_resist_Fire = value;
				UpdateValue(UNITFIELDS.RESIST_FIRE);
			}
		}

		public override int Resist_Nature
		{
			get { return m_resist_Nature; }
			set
			{
				m_resist_Nature = value;
				UpdateValue(UNITFIELDS.RESIST_NATURE);
			}
		}

		public override int Resist_Frost
		{
			get { return m_resist_Frost; }
			set
			{
				m_resist_Frost = value;
				UpdateValue(UNITFIELDS.RESIST_FROST);
			}
		}

		public override int Resist_Shadow
		{
			get { return m_resist_Shadow; }
			set
			{
				m_resist_Shadow = value;
				UpdateValue(UNITFIELDS.RESIST_SHADOW);
			}
		}

		public override int Resist_Arcane
		{
			get { return m_resist_Arcane; }
			set
			{
				m_resist_Arcane = value;
				UpdateValue(UNITFIELDS.RESIST_ARCANE);
			}
		}

		#endregion

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof (PetBase));
		}

		public PetBase(DBCreature creature, uint SpellID, DBPet dbPet, Vector position, float facing, LivingObject owner)
			: base(creature, (int) dbPet.Level, position, facing, 0x0, 0x0, owner.Faction)
		{
			m_dbPet = dbPet;
			m_owner = owner;
			m_grow = dbPet.Grows;
			m_summonedBy = m_owner.GUID;
			m_createdBySpell = SpellID;
			m_cname = dbPet.Name;
			if (m_cname != string.Empty)
				Name = m_cname;
			Exp = (int) dbPet.Exp;
			m_behaivor = new SimplePetAI(this, m_owner);
			m_behaivor.Start();

//			Flags = 0x808;
			int level = Level;

			if (m_creature.CreatureType == 3)
			{
				float pow = (level < 14 ? (level * 7.5f + 2.5f) : (level * 38.5f - 433.0f));
				float health = (level < 20 ? (level * 6f + 10f) : (level * 19.75f - 265.4f));
				switch (m_creature.ObjectId)
				{
					case 12922: // Imp Minion
					case 416: // Imp
						m_mindamage = level * 1.2f;
						m_maxdamage = 2 + level * 1.3f;
						m_baseAttackTime = 2400;
						pow += 25;
						break;
					case 8996: // Voidwalker Minion
					case 1860: // Voidwalker
						m_mindamage = 1 + level * 0.4f;
						m_maxdamage = 7 + level * 0.4f;
						m_baseAttackTime = 2100;
						health *= 3.5f;
						break;
					case 1863: // Succubus
					case 10928: // Succubus Minion
						m_mindamage = 31 + level * 1.2f;
						m_maxdamage = 62 + level * 1.3f;
						m_baseAttackTime = 2000;
						health *= 2f;
						break;
					case 417: // Felhunter
					case 10656: // Felhunter Minion?
						m_resist_Arcane =
							m_resist_Fire =
							m_resist_Frost =
							m_resist_Nature =
							m_resist_Physical =
							m_resist_Shadow = level / 2;
						m_mindamage = 40 + level * 0.45f;
						m_maxdamage = 64 + level * 0.4f;
						m_baseAttackTime = 2000;
						health *= 2.5f;
						break;
					case 14668: // Infernal
					case 8616: // Infernal
					case 89: // Infernal
						pow = 0;
						health = 5000;
						m_resist_Fire = 300;
						m_mindamage = 130;
						m_maxdamage = 230;
						level = 60;
						break;
					case 14385: // Doomguard
					case 11859: // Doomguard
						m_mindamage = 150;
						m_maxdamage = 200;
						level = 60;
						health *= 3f;
						break;
				}
				if (Level != level)
					Level = level;
				MaxPower = Power = m_basePower = (int) pow;
				Health = MaxHealth = m_baseHealth = (int) health;
			}
			SendSpells();
		}

		public void SendSpells()
		{
			if (m_owner is PlayerObject && m_creature.CreatureType == 3)
			{

				ShortPacket pkg = new ShortPacket(SMSG.PET_SPELLS);
				pkg.Write(GUID);
				pkg.Write(0);
				pkg.Write(0x00000100); // flags?
				pkg.Write(0x07000002); // attack
				pkg.Write(0x07000000); // stay
				pkg.Write(0x07000001); // follow
				pkg.Write(0x07000003); // dismiss
				pkg.Write(0x02000000);
				pkg.Write(0x04000000);
				pkg.Write(0x05000000);
				pkg.Write(0x06000002); // aggressive
				pkg.Write(0x06000001); // defencive
				pkg.Write(0x06000000); // passive

				if (Creature.ObjectId == 4277)
					pkg.Write((byte)0);
				else
				{
					pkg.Write((byte) m_dbPet.Spells.Count); // number of spells
					foreach (DBPetSpell spell in m_dbPet.Spells)
					{
						pkg.Write((short) spell.SpellID);
						pkg.Write((short) 1); // autocast or other flag
					}
				}
				pkg.Write((byte)0);

				((PlayerObject) m_owner).BackLink.Client.Send(pkg);
			}
		}

		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);
			CreateValue(UNITFIELDS.SUMMONEDBY, array);
			CreateValue(UNITFIELDS.CREATED_BY_SPELL, array);
			if (m_grow)
			{
				CreateValue(UNITFIELDS.PETNUMBER, array);
				CreateValue(UNITFIELDS.PETEXPERIENCE, array);
				CreateValue(UNITFIELDS.PETNEXTLEVELEXP, array);
				CreateValue(UNITFIELDS.PET_NAME_TIMESTAMP, array);
				CreateValue(UNITFIELDS.MAXDAMAGE, array);
				CreateValue(UNITFIELDS.MINDAMAGE, array);
				CreateValue(UNITFIELDS.STRENGTH, array);
				CreateValue(UNITFIELDS.AGILITY, array);
				CreateValue(UNITFIELDS.STAMINA, array);
				CreateValue(UNITFIELDS.INTELLECT, array);
				CreateValue(UNITFIELDS.SPIRIT, array);
				CreateValue(UNITFIELDS.RESIST_PHYSICAL, array);
				CreateValue(UNITFIELDS.RESIST_HOLY, array);
				CreateValue(UNITFIELDS.RESIST_FIRE, array);
				CreateValue(UNITFIELDS.RESIST_NATURE, array);
				CreateValue(UNITFIELDS.RESIST_FROST, array);
				CreateValue(UNITFIELDS.RESIST_SHADOW, array);
				CreateValue(UNITFIELDS.RESIST_ARCANE, array);
				CreateValue(UNITFIELDS.ATTACK_POWER, array);
				CreateValue(UNITFIELDS.ATTACK_POWER_MOD, array);
			}
		}

		public override void Attacked(LivingObject enemy)
		{
			m_behaivor.Attacked(enemy);
		}

		public override void DoSleep()
		{
		}

		public override void DoAwake()
		{
		}

		public override void Die()
		{
			if (m_owner is PlayerObject)
			{
				ShortPacket pkg = new ShortPacket(SMSG.PET_SPELLS);
				pkg.Write(new byte[62]);
				((PlayerObject) m_owner).BackLink.Client.Send(pkg);
				((PlayerObject) m_owner).Pet = null;
				if (Grow)
				{
					m_dbPet.Level = (uint) Level;
					m_dbPet.Name = CustomName;
					m_dbPet.Exp = (uint) Exp;
				}
				m_owner.UpdateData();
			}
			base.Die();
		}

		public void Attack(LivingObject target)
		{
			m_behaivor.Attack(target);
		}

		public void Stay()
		{
			m_behaivor.SetStay();
		}

		public void Aggressive()
		{
			m_behaivor.SetAggressive();
		}

		public void Defensive()
		{
			m_behaivor.SetDefensive();
		}

		public void Passive()
		{
			m_behaivor.SetPassive();
		}

		public void Follow()
		{
			m_behaivor.SetFollow();
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_behaivor != null && !m_behaivor.Finished)
					m_behaivor.Finish(EventResult.COMPLETED);
				m_owner = null;
			}
			base.Dispose(disposing);
		}

		public override void BehaivorTick()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.OnTick();
		}
	}
}