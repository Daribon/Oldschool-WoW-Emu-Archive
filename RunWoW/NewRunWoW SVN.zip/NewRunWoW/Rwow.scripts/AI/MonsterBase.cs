//
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.ServerScripts.AI.Behaivors;
using RunServer.Common.Attributes;
using RunServer.Common;

namespace RunWoW.AI
{
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class MonsterBase : UnitBase
	{
		private Behaivor m_behaivor;
		private bool m_ranged;

		public Behaivor Behaivor
		{
			get { return m_behaivor; }
		}

		[InitializeHandler]
		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(MonsterBase));
			AIManager.RegisterAI(0, new MobileConstructor(Create));
			AIManager.RegisterAI(8, new MobileConstructor(CreateRanged));
		}

		public static UnitBase Create(DBSpawn spawn)
		{
			return new MonsterBase(spawn, spawn.Level < 60 || spawn.Creature.Elite == 0);
		}

		public static UnitBase CreateRanged(DBSpawn spawn)
		{
			return new MonsterBase(spawn, true);
		}

		public MonsterBase(DBSpawn spawn, bool ranged)
			: base(spawn)
		{
			m_ranged = ranged;
		}

		public MonsterBase(DBCreature creature, Vector position, float facing, bool ranged)
			: base(
				creature, creature.Defaults.Level, 
				position, facing, creature.Defaults.Flags, creature.Defaults.NpcFlags,
				creature.Defaults.Faction)
		{
			m_ranged = ranged;
		}

		protected override void StartFightEvent(LivingObject enemy)
		{
			Init();
			DoAwake();
			if (!Attacking && enemy is PlayerObject && Utility.Chance(0.3))
				if (Spawn.Speech != null && Spawn.Speech.AttackedText != null)
					Chat.MonsterSay(this, (PlayerObject) enemy, Spawn.Speech.AttackedText.Text);
			base.StartFightEvent(enemy);
		}

		public override void Attacked(LivingObject enemy)
		{
			Init();
			DoAwake();
			m_behaivor.Attacked(enemy);
		}

		public override void DoSleep()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.Finish(EventResult.COMPLETED);

		}

		public override void DoAwake()
		{
			if (m_behaivor == null)
				m_behaivor = m_ranged ? (Behaivor) new RoamingRangedAI(this) : (Behaivor) new RoamingMonsterAI(this);
			m_behaivor.Start();
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (m_behaivor != null && !m_behaivor.Finished)
					m_behaivor.Finish(EventResult.COMPLETED);
			}
			base.Dispose(disposing);
		}

		public override void BehaivorTick()
		{
			if (m_behaivor != null && !m_behaivor.Finished)
				m_behaivor.OnTick();
		}
	}
}