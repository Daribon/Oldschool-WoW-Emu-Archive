//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.Objects.Misc
{
	//struct UnitAura
	//{
	//    uint m_spellId;
	//    uint m_applications;
	//    uint m_level;
	//    bool m_cancelable;
	//    byte m_flags;
	//    bool m_visible;
	//    DateTime m_duration;

	//    List<BaseAura> m_events;

	//    #region Properties

	//    public uint SpellId
	//    {
	//        get { return m_spellId; }
	//    }

	//    public uint Applications
	//    {
	//        get { return m_applications; }
	//    }

	//    public uint Level
	//    {
	//        get { return m_level; }
	//    }

	//    public bool Cancelable
	//    {
	//        get { return m_cancelable; }
	//    }

	//    public byte Flags
	//    {
	//        get { return m_flags; }
	//    }

	//    public DateTime Duration
	//    {
	//        get { return m_duration; }
	//    }

	//    public bool Visible
	//    {
	//        get { return m_visible; }
	//    }

	//    #endregion

	//    public UnitAura(uint spellId, uint applications, uint level, bool cancelable, byte flags, bool visible)
	//    {
	//        m_spellId = spellId;
	//        m_applications = applications;
	//        m_level = level;
	//        m_cancelable = cancelable;
	//        m_flags = flags;
	//        m_events = new List<BaseAura>(4);
	//        m_duration = CustomDateTime.Now;
	//        m_visible = visible;
	//    }

	//    public void AddEffect(AURAEFFECT effect, BaseAura auraEvent)
	//    {
	//        lock(m_events)
	//            m_events.Add(auraEvent);
	//    }

	//    public void Cancel()
	//    {
	//        lock(m_events)
	//            foreach (BaseAura auraEvent in m_events)
	//                auraEvent.Finish();

	//        m_events = null;
	//    }
	//}
	public class UIntPool : GenericPool<uint>
	{
		public static UIntPool Instance = new UIntPool();

		private UIntPool()
			: base(100, 5000, 64)
		{
		}
	}

	public class UnitAuras
	{
		private LivingObject m_owner;

		private uint[] m_auras;
		private uint[] m_applications;
		private uint[] m_flags;
		private uint[] m_levels;
		private uint m_state;

		private uint m_count;
		//private bool[] m_cancelable;
		private uint[] m_nevents;
		private bool m_cleaning = false;
		private DateTime[] m_durations;
		private Dictionary<ulong, List<BaseAura>> m_events;

		private static int MaxAura = 56;
		private static int NegativeStart = Constants.BurningCrusade ? 32/*MaxAura/2*/ : 32;
		private static int MaxLevel = 14;
		private static int MaxApp = 14;
		private static int MaxFlags = 7;
		//private int last=-1;
		//private int count=0;

		[UpdateValue(UNITFIELDS.AURA, ArraySize = 48)]
		public uint[] Auras
		{
			get { return m_auras; }
		}

		[UpdateValue(UNITFIELDS.AURAAPPLICATIONS, ArraySize = 12)]
		public uint[] Applications
		{
			get { return m_applications; }
		}

		[UpdateValue(UNITFIELDS.AURAFLAGS, ArraySize = 6)]
		public uint[] Flags
		{
			get { return m_flags; }
		}

		[UpdateValue(UNITFIELDS.AURALEVELS, ArraySize = 12)]
		public uint[] Levels
		{
			get { return m_levels; }
		}

		[UpdateValue(UNITFIELDS.AURASTATE, Private = false)]
		public uint State
		{
			get { return m_state; }
		}

		public UnitAuras(LivingObject owner)
		{
			m_events = new Dictionary<ulong, List<BaseAura>>();

			//m_cancelable = new bool[MaxAura];
			m_nevents = UIntPool.Instance.AquireBuffer(MaxAura);
			//new uint[MaxAura];
			m_auras = UIntPool.Instance.AquireBuffer(MaxAura);
			//new uint[MaxAura];
			m_durations = new DateTime[MaxAura];
			m_applications = UIntPool.Instance.AquireBuffer(MaxLevel);
			//new uint[MaxLevel];
			m_levels = UIntPool.Instance.AquireBuffer(MaxApp);
			//new uint[MaxApp];
			m_flags = UIntPool.Instance.AquireBuffer(MaxFlags);
			//new uint[MaxFlags];
			m_count = 0;
			m_owner = owner;
			//for (int i = 0; i < MaxLevel; i++)
			//{
			//    m_levels[i] = 0xeeeeeeee;
			//    m_applications[i] = 0xeeeeeeee;
			//}
			/*for (int i=0;i<MaxFlags;i++)
				flags[i]=0xff;*/
			//UpdateAuras();
		}

		~UnitAuras()
		{
			UIntPool.Instance.ReleaseBuffer(m_nevents);
			UIntPool.Instance.ReleaseBuffer(m_auras);
			UIntPool.Instance.ReleaseBuffer(m_applications);
			UIntPool.Instance.ReleaseBuffer(m_levels);
			UIntPool.Instance.ReleaseBuffer(m_flags);
		}

		public int GetAura(uint spell)
		{
			return GetAura(spell, 0);
		}

		public int GetAura(uint spell, int start)
		{
			for (int i = start; i < MaxAura; i++)
				if (m_auras[i] == spell)
					return i;
			return -1;
		}

		public int AddAura(uint spell, byte app, byte level, byte flag, bool cancelAble)
		{
			if (m_cleaning)
				return -1;
			int num = GetAura(spell);

			if (num == -1)
				num = GetAura(0, cancelAble ? 0 : NegativeStart);
			else
			{
				//if (cancelAble == false && m_cancelable[num] == true)
				//    m_cancelable[num] = false;
				return num;
			}
			if (num == -1)
				return -1;

			SetAura(num, spell, app, level, flag, cancelAble);
			m_count++;
			UpdateAura(num);
			//m_owner.UpdateData();

			return num;
		}

		public bool CancelAura(uint spell)
		{
			if (m_cleaning)
				return false;
			int num = GetAura(spell);
			if (num == -1 || num < NegativeStart)
			{
				Unregister(0, spell);
				return true;
			}
			return false;
		}

		public bool CancelAuraForce(uint spell)
		{
			if (m_cleaning)
				return false;
			
			Unregister(0, spell);
			return true;
		}

		private void RemoveAuraIcon(int num)
		{
			if (num == -1)
				return;
			SetAura(num, 0, (byte) 0, (byte) 0, 0, false);
			m_nevents[num] = 0;
			/*if (num == last)
                last--;*/
			m_count--;
			UpdateAura(num);
		}

		public void Register(BaseAura aura)
		{
			if (m_cleaning)
				return;

			lock (m_events)
			{
				List<BaseAura> auras;

				if (!m_events.ContainsKey(aura.Caster.GUID))
					m_events.Add(aura.Caster.GUID, auras = new List<BaseAura>());
				else
					auras = m_events[aura.Caster.GUID];

				if (!auras.Contains(aura))
				{
					auras.Add(aura);

					if (aura.Number != -1)
						m_nevents[aura.Number]++;
				}
			}
		}

		public void Unregister(ulong owner, uint spell)
		{
			if (m_cleaning)
				return;

			//int number = GetAura(spell);

			lock (m_events)
				foreach (KeyValuePair<ulong, List<BaseAura>> pair in m_events)
					if (pair.Key == owner || owner == 0)
					{
						List<BaseAura> toRemove = new List<BaseAura>();
					
						foreach (BaseAura aura in pair.Value)
							if (aura.Spell.SpellID == spell)
								toRemove.Add(aura);

						foreach (BaseAura aura in toRemove)
						{
							pair.Value.Remove(aura);
							AuraTickManager.Instance.Unregister(aura, false);

							if (aura.Number != -1)
							{
								m_nevents[aura.Number]--;
								if (m_nevents[aura.Number] <=0)
									RemoveAuraIcon(aura.Number);
							}
						}
					}

		}
		
		public void UnregisterByGroup(ulong owner, int spellGroup, int exceptCast)
		{
			if (m_cleaning)
				return;
			
			bool process = false;

			List<uint> toRemove = new List<uint>();

			lock (m_events)
				if (m_events.ContainsKey(owner))
					foreach (BaseAura aura in m_events[owner])
						if (aura.Visible && aura.Spell.SpellGroup == spellGroup && aura.CastNumber != exceptCast)
							toRemove.Add(aura.Spell.ObjectId);

			foreach (uint spell in toRemove)
			{
				Unregister(owner, spell);
				process = true;
			}

			if (process && m_owner != null && !m_owner.IsDisposed)
				m_owner.UpdateData();
		}

		public void UnregisterByAuraKey(ulong owner, int key, int exceptCast)
		{
			if (m_cleaning)
				return;

			bool process = false;
			
			List<uint> toRemove = new List<uint>();
			
			lock (m_events)
				if (m_events.ContainsKey(owner))
					foreach (BaseAura aura in m_events[owner])
						if (aura.Visible && (aura.AuraKey & key) == key && aura.CastNumber != exceptCast)
							toRemove.Add(aura.Spell.ObjectId);

			foreach (uint spell in toRemove)
			{
				Unregister(owner, spell);
				process = true;
			}

			if (process && m_owner != null && !m_owner.IsDisposed)
				m_owner.UpdateData();
		}

		private void UnregisterAllAuras()
		{
			lock (m_events)
			{
				foreach (List<BaseAura> auras in m_events.Values)
				{
					foreach (BaseAura aura in auras)
					{
						AuraTickManager.Instance.Unregister(aura, false);
						if (aura.Number != -1)
							m_nevents[aura.Number] = 0;
					}
					auras.Clear();
				}

				m_events.Clear();
			}
		}

		public void RemoveAllAuras()
		{
			RemoveAllAuras(true);
		}

		public void RemoveAllAuras(bool force)
		{
			if (force)
				m_cleaning = true;
			UnregisterAllAuras();
			for (int i = 0; i < MaxAura; i++)
				RemoveAuraIcon(i);
			m_cleaning = false;
		}

		public bool HasAura(uint spell)
		{
			lock (m_events)
				foreach (List<BaseAura> auras in m_events.Values)
					foreach (BaseAura aura in auras)
						if (aura.Spell.ObjectId == spell)
							return true;

			return false;
			//return GetAura(spell) != -1;
		}

		private void SetAura(int num, uint spell, byte app, byte level, byte flag, bool cancelAble)
		{
			// 6 1342 1 4 			
			int sshift = num%4; // 2
			int snum = num/4; // 1
			uint smul = 1;
			for (int i = 1; i <= sshift; i++)
				smul *= 0x100; // 0x10000
			uint mask = ~(0xff*smul); //0xFF00FFFF

			m_auras[num] = spell;
			m_applications[snum] &= mask; //0xEE00EEEE
			m_applications[snum] |= app*smul; // EE01EEEE
			m_levels[snum] &= mask; //0xEE00EEEE
			m_levels[snum] |= level*smul; //0xEE04EEEE

			/*for(byte i=1;i<4;i++)
				flags[snum/8]=Utility.SetBit(flags[snum/8],(byte)(i+(snum%8)*4),Utility.HasBit(flag,i));*/
			m_flags[snum/2] = 0xdddddddd; //flag;
			if (num >= m_count)
				m_count = (uint) num + 1;
			m_state = 16; //(uint)num;
		}

		public void Save()
		{
		}

		public void SaveAndRemove()
		{
			RemoveAllAuras(true);
			m_owner = null;
		}

		public void SetDuration(int num, int duration)
		{
			PlayerObject owner = m_owner as PlayerObject;
			if (owner == null || owner.IsDisposed)
				return;
			ShortPacket pkg = new ShortPacket(SMSG.UPDATE_AURA_DURATION);
			pkg.Write((byte) num);
			pkg.Write(duration);
			owner.BackLink.Client.Send(pkg);
			m_durations[num] = CustomDateTime.Now.AddMilliseconds(duration);
		}

		public void UpdateDurations()
		{
			if (m_owner == null || m_owner.IsDisposed)
				return;
			DateTime now = CustomDateTime.Now;
			for (int i = 0; i < MaxAura; i++)
				if (m_auras[i] != 0 && m_durations[i] > now)
					SetDuration(i, (int) (m_durations[i] - now).TotalMilliseconds);
		}

		public void UpdateAuras()
		{
			if (m_owner == null || m_owner.IsDisposed)
				return;
			for (int i = 0; i < MaxAura; i++)
				if (m_auras[i] > 0)
					UpdateAura(i);
		}

		public void CreateAuras(BitArray array)
		{
			if (m_owner == null || m_owner.IsDisposed)
				return;
			for (int i = 0; i < MaxAura; i++)
				if (m_auras[i] > 0)
				{
					ObjectBase.CreateValue(UNITFIELDS.AURA + i, array);
					ObjectBase.CreateValue(UNITFIELDS.AURALEVELS + i / 4, array);
					ObjectBase.CreateValue(UNITFIELDS.AURAAPPLICATIONS + i / 4, array);
					ObjectBase.CreateValue(UNITFIELDS.AURAFLAGS + i / 8, array);
					ObjectBase.CreateValue(UNITFIELDS.AURASTATE, array);
				}
		}

		private void UpdateAura(int i)
		{
			if (m_owner == null || m_owner.IsDisposed)
				return;

			m_owner.UpdateValue(UNITFIELDS.AURA + i);
			m_owner.UpdateValue(UNITFIELDS.AURALEVELS + i/4);
			m_owner.UpdateValue(UNITFIELDS.AURAAPPLICATIONS + i/4);
			m_owner.UpdateValue(UNITFIELDS.AURAFLAGS + i/8);
			m_owner.UpdateValue(UNITFIELDS.AURASTATE);
			m_owner.UpdateData();
		}

		public void RemoveAuras(int count, MechanicDispelType dispel)
		{
			List<uint> toRemove = new List<uint>();
			lock (m_events)
				foreach (List<BaseAura> auras in m_events.Values)
					foreach (BaseAura aura in auras)
						if (aura.Visible && aura.Spell.MechanicDispelType == dispel)
							toRemove.Add(aura.Spell.ObjectId);

			int max = toRemove.Count > count ? count : toRemove.Count;
			for (int i = 0; i < max; i++)
				CancelAuraForce(toRemove[i]);
		}

		public void RemoveAuras(int count, SpellDispelType dispel)
		{
			List<uint> toRemove = new List<uint>();
			lock (m_events)
				foreach (List<BaseAura> auras in m_events.Values)
					foreach (BaseAura aura in auras)
						if (aura.Visible && aura.Spell.DispelType == dispel)
							toRemove.Add(aura.Spell.ObjectId);

			int max = toRemove.Count > count ? count : toRemove.Count;
			for (int i = 0; i < max; i++)
				CancelAuraForce(toRemove[i]);
		}
	}
}