using RunWoW.Common;
using RunWoW.DB.DataTables;

namespace RunWoW.Objects.Misc
{
	public class SpellProcessor
	{
		public virtual int ProcessDamage(DBSpell spell, float value, int ticks)
		{
			return (int) value/ticks;
		}

		public virtual int ProcessNonDamage(DBSpell spell, float value)
		{
			return (int) value;
		}

		public virtual float ProcessPctDamage(int category, float value, DAMAGETYPE school)
		{
			return value;
		}

		public int RandomDamage(DBSpell spell, byte efnum)
		{
			return (int)RandomDamage(spell, efnum, 1);
		}
		
		public float RandomDamage(DBSpell spell, byte efnum, int ticks)
		{
			float value = Utility.Random(spell.Effect[efnum].Damage, spell.Effect[efnum].Damage + spell.Effect[efnum].RandomDamage);
			return ProcessDamage(spell, value, ticks);
		}

		public int FullDamage(DBSpell spell, byte efnum)
		{
			float value = spell.Effect[efnum].Value;
			return ProcessDamage(spell, value, 1);
		}

		public int FullValue(DBSpell spell, byte efnum)
		{
			float value = spell.Effect[efnum].Value;
			return ProcessNonDamage(spell, value);
		}

		public float PeriodicDamage(DBSpell spell, byte efnum, int ticks, int bonus)
		{
			float value = spell.Effect[efnum].Value + bonus;
			return ProcessDamage(spell, value, ticks);
		}

		public int PureDamage(DBSpell spell, byte efnum)
		{
			float value = spell.Effect[efnum].Damage;
			return ProcessDamage(spell, value, 1);
		}

		public float FlatPctDamage(DBSpell spell, byte efnum)
		{
			float value = spell.Effect[efnum].Value/100f;
			return ProcessPctDamage((int) spell.Category, value, spell.School);
		}

		public int CastTime(DBSpell spell)
		{
			if (spell.CastTime < 0)
				return 0;
			return
				spell.CastTime + GetModifier((int) spell.Category, SPELLMODIFIER.CAST_TIME, spell.School) +
				(int) (spell.CastTime*GetModifier((int) spell.Category, SPELLMODIFIER.PCT_CAST_TIME, spell.School)/100f);
		}

		public float AdditionalCritChance(DBSpell spell)
		{
			return GetModifier((int) spell.Category, SPELLMODIFIER.CRIT_CHANCE, spell.School)/100f;
		}

		public float AdditionalCritChance(DAMAGETYPE school)
		{
			return GetModifier(0, SPELLMODIFIER.CRIT_CHANCE, school)/100f;
		}

		public float AdditionalCritDamage(DBSpell spell)
		{
			return GetModifier((int)spell.Category, SPELLMODIFIER.PCT_CRIT_DAMAGE, spell.School) / 100f;
		}

		public int Cooldown(DBSpell spell)
		{
			if (spell.CoolDown < 0)
				return 0;
			return spell.CoolDown + GetModifier((int)spell.Category, SPELLMODIFIER.COOLDOWN, spell.School);
		}

		public int Duration(DBSpell spell)
		{
			if (spell.Duration < 0)
				return 0;
			return spell.Duration + GetModifier((int)spell.Category, SPELLMODIFIER.DURATION, spell.School);
		}

		public int PowerCost(DBSpell spell, int level, int baseMaxPower)
		{
			int powerCostPercent = spell.PowerCostPercent;

			if (
				spell.SpellID == 633 ||
				spell.SpellID == 2800 ||
				spell.SpellID == 9257 ||
				spell.SpellID == 10310 ||
				spell.SpellID == 17233 ||
				spell.SpellID == 20233 ||
				spell.SpellID == 20236 ||
				spell.SpellID == 27154
				)
				powerCostPercent = 100;

			int value = spell.PowerCost + powerCostPercent * baseMaxPower / 100 + spell.PowerCostPerLevel * level;

			if (value <= 0)
				return 0;

			value += GetModifier((int) spell.Category, SPELLMODIFIER.POWER_COST, spell.School);
			return value + (int)(value * GetModifier((int)spell.Category, SPELLMODIFIER.PCT_POWER_COST, spell.School) / 100f);
		}

		public uint MaxRange(DBSpell spell)
		{
			if (spell.MaxRange == 0)
				return 0;
			return spell.MaxRange + (uint)GetModifier((int)spell.Category, SPELLMODIFIER.RANGE, spell.School);
		}

		public float AvoidInterruptionChance(DBSpell spell)
		{
			if (spell.CastTime == 0)
				return 1f;
			return GetModifier((int)spell.Category, SPELLMODIFIER.PCT_INTERRUPT, spell.School) / 100f;
		}

		protected virtual int GetModifier(int category, SPELLMODIFIER effect, DAMAGETYPE school)
		{
			return 0;
		}

		public virtual void Clean()
		{
		}
	}
}