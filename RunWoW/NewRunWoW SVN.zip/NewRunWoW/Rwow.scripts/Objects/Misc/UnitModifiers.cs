using System.Collections.Specialized;
using RunServer.Common;
using RunWoW.Common;

namespace RunWoW.Objects.Misc
{
	public class ModifierPair
	{
		private long m_key;
		private float m_value;

		public long Key
		{
			get { return m_key; }
			set { m_key = value; }
		}

		public float Value
		{
			get { return m_value; }
			set { m_value = value; }
		}

		public ModifierPair(long key, float value)
		{
			m_key = key;
			m_value = value;
		}
	}

	public class UnitModifiers
	{
		public const long DefaultKey = 0;

		private PooledList<ModifierPair>[] m_modifiers;
		private bool m_inited;

		private ObjectBase m_owner;

/*		public UnitModifiers()
		{
			m_inited = false;
		}*/

		public UnitModifiers(ObjectBase owner)
		{
			m_owner = owner;
			m_inited = false;
		}

		private void Init()
		{
			if (m_inited)
				return;
			m_modifiers = new PooledList<ModifierPair>[(int) MODIFIER.MAX + 1];
			m_inited = true;
		}

		public ModifierPair RegisterModifier(MODIFIER index, float value, long key)
		{
			Init();

			PooledList<ModifierPair> list;
			if (m_modifiers[(int)index] == null)
				m_modifiers[(int)index] = list = new PooledList<ModifierPair>();
			else
				list = m_modifiers[(int) index];

			ModifierPair pair = new ModifierPair(key, value);

			lock (list)
			{
				if (list.Count >= 10)
					LogConsole.WriteLine(LogLevel.WARNING, "Warning, registering modifier of type {0} while 10 are active, owner is {1}", index, m_owner.Name);

				if (list.Count >= 25)
				{
					LogConsole.WriteLine(LogLevel.WARNING, "WARNING, registering modifier of type {0} while 25 are active, owner is {1}", index, m_owner.Name);
					list.RemoveAt(0);
				}
				for (int i = 0; i < list.Count; i++)
					if (list[i].Key == key)
					{
						list[i] = pair;
						return pair;
					}

				list.Add(pair);
			}
			return pair;
		}

		public void UnregisterModifier(MODIFIER index, ModifierPair pair)
		{
			if (!m_inited)
				return;

			PooledList<ModifierPair> list = m_modifiers[(int)index];

			if (list == null)
				return;

			lock (list)
			{
				list.Remove(pair);
				if (list.Count == 0)
					m_modifiers[(int)index] = null;
			}

		}

		public void UnregisterAllModifiers(MODIFIER index)
		{
			if (!m_inited)
				return;

			PooledList<ModifierPair> list = m_modifiers[(int)index];

			if (list == null)
				return;

			lock (list)
			{
				list.Clear();
				m_modifiers[(int) index] = null;
			}
		}

		public void UnregisterAllModifiers()
		{
			if (!m_inited)
				return;
			for (int i = 0; i < (int) MODIFIER.MAX; i++)
				if (m_modifiers[i] != null)
				{
					lock (m_modifiers[i])
					{
						m_modifiers[i].Clear();
						m_modifiers[i] = null;
					}
				}
		}

		#region Getters

		public float this[MODIFIER index]
		{
			get
			{
				if (!m_inited)
					return 0f;

				if (m_modifiers[(int) index] == null)
					return 0f;

				ListDictionary values = new ListDictionary();

				lock (m_modifiers[(int) index])
					foreach (ModifierPair pair in m_modifiers[(int) index])
						if (!values.Contains(pair.Key) || (float) values[pair.Key] < pair.Value)
							values[pair.Key] = pair.Value;

				float result = 0f;
				foreach (float value in values.Values)
					result += value;

				return result;
			}
		}

		public float GetFloat(MODIFIER index)
		{
			return this[index];
		}

		public int GetInt(MODIFIER index)
		{
			return (int) this[index];
		}

		public bool GetBool(MODIFIER index)
		{
			return this[index] != 0f;
		}
		
		public int GetMixed(MODIFIER i1, MODIFIER i2, int original)
		{
			return (int) (this[i1] + this[i2]*original);
		}

		public float GetMixed(MODIFIER i1, MODIFIER i2, float original)
		{
			return this[i1] + this[i2]*original;
		}

		public float GetPct(MODIFIER i, float original)
		{
			return this[i]*original;
		}

		public int GetPct(MODIFIER i, int original)
		{
			return (int) (this[i]*original);
		}

		public float GetAddPct(MODIFIER i, float original)
		{
			return (this[i] + 1)*original;
		}

		public int GetAddPct(MODIFIER i, int original)
		{
			return (int) ((this[i] + 1)*original);
		}

		#endregion
	}
}