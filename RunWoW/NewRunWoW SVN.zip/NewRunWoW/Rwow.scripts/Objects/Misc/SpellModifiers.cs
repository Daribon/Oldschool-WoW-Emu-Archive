using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;

namespace RunWoW.Objects.Misc
{
	public class SortedIntQueue
	{
		private List<int> m_list = new List<int>();

		public void Enqueue(int value)
		{
			lock (m_list)
			{
				if (m_list.Count == 0 || value < m_list[m_list.Count - 1])
					m_list.Add(value);
				else
				{
					int pos = 0;

					for (int i = 0; i < m_list.Count; i++)
						if (value > m_list[i])
						{
							pos = i;
							break;
						}
					m_list.Insert(pos, value);
				}
			}
		}

		public int Dequeue()
		{
			lock (m_list)
				return m_list[0];
		}

		public void Remove(int value)
		{
			lock (m_list)
			{
				for (int i = 0; i < m_list.Count; i++)
					if (value > m_list[i])
					{
						m_list.RemoveAt(i);
						return;
					}
				//throw new Exception("Asked to remove non-existing value " + value);
			}
		}

		public int Count
		{
			get { lock (m_list) return m_list.Count; }
		}
	}

	internal class SpellModifier
	{
		private int m_staticValue;
		/*private int m_dynamicValue;
		private SortedIntQueue m_dynamicValues = new SortedIntQueue();*/
		private SPELLMODIFIER m_modifier;

		#region Properties

		public int Value
		{
			get { return m_staticValue/* + m_dynamicValue*/; }
		}

		public SPELLMODIFIER Modifier
		{
			get { return m_modifier; }
		}

		#endregion

		public SpellModifier(SPELLMODIFIER modifier)
		{
			m_modifier = modifier;
		}

		public void Add(int value, bool isStatic)
		{
			//if (isStatic)
				m_staticValue += value;
			/*else
			{
				lock (m_dynamicValues)
					if (value > m_dynamicValue)
					{
						m_dynamicValues.Enqueue(m_dynamicValue);
						m_dynamicValue = value;
					}
					else
					{
						m_dynamicValues.Enqueue(value);
					}
			}*/
		}

		public void Remove(int value, bool isStatic)
		{
			//if (isStatic)
				m_staticValue -= value;
			/*else
			{
				lock (m_dynamicValues)
					if (value == m_dynamicValue)
					{
						if (m_dynamicValues.Count > 0)
							m_dynamicValue = m_dynamicValues.Dequeue();
						else
							m_dynamicValue = 0;
					}
					else
					{
						m_dynamicValues.Remove(value);
					}
			}*/
		}
	}

	public class SpellModifiers : SpellProcessor
	{
		private static int ModifierLength = 41;

		private static List<uint> AllowedSchoolSpells = new List<uint>(new uint[]
		                                                               	{
		                                                               		11115,11367,11368,11369,11370, // Critical Mass
		                                                               		28682, // Combustion
		                                                               		11222,12839,12840,12841,12842 // Arcane focus
		                                                               	});

		private PooledList<SpellModifier>[] m_mods = new PooledList<SpellModifier>[ModifierLength];

		private PooledList<SpellModifier>[] m_damageMods = new PooledList<SpellModifier>[7];

		~SpellModifiers()
		{
			m_mods = null;
		}
		#region Modifiers registration

		public void SetModifier(int category, SPELLMODIFIER effect, DAMAGETYPE school, int value, bool isStatic, uint spellId)
		{
			BitArray barr = new BitArray(new int[] { category });
			for (byte i = 0; i < 32; i++)
				if (barr[i])
				{
					SpellModifier spellMod = findMod(i, effect, true);
					spellMod.Add(value, isStatic);
				}

			if (category == 0 && school != DAMAGETYPE.MAX && AllowedSchoolSpells.Contains(spellId))
				SetSchoolModifier(effect, school, value, isStatic);
		}

		public void SetSchoolModifier(SPELLMODIFIER effect, DAMAGETYPE school, int value, bool isStatic)
		{
			SpellModifier spellMod = findMod(32 + (int)school, effect, true);
			spellMod.Add(value, isStatic);
		}

		public void SetDamageModifier(int spellMask, int value, bool isStatic)
		{
			BitArray barr = new BitArray(new int[] { spellMask });
			for (byte i = 0; i < 7; i++)
				if (barr[i])
				{
					SpellModifier spellMod = findDamageMod(i, true);
					spellMod.Add(value, isStatic);
				}
		}

		public void RemoveModifier(int category, SPELLMODIFIER effect, DAMAGETYPE school, int value, bool isStatic, uint spellId)
		{
			BitArray barr = new BitArray(new int[] { category });
			for (byte i = 0; i < 32; i++)
				if (barr[i])
				{
					SpellModifier spellMod = findMod(i, effect, false);
					if (spellMod != null)
						spellMod.Remove(value, isStatic);
				}

			if (category == 0 && school != DAMAGETYPE.MAX && AllowedSchoolSpells.Contains(spellId))
				RemoveSchoolModifier(effect, school, value, isStatic);
		}

		public void RemoveDamageModifier(int spellMask, int value, bool isStatic)
		{
			BitArray barr = new BitArray(new int[] { spellMask });
			for (byte i = 0; i < 7; i++)
				if (barr[i])
				{
					SpellModifier spellMod = findDamageMod(i, false);
					if (spellMod != null)
						spellMod.Remove(value, isStatic);
				}
		}

		public void RemoveSchoolModifier(SPELLMODIFIER effect, DAMAGETYPE school, int value, bool isStatic)
		{
			SpellModifier spellMod = findMod(32 + (int)school, effect, true);
			if (spellMod != null)
				spellMod.Remove(value, isStatic);
		}

#endregion

		#region Seekers

		private static SpellModifier findMod(PooledList<SpellModifier>[] mods, int index, SPELLMODIFIER effect, bool create)
		{
			if (mods[index] == null)
				if (!create)
					return null;
				else
					mods[index] = new PooledList<SpellModifier>();

			foreach (SpellModifier mod in mods[index])
				if (mod.Modifier == effect)
					return mod;

			if (!create)
				return null;
			else
			{
				SpellModifier result = new SpellModifier(effect);
				mods[index].Add(result);
				return result;
			}
		}

		private SpellModifier findMod(int bit, SPELLMODIFIER effect, bool create)
		{
			return findMod(m_mods, bit, effect, create);
		}

		private SpellModifier findDamageMod(int index, bool create)
		{
			return findMod(m_damageMods, index, SPELLMODIFIER.DAMAGE, create);
		}

#endregion

		public override void Clean()
		{
			m_mods = new PooledList<SpellModifier>[40];
			m_damageMods = new PooledList<SpellModifier>[7];
		}

		private int GetModifier(int category, SPELLMODIFIER effect, DAMAGETYPE school, bool damage)
		{
			int result = 0;
			BitArray barr = new BitArray(new int[] { category });

			for (byte i = 0; i < 32; i++)
				if (barr[i])
				{
					SpellModifier spellMod = findMod(i, effect, false);
					if (spellMod != null)
						result += spellMod.Value;
				}

			if (school != DAMAGETYPE.MAX)
			{
				SpellModifier spellMod = findMod(32 + (int)school, effect, false);
				if (spellMod != null)
					result += spellMod.Value;

				if (damage && effect == SPELLMODIFIER.DAMAGE)
				{
					SpellModifier spellDamageMod = findDamageMod((int)school, false);
					if (spellDamageMod != null)
						result += spellDamageMod.Value;
				}
			}

			return result;
		}

		protected override int GetModifier(int category, SPELLMODIFIER effect, DAMAGETYPE school)
		{
			return GetModifier(category, effect, school, false);
		}

		public override int ProcessNonDamage(DBSpell spell, float value)
		{
			float bonus = GetModifier((int)spell.Category, SPELLMODIFIER.DAMAGE, spell.School, false);
			float percent = GetModifier((int)spell.Category, SPELLMODIFIER.PCT_DAMAGE, spell.School, false) / 100f + 1f;

			if (bonus == 0f && percent == 1f)
				return (int)value;

			return (int)((value + bonus) * percent);
		}

		public override int ProcessDamage(DBSpell spell, float value, int ticks)
		{
			float bonus = GetModifier((int)spell.Category, SPELLMODIFIER.DAMAGE, spell.School, true);
			float percent = GetModifier((int)spell.Category, SPELLMODIFIER.PCT_DAMAGE, spell.School, true) / 100f + 1f;

			if (bonus == 0f && percent == 1f)
				return (int)value;

			float benefit;
			if (spell.AreaCast)
			{
				benefit = spell.CastTime / 10500;
				if (benefit < 0.1429)
					benefit = 0.1429f;
			}
			else
				if (ticks == 1 || spell.Channeled)
				{
					benefit = spell.CastTime / 3500f;
					if (benefit < 0.4286f)
						benefit = 0.4286f;

					if (spell.Name == "Pyroblast")
						benefit = 1f;
				}
				else
				{
					// TODO:  Combination - Standard and Over Time Spell

					if (spell.Name == "Pyroblast")
						benefit = 0.714f;
					else if (spell.Name == "Fireball")
						benefit = 0f;
					else
					{
						benefit = spell.Duration / 15000f;
						if (benefit < 0.2f)
							benefit = 0.2f;
					}

					benefit /= ticks;
				}

			// TODO: healing spell applies percent only to base value
			return (int)((value + bonus * benefit) * percent);
		}

		public override float ProcessPctDamage(int category, float value, DAMAGETYPE school)
		{
			return
				(value + GetModifier(category, SPELLMODIFIER.DAMAGE, school) + value * GetModifier(category, SPELLMODIFIER.PCT_DAMAGE, school) / 100f);
		}
	}
}