using RunWoW.Common;
using RunWoW.DB.DataTables;

namespace RunWoW.Objects.Inventory
{
	public class ContainerInventory : BaseInventory
	{
		public ContainerInventory(ObjectBase owner, int slots)
			: base(owner, (int)CONTAINERFIELDS.SLOTS, slots)
		{
		}

		public override PlayerObject Owner
		{
			get { return ((ContainerObject) m_owner).ContainedIn.Owner; }
		}

		public override bool AcceptItem(DBItem item)
		{
			ContainerObject owner = m_owner as ContainerObject;
			if (owner == null)
				return false;
			
			switch (owner.Template.Class)
			{
				case ITEMCLASS.CONTAINER:
					switch (owner.Template.BagSubClass)
					{
						case BAGSUBCLASS.ENGINEERING:
							return item.Template.Class == ITEMCLASS.TRADEGOODS; // wrong
//						case BAGSUBCLASS.ENCHANTING:
//							return item.Template.Class == ITEMCLASS.REAGENT; // wrong
						case BAGSUBCLASS.HERBS:
							return item.Template.Class == ITEMCLASS.TRADEGOODS && item.Template.Material == 2; // wrong
						case BAGSUBCLASS.SOUL_SHARDS:
							return item.Template.ObjectId == 6265;
						case BAGSUBCLASS.NONE:
							return true;
						default:
							return false;
					}
				case ITEMCLASS.QUIVER:
					if (item.Template.Class != ITEMCLASS.PROJECTILE)
						return false;
					
					switch (owner.Template.QuiverSubClass)
					{
						case QUIVERSUBCLASS.AMMO:
							return item.Template.ProjectileSubClass == PROJECTILESUBCLASS.BULLET;
						case QUIVERSUBCLASS.BOLTS:
							return item.Template.ProjectileSubClass == PROJECTILESUBCLASS.BOLT;
						case QUIVERSUBCLASS.ARROWS:
							return item.Template.ProjectileSubClass == PROJECTILESUBCLASS.ARROW || item.Template.ProjectileSubClass == PROJECTILESUBCLASS.BOLT;
					}
					break;
			}
			return false;
		}
	}
}