//
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;
using System.Collections.Generic;

namespace RunWoW.Objects.Inventory
{
	public abstract class BaseInventory
	{
		protected ObjectBase m_owner;

		protected ulong[] m_slots;

		[UpdateValue(PLAYERFIELDS.INV_SLOTS, ArraySize = 113, OnlyForType = typeof(PlayerObject), Private = true)]
		[UpdateValue(CONTAINERFIELDS.SLOTS, ArraySize = 28, OnlyForType = typeof(ContainerObject), Private = true)]
		public ulong[] Slots
		{
			get { return m_slots; }
		}

		protected ItemObject[] m_invObjects;
		private int m_baseField;
		private int m_itemCount;

		public BaseInventory(ObjectBase owner, int baseField, int count)
		{
			m_slots = new ulong[count];
			m_invObjects = new ItemObject[count];

			m_owner = owner;
			m_baseField = baseField;
			m_itemCount = 0;
		}

		public ItemObject CreateItem(DBItem dbItem, bool send)
		{
			ItemObject item;
			if (dbItem.Template == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "DBItem " + dbItem.ObjectId + " is missing Item template.");
				return null;
			}
			int slot = dbItem.OwnerSlot;
			if (slot >= m_slots.Length)
			{
				LogConsole.WriteLine(LogLevel.ERROR,
				                     "DBItem " + dbItem.ObjectId + ": " + dbItem.Template.Name + " has invalid OwnerSlot: " + slot);
				return AddItem(dbItem, send);
			}
			if (m_slots[slot] != 0)
			{
				LogConsole.WriteLine(LogLevel.ERROR,
				                     "DBItem " + dbItem.ObjectId + ": " + dbItem.Template.Name + " has occupied OwnerSlot: " + slot);
				return AddItem(dbItem, send);
			}
			if (dbItem.Template.InvType == INVTYPE.BAG)
				item = new ContainerObject(dbItem, this);
			else
				item = new ItemObject(dbItem, this);
			m_slots[slot] = item.GUID;
			m_invObjects[slot] = item;
			m_itemCount++;
			UpdateSlot(slot);
			if (send)
			{
				SendCreate(item);
				SendUpdate(item);
			}
		    
			return item;
		}

		public ItemObject DeleteItem(int slot, bool send)
		{
			ItemObject item = GetItem(slot);
			if (item == null)
				return null;
			m_slots[slot] = 0;
			m_invObjects[slot] = null;
			UpdateSlot(slot);
			m_itemCount--;
			item.Delete();

			if (Owner != null)
				Owner.Character.Items.Remove(item.DBItem);
				
			if (send)
				SendDestroy(item);
			return item;
		}

		public ItemObject RemoveItem(int slot, bool send)
		{
			ItemObject item = GetItem(slot);
			if (item == null)
				return null;
			m_slots[slot] = 0;
			m_invObjects[slot] = null;
			UpdateSlot(slot);
			m_itemCount--;
			if (send)
				SendDestroy(item);
			return item;
		}

		public void UpdateItem(int i, bool send)
		{
			UpdateSlot(i);
			if (send)
				SendUpdate(m_invObjects[i]);
		}

		public ItemObject AddItem(DBItem dbItem, bool send, byte i)
		{
			ItemObject dest = m_invObjects[i];
			if (dest == null)
				return null;
			if (
				dest.Entry == dbItem.TemplateID &&
				dest.StackCount + dbItem.StackCount <= dbItem.Template.MaxStack)
			{
				dest.StackCount += dbItem.StackCount;
				UpdateSlot(i);
				if (send)
				{
					SendUpdate(dest);
					ItemAdded(dest);
				}
				DBManager.EraseDBObject(dbItem);
				return dest;
			}
			return null;
		}


		private bool CanAddItem(DBItem dbItem, byte i)
		{
			ItemObject dest = m_invObjects[i];
			return
				dest != null && dest.Entry == dbItem.TemplateID && dest.StackCount + dbItem.StackCount <= dbItem.Template.MaxStack;
		}

		public ItemObject AddNewItem(DBItem dbItem, bool send, byte i)
		{
			if (!AcceptItem(dbItem))
				return null;
			if (m_invObjects[i] == null)
			{
				dbItem.OwnerSlot = i;
				ItemObject result = CreateItem(dbItem, send);
				if (send)
				{
					SendUpdate(result);
					ItemAdded(result);
				}
				return result;
			}
			return null;
		}

		private bool CanAddNewItem(DBItem dbItem, byte i)
		{
			if (!AcceptItem(dbItem))
				return false;
			return m_invObjects[i] == null;
		}

		public ItemObject AddNewItem(DBItem dbItem, bool send)
		{
			if (!AcceptItem(dbItem))
				return null;
			for (byte i = Divider; i < Last; i++) // find empty slot
				if (m_invObjects[i] == null)
				{
					ItemObject tmp = AddNewItem(dbItem, send, i);
					if (tmp != null)
						return tmp;
				}
			
			for (byte i = SubFirst; i <= SubLast; i++)
				if (m_invObjects[i] != null)
				{
					ContainerObject bag = m_invObjects[i] as ContainerObject;
					if (bag != null)
					{
						ItemObject tmp = bag.Inventory.AddNewItem(dbItem, send);
						if (tmp != null)
							return tmp;
					}
				}
			return null;
		}

		private bool CanAddNewItem(DBItem dbItem)
		{
			if (!AcceptItem(dbItem))
				return false;
			for (byte i = Divider; i < Last; i++) // find empty slot
			{
				bool result = CanAddNewItem(dbItem, i);
				if (result)
					return true;
			}
			for (byte i = SubFirst; i <= SubLast; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
				{
					bool result = bag.Inventory.CanAddNewItem(dbItem);
					if (result)
						return true;
				}
			}
			return false;
		}

		public bool AddNewItem(uint templateID, bool send)
		{
			DBItemTemplate templ = DBUtility.GetTemplate(templateID);
			DBItem item = new DBItem(templ);
			if (AddNewItem(item, true) != null)
			{
				item.OwnerID = Owner.CharacterID;
				DBManager.NewDBObject(item);
				return true;
			}
			return false;
		}

		public ItemObject AddExistingItem(DBItem dbItem, bool send)
		{
			for (byte i = Divider; i < Last; i++) // find similar
			{
				ItemObject tmp = AddItem(dbItem, send, i);
				if (tmp != null)
					return tmp;
			}
			for (byte i = SubFirst; i <= SubLast; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
				{
					ItemObject tmp = bag.Inventory.AddExistingItem(dbItem, send);
					if (tmp != null)
						return tmp;
				}
			}
			return null;
		}

		public bool CanAddExistingItem(DBItem dbItem)
		{
			for (byte i = Divider; i < Last; i++) // find similar
			{
				bool result = CanAddItem(dbItem, i);
				if (result)
					return true;
			}
			for (byte i = SubFirst; i <= SubLast; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
				{
					bool result = bag.Inventory.CanAddExistingItem(dbItem);
					if (result)
						return true;
				}
			}
			return false;
		}

		public virtual bool AcceptItem(DBItem item)
		{
			return true;
		}

		public ItemObject AddItem(DBItem dbItem, bool send)
		{
			ItemObject exsisting = AddExistingItem(dbItem, send);
			if (exsisting != null)
				return exsisting;
			return AddNewItem(dbItem, send);
		}

		public bool CanAddItem(DBItem dbItem)
		{
			return CanAddExistingItem(dbItem) || CanAddNewItem(dbItem);
		}

		public void ItemAdded(ItemObject item)
		{
			if (Owner != null)
			{
				if (item.DBItem.ContainerID == item.DBItem.OwnerID)
				{
					byte cont;
					cont = 255;
					/*else
					cont = (byte)(item.DBItem.OwnerSlot - (int)INVSLOT.BAGFIRST);*/

					ShortPacket pkg = new ShortPacket(SMSG.ITEM_PUSH_RESULT);
					pkg.Write(Owner.GUID);
					pkg.Write(0);	//0-looted, 1-from npc
					pkg.Write(1);	//0-received, 1-created
					pkg.Write(1/*item.StackCount*/);	//???
					pkg.Write(/*(byte)item.Template.InvType*/cont); // target container???
					pkg.Write(item.DBItem.TemplateID);
					pkg.Write(0);	//SuffixFactor
					pkg.Write(0);	//random item property id
					pkg.Write(1);	//count of items will added???
					pkg.Write(CountItems(item.DBItem.TemplateID));
					Owner.BackLink.Client.Send(pkg);
				}
			}
			if ((item.Template.BindType == 1 || item.Template.BindType == 4) && !item.Soulbound)
			{
				item.Soulbound = true;
				item.UpdateData();
				UpdateItem(item.DBItem.OwnerSlot, true);
			}
		}

		public ItemObject FindItem(int model)	//model???
		{
			for (byte i = Divider; i < Last; i++)
				if (m_invObjects[i] != null && m_invObjects[i].Entry == model)
					return m_invObjects[i];
			for (byte i = SubFirst; i <= SubLast; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
				{
					ItemObject tmp = bag.Inventory.FindItem(model);
					if (tmp != null)
						return tmp;
				}
			}
			return null;
		}

		public ItemObject FindItem(ulong GUID)
		{
			for (byte i = 0; i < Last; i++)
				if (m_invObjects[i] != null && m_invObjects[i].GUID == GUID)
					return m_invObjects[i];
			for (byte i = SubFirst; i <= SubLast; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
				{
					ItemObject tmp = bag.Inventory.FindItem(GUID);
					if (tmp != null)
						return tmp;
				}
			}
			return null;
		}

		public int CountItems(uint model)	//model ???
		{
			int result = 0;
			for (byte i = 0; i < Last; i++)
				if (m_invObjects[i] != null && m_invObjects[i].Entry == model)
					result += m_invObjects[i].StackCount;
			
			for (byte i = SubFirst; i <= SubLast; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
					result += bag.Inventory.CountItems(model);
			}
			return result;
		}

		public ICollection<ItemObject> GetItems(uint model)	//model ???
		{
			List<ItemObject> result = new List<ItemObject>();
			
			for (byte i = 0; i < Last; i++)
				if (m_invObjects[i] != null && m_invObjects[i].Entry == model)
					result.Add(m_invObjects[i]);
			
			for (byte i = SubFirst; i <= SubLast; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
					result.AddRange(bag.Inventory.GetItems(model));
			}
			return result;
		}

		public int ConsumeItems(int model, int quantity)	//model???
		{
			int left = quantity;
			for (byte i = Divider; i < Last; i++)
			{
				ItemObject tmp = m_invObjects[i];
				if (tmp == null || tmp.Entry != model)
					continue;
				if (tmp.StackCount > left)
				{
					tmp.StackCount -= left;
					UpdateItem(tmp.DBItem.OwnerSlot, true);
					return 0;
				}
				left -= tmp.StackCount;
				DeleteItem(tmp.DBItem.OwnerSlot, true);
			}
			for (byte i = SubFirst; i <= SubLast && left > 0; i++)
			{
				ContainerObject bag = m_invObjects[i] as ContainerObject;
				if (bag != null)
					left = bag.Inventory.ConsumeItems(model, left);
			}
			return left;
		}

		public void SwapItems(byte src, byte dest, bool send)
		{
			ItemObject srcitem = GetItem(src);
			ItemObject destitem = GetItem(dest);

			if (srcitem != null && destitem != null &&
			    srcitem.Entry == destitem.Entry &&
			    destitem.StackCount + srcitem.StackCount <= srcitem.DBItem.Template.MaxStack
				) // stack items
			{
				destitem.StackCount += srcitem.StackCount;
				if (send)
					SendUpdate(destitem);
				DeleteItem(src, send);
			}
			else
			{
				if (srcitem != null)
				{
					if (Equipment(src))
						srcitem.OnUnequip(Owner);

					srcitem.DBItem.OwnerSlot = dest;
					m_slots[dest] = srcitem.GUID;
					m_invObjects[dest] = srcitem;

					if (Equipment(dest))
						srcitem.OnEquip(Owner);

					if (send)
						SendUpdate(srcitem);
				}
				else
				{
					m_slots[dest] = 0;
					m_invObjects[dest] = null;
				}

				if (destitem != null)
				{
					if (Equipment(dest))
						destitem.OnUnequip(Owner);

					destitem.DBItem.OwnerSlot = src;
					m_slots[src] = destitem.GUID;
					m_invObjects[src] = destitem;

					if (Equipment(src))
						destitem.OnEquip(Owner);

					if (send)
						SendUpdate(destitem);
				}
				else
				{
					m_slots[src] = 0;
					m_invObjects[src] = null;
				}
			}
			UpdateSlot(src);
			UpdateSlot(dest);
			UpdateInventory();
		}

		public void UpdateSlot(int slot)
		{
			if (!m_owner.IsDisposed)
				m_owner.UpdateValue(m_baseField + slot * 2);
		}

		public void UpdateInventory()
		{
			for (int i = 0; i < m_slots.Length; i++)
				if (m_slots[i] != 0)
					UpdateSlot(i);
		}

		public void CreateInventory(BitArray array)
		{
			for (int i = 0; i < m_slots.Length; i++)
				if (m_slots[i] != 0)
					ObjectBase.CreateValue(m_baseField + i * 2, array);
		}

		public ItemObject GetItem(int slot)
		{
			if (m_invObjects == null)
				return null;
			if (slot < 0 || slot >= m_invObjects.Length)
				return null;
			return m_invObjects[slot];
		}

		public ItemObject this[INVSLOT slot]
		{
			get { return GetItem((int) slot); }
		}

/*		public ItemObject this[INVTYPE slot]
		{
			get { return GetItem((int)slot);}
		}*/

		public ItemObject this[int slot]
		{
			get { return GetItem(slot); }
		}

		public virtual BaseInventory GetSubContainer(byte num)
		{
			if (num == 255)
				return this;
			return null;
		}

		public int ItemCount
		{
			get { return m_itemCount; }
		}
		
		public int FreeSlots
		{
			get
			{
				int count = NumSlots - ItemCount;
				for (byte i = SubFirst; i <= SubLast; i++)
				{
					ContainerObject bag = m_invObjects[i] as ContainerObject;
					if (bag != null)
						count += bag.Inventory.FreeSlots;
				}
				return count;
			}
		}

		public int NumSlots
		{
			get { return m_slots.Length; }
		}

		public abstract PlayerObject Owner { get; }

		public virtual byte Divider
		{
			get { return 0; }
		}

		public virtual byte Last
		{
			get { return (byte) m_invObjects.Length; }
		}

		public virtual byte SubFirst
		{
			get { return 0; }
		}

		public virtual byte SubLast
		{
			get { return 0; }
		}

		public virtual ObjectBase InventoryOwner
		{
			get { return m_owner; }
		}

		public virtual bool Visible(int slot)
		{
			return false;
		}

		public virtual bool Equipment(int slot)
		{
			return false;
		}

		public void SendDestroy(ItemObject item)
		{
			/*if (Visible(item.DBItem.OwnerSlot))
				m_owner.MapTile.SendDestroy(item); else*/
			if (!m_owner.IsDisposed)
				Owner.BackLink.Client.Send(item.DestroyPacket);
		}

		public void SendCreate(ItemObject item)
		{
			/*if (Visible(item.DBItem.OwnerSlot))
				m_owner.MapTile.SendCreate(item); else*/
			if (!m_owner.IsDisposed)
				Owner.BackLink.Client.Send(new CompressedA9Packet(item.CreatePacketFull));
		}

		public void SendUpdate(ItemObject item)
		{
			/*if (Visible(item.DBItem.OwnerSlot))
					m_owner.MapTile.SendUpdate(item); else
			if (m_owner is PlayerObject)
				(m_owner as PlayerObject).BackLink.Client.Send(new CompressedA9Packet(item.UpdatePacketFull));*/
			
			if (m_owner != Owner)
				Owner.UpdateBags();
			else
				m_owner.UpdateData();
		}

		public void Dispose()
		{
			for (int i = 0; i < NumSlots; i++)
				if (this[i] != null)
					this[i].Dispose();
			m_invObjects = null;
			m_owner = null;
		}
	}
}