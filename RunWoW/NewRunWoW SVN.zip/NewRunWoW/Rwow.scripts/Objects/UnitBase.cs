//
using System;
using System.Collections;
using RunServer.Common;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.GamePackets;
using RunWoW.Objects.Misc;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.Objects
{
	/// <summary>
	/// Summary description for UnitBase.
	/// </summary>
	[UpdateObject(MaxFields=(int) UNITFIELDS.MAX)]
	public class UnitBase : LivingObject, ILootable
	{
		protected DBCreature m_creature;
		protected DBSpawn m_spawn;

		private Vector m_position;
		private float m_facing;

		private int m_health;
		private int m_maxHealth;
		private int m_power;
		private int m_maxPower;
		private POWERTYPE m_powerType;
		private int m_level;
		private int m_money;
		private uint m_npcflags;
		private FACTION m_faction;
		private bool m_inWater;

		private int m_displayID;

		protected int m_basePower;
		protected int m_baseHealth;
		protected int m_defence;

		protected int m_baseAttackTime;

		private PooledList<LootHolder> m_loot;
		private PooledList<PlayerReference> m_looters;

		private bool m_moving = false;

		private bool m_skinnable = false;

		private DBMonsterSpell[] m_spells;

		public static long Awakened = 0;
		public static long Sleeping = 0;

		#region Properties

		public PooledList<LootHolder> Loot
		{
			get { return m_loot; }
			set { m_loot = value; }
		}

		public PooledList<PlayerReference> Looters
		{
			get { return m_looters; }
			set { m_looters = value; }
		}

		public override float WalkSpeed
		{
			get { return (m_creature.WalkSpeed > 0 ? m_creature.WalkSpeed : 1f)*m_speedmod; }
		}

		public override float RunningSpeed
		{
			get { return (m_creature.RunningSpeed > 0 ? m_creature.RunningSpeed : 4f)*m_speedmod; }
		}

		public override bool IsDisposed
		{
			get { return Disposed || m_creature == null; }
		}

		public int Money
		{
			get { return m_money; }
			set { m_money = value; }
		}

		public override bool InWater
		{
			get { return m_inWater; }
			set { m_inWater = value; }
		}

		#region Creature Properties

		public bool Moving
		{
			get { return m_moving; }
			set { m_moving = value; }
		}

		public override string Name
		{
			get { return m_creature == null ? GUID.ToString() : m_creature.Name; }
			set { }
		}

		public DBSpawn Spawn
		{
			get { return m_spawn; }
		}

		public DBMonsterSpell[] Spells
		{
			get
			{
				if (m_spells == null && m_spawn != null && m_spawn.Spells != null)
					m_spells = m_spawn.Spells.ToArray();
				return m_spells;
			}
			set { m_spells = value; }
		}


		[UpdateValue(UNITFIELDS.NPC_FLAGS)]
		public uint NPC_Flags
		{
			get { return m_npcflags; }
			set
			{
				m_npcflags = value;
				if (m_spawn != null) m_spawn.NpcFlags = value;
				UpdateValue(UNITFIELDS.NPC_FLAGS);
			}
		}

		public int CreatureType
		{
			get { return m_creature.CreatureType; }
		}

		public int CreatureFamily
		{
			get { return m_creature.CreatureFamily; }
		}

		public override int AttackPower
		{
			get { return 0; }
			set { }
		}

		public override int RangedAttackPower
		{
			get { return 0; }
			set { }
		}

		public override int AttackPowerModifier
		{
			get { return 0; }
			set { }
		}

		public override int RangedAttackPowerModifier
		{
			get { return 0; }
			set { }
		}

		public override int Defence
		{
			get { return m_defence; }
		}


		public DBCreature Creature
		{
			get { return m_creature; }
		}

		#endregion

		#region Object Properties

		public override OBJECTTYPE ObjectType
		{
			get { return OBJECTTYPE.UNIT; }
		}

		public override Vector Position
		{
			get { return m_position; }
			set { m_position = value.Clone(); }
		}


		public override float Facing
		{
			get { return m_facing; }
			set { m_facing = value; }
		}

		#endregion

		#region OBJECTFIELDS

		public override uint Entry
		{
			get { return m_creature.Entry; }
		}

		public override HIER_OBJECTTYPE HierType
		{
			get { return HIER_OBJECTTYPE.UNIT; }
		}

		public override float Scale
		{
			get { return m_creature.Scale != 0 ? m_creature.Scale : (m_creature.Scale = 0.5f); }
			set
			{
				m_creature.Scale = value;
				UpdateValue(OBJECTFIELDS.SCALE);
			}
		}

		#endregion

		#region UNITFIELDS

		public override int Health
		{
			get { return m_health; }
			set
			{
				if (m_health != value)
				{
					m_health = value;
					UpdateValue(UNITFIELDS.HEALTH);
				}
			}
		}

		public override int MaxHealth
		{
			get { return m_maxHealth; }
			set
			{
				m_maxHealth = value;
				UpdateValue(UNITFIELDS.MAX_HEALTH);
			}
		}

		public override int Power
		{
			get { return m_power; }
			set
			{
				if (m_power != value)
				{
					m_power = value;
					UpdateValue(((int) UNITFIELDS.MANA) + (int) m_powerType);
				}
			}
		}

		public override int MaxPower
		{
			get { return m_maxPower; }
			set
			{
				m_maxPower = value;
				UpdateValue(((int) UNITFIELDS.MAX_MANA) + (int) m_powerType);
			}
		}

		public override POWERTYPE PowerType
		{
			get { return m_powerType; }
			set
			{
				m_powerType = value;
				UpdateValue(UNITFIELDS.BYTES_0);
			}
		}

		public override int Level
		{
			get { return m_level; }
			set
			{
				m_level = value;
				UpdateValue(UNITFIELDS.LEVEL);
			}
		}

		public override FACTION Faction
		{
			get { return m_faction; }
			set
			{
				m_faction = value;
				if (m_spawn != null) m_spawn.Faction = value;
				UpdateValue(UNITFIELDS.FACTION);
			}
		}

		public override int DisplayID
		{
			get { return m_displayID; }
			set
			{
				m_displayID = value;
				UpdateValue(UNITFIELDS.DISPLAYID);
			}
		}

		public override int NativeDisplayID
		{
			get { return m_creature.DisplayID; }
		}

		[UpdateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY0)]
		public int VirtualItemMainhandDisplay
		{
			get { return m_spawn != null ? m_spawn.VirtualItem0D : 0; }
			set
			{
				if (m_spawn != null) m_spawn.VirtualItem0D = value;
				UpdateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY0);
			}
		}

		[UpdateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY1)]
		public int VirtualItemOffhandDisplay
		{
			get { return m_spawn != null ? m_spawn.VirtualItem1D : 0; }
			set
			{
				if (m_spawn != null) m_spawn.VirtualItem1D = value;
				UpdateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY1);
			}
		}

		[UpdateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY2)]
		public int VirtualItemRangedDisplay
		{
			get { return m_spawn != null ? m_spawn.VirtualItem2D : 0; }
			set
			{
				if (m_spawn != null) m_spawn.VirtualItem2D = value;
				UpdateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY2);
			}
		}

		[UpdateValue(UNITFIELDS.VIRTUAL_ITEM_INFO0)]
		public ulong VirtualItemMainhand
		{
			get { return m_spawn != null ? m_spawn.VirtualItem0 : 0; }
			set
			{
				if (m_spawn != null) m_spawn.VirtualItem0 = value;
				UpdateValue(UNITFIELDS.VIRTUAL_ITEM_INFO0);
			}
		}

		[UpdateValue(UNITFIELDS.VIRTUAL_ITEM_INFO1)]
		public ulong VirtualItemOffhand
		{
			get { return m_spawn != null ? m_spawn.VirtualItem1 : 0; }
			set
			{
				if (m_spawn != null) m_spawn.VirtualItem1 = value;
				UpdateValue(UNITFIELDS.VIRTUAL_ITEM_INFO1);
			}
		}

		[UpdateValue(UNITFIELDS.VIRTUAL_ITEM_INFO2)]
		public ulong VirtualItemRanged
		{
			get { return m_spawn != null ? m_spawn.VirtualItem2 : 0; }
			set
			{
				if (m_spawn != null) m_spawn.VirtualItem2 = value;
				UpdateValue(UNITFIELDS.VIRTUAL_ITEM_INFO2);
			}
		}

		//	[UpdateValueAttribute(UNITFIELDS.TARGET)]
		protected ulong m_target;

		public override ulong Target
		{
			get { return m_target; }
			set
			{
				UpdateValue(UNITFIELDS.TARGET);
				m_target = value;
			}
		}

		#endregion

		#region UnusedStats

		public override int Agility
		{
			get { return (int) (Level <= 14 ? (19 + Level*0.9f) : (13 + Level*0.3f)); }
			set { }
		}

		public override int Intellect
		{
			get { return (int) (Level <= 10 ? (20 + Level*0.2f) : (16 + Level*0.5f)); }
			set { }
		}

		public override int Spirit
		{
			get { return (int) (Level <= 10 ? (20 + Level*0.3f) : (12 + Level*1.05f)); }
			set { }
		}

		public override int Stamina
		{
			get { return (int) (Level <= 10 ? (21 + Level*1.0f) : (Level*4.25f - 13)); }
			set { }
		}

		public override int Strength
		{
			get { return (int) (Level <= 14 ? (21 + Level*1.0f) : (12 + Level*1.65f)); }
			set { }
		}

		#endregion

		#region Resistances

		private int m_resist_Physical; // = (int)(Math.Pow(Level - 1, 2.3) * m_coef);
		private int m_resist_Holy; // = 0;
		private int m_resist_Fire; // = (int)Utility.Random(0, Level) * m_coef;
		private int m_resist_Nature;
		private int m_resist_Frost;
		private int m_resist_Shadow;
		private int m_resist_Arcane;


		public override int Resist_Physical
		{
			get { return m_resist_Physical + Modifiers.GetInt(MODIFIER.PHYS_RES); }
			set { m_resist_Physical = value; }
		}

		public override int Resist_Holy
		{
			get { return m_resist_Holy + Modifiers.GetInt(MODIFIER.HOLY_RES); }
			set { m_resist_Holy = value; }
		}

		public override int Resist_Fire
		{
			get { return m_resist_Fire + Modifiers.GetInt(MODIFIER.FIRE_RES); }
			set { m_resist_Fire = value; }
		}

		public override int Resist_Nature
		{
			get { return m_resist_Nature + Modifiers.GetInt(MODIFIER.NATURE_RES); }
			set { m_resist_Nature = value; }
		}

		public override int Resist_Frost
		{
			get { return m_resist_Frost + Modifiers.GetInt(MODIFIER.FROST_RES); }
			set { m_resist_Frost = value; }
		}

		public override int Resist_Shadow
		{
			get { return m_resist_Shadow + Modifiers.GetInt(MODIFIER.SHADOW_RES); }
			set { m_resist_Shadow = value; }
		}

		public override int Resist_Arcane
		{
			get { return m_resist_Arcane + Modifiers.GetInt(MODIFIER.ARCANE_RES); }
			set { m_resist_Arcane = value; }
		}

		#endregion

		#endregion

		public static void Initialize()
		{
			UpdateManager.Instance.Register(typeof (UnitBase));
		}

		protected UnitBase(DBSpawn spawn)
			: base(true)
		{
			m_spawn = spawn;
			m_creature = m_spawn.Creature;

			m_level = m_spawn.Level;
			m_nextLevelExp = ExperienceForLevel(m_level)/10;
			m_exp = ExperienceForLevel(m_level - 1)/10;
			m_position = m_spawn.Position.Clone();
			m_position.Z += Constants.MobileZShift;
			m_facing = m_spawn.Facing;
			m_npcflags = m_spawn.NpcFlags;
			m_faction = m_spawn.Faction;

			m_flags = (m_spawn.Flags & ~0x4000000) | 0x800;
			m_bounding = m_creature.MinRange < 0.5f ? 0.5f : m_creature.MinRange;
			m_combatreach = m_creature.MaxRange < 0.5f ? 0.5f : m_creature.MaxRange;
			if (m_combatreach < m_bounding)
				m_combatreach = m_bounding;

			if (m_combatreach > m_bounding * 2)
				m_combatreach = m_bounding * 2;

			AttackTime = m_baseAttackTime = m_creature.AttackTime == 0 ? 2000 : m_creature.AttackTime;

			switch (m_creature.CreatureType)
			{
				case 1: // beast
					m_coef = 1.05f;
					m_money = 0;
					break;
				case 2: // dragon
					m_coef = 1.36f;
					m_money = Utility.Random(m_level, m_level*m_level)*3;
					break;
				case 3: // demon
				case 4: // elemental
					m_coef = 1.26f;
					m_money = Utility.Random(m_level, m_level*m_level)*2;
					break;
				case 7: // humanoid
				case 6: // undead
					m_money = Utility.Random(m_level, m_level*m_level);
					m_coef = 1.12f;
					break;
				case 8: // critter;
					m_coef = 0;
					break;
				default:
					m_money = Utility.Random(m_level, m_level*m_level)/2;
					m_coef = 1f;
					break;
			}

			switch (m_creature.Elite)
			{
				case 1: // Elite
					m_coef *= 1.3f;
					m_money *= 2;
					break;
				case 2: // Rare Elite
					m_coef *= 2f;
					m_money *= 3;
					break;
				case 3: // World Boss
					m_coef *= 5f;
					m_money *= 8;
					break;
				case 4: // Rare
					m_coef *= 1.5f;
					m_money *= 3;
					break;
				case 0: // Normal
				default:
					break;
			}

			m_health = m_maxHealth = m_baseHealth = 
				m_spawn.Health > 100 ? m_spawn.Health : 
				(int) ((m_level*m_level*m_coef + m_level*m_coef*1.15f + 35)*m_creature.HealthPerLevel);

			m_powerType = m_creature.CreatureType == 1 ? POWERTYPE.RAGE : POWERTYPE.MANA;
			m_power = m_maxPower = m_basePower = (m_powerType == POWERTYPE.RAGE) ? 1000 :
				m_spawn.Power > 100 ? m_spawn.Power : 
				m_creature.PowerPerLevel == 1f
					? 0
					: (int)(m_level <= 10 ? (22 + m_level * 2.0f) : (6 + m_level * 3.2f));

			m_guid = ObjectManager.NextGUID();
			m_guid += 0xC000000000000;

			m_speedmod_base = 0.9f; // = m_speedmod_base;
			m_speedmod = m_speedmod_base;

			m_displayID = m_creature.DisplayID;

			m_mountDisplayID = m_creature.MountDisplayID;
			if (MountDisplayID != 0)
			{
				m_bounding += 1;
				m_combatreach += 1;
			}
			//Redress();

			m_resist_Physical = m_creature.Resistance.Physical == -2
			                    	? (int) (m_level*40*m_coef)
			                    	: m_creature.Resistance.Physical;
			m_resist_Holy = m_creature.Resistance.Holy == -2 ? Utility.Random(0, m_level / 2) : m_creature.Resistance.Holy;
			m_resist_Fire = m_creature.Resistance.Fire == -2
			                	? m_creature.Name.StartsWith("Fire") ? -1 : (int) (Utility.Random(0, m_level/2)*m_coef)
			                	: m_creature.Resistance.Fire;
			m_resist_Nature = m_creature.Resistance.Nature == -2
								? (int)(Utility.Random(0, m_level / 2) * m_coef)
			                  	: m_creature.Resistance.Nature;
			m_resist_Frost = m_creature.Resistance.Frost == -2
								? m_creature.Name.StartsWith("Frost") ? -1 : (int)(Utility.Random(0, m_level / 2) * m_coef)
			                 	: m_creature.Resistance.Frost;
			m_resist_Shadow = m_creature.Resistance.Shadow == -2
								? (int)(Utility.Random(0, m_level / 2f) * m_coef)
			                  	: m_creature.Resistance.Shadow;
			m_resist_Arcane = m_creature.Resistance.Arcane == -2
								? (int)(Utility.Random(0, m_level / 2) * m_coef)
			                  	: m_creature.Resistance.Arcane;

			Sheathed = 1;

			InitAttackers();
		}

		public UnitBase(DBCreature creature, int level, Vector position, float facing, int flags, uint npcflags,
		                FACTION faction)
		{
			m_spawn = null;
			m_creature = creature;

			m_level = level;
			m_nextLevelExp = ExperienceForLevel(m_level);
			m_exp = ExperienceForLevel(m_level - 1);
			m_position = position;
			m_position.Z += Constants.MobileZShift;
			m_facing = facing;
			m_npcflags = npcflags;
			m_faction = faction;

			m_flags = flags;

			m_health = m_maxHealth = m_baseHealth = (int) (m_level*m_level*1.245 + m_level*1.5f + 35);

			m_power =
				m_maxPower =
				m_basePower =
				(m_powerType == POWERTYPE.RAGE)
					? 1000
					:
				creature.PowerPerLevel == 1f
					? 0
					: (int) (m_level <= 10 ? (22 + m_level*2.0f) : (10 + m_level*20f));

			m_bounding = m_creature.MinRange;
			m_combatreach = m_creature.MaxRange < 0.5f ? 0.5f : m_creature.MaxRange;
			if (m_combatreach < m_bounding)
				m_combatreach = m_bounding;
			m_powerType = POWERTYPE.FOCUS;

			m_displayID = m_creature.DisplayID;

			m_guid = ObjectManager.NextGUID();
			m_guid += 0xD000000000000;

			m_speedmod_base = 1.4f;
			m_speedmod = m_speedmod_base;

			AttackTime = m_baseAttackTime = m_creature.AttackTime == 0 ? 2000 : m_creature.AttackTime;

			m_money = 0; //Utility.Random(m_level,m_level*m_level)*Utility.Random(0,9)/2;
			m_mountDisplayID = m_creature.MountDisplayID;
			InitAttackers();
			m_coef = 2f;
			Redress();
		}

		public override void Redress()
		{
			if (Modifiers == null || Disposed || Dead)
				return;

			base.Redress();

			int iMaxHealthMod = Modifiers.GetMixed(MODIFIER.MAX_HEALTH, MODIFIER.MAX_HEL_PCT, m_maxHealth);
			int iMaxPowerMod = Modifiers.GetMixed(MODIFIER.MAX_POWER, MODIFIER.MAX_POW_PCT, m_maxPower);

			int IntellectModPos = Modifiers.GetInt(MODIFIER.INT_POS) + Modifiers.GetInt(MODIFIER.ALLSTAT_POS);
			int IntellectModNeg = Modifiers.GetInt(MODIFIER.INT_NEG) + Modifiers.GetInt(MODIFIER.ALLSTAT_NEG);
			int StaminaModPos = Modifiers.GetInt(MODIFIER.STA_POS) + Modifiers.GetInt(MODIFIER.ALLSTAT_POS);
			int StaminaModNeg = Modifiers.GetInt(MODIFIER.STA_NEG) + Modifiers.GetInt(MODIFIER.ALLSTAT_NEG);

			m_maxHealth = m_baseHealth + iMaxHealthMod + (StaminaModPos + StaminaModNeg)*10;
			if (m_health > m_maxHealth)
				m_health = m_maxHealth;
			m_maxPower = m_basePower + iMaxPowerMod + (IntellectModPos + IntellectModNeg)*15;
			if (m_power > m_maxPower)
				m_power = m_maxPower;

			/*m_maxHealth = m_baseHealth + (int)(Modifiers.GetFloat(MODIFIER.STA_POS) * 10f);
			m_maxPower = m_basePower + (int)(Modifiers.GetFloat(MODIFIER.INT_POS) * 10f);*/

			float attackTimeMod = Modifiers.GetFloat(MODIFIER.MELEE_HASTE_PCT);

			if (attackTimeMod != 0f)
				AttackTime = (int) (m_baseAttackTime*attackTimeMod);

			m_speedmod = m_speedmod_base + m_speedmod_base*Modifiers.GetFloat(MODIFIER.SPEED_PCT);

			if (!(this is PetBase))
			{
				m_mindamage = Modifiers.GetAddPct(MODIFIER.DAMAGE_PCT, (float) (4 + 1.3f*m_level*Math.Pow(m_coef, 1.5)));
				m_maxdamage = Modifiers.GetAddPct(MODIFIER.DAMAGE_PCT, (float) (4 + 2.7f*m_level*Math.Pow(m_coef, 1.5)));

				float damageMod = m_baseAttackTime*Modifiers.GetInt(MODIFIER.ATTACK_POW)/14000f;

				if (damageMod < 0)
				{
					damageMod *= 10;

					if (-damageMod > m_mindamage*0.3f)
						damageMod = -m_mindamage*0.3f;
				}

				m_mindamage += damageMod;
				m_maxdamage += damageMod;

				switch (Creature.Elite)
				{
					case 1:
						m_defence = Level*5 + 5;
						break;
					case 2:
						m_defence = Level*5 + 10;
						break;
					case 3:
						m_defence = Level*5 + 15;
						break;
					case 4:
						m_defence = Level*5 + 5;
						break;
					default:
						m_defence = Level*5;
						break;
				}
			}
		}


		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);
			CreateValue(UNITFIELDS.NPC_FLAGS, array);
			if (VirtualItemMainhand != 0)
			{
				CreateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY0, array);
				CreateValue(UNITFIELDS.VIRTUAL_ITEM_INFO0, array);
			}
			if (VirtualItemOffhand != 0)
			{
				CreateValue(UNITFIELDS.VIRTUAL_ITEM_INFO1, array);
				CreateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY1, array);
			}
			if (VirtualItemRanged != 0)
			{
				CreateValue(UNITFIELDS.VIRTUAL_ITEM_SLOT_DISPLAY2, array);
				CreateValue(UNITFIELDS.VIRTUAL_ITEM_INFO2, array);
			}
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
				if (MapTile != null)
					MapTile.Map.Leave(this);

				MapTile = null;
				m_loot = null;
				m_looters = null;
				m_spawn = null;
				m_creature = null;
				m_spells = null;
			}
			base.Dispose(disposing);
		}

		public override void LevelUp()
		{
			if (Exp < NextLevelExp)
				return;
			Level++;
			Exp -= NextLevelExp;
			NextLevelExp = ExperienceForLevel(Level + 1);
			Console.WriteLine("Unit LevelUp doesn't implemented yet");
			int HealthGain = (int) (m_creature.HealthPerLevel + m_level*1.245);
			int PowerGain = PowerType != POWERTYPE.RAGE ? (int) (m_creature.PowerPerLevel + m_level*1.245) : 0;

			m_baseHealth = Health = MaxHealth += HealthGain;
			m_basePower = MaxPower += PowerGain;
			Power = PowerType != POWERTYPE.RAGE ? MaxPower : 0;

			UpdateData();
			if (Exp >= NextLevelExp)
				LevelUp();
		}

		public override bool Dead
		{
			get { return (StandState == UNITSTANDSTATE.DEAD) || (Health <= 0); }
			set
			{
				if (value /* && m_respawnEvent == null*/)
				{
					StandState = UNITSTANDSTATE.DEAD;
					Health = 0;
				}
			}
		}

		public override void Die()
		{
			base.Die();
			GenerateLoot();

			if ((Loot != null && Loot.Count > 0) || Money > 0)
				DynamicFlags |= 1;

			if (Loot != null && Loot.Count > 0 && AllowedLootGroup != 0)
				GamePackets.Loot.OnTargetDie(GroupManager.FindGroup(AllowedLootGroup), this);

			//if ((CreatureType == 1 || CreatureType == 2 || CreatureType == 8) && (CreatureFamily != 3))
			// beast, dragon, critter, !spider
			if (m_skinnable)
				Flags |= 0x4000000;

			//DynamicFlags |= 16;

			/*Event CorpseDespawn = new DespawnEvent(this, Constants.MobileCorpseDespawnTime);
			CorpseDespawn.Start();*/
			MapTile.Map.AddDespawn(this, Constants.MobileCorpseDespawnTime);

			if (Auras != null)
				Auras.SaveAndRemove();

			if (m_spawn != null /* && m_respawnEvent == null*/)
			{
				/*m_respawnEvent = new RespawnEvent(this, (int) (m_coef*Constants.MobileRespawnTime));
				m_respawnEvent.Start();*/
				int respTime = (int) (m_coef*Constants.MobileRespawnTime);

				if (Creature.Elite > 0 && Level > 60)
					respTime = Utility.Random(600, 600 + (Level - 60)*60);

				MapTile.Map.AddUnitRespawn(m_spawn, respTime);
			}
			UpdateData();
			Sleep();
		}


		public override bool Attackable
		{
			get { return !Dead; }
		}

		public void Sleep()
		{
			if (!MapTile.HasAjPlayers)
			{
				if (m_auras != null)
					Sleeping++;

				Deinit();
				Attackers.Clean();
				if (FightEvent != null && !FightEvent.Finished)
					FightEvent.Finish();
				FightEvent = null;
				if (CastEvent != null && !CastEvent.Finished)
					CastEvent.Finish();
				CastEvent = null;

				//if (m_spawn != null)
				//{
				//    m_spawn.Movepoints = null;
				//    m_spawn.Spells = null;
				//    m_spawn.Trade = null;
				//    m_spawn.Train = null;
				//}

				DoSleep();
			}
		}

		public void Awake()
		{
			if (Disposed || m_auras != null)
				return;

			if (m_auras == null)
				Awakened++;

			Init();

			Redress();

			if (m_spawn != null && m_spawn.BehaivorID != 9 && m_spawn.Spells == null && m_spawn.Movepoints == null)
			{
				Database.Instance.ResolveRelations(m_spawn, typeof (DBMonsterSpell));
				Database.Instance.ResolveRelations(m_spawn, typeof (DBMovepoint));
			}

			DoAwake();
		}

		public virtual void DoSleep()
		{
		}

		public virtual void DoAwake()
		{
		}

		protected override int UpdatePacketFlags(bool isPrivate)
		{
			return 0x78;
		}

		public override A9Packet CreatePacketSmall
		{
			get
			{
				Awake();
				return base.CreatePacketSmall;
			}
		}

		public override A9Packet UpdatePacketSmall
		{
			get
			{
				Awake();
				return base.UpdatePacketSmall;
			}
		}

		public override A9Packet[] CreatePacketFull
		{
			get
			{
				Awake();
				return base.CreatePacketFull;
			}
		}

		public bool AllowLoot(PlayerObject looter)
		{
			if (Spawn == null || (AllowedLooter == 0 && AllowedLootGroup == 0))
				return false;
			
			if (AllowedLooter == looter.GUID)
				return true;

			if (AllowedLooter == 0)
			{
				Group group = GroupManager.FindGroup(AllowedLootGroup);

				if (group == null)
					return false;

				return group.Contains(looter.GUID);
			}

			return false;
		}

		public virtual void GenerateLoot()
		{
			if (m_loot != null || m_spawn == null || m_creature == null)
				return;

			if (m_killers == null)
				GetKillers();

			if (m_killers.Count == 0)
				return;

			if (m_spawn.Loot == null)
				Database.Instance.ResolveRelations(m_spawn, typeof (DBLoot));

			PooledList<DBLoot> loots;

			if (WorldBase.WorldLoot == null)
				loots = m_spawn.Loot;
			else
			{
				loots = new PooledList<DBLoot>(m_spawn.Loot);
				loots.AddRange(WorldBase.WorldLoot);
			}

			m_loot = new PooledList<LootHolder>();

			if (loots.Count == 0)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "No loot for creature {0}!", Name);
				return;
			}

			foreach (DBLoot loot in loots)
			{
				DBItemTemplate template = loot.Target;
				if (template == null)
				{
					Console.WriteLine("Unknown item in loot: " + loot.TargetID);
					continue;
				}

				if (loot.WorldLoot)
					if (!template.Quest && template.Class != ITEMCLASS.QUEST && loot.Category != LootCategory.SKINNING)
					{
						if (Level < 60 && template.Itemlevel > Level + Constants.LootLevelFilter)
							continue;

						if (Level >= 30 && template.Itemlevel < Level - Constants.LootLevelFilter)
							continue;

						if ((Level >= 60 || Creature.Elite > 0) && template.OverallQuality < 2)
							continue;
					}

				bool chance = Utility.Chance(loot.Percentage/100.0f + 0.0001f);
				if (!chance)
					continue;

				int count = 1;
				switch (loot.Category)
				{
					case LootCategory.ITEM:
					case LootCategory.LOOT:
						bool cont = false;
						foreach (LootHolder oldloot in m_loot)
							if (oldloot.Item.TemplateID == loot.TargetID)
							{
								cont = true;
								break;
							}
						if (cont)
							continue;

						count = template.MaxStack > 1 ? Utility.Random(1, 3) : 1;

						
						break;
					case LootCategory.QUEST:
						bool drop = false;

						foreach (LivingObject living in m_killers)
						{
							PlayerObject player = living as PlayerObject;
							if (player != null && player.Quests.NeedGather(loot.TargetID, ref count))
							{
								drop = true;
								break;
							}
						}

						if (!drop && template.StartQuestID != 0)
							foreach (LivingObject living in m_killers)
							{
								PlayerObject player = living as PlayerObject;
								if (player == null || player.Inventory.FindItem(loot.TargetID) != null)
									continue;

								PooledList<DBQuest> quests;
								QuestStatus status = PlayerQuests.CheckPlayerQuests(player, new DBQuest[] {template.StartQuest}, out quests);
								if (status == QuestStatus.Available || status == QuestStatus.AvailableRep)
								{
									drop = true;
									break;
								}
							}

						if (!drop)
							continue;
						break;
					case LootCategory.SKINNING:
						m_skinnable = true;
						continue;
					default:
						LogConsole.WriteLine(LogLevel.ECHO, "Wrong loot category " + loot.Category + " for UnitBase");
						break;
				}
				DBItem item = new DBItem(template);
				item.StackCount = count;

				if (template.RandomProperties > 0)
				{
					ICollection rgroups =
						Database.Instance.FindObjectsByField(typeof(DBRandomGroup), "GroupID", template.RandomProperties);

					if (rgroups != null)
					{
						foreach (DBRandomGroup rgroup in rgroups)
						{
							if (Utility.Chance(rgroup.Percent / 100f))
							{
								/*DBItemRandomProperties irand =
									(DBItemRandomProperties)
									Database.Instance.FindObjectByKey(typeof(DBItemRandomProperties), rgroup.RandomProperiesID);*/

								DBItemRandomProperties irand = rgroup.ItemRandomProperties;

								if (irand != null)
								{
									item.RandomPropertyID = rgroup.RandomProperiesID;
									item.Enchantments[DBItem.MaxUserEnchants].ID = irand.EnchantEffect[0];
									item.Enchantments[DBItem.MaxUserEnchants + 1].ID = irand.EnchantEffect[1];
									item.Enchantments[DBItem.MaxUserEnchants + 2].ID = irand.EnchantEffect[2];
								}
								break;
							}
						}
					}
				}
				m_loot.Add(new LootHolder(item));
			}

			if (!m_skinnable && (CreatureType == 1 || CreatureType == 2 || CreatureType == 8) &&
			    (CreatureFamily != 3 && CreatureFamily != 7 && CreatureFamily != 25 && CreatureFamily != 26))
				m_skinnable = true; // allow default loot for beasts, dragons and critters
		}

		public virtual void BehaivorTick()
		{
		}

		public override bool DoTakeDamage(ObjectBase enemy, DAMAGETYPE damageType, DAMAGECATEGORY damageCategory,
		                                  float minDamage, float maxDamage, float hitChance, float critChance,
		                                  float blockChance, float parryChance, float dodgeChance, DBSpell spell, bool offhand)
		{
			Awake();
			//Attacked((LivingObject)enemy);
			return
				base.DoTakeDamage(enemy, damageType, damageCategory, minDamage, maxDamage, hitChance, critChance, blockChance,
				                  parryChance, dodgeChance, spell, offhand);
		}

		public override void Attacked(LivingObject enemy)
		{
			AddThreat(enemy, 1f);
			base.Attacked(enemy);
		}


		public static void Respawn(MapInstance map, DBSpawn param)
		{
			UnitBase unitBase = AIManager.CreateMobile(param);
			map.Enter(unitBase);
			if (unitBase.MapTile.HasAjPlayers)
				unitBase.Awake();
		}

		protected override void StartFightEvent(LivingObject enemy)
		{
			if (FightEvent != null && !FightEvent.Finished)
				FightEvent.ChangeTarget(enemy);
			else
			{
				FightEvent = new MobileCombatEvent(this, enemy);
				FightEvent.Start();
			}
			//Enemy = enemy;
		}

	}
}