//
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects.Inventory;

namespace RunWoW.Objects
{
	[UpdateObject(MaxFields=(int) CONTAINERFIELDS.MAX)]
	public class ContainerObject : ItemObject
	{
		private ContainerInventory m_inventory;

		private int m_numSlots;

		#region Properties

		[UpdateValue(CONTAINERFIELDS.NUM_SLOTS)]
		public int NumSlots
		{
			get { return m_numSlots; }
		}
		
		public override HIER_OBJECTTYPE HierType
		{
			get { return HIER_OBJECTTYPE.CONTAINER; }
		}

		public override OBJECTTYPE ObjectType
		{
			get { return OBJECTTYPE.CONTAINER; }
		}

		[UpdateValue]
		public ContainerInventory Inventory
		{
			get { return m_inventory; }
		}

		#endregion


		public ContainerObject(DBItem item, BaseInventory inventory)
			: base(item, inventory)
		{
			m_numSlots = item.Template.ContainerSlots;
			m_inventory = new ContainerInventory(this, m_numSlots);
			m_guid += 0x1000000000000;
		}


		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);
			CreateValue(CONTAINERFIELDS.NUM_SLOTS, array);
			Inventory.CreateInventory(array);
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
				Inventory.Dispose();
			base.Dispose(disposing);
		}

		public override void Save()
		{
			if (Disposed)
				return;

			for (int i = 0; i < Inventory.NumSlots; i++)
				if (Inventory[i] != null)
					Inventory[i].Save();
			base.Save();
		}

		#region packets

        //public override ShortPacket DestroyPacket
        //{
        //    get
        //    {
        //        CustomArrayList result = new CustomArrayList();
        //        result.AddRange(base.DestroyPacket);
        //        for (int i = 0; i < NumSlots; i++)
        //            if (Inventory[i] != null)
        //                result.AddRange(Inventory[i].DestroyPacket);
        //        return (ShortPacket[]) result.ToArray(typeof (ShortPacket));
        //    }
        //}

        public override A9Packet[] CreatePacketFull
		{
			get
			{
				CustomArrayList result = new CustomArrayList();
				result.AddRange(base.CreatePacketFull);
				for (int i = 0; i < NumSlots; i++)
					if (Inventory[i] != null)
						result.AddRange(Inventory[i].CreatePacketFull);
				return (A9Packet[]) result.ToArray(typeof (A9Packet));
			}
		}

		public override A9Packet[] UpdatePacketFull
		{
			get
			{
				CustomArrayList result = new CustomArrayList();
				result.AddRange(base.UpdatePacketFull);
				for (int i = 0; i < NumSlots; i++)
					if (Inventory[i] != null && Inventory[i].HasUpdates)
						result.AddRange(Inventory[i].UpdatePacketFull);
				return (A9Packet[]) result.ToArray(typeof (A9Packet));
			}
		}

		#endregion

		public new static void Initialize()
		{
			UpdateManager.Instance.Register(typeof (ContainerObject));
		}
	}
}