using RunServer.Common;
using RunWoW.GamePackets;
using RunWoW.Objects.Misc;

namespace RunWoW.Objects
{
	public interface ILootable
	{
		PooledList<LootHolder> Loot { get; }
		PooledList<PlayerReference> Looters { get; set; }
		int Money { get; }
		ulong GUID { get; }
		void Dispose();
		ObjectReference Reference { get; }

		bool AllowLoot(PlayerObject looter);
	}
}
