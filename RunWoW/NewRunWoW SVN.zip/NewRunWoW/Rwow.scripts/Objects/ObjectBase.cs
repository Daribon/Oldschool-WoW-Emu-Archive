//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.Objects.Misc;
using RunWoW.World;

namespace RunWoW.Objects
{
	//public class BoolBufferPool : GenericPool<bool>
	//{
	//    public static int InitialBufferSize = 1500;
	//    private static int MaximumCapacity = 1000;
	//    private static int InitialCapacity = 10;

	//    public static BoolBufferPool Instance = new BoolBufferPool(InitialCapacity, MaximumCapacity, InitialBufferSize);


	//    private BoolBufferPool(int initialCapacity, int maximumCapacity, int initialBufferSize)
	//        : base(initialCapacity, maximumCapacity, initialBufferSize)
	//    {
	//    }
	//}

	
	public abstract class ObjectBase : ManagedDisposableType, IGuidable
	{
		public virtual OBJECTTYPE ObjectType
		{
			get { return OBJECTTYPE.OBJECT; }
		}

		public virtual bool IsDisposed { get { return Disposed; } }

		//private bool[] m_updateValues = null;
		private BitArray m_updateValues = null;
		
		private int m_publicupdates = 0;
		private int m_privateupdates = 0;
		private int m_maxFields = 0;

		protected ulong m_guid = 0;

		private int m_castCount;

		//private A9Packet m_smallCreatePacket;
		
		protected object m_syncRoot = new object();

		#region public properties

		public bool HasPublicUpdates
		{
			get { return m_publicupdates > 0; }
		}

		public bool HasPrivateUpdates
		{
			get { return m_privateupdates > 0; }
		}

		public bool HasUpdates
		{
			get { return HasPublicUpdates || HasPrivateUpdates; }
		}

		public int CastCount
		{
			get { return m_castCount; }
			set { m_castCount = value; }
		}

		#endregion

		#region Fields

		[UpdateValue(OBJECTFIELDS.HIER_TYPE)]
		public virtual HIER_OBJECTTYPE HierType
		{
			get { return HIER_OBJECTTYPE.OBJECT; }
		}

		[UpdateValue(OBJECTFIELDS.ENTRY)]
		public abstract uint Entry { get; }

		[UpdateValue(OBJECTFIELDS.SCALE)]
		public virtual float Scale
		{
			get { return 1.0f; }
			set
			{
			}
		}

		[UpdateValue(OBJECTFIELDS.GUID)]
		public ulong GUID
		{
			get { return m_guid; }
		}

		#endregion

		#region Movement data

		public virtual int MovementFlags
		{
			get { return 0; }
			set
			{
			}
		}

		public virtual float Facing
		{
			get { return 0; }
			set
			{
			}
		}

		public virtual Vector Position
		{
			get { return new Vector(0, 0, 0); }
			set
			{
			}
		}

		public virtual float WalkSpeed
		{
			get { return 1.0f; }
			set
			{
			}
		}

		public virtual float RunningSpeed
		{
			get { return 4.0f; }
			set
			{
			}
		}

		public virtual float RunBackSpeed
		{
			get { return 1.0f; }
			set
			{
			}
		}

		public virtual float SwimSpeed
		{
			get { return 5.0f; }
			set
			{
			}
		}

		public virtual float SwimBackSpeed
		{
			get { return 4.0f; }
			set
			{
			}
		}

		public virtual float TurnRate
		{
			get { return 3.141593f; }
			set
			{
			}
		}

		#endregion

		#region Inner Server data and methods

		private MapTile m_mapTile = null;

		public MapTile MapTile
		{
			get { return m_mapTile; }
			set { m_mapTile = value; }
		}

		public abstract string Name { get; set; }

		public abstract int Level { get; set; }

		public abstract SpellProcessor SpellProcessor { get; }

		public abstract FACTION Faction { get; set; }

		public virtual void Save()
		{
		}

		protected override void Dispose(bool disposing)
		{
            lock (m_syncRoot) // lock disposition to be sure that no create/update is running
            {
                if (!Disposed)
                    if (m_updateValues != null)
                        m_updateValues = null;
            }
		}

		#endregion
		
		protected ObjectBase()
		{
			m_maxFields = UpdateManager.Instance.MaxLength(GetType());
		}

		#region Update helpers

		public void UpdateValue(int field)
		{
			if (Disposed)
				return;

			if (m_updateValues == null)
				m_updateValues = new BitArray(field > m_maxFields ? field : m_maxFields);

			if (!m_updateValues[field])
			{
				m_updateValues[field] = true;

				if (UpdateManager.Instance.IsPrivateField(GetType(), field))
					m_privateupdates++;
				else
					m_publicupdates++;
			}
		}

		#region Assigners

		protected void Assign<T>(ref T var, T value, UNITFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
			{
				var = value;
				UpdateValue((int)field);
			}
		}
		protected T Assign<T>(T var, T value, UNITFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
				UpdateValue((int)field);

			return value;
		}

		protected void Assign<T>(ref T var, T value, OBJECTFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
			{
				var = value;
				UpdateValue((int)field);
			}
		}
		protected T Assign<T>(T var, T value, OBJECTFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
				UpdateValue((int)field);

			return value;
		}

		protected void Assign<T>(ref T var, T value, PLAYERFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
			{
				var = value;
				UpdateValue((int)field);
			}
		}
		protected T Assign<T>(T var, T value, PLAYERFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
				UpdateValue((int)field);

			return value;
		}

		protected void Assign<T>(ref T var, T value, ITEMFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
			{
				var = value;
				UpdateValue((int)field);
			}
		}
		protected T Assign<T>(T var, T value, ITEMFIELDS field)
		{
			if ((var == null && value != null) || (var != null && !var.Equals(value)))
				UpdateValue((int)field);

			return value;
		}

		#endregion

		#region UpdateValue
		
		public void UpdateValue(OBJECTFIELDS field)
		{
			UpdateValue((int)field);
		}

		public void UpdateValue(UNITFIELDS field)
		{
			UpdateValue((int)field);
		}

		public void UpdateValue(PLAYERFIELDS field)
		{
			UpdateValue((int)field);
		}

		public void UpdateValue(ITEMFIELDS field)
		{
			UpdateValue((int)field);
		}

		public void UpdateValue(CONTAINERFIELDS field)
		{
			UpdateValue((int)field);
		}

		#endregion
		#region CreateValue

		public static void CreateValue(int field, BitArray array)
		{
			array[field] = true;
		}

		public static void CreateValue(OBJECTFIELDS field, BitArray array)
		{
			CreateValue((int)field, array);
		}

		public static void CreateValue(UNITFIELDS field, BitArray array)
		{
			CreateValue((int)field, array);
		}

		public static void CreateValue(PLAYERFIELDS field, BitArray array)
		{
			CreateValue((int)field, array);
		}

		public static void CreateValue(ITEMFIELDS field, BitArray array)
		{
			CreateValue((int)field, array);
		}

		public static void CreateValue(CONTAINERFIELDS field, BitArray array)
		{
			CreateValue((int)field, array);
		}

		#endregion

		#endregion

		#region update methods

		protected A9Packet CreateObjectPacket(bool isPrivate)
		{
			A9Packet target = null;

			lock (m_syncRoot)
			try
			{
				if (Disposed)
					return null;

				LogConsole.WriteLine(LogLevel.TRACE, "Initing data create values");

				BitArray createValues = new BitArray(m_maxFields);

				InitCreateFields(createValues);

				target = new A9Packet(m_maxFields + 40);

				PreCreateObjectPacket(target, isPrivate);

				LogConsole.WriteLine(LogLevel.TRACE, "Writing data create values");
				UpdateManager.Instance.WriteUpdates(target, createValues, this, isPrivate, false);
				LogConsole.WriteLine(LogLevel.TRACE, "Writing done");

				return target;
			}
			catch(Exception ex)
			{
				Console.WriteLine("Error creating object packet: " + ex);
				if (target != null)
					target.Dispose();
				return null;
				//throw;
			}
		}

		protected A9Packet UpdateObjectPacket(bool Private, bool clear)
		{
			if ((Private && !HasUpdates) || (!Private && !HasPublicUpdates) || Disposed)
				return null;

			if (m_updateValues == null)
				return null;

			A9Packet target = null;

			lock (m_syncRoot)
			try
			{
				if (Disposed)
					return null;

				target = new A9Packet(m_maxFields + 40);

				PreUpdateObjectPacket(target, Private);

				UpdateManager.Instance.WriteUpdates(target, m_updateValues, this, Private, clear/*Private*/);

				if (clear)
				{
					if (Private)
						m_privateupdates = 0;
					m_publicupdates = 0;
				}

				return target;
			}
			catch (Exception ex)
			{
				Console.WriteLine("Error creating update packet: " + ex);
				if (target != null)
					target.Dispose();
				//throw;
				return null;
			}
		}

		protected void ClearPrivateFields()
		{
			lock(m_syncRoot)
			{
				m_privateupdates = 0;
			}
		}

		public A9Packet SingleFieldPacket(int fieldId)
		{
			lock (m_syncRoot)
			try
			{
				if (Disposed)
					return null;
                
				A9Packet target = new A9Packet();

				PreUpdateObjectPacket(target, false);

				UpdateManager.Instance.WriteSingleUpdate(target, fieldId, this);

				return target;
			}
			catch
			{
				return null;
			}
		}

		protected virtual void InitCreateFields(BitArray array)
		{
			CreateValue(OBJECTFIELDS.GUID, array);
			CreateValue(OBJECTFIELDS.HIER_TYPE, array);
			CreateValue(OBJECTFIELDS.ENTRY, array);
			CreateValue(OBJECTFIELDS.SCALE, array);
		}

		protected virtual void PreCreateObjectPacket(BinWriter target, bool Private)
		{
			bool selfPlayer = ObjectType == OBJECTTYPE.PLAYER && Private;

			if (selfPlayer)
				target.Write((byte) 3); // update type == CreateSelfPlayerObject
			else
				target.Write((byte) 2); // update type == CreateObject

//			target.Write((byte)0xFF);
//			target.Write(GUID);
			target.WriteGuid(GUID);
			target.Write((byte) ObjectType);

			WriteMovementBlock(target, Private);
		}

		protected virtual void PreUpdateObjectPacket(BinWriter target, bool Private)
		{
			if (Disposed)
				return;

			target.Write((byte) 0); // UpdateData 
			target.WriteGuid(GUID);
		}

		private void WriteMovementBlock(BinWriter target, bool Private)
		{
			int updateFlag = UpdatePacketFlags(Private);

			target.Write((byte) updateFlag);

			if ((updateFlag & 0x20) == 0x20)
			{
//TODO: Transport
//TODO: spirithealers...
				target.Write(0);
				target.Write(Utility.PreciseTimestamp()); // timestamp?
			}

			if ((updateFlag & 0x40) == 0x40)
			{
				//TODO: Transport
				target.WriteVector(Position);
				target.Write(Facing);
			}

			if ((updateFlag & 0x20) == 0x20)
			{
				//TODO: Transport
				target.Write(0);	//unknown

				target.Write(WalkSpeed);
				target.Write(RunningSpeed);
				target.Write(RunBackSpeed);
				target.Write(SwimSpeed);
				target.Write(SwimBackSpeed);
				// TODO: Flight Speed?
				target.Write(RunningSpeed);	//fly
				target.Write(RunBackSpeed);	//back fly
				target.Write(TurnRate);
			}

			// TODO: movepoints ???

			if ((updateFlag & 0x10) == 0x10)
				target.Write(0);
			if ((updateFlag & 0x8) == 0x8)
				target.Write(0);
//			if ((updateFlag & 0x4) == 0x4)
//			{
//				target.WriteGuid(GUID);	//???
//			}
			if ((updateFlag & 0x2) == 0x2)	//transport
				target.Write(Utility.PreciseTimestamp()); // timestamp?
		}

		protected abstract int UpdatePacketFlags(bool Private);

		public virtual void UpdateData()
		{
			if (IsDisposed)
				return;

			if (MapTile != null)
				MapTile.HasUpdates = true;
		}

		#endregion

		#region Packets

		public virtual A9Packet [] UpdatePacketFull
		{
            get { return HasUpdates && !Disposed ? new A9Packet[] { UpdateObjectPacket(true, true) } : null; }
		}

		public virtual A9Packet UpdatePacketSmall
		{
			get { return HasPublicUpdates && !Disposed ? UpdateObjectPacket(false, true) : null; }
		}

		public virtual A9Packet [] CreatePacketFull
		{
			get { return !Disposed ? new A9Packet[] { CreateObjectPacket(true) } : null; }
		}

		public virtual A9Packet CreatePacketSmall
		{
			get { return !Disposed ? CreateObjectPacket(false) : null; }
		}

		public virtual ShortPacket DestroyPacket
		{
			get
			{
				ShortPacket pkg = new ShortPacket(SMSG.DESTROY_OBJECT);
				pkg.Write(GUID);
				return pkg;
			}
		}

		public static A9Packet CreateDestroyPacket(List<ulong> guids)
		{
			A9Packet destroy = new A9Packet();
			destroy.Write((byte) 4);
			destroy.Write(guids.Count);
			foreach (ulong guid in guids)
				destroy.WriteGuid(guid);

			return destroy;
		}

		#endregion

		private ObjectReference m_reference;

		public ObjectReference Reference
		{
			get
			{
				if (m_reference == null)
					m_reference = new ObjectReference(this);
				return m_reference;
			}
		}
		
		[InitializeHandler(InitPass.Second)]
		public static void CoInitialize()
		{
			LogConsole.WriteLine(LogLevel.TRACE, "Generating update proxies");
			UpdateManager.Instance.GenerateProxies();
			LogConsole.WriteLine(LogLevel.TRACE, "done");
		}
	}
}