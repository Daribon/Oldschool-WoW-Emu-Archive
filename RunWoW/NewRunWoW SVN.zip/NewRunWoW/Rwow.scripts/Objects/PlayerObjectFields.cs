//
using System;
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.Objects.Inventory;
using RunWoW.Objects.Player;
using RunWoW.World;

namespace RunWoW.Objects
{
	public partial class PlayerObject
	{
		private int m_maxpower = 0;
		private int m_channel_spell;

		private int m_maxhealth = 0;
		private RACE m_forceRace = RACE.ANY;

		private int m_strength = 0;
		private int m_agility = 0;
		private int m_stamina = 0;
		private int m_intellect = 0;
		private int m_spirit = 0;

		private int[] m_resistances = new int[7];

		private ObjectBase m_channelobject = null;
		private byte m_drunk = 0;

		private ObjectBase m_selectedObject = null;
		private ItemObject m_ammo = null;

		private int m_trackResources = 0;
		private int m_trackCreatures = 0;

		private int m_strmodpos = 0;
		private int m_strmodneg = 0;
		private int m_agmodpos = 0;
		private int m_agmodneg = 0;
		private int m_stmodpos = 0;
		private int m_stmodneg = 0;
		private int m_intmodpos = 0;
		private int m_intmodneg = 0;
		private int m_spmodpos = 0;
		private int m_spmodneg = 0;
		private int m_resphysmodpos = 0;
		private int m_resphysmodneg = 0;
		private int m_resholymodpos = 0;
		private int m_resholymodneg = 0;
		private int m_resfiremodpos = 0;
		private int m_resfiremodneg = 0;
		private int m_resnaturemodpos = 0;
		private int m_resnaturemodneg = 0;
		private int m_resfrostmodpos = 0;
		private int m_resfrostmodneg = 0;
		private int m_resshadowmodpos = 0;
		private int m_resshadowmodneg = 0;
		private int m_resarcanemodpos = 0;
		private int m_resarcanemodneg = 0;
		private int m_damphysmodpos = 0;
		private int m_damphysmodneg = 0;
		private int m_damholymodpos = 0;
		private int m_damholymodneg = 0;
		private int m_damfiremodpos = 0;
		private int m_damfiremodneg = 0;
		private int m_damnaturemodpos = 0;
		private int m_damnaturemodneg = 0;
		private int m_damfrostmodpos = 0;
		private int m_damfrostmodneg = 0;
		private int m_damshadowmodpos = 0;
		private int m_damshadowmodneg = 0;
		private int m_damarcanemodpos = 0;
		private int m_damarcanemodneg = 0;

		private float m_damphyspct = 1f;
		private float m_damholypct = 1f;
		private float m_damfirepct = 1f;
		private float m_damnaturepct = 1f;
		private float m_damfrostpct = 1f;
		private float m_damshadowpct = 1f;
		private float m_damarcanepct = 1f;
		private float m_damranpct = 1f;

		private int m_attackPower = 0;
		private int m_rangedAttackPower = 0;
		private int m_attackPowerModifier = 0;
		private int m_rangedAttackPowerModifier = 0;

		private float m_hitChance = 0f;
		private float m_magicHitChance = 0f;
		private float m_rangedHitChance = 0f;
		private float m_critchance = 0f;
		private float m_rangedccritchance = 0f;
		private float m_blockchance = 0f;
		private float m_dodgechance = 0f;
		private float m_parrychance = 0f;
		/*private float m_deflectchance = 0f;*/

		private float m_magicCritChance = 0f;

		private float m_fireCritChance = 0f;
		private float m_holyCritChance = 0f;
		private float m_frostCritChance = 0f;
		private float m_arcaneCritChance = 0f;
		private float m_natureCritChance = 0f;
		private float m_shadowCritChance = 0f;

		private float m_castSpeed = 1f;

		private uint m_watchedFaction = 0xEEEEEEEE;

		#region OBJECTFIELDS

		public override float Scale
		{
			get { return m_scale; }
			set
			{
				m_scale = value;
				UpdateValue(OBJECTFIELDS.SCALE);
			}
		}

		[UpdateValue(OBJECTFIELDS.ENTRY)]
		public override uint Entry
		{
			get { return (uint) DisplayID; }
		}

		#endregion

		#region UNITFIELDS

		public override int Health
		{
			get { return m_character.Health; }
			set { m_character.Health = (short) Assign((int) m_character.Health, value, UNITFIELDS.HEALTH); }
		}

		public override int MaxHealth
		{
			get { return m_maxhealth == 0 ? m_character.MaxHealth : m_maxhealth; }
			set
			{
				m_maxhealth = value;
				UpdateValue(UNITFIELDS.MAX_HEALTH);
			}
		}

		public override POWERTYPE PowerType
		{
			get { return m_character.PowerType; }
			set
			{
				m_character.PowerType = value;
				UpdateValue(UNITFIELDS.BYTES_0);
			}
		}

		public override int Power
		{
			get { return m_character.Power; }
			set
			{
				short nvalue = (short) (value < 0 ? 0 : value);
				if (m_character.Power != nvalue)
				{
					m_character.Power = nvalue;
					UpdateValue(UNITFIELDS.MANA + (int) m_character.PowerType);
				}
			}
		}

		public override int MaxPower
		{
			get { return m_maxpower == 0 ? m_character.MaxPower : m_maxpower; }
			set { Assign(ref m_maxpower, value, UNITFIELDS.MAX_MANA + (int) m_character.PowerType); }
		}

		public float HealthRegenRate
		{
			get { return m_hregen; }
		}

		public float PowerRegenRate
		{
			get { return m_pregen; }
		}

		[UpdateValue(UNITFIELDS.BYTES_0, BytesIndex = 0)]
		public RACE Race
		{
			get { return m_forceRace == RACE.ANY ? m_character.Race : m_forceRace; }
			set
			{
				m_forceRace = value;
				UpdateValue(UNITFIELDS.BYTES_0);
			}
		}

		[UpdateValue(UNITFIELDS.BYTES_0, BytesIndex = 1)]
		public CLASS Class
		{
			get { return m_character.Class; }
		}

		[UpdateValue(UNITFIELDS.BYTES_0, BytesIndex = 2)]
		public byte Gender
		{
			get { return m_character.Gender; }
		}

		public override int Level
		{
			get { return m_character.Level; }
			set { m_character.Level = (byte) Assign((int) m_character.Level, value, UNITFIELDS.LEVEL); }
		}

		public override int Strength
		{
			get { return m_strength == 0 ? m_character.Strength : m_strength; }
			set { Assign(ref m_strength, value, UNITFIELDS.STRENGTH); }
		}

		public override int Agility
		{
			get { return m_agility == 0 ? m_character.Agility : m_agility; }
			set { Assign(ref m_agility, value, UNITFIELDS.AGILITY); }
		}


		public override int Stamina
		{
			get { return m_stamina == 0 ? m_character.Stamina : m_stamina; }
			set { Assign(ref m_stamina, value, UNITFIELDS.STAMINA); }
		}


		public override int Intellect
		{
			get { return m_intellect == 0 ? m_character.Intellect : m_intellect; }
			set { Assign(ref m_intellect, value, UNITFIELDS.INTELLECT); }
		}


		public override int Spirit
		{
			get { return m_spirit == 0 ? m_character.Spirit : m_spirit; }
			set { Assign(ref m_spirit, value, UNITFIELDS.SPIRIT); }
		}

		public override int Resist_Physical
		{
			get { return m_resistances[0]; }
			set { Assign(ref m_resistances[0], value, UNITFIELDS.RESIST_PHYSICAL); }
		}

		public override int Resist_Holy
		{
			get { return m_resistances[1]; }
			set { Assign(ref m_resistances[1], value, UNITFIELDS.RESIST_HOLY); }
		}


		public override int Resist_Fire
		{
			get { return m_resistances[2]; }
			set { Assign(ref m_resistances[2], value, UNITFIELDS.RESIST_FIRE); }
		}


		public override int Resist_Nature
		{
			get { return m_resistances[3]; }
			set { Assign(ref m_resistances[3], value, UNITFIELDS.RESIST_NATURE); }
		}


		public override int Resist_Frost
		{
			get { return m_resistances[4]; }
			set { Assign(ref m_resistances[4], value, UNITFIELDS.RESIST_FROST); }
		}


		public override int Resist_Shadow
		{
			get { return m_resistances[5]; }
			set { Assign(ref m_resistances[5], value, UNITFIELDS.RESIST_SHADOW); }
		}


		public override int Resist_Arcane
		{
			get { return m_resistances[6]; }
			set { Assign(ref m_resistances[6], value, UNITFIELDS.RESIST_ARCANE); }
		}

		[UpdateValue(PLAYERFIELDS.DUEL_ARBITER, Private = false)]
		public ulong DuelArbiter
		{
			get { return m_duelArbiter; }
			set { Assign(ref m_duelArbiter, value, PLAYERFIELDS.DUEL_ARBITER); }
		}

		[UpdateValue(PLAYERFIELDS.DUEL_TEAM, Private = false)]
		public int DuelTeam
		{
			get { return m_duelTeam; }
			set { Assign(ref m_duelTeam, value, PLAYERFIELDS.DUEL_TEAM); }
		}

		[UpdateValue(PLAYERFIELDS.COINAGE, Private = true)]
		public int Money
		{
			get { return m_character.Money; }
			set
			{
				m_character.Money = value;
				UpdateValue(PLAYERFIELDS.COINAGE);
			}
		}

//#if !BURNING_CRUSADE
//		[UpdateValue(PLAYERFIELDS.HONOR, Private = true)]
//#else
			//	[UpdateValue(PLAYERFIELDS.BYTES_5)]
//#endif
			public int Honor
		{
			get { return m_character.Honor; }
			set
			{
				m_character.Honor = value;
//#if !BURNING_CRUSADE
//				UpdateValue(PLAYERFIELDS.HONOR);
//#else
				//UpdateValue(PLAYERFIELDS.BYTES_5);
//#endif
				//RecalcRank();
			}
		}
/*
#if !BURNING_CRUSADE
		[UpdateValue(PLAYERFIELDS.HONORBALE_KILLS, Private = true)]
		public int HKills
		{
			get { return m_character.HKills; }
			set
			{
				m_character.HKills = value;
				UpdateValue(PLAYERFIELDS.HONORBALE_KILLS);
				m_sessionHKills++;
				UpdateValue(PLAYERFIELDS.SESSION_KILLS);
			}
		}

		[UpdateValue(PLAYERFIELDS.DISHONORBALE_KILLS, Private = true)]
		public int DHKills
		{
			get { return m_character.DHKills; }
			set
			{
				m_character.DHKills = value;
				UpdateValue(PLAYERFIELDS.DISHONORBALE_KILLS);
				m_sessionDHKills++;
				UpdateValue(PLAYERFIELDS.SESSION_KILLS);
			}
		}
#else
*/
		[UpdateValue(PLAYERFIELDS.HONORBALE_KILLS, ShortsIndex = 0, Private = true)]
		public short HKills
		{
			get { return (short)m_character.HKills; }
			set
			{
				m_character.HKills = value;
				UpdateValue(PLAYERFIELDS.HONORBALE_KILLS);
				m_sessionHKills++;
				UpdateValue(PLAYERFIELDS.KILLS);
			}
		}

		[UpdateValue(PLAYERFIELDS.HONORBALE_KILLS, ShortsIndex = 1, Private = true)]
		public short DHKills
		{
			get { return (short)m_character.DHKills; }
			set
			{
				m_character.DHKills = value;
				UpdateValue(PLAYERFIELDS.HONORBALE_KILLS);
				m_sessionDHKills++;
				UpdateValue(PLAYERFIELDS.KILLS);
			}
		}
//#endif

		[UpdateValue(PLAYERFIELDS.KILLS, ShortsIndex = 0, Private = true)]
		public ushort SessionHKills
		{
			get { return m_sessionHKills; }
		}

		[UpdateValue(PLAYERFIELDS.KILLS, ShortsIndex = 1, Private = true)]
		public ushort SessionDHKills
		{
			get { return m_sessionDHKills; }
		}

		public override int DisplayID
		{
			get { return m_tempdisplay; }
			set { Assign(ref m_tempdisplay, value, UNITFIELDS.DISPLAYID); }
		}

		public override int NativeDisplayID
		{
			get { return m_character.DisplayID; }
		}

		public override FACTION Faction
		{
			get { return m_character == null ? bRace.Faction : m_character.Faction; }
			set
			{
				m_character.Faction = value;
				UpdateValue(UNITFIELDS.FACTION);
			}
		}

		public override ulong Target
		{
			get { return m_target; }
			set { Assign(ref m_target, value, UNITFIELDS.TARGET); }
		}

		#endregion

		#region PLAYERFIELDS

		[UpdateValue(PLAYERFIELDS.XP, Private = true)]
		public override int Exp
		{
			get { return m_character.Exp; }
			set
			{
				m_character.Exp = value;
				UpdateValue(PLAYERFIELDS.XP);
			}
		}

		[UpdateValue(PLAYERFIELDS.NEXT_LEVEL_XP, Private = true)]
		public override int NextLevelExp
		{
			get { return m_nextLevelExp; }
			set
			{
				m_nextLevelExp = value;
				UpdateValue(PLAYERFIELDS.NEXT_LEVEL_XP);
			}
		}

		[UpdateValue(UNITFIELDS.CHANNEL_SPELL, Private = false)]
		public int ChannelSpell
		{
			get { return m_channel_spell; }
			set
			{
				m_channel_spell = value;
				UpdateValue(UNITFIELDS.CHANNEL_SPELL);
			}
		}

		[UpdateValue(PLAYERFIELDS.PROF_POINTS, Private = true)]
		public int ProfPoints
		{
			get { return m_character.ProfPoints; }
			set
			{
				m_character.ProfPoints = (byte) value;
				UpdateValue(PLAYERFIELDS.PROF_POINTS);
			}
		}

		[UpdateValue(PLAYERFIELDS.TALENT_POINTS, Private = true)]
		public int TalentPoints
		{
			get { return m_character.TalentPoints; }
			set
			{
				m_character.TalentPoints = (byte) value;
				UpdateValue(PLAYERFIELDS.TALENT_POINTS);
			}
		}

		[UpdateValue(PLAYERFIELDS.GUILD_ID, Private = false)]
		public uint GuildID
		{
			get { return m_character.GuildID; }
			set
			{
				m_character.GuildID = value;
				UpdateValue(PLAYERFIELDS.GUILD_ID);
			}
		}

		[UpdateValue(PLAYERFIELDS.GUILD_RANK, Private = false)]
		public uint GuildRank
		{
			get { return m_character.GuildRank; }
			set
			{
				m_character.GuildRank = value;
				UpdateValue(PLAYERFIELDS.GUILD_RANK);
			}
		}

		[UpdateValue(PLAYERFIELDS.GUILD_TIMESTAMP, Private = false)]
		public int GuildTimestampInt
		{
			get { return Utility.Timestamp(GuildTimestamp); }
		}

		public DateTime GuildTimestamp
		{
			get { return m_character.Guild == null ? CustomDateTime.Now : m_character.Guild.CreationDate; }
			set
			{
				/*if (m_character.Guild == null)
					return;*/
				//m_character.Guild.CreationDate = value;
				UpdateValue(PLAYERFIELDS.GUILD_TIMESTAMP);
			}
		}


		public ObjectBase ChannelObject
		{
			get { return m_channelobject; }
			set { Assign(ref m_channelobject, value, UNITFIELDS.CHANNEL_OBJECT); }
		}

		[UpdateValue(UNITFIELDS.CHANNEL_OBJECT, Private = false)]
		public ulong ChannelObjectID
		{
			get { return m_channelobject == null ? 0 : m_channelobject.GUID; }
			/*set
			{
				ChannelObject = MapTile.GetObject(value);
				UpdateValue(UNITFIELDS.CHANNEL_OBJECT);
			}*/
		}

		[UpdateValue(PLAYERFIELDS.BYTES_4, BytesIndex = 1, Private = true)]
		public byte ComboPoints
		{
			get { return m_cpoints; }
			set { Assign(ref m_cpoints, value >= 5 ? (byte) 5 : value, PLAYERFIELDS.BYTES_4); }
		}

		[UpdateValue(PLAYERFIELDS.BYTES_4, BytesIndex = 2, Private = true)]
		public byte ActionBars
		{
			get { return m_character.ActionBars; }
			set
			{
				m_character.ActionBars = value;
				UpdateValue(PLAYERFIELDS.BYTES_4);
			}
		}

		[UpdateValue(PLAYERFIELDS.BYTES_1, BytesIndex = 0)]
		public byte Skin
		{
			get { return m_character.Skin; }
		}

		[UpdateValue(PLAYERFIELDS.BYTES_1, BytesIndex = 1)]
		public byte Face
		{
			get { return m_character.Face; }
		}

		[UpdateValue(PLAYERFIELDS.BYTES_1, BytesIndex = 2)]
		public byte HairStyle
		{
			get { return m_character.HairStyle; }
		}

		[UpdateValue(PLAYERFIELDS.BYTES_1, BytesIndex = 3)]
		public byte HairColor
		{
			get { return m_character.HairColor; }
		}

		//[UpdateValue(PLAYERFIELDS.BYTES_2, BytesIndex=0)]
		//public byte APlayerFlags
		//{
		//    get { return m_aplayerFlags; }
		//    set
		//    {
		//        UpdateValue(PLAYERFIELDS.BYTES_2);
		//        m_aplayerFlags = value;
		//    }
		//}

		[UpdateValue(PLAYERFIELDS.FLAGS, Private = false)]
		public uint PlayerFlags
		{
			get { return GM ? m_playerFlags | 0x8 : m_playerFlags; }
			set
			{
				m_playerFlags = value;
				UpdateValue(PLAYERFIELDS.FLAGS);
			}
		}

		[UpdateValue(PLAYERFIELDS.BYTES_2, BytesIndex = 0)]
		public byte FacialHairStyle
		{
			get { return m_character.FacialHairStyle; }
		}

		[UpdateValue(PLAYERFIELDS.BYTES_2, BytesIndex = 2)]
		public byte NumBankSlots
		{
			get { return m_character.BankSlots; }
			set
			{
				m_character.BankSlots = value;
				UpdateValue(PLAYERFIELDS.BYTES_2);
			}
		}

		[UpdateValue(PLAYERFIELDS.BYTES_2, BytesIndex = 3)]
		public RESTEDSTATE RestedState
		{
			get { return m_character.RestedPoints > 0 ? RESTEDSTATE.WELLRESTED : RESTEDSTATE.NORMAL; }
		}

		public int RestedPoints
		{
			get { return m_character.RestedPoints; }
			set
			{
				m_character.RestedPoints = value;
				UpdateValue(PLAYERFIELDS.BYTES_2);
			}
		}

		[UpdateValue(PLAYERFIELDS.BYTES_3, BytesIndex = 3)]
		public byte PVPRank
		{
			get { return m_character.PVPRank; }
			set
			{
				if (m_character.PVPRank != value)
				{
					m_character.PVPRank = value;
					UpdateValue(PLAYERFIELDS.BYTES_3);
				}
			}
		}


		[UpdateValue(PLAYERFIELDS.BYTES_3, BytesIndex = 1)]
		public byte Drunk
		{
			get { return m_drunk; }
			set { Assign(ref m_drunk, value, PLAYERFIELDS.BYTES_3); }
		}

		[UpdateValue(PLAYERFIELDS.WATCHED_FACTION_INDEX, Private = true)]
		public uint WatchedFaction
		{
			get { return m_watchedFaction; }
			set { Assign(ref m_watchedFaction, value, PLAYERFIELDS.WATCHED_FACTION_INDEX); }
		}

//		[UpdateValue(PLAYERFIELDS.COMBO_TARGET, Private = true)]
//		public ulong ComboTarget
//		{
//			get { return m_combotarget; }
//			set { Assign(ref m_combotarget, value, PLAYERFIELDS.COMBO_TARGET); }
//		}

		public Vector DeathPoint
		{
			get { return m_character.DeathPoint; }
			set { m_character.DeathPoint = value; }
		}

		public int DeathWorld
		{
			get { return m_character.DeathWorld; }
			set { m_character.DeathWorld = value; }
		}


		public MapTile DeathTile
		{
			get { return m_deathtile; }
			set { m_deathtile = value; }
		}

		public LivingObject DeathHealer
		{
			get { return m_healer; }
			set { m_healer = value; }
		}


		public ulong SelectionGUID
		{
			get { return m_selectedObject == null ? (ulong) 0 : m_selectedObject.GUID; }
		}


		public ObjectBase Selection
		{
			get { return m_selectedObject; }
			set
			{
				m_selectedObject = value;
			}
		}


		[UpdateValue(PLAYERFIELDS.TRACK_RESOURCES, Private = true)]
		public int TrackResources
		{
			get { return m_trackResources; }
			set { Assign(ref m_trackResources, value, PLAYERFIELDS.TRACK_RESOURCES); }
		}


		[UpdateValue(PLAYERFIELDS.TRACK_CREATURES, Private = true)]
		public int TrackCreatures
		{
			get { return m_trackCreatures; }
			set { Assign(ref m_trackCreatures, value, PLAYERFIELDS.TRACK_CREATURES); }
		}

		[UpdateValue(PLAYERFIELDS.AMMO_ID, Private = true)]
		public int AmmoID
		{
			get { return (m_ammo == null) ? 0 : (int) m_ammo.Template.ObjectId; }
		}

		public ItemObject Ammo
		{
			get { return m_ammo; }
			set
			{
				if (m_ammo != value)
				{
					m_ammo = value;
					m_character.Ammo = m_ammo != null ? m_ammo.Template.ObjectId : 0;
					UpdateValue(PLAYERFIELDS.AMMO_ID);
				}
			}
		}

		[UpdateValue]
		public PlayerInventory Inventory
		{
			get { return m_inventory; }
		}

		[UpdateValue]
		public PlayerSkills Skills
		{
			get { return m_skills; }
		}

		public PlayerSpells Spells
		{
			get { return m_spells; }
		}

		[UpdateValue]
		public PlayerZones Zones
		{
			get { return m_zones; }
		}

		[UpdateValue]
		public PlayerVItems VItems
		{
			get { return m_vItems; }
		}

		[UpdateValue]
		public PlayerQuests Quests
		{
			get { return m_quests; }
		}

		public PlayerReputations Reputations
		{
			get { return m_reputations; }
		}

		#endregion

		#region Modifiers

		#region Stat Modifiers

		[UpdateValue(UNITFIELDS.POSSTAT0, Private = true)]
		public int StrengthModPos
		{
			get { return m_strmodpos; }
			set { Assign(ref m_strmodpos, value, UNITFIELDS.POSSTAT0); }
		}

		[UpdateValue(UNITFIELDS.NEGSTAT0, Private = true)]
		public int StrengthModNeg
		{
			get { return m_strmodneg; }
			set { Assign(ref m_strmodneg, value, UNITFIELDS.NEGSTAT0); }
		}

		[UpdateValue(UNITFIELDS.POSSTAT1, Private = true)]
		public int AgilityModPos
		{
			get { return m_agmodpos; }
			set { Assign(ref m_agmodpos, value, UNITFIELDS.POSSTAT1); }
		}

		[UpdateValue(UNITFIELDS.NEGSTAT1, Private = true)]
		public int AgilityModNeg
		{
			get { return m_agmodneg; }
			set { Assign(ref m_agmodneg, value, UNITFIELDS.NEGSTAT1); }
		}

		[UpdateValue(UNITFIELDS.POSSTAT2, Private = true)]
		public int StaminaModPos
		{
			get { return m_stmodpos; }
			set { Assign(ref m_stmodpos, value, UNITFIELDS.POSSTAT2); }
		}

		[UpdateValue(UNITFIELDS.NEGSTAT2, Private = true)]
		public int StaminaModNeg
		{
			get { return m_stmodneg; }
			set
			{
				m_stmodneg = value;
				UpdateValue(UNITFIELDS.NEGSTAT2);
			}
		}

		[UpdateValue(UNITFIELDS.POSSTAT3, Private = true)]
		public int IntellectModPos
		{
			get { return m_intmodpos; }
			set { Assign(ref m_intmodpos, value, UNITFIELDS.POSSTAT3); }
		}

		[UpdateValue(UNITFIELDS.NEGSTAT3, Private = true)]
		public int IntellectModNeg
		{
			get { return m_intmodneg; }
			set { Assign(ref m_intmodneg, value, UNITFIELDS.NEGSTAT3); }
		}

		[UpdateValue(UNITFIELDS.POSSTAT4, Private = true)]
		public int SpiritModPos
		{
			get { return m_spmodpos; }
			set { Assign(ref m_spmodpos, value, UNITFIELDS.POSSTAT4); }
		}

		[UpdateValue(UNITFIELDS.NEGSTAT4, Private = true)]
		public int SpiritModNeg
		{
			get { return m_spmodneg; }
			set { Assign(ref m_spmodneg, value, UNITFIELDS.NEGSTAT4); }
		}

		#endregion

		#region Resist Modifiers

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE0, Private = true)]
		public int ResistPhysicalModPos
		{
			get { return m_resphysmodpos; }
			set { Assign(ref m_resphysmodpos, value, UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE0); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE0, Private = true)]
		public int ResistPhysicalModNeg
		{
			get { return m_resphysmodneg; }
			set { Assign(ref m_resphysmodneg, value, UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE0); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE1, Private = true)]
		public int ResistHolyModPos
		{
			get { return m_resholymodpos; }
			set { Assign(ref m_resholymodpos, value, UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE1); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE1, Private = true)]
		public int ResistHolyModNeg
		{
			get { return m_resholymodneg; }
			set { Assign(ref m_resholymodneg, value, UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE1); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE2, Private = true)]
		public int ResistFireModPos
		{
			get { return m_resfiremodpos; }
			set { Assign(ref m_resfiremodpos, value, UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE2); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE2, Private = true)]
		public int ResistFireModNeg
		{
			get { return m_resfiremodneg; }
			set { Assign(ref m_resfiremodneg, value, UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE2); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE3, Private = true)]
		public int ResistNatureModPos
		{
			get { return m_resnaturemodpos; }
			set { Assign(ref m_resnaturemodpos, value, UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE3); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE3, Private = true)]
		public int ResistNatureModNeg
		{
			get { return m_resnaturemodneg; }
			set { Assign(ref m_resnaturemodneg, value, UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE3); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE4, Private = true)]
		public int ResistFrostModPos
		{
			get { return m_resfrostmodpos; }
			set { Assign(ref m_resfrostmodpos, value, UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE4); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE4, Private = true)]
		public int ResistFrostModNeg
		{
			get { return m_resfrostmodneg; }
			set { Assign(ref m_resfrostmodneg, value, UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE4); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE5, Private = true)]
		public int ResistShadowModPos
		{
			get { return m_resshadowmodpos; }
			set { Assign(ref m_resshadowmodpos, value, UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE5); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE5, Private = true)]
		public int ResistShadowModNeg
		{
			get { return m_resshadowmodneg; }
			set { Assign(ref m_resshadowmodneg, value, UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE5); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE6, Private = true)]
		public int ResistArcaneModPos
		{
			get { return m_resarcanemodpos; }
			set { Assign(ref m_resarcanemodpos, value, UNITFIELDS.RESISTANCEBUFFMODSPOSITIVE6); }
		}

		[UpdateValue(UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE6, Private = true)]
		public int ResistArcaneModNeg
		{
			get { return m_resarcanemodneg; }
			set { Assign(ref m_resarcanemodneg, value, UNITFIELDS.RESISTANCEBUFFMODSNEGATIVE6); }
		}

		#endregion

		#region Damage Modifiers

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPOSITIVE0, Private = true)]
		public int DamagePhysicalModPos
		{
			get { return m_damphysmodpos; }
			set { Assign(ref m_damphysmodpos, value, PLAYERFIELDS.DAMAGEMODSPOSITIVE0); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSNEGATIVE0, Private = true)]
		public int DamagePhysicalModNeg
		{
			get { return m_damphysmodneg; }
			set { Assign(ref m_damphysmodneg, value, PLAYERFIELDS.DAMAGEMODSNEGATIVE0); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPOSITIVE1, Private = true)]
		public int DamageHolyModPos
		{
			get { return m_damholymodpos; }
			set { Assign(ref m_damholymodpos, value, PLAYERFIELDS.DAMAGEMODSPOSITIVE1); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSNEGATIVE1, Private = true)]
		public int DamageHolyModNeg
		{
			get { return m_damholymodneg; }
			set { Assign(ref m_damholymodneg, value, PLAYERFIELDS.DAMAGEMODSNEGATIVE1); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPOSITIVE2, Private = true)]
		public int DamageFireModPos
		{
			get { return m_damfiremodpos; }
			set { Assign(ref m_damfiremodpos, value, PLAYERFIELDS.DAMAGEMODSPOSITIVE2); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSNEGATIVE2, Private = true)]
		public int DamageFireModNeg
		{
			get { return m_damfiremodneg; }
			set { Assign(ref m_damfiremodneg, value, PLAYERFIELDS.DAMAGEMODSNEGATIVE2); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPOSITIVE3, Private = true)]
		public int DamageNatureModPos
		{
			get { return m_damnaturemodpos; }
			set { Assign(ref m_damnaturemodpos, value, PLAYERFIELDS.DAMAGEMODSPOSITIVE3); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSNEGATIVE3, Private = true)]
		public int DamageNatureModNeg
		{
			get { return m_damnaturemodneg; }
			set { Assign(ref m_damnaturemodneg, value, PLAYERFIELDS.DAMAGEMODSNEGATIVE3); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPOSITIVE4, Private = true)]
		public int DamageFrostModPos
		{
			get { return m_damfrostmodpos; }
			set { Assign(ref m_damfrostmodpos, value, PLAYERFIELDS.DAMAGEMODSPOSITIVE4); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSNEGATIVE4, Private = true)]
		public int DamageFrostModNeg
		{
			get { return m_damfrostmodneg; }
			set { Assign(ref m_damfrostmodneg, value, PLAYERFIELDS.DAMAGEMODSNEGATIVE4); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPOSITIVE5, Private = true)]
		public int DamageShadowModPos
		{
			get { return m_damshadowmodpos; }
			set { Assign(ref m_damshadowmodpos, value, PLAYERFIELDS.DAMAGEMODSPOSITIVE5); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSNEGATIVE5, Private = true)]
		public int DamageShadowModNeg
		{
			get { return m_damshadowmodneg; }
			set { Assign(ref m_damshadowmodneg, value, PLAYERFIELDS.DAMAGEMODSNEGATIVE5); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPOSITIVE6, Private = true)]
		public int DamageArcaneModPos
		{
			get { return m_damarcanemodpos; }
			set { Assign(ref m_damarcanemodpos, value, PLAYERFIELDS.DAMAGEMODSPOSITIVE6); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSNEGATIVE6, Private = true)]
		public int DamageArcaneModNeg
		{
			get { return m_damarcanemodneg; }
			set { Assign(ref m_damarcanemodneg, value, PLAYERFIELDS.DAMAGEMODSNEGATIVE6); }
		}

		#endregion

		#region Mod Damage Chance

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPCT0, Private = true)]
		public float DamagePhysicalPercent
		{
			get { return m_damphyspct; }
			set { Assign(ref m_damphyspct, value, PLAYERFIELDS.DAMAGEMODSPCT0); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPCT1, Private = true)]
		public float DamageHolyPercent
		{
			get { return m_damholypct; }
			set { Assign(ref m_damholypct, value, PLAYERFIELDS.DAMAGEMODSPCT1); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPCT2, Private = true)]
		public float DamageFirePercent
		{
			get { return m_damfirepct; }
			set { Assign(ref m_damfirepct, value, PLAYERFIELDS.DAMAGEMODSPCT2); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPCT3, Private = true)]
		public float DamageNaturePercent
		{
			get { return m_damnaturepct; }
			set { Assign(ref m_damnaturepct, value, PLAYERFIELDS.DAMAGEMODSPCT3); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPCT4, Private = true)]
		public float DamageFrostPercent
		{
			get { return m_damfrostpct; }
			set { Assign(ref m_damfrostpct, value, PLAYERFIELDS.DAMAGEMODSPCT4); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPCT5, Private = true)]
		public float DamageShadowPercent
		{
			get { return m_damshadowpct; }
			set { Assign(ref m_damshadowpct, value, PLAYERFIELDS.DAMAGEMODSPCT5); }
		}

		[UpdateValue(PLAYERFIELDS.DAMAGEMODSPCT6, Private = true)]
		public float DamageArcanePercent
		{
			get { return m_damarcanepct; }
			set { Assign(ref m_damarcanepct, value, PLAYERFIELDS.DAMAGEMODSPCT6); }
		}

		//[UpdateValueAttribute(PLAYERFIELDS.DAMAGEMODSPCT0, Private=true )]
		public float DamageRangedPercent
		{
			get { return m_damranpct; }
			set { m_damranpct = value; /*UpdateValue(PLAYERFIELDS.ran);*/ }
		}

		#endregion

		#region Attack power

		public override int AttackPower
		{
			get { return m_attackPower; }
			set { Assign(ref m_attackPower, value, UNITFIELDS.ATTACK_POWER); }
		}

		public override int RangedAttackPower
		{
			get { return m_rangedAttackPower; }
			set { Assign(ref m_rangedAttackPower, value, UNITFIELDS.RANGED_ATTACK_POWER); }
		}

		public override int AttackPowerModifier
		{
			get { return m_attackPowerModifier; }
			set { Assign(ref m_attackPowerModifier, value, UNITFIELDS.ATTACK_POWER_MOD); }
		}

		public override int RangedAttackPowerModifier
		{
			get { return m_rangedAttackPowerModifier; }
			set { Assign(ref m_rangedAttackPowerModifier, value, UNITFIELDS.RANGED_ATTACK_POWER_MOD); }
		}

		#endregion

		#region Chances

		public float MeleeHitChance
		{
			get { return m_hitChance; }
			set { m_hitChance = value; }
		}

		public float MagicHitChance
		{
			get { return m_magicHitChance; }
			set { m_magicHitChance = value; }
		}

		public float RangedHitChance
		{
			get { return m_rangedHitChance; }
			set { m_rangedHitChance = value; }
		}

		[UpdateValue(PLAYERFIELDS.CRIT_PERCENTAGE, Private = true)]
		public float MeleeCritChance
		{
			get { return m_critchance; }
			set { Assign(ref m_critchance, value, PLAYERFIELDS.CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.SPELL_CRIT_PERCENTAGE, Private = true)]
		public float MagicCritChance
		{
			get { return m_magicCritChance; }
			set { Assign(ref m_magicCritChance, value, PLAYERFIELDS.SPELL_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.FIRE_CRIT_PERCENTAGE, Private = true)]
		public float FireCritChance
		{
			get { return m_fireCritChance; }
			set { Assign(ref m_fireCritChance, value, PLAYERFIELDS.FIRE_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.FROST_CRIT_PERCENTAGE, Private = true)]
		public float FrostCritChance
		{
			get { return m_frostCritChance; }
			set { Assign(ref m_frostCritChance, value, PLAYERFIELDS.FROST_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.HOLY_CRIT_PERCENTAGE, Private = true)]
		public float HolyCritChance
		{
			get { return m_holyCritChance; }
			set { Assign(ref m_holyCritChance, value, PLAYERFIELDS.HOLY_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.ARCANE_CRIT_PERCENTAGE, Private = true)]
		public float ArcaneCritChance
		{
			get { return m_arcaneCritChance; }
			set { Assign(ref m_arcaneCritChance, value, PLAYERFIELDS.ARCANE_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.NATURE_CRIT_PERCENTAGE, Private = true)]
		public float NatureCritChance
		{
			get { return m_natureCritChance; }
			set { Assign(ref m_natureCritChance, value, PLAYERFIELDS.NATURE_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.SHADOW_CRIT_PERCENTAGE, Private = true)]
		public float ShadowCritChance
		{
			get { return m_shadowCritChance; }
			set { Assign(ref m_shadowCritChance, value, PLAYERFIELDS.SHADOW_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.RANGED_CRIT_PERCENTAGE, Private = true)]
		public float RangedCritChance
		{
			get { return m_rangedccritchance; }
			set { Assign(ref m_rangedccritchance, value, PLAYERFIELDS.RANGED_CRIT_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.BLOCK_PERCENTAGE, Private = true)]
		public float BlockChance
		{
			get { return m_blockchance; }
			set { Assign(ref m_blockchance, value, PLAYERFIELDS.BLOCK_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.DODGE_PERCENTAGE, Private = true)]
		public float DodgeChance
		{
			get { return m_dodgechance; }
			set { Assign(ref m_dodgechance, value, PLAYERFIELDS.DODGE_PERCENTAGE); }
		}

		[UpdateValue(PLAYERFIELDS.PARRY_PERCENTAGE, Private = true)]
		public float ParryChance
		{
			get { return m_parrychance; }
			set { Assign(ref m_parrychance, value, PLAYERFIELDS.PARRY_PERCENTAGE); }
		}

		/*public float DeflectChance
		{
			get { return m_deflectchance; }
			set { m_deflectchance = value; }
		}*/

		#endregion

		[UpdateValue(UNITFIELDS.MOD_CAST_SPEED, Private = true)]
		public float CastSpeed
		{
			get { return m_castSpeed; }
			set { Assign(ref m_castSpeed, value, UNITFIELDS.MOD_CAST_SPEED); }
		}

		#endregion

		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);

			Inventory.CreateInventory(array);

			VItems.CreateVItems(array);

			Skills.CreateSkills(array);

			Quests.CreateQuests(array);

			Auras.CreateAuras(array);

			Zones.CreateZones(array);

			CreateValue(PLAYERFIELDS.BYTES_1, array);
			CreateValue(PLAYERFIELDS.BYTES_2, array);
			CreateValue(PLAYERFIELDS.BYTES_3, array);
			CreateValue(PLAYERFIELDS.BYTES_4, array);
//#if BURNING_CRUSADE
			CreateValue(PLAYERFIELDS.BYTES_5, array);
			CreateValue(PLAYERFIELDS.WATCHED_FACTION_INDEX, array);
//#endif
			CreateValue(PLAYERFIELDS.COINAGE, array);
			CreateValue(PLAYERFIELDS.GUILD_ID, array);
			CreateValue(PLAYERFIELDS.GUILD_RANK, array);
			CreateValue(PLAYERFIELDS.GUILD_TIMESTAMP, array);
			CreateValue(PLAYERFIELDS.PROF_POINTS, array);
			CreateValue(PLAYERFIELDS.TALENT_POINTS, array);
			//CreateValue(PLAYERFIELDS.SELECTION, array);
			CreateValue(PLAYERFIELDS.XP, array);
			CreateValue(PLAYERFIELDS.NEXT_LEVEL_XP, array);
			CreateValue(PLAYERFIELDS.DAMAGEMODSPCT0, array);
			CreateValue(PLAYERFIELDS.HONORBALE_KILLS, array);
//#if !BURNING_CRUSADE
//			CreateValue(PLAYERFIELDS.DISHONORBALE_KILLS, array);
//			CreateValue(PLAYERFIELDS.HONOR, array);
//#endif
			CreateValue(PLAYERFIELDS.AMMO_ID, array);
			CreateValue(PLAYERFIELDS.DUEL_TEAM, array);
			CreateValue(PLAYERFIELDS.DUEL_ARBITER, array);
			CreateValue(PLAYERFIELDS.AMMO_ID, array);
			CreateValue(PLAYERFIELDS.FLAGS, array);

			CreateValue(UNITFIELDS.MOD_CAST_SPEED, array);

			CreateValue(UNITFIELDS.MAXDAMAGE, array);
			CreateValue(UNITFIELDS.MINDAMAGE, array);
			CreateValue(UNITFIELDS.MAXOFFHANDDAMAGE, array);
			CreateValue(UNITFIELDS.MINOFFHANDDAMAGE, array);
			CreateValue(UNITFIELDS.MAXRANGEDDAMAGE, array);
			CreateValue(UNITFIELDS.MINRANGEDDAMAGE, array);
			CreateValue(UNITFIELDS.STRENGTH, array);
			CreateValue(UNITFIELDS.AGILITY, array);
			CreateValue(UNITFIELDS.STAMINA, array);
			CreateValue(UNITFIELDS.INTELLECT, array);
			CreateValue(UNITFIELDS.SPIRIT, array);
			CreateValue(UNITFIELDS.RESIST_PHYSICAL, array);
			CreateValue(UNITFIELDS.RESIST_HOLY, array);
			CreateValue(UNITFIELDS.RESIST_FIRE, array);
			CreateValue(UNITFIELDS.RESIST_NATURE, array);
			CreateValue(UNITFIELDS.RESIST_FROST, array);
			CreateValue(UNITFIELDS.RESIST_SHADOW, array);
			CreateValue(UNITFIELDS.RESIST_ARCANE, array);
			CreateValue(UNITFIELDS.ATTACK_POWER, array);
			CreateValue(UNITFIELDS.RANGED_ATTACK_POWER, array);
			CreateValue(UNITFIELDS.ATTACK_POWER_MOD, array);
			CreateValue(UNITFIELDS.RANGED_ATTACK_POWER_MOD, array);
		}
	}
}