//
using System;
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.GamePackets;
using RunWoW.Objects.Inventory;
using RunWoW.Objects.Misc;
using RunWoW.ServerDatabase;
using RunWoW.Spells;

namespace RunWoW.Objects
{
	[UpdateObject(MaxFields=(int) ITEMFIELDS.MAX)]
	public class ItemObject : ObjectBase, ILootable
	{
		public DBItem m_itemData;

		private BaseInventory m_containedIn;
		private DBItemTemplate m_template;

		private PooledList<LootHolder> m_loot;
		private PooledList<PlayerReference> m_looters;
		
		#region Properties

		public PooledList<LootHolder> Loot
		{
			get { return m_loot; }
			set { m_loot = value; }
		}

		public PooledList<PlayerReference> Looters
		{
			get { return m_looters; }
			set { m_looters = value; }
		}

		public int Money
		{
			get { return 0; }
		}

		[UpdateValue]
		public DBItem DBItem
		{
			get { return m_itemData; }
		}

		public DBItemTemplate Template
		{
			get { return m_template; }
		}

		public BaseInventory ContainedIn
		{
			get { return m_containedIn; }
			set { m_containedIn = value; }
		}


		#region OBJECTFIELDS

		public override HIER_OBJECTTYPE HierType
		{
			get { return HIER_OBJECTTYPE.ITEM; }
		}

		public override uint Entry
		{
			get { return m_itemData.TemplateID; }
		}

		#endregion

		#region Object Properties

		public override OBJECTTYPE ObjectType
		{
			get { return OBJECTTYPE.ITEM; }
		}

		public override string Name
		{
			get { return m_template.Name; }
			set
			{
			}
		}

		public override int Level
		{
			get { return m_template.Itemlevel; }
			set
			{
			}
		}

		public override SpellProcessor SpellProcessor
		{
			get { return ContainedIn.Owner.SpellProcessor; }
		}

		public override FACTION Faction
		{
			get { return FACTION.NONE; }
			set
			{
			}
		}

		#endregion

		#region ITEMFIELDS

		[UpdateValue(ITEMFIELDS.OWNER)]
		public ulong Owner
		{
			get { return ContainedIn.Owner.GUID; }
		}

		[UpdateValue(ITEMFIELDS.CONTAINED)]
		public ulong Container
		{
			get { return ContainedIn.InventoryOwner.GUID; }
		}

		[UpdateValue(ITEMFIELDS.MAX_DURABILITY, Private = true)]
		public int MaxDurability
		{
			get { return m_template.MaxDurability; }
		}

		public int ItemTextID
		{
			get { return m_itemData.TextID; }
			set
			{
				UpdateValue(ITEMFIELDS.ITEM_TEXT_ID);
				m_itemData.TextID = value;
			}
		}

		private int m_forceDuration = int.MinValue;
		
		[UpdateValue(ITEMFIELDS.DURATION, Private = true)]
		public int TsDuration
		{
			get { return m_forceDuration == int.MinValue ? Utility.Timestamp(m_itemData.Expiration) : m_forceDuration; }
			set { m_forceDuration = value; }
		}

		public DateTime Duration
		{
			get { return m_itemData.Expiration; }
			set
			{
				UpdateValue(ITEMFIELDS.DURATION);
				m_itemData.Expiration = value;
			}
		}

		public DateTime Cooldown
		{
			get { return m_itemData.Cooldown; }
			set { m_itemData.Cooldown = value; }
		}

		public int StackCount
		{
			get { return m_itemData.StackCount; }
			set
			{
				UpdateValue(ITEMFIELDS.STACK_COUNT);
				m_itemData.StackCount = value;
			}
		}

		public int Durability
		{
			get { return m_itemData.Durability; }
			set
			{
				UpdateValue(ITEMFIELDS.DURABILITY);
				m_itemData.Durability = value;
			}
		}

		public bool Destroyed
		{
			get { return m_template.MaxDurability > 0 && m_itemData.Durability <= 0; }
			set
			{
				if (value) Durability = 0;
				else Durability = m_template.MaxDurability;
			}
		}

		public int Damaged
		{
			get { return m_template.MaxDurability - m_itemData.Durability; }
		}

		public int MaxStack
		{
			get { return m_template.MaxStack; }
		}

		public bool Enchanted
		{
			get { return m_itemData.LastEnchant != -1; }
		}

		public bool Soulbound
		{
			get { return m_itemData.Soulbound; }
			set { m_itemData.Soulbound = value; UpdateValue(ITEMFIELDS.FLAGS); }
		}

		public ushort StaticFlags
		{
			set { m_itemData.StaticFlags = value; UpdateValue(ITEMFIELDS.FLAGS); }
		}

		public ushort DynamicFlags
		{
			set { m_itemData.DynamicFlags = value; UpdateValue(ITEMFIELDS.FLAGS); }
		}
		
		#endregion
		
		#endregion

		public ItemObject(DBItem item, BaseInventory inventory)
		{
			m_itemData = item;
			m_template = item.Template;
			if (m_itemData.New)
				DBManager.NewDBObject(m_itemData);
			m_containedIn = inventory;
			LogConsole.WriteLine(LogLevel.ECHO, "Adding item " + m_itemData.ObjectId + " to " + Container);
			m_guid = m_itemData.ObjectId;
			m_guid += 0xA000000000000;
			m_itemData.ContainerID = (long)inventory.InventoryOwner.GUID;
		}

		protected override void InitCreateFields(BitArray array)
		{
			base.InitCreateFields(array);
			if (m_itemData.OwnerID != 0)
				CreateValue(ITEMFIELDS.OWNER, array);
			if (m_itemData.ContainerID != 0)
				CreateValue(ITEMFIELDS.CONTAINED, array);
			if (m_itemData.Creator != 0)
				CreateValue(ITEMFIELDS.CREATOR, array);
			//if (m_itemData. != 0)
			//	CreateValue(ITEMFIELDS.GIFTCREATOR, array);
			CreateValue(ITEMFIELDS.STACK_COUNT, array);
			//CreateValue(ITEMFIELDS.DURATION, array); //!!
			CreateValue(ITEMFIELDS.FLAGS, array);
			CreateValue(ITEMFIELDS.DURABILITY, array);
			CreateValue(ITEMFIELDS.MAX_DURABILITY, array);

			if (m_itemData.RandomPropertyID != 0)
			{
				CreateValue(ITEMFIELDS.PROPERTY_SEED, array);
				CreateValue(ITEMFIELDS.RANDOM_PROPERTIES_ID, array);
			}

			CreateValue(ITEMFIELDS.ITEM_TEXT_ID, array);

			for (int i = 0; i < 5; i++)
				if (m_itemData.SpellCharges[i] != 0)
					CreateValue(ITEMFIELDS.SPELL_CHARGES + i, array);
			
			for (int i = 0; i < 7; i++)
				if (m_itemData.Enchantments[i].ID != 0)
				{
					CreateValue(ITEMFIELDS.ENCHANTMENTS + i * 3, array);
					CreateValue(ITEMFIELDS.ENCHANTMENTS + i * 3 + 1, array);
					CreateValue(ITEMFIELDS.ENCHANTMENTS + i * 3 + 2, array);
				}
		}

		public override void Save()
		{
			DBManager.SaveDBObject(m_itemData);
		}

		protected override void Dispose(bool disposing)
		{
			if (!Disposed)
			{
					m_loot = null;
			}
			base.Dispose(disposing);
		}

		public bool AllowLoot(PlayerObject looter)
		{
			return true;
		}
		
		public void GenerateLoot(PlayerObject opener)
		{
			if (m_loot != null || m_itemData == null)
				return;
			
			if (m_template.Loot == null)
				Database.Instance.ResolveRelations(Template, typeof(DBItemLoot));

			m_loot = new PooledList<LootHolder>();

			if (m_template.Loot.Count == 0)
			{
				LogConsole.WriteLine(LogLevel.SYSTEM, string.Format("NO item loot for object {0}", m_template.ObjectId));
				return;
			}

			try
			{
				foreach (DBItemLoot loot in m_template.Loot)
				{
					bool chance = Utility.Chance(loot.Percentage / 100.0f + 0.0001f);
					if (!chance)
						continue;

					DBItemTemplate template = loot.Target;
					if (template == null)
					{
						Console.WriteLine("Unknown item in loot: " + loot.TargetID);
						continue;
					}

					int count = 1;

					switch (loot.Category)
					{
						case LootCategory.ITEM:
						case LootCategory.LOOT:
							count = template.MaxStack > 1 ? Utility.Random(1, 3) : 1;
							break;
						case LootCategory.QUEST:

							bool drop = false;

							if (opener != null && opener.Quests.NeedGather(loot.TargetID, ref count))
							{
								drop = true;
							}

							if (!drop && template.StartQuestID != 0)
								if (
									opener != null &&
									!opener.Quests.Has((uint) template.StartQuestID) &&
									!opener.Quests.HasOld((uint) template.StartQuestID) &&
									opener.Inventory.FindItem(loot.TargetID) == null
									)
								{
									drop = true;
								}
							
							if (!drop)
								continue;
							break;
						default:
							LogConsole.WriteLine(LogLevel.ECHO,
							                     "Wrong loot category " + loot.Category + " for MonsterBase");
							break;
					}
					DBItem item = new DBItem(template);
					item.StackCount = count;
					m_loot.Add(new LootHolder(item));
				}
			}
			catch
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error generating loot for " + Name);
			}
		}
		
		public virtual void Delete()
		{
			if (ItemTextID!=0)
			{
				DBMailMessage mailMessage = (DBMailMessage)Database.Instance.FindObjectByKey(typeof(DBMailMessage), ItemTextID);
				if (mailMessage != null)
					DBManager.EraseDBObject(mailMessage);
			}
			m_containedIn = null;
			DBManager.EraseDBObject(m_itemData);
		}

		public void OnHit(LivingObject enemy)
		{
			if (Destroyed)
				return;

			for (int j = 0; j < Template.SpellStat.Length; j++)
				if (Template.SpellStat[j].ID != 0 && Template.SpellStat[j].Trigger == 2)
				{
					float chance = 0.20f;

					if (DBItem.OwnerSlot == (int)INVSLOT.OFFHAND)
						chance = chance * 3f / 4f;

					if (!Utility.Chance(chance)) /*Spell.ProcChance/100)*/
						continue;

					if (Template.SpellStat[j].Spell == null)
						Template.SpellStat[j].Spell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), Template.SpellStat[j].ID);

					if (Template.SpellStat[j].Spell == null)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Hit cast unknown spell " + Template.SpellStat[j].ID);
						continue;
					}

					SpellCastEvent hitcast = new SingleTargetCast(this, Template.SpellStat[j].Spell, 2, enemy, true);
					hitcast.FireEvent();
				}

			if (Enchanted || DBItem.RandomPropertyID != 0)
			{
				for (int k = 0; k < Enchantments.Length; k++)
					if (Enchantments[k].ID != 0)
					{
						DBEnchantment ench = Enchantments[k].Enchantment;
						for (int h = 0; h < ench.Effect.Length; h++)
							if (ench.Effect[h] == ENCHANTEFFECT.PROC_SPELL)
							{
/*								float chance = ench.Effect[h].Param / 100f;

								if (chance == 0)
								{
									/*if (Template.WeaponSpeed != 0)
										chance = Template.WeaponSpeed / 20000f; // 3 proces per minute
									else
									{
										LogConsole.WriteLine(LogLevel.ERROR, "Enchant {0}, effect {1} proc chance 0", ench.ObjectId, h);*/
/*									chance = ContainedIn.Owner.AttackTime / 20000f;
									/*}*/
/*								}

								if (DBItem.OwnerSlot == (int)INVSLOT.OFFHAND)
									chance = chance * 3f / 4f;

								if (!Utility.Chance(chance))
									continue;

								if (ench.Effect[h].Spell == null)
									ench.Effect[h].Spell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), ench.Effect[h].SpellId);

								if (ench.Effect[h].Spell == null)
								{
									LogConsole.WriteLine(LogLevel.ERROR, "Hit cast unknown spell " + ench.Effect[h].SpellId);
									continue;
								}


								SpellCastEvent hitcast = new SingleTargetCast(this, ench.Effect[h].Spell, 2, enemy, true);
								hitcast.FireEvent();

								if (Enchantments[k].Charges != -1)
								{
									Enchantments[k].Charges--;
									if (Enchantments[k].Charges == 0)
										ClearEnchant(k);
								}
*/
							}
					}
			}
		}

		public void OnEquip(LivingObject owner)
		{
			if ((Template.BindType == 2 || Template.BindType == 1) && !Soulbound)
			{
				Soulbound = true;
				UpdateData();
			}

			if (Destroyed)
				return;
			//LogConsole.WriteLine(LogLevel.SYSTEM,"Casting equip for item " + Name);
			for (int i = 0; i < Template.SpellStat.Length; i++)
			{
				SpellStat spell = Template.SpellStat[i];
				if (spell.ID != 0 && spell.Trigger == 1 /*&& (spell.Charges == -1 || spell.Charges>0)*/)
				{
					if (spell.Spell == null)
						spell.Spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spell.ID);
					if (spell.Spell == null)
						continue;

					SpellManager.Cast(this, owner, spell.Spell);
				}
			}

			if (Enchanted || DBItem.RandomPropertyID !=0 )
			{
				CustomArrayList elist = GetEnchantList(ENCHANTEFFECT.SPELL);
				
				for (int i = 0; i < elist.Count; i++)
				{
                    ENCHANTEFFECT eff = (ENCHANTEFFECT)elist[i];
/*					if (eff.Spell == null)
						eff.Spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), eff.SpellId);
					if (eff.Spell == null)
						continue;
*/
//					SpellManager.Cast(this, owner, eff.Spell);
				}
			}
		}

		public void OnUnequip(LivingObject owner)
		{
			//LogConsole.WriteLine(LogLevel.SYSTEM,"Casting unequip for item " + Name);
			foreach (SpellStat spell in Template.SpellStat)
				if (spell.ID != 0 && spell.Trigger == 1)
					owner.Auras.Unregister(GUID, spell.ID);
			if (Enchanted || DBItem.RandomPropertyID != 0)
			{
				CustomArrayList elist = GetEnchantList(ENCHANTEFFECT.SPELL);
//                foreach (ENCHANTEFFECT eff in elist)
//					owner.Auras.Unregister(GUID, (uint)eff.SpellId);
			}
		}

		public ItemEnchantment[] Enchantments
		{
			get { return m_itemData.Enchantments; }
		}

		public void AddEnchant(DBEnchantment enchantment, TimeSpan time, int charges)
		{
			int num = m_itemData.LastEnchant + 1;
			if (num >= DBItem.MaxUserEnchants/*Enchantments.Length*/)
				return;
			SetEnchant(num, enchantment, time, charges);
		}

		public void SetEnchant(int num, DBEnchantment enchantment, TimeSpan time, int charges)
		{
			Enchantments[num].ID = (int) enchantment.ObjectId;
			Enchantments[num].Expires = time == TimeSpan.Zero ? 0 : Utility.Timestamp(CustomDateTime.Now + time);
			Enchantments[num].Charges = (sbyte) charges;
			Enchantments[num].Enchantment = enchantment;

			UpdateValue(ITEMFIELDS.ENCHANTMENTS + num*3);
			UpdateValue(ITEMFIELDS.ENCHANTMENTS + num*3 + 1);
			UpdateValue(ITEMFIELDS.ENCHANTMENTS + num*3 + 2);
		}

		public void ClearEnchant(int num)
		{
			Enchantments[num].ID = 0;
			Enchantments[num].Expires = 0;
			Enchantments[num].Charges = 0;
			Enchantments[num].Enchantment = null;

			UpdateValue(ITEMFIELDS.ENCHANTMENTS + num*3);
			UpdateValue(ITEMFIELDS.ENCHANTMENTS + num*3 + 1);
			UpdateValue(ITEMFIELDS.ENCHANTMENTS + num*3 + 2);
		}

		public void EnsureEnchant()
		{
			int now = Utility.Timestamp(CustomDateTime.Now);
			for (int k = 0; k < Enchantments.Length; k++)
				if (Enchantments[k].ID != 0)
				{
					if (Enchantments[k].Expires != 0 && now > Enchantments[k].Expires)
					{
						ClearEnchant(k);
						continue;
					}
					
					if (Enchantments[k].Enchantment == null)
						if ((Enchantments[k].Enchantment = (DBEnchantment) Database.Instance.FindObjectByKey(typeof (DBEnchantment), Enchantments[k].ID)) == null)
						{
							LogConsole.WriteLine(LogLevel.ERROR, "Bad enchatment on item " + Name);
							ClearEnchant(k);
							continue;
						}
					
				}
			UpdateData();
		}

		public int GetFlatEnchant(ENCHANTEFFECT effect)
		{
			if (!Enchanted)
				return 0;
			EnsureEnchant();
			int result = 0;

			for (int k = 0; k < Enchantments.Length; k++)
				if (Enchantments[k].ID != 0)
				{
					DBEnchantment ench = Enchantments[k].Enchantment;
                    for (int h = 0; h < ench.Effect.Length; h++)
                        if (ench.Effect[h] == effect)
                            Console.WriteLine("!!!FUCKING CODE!!! result += ench.Effect[h].Param; !!!FUCKING CODE!!!");
//							result += ench.Effect[h].Param;
				}

			/*if (DBItem.ItemRandomProperties != null)
			{
				EnsureRandomProperties();

				for (int k = 0; k < DBItem.ItemRandomProperties.Enchantments.Length; k++)
					if (DBItem.ItemRandomProperties.Enchantments[k] != null)
					{
						DBEnchantment ench = DBItem.ItemRandomProperties.Enchantments[k];

						for (int h = 0; h < ench.Effect.Length; h++)
							if (ench.Effect[h].Type == effect)
								result += ench.Effect[h].Param;
					}
			}*/

			return result;
		}

		/*private void EnsureRandomProperties()
		{
			if (DBItem.ItemRandomProperties != null)
			{
				if (DBItem.ItemRandomProperties.Enchantments == null)
				{
					DBItem.ItemRandomProperties.Enchantments = new DBEnchantment[3];
					for (int i = 0; i < DBItem.ItemRandomProperties.EnchantEffect.Length; i++)
						if (DBItem.ItemRandomProperties.EnchantEffect[i] != 0)
							DBItem.ItemRandomProperties.Enchantments[i] =
								(DBEnchantment)
								Database.Instance.FindObjectByKey(typeof (DBEnchantment), DBItem.ItemRandomProperties.EnchantEffect[i]);
				}
			}
		}*/

		public CustomArrayList GetEnchantList(ENCHANTEFFECT effect)
		{
			CustomArrayList result = new CustomArrayList();

			if (Enchanted || DBItem.RandomPropertyID != 0)
			{
				EnsureEnchant();
				for (int k = 0; k < Enchantments.Length; k++)
					if (Enchantments[k].ID != 0)
					{
						DBEnchantment ench = Enchantments[k].Enchantment;
						for (int h = 0; h < ench.Effect.Length; h++)
							if (ench.Effect[h] == effect)
								result.Add(ench.Effect[h]);
					}
			}

			/*if (DBItem.ItemRandomProperties != null)
			{
				EnsureRandomProperties();

				for (int k = 0; k < DBItem.ItemRandomProperties.Enchantments.Length; k++)
					if (DBItem.ItemRandomProperties.Enchantments[k] != null)
					{
						DBEnchantment ench = DBItem.ItemRandomProperties.Enchantments[k];
						for (int h = 0; h < ench.Effect.Length; h++)
							if (ench.Effect[h].Type == effect)
								result.Add(ench.Effect[h]);
					}
			}*/

			return result;
		}

		public static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(ItemObject));
		}

		protected override int UpdatePacketFlags(bool isPrivate)
		{
			if (Constants.BurningCrusade)
				return 0x18;
			else
				return 0x10;
		}

		public override void UpdateData()
		{
			ContainedIn.Owner.UpdateData();
		}
	}
}