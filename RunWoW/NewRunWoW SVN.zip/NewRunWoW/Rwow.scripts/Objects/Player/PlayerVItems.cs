//
using System.Collections;
using RunServer.Common;
using RunWoW.Common;

namespace RunWoW.Objects.Player
{
	public class PlayerVItem
	{
//#if BURNING_CRUSADE
		[UpdateValue(Field = 2)]
		public uint Template;

		//[UpdateValue(Field = 1)]
		public int DisplayID = 0;

		//[UpdateValue(Field = 0)]
		public long Creator;

		[UpdateValue(Field = 3, ArraySize = 7)]
		public int[] Enchantments = new int[7];

		//[UpdateValue(Field = 10, ArraySize = 3)] - gems

		[UpdateValue(Field = 15)]
		public int Properties;

/*#else
		[UpdateValue(Field = 0)]
		public long Creator;

		[UpdateValue(Field = 2)]
		public uint Template;

		[UpdateValue(Field = 3, ArraySize = 7)]
		public int[] Enchantments = new int[7];

		[UpdateValue(Field = 11)]
		public int Properties;
		
		public int DisplayID = 0;
#endif*/

		public PlayerVItem(ItemObject item)
		{
			Creator = (long)item.DBItem.Creator;
			Properties = item.DBItem.RandomPropertyID;
			Template = item.Entry;
			for (int i = 0; i < item.Enchantments.Length; i++)
				Enchantments[i] = item.Enchantments[i].ID;
		}

		public PlayerVItem()
		{
			Reset();
		}

		public bool Update(ItemObject item)
		{
			bool changed = false;
			changed |= Helper.Assign(ref Template, item.Entry);
			changed |= Helper.Assign(ref Creator, item.DBItem.Creator);
			changed |= Helper.Assign(ref DisplayID, item.Template.DisplayID);
			for (int i = 0; i < item.DBItem.Enchantments.Length; i++)
				changed |= Helper.Assign(ref Enchantments[i], item.DBItem.Enchantments[i].ID);
			return changed;
		}

		public void Reset()
		{
			Template = 0;
			Properties = 0;
			Creator = 0;
			DisplayID = 0;
			for (int i = 0; i < Enchantments.Length; i++)
				Enchantments[i] = 0;
		}
	}

	public class PlayerVItems
	{
		private const int ArrayLenth = 16;
//		if (!Constants.BurningCrusade)
//			ArrayLength = 12;
		
		private PlayerObject owner;

		[UpdateValue(PLAYERFIELDS.VISIBLE_ITEM, ArraySize = 19, NumSubFields = ArrayLenth, Private = false)]
		public PlayerVItem[] VItems = new PlayerVItem[19];

		public PlayerVItems(PlayerObject owner)
		{
			this.owner = owner;
			for (int i = 0; i <= (int)INVSLOT.EQUIPPEDLAST; i++)
			{
				VItems[i] = new PlayerVItem();
				UpdateItem(i);
			}
		}

		public void UpdateItem(int i)
		{
			ItemObject item = owner.Inventory[i];
		    
			if (item == null) // no item
				VItems[i].Reset();
			else
			{
				if (!VItems[i].Update(item)) // not changed
					return;
			}

			owner.Character.Dirty |= Helper.Assign(ref owner.Character.Outfit[i], VItems[i].DisplayID);
		    
			UpdateFields(i);
		}

		public void UpdateVItems()
		{
			for (int i = 0; i <= (int) INVSLOT.EQUIPPEDLAST; i++)
				UpdateFields(i);
		}

		private void UpdateFields(int i)
		{
			for (int ni = 0; ni < ArrayLenth - 1; ni++)
				owner.UpdateValue(PLAYERFIELDS.VISIBLE_ITEM + i * ArrayLenth + ni);
		}


		public void Update()
		{
			for (int i = 0; i <= (int) INVSLOT.EQUIPPEDLAST; i++)
				UpdateItem(i);
		}

		public void CreateVItems(BitArray array)
		{
			for (int i = 0; i <= (int)INVSLOT.EQUIPPEDLAST; i++)
				if (owner.Inventory[i] != null)
				{
					for (int ni = 0; ni < ArrayLenth - 1; ni++)
						ObjectBase.CreateValue(PLAYERFIELDS.VISIBLE_ITEM + i * ArrayLenth + ni, array);
				}
		}
	}
}