using System.Collections;
using RunServer.Common;
using RunWoW.Common;

namespace RunWoW.Objects.Player
{
	public class IntPool : GenericPool<int>
	{
		public static IntPool Instance = new IntPool();

		private IntPool()
			: base(100, 1000, 64)
		{
		}
	}

	public class PlayerZones
	{
		private PlayerObject m_owner;
		private int[] m_zones;

		[UpdateValue(PLAYERFIELDS.EXPLORED_ZONES, ArraySize = 64, Private = true)]
		public int[] Zones
		{
			get { return m_zones; }
		}

		public PlayerZones(PlayerObject owner)
		{
			m_owner = owner;
			//if (m_owner.Character.ExploredZones[0] == null)
			//{
			//    m_owner.Character.ExploredZones[0] = new byte[64 * 4];
			//    for (int i = 0; i < m_owner.Character.ExploredZones[0].Length; i++)
			//        m_owner.Character.ExploredZones[0][i] = 0xff;
			//}

			m_zones = IntPool.Instance.AquireBuffer();
			//new int[64];

			for (int i = 0; i < 64; i++)
				m_zones[i] = -1;
			//BitConverter.ToInt32(m_owner.Character.ExploredZones[0], i*4);

			UpdateZones();
		}

		public bool AddZone(int zoneFlag)
		{
			int index = zoneFlag/32;
			int value = 1 << (zoneFlag%32);

			if ((m_zones[index] & value) != value)
			{
				m_zones[index] |= value;

				m_owner.Character.ExploredZones[0][zoneFlag/128] |= (byte) (1 << (zoneFlag%128));
				m_owner.Character.Dirty = true;
				UpdateZone(index);
				return true;
			}
			return true;
		}

		public void Dispose()
		{
			m_owner = null;
			IntPool.Instance.ReleaseBuffer(Zones);
		}

		public void UpdateZones()
		{
			for (int i = 0; i < Zones.Length; i++)
				UpdateZone(i);
		}

		private void UpdateZone(int num)
		{
			m_owner.UpdateValue(PLAYERFIELDS.EXPLORED_ZONES + num);
		}

		public void CreateZones(BitArray array)
		{
			for (int i = 0; i < Zones.Length; i++)
				if (Zones[i] != 0)
					ObjectBase.CreateValue(PLAYERFIELDS.EXPLORED_ZONES + i, array);
		}
	}
}