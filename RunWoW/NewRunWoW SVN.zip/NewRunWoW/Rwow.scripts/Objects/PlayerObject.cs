//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects.Inventory;
using RunWoW.Objects.Misc;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunWoW.Spells;
using RunWoW.Vendors;
using RunWoW.World;
using RunWoW.WoWClasses;
using RunWoW.WoWRaces;

namespace RunWoW.Objects
{
	public enum WCHANGESTATE : byte
	{
		NONE = 0,
		CHANGING = 1,
		CHANGED = 2,
	} ;

	[UpdateObject(MaxFields = (int)PLAYERFIELDS.MAX)]
	public partial class PlayerObject : LivingObject
	{
		private DBCharacter m_character;
		private ACCESSLEVEL m_accessLevel;
		private ClientData m_backlink;
		private bool m_pvp = false;
		private bool m_invul = false;
		private bool m_ghost = false;
		private bool m_isdead = false;
		private bool m_autoIgnore = false;

		private bool m_inWater = false;
		private bool m_markwater = false;

		private ulong m_target = 0;
		private ObjectReference m_lastloot = null;

//		private ulong m_combotarget = 0;
		private ulong m_lastVictim = 0;
		private uint m_characterId;

		private byte m_cpoints = 0;
		private uint m_playerFlags = 0;

		private float m_scale;

		private float m_pregen;
		private float m_hregen;

		private int m_tempdisplay;

		public BaseClass bClass;
		public BaseClass bOriginalClass;
		public readonly BaseRace bRace;

		public WCHANGESTATE WorldChange;
		public Vector LastPos = null;
		public ActionButtons Actions;

		private Event m_releaseEvent = null;
		private Event m_pvpEvent = null;
		//private Event[] events;

		private DateTime m_lastAir;
		private uint m_mountSpell = 0;

		private uint m_lastSpell;
		private ulong m_lastItemCast;


		private PlayerInventory m_inventory;
		private PlayerSkills m_skills;
		private PlayerSpells m_spells;
		private PlayerZones m_zones;
		private PlayerVItems m_vItems;
		private PlayerQuests m_quests;
		private PlayerReputations m_reputations;

		private ushort m_sessionHKills = 0;
		private ushort m_sessionDHKills = 0;

		private int m_weaponSpeed = 2000;
		private int m_offhandWeaponSpeed = 2000;
		private int m_rangedWeaponSpeed = 2000;

		private ulong m_duelArbiter;
		private int m_duelTeam;
		private ulong m_isTaming;

		private DBSpell m_lastClassSpell;
		
		private int m_hiddenPower;

		private DateTime m_castStart = CustomDateTime.Now;
		
		private bool m_forceClean = false;

		private DAMAGETYPE m_damageType = DAMAGETYPE.PHYSICAL;
		private DAMAGETYPE m_rangedDamageType = DAMAGETYPE.PHYSICAL;
		private DAMAGETYPE m_offhandDamageType = DAMAGETYPE.PHYSICAL;

		private Vector m_position;
		private float m_facing;

		private bool m_breathUnderwater = false;
		private float m_feralAPBonus = 0f;
		private DBSpell m_nextHitSpell = null;
		private MapTile m_deathtile;
		private LivingObject m_healer;

		private PlayerReference m_reference;


		public new PlayerReference Reference
		{
			get
			{
				if (m_reference == null)
					m_reference = new PlayerReference(this);
				return m_reference;
			}
		}

		public uint LastSpell
		{
			get { return m_lastSpell; }
			set { m_lastSpell = value; }
		}

		public ulong LastItemCast
		{
			get { return m_lastItemCast; }
			set { m_lastItemCast = value; }
		}

		public float FeralAPBonus
		{
			get { return m_feralAPBonus; }
			set { m_feralAPBonus = value; }
		}

		public bool ForceClean
		{
			get { return m_forceClean; }
			set { m_forceClean = value; }
		}

		public DateTime CastStart
		{
			get { return m_castStart; }
			set { m_castStart = value; }
		}

		public ulong IsTaming
		{
			get { return m_isTaming; }
			set { m_isTaming = value; }
		}

		public int HiddenPower
		{
			get { return m_hiddenPower; }
			set { m_hiddenPower = value; }
		}

		public DBSpell LastClassSpell
		{
			get { return m_lastClassSpell; }
			set { m_lastClassSpell = value; }
		}

		public bool BreathUnderwater
		{
			get { return m_breathUnderwater; }
			set { m_breathUnderwater = value; }
		}

		public DBSpell NextHitSpell
		{
			get { return m_nextHitSpell; }
			set { m_nextHitSpell = value; }
		}

		public bool IsFlying
		{
			get
			{
				Taxi.RideEvent ride = CastEvent as Taxi.RideEvent;
				return ride != null && ride.TotalTime > 0;
			}
		}

		public bool IsWarriorStance
		{
			get
			{
				switch ((ShapeshiftForm)SShift)
				{
					case ShapeshiftForm.FORM_BEAR:
					case ShapeshiftForm.FORM_BATTLESTANCE:
					case ShapeshiftForm.FORM_BERSERKERSTANCE:
					case ShapeshiftForm.FORM_DEFENSIVESTANCE:
					case ShapeshiftForm.FORM_DIREBEAR:
						return true;
					default:
						return false;
				}
			}
		}
		
		public bool IsFeralForm
		{
			get
			{
				switch ((ShapeshiftForm)SShift)
				{
					case ShapeshiftForm.FORM_AQUA:
					case ShapeshiftForm.FORM_BEAR:
					case ShapeshiftForm.FORM_DIREBEAR:
					case ShapeshiftForm.FORM_CAT:
					case ShapeshiftForm.FORM_TRAVEL:
					case ShapeshiftForm.FORM_TREE:
					case ShapeshiftForm.FORM_MOONKIN:
					case ShapeshiftForm.FORM_FLIGHT:
						return true;
					default:
						return false;
				}
			}
		}

		public DateTime LastAir
		{
			get { return m_lastAir; }
			set { m_lastAir = value; }
		}

		public uint MountSpell
		{
			get { return m_mountSpell; }
			set { m_mountSpell = value; }
		}

		public override bool IsDisposed
		{
			get { return Disposed || m_character == null || m_backlink == null || m_backlink.Client == null; }
		}

		#region Damage

		public override float MaxDamage
		{
			get { return base.MaxDamage + (m_weaponSpeed * (AttackPower/* + AttackPowerModifier*/) / 14000f); }
		}

		public override float MinDamage
		{
			get { return base.MinDamage + (m_weaponSpeed * (AttackPower/* + AttackPowerModifier*/) / 14000f); }
		}

		public override float MaxOffhandDamage
		{
			get { return base.MaxOffhandDamage + (m_offhandWeaponSpeed * (AttackPower /*+ AttackPowerModifier*/) / 14000f); }
		}

		public override float MinOffhandDamage
		{
			get { return base.MinOffhandDamage + (m_offhandWeaponSpeed * (AttackPower/* + AttackPowerModifier*/) / 14000f); }
		}

		public override float MaxRangedDamage
		{
			get { return base.MaxRangedDamage + (m_rangedWeaponSpeed * (RangedAttackPower/* + RangedAttackPowerModifier*/) / 14000f); }
		}

		public override float MinRangedDamage
		{
			get { return base.MinRangedDamage + (m_rangedWeaponSpeed * (RangedAttackPower/* + RangedAttackPowerModifier*/) / 14000f); }
		}

		#endregion
		
		public PlayerObject(DBCharacter character, ClientData owner)
		{
			m_position = character.Position;
			m_speedmod = m_speedmod_base = 2.0f;
			m_backlink = owner;
			m_character = character;
			m_characterId = character.ObjectId;
			m_guid = m_characterId;
			m_combatreach = 0.5f;
			m_bounding = 0.3f;
			m_scale = m_character.Scale;
			bRace = Races.Instance[character.Race];
			bClass = bRace.GetClass(character.Class);

			m_nextLevelExp = ExperienceForLevel(character.Level);

			m_tempdisplay = m_character.DisplayID;

			WorldChange = WCHANGESTATE.CHANGING;

			AttackTime = bClass.AttackTime;
			OffHandAttackTime = bClass.AttackTime;
			Flags = 0x8;

			m_spells = new PlayerSpells(this);
			m_skills = new PlayerSkills(this);
			m_inventory = new PlayerInventory(this);
			m_zones = new PlayerZones(this);
			m_vItems = new PlayerVItems(this);
			m_quests = new PlayerQuests(this);
			m_reputations = new PlayerReputations(this);
			Zone = m_character.Zone;

			PlayerFlags = 0;

			m_mapInstanceId = (uint) (RunWoW.Misc.Faction.IsAlliance(m_character.Faction) ? 1 : 0);

#if BURNING_CRUSADE
			//m_watchedFaction = (uint)(RunWoW.Misc.Faction.IsAlliance(m_character.Faction) ? FACTION.STORMWIND : FACTION.ORGRIMMAR);
#endif
			InitAttackers();
		}

		public new void Init()
		{
			//Console.WriteLine("Registering passive spells");
			RegisterPermanentMods();
			//Console.WriteLine("Casting Equip items");
			EquipItems();
			//Console.WriteLine("Looking for ammo " + m_character.Ammo);
			LookSetAmmo(m_character.Ammo, false);
			//Console.WriteLine("Redress");
			Redress();
			//Console.WriteLine("Recalc rank");
			RecalcRank();
			//Console.WriteLine("Constructor done");
			if (Money < 0)
				Money = 0;

			if (Health == 0)
			{
				//ReleaseSpirit();
				Dead = true;
				Ghost = true;
			}
			else if (DeathWorld != -1)
			{
				m_isdead = true;
				DeathTile = MapManager.GetWorldMap((uint)DeathWorld, MapInstanceID).GetTileByLoc(DeathPoint);
				GhostForm();
			}
			/*events = new Event[] {new PlayerSaveEvent(this), new PlayerRegenEvent(this)};
            for (int i = 0; i < events.Length; i++)
                events[i].Start();*/
		}

		public void RegisterPermanentMods()
		{
			Auras.RemoveAllAuras();
			Modifiers.UnregisterAllModifiers();
			SpellProcessor.Clean();

			foreach (DBAbility ability in m_character.Abilities)
				if (ability.Spell != null && ability.Spell.Passive)
				{
					//Console.WriteLine("Casting passive spell " + ability.Spell.Name);
					SpellManager.SelfCast(this, ability.Spell);
				}
			//Console.WriteLine("Registered all passive spells");
		}

		public void ResummonPet()
		{
			if (m_character.LastPetID != 0)
			{
				DBPet dbpet = (DBPet)Database.Instance.FindObjectByKey(typeof(DBPet), m_character.LastPetID);
				if (dbpet == null)
				{
					m_character.LastPetID = 0;
					return;
				}
				Database.Instance.ResolveRelations(dbpet, true);

				if (Pet != null)
				{
					try
					{
						PetBase oldpet = Pet;
						oldpet.Die();
						oldpet.Dispose();
					}
					catch(NullReferenceException)
					{
					}
				}


				Pet = new PetBase(dbpet.Creature, 0 /*m_spell.ObjectId*/, dbpet, Position, Facing, this);

				MapTile.Map.Enter(Pet);
			}
		}

		public void CancelCast(SpellFailedReason reason)
		{
			if (!Casting)
				return;
			SpellCastEvent spellcast = CastEvent as SpellCastEvent;
			if (spellcast != null)
			{
				//if (reason != SpellFailedReason.SPELL_FAILED_MOVING && spellcast.Delay.TotalMilliseconds>0)
				spellcast.Interrupt(reason);
			}
			else
				CastEvent.Finish();
			CastEvent = null;
		}

		public void DelayCast(int time)
		{
			if (!Casting || !Attackable)
				return;
			if (time < 0)
				return;
			if (time > 10000)
			{
				CancelCast(SpellFailedReason.SPELL_FAILED_ERROR /*INTERRUPTED_COMBAT*/);
				return;
			}
			SpellCastEvent cast = CastEvent as SpellCastEvent;
			if (cast == null)
				return;
			cast.DelayCast(time);
		}

		public override void LevelUp()
		{
			if (Exp < NextLevelExp)
				return;
			if (Level >= Constants.MaximumLevel)
				return;
			
			if (m_character.Class != bClass.ClassID)
				Auras.Unregister(0, MountSpell); // to revert shapeshift and mount
			
			Level++;
			Exp -= NextLevelExp;
			NextLevelExp = ExperienceForLevel(Level);
			short StrengthGain = bClass.StrengthBonus(Level);
			short AgilityGain = bClass.AgilityBonus(Level);
			short StaminaGain = bClass.StaminaBonus(Level);
			short IntellectGain = bClass.IntellectBonus(Level);
			short SpiritGain = bClass.SpiritBonus(Level);

			m_character.Strength += StrengthGain;
			m_character.Agility += AgilityGain;
			m_character.Stamina += StaminaGain;
			m_character.Intellect += IntellectGain;
			m_character.Spirit += SpiritGain;

			Skills.UpdateLevel();

			short HealthGain = (short)(StaminaGain * 10 + bClass.HealthGain(Level));
			short PowerGain = (short)((PowerType != POWERTYPE.RAGE && PowerType != POWERTYPE.ENERGY)
										? IntellectGain * 10 + bClass.PowerGain(Level)
										: 0);

			m_character.MaxHealth += HealthGain;
			m_character.MaxPower += PowerGain;
			if (Level >= 10)
				TalentPoints++;

			ShortPacket pkg = new ShortPacket(SMSG.LEVELUP_INFO);
			pkg.Write(Level);
			pkg.Write((int)HealthGain);
			pkg.Write((int)PowerGain);
			pkg.Write((int)PowerGain);
			pkg.Write((int)PowerGain);
			pkg.Write((int)PowerGain); // other powers?


			pkg.Write(0); // ??
			pkg.Write((int)StrengthGain);
			pkg.Write((int)AgilityGain);
			pkg.Write((int)StaminaGain);
			pkg.Write((int)IntellectGain);
			pkg.Write((int)SpiritGain);

			BackLink.Client.Send(pkg);

			Redress();
			Health = MaxHealth;
			if (PowerType != POWERTYPE.RAGE && PowerType != POWERTYPE.ENERGY)
				Power = MaxPower;
			UpdateData();
			Save();
			if (Exp >= NextLevelExp)
				LevelUp();
		}

		public void EquipItems()
		{
			if (Dead)
				return;
			for (int i = 0; i <= (int)INVSLOT.EQUIPPEDLAST; i++)
			{
				ItemObject item = Inventory[i];
				if (item == null || item.Destroyed)
					continue;
				item.OnEquip(this);
			}
		}

		public void UnequipItems()
		{
			for (int i = 0; i <= (int)INVSLOT.EQUIPPEDLAST; i++)
			{
				ItemObject item = Inventory[i];
				if (item == null)
					continue;
				item.OnUnequip(this);
			}
		}

		public void RecalcRank()
		{
			PVPRank = DBUtility.RP2Rank(m_character);
		}

		public ClientData BackLink
		{
			get { return m_backlink; }
		}

		public override void Save()
		{
			if (Disposed)
				return;

			m_character.Position = m_position;
			m_character.Facing = m_facing;

			for (int i = 0; i < Inventory.NumSlots; i++)
				if (Inventory[i] != null)
					Inventory[i].Save();
			Skills.Save();
			Quests.Save();
			DBManager.SaveDBObject(m_character);
		}

		public bool AddItem(DBItemTemplate template, int count, bool sign)
		{
			DBItem item = new DBItem(template);
			item.StackCount = count;
			if (sign)
				item.Creator = CharacterID;
			return AddItem(item);
		}
		
		public bool AddItem(DBItem item)
		{
			if (!Inventory.CanAddItem(item))
			{
				Items.SendChangeFail(BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
				return false;
			}

			item.OwnerID = CharacterID;
			
			Inventory.AddItem(item, true);

			UpdateBags();
			
			//ForceUpdateData();
			
			Quests.CheckGather(item.TemplateID, item.StackCount);
			
			m_character.Items.Add(item);

			if (item.New)
				Database.Instance.AddNewObject(item);
			else
				Database.Instance.SaveObject(item);
			
			return true;
		}

		protected override void Dispose(bool disposing)
		{
			if (MapTile != null)
				MapTile.Map.Leave(this);
			
			if (!Disposed)
			{
				if (m_character == null)
				{
					try
					{
						throw new Exception(
							string.Format("PlayerObject method Dispose(bool) called more than once! Disposed: {0}, disposing {1}", Disposed,
										  disposing));
					}
					catch (Exception e)
					{
						Console.WriteLine(e);
					}
					return;
				}
				//if (Name!=null)
				//    Console.WriteLine("Called SaveAndRemove for player {0}", Name);

				if (Auras != null)
					try
					{
						Auras.SaveAndRemove();
					}
					catch (Exception e)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Error while removing auras: " + e);
					}

				if (Attackers != null)
					RemoveFromAttackers();
				if (Inventory != null)
					Inventory.Dispose();
				if (Skills != null)
					Skills.Dispose();
				if (Spells != null)
					Spells.Dispose();
				if (Quests != null)
					Quests.Dispose();
				if (Zones != null)
					Zones.Dispose();

				m_spells = null;
				m_skills = null;
				m_inventory = null;
				m_zones = null;
				m_vItems = null;
				m_quests = null;

				if (FightEvent != null)
					FightEvent.Finish();
				FightEvent = null;
				if (CastEvent != null)
					CastEvent.Finish();
				CastEvent = null;
				if (m_releaseEvent != null)
					m_releaseEvent.Finish();
				m_releaseEvent = null;
				if (m_pvpEvent != null)
					m_pvpEvent.Finish();
				m_pvpEvent = null;

				//for (int i = 0; i < events.Length; i++)
				//{
				//    events[i].Finish();
				//    events[i].Dispose();
				//}
				DBManager.SaveDBObject(m_character);
				m_character.Items.Clear();
				m_character.Items = null;
				m_character.Abilities.Clear();
				m_character.Abilities = null;
				m_character.QuestLog.Clear();
				m_character.QuestLog = null;
				m_character.Actions.Clear();
				m_character.Actions = null;
				m_character = null;
				m_backlink = null;
			}

			/*Removed = true;
			ObjectManager.Remove(this);*/

			base.Dispose(disposing);
		}

		public void Disconnect()
		{
			//if (MapTile != null)
			//    MapTile.Map.Leave(this);
			//MapTile = null;

			PlayerFlags |= 0x4;
			UpdateData();
			Save();
			//DBManager.SaveDBObject(m_character);
			m_backlink = null;
		}

		public void Reconnect(ClientData owner)
		{
			PlayerFlags = (uint)(PlayerFlags & ~0x4);
			m_backlink = owner;
			//Auras.UpdateAuras();
			Auras.UpdateDurations();
		}

		public void ContinueRide()
		{
			Taxi.RideEvent ride = CastEvent as Taxi.RideEvent;
			if (ride != null && ride.TotalTime > 0)
			{
				Console.WriteLine("Continue fly. Time left: {0}", ride.TotalTime);
				ride.Resend();
			}
		}

		public PlayerSkill[] GetCombatSkills()
		{
			PlayerSkill[] result = new PlayerSkill[2];
			int nskill = 0;

			if (IsFeralForm)
				result[nskill] = Skills[SKILL.UNARMED];
			else
			{
				if (Inventory[INVSLOT.MAINHAND] != null)
				{
					result[nskill] = Skills.SkillForItem(Inventory[INVSLOT.MAINHAND]);
					nskill++;
				}
				if (Inventory[INVSLOT.OFFHAND] != null)
				{
					result[nskill] = Skills.SkillForItem(Inventory[INVSLOT.OFFHAND]);
					nskill++;
				}
				if (nskill == 0)
				{
					result[nskill] = Skills[SKILL.UNARMED];
					//nskill++;
				}
			}
			return result;
		}

		public PlayerSkill[] GetRangedSkills()
		{
			PlayerSkill[] result = new PlayerSkill[1];
			//int nskill = 0;
			if (Inventory[INVSLOT.RANGED] != null)
			{
				result[0] = Skills.SkillForItem(Inventory[INVSLOT.RANGED]);
				//nskill++;
			}
			return result;
		}

		public override bool HasRangedAmmo()
		{
			ItemObject ranged = Inventory[INVSLOT.RANGED];
			if (ranged == null)
				return false;
			if (ranged.Template.WeaponSubClass == WEAPONSUBCLASS.WAND)
				return true;
			if (ranged.Template.WeaponSubClass == WEAPONSUBCLASS.THROWN)
				return true;
			if (Ammo == null)
				return false;
			return Ammo.StackCount > 0;
		}

		public bool ConsumeItem(ItemObject item)
		{
			return ConsumeItem(item, 1);
		}

		public bool ConsumeItem(ItemObject item, int quantity)
		{
			if (item == null)
				return false;

			if (item.StackCount < quantity && item.StackCount != 0)
				return false;

			if (item.ContainedIn == null || item.ContainedIn.Owner != this)
				return false;

			item.StackCount -= quantity;
			if (item.StackCount <= 0)
			{
				item.ContainedIn.DeleteItem(item.DBItem.OwnerSlot, true);
				return false;
			}
			else
				item.ContainedIn.UpdateItem(item.DBItem.OwnerSlot, true);
			return true;
		}

		public override void ConsumeRangedAmmo()
		{
			ItemObject ranged = Inventory[INVSLOT.RANGED];
			if (ranged == null)
				return;

			if (ranged.Template.WeaponSubClass == WEAPONSUBCLASS.THROWN)
			{
				ConsumeItem(ranged);
				return;
			}

			if (ranged.Template.WeaponSubClass == WEAPONSUBCLASS.WAND)
				return;

			if (Ammo == null)
				return;

			if (!ConsumeItem(Ammo))
			{
				LookSetAmmo(Ammo.Entry, true);
			}
		}

		public ItemObject LookItemModel(int model)
		{
			return Inventory.FindItem(model);
		}

		public void LookSetAmmo(uint model, bool redress)
		{
			ItemObject nammo = LookItemModel((int)model);

			if (nammo != null && nammo.Template != null && nammo.Template.ReqLevel > Level)
			{
				Items.SendChangeFail(BackLink.Client, nammo, null, BagResponseUpdateFields.BAG_LEVEL_MISMATCH);
				return;
			}

			if (nammo != Ammo)
			{
				Ammo = nammo;
				if (redress)
					Redress();
			}
		}

		public void LookSetAmmo(int model)
		{
			LookSetAmmo((uint)model, true);
		}

		public override void AddRangedDelay()
		{
			ItemObject ranged = Inventory[INVSLOT.RANGED];
			if (ranged == null)
				return;
			LastCast = CustomDateTime.Now + TimeSpan.FromMilliseconds(ranged.DBItem.Template.WeaponSpeed);
			//DelayCast(ranged.DBItem.Template.WeaponSpeed);
		}

		public PlayerSkill[] GetDefenceSkills()
		{
			return new PlayerSkill[] { Skills[SKILL.DEFENCE] };
		}

		public int GetCombatLevel()
		{
			int result = 0;
			foreach (PlayerSkill skill in GetCombatSkills())
				if (skill != null && skill.Level > result)
					result = skill.Value;
			return result;
		}

		public int GetRangedLevel()
		{
			int result = 0;
			foreach (PlayerSkill skill in GetRangedSkills())
				if (skill != null && skill.Level > result)
					result = skill.Value;
			return result;
		}

		public void RaiseSkill(PlayerSkill skill)
		{
			if (skill.Raise())
				Skills.UpdateSkill((SKILL) skill.SkillID);
		}

		#region Weapon checkes

		public bool IsDualWield
		{
			get
			{
				return !IsFeralForm &&
					Inventory[INVSLOT.MAINHAND] != null &&
					Inventory[INVSLOT.MAINHAND].DBItem.Template.Class == ITEMCLASS.WEAPON &&
					Inventory[INVSLOT.OFFHAND] != null &&
					Inventory[INVSLOT.OFFHAND].DBItem.Template.Class == ITEMCLASS.WEAPON &&
					Spells[SPELLSKILL.DUALWIELD] != null;
			}
		}

		public bool IsShield
		{
			get
			{
				return
					Inventory[INVSLOT.OFFHAND] != null &&
					Inventory[INVSLOT.OFFHAND].DBItem.Template.Class == ITEMCLASS.ARMOUR &&
					Inventory[INVSLOT.OFFHAND].DBItem.Template.ArmourSubClass == ARMOURSUBCLASS.SHIELD &&
					Spells[SPELLSKILL.BLOCK] != null;
			}
		}

		public bool IsTwoHanded
		{
			get
			{
				if (Inventory[INVSLOT.MAINHAND] == null)
					return false;
				switch (Inventory[INVSLOT.MAINHAND].DBItem.Template.WeaponSubClass)
				{
					case WEAPONSUBCLASS.POLEARM:
					case WEAPONSUBCLASS.STAFF:
					case WEAPONSUBCLASS.SPEAR:
					case WEAPONSUBCLASS.TWOHANDAXE:
					case WEAPONSUBCLASS.TWOHANDBLUNT:
					case WEAPONSUBCLASS.TWOHANDEXOTIC:
					case WEAPONSUBCLASS.TWOHANDSWORD:
						return true;
					default:
						return false;
				}
			}
		}

		#endregion

		public override void Redress()
		{
			if (Modifiers == null || IsDisposed)
				return;

			base.Redress();

			float old_speed = m_speedmod;
			m_speedmod = m_speedmod_base + m_speedmod_base * Modifiers.GetFloat(MODIFIER.SPEED_PCT);
			if (m_speedmod != old_speed)
			{
				Teleport.SpeedChange(this, RunningSpeed, SMSG.FORCE_RUN_SPEED_CHANGE);
				Teleport.SpeedChange(this, RunBackSpeed, SMSG.FORCE_RUN_BACK_SPEED_CHANGE);
			}

			StrengthModPos = Modifiers.GetInt(MODIFIER.STR_POS) + Modifiers.GetInt(MODIFIER.ALLSTAT_POS);
			StrengthModNeg = Modifiers.GetInt(MODIFIER.STR_NEG) + Modifiers.GetInt(MODIFIER.ALLSTAT_NEG);
			AgilityModPos = Modifiers.GetInt(MODIFIER.AGL_POS) + Modifiers.GetInt(MODIFIER.ALLSTAT_POS);
			AgilityModNeg = Modifiers.GetInt(MODIFIER.AGL_NEG) + Modifiers.GetInt(MODIFIER.ALLSTAT_NEG);
			IntellectModPos = Modifiers.GetInt(MODIFIER.INT_POS) + Modifiers.GetInt(MODIFIER.ALLSTAT_POS);
			IntellectModNeg = Modifiers.GetInt(MODIFIER.INT_NEG) + Modifiers.GetInt(MODIFIER.ALLSTAT_NEG);
			SpiritModPos = Modifiers.GetInt(MODIFIER.SPI_POS) + Modifiers.GetInt(MODIFIER.ALLSTAT_POS);
			SpiritModNeg = Modifiers.GetInt(MODIFIER.SPI_NEG) + Modifiers.GetInt(MODIFIER.ALLSTAT_NEG);
			StaminaModPos = Modifiers.GetInt(MODIFIER.STA_POS) + Modifiers.GetInt(MODIFIER.ALLSTAT_POS);
			StaminaModNeg = Modifiers.GetInt(MODIFIER.STA_NEG) + Modifiers.GetInt(MODIFIER.ALLSTAT_NEG);

			int iResist_ArcaneMod = Modifiers.GetInt(MODIFIER.ARCANE_RES) + Modifiers.GetInt(MODIFIER.ALLRESIST);
			int iResist_FireMod = Modifiers.GetInt(MODIFIER.FIRE_RES) + Modifiers.GetInt(MODIFIER.ALLRESIST);
			int iResist_FrostMod = Modifiers.GetInt(MODIFIER.FROST_RES) + Modifiers.GetInt(MODIFIER.ALLRESIST);
			int iResist_HolyMod = Modifiers.GetInt(MODIFIER.HOLY_RES) + Modifiers.GetInt(MODIFIER.ALLRESIST);
			int iResist_NatureMod = Modifiers.GetInt(MODIFIER.NATURE_RES) + Modifiers.GetInt(MODIFIER.ALLRESIST);
			int iResist_ShadowMod = Modifiers.GetInt(MODIFIER.SHADOW_RES) + Modifiers.GetInt(MODIFIER.ALLRESIST);
			int iResist_PhysicalMod = Modifiers.GetInt(MODIFIER.PHYS_RES);
			int iAttackPowerModifier = Modifiers.GetInt(MODIFIER.ATTACK_POW);
			int iRangedAttackPowerModifier = Modifiers.GetInt(MODIFIER.RANGED_POW);
			int iResist_Arcane = 0;
			int iResist_Fire = 0;
			int iResist_Frost = 0;
			int iResist_Holy = 0;
			int iResist_Nature = 0;
			int iResist_Physical = 0;
			int iResist_Shadow = 0;
			float iMinDamage = 0;
			float iMaxDamage = 0;
			float iMinOffhandDamage = 0;
			float iMaxOffhandDamage = 0;
			float iMinRangedDamage = 0;
			float iMaxRangedDamage = 0;
			int iMaxHealthMod = Modifiers.GetMixed(MODIFIER.MAX_HEALTH, MODIFIER.MAX_HEL_PCT, m_character.MaxHealth);
			int iMaxPowerMod = Modifiers.GetMixed(MODIFIER.MAX_POWER, MODIFIER.MAX_POW_PCT, m_character.MaxPower);
			float iDodgeMod = Modifiers.GetFloat(MODIFIER.DODGE_PCT);
			float iBlockMod = Modifiers.GetFloat(MODIFIER.BLOCK_PCT);
			float iParryMod = Modifiers.GetFloat(MODIFIER.PARRY_PCT);
			float iCritMod = Modifiers.GetFloat(MODIFIER.CRIT_PCT);
			float iMagicCritMod = Modifiers.GetFloat(MODIFIER.MAGIC_CRIT_PCT);

			int combatLevel = GetCombatLevel();
			int rangedLevel = GetRangedLevel();

			bool hasMainHand = Inventory[INVSLOT.MAINHAND] != null && !Inventory[INVSLOT.MAINHAND].Destroyed;
			bool hasOffHand = Inventory[INVSLOT.OFFHAND] != null && !Inventory[INVSLOT.OFFHAND].Destroyed;
			bool hasRanged = Inventory[INVSLOT.RANGED] != null && !Inventory[INVSLOT.RANGED].Destroyed;

			if (IsFeralForm)
				hasMainHand = hasOffHand = hasRanged = false;
			
			#region Attack Times

			if (hasMainHand)
				m_weaponSpeed = AttackTime = Inventory[INVSLOT.MAINHAND].DBItem.Template.WeaponSpeed;
			else
				m_weaponSpeed = AttackTime = bClass.AttackTime;

			if (hasOffHand)
				m_offhandWeaponSpeed = OffHandAttackTime = Inventory[INVSLOT.OFFHAND].DBItem.Template.WeaponSpeed;
			else
				m_offhandWeaponSpeed = OffHandAttackTime = bClass.AttackTime;

			if (hasRanged)
				m_rangedWeaponSpeed = RangedAttackTime = Inventory[INVSLOT.RANGED].DBItem.Template.WeaponSpeed;
			else
				m_rangedWeaponSpeed = RangedAttackTime = bClass.AttackTime;

			if (IsFeralForm)
			{
				switch ((ShapeshiftForm)SShift)
				{
					case ShapeshiftForm.FORM_CAT:
						m_weaponSpeed = m_offhandWeaponSpeed = AttackTime = OffHandAttackTime = 1000;
						iMinDamage = 44 * Level / 60;
						iMaxDamage = 66 * Level / 60;
						break;
					case ShapeshiftForm.FORM_BEAR:
						m_weaponSpeed = m_offhandWeaponSpeed = AttackTime = OffHandAttackTime = 2500;
						iMinDamage = 50 * Level / 60;
						iMaxDamage = 75 * Level / 60;
						break;
					case ShapeshiftForm.FORM_DIREBEAR:
					case ShapeshiftForm.FORM_MOONKIN:
						m_weaponSpeed = m_offhandWeaponSpeed = AttackTime = OffHandAttackTime = 2500;
						iMinDamage = 101 * Level / 60;
						iMaxDamage = 151 * Level / 60;
						break;
				}
			}

			float attackTimeMod = Modifiers.GetFloat(MODIFIER.MELEE_HASTE_PCT);

			if (attackTimeMod != 0f)
			{
				AttackTime = (int)(attackTimeMod * AttackTime);
				OffHandAttackTime = (int)(attackTimeMod * OffHandAttackTime);
			}

			float rangedAttackTime = Modifiers.GetFloat(MODIFIER.RANGED_ATTACK_SPEED_PCT);

			if (rangedAttackTime != 0f)
				RangedAttackTime = (int)(rangedAttackTime * RangedAttackTime);

			if (AttackTime < 900)
				AttackTime = bClass.AttackTime;
			if (OffHandAttackTime < 900)
				OffHandAttackTime = bClass.AttackTime;
			if (RangedAttackTime < 900)
				RangedAttackTime = bClass.AttackTime;

			#endregion

			if (hasRanged && (
								Inventory[INVSLOT.RANGED].Template.WeaponSubClass == WEAPONSUBCLASS.THROWN ||
								Inventory[INVSLOT.RANGED].Template.WeaponSubClass == WEAPONSUBCLASS.WAND))
				Ammo = Inventory[INVSLOT.RANGED];

			if (Ammo != Inventory[INVSLOT.RANGED] && Ammo != null)
			{
				for (int j = 0; j < 5; j++)
				{
					iMinRangedDamage += Ammo.DBItem.Template.DamageStats[j].Min;
					iMaxRangedDamage += Ammo.DBItem.Template.DamageStats[j].Max;
				}
			}

			#region Additional damage percents

			/*DamagePhysicalPercent=combatLevel>0?((float)combatLevel-1.0f)/100.0f+1.0f:0.0f;
			DamageRangedPercent=combatLevel>0?((float)rangedLevel-1.0f)/100.0f+1.0f:0.0f;
			DamageHolyPercent=DamagePhysicalPercent;
			DamageFirePercent=DamagePhysicalPercent;
			DamageFrostPercent=DamagePhysicalPercent;
			DamageShadowPercent=DamagePhysicalPercent;
			DamageArcanePercent=DamagePhysicalPercent;*/

			#endregion

			#region Item bonuses

			#region Euipped items

			for (int i = 0; i <= (int)INVSLOT.EQUIPPEDLAST; i++)
			{
				ItemObject item = Inventory[i];
				if (item == null || item.Destroyed)
					continue;

				iResist_Fire += item.DBItem.Template.Resists.Fire;
				iResist_Holy += item.DBItem.Template.Resists.Holy;
				iResist_Arcane += item.DBItem.Template.Resists.Arcane;
				iResist_Nature += item.DBItem.Template.Resists.Nature;
				iResist_Physical += item.DBItem.Template.Resists.Physical;
				iResist_Shadow += item.DBItem.Template.Resists.Shadow;
				iResist_Frost += item.DBItem.Template.Resists.Frost;

				iMaxHealthMod += item.DBItem.Template.getItemBonusByStat(0);
				iMaxPowerMod += item.DBItem.Template.getItemBonusByStat(1);

				int iStrengthMod = item.DBItem.Template.getItemBonusByStat(4);
				if (iStrengthMod > 0)
					StrengthModPos += iStrengthMod;
				else if (iStrengthMod < 0)
					StrengthModNeg += iStrengthMod;

				int iAgilityMod = item.DBItem.Template.getItemBonusByStat(3);
				if (iAgilityMod > 0)
					AgilityModPos += iAgilityMod;
				else if (iAgilityMod < 0)
					AgilityModNeg += iAgilityMod;

				int iIntellectMod = item.DBItem.Template.getItemBonusByStat(5);
				if (iIntellectMod > 0)
					IntellectModPos += iIntellectMod;
				else if (iIntellectMod < 0)
					IntellectModNeg += iIntellectMod;

				int iSpiritMod = item.DBItem.Template.getItemBonusByStat(6);
				if (iSpiritMod > 0)
					SpiritModPos += iSpiritMod;
				else if (iSpiritMod < 0)
					SpiritModNeg += iSpiritMod;

				int iStaminaMod = item.DBItem.Template.getItemBonusByStat(7);
				if (iStaminaMod > 0)
					StaminaModPos += iStaminaMod;
				else if (iStaminaMod < 0)
					StaminaModNeg += iStaminaMod;

				iResist_Physical += item.GetFlatEnchant(ENCHANTEFFECT.ARMOR);
			}

			#endregion

			#region Main Hand

			if (hasMainHand)
			{
				ItemObject item = Inventory[INVSLOT.MAINHAND];
				for (int j = 0; j < 5; j++)
				{
					DamageStat stat = item.Template.DamageStats[j];
					
					if (stat.Max > iMaxDamage)
						m_damageType = (DAMAGETYPE)stat.Type;
					
					iMinDamage += stat.Min;
					iMaxDamage += stat.Max;
				} // TODO: add different damage types
				int ench = item.GetFlatEnchant(ENCHANTEFFECT.DAMAGE);
				iMinDamage += ench;
				iMaxDamage += ench;
			}

			#endregion

			#region Offhand

			if (hasOffHand)
			{
				ItemObject item = Inventory[INVSLOT.OFFHAND];
				for (int j = 0; j < 5; j++)
				{
					DamageStat stat = item.Template.DamageStats[j];
					
					if (stat.Max > iMaxOffhandDamage)
						m_offhandDamageType = (DAMAGETYPE)stat.Type;
					
					iMinOffhandDamage += stat.Min;
					iMaxOffhandDamage += stat.Max;
				} // TODO: add different damage types
				int ench = item.GetFlatEnchant(ENCHANTEFFECT.DAMAGE);
				iMinOffhandDamage += ench;
				iMaxOffhandDamage += ench;
			}

			#endregion

			#region Ranged

			if (hasRanged)
			{
				ItemObject item = Inventory[INVSLOT.RANGED];
				for (int j = 0; j < 5; j++)
				{
					DamageStat stat = item.Template.DamageStats[j];

					if (stat.Max > iMaxRangedDamage)
						m_rangedDamageType = (DAMAGETYPE)stat.Type;
					
					iMinRangedDamage += stat.Min;
					iMaxRangedDamage += stat.Max;

				} // TODO: add different damage types
				int ench = item.GetFlatEnchant(ENCHANTEFFECT.DAMAGE);
				iMinRangedDamage += ench;
				iMaxRangedDamage += ench;
			}

			#endregion

			#endregion

			#region Final Calculation

			StrengthModPos += Modifiers.GetPct(MODIFIER.STR_POS_PCT, m_character.Strength);
			StrengthModNeg += Modifiers.GetPct(MODIFIER.STR_NEG_PCT, m_character.Strength);
			AgilityModPos += Modifiers.GetPct(MODIFIER.AGL_POS_PCT, m_character.Agility);
			AgilityModNeg += Modifiers.GetPct(MODIFIER.AGL_NEG_PCT, m_character.Agility);
			IntellectModPos += Modifiers.GetPct(MODIFIER.INT_POS_PCT, m_character.Intellect);
			IntellectModNeg += Modifiers.GetPct(MODIFIER.INT_NEG_PCT, m_character.Intellect);
			StaminaModPos += Modifiers.GetPct(MODIFIER.STA_POS_PCT, m_character.Stamina);
			StaminaModNeg += Modifiers.GetPct(MODIFIER.STA_NEG_PCT, m_character.Stamina);
			SpiritModPos += Modifiers.GetPct(MODIFIER.SPI_POS_PCT, m_character.Spirit);
			SpiritModNeg += Modifiers.GetPct(MODIFIER.SPI_NEG_PCT, m_character.Spirit);

			StrengthModPos += Modifiers.GetPct(MODIFIER.ALLSTAT_POS_PCT, m_character.Strength);
			StrengthModNeg += Modifiers.GetPct(MODIFIER.ALLSTAT_NEG_PCT, m_character.Strength);
			AgilityModPos += Modifiers.GetPct(MODIFIER.ALLSTAT_POS_PCT, m_character.Agility);
			AgilityModNeg += Modifiers.GetPct(MODIFIER.ALLSTAT_NEG_PCT, m_character.Agility);
			IntellectModPos += Modifiers.GetPct(MODIFIER.ALLSTAT_POS_PCT, m_character.Intellect);
			IntellectModNeg += Modifiers.GetPct(MODIFIER.ALLSTAT_NEG_PCT, m_character.Intellect);
			StaminaModPos += Modifiers.GetPct(MODIFIER.ALLSTAT_POS_PCT, m_character.Stamina);
			StaminaModNeg += Modifiers.GetPct(MODIFIER.ALLSTAT_NEG_PCT, m_character.Stamina);
			SpiritModPos += Modifiers.GetPct(MODIFIER.ALLSTAT_POS_PCT, m_character.Spirit);
			SpiritModNeg += Modifiers.GetPct(MODIFIER.ALLSTAT_NEG_PCT, m_character.Spirit);

			MaxHealth = m_character.MaxHealth + iMaxHealthMod + (StaminaModPos + StaminaModNeg) * 10;
			if (Health > MaxHealth)
				Health = MaxHealth;
			MaxPower = bClass.MaxPower((short)(m_character.MaxPower + iMaxPowerMod + (IntellectModPos + IntellectModNeg) * 15));
			if (Power > MaxPower)
				Power = MaxPower;

			Strength = m_character.Strength + StrengthModPos + StrengthModNeg;
			Agility = m_character.Agility + AgilityModPos + AgilityModNeg;
			Spirit = m_character.Spirit + SpiritModPos + SpiritModNeg;
			Intellect = m_character.Intellect + IntellectModPos + IntellectModNeg;
			Stamina = m_character.Stamina + StaminaModPos + StaminaModNeg;

			Resist_Fire = iResist_Fire + iResist_FireMod;
			Resist_Fire += Modifiers.GetPct(MODIFIER.FIRE_RES_PCT, Resist_Fire);

			Resist_Arcane = iResist_Arcane + iResist_ArcaneMod;
			Resist_Arcane += Modifiers.GetPct(MODIFIER.ARCANE_RES_PCT, Resist_Arcane);

			Resist_Frost = iResist_Frost + iResist_FrostMod;
			Resist_Frost += Modifiers.GetPct(MODIFIER.FROST_RES_PCT, Resist_Frost);

			Resist_Holy = iResist_Holy + iResist_HolyMod;
			Resist_Holy += Modifiers.GetPct(MODIFIER.HOLY_RES_PCT, Resist_Holy);

			Resist_Nature = iResist_Nature + iResist_NatureMod;
			Resist_Nature += Modifiers.GetPct(MODIFIER.NATURE_RES_PCT, Resist_Nature);

			Resist_Shadow = iResist_Shadow + iResist_ShadowMod;
			Resist_Shadow += Modifiers.GetPct(MODIFIER.SHADOW_RES_PCT, Resist_Shadow);

			Resist_Physical = iResist_Physical + Agility * 2 + iResist_PhysicalMod;
			Resist_Physical += Modifiers.GetPct(MODIFIER.PHYS_RES_PCT, Resist_Physical);

			ResistFireModPos = iResist_FireMod;
			ResistArcaneModPos = iResist_ArcaneMod;
			ResistFrostModPos = iResist_FrostMod;
			ResistHolyModPos = iResist_HolyMod;
			ResistNatureModPos = iResist_NatureMod;
			ResistShadowModPos = iResist_ShadowMod;
			ResistPhysicalModPos = iResist_PhysicalMod;

			m_hregen = bClass.CalculateHRegen(Level, Spirit);
			m_hregen += Modifiers.GetPct(MODIFIER.HEALTH_REGEN, m_hregen);
			m_pregen = bClass.CalculatePRegen(Level, Spirit);
			m_pregen += Modifiers.GetPct(MODIFIER.POWER_REGEN, m_pregen);

			AttackPower = bClass.CalculateAP(Level, Strength, Agility) + iAttackPowerModifier;
			RangedAttackPower = bClass.CalculateRangedAP(Level, Strength, Agility) + iRangedAttackPowerModifier;

			if (IsFeralForm)
				AttackPower += (int)(FeralAPBonus*Level);

			AttackPowerModifier = iAttackPowerModifier;
			RangedAttackPowerModifier = iRangedAttackPowerModifier;

			Utility.NormalizePair(ref iMinDamage, ref iMaxDamage);
			MinDamage = iMinDamage;
			MaxDamage = iMaxDamage;

			if (hasOffHand)
			{
				Utility.NormalizePair(ref iMinOffhandDamage, ref iMaxOffhandDamage);
				MinOffhandDamage = Modifiers.GetPct(MODIFIER.OFFHAND_DAMAGE_PCT, (iMinOffhandDamage * 0.5f));
				MaxOffhandDamage = Modifiers.GetPct(MODIFIER.OFFHAND_DAMAGE_PCT, (iMaxOffhandDamage * 0.5f));
			}
			else
			{
				MinOffhandDamage = 0;
				MaxOffhandDamage = 0;
			}

			if (hasRanged)
			{
				Utility.NormalizePair(ref iMinRangedDamage, ref iMaxRangedDamage);
				MinRangedDamage = iMinRangedDamage;
				MaxRangedDamage = iMaxRangedDamage;
			}
			else
			{
				MinRangedDamage = 0;
				MaxRangedDamage = 0;
			}

			DamagePhysicalPercent = 1f + Modifiers.GetFloat(MODIFIER.DAMAGE_PCT);
			DamageRangedPercent = 1f + Modifiers.GetFloat(MODIFIER.RDAMAGE_PCT);

			MeleeHitChance = IsDualWield ? 76.0f : 95.0f;
			MeleeCritChance = bClass.CalculateMeleeCrit(Level, m_character.Agility, AgilityModPos + AgilityModNeg) + combatLevel * 0.04f + iCritMod;
			RangedHitChance = 95.0f;
			RangedCritChance = bClass.CalculateMeleeCrit(Level, m_character.Agility, AgilityModPos + AgilityModNeg) + rangedLevel * 0.04f;
			BlockChance = 5.0f - 0.2f * Level + Defence * 0.04f + iBlockMod;
			if (BlockChance < 0)
				BlockChance = 0;
			DodgeChance = bClass.CalculateDodge(Level, Agility) + iDodgeMod + Defence * 0.04f;
			if (DodgeChance < 0)
				DodgeChance = 0;
			ParryChance = Spells[SPELLSKILL.PARRY] != null ? (5.0f - 0.2f * Level + Defence * 0.04f + iParryMod) : 0.0f;
			if (ParryChance < 0)
				ParryChance = 0;
			//DeflectChance = defencelevel / 6.0f;

			MagicHitChance = 95.0f;

			MagicCritChance = bClass.CalculateMagicCrit(Level, m_character.Intellect, IntellectModPos + IntellectModNeg) + iMagicCritMod;


			FireCritChance = MagicCritChance + SpellProcessor.AdditionalCritChance(DAMAGETYPE.FIRE) * 100f;
			FrostCritChance = MagicCritChance + SpellProcessor.AdditionalCritChance(DAMAGETYPE.FROST) * 100f;
			HolyCritChance = MagicCritChance + SpellProcessor.AdditionalCritChance(DAMAGETYPE.HOLY) * 100f;
			ArcaneCritChance = MagicCritChance + SpellProcessor.AdditionalCritChance(DAMAGETYPE.ARCANE) * 100f;
			NatureCritChance = MagicCritChance + SpellProcessor.AdditionalCritChance(DAMAGETYPE.NATURE) * 100f;
			ShadowCritChance = MagicCritChance + SpellProcessor.AdditionalCritChance(DAMAGETYPE.SHADOW) * 100f;

			#endregion

			VItems.Update();
		}

		public override int Defence
		{
			get { return Skills.SkillLevel(SKILL.DEFENCE); }
		}


		#region PlayerProperties

		#region Trade Helper

		private TradeHelper m_thelper = null;

		public TradeHelper TradeHelper
		{
			get { return m_thelper; }
			set { m_thelper = value; }
		}

		#endregion

		#region Group Helpers

		public PlayerReference GroupInvite = null;
		private Group m_group = null;

		private uint m_mapInstanceId = 0;

		public uint MapInstanceID
		{
			get { return m_mapInstanceId; }
			set { m_mapInstanceId = value; }
		}

		public Group Group
		{
			get { return m_group; }
			set
			{
				m_group = value;
				m_character.GroupID = m_group == null ? 0 : m_group.GroupID;
			}
		}

		public PlayerReference GuildInvite = null;

		public bool SameGroup(ObjectBase obj)
		{
			if (obj == null)
				return true;

			if (obj == this)
				return true;

			if (obj is IOwnedUnit)
				return SameGroup(((IOwnedUnit)obj).Owner);

			if (m_group != null && obj is PlayerObject)
				return m_group.Contains(obj.GUID);
					/*Character != null && ((PlayerObject)obj).Character != null &&
					Character.GroupID == ((PlayerObject)obj).Character.GroupID;*/

			return false;
		}

		#endregion

		#region Pet Helpers

		private PetBase m_pet = null;

		public PetBase Pet
		{
			get { return m_pet; }
			set
			{
				m_pet = value;
				m_summon = value != null ? value.GUID : 0;
				m_character.LastPetID = value != null ? m_pet.DBPet.ObjectId : (uint)0;

				UpdateValue(UNITFIELDS.SUMMON);
			}
		}

		private ArrayList m_totems = new ArrayList();

		public void AddTotem(TotemBase totem)
		{
			lock (m_totems)
			{
				if (m_totems.Count >= 4)
				{
					TotemBase toRemove = (TotemBase)m_totems[0];
					if (!toRemove.Disposed)
						toRemove.Die(); // it should unregister itself
					else
						m_totems.Remove(toRemove);
				}
				m_totems.Add(totem);
			}
		}

		public void RemoveTotem(TotemBase totem)
		{
			lock (m_totems)
				if (m_totems.Contains(totem))
					m_totems.Remove(totem);
		}

		#endregion

		public uint CharacterID
		{
			get { return m_characterId; }
		}

		public DBCharacter Character
		{
			get { return m_character; }
		}

		public bool Invul
		{
			get { return m_invul; }
			set { m_invul = value; }
		}

		public bool AutoIgnore
		{
			get { return m_autoIgnore; }
			set { m_autoIgnore = value; }
		}

		public Vector BindPoint
		{
			get { return m_character.BindPoint; }
			set { m_character.BindPoint = value; }
		}

		public uint WorldMapID
		{
			get { return m_character.WorldMapID; }
			set { m_character.WorldMapID = value; }
		}

		public uint Zone
		{
			get { return m_character.Zone; }
			set
			{
				m_character.Zone = value;
				if (Area == null || Area.ObjectId != value)
					Area = (DBArea)Database.Instance.FindObjectByKey(typeof(DBArea), value);
				if (Area == null)
					Area = (DBArea)Database.Instance.FindObjectByKey(typeof(DBArea), 30);
				if (Area == null)
					return;
				if (RunWoW.Misc.Faction.PVPZone(m_character.Faction, Area.Type))
					PvP = true;
				else if (RunWoW.Misc.Faction.NoPVPZone(m_character.Faction, Area.Type))
					PvP = false;
			}
		}

		private DBArea m_area = null;

		public DBArea Area
		{
			get { return m_area; }
			set { m_area = value; }
		}

		public ACCESSLEVEL AccessLvl
		{
			get { return m_accessLevel; }
			set { m_accessLevel = value; }
		}

		public bool PvP
		{
			get { return m_pvp; }
			set
			{
				//if (m_pvp == value)
				//	return;
				if (m_pvpEvent != null)
					m_pvpEvent.Finish();
				if (value)
				{
					Flags |= 0x1000;
					//Flags &= ~0x8;

					if (Area != null)
					{
						if (!RunWoW.Misc.Faction.PVPZone(m_character.Faction, Area.Type))
							m_pvpEvent = new PVPEvent(this);
					}
				}
				else
				{
					if (Area != null)
					{
						if (RunWoW.Misc.Faction.PVPZone(m_character.Faction, Area.Type))
							return;
					}
					Flags &= ~0x1000;
					//Flags |= 0x8;
				}
				m_pvp = value;
			}
		}

		public bool Ghost
		{
			get { return m_ghost; }
			set { m_ghost = value; }
		}

		public bool GM
		{
			get { return m_accessLevel >= ACCESSLEVEL.SEER; }
		}

		public bool Stealth
		{
			get { return (ShapeshiftForm)SShift == ShapeshiftForm.FORM_STEALTH; }
		}

		public int SenseInvisLevel
		{
			get { return m_accessLevel >= ACCESSLEVEL.SEER ? (int)m_accessLevel - (int)ACCESSLEVEL.SEER + 1 : 0; }
		}

		public override string Name
		{
			get { return m_character == null ? "(none)" : m_character.Name; }
			set { m_character.Name = value; }
		}

		public override bool Dead
		{
			get { return m_isdead; }
			set
			{
				if (Disposed) return;
				m_isdead = value;
				if (value)
				{
					StandState = UNITSTANDSTATE.DEAD;
					RunPose = 1;
					Health = 0;
					Power = 0;
					Drunk = 0;
					Flags = 0x8;
					Zone = m_character.Zone;
					UnequipItems();
					m_releaseEvent = new ReleaseSpiritEvent(this);
					m_releaseEvent.Start();
					m_stunned = 0;
					m_rooted = 0;
					m_noControl = 0;
					m_pacified = 0;
					m_silenced = 0;
					InvisLevel = 0;
					//Attackers.Clean();
				}
				else
				{
					RunPose = 0;
					Ghost = false;
					if (Race == RACE.NIGHTELF)
						Auras.CancelAuraForce(OtherBase.GhostWispSpell.SpellID);
					Auras.CancelAuraForce(OtherBase.GhostSpell.SpellID);
					if (MapTile != null)
						MapTile.Map.Reenter(this);
					StandState = UNITSTANDSTATE.STANDING;

					PlayerFlags = 0;

					//PvP = false;
					Flags = 0x8;
					DeathWorld = -1;

					Zone = m_character.Zone;

					ClearKillers();

					RegisterPermanentMods();
					EquipItems();
					Redress();
				}
				UpdateData();
			}
		}

		public override bool Attackable
		{
			get
			{
				if (Dead || Invul)
					return false;

				if ((Flags & 0x10000) == 0x10000)
					return false;

				if (CastEvent is Taxi.RideEvent)
					return false;

				return true;
			}
		}

		#endregion

		#region Object Properties

		public override bool InWater
		{
			get { return m_inWater; }
			set { m_inWater = value; }
		}

		public bool MarkWater
		{
			get { return m_markwater; }
			set { m_markwater = value; }
		}

		public bool Marking
		{
			get { return m_markwater; }
		}

		public override Vector Position
		{
			get { return m_position; }
			set { m_position = value; }
		}

		public override float Facing
		{
			get { return m_facing; }
			set { m_facing = value; }
		}

		//public override float RunningSpeed { get {return 17.0f;} }

		public override OBJECTTYPE ObjectType
		{
			get { return OBJECTTYPE.PLAYER; }
		}

		public override HIER_OBJECTTYPE HierType
		{
			get { return HIER_OBJECTTYPE.PLAYER; }
		}


		public ObjectReference LastLoot
		{
			get { return m_lastloot; }
			set { m_lastloot = value; }
		}


		#endregion

		#region Hit-related

		public override void StartCombat(LivingObject targetObject)
		{
			StandState = UNITSTANDSTATE.STANDING;
			base.StartCombat(targetObject);
		}

		private void AccumulateRage(int amount)
		{
			if (IsWarriorStance)
			{
				if (Power < MaxPower)
					Power += amount;
				if (Power > MaxPower)
					Power = MaxPower;
			}
		}

		private void RaiseCombat()
		{
			foreach (PlayerSkill skill in GetCombatSkills())
				if (skill != null &&
					skill.SkillID != (ushort)SKILL.FISHING &&
					skill.SkillID != (ushort)SKILL.ENGENEERING &&
					skill.SkillID != (ushort)SKILL.BLACKSMITHING &&
					Utility.Chance(skill.RaiseChance))
					RaiseSkill(skill);
		}

		private void RaiseDefence()
		{
			foreach (PlayerSkill skill in GetDefenceSkills())
				if (skill != null && Utility.Chance(skill.RaiseChance / 2))
					RaiseSkill(skill);
		}

		private void RaiseRanged()
		{
			foreach (PlayerSkill skill in GetRangedSkills())
				if (skill != null && Utility.Chance(skill.RaiseChance))
					RaiseSkill(skill);
		}

		public void DamageArmor(float chance, float value)
		{
			bool isdestr = false, isdam = false;
			for (int i = 0; i <= (int)INVSLOT.EQUIPPEDLAST; i++)
				if (Inventory[i] != null && Inventory[i].MaxDurability != 0 && Inventory[i].Durability > 0 &&
					Utility.Chance(chance))
				{
					Inventory[i].Durability -= value == 0f ? 1 : (int)(Inventory[i].MaxDurability * value);
					if (Inventory[i].Destroyed)
					{
						Inventory[i].Durability = 0;
						Inventory[i].OnUnequip(this);
						isdestr = true;
					}
					isdam = true;
				}
			if (isdam)
			{
				if (isdestr)
					Redress();
				UpdateData();
			}
		}

		public void DamageWeapon(float chance)
		{
			DamageWeapon(chance, 0.0f);
		}

		public void DamageWeapon(float chance, float value)
		{
			if (IsFeralForm)
				return;

			if (Inventory[INVSLOT.MAINHAND] != null && Inventory[INVSLOT.MAINHAND].MaxDurability != 0 &&
				Inventory[INVSLOT.MAINHAND].Durability > 0 && Utility.Chance(chance))
			{
				Inventory[INVSLOT.MAINHAND].Durability -= value == 0f
															? 1
															: (int)(Inventory[INVSLOT.MAINHAND].MaxDurability * value);
				if (Inventory[INVSLOT.MAINHAND].Destroyed)
				{
					Inventory[INVSLOT.MAINHAND].OnUnequip(this);
					Redress();
				}
				UpdateData();
			}
			if (Inventory[INVSLOT.OFFHAND] != null && Inventory[INVSLOT.OFFHAND].MaxDurability != 0 &&
				Inventory[INVSLOT.OFFHAND].Durability > 0 && Utility.Chance(chance))
			{
				Inventory[INVSLOT.OFFHAND].Durability -= value == 0f
															? 1
															: (int)(Inventory[INVSLOT.OFFHAND].MaxDurability * value);
				;
				if (Inventory[INVSLOT.OFFHAND].Destroyed)
				{
					Inventory[INVSLOT.OFFHAND].OnUnequip(this);
					Redress();
				}
				UpdateData();
			}
		}

		private void CastOnHit(LivingObject enemy)
		{
			for (int i = (int)INVSLOT.MAINHAND; i <= (int)INVSLOT.OFFHAND; i++)
			{
				if (enemy == null || enemy.Dead)
					return;
				ItemObject item = Inventory[i];
				if (item == null || item.Destroyed)
					continue;

				item.OnHit(enemy);
			}
		}

		public override bool TakeMeleeDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage, float maxDamage,
											 float hitChance, float critChance, bool offhand)
		{
			if (enemy is PlayerObject)
				PvP = ((PlayerObject)enemy).PvP = true;

			float avDamage = (maxDamage - minDamage) / 2 + minDamage;
			DelayCast((int)avDamage * 30);

			if (DamageType == DAMAGETYPE.PHYSICAL)
			{
				AccumulateRage((int)(10 * avDamage / (Level * 1.5f)));

				RaiseDefence();
				DamageArmor(0.04f, (enemy.Level / Level) / 50.0f);
			}
			float nBlockChance = Inventory[INVSLOT.OFFHAND] != null &&
								 Inventory[INVSLOT.OFFHAND].Template.InvType == INVTYPE.SHIELD
									? BlockChance / 100f
									: 0;

			float nCritChance = critChance;
			if (StandState != UNITSTANDSTATE.STANDING)
			{
				nCritChance = 1f;
				StandState = UNITSTANDSTATE.STANDING;
			}

			// npc backstab
			if (enemy is UnitBase && !(enemy is PetBase))
			{
				if (!Position.InFront(Facing, enemy.Position))
				{
					nCritChance += 0.4f;
					if (!SpellManager.CheckResist(enemy, this, OtherBase.DazeSpell) && Utility.Chance(0.40))
						SpellManager.Cast(enemy, this, OtherBase.DazeSpell);
				}

				if (((UnitBase)enemy).Creature.Elite>0 &&((UnitBase)enemy).Creature.CreatureType == 2 && Utility.Chance(0.3))
				{
					DamageType = DAMAGETYPE.FIRE;
				}
			}

			return
				DoTakeDamage(
					enemy,
					DamageType,
					DAMAGECATEGORY.MELEE,
					minDamage,
					maxDamage,
					hitChance,
					nCritChance,
					nBlockChance,
					ParryChance / 100f,
					DodgeChance / 100f,
					spell,
					offhand
					);
		}

		public override bool TakeMagicDamage(ObjectBase enemy, DBSpell spell, DAMAGETYPE DamageType, float minDamage, float maxDamage, float hitChance, float critChance)
		{
			if (DamageType == DAMAGETYPE.PHYSICAL)
			{
				float avDamage = (maxDamage - minDamage) / 2 + minDamage;
				AccumulateRage((int)(10 * avDamage / (Level * 1.5f)));
			}

			return base.TakeMagicDamage(enemy, spell, DamageType, minDamage, maxDamage, hitChance, critChance);
		}

		public override bool SubmitMeleeDamage(LivingObject enemy)
		{
			if (enemy is PlayerObject)
				PvP = ((PlayerObject)enemy).PvP = true;
			CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED_COMBAT);
			
			RaiseCombat();
			
			CastOnHit(enemy);
			
			if (enemy.Dead)
				return false;

			DamageWeapon(0.005f);

			float damageMult = DamagePhysicalPercent != 0 ? DamagePhysicalPercent : 1f;

			bool offhand = IsDualWield && Utility.Chance(0.5f);

			float nminDamage = damageMult * (offhand ? MinOffhandDamage : MinDamage);
			float nmaxDamage = damageMult * (offhand ? MaxOffhandDamage : MaxDamage);

			float avDamage = nminDamage / 2f + nmaxDamage / 2f;

			AccumulateRage((int)(10 * avDamage / (Level * 0.5f)));

			return
				enemy.TakeMeleeDamage(this, null, offhand ? m_offhandDamageType : m_damageType, nminDamage, nmaxDamage,
									  HitChance(MeleeHitChance, GetCombatLevel(), enemy.Defence),
									  HitChance(MeleeCritChance, GetCombatLevel(), enemy.Defence), offhand);
		}

		public override bool SubmitMeleeDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float minDamage,
											   float maxDamage, bool instant)
		{
			if (enemy is PlayerObject)
				PvP = ((PlayerObject)enemy).PvP = true;
			//CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED_COMBAT);
			
			RaiseCombat();
			
			CastOnHit(enemy);
			
			if (enemy.Dead)
				return false;
			
			DamageWeapon(0.01f);

			float damageMult = DamagePhysicalPercent != 0 ? DamagePhysicalPercent : 1f;

			int aTime = 2400;

			if (instant && !IsFeralForm && Inventory[INVSLOT.MAINHAND] != null)
				switch (Inventory[INVSLOT.MAINHAND].Template.WeaponSubClass)
				{
					case WEAPONSUBCLASS.TWOHANDAXE:
					case WEAPONSUBCLASS.TWOHANDBLUNT:
					case WEAPONSUBCLASS.TWOHANDSWORD:
					case WEAPONSUBCLASS.TWOHANDEXOTIC:
						aTime = 3300;
						break;
					case WEAPONSUBCLASS.DAGGER:
						aTime = 1700;
						break;
				}
			float attackPower = aTime * (AttackPower/* + AttackPowerModifier*/) / 14000f;

			//bool offhand = IsDualWield && Utility.Chance(0.5f);

			float nminDamage = SpellProcessor.ProcessDamage(spell, damageMult * (base.MinDamage + attackPower) + minDamage, 1);
			float nmaxDamage = SpellProcessor.ProcessDamage(spell, damageMult * (base.MaxDamage + attackPower) + maxDamage, 1);

			//float avDamage = nminDamage/2f + nmaxDamage/2f;

			//AccumulateRage((int) (avDamage/(Level*0.05f)));

			return
				enemy.TakeMeleeDamage(this, spell, damageType == DAMAGETYPE.MAX ? m_damageType : damageType, nminDamage, nmaxDamage,
									  HitChance(MeleeHitChance, GetCombatLevel(), enemy.Defence),
									  HitChance(MeleeCritChance, GetCombatLevel(), enemy.Defence), false);
			// else
		}

		public override bool SubmitMeleeDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float percent)
		{
			if (enemy is PlayerObject)
				PvP = ((PlayerObject)enemy).PvP = true;

			//CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED_COMBAT);
			RaiseCombat();
			if (!IsFeralForm)
				CastOnHit(enemy);
			if (enemy.Dead)
				return false;
			DamageWeapon(0.01f);

			float damageMult = DamagePhysicalPercent != 0 ? DamagePhysicalPercent * percent : percent;

			float nminDamage = SpellProcessor.ProcessDamage(spell, damageMult * MinDamage, 1); // attack power is added in MinDamage
			float nmaxDamage = SpellProcessor.ProcessDamage(spell, damageMult * MaxDamage, 1); // attack power is added in MaxDamage

			return
				enemy.TakeMeleeDamage(this, spell, damageType == DAMAGETYPE.MAX ? m_damageType : damageType, nminDamage, nmaxDamage,
									  HitChance(MeleeHitChance, GetCombatLevel(), enemy.Defence),
									  HitChance(MeleeCritChance, GetCombatLevel(), enemy.Defence), false);
		}

		public override bool SubmitRangedDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float minDamage,
												float maxDamage)
		{
			if (enemy is PlayerObject)
				PvP = ((PlayerObject)enemy).PvP = true;
			RaiseRanged();

			float damageMult = DamageRangedPercent != 0 ? DamageRangedPercent : 1f;

			float nminDamage = SpellProcessor.ProcessDamage(spell, MinRangedDamage * damageMult + minDamage, 1);
			float nmaxDamage = SpellProcessor.ProcessDamage(spell, MaxRangedDamage * damageMult + maxDamage, 1);

			LogConsole.WriteLine(LogLevel.ECHO, "Ranged damage {0} - {1}, type {2}", nminDamage, nmaxDamage, damageType);

			return
				enemy.TakeRangedDamage(this, spell, damageType == DAMAGETYPE.MAX ? m_rangedDamageType : damageType, nminDamage, nmaxDamage,
									   HitChance(RangedHitChance, GetRangedLevel(), enemy.Defence),
									   HitChance(RangedCritChance, GetRangedLevel(), enemy.Defence));
		}

		public override bool SubmitRangedDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float percent)
		{
			if (enemy is PlayerObject)
				PvP = ((PlayerObject)enemy).PvP = true;
			//CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED_COMBAT);
			RaiseRanged();

			float damageMult = DamageRangedPercent != 0 ? DamageRangedPercent * percent : percent;

			float nminDamage = SpellProcessor.ProcessDamage(spell, MinRangedDamage * damageMult, 1);
			float nmaxDamage = SpellProcessor.ProcessDamage(spell, MaxRangedDamage * damageMult, 1);

			LogConsole.WriteLine(LogLevel.ECHO,
			                     "Ranged damage " + nminDamage + " - " + nmaxDamage + ", type " + damageType);

			//float avDamage = (maxDamage - minDamage) / 2 + minDamage;
			//AccumulateRage((int)(avDamage / (Level * 5)));

			return
				enemy.TakeRangedDamage(this, spell, damageType == DAMAGETYPE.MAX ? m_rangedDamageType : damageType, nminDamage, nmaxDamage,
									   HitChance(RangedHitChance, GetRangedLevel(), enemy.Defence),
									   HitChance(RangedCritChance, GetRangedLevel(), enemy.Defence));
		}

		public override bool SubmitMagicDamage(LivingObject enemy, DBSpell spell, DAMAGETYPE damageType, float minDamage,
											   float maxDamage)
		{
			if (enemy is PlayerObject)
				PvP = ((PlayerObject)enemy).PvP = true;

			//float avDamage = (maxDamage - minDamage)/2 + minDamage;
			//AccumulateRage((int) (avDamage/(Level*5)));

			return
				enemy.TakeMagicDamage(this, spell, damageType, minDamage, maxDamage,
				                      MagicHitChance / 100f,
									  MagicCritChance / 100f + SpellProcessor.AdditionalCritChance(spell));
		}

		#endregion

		#region packets

		public override A9Packet[] CreatePacketFull
		{
			get
			{
				CustomArrayList result = new CustomArrayList();
				result.AddRange(base.CreatePacketFull);
				for (int i = 0; i < (int)INVSLOT.MAX; i++)
					if (Inventory[i] != null)
						result.AddRange(Inventory[i].CreatePacketFull);
				LogConsole.WriteLine(LogLevel.ECHO,
						 "Created full create packet for player " + Name + ", total sub-packets: " +
						 result.Count);
				A9Packet[] aresult = (A9Packet[])result.ToArray(typeof(A9Packet));
				result.Dispose();
				return aresult;
			}
		}

		//public override A9Packet[] UpdatePacketFull
		//{
		//    get
		//    {
		//        CustomArrayList result = new CustomArrayList();
		//        result.AddRange(base.UpdatePacketFull);
		//        for (int i = 0; i < (int)INVSLOT.MAX; i++)
		//            if (Inventory[i] != null && Inventory[i].HasUpdates)
		//                result.AddRange(Inventory[i].UpdatePacketFull);

		//        LogConsole.WriteLine(LogLevel.ECHO,
		//                             "Created full update packet for player " + Name + ", total sub-packets: " +
		//                             result.Count);

		//        A9Packet[] aresult = (A9Packet[])result.ToArray(typeof(A9Packet));
		//        result.Dispose();
		//        return aresult;
		//    }
		//}

		#endregion

		#region Update/Create

		protected override int UpdatePacketFlags(bool isPrivate)
		{
				return isPrivate ? 0x79 : 0x78;
		}

		public void CreatePlayerObject()
		{
			if (BackLink != null && BackLink.Client != null)
				BackLink.Client.Send(new CompressedA9Packet(CreatePacketFull));
		}

		public void ForceUpdateData()
		{
			if (IsDisposed)
				return;

			if (MapTile != null && HasUpdates)
				MapTile.SendSurrounding(new CompressedA9Packet(UpdatePacketSmall), this);

			if (/*HasUpdates && */BackLink != null && BackLink.Client != null)
			{
				List<A9Packet> packets = new List<A9Packet>();

				for (byte i = 0; i <= Inventory.Last; i++)
					if (Inventory[i] != null && Inventory[i].HasUpdates)
						packets.AddRange(Inventory[i].UpdatePacketFull);

				if (HasUpdates)
					packets.AddRange(UpdatePacketFull);

				BackLink.Client.Send(new CompressedA9Packet(packets));
			}

			/*if (BackLink != null && BackLink.Client != null)
			{
				List<A9Packet> packets = new List<A9Packet>();

				if (HasUpdates)
					lock (m_syncRoot)
					{
						packets.Add(UpdateObjectPacket(true, false));
						ClearPrivateFields();
					}

				if (packets.Count>0)
					BackLink.Client.Send(new CompressedA9Packet(packets));
			}

			if (HasPublicUpdates && MapTile != null && MapTile.HasAjPlayers)
			{
				MapTile.SendSurrounding(new CompressedA9Packet(UpdatePacketSmall), this, this);
				//toSend.Add(UpdatePacketSmall);
			}

			//UpdateData(null);*/
		}

		public void UpdateData(List<A9Packet> toSend)
		{
			if (IsDisposed)
				return;

			/*if (HasUpdates)
				toSend.Add(UpdatePacketSmall);*/

			ForceUpdateData();
			/*
			if (BackLink != null && BackLink.Client != null)
			{
				List<A9Packet> packets = new List<A9Packet>();

				if (HasUpdates)
					lock (m_syncRoot)
					{
						packets.Add(UpdateObjectPacket(true, false));
						ClearPrivateFields();
					}

				if (packets.Count > 0)
					BackLink.Client.Send(new CompressedA9Packet(packets));
			}

			if (HasPublicUpdates && MapTile != null && MapTile.HasAjPlayers)
			{
				//MapTile.SendSurrounding(new CompressedA9Packet(UpdatePacketSmall), this, this);
				toSend.Add(UpdatePacketSmall);
			}*/
			//if (HasUpdates && BackLink != null && BackLink.Client != null)
			//	BackLink.Client.Send(new CompressedA9Packet(UpdatePacketFull));
		}

		public void UpdateBags()
		{
			if (IsDisposed || BackLink == null || BackLink.Client == null)
				return;

			ForceUpdateData();
			/*
			List<A9Packet> result = new List<A9Packet>();

			for (byte i = (byte)INVSLOT.BAGFIRST; i <= (byte)INVSLOT.BAGLAST; i++)
				if (Inventory[i] != null && Inventory[i].HasUpdates)
					result.AddRange(Inventory[i].UpdatePacketFull);

			if (result.Count>0)
				BackLink.Client.Send(new CompressedA9Packet(result));
			 * */
		}

		#endregion

		public override void Mount(int dispID)
		{
			base.Mount(dispID);
			ForceUpdateData();
		}

		protected override void StartFightEvent(LivingObject enemy)
		{
			if (FightEvent != null && !FightEvent.Finished)
				FightEvent.ChangeTarget(enemy);
			else
			{
				FightEvent = new CombatEvent(this, enemy);
				FightEvent.Start();
			}
			//Enemy = enemy;
		}

		#region Death

		public void ReleaseSpirit()
		{
			if (!Dead)
				return;
			try
			{
				if (m_releaseEvent != null)
				{
					m_releaseEvent.Finish();
					m_releaseEvent = null;
				}

				DeathPoint = Position.Clone();
				DeathWorld = (int)WorldMapID;
				DeathTile = MapTile;

				Ghost = true;

				TeleportToHealer();

				GhostForm();
			}
			catch (Exception e)
			{
				Dead = false;
				LogConsole.WriteLine(LogLevel.SYSTEM, "Error at release " + e);
			}
		}

		public void TeleportToHealer()
		{
			if (WorldMapID == 13 || WorldMapID == 29)
				return;

			int ressurectWorld = MapTile.Map.RessurectWorld;
			Vector ressurectPoint = MapTile.Map.RessurectPoint;

			if (ressurectWorld == -1)
			{
				ressurectWorld = (int)WorldMapID;
				ressurectPoint = Position.Clone();
			}

			CustomArrayList sh = MapManager.GetWorldMap((uint)ressurectWorld, MapInstanceID).SpiritHealers;

			if (sh.Count > 0)
			{
				DeathHealer = null;
				float dist = 0f;
				foreach (LivingObject spawn in sh)
				{
					float ndist = spawn.Position.DistanceAvr(ressurectPoint);
					if (DeathHealer == null || ndist < dist)
					{
						DeathHealer = spawn;
						dist = ndist;
					}
				}
				if (DeathHealer != null)
					Teleport.TeleportTo(DeathHealer.Position, (uint)ressurectWorld, this);
			} else
				Teleport.TeleportTo(BindPoint, m_character.BindWorld, this);
		}

		public void GhostForm()
		{
			Auras.RemoveAllAuras();
			Modifiers.UnregisterAllModifiers();
			Redress();

			PlayerFlags = 0x10;
			StandState = UNITSTANDSTATE.STANDING;
			Health = 1;

			if (Race == RACE.NIGHTELF)
				SpellManager.SelfCast(this, OtherBase.GhostWispSpell);
			SpellManager.SelfCast(this, OtherBase.GhostSpell);
			Ghost = true;

			UpdateData();
		}

		private static int[] RankCP = {0, 0, 0, 0, 0, 189, 210, 221, 233, 246, 260, 274, 289, 305, 321, 339, 357, 377, 398};

		private static double[] DishonorPenalty =
				{
					11.5, 13.0, 14.5, 16.0, 17.5, 19.0, 21.0, 23.0, 25.0, 27.0, 29.0, 31.0, 34.2, 37.4, 40.7, 43.9, 47.1, 50.3, 53.6,
					56.8, 60.0, 64.0, 68.0, 72.0, 76.0, 80.0, 84.0, 88.0, 92.0, 96.0, 100.0
				};

		protected override int KillExperience(LivingObject victim, int exp/*, int levelGap*/)
		{
			if (m_lastVictim == victim.GUID)
				return -1;
			m_lastVictim = GUID;

			int result = exp;

			if (Level < Constants.MaximumLevel && !(victim is PlayerObject))
			{
				/*if (victim.Level > Level + levelGap *2 )
				{
					int newexp = 70 + (Level*5);
					if (exp > newexp)
						result = exp = newexp;
				}*/
				
				if (Dead && Exp + exp*2 > NextLevelExp)
				{
					
				}
				else
				if (RestedState == RESTEDSTATE.WELLRESTED)
				{
					RestedPoints--;
					result += exp;
				}

				if (exp > 0 && BackLink != null)
				{
					//Console.WriteLine("Sending exp {0} result {1}", exp, result);
					ShortPacket pkg = new ShortPacket(SMSG.LOG_XPGAIN);
					pkg.Write(victim.GUID);
					pkg.Write(result);
					pkg.Write((byte)0);
					pkg.Write(exp);
					BackLink.Client.Send(pkg);
				}
			}
			else result = 0;

			if (victim is PlayerObject)
			{
				PlayerObject player = (PlayerObject)victim;

				if (RunWoW.Misc.Faction.SameFaction(player.bRace.Faction, bRace.Faction)) // skip duelling, etc.
					return -1;

				if (honorableLevel(victim.Level, Level))
				{
					HKills++;

					Honor += RankCP[player.PVPRank];

					if (BackLink != null)
					{
						ShortPacket pkg = new ShortPacket(SMSG.PVP_CREDIT);
						pkg.Write(player.PVPRank);
						pkg.WriteGuid(GUID);
						pkg.Write(PVPRank);
						BackLink.Client.Send(pkg);
					}
				}
				else
				{
					DHKills++;

					if (m_character.Level < 30)
						m_character.RPAll -= 10;
					else
						if (m_character.Level >= 60)
							m_character.RPAll -= 100;
						else
							m_character.RPAll -= (int)Math.Round(DishonorPenalty[m_character.Level - 30]);
					
					if (m_character.RPAll < 0)
						m_character.RPAll = 0;

					RecalcRank();
					
					if (BackLink != null)
					{
						ShortPacket pkg = new ShortPacket(SMSG.PVP_CREDIT);
						pkg.Write(0);
						pkg.Write(GUID);
						pkg.Write(PVPRank);
						BackLink.Client.Send(pkg);
					}
				}
				
				//if (victim.Level < Level - levelGap) // low level player
				//{
				//    if (BackLink != null)
				//        Chat.System(BackLink.Client, "You have gained dishonourable kill");
				//    DHKills++;
				//}
				//else // less than gap, same or higher level player 
				//{
				//    if (BackLink != null)
				//        Chat.System(BackLink.Client, "You have gained honourable kill");
				//    HKills++;
				//}
				
			}
			else
				if (victim is UnitBase)
				{
					switch (victim.Entry)
					{
						case 1748: // Highlord Bolvar Fordragon
						case 4949: // Thrall
						case 7937: // High Tinker Mekkatorque
						case 7999: // Tyrande Whisperwind
						case 10540: // Vol'jin
						case 3057: // Cairne Bloodhoof
						case 10181: // Lady Sylvanas Windrunner
						case 2784: // King Magni Bronzebeard
							
						case 16802: // Lor'Themar Theron
						//case ???:// Propet Velen
							HKills++;

							Honor += 488;

							if (BackLink != null)
							{
								ShortPacket pkg = new ShortPacket(SMSG.PVP_CREDIT);
								pkg.Write(19);
								pkg.Write(GUID);
								pkg.Write(PVPRank);
								BackLink.Client.Send(pkg);
							}
							break;
						default:
							if (victim is NPCBase && (victim.Flags & 0x1000) == 0x1000 && victim.Level < XPCalculator.GrayLevel(Level)) // civilian?
							{
								if (m_character.Level < 30)
									m_character.RPAll -= 10;
								else
									if (m_character.Level >= 60)
										m_character.RPAll -= 100;
									else
										m_character.RPAll -= (int)Math.Round(DishonorPenalty[m_character.Level - 30]);

								if (m_character.RPAll < 0)
									m_character.RPAll = 0;

								RecalcRank();
								
								if (BackLink != null)
								{
									//Chat.System(BackLink.Client, "You have gained dishonourable kill");
									ShortPacket pkg = new ShortPacket(SMSG.PVP_CREDIT);
									pkg.Write(0);
									pkg.Write(GUID);
									pkg.Write(PVPRank);
									BackLink.Client.Send(pkg);
								}
							}
							break;

					}
				}
			//else  /// TODO: race leaders
			//    if (victim is BossBase)
			//    {
					
			//    }

			return result;
		}

		static bool honorableLevel(int level1, int level2)//level1 - ������� ������, level2 - ������� ��������� ����
		{
			if (level2 <= 19)
			{
				if (level2 - level1 >= 6)
					return false;
				else
					return true;
			}
			if (level2 <= 29)
			{
				if (level2 - level1 >= 7)
					return false;
				else
					return true;
			}
			if (level2 <= 39)
			{
				if (level2 - level1 >= 8)
					return false;
				else
					return true;
			}
			if (level2 <= 44)
			{
				if (level2 - level1 >= 9)
					return false;
				else
					return true;
			}
			if (level2 <= 49)
			{
				if (level2 - level1 >= 10)
					return false;
				else
					return true;
			}
			if (level2 <= 54)
			{
				if (level2 - level1 >= 11)
					return false;
				else
					return true;
			}
			if (level2 <= 59)
			{
				if (level2 - level1 >= 12)
					return false;
				else
					return true;
			}
			if (level2 - level1 >= 13)
				return false;
			else
				return true;
		}	
		#endregion

		#region Visibility

		//public bool CanSee(ulong oGUID)
		//{
		//    if (oGUID == 0)
		//        return false;
		//    if (oGUID == ulong.MaxValue)
		//        return true;
		//    if (Disposed || MapTile == null)
		//        return false;

		//    ObjectBase obj = MapTile.GetObject(GUID);

		//    if (obj == null)
		//        return false;

		//    return CanSee(obj);
		//}

		public bool CanSee(ObjectBase obj)
		{
			if (obj == null || obj.IsDisposed || IsDisposed || MapTile == null)
				return false;

			if (obj == this)
				return true;

			if (GM)
				return true; // GMs can see everyone

			if (SameGroup(obj))
				return true; // Always see party members

			if (Ghost) // I'm dead
			{
				if (obj is PlayerObject && ((PlayerObject)obj).Ghost)
					return true; // can see other ghosts
				if (obj is UnitBase && obj.Entry == MapTile.Map.SpiritHealer)
					return true; // can see spirit healers 
				if (obj.MapTile != null && obj.MapTile.IsAdjacent(DeathTile) != ADJACENT.NONE
					/* == DeathTile)/* || (obj.MapTile != null && obj.MapTile.Map.MapID > 1)*/)
					return true;
				return false;
			}
			if (obj is PlayerObject && ((PlayerObject)obj).Ghost)
				return false;

			if (obj is UnitBase && ((UnitBase)obj).Spawn != null && ((UnitBase)obj).Spawn.BehaivorID ==9/*Entry == MapTile.Map.SpiritHealer*/)
				return false;

			if (obj is LivingObject && ((LivingObject)obj).SShift == (byte)ShapeshiftForm.FORM_STEALTH)
			{
				float sqrdDistance = obj.Position.DistanceSqrd(Position);
				if (sqrdDistance > ConstantsCache.MonsterStealthSightRangeSqrd)
					return false;
				else
				{
					((LivingObject) obj).Flags &= ~0x2000000;
					//((LivingObject) obj).SFlags
				}
			}

			if (obj is LivingObject && ((LivingObject)obj).InvisLevel > SenseInvisLevel)
				return false;

			return true;
		}

		//public bool CanSee_Create(ulong oGUID)
		//{
		//    if (Disposed || MapTile == null)
		//        return false;

		//    if (oGUID == GUID)
		//        return false; // do not need to see own small create packet

		//    ObjectBase obj = MapTile.GetObject(GUID);

		//    if (obj == null)
		//        return false;

		//    return CanSee_Create(obj);
		//}

		public bool CanSee_Create(ObjectBase obj)
		{
			if (obj == null || obj.IsDisposed || Disposed || MapTile == null)
				return false;

			if (obj == this)
				return false; // do not need to see own small create packet

			return CanSee(obj);
		}

		//public bool CanSee_Destroy(ulong oGUID)
		//{
		//    if (Disposed || MapTile == null)
		//        return false;

		//    if (oGUID == GUID)
		//        return false; // do not need to see own destroy packet

		//    ObjectBase obj = MapTile.GetObject(GUID);

		//    if (obj == null)
		//        return false;

		//    return CanSee_Destroy(obj);
		//}

		public bool CanSee_Destroy(ObjectBase obj)
		{
			if (obj == null || IsDisposed || MapTile == null)
				return false;

			if (obj == this)
				return false; // do not need to see own destroy packet
			//if (obj is GameObject/* && ((GameObject)obj).Template.Transport*/)
			//    return false; // transports are always visible

			if (obj is PlayerObject && SameGroup(obj))
				return false; // do not send destroy packets on groupmates

			return true;
		}

		#endregion

		public override bool Moved(DateTime time, bool positionChanged)
		{
			if (positionChanged && Casting && CastEvent is SpellCastEvent && CastEvent.Delay.TotalMilliseconds >= 500)
			{
				if (time > m_castStart)
				{
					CancelCast(SpellFailedReason.SPELL_FAILED_MOVING);
					if (m_channel_spell != 0)
						Auras.CancelAuraForce((uint)m_channel_spell);
				}
				else return false;
			}

			if (positionChanged && Casting && CastEvent is LogoutEvent)
			{
				CancelCast(SpellFailedReason.SPELL_FAILED_MOVING);
			}

			return base.Moved(time, positionChanged);
		}

		public ObjectBase GetNearUnit(ulong unitGUID)
		{
			if (SelectionGUID == unitGUID)
				return Selection;
			
			if (MapTile != null)
				return MapTile.GetNearObject(unitGUID, OBJECTTYPE.UNIT, Position);

			return null;
		}

		public static void Initialize()
		{
			UpdateManager.Instance.Register(typeof(PlayerObject));
		}


	}

	[PacketHandlerClass()]
	public class Respawn
	{
		[PacketHandler(CMSG.REPOP_REQUEST)]
		public static void OnRespawn(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;

			if (Client == null || Client.Player == null)
				return;
			Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
			Client.Player.ReleaseSpirit();
		}

		[PacketHandler(CMSG.RESURRECT_RESPONSE)]
		[PacketHandler(CMSG.RECLAIM_CORPSE)]
		public static void OnResurrect(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;

			if (Client == null || Client.Player == null)
				return;
			if (!Client.Player.Dead)
				return;

			if (Client.Player.MapTile != null && Client.Player.MapTile.IsAdjacent(Client.Player.DeathTile) != ADJACENT.NONE)
			{
				Client.Player.Dead = false;
				Client.Player.Health = Client.Player.MaxHealth / 2;
				if (Client.Player.PowerType != POWERTYPE.RAGE)
					Client.Player.Power = Client.Player.MaxPower / 2;

				Client.Player.DamageArmor(1f, 0.1f);
				Client.Player.DamageWeapon(1f, 0.1f);
			}
		}
	}
}