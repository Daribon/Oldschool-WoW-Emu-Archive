//
using System;
using RunServer.Common;
using RunServer.Database;
using RunWoW.Objects;

namespace RunWoW.Misc
{
	public enum EventResult : int
	{
		NOT_FINISHED = -3,
		ERROR_WRONG_PARAMS = -2,
		ERROR = -1,
		COMPLETED = 0,
		OWNER_DEAD = 1,
		TARGET_DEAD = 2,
		TARGET_TO_FAR = 3,
		TERMINATED = 4,
		CANCELED = 5,
		NEED_RECALC = 6,
	}
	
	public delegate void EventFinishHandler(object data);

	public abstract class Event : CountedObject, IDisposable 
	{
		private EventResult m_result;

		private Timer m_timer;

		private TimeSpan m_delay;
		private TimeSpan m_interval;
		private TimerPriority m_priority;

		private int m_count;

		private bool disposed = false;

		private string m_timerName = string.Empty;

		private ExecutionPriority m_executionPriority = ExecutionPriority.None;

		public event EventFinishHandler OnEventFinished;
		
		#region Properties

		public EventResult Result
		{
			get { return m_result; }
		}

		public int Count
		{
			get { return m_count; }
			set
			{
				m_count = value;
				if (m_timer != null)
					//lock(m_timer)
					m_timer.Count = value;
			}
		}

		public int Index
		{
			get
			{
				if (m_timer != null)
					//lock(m_timer)
					return m_timer.Index;
				return 0;
			}
		}

		public TimeSpan Interval
		{
			get { return m_interval; }
			set
			{
				m_interval = value;
				if (m_timer != null)
					//lock(m_timer)
					m_timer.Interval = value;
			}
		}

		public TimeSpan Delay
		{
			get { return m_delay; }
			set
			{
				m_delay = value;
				if (m_timer != null)
					//lock(m_timer)
					m_timer.Delay = value;
			}
		}

		public TimerPriority Priority
		{
			get { return m_priority; }
			set
			{
				m_priority = value;
				if (m_timer != null)
					//lock(m_timer)
					m_timer.Priority = value;
			}
		}

		public bool Finished
		{
			get { return m_result != EventResult.NOT_FINISHED; }
		}

		public string TimerName
		{
			get { return m_timerName; }
			set
			{
				m_timerName = value;
				if (m_timer != null) m_timer.Name = value;
			}
		}

		public ExecutionPriority ExecPriority
		{
			get { return m_executionPriority; }
			set { m_executionPriority = value; }
		}
	    
	    public bool Infinite
	    {
            get { return !Finished && m_timer == null;  }
	    }
	    
		#endregion

		#region Event Handlers

		protected abstract void OnTick();

		protected virtual bool OnStart()
		{
			return true;
		}

		protected virtual void OnFinish()
		{
		}

		#endregion

		public Event(TimeSpan delay)
			: this(delay, TimeSpan.Zero)
		{
		}

		public Event(TimeSpan delay, TimeSpan interval)
		{
			m_delay = delay;
			m_interval = interval;
		}

		public void Prolongate(TimeSpan time)
		{
			if (m_timer != null)
				//lock(m_timer)
				m_timer.Prolongate(time);
		}

		public void Finish(EventResult result)
		{
			if (Finished)
				return;
			m_result = result;

			if (m_timer != null)
			{
				m_timer.Stop();
			}
			else
			{
				LogConsole.WriteLine(LogLevel.ECHO, "Finishing infinite event: " + ToString() + ": " + result);
				OnFinish();
			}
			if (OnEventFinished != null)
				OnEventFinished(null);
		}

		public void Finish()
		{
			Finish(EventResult.TERMINATED);
		}

		public bool Start()
		{
			if (!Finished)
				return false;

			if (m_timer != null)
				//lock(m_timer)
				if (m_timer.Running)
					m_timer.Stop();

			m_result = EventResult.NOT_FINISHED;

            if (m_delay.TotalMilliseconds > 0 || m_interval.TotalMilliseconds > 0)
			{
				m_timer = new Timer(m_delay, m_interval);
				//lock(m_timer)
				{
					m_timer.Name = m_timerName == string.Empty ? GetType().Name : m_timerName;
					m_timer.Count = m_count;
					m_timer.Priority = m_priority;
					m_timer.ExecutionPriority = m_executionPriority;
					m_timer.OnStart += new TimerStartCallback(OnStart);
					m_timer.OnStop += new TimerCallback(OnFinish);
					m_timer.OnTick += new TimerCallback(OnTick);
					m_timer.Start();
				}
				return false;
			}
			else
			{
				LogConsole.WriteLine(LogLevel.ECHO, "Starting infinite event: " + ToString());
				m_timer = null;
				if (OnStart())
					FireEvent();
				return true;
                //Finish(EventResult.COMPLETED);
			}
		}
		
		public void Restart()
		{
			m_result = EventResult.COMPLETED;
			
			Start();
		}

		public void FireEvent()
		{
			m_result = EventResult.NOT_FINISHED;
			OnTick();
		}

		~Event()
		{
			Dispose(false);
		}

		public void Dispose()
		{
			Dispose(true);
			GC.SuppressFinalize(this);
		}

		private void Dispose(bool disposing)
		{
			if (!disposed)
			{
				//if (disposing)
				//{
					if (m_timer != null)
						if (m_timer.Running)
						{
							m_timer.Stop();
							m_timer = null;
						}
				//}
				if (disposing)
					FreeInstance();
				OnEventFinished = null;
			}
			disposed = true;
		}

		#region Checkers

		public static bool CheckObjects(ObjectBase obj)
		{
			return obj != null && obj.MapTile != null && !obj.IsDisposed && !(obj is LivingObject && ((LivingObject)obj).Auras == null);
		}

		public static bool CheckObjects(ObjectBase obj1, ObjectBase obj2)
		{
			return CheckObjects(obj1) && CheckObjects(obj2);
		}

		#endregion
	}
}