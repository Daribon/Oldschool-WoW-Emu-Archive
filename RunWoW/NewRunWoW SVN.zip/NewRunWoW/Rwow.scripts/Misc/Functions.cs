//
using System;
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW
{
	public class DBUtility
	{
		private static int[] HonorLimits = new int[]
			{
				7150, 8125, 9100, 10075, 11050, 12025,
				13325, 14625, 15925, 17225, 18850, 20475,
				22100, 23725, 26000, 28275, 30550, 32825,
				35100, 37375, 39650, 41925, 44200, 46800,
				49400, 52000, 54600, 57200, 59800, 62400,
				65000
			};


		public static byte RP2Rank(DBCharacter chr)
		{
			int max = chr.Level < 30 ? 6500 : chr.Level >= 60 ? 65000 : HonorLimits[chr.Level - 30];
			
			if (chr.RPAll > max)
				chr.RPAll = 65000;

			byte rank;
			if (chr.RPAll >= 2000)
			{
				rank = (byte) Math.Floor(chr.RPAll/5000 + 2.0);
				if (rank > 14)
					rank = 14;
			}
			else
				rank = 1;
			return (byte) (rank + 4);
		}

		public static DBItem ItemOfChar(DBCharacter Character, uint ItemTemplateId, INVSLOT Slot)
		{
			return ItemOfChar(Character, ItemTemplateId, Slot, 1);
		}

		public static DBItem ItemOfChar(DBCharacter Character, uint ItemTemplateId, INVSLOT Slot, int Count)
		{
			DBItemTemplate IT = GetTemplate(ItemTemplateId);
			return ItemOfChar(Character, IT, Slot, Count);
		}

		public static DBItem ItemOfChar(DBCharacter character, DBItemTemplate IT, INVSLOT Slot, int Count)
		{
			if (IT == null)
				return null;
			DBItem item = new DBItem(IT);
			item.ContainerID = character.ObjectId;
			item.OwnerID = character.ObjectId;
			item.OwnerSlot = (byte) Slot;
			item.StackCount = Count;
			//DateTime time = CustomDateTime.Now;
			Database.Instance.AddNewObject(item);
			character.Items.Add(item);
			//double ms = (CustomDateTime.Now - time).TotalMilliseconds;
			//if (ms > 300)
			//    Console.WriteLine("Adding item {0} to player {1} for {2}", IT.Name, Character.Name, ms);
			return item;
		}

		public static DBItemTemplate GetTemplate(uint itemTemplateId)
		{
			DBItemTemplate it = (DBItemTemplate) Database.Instance.FindObjectByKey(typeof (DBItemTemplate), itemTemplateId);
			if (it == null)
				LogConsole.WriteLine(LogLevel.ERROR, "ItemTemplate {0} not found in database!", itemTemplateId);

			return it;
		}

		public static DBAbility SpellOfChar(DBCharacter character, ushort spellID, ushort slot)
		{
			if (character == null)
				return null;
			if (character.Abilities != null)
				foreach (DBAbility abl in character.Abilities)
					if (abl != null && abl.SpellID == spellID)
					{
						if (abl.Slot == 0xffff && slot != 0xffff)
						{
							abl.Slot = slot;
							DBManager.SaveDBObject(abl);
						}
						return abl;
					}
			DBAbility spell = new DBAbility();
			spell.OwnerID = character.ObjectId;
			spell.SpellID = spellID;
			spell.Slot = slot;
			spell.Type = ABILITYTYPE.SPELL;
			spell.Spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellID);
			//DateTime time = CustomDateTime.Now;
			Database.Instance.AddNewObject(spell);
			character.Abilities.Add(spell);
			//double ms = (CustomDateTime.Now - time).TotalMilliseconds;
			//if (ms > 300)
			//    Console.WriteLine("Adding spell {0} to player {1} for {2}", spellID, character.Name, ms);
			//LogConsole.WriteLine(LogLevel.TRACE, "Added spell " + spellID + ": " + spell.Spell.Name + " to player " + character.Name);
			return spell;
		}

		public static DBPetSpell SpellOfPet(DBPet pet, ushort spellID)
		{
			if (pet == null)
				return null;

			if (pet.Spells != null)
			{
				foreach (DBPetSpell abl in pet.Spells)
					if (abl != null && abl.SpellID == spellID)
						return abl;
			}
			else
				Database.Instance.ResolveRelations(pet, typeof (DBPetSpell));

			DBPetSpell spell = new DBPetSpell();
			spell.OwnerID = pet.ObjectId;
			spell.SpellID = spellID;
			spell.Spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellID);
			Database.Instance.AddNewObject(spell);
			pet.Spells.Add(spell);
			LogConsole.WriteLine(LogLevel.TRACE, "Added spell " + spellID + ": " + spell.Spell.Name + " to pet " + pet.Name);
			return spell;
		}

		public static DBAbility TalentOfChar(DBCharacter character, ushort spellID, ushort Rank, ushort TalentID)
		{
			if (character == null)
				return null;
			if (character.Abilities != null)
				foreach (DBAbility abl in character.Abilities)
					if (abl != null && abl.SpellID == spellID)
						return abl;
			DBAbility spell = new DBAbility();
			spell.OwnerID = character.ObjectId;
			spell.SpellID = spellID;
			spell.Slot = 0xffff;
			spell.Level = Rank;
			spell.TalentID = TalentID;
			spell.Type = ABILITYTYPE.TALENT;
			spell.Spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellID);
			Database.Instance.AddNewObject(spell);
			character.Abilities.Add(spell);
			//LogConsole.WriteLine(LogLevel.SYSTEM,"Added talent "+spellID+": "+spell.Spell.Name+" to player "+Character.Name); 
			return spell;
		}

		public static DBAbility SpellOfChar(DBCharacter Character, SPELLSKILL SpellID)
		{
			return SpellOfChar(Character, (ushort) SpellID, 0xffff);
		}

		public static DBAbility SpellOfChar(DBCharacter Character, ushort SpellID)
		{
			return SpellOfChar(Character, SpellID, 0xffff);
		}

		public static DBAbility SkillOfChar(DBCharacter character, ushort spellID, ushort skillID, ushort level,
		                                    ushort maxLevel, byte craft, ushort slot)
		{
			if (character == null)
				return null;
			if (character.Abilities != null)
				foreach (DBAbility abl in character.Abilities)
					if (abl != null && abl.SkillID == skillID)
					{
						if (abl.MaxLevel != maxLevel || (abl.SpellID != spellID))
						{
							abl.SpellID = spellID;
							abl.SkillID = skillID;
							abl.MaxLevel = maxLevel;
							abl.Craft = craft;
							DBManager.SaveDBObject(abl);
						}
						return abl;
					}
			DBAbility skill = new DBAbility();
			skill.OwnerID = character.ObjectId;
			skill.SpellID = spellID;
			skill.Slot = slot;
			skill.SkillID = skillID;
			skill.Level = level;
			skill.MaxLevel = maxLevel;
			skill.Craft = craft;
			skill.Type = ABILITYTYPE.SKILL;
			skill.Spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellID);
			Database.Instance.AddNewObject(skill);
			character.Abilities.Add(skill);
			return skill;
		}

		public static DBAbility SkillOfChar(DBCharacter Character, SPELLSKILL SpellID, SKILL SkillID, ushort Level,
		                                    ushort MaxLevel, byte Craft, ushort slot)
		{
			return SkillOfChar(Character, (ushort) SpellID, (ushort) SkillID, Level, MaxLevel, Craft, slot);
		}

		public static DBAbility SkillOfChar(DBCharacter Character, DBNSkill NSkill)
		{
			if (NSkill.Craft == 3)
				return SpellOfChar(Character, (ushort) NSkill.SpellID, 0xffff);
			else
				return
					SkillOfChar(Character, (ushort) NSkill.SpellID, (ushort) NSkill.SkillID, (ushort) NSkill.Level,
					            (ushort) NSkill.MaxLevel, NSkill.Craft, 0xffff);
		}

		public static DBActionButton ActionButtonOfChar(DBCharacter character, byte num, ushort action, byte type, byte misc)
		{
			if (character == null)
				return null;
			if (character.Actions != null)
				foreach (DBActionButton act in character.Actions)
					if (act.Slot == num)
						if (action == 0)
						{
							DBManager.EraseDBObject(act);
							character.Actions.Remove(act);
							return null;
						}
						else
						{
							act.Action = action;
							act.Type = type;
							act.Misc = misc;
							DBManager.SaveDBObject(act);
							return act;
						}
			if (action == 0)
				return null;
			DBActionButton button = new DBActionButton();
			button.OwnerID = character.ObjectId;
			button.Slot = num;
			button.Action = action;
			button.Type = type;
			button.Misc = misc;
			Database.Instance.AddNewObject(button);
			character.Actions.Remove(button);
			return button;
		}
	}

	public class DamageLog
	{
		public static ShortPacket Melee(ulong target, ulong submitter, DAMAGETYPE damageType, uint hitFlag, byte swingFlag,
		                                float damage, float absorbed,
		                                float resisted, float blocked, VICTIMSTATE victimstate, bool critical)
		{
			ShortPacket pkg = new ShortPacket(SMSG.ATTACKERSTATEUPDATE);
			pkg.Write(hitFlag);
			pkg.WriteGuid(submitter);
			pkg.WriteGuid(target);
			float totalDamage = -blocked + damage - absorbed - resisted;
			pkg.Write((int) totalDamage);

			pkg.Write(swingFlag);
			pkg.Write((int) damageType); // damage type
			pkg.Write((float) damage);
			pkg.Write((int) damage);
			pkg.Write((int) absorbed);
			pkg.Write((int) resisted); // turn ? // vulnerability bonus
			//pkg.Write((byte) damage.Length);
			//for (int i = 0; i < damage.Length; i++)
			//{
			//    pkg.Write((int) i); // damage type
			//    pkg.Write((float) (damage[i]) /* - absorbed[i])*/);
			//    pkg.Write((int) damage[i]);
			//    pkg.Write((int) absorbed[i]);
			//    pkg.Write((int) 0); // turn ? // vulnerability bonus
			//}

			pkg.Write((int) victimstate);
			pkg.Write(absorbed == 0 ? 0 : -1); // victim round duration //?
			pkg.Write((int) 0);
			pkg.Write((int) blocked);

			return pkg;
		}

		public static ShortPacket Periodic(ulong target, ulong submitter, uint spellId, DAMAGETYPE damageType,
		                                   float totalDamage, float totalAbsorbed)
		{
			ShortPacket pkg = new ShortPacket(SMSG.PERIODICAURALOG);
			pkg.WriteGuid(target);
			pkg.WriteGuid(submitter);
			pkg.Write(spellId);

			pkg.Write(1); // count
			pkg.Write(3);
			pkg.Write((int) totalDamage);
			pkg.Write((int) damageType);
			pkg.Write(0);
			return pkg;
		}

		public static ShortPacket Environment(ulong target, ulong submitter, uint spellId, DAMAGETYPE damageType,
		                                      float totalDamage, float totalAbsorbed)
		{
			ShortPacket pkg = new ShortPacket(SMSG.ENVIRONMENTALDAMAGELOG);
			pkg.Write(target);

			pkg.Write((byte) damageType);
			pkg.Write((int) totalDamage);
			return pkg;
		}

		public static ShortPacket Magic(ulong target, ulong submitter, uint spellId, DAMAGETYPE damageType, float Damage,
		                                float Absorbed, float Resisted, float Blocked, bool Critical, VICTIMSTATE victimState)
		{
			/*if (victimState == VICTIMSTATE.DEFLECT) // resist
                return MagicResist(target,submitter,spellId);*/
			// TODO: Magic miss, ranged dodge, etc.

			ShortPacket pkg = new ShortPacket(SMSG.SPELLNONMELEEDAMAGELOG);
			pkg.WriteGuid(target);
			pkg.WriteGuid(submitter);
			pkg.Write(spellId);

			pkg.Write((int) Damage);
			pkg.Write((byte) damageType);
			pkg.Write((int) Absorbed); // absorb
			pkg.Write((int) Resisted); // resist
			pkg.Write(true); // pyshical damage?
			pkg.Write((byte) 0);
			pkg.Write((int) Blocked); // blocked
			pkg.Write(Critical ? (byte) 7 : (byte) 6);

			pkg.Write(10);
			return pkg;
		}

		public static ShortPacket MagicResist(ulong target, ulong submitter, uint spellId)
		{
			ShortPacket pkg = new ShortPacket(SMSG.RESISTLOG);
			pkg.Write(target);
			pkg.Write(submitter);
			pkg.Write(spellId);
			pkg.Write((byte) 0);
			return pkg;
		}

		public static ShortPacket SpellLogExecute(ulong caster, int target, uint spellId, SPELLEFFECT effect)
		{
			ShortPacket pkg = new ShortPacket(SMSG.SPELLLOGEXECUTE);
			pkg.WriteGuid(caster);
			pkg.Write(spellId);
			pkg.Write(1);
			pkg.Write((int) effect);

			if (target == 0)
				pkg.Write(0);
			else
			{
				pkg.Write(1);
				pkg.Write(target);
			}
			return pkg;
		}

		public static ShortPacket Heal(ulong target, ulong submitter, uint spellId, int value, bool critical)
		{
			//ShortPacket pkg = new ShortPacket(SMSG.HEALSPELL_ON_PLAYER_OBSOLETE);
			//pkg.WriteGuid(target);
			//pkg.WriteGuid(submitter);
			//pkg.Write(spellId);
			//pkg.Write(value);
			//pkg.Write((byte)(critical ? 1 : 0));
			//return pkg;
			return SpellLogExecute(submitter, value /*target*/, spellId, SPELLEFFECT.HEAL_HEALTH);
		}
	}

	public class Utility
	{
		//private static Random random = new Random();

		private static long holdrand;

		private static int rand()
		{
			return (int) (((holdrand = holdrand*214013L + 2531011L) >> 16) & 0x7fff);
		}

		public static bool Chance()
		{
			return Chance(RandomDouble());
		}

		public static bool Chance(double chance)
		{
			return chance > 1 ? true : chance < 0 ? false : RandomDouble() <= chance;
		}

		public static bool Chance(float chance)
		{
			return Chance((double) chance);
		}

		/*public static bool Chance(int chance)
        {
            return chance >= 10000 ? true : random.Next(0, 10000) <= chance;
        }*/

		public static int Random()
		{
			return rand();
		}

		public static double RandomDouble()
		{
			return rand()/(double) 0x7fff;
		}

		public static int Random(int from, int to)
		{
			return
				from > to
					? (int) Math.Round(RandomDouble()*(from - to) + to)
					: (int) Math.Round((RandomDouble()*(to - from) + from));
		}

		public static uint Random(uint from, uint to)
		{
			return
				from > to
					? (uint) Math.Round((RandomDouble()*(from - to) + to))
					: (uint) Math.Round((RandomDouble()*(to - from) + from));
		}

		public static float Random(float from, float to)
		{
			return from > to ? (float) (RandomDouble()*(from - to) + to) : (float) (RandomDouble()*(to - from) + from);
		}

		public static double Random(double from, double to)
		{
			return from > to ? (double) (RandomDouble()*(from - to) + to) : (double) (RandomDouble()*(to - from) + from);
		}

		//public static double Random(double from, double to)
		//{
		//    return from > to ? Random(to, from) : (RandomDouble ()* (to - from) + to);
		//}

		public static bool HasBit(int i, byte n)
		{
			if (n > 32 || n < 1 || i == 0)
				return false;
			//BitArray barr = new BitArray(new int[] {i});
			//return barr[n - 1];
			int value = (1 << (n - 1));
			return (i & value) == value;
		}

		public static bool HasBit(byte i, int n)
		{
			if (n > 8 || n < 1 || i == 0)
				return false;
			return HasBit((int) i, n);
		}

		public static bool HasBit(int i, int n)
		{
			return HasBit(i, (byte) n);
		}

		public static bool HasBit(uint i, int n)
		{
			return HasBit((int) i, (byte) n);
		}

		public static bool HasBit(uint i, byte n)
		{
			return HasBit((int) i, n);
		}

		public static uint SetBit(uint i, byte n, bool value)
		{
			return SetBit(i, n, value);
		}

		public static int SetBit(int i, byte n, bool value)
		{
			if (n > 32 || n < 1)
				return i;
			if (!value && i == 0)
				return 0;
			if (value && i == 1)
				return 1;

			int val = (1 << (n - 1));

			//BitArray barr = new BitArray(i);
			//barr[n - 1] = value;
			//int[] result = new int[0];
			//barr.CopyTo(result, 0);
			//return result[0];

			if (value)
				return i | val;
			else
				return i & ~val;
		}

		public static int Timestamp(TimeSpan shift)
		{
			return Timestamp(CustomDateTime.Now + shift);
		}

		public static int Timestamp()
		{
			return Timestamp(TimeSpan.Zero);
		}

		public static int Timestamp(DateTime time)
		{
			return
				(((((time.Minute | (time.Hour << 6)) | (((int) time.DayOfWeek) << 11)) | ((time.Day - 1) << 14)) |
				  ((time.Year - 2000) << 18)) | ((time.Month - 1) << 20));
		}

		public static int PreciseTimestamp()
		{
			return (int) (CustomDateTime.Now.Ticks/TimeSpan.TicksPerMillisecond);
		}

		public static float Normalize(float value)
		{
			return value > 0 ? value : -value;
		}

		public static void Swap(ref float one, ref float second)
		{
			float tmp = second;
			second = one;
			one = tmp;
		}

		public static void NormalizePair(ref float one, ref float second)
		{
			one = Normalize(one);
			second = Normalize(second);
			if (one > second)
				Swap(ref one, ref second);
		}

		public static ulong ReadGuid(BinReader reader)
		{
			int bitmask = reader.ReadByte();
			BitArray mask = new BitArray(new int[] {bitmask});
			byte[] data = new byte[8];
			for (int i = 0; i < 8; i++)
				if (mask[i])
					data[i] = reader.ReadByte();
			return BitConverter.ToUInt64(data, 0);
		}

		public static string SmartCapitalize(object text)
		{
			string txt = text.ToString();
			string result = string.Empty;
			for (int i = 0; i < txt.Length; i++)
				if (i == 0 || txt[i - 1] == ' ' || txt[i - 1] == '-' || txt[i - 1] == '_')
					result += txt[i].ToString().ToUpper();
				else
					result += txt[i].ToString().ToLower();
			return result.Replace('_', ' ');
		}
	}
}