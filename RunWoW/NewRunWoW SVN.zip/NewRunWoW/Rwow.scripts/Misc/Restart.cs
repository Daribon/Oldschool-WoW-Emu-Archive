//
using System;
using System.IO;
using System.Threading;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Misc
{
	[ServerHandlerClass()]
	internal class FinishClass
	{
		[ServerHandler(IMSG.SERVER_RESTARTING)]
		public static void ServerRestart(ClientBase client)
		{
			Chat.System("Server is restarting.. Please reconnect in a minute");
		}

		public static void SavePlayers()
		{
			PooledList<PlayerObject> players = ClientManager.GetPlayerList();

			foreach (PlayerObject player in players)
				player.Save();
			
			Database.Instance.FlushTables();
		}

		[ServerHandler(IMSG.SERVER_EXITING)]
		public static void ServerExit(ClientBase client)
		{
			int delay = 10;
			int count = 1;

			SavePlayers();

			for (int i = 0; i < count; i ++)
			{
				Chat.System(string.Format("������ ��������������� ��� ������������ ����� {0} ������. �������� ���������� ���.", (count - i) * delay));
				Thread.Sleep(delay * 1000);
			}

			SavePlayers();

			using (StreamWriter op = new StreamWriter(Constants.StatusPath + Constants.StatusFile))
			{
				op.WriteLine("<HEAD><META HTTP-EQUIV='Refresh' CONTENT='60' /></HEAD>");
				op.WriteLine(
					"<h2 style='color:white'><center>World of Warcraft Server Status: &nbsp<img src='http://wowserver.wnet.ua/stat.aspx'></center></h2>");
				op.WriteLine("<style>");
				op.WriteLine("TD.head {");
				op.WriteLine("   color: white;");
				op.WriteLine("   font: bold;");
				op.WriteLine("   background: #222222;");
				op.WriteLine("}");
				op.WriteLine("TD.head1 {");
				op.WriteLine("   color: white;");
				op.WriteLine("   font: bold;");
				op.WriteLine("}");
				op.WriteLine("</style>");
				op.WriteLine(
					"   <table style='border-style: solid; border-color: Gray;border-width: 1px;' width='100%' cellspacing='1'>");
				op.WriteLine("      <tr><td class='head' colspan=4><center>Server Information</center></td></tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>.NET Framework Version</td><td>" + Environment.Version.ToString() + "</td>");
				op.WriteLine("         <td class='head1'>Server Version</td><td>" + Constants.Version + "</td>");
				op.WriteLine("      </tr>");
				op.WriteLine("</table>");
				op.WriteLine("<h2 style='color:white'><center>Server is down for maintenance</center></h2>");
			}
		}
	}
}