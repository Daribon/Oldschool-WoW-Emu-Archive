#if USE_IRC
	using System;
using System.Text;
using RunWoW.Accounting;
using RunWoW.Common;using RunServer.Common;
using RunWoW.Objects;
//using Meebey.SmartIrc4net.Delegates;

namespace RunWoW.Misc
{
	public class IRCChat
	{
		private ClientBase m_client;
		private ClientData Client;
		private IrcClient irc;
		private ChatUpdater updater;
		private bool logged;

		public IRCChat(ClientBase client)
		{
			m_client = client;
			logged = false;
			irc = new IrcClient();
			Client = (ClientData) client.Data;
			updater = new ChatUpdater(irc, Client.Player);
		}

		public void JoinChannel(string channel)
		{
			if (!logged)
				Logon();
			string ch = "#" + channel.Replace(" ", "_");
			irc.RfcJoin(ch);
			LogConsole.WriteLine(LogLevel.TRACE, "Joining channel " + channel + "(" + ch + ")");
		}

		public void PartChannel(string channel)
		{
			if (!logged)
				Logon();
			string ch = "#" + channel.Replace(" ", "_");
			irc.RfcPart(ch);
			LogConsole.WriteLine(LogLevel.TRACE, "Parting channel " + channel + "(" + ch + ")");
		}

		public void Logon()
		{
			logged = false;
			irc.SendDelay = 200;
			irc.AutoRetry = true;
			irc.ActiveChannelSyncing = true;
			irc.Encoding = Encoding.GetEncoding(1251);
			//irc.OnQueryMessage += new MessageEventHandler(OnQueryMessage);

			int port = Constants.ChatPort;
			try
			{
				irc.Connect(new string[] {Constants.ChatServer}, port);
				irc.Login(Client.Player.Name, Client.Account.Name);
				irc.ListenOnce();
				updater.Start();
				logged = true;
			}
			catch (ConnectionException e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Cannot connect: " + e);
			}
		}

		public void Message(string mess, string channel)
		{
			if (!logged)
				Logon();
			string ch = "#" + channel.Replace(" ", "_");
			irc.SendMessage(SendType.Message, ch, mess);
		}

		public void Logoff()
		{
			updater.Stop();
			try
			{
				irc.Disconnect();
			}
			catch
			{
			}
		}
	}

	public class ChatUpdater : Timer
	{
		private IrcClient m_chat;
		private PlayerObject m_player;
		private static int UpdateTime = Constants.ChatUpdateTime;

		public ChatUpdater(IrcClient chat, PlayerObject Player) : base(TimeSpan.FromMilliseconds(UpdateTime), TimeSpan.FromMilliseconds(UpdateTime))
		{
			m_chat = chat;
			m_chat.OnChannelMessage += new IrcEventHandler(OnMessage);
			m_player = Player;
			this.Priority = TimerPriority.TwoFiftyMS;
			Primary = false;
		}

		public void OnMessage(object sender, IrcEventArgs e)
		{
			if (m_player == null)
			{
				Stop();
				return;
			}
			string ch = e.Data.Channel.Replace("_", " ");
			ch = ch.TrimStart(new char[] {'#'});
			Chat.Message(CHATMESSAGETYPE.CHANNEL, sender /*Clients.GetCharacterByName(e.Data.Nick)*/, m_player, "[" + e.Data.Nick + "]: " + e.Data.Message, 0, 0.0f, ch);
		}

		protected override void OnTick()
		{
			if (m_chat == null)
			{
				Stop();
				return;
			}
			if (m_player == null)
			{
				Stop();
				return;
			}
			m_chat.ListenOnce(false);
		}
	}
}

#endif