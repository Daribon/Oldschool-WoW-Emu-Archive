//
using System;
using System.Collections;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.Misc
{
	public class WeatherHolder
	{
		public static int WeatherChangeTime = 30; // minutes
		
		private float m_grain;
		private WeatherType m_type;
		private WeatherSound m_sound;
		private DateTime m_date;

		public float Grain
		{
			get { return m_grain; }
		}

		public WeatherType Type
		{
			get { return m_type; }
		}

		public WeatherSound Sound
		{
			get { return m_sound; }
		}

		public bool Expired
		{
			get { return m_date < CustomDateTime.Now; }
		}
		
		public WeatherHolder(float grain, WeatherType type, WeatherSound sound)
		{
			m_grain = grain;
			m_type = type;
			m_sound = sound;
			m_date = CustomDateTime.Now.AddMinutes(WeatherChangeTime);
		}
	}
	
	public class Weather
	{
		private static Hashtable weatherMap = Hashtable.Synchronized(new Hashtable());
		
		public static float WeatherThreshold = 0.5f; // 50% change of good wheather. 0.3 = 30% chance
		
		public static void SendWeather(ClientBase client, uint zone)
		{
			WeatherType type = WeatherType.NONE;
			float grain = 0;
			WeatherSound sound = WeatherSound.NONE;

			if (!((ClientData)client.Data).Player.NoWeather)
				getWeatherForZone(zone, out type, out grain, out sound, false);
			
			ShortPacket weather = new ShortPacket(SMSG.WEATHER);
			weather.Write((int)type);
			weather.Write(grain);
			weather.Write((int)sound);
			client.Send(weather);
		}

		public static bool Cristmas
		{
			get
			{
				return 
					(CustomDateTime.Now.Month == 12 && CustomDateTime.Now.Day >= 25) ||
					(CustomDateTime.Now.Month == 1 && CustomDateTime.Now.Day <= 13);
			}
		}

		private static void getWeatherForZone(uint zone, out WeatherType type, out float grain, out WeatherSound sound, bool force)
		{
			if (Cristmas)
			{
				type= WeatherType.SNOW;
				grain = Utility.Random(0.2f, 0.8f);
				sound = WeatherSound.SNOWHEAVY;
				return;
			}
			WeatherHolder holder = weatherMap[zone] as WeatherHolder;
			if (!force && holder != null && !holder.Expired)
			{
				type = holder.Type;
				grain = holder.Grain;
				sound = holder.Sound;
				return;
			}
			
			grain = Utility.Random(0f, 1f);

			if (grain > WeatherThreshold && !force)
			{
				grain = 0f;
				type = WeatherType.NONE;
				sound = WeatherSound.NONE;
			}
			else
			{
				grain = grain / (1f - WeatherThreshold);

				DBArea area = (DBArea)Database.Instance.FindObjectByKey(typeof(DBArea), zone);
				if (area == null)
					type = WeatherType.NONE;
				else
					type = area.Weather;

				switch (type)
				{
					case WeatherType.RAIN:                                             //rain
						if (grain < 0.33333334f)
							sound = WeatherSound.RAINLIGHT;
						else if (grain < 0.6666667f)
							sound = WeatherSound.RAINMEDIUM;
						else
							sound = WeatherSound.RAINHEAVY;
						break;
					case WeatherType.SNOW:                                             //snow
						if (grain < 0.33333334f)
							sound = WeatherSound.SNOWLIGHT;
						else if (grain < 0.6666667f)
							sound = WeatherSound.SNOWMEDIUM;
						else
							sound = WeatherSound.SNOWHEAVY;
						break;
					case WeatherType.SANDSTORM:                                             //storm
						if (grain < 0.33333334f)
							sound = WeatherSound.SANDSTORMLIGHT;
						else if (grain < 0.6666667f)
							sound = WeatherSound.SANDSTORMMEDIUM;
						else
							sound = WeatherSound.SANDSTORMHEAVY;
						break;
					case WeatherType.NONE:                                             //fine
					default:
						sound = WeatherSound.NONE;
						break;
				}
			}

			weatherMap[zone] = new WeatherHolder(grain, type, sound);
		}

		public static void ForceSetWeather(ClientBase client, uint zone)
		{
			float grain;
			WeatherSound sound;
			WeatherType type;

			getWeatherForZone(zone, out type, out grain, out sound, true);

			ShortPacket weather = new ShortPacket(SMSG.WEATHER);
			weather.Write((int)type);
			weather.Write(grain);
			weather.Write((int)sound);
			client.Send(weather);
		}
	}
}
