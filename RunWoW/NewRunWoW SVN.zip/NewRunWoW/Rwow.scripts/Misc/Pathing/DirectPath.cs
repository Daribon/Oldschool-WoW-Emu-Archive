//
using System.Collections.Generic;
using RunServer.Common;

namespace RunWoW.Misc.Pathing
{
	public class DirectPath : BasePath
	{
		private float distance;
		private Vector m_shift;
		private float m_gap;
		private float m_strafe;

		private PooledList<Vector> m_points;
		private float m_facing;

		public DirectPath(Vector from, Vector to, float step, float gap, float strafe)
		{
			m_pos = from.Clone();
			m_gap = gap;
			m_step = step;
			m_strafe = strafe;
			if (m_gap < 0)
				m_gap = 0;
			m_points = new PooledList<Vector>();
			if (to != null)
				Recalc(to);
		}

		public override bool Recalc(Vector to)
		{
			if (m_to != null && m_to.Equals(to))
				return false; // not changed

			unchecked
			{
				m_from = m_pos.Clone();
				m_to = to.Clone();

				Vector nto = m_to;

				m_shift = (nto - m_from) / nto.Distance(m_from); // move vector

				if (m_strafe != 0f)
				{
					nto = new Vector(m_to.X - m_shift.Y * m_strafe, m_to.Y + m_shift.X * m_strafe, m_to.Z);
					m_shift = (nto - m_from) / nto.Distance(m_from); // altered move vector
				}

				Vector m_last;
				if (m_gap == 0f)
				{
					m_last = nto;
				}
				else
				{
					m_last = nto - m_shift * m_gap;
				}
				distance = m_from.Distance(m_last);
				m_steps = (int)(distance / m_step);

				m_shift *= m_step;

				m_points.Clear();
				m_points.Add(m_last);
				m_facing = m_from.Angle(m_last);
			}
			return true;
		}

		public override int Advance(int steps)
		{
			if (this.Finished)
				return 0;
			if (steps > m_steps)
				steps = m_steps;
			distance -= m_step*steps;
			m_pos = m_pos + m_shift*steps;
			m_steps -= steps;
			return steps;
		}

		public override float Distance
		{
			get { return distance; }
		}

		public override float Direction
		{
			get { return m_facing; }
		}

		public override ICollection<Vector> Path
		{
			get { return m_points; }
		}
	}
}