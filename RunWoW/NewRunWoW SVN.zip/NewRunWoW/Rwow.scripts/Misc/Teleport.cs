//
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;
using RunServer.Common;

namespace RunWoW.Misc
{
	public class Teleport
	{
		public static void TeleportTo(Vector vec, uint world, PlayerObject player)
		{
			if (!WorldBase.Worlds.Contains(world))
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error: asked to teleport player {0} to instance world {1}", player.Name, world);

				TeleportTo(vec, MapManager.GetWorldMap(world, player.MapInstanceID), player, false);
			}
			else
				TeleportTo(vec, MapManager.GetWorldMap(world, 0), player, false);
		}

		public static void TeleportTo(Vector vec, MapInstance world, PlayerObject player)
		{
			TeleportTo(vec, world, player, false);
		}

		public static void TeleportTo(Vector vec, PlayerObject player)
		{
			TeleportTo(vec, player.MapTile.Map, player, false);
		}

		public static void TeleportTo(Vector vec, MapInstance world, PlayerObject player, bool reenter)
		{
			if (player.IsDisposed)
				return;
			player.WorldChange = WCHANGESTATE.CHANGING;

			player.Position = vec;
			player.LastPos = null;

			if (player.MapTile.Map != world)
			{
				//player.Flags |= 0x4; // freeze
				//player.ForceUpdateData();

				player.WorldMapID = world.MapID;

				if (!WorldBase.Worlds.Contains(world.MapID))
					player.MapInstanceID = world.InstanceID;

				ShortPacket pkg = new ShortPacket(SMSG.TRANSFER_PENDING);
				pkg.Write(world.MapID);
				player.BackLink.Client.Send(pkg);

				pkg = new ShortPacket(SMSG.NEW_WORLD);
				pkg.Write(world.MapID);
				pkg.WriteVector(player.Position);
				pkg.Write(player.Facing);
				player.BackLink.Client.Send(pkg);
				/*pkg = new ShortPacket(SMSG.MOVE_WORLDPORT_ACK);
				pkg.Write(player.GUID);
				player.BackLink.Client.Send(pkg);*/

				player.MapTile.Map.DeleteTransports(player);
				player.MapTile.Map.Leave(player);
				player.MapTile = null;


				//player.Flags &= ~0x4; // unfreeze
				//player.ForceUpdateData();

				//MapManager.PlayerEnterWorld(player.BackLink);
				return;
			}
			else
			{
				ShortPacket pkg = new ShortPacket(SMSG.MOVE_TELEPORT);
				pkg.WriteGuid(player.GUID);
				pkg.Write(0);
				pkg.Write(0);
				pkg.WriteVector(player.Position);
				pkg.Write(player.Facing);
				player.BackLink.Client.Send(pkg);
				if (reenter)
					player.MapTile.Map.Reenter(player);
				else
					player.MapTile.Map.Move(player);
			}
			player.WorldChange = WCHANGESTATE.CHANGED;
		}

		public static void SpeedChange(LivingObject unit, float speed, SMSG code)
		{
			if (unit == null || unit.MapTile == null || unit.IsDisposed)
				return;
			ShortPacket pkg = new ShortPacket(code);
			pkg.WriteGuid(unit.GUID);
			
			if (Constants.BurningCrusade)
			switch(code)
			{
				case SMSG.FORCE_RUN_BACK_SPEED_CHANGE:
					pkg.Write(7);
					break;
				case SMSG.FORCE_RUN_SPEED_CHANGE:
					pkg.Write(6);
					break;
				case SMSG.FORCE_SWIM_SPEED_CHANGE:
					pkg.Write(8);
					break;
				default:
					pkg.Write(0);
					break;
			}
			pkg.Write(speed);
			if (unit is PlayerObject)
				((PlayerObject)unit).BackLink.Client.Send(pkg);
		}
	}
}