// TODO: add enemies factions and friends faction to DB
using System.Collections;
using RunServer.Common.Attributes;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Misc
{
	public class Faction
	{
		private static Hashtable factions = Hashtable.Synchronized(new Hashtable());

		public static bool ShouldAttackMonster(FACTION one, FACTION another)
		{
			return ShouldAttackPlayer((int) one, (int) another);
		}

		public static bool ShouldAttackMonster(int one, int another)
		{
			DBFaction One = (DBFaction) factions[one];
			DBFaction Second = (DBFaction) factions[another];
			if (One == null || Second == null)
				return false;
			if ((One.Friends & 1) == 1) // neutral
				return false;
			if ((Second.Friends & 2 ) == 2 && (One.Hostiles & 4) == 4) // attack horde
				return true;
			if ((Second.Friends & 4 ) == 4 && (One.Hostiles & 2) == 2) // attack alliance
				return true;
			if (Second.Friends == 0 && (One.Hostiles & 8) == 8) // attack monsters
				return true;

			return false;
		}

		public static bool ShouldAttackPlayer(FACTION one, FACTION another)
		{
			return ShouldAttackPlayer((int) one, (int) another);
		}

		public static bool ShouldAttackPlayer(int one, int another)
		{
			DBFaction One = (DBFaction) factions[one];
			DBFaction Second = (DBFaction) factions[another];
			if (One == null || Second == null)
				return false;
			if (One.Friends == 8) // hostile to all players
				return true;
			if (One.Friends == 1) // neutral
				return false;
			/*if (One.Friends==0) // attack all players
				return true;*/
			if (Utility.HasBit(One.Hostiles, 1)) // hostile to players
				return true;
			if (Second.Friends == 4 && (One.Hostiles & 4) == 4) // attack horde
				return true;
			if (Second.Friends == 2 && (One.Hostiles & 2) == 2) // attack alliance
				return true;
			return false;
		}

		public static bool IsHorde(FACTION one)
		{
			DBFaction One = (DBFaction) factions[(int) one];
			return One != null && One.Friends == 4;
		}

		public static bool IsAlliance(FACTION one)
		{
			DBFaction One = (DBFaction) factions[(int) one];
			return One != null && One.Friends == 2;
		}

		public static bool PVPZone(FACTION one, int zone)
		{
			DBFaction One = (DBFaction) factions[(int) one];
			return One != null && One.Friends != zone; // PVP server rule
			// return (One.Friends==2 && zone==4) || (One.Friends==4 && zone==2) // PVE server rule
		}

		public static bool NoPVPZone(FACTION one, int zone)
		{
			DBFaction One = (DBFaction) factions[(int) one];
			return One != null && One.Friends == zone;
		}

		//public static bool DifferentFaction(FACTION one, FACTION another)
		//{
		//    DBFaction One = (DBFaction) factions[(int) one];
		//    DBFaction Second = (DBFaction) factions[(int) another];
		//    return One.Friends != Second.Friends;
		//}

		public static bool SameFaction(FACTION one, FACTION another)
		{
			if (one == another)
				return true;
			DBFaction One = (DBFaction) factions[(int) one];
			DBFaction Second = (DBFaction) factions[(int) another];
			if (One == null || Second == null)
				return false;
			return One.Friends == Second.Friends;
		}

		public static bool SameFaction(ObjectBase one, ObjectBase another)
		{
			if (one == another)
				return true;

			PlayerObject pone = one as PlayerObject;
			PlayerObject panother = another as PlayerObject;

			if (pone != null && panother != null && pone.DuelArbiter != 0 && pone.DuelArbiter == panother.DuelArbiter)
				return false; // duel

			if (one is IOwnedUnit && ((IOwnedUnit)one).Owner != null)
				return SameFaction(((IOwnedUnit) one).Owner, another);

			if (another is IOwnedUnit && ((IOwnedUnit)another).Owner != null)
				return SameFaction(one, ((IOwnedUnit)another).Owner);

			return SameFaction(one.Faction, another.Faction);
		}
		/*public static bool Friendly(int one, int another)
		{
			if (factions[one].Friendly==8)
				return false;
			if (factions[one].Friendly==1)
				return true;			
			return false;
		}*/

	    public static int GetFactionReputationID(FACTION faction)
	    {
            DBFaction dbFaction = (DBFaction)factions[(int)faction];
            if (dbFaction == null)
                return -1;
            return dbFaction.Reputation;
	    }
	    
		[InitializeHandler(InitPass.Fourth)]
		public static void Initialize()
		{
			ICollection c_factions = Database.Instance.SelectAllObjects(typeof(DBFaction));
			foreach (DBFaction f in c_factions)
				factions[(int) f.ObjectId] = f;
		}
	}
}