//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Misc;
using RunWoW.ServerDatabase;

namespace RunWoW.GamePackets
{
    public class LootHolder
    {
        private DBItem m_item;
        private bool m_taken;
        private bool m_rolled;

        public DBItem Item
        {
            get { return m_item; }
            set { m_item = value; }
        }

        public bool Taken
        {
            get { return m_taken; }
            set { m_taken = value; }
        }


        public bool Rolled
        {
            get { return m_rolled; }
            set { m_rolled = value; }
        }

        public LootHolder(DBItem item)
        {
            m_item = item;
            m_taken = false;
            m_rolled = false;
        }
    }

    public enum LOOT_MODE : byte
    {
        FREE_FOR_ALL = 0x00,
        ROUND_ROBIN = 0x01,
        MASTER_LOOT = 0x02,
        GROUP_LOOT = 0x0003,
        NEED_BEFORE_GREED = 0x0004
    }

    [PacketHandlerClass()]
    public class Loot
    {
        public static int LOOT_MAX_DISTANCE = 100; // 100 yards max loot distance.

        [PacketHandler(CMSG.AUTOSTORE_LOOT_ITEM)]
        public static void OnAutostoreLoot(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;
            if (Client == null || Client.Player.LastLoot == null || !Client.Player.LastLoot.IsAlive)
                return;
            byte lootslot = data.ReadByte();

            ILootable obj = Client.Player.LastLoot.Target as ILootable;

            if (obj == null || obj.Loot == null)
                return;


            LootHolder item = obj.Loot[lootslot];

            if (item == null || item.Taken)
                return;

            if (!Client.Player.AddItem(item.Item))
                return;

            // COMMENTED: show everyone who got loot.  
            //Chat.AreaMessage(CHATMESSAGETYPE.SAY, Client.Player, "I got loot: |Hitem:" + item.Item.TemplateID + ":0:0:0|h[" + item.Item.Template.Name + "]|h", 0, 7.0f);

            //int count = item.Item.StackCount;
            //item.Item.OwnerID = Client.Player.CharacterID;
            //if (!Client.Player.Inventory.CanAddItem(item.Item))
            //{
            //    Items.SendChangeFail(client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
            //    return;
            //}
            //Client.Player.Inventory.AddItem(item.Item, true);
            //Database.Instance.AddObjectToRelations(Client.Player.Character, item);
            //Client.Player.UpdateBags();
            //Client.Player.ForceUpdateData();

            //Client.Player.Quests.CheckGather(item.Item.TemplateID, count);

            item.Taken = true;

            /// TODO: Send this to other looters
            ShortPacket pkg = new ShortPacket(SMSG.LOOT_REMOVED);
            pkg.Write(lootslot);

            pkg.Aquire();

            if (obj.Looters == null)
                client.Send(pkg);
            else
                foreach (PlayerReference player in obj.Looters)
                    if (player != null && player.IsAlive && !player.Target.IsDisposed)
                        player.Target.BackLink.Client.Send(pkg);

            pkg.Release();

            int left = 0;
            foreach (LootHolder holder in obj.Loot)
                if (holder != null && !holder.Taken)
                    left++;

            if (left == 0)
            {
                if (obj is UnitBase)
                {
                    UnitBase unit = (UnitBase)obj;
                    if (unit.Money == 0)
                    {
                        pkg = new ShortPacket(SMSG.LOOT_RELEASE_RESPONSE);
                        pkg.Write(obj.GUID);
                        pkg.Write(1);
                        client.Send(pkg);

                        //clean loot to allow skinning loot
                        unit.DynamicFlags = 0;
                        unit.Loot = null;
                        unit.Looters = null;
                        unit.AllowedLooter = 0;
                        unit.AllowedLootGroup = 0;
                    }
                }
                else if (obj is GameObject)
                {
                    Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
                    obj.Dispose();
                }
                else if (obj is ItemObject)
                {
                    if (((ItemObject)obj).ContainedIn != null)
                    {
                        ItemObject itdel = Client.Player.Inventory.FindItem(obj.GUID);
                        if (itdel != null)
                        {
                            itdel.ContainedIn.RemoveItem(itdel.DBItem.OwnerSlot, true);
                            DBManager.EraseDBObject(itdel.DBItem);
                        }
                        obj.Dispose();
                    }
                }
            }
        }

        [PacketHandler(CMSG.LOOT_MONEY)]
        public static void OnLootMoney(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;
            if (Client == null || Client.Player.LastLoot == null || !Client.Player.LastLoot.IsAlive)
                return;

            UnitBase unit = Client.Player.LastLoot.Target as UnitBase;

            if (unit != null)
            {
                // Share money in group
                if (Client.Player.Group != null)
                {
                    PooledList<PlayerObject> looters = Client.Player.Group.LivingMembers;

                    int money = (int)(unit.Money / (float)looters.Count);

                    foreach (PlayerObject plr in looters)
                    {
                        plr.Money += money;
                        plr.UpdateData();
                    }

                    ShortPacket mNotPckg = new ShortPacket(SMSG.LOOT_MONEY_NOTIFY);
                    mNotPckg.Write(money);
                    Client.Player.Group.Send(new ShortPacket(SMSG.LOOT_CLEAR_MONEY));
                    Client.Player.Group.Send(mNotPckg);
                }
                else
                    Client.Player.Money += unit.Money;

                unit.Money = 0;
                if (unit.Loot == null || unit.Loot.Count == 0)
                {
                    //clean loot to allow skinning loot
                    unit.DynamicFlags = 0;
                    unit.Loot = null;
                    unit.Looters = null;
                    unit.AllowedLooter = 0;
                    unit.AllowedLootGroup = 0;
                }

                if (Client.Player.Group == null)
                {
                    Client.Player.UpdateData();
                    client.Send(new ShortPacket(SMSG.LOOT_CLEAR_MONEY));
                }
            }
        }

        public static void DoLoot(ILootable obj, PlayerObject player)
        {
            bool allow = player.Attackable && obj.AllowLoot(player);

            /*   T�������� ������� - ������ ������ � ���� ��� ���� ������ ������� , 
             *   ������������� �����v� ����������_� � ��������� ����
             * */
            /*
            UnitBase unit = obj as UnitBase;
            if ( unit != null )
            {
                allow = false;
				
                CustomArrayList lootGuilds = new CustomArrayList();
                if (unit.AllowedLooter == 0 && unit.AllowedLootGroup == 0)
                    allow = true;
                if (unit.AllowedLooter ==  player.GUID)
                    allow = true;
                if ( player.Group != null &&  unit.AllowedLootGroup ==  player.Group.ID )
                    allow = true;
				
                if (unit.AllowedLooter != 0)
                {
                    PlayerObject looter = ClientManager.GetPlayer(unit.AllowedLooter);
                    if ( looter != null && looter.GuildID > 0 )
                    {
                        if (looter.Group != null )
                        {
                            foreach( PlayerObject plr in looter.Group.LivingMembers )
                                lootGuilds.Add(plr.GuildID);
                        } else
                            lootGuilds.Add(looter.GuildID);
                    }
                }
				
                if ( !allow && lootGuilds.Count > 0 )
                {
                    foreach (uint guildId in lootGuilds)
                    {
                        if (player.GuildID == guildId)
                        {
                            allow = true;
                            break;
                        }
                    }
                }
            }
            */

            ShortPacket pkg = new ShortPacket(SMSG.LOOT_RESPONSE);
            pkg.Write(obj.GUID);

            if (!allow)
            {
                pkg.Write(0x0);
                player.BackLink.Client.Send(pkg);
                return;
            }


            bool isMasterLoot = false;
            if (player.Group != null && player.Group.LootMode == (byte)LOOT_MODE.MASTER_LOOT)
            {
                if ((player.Group.GroupLooter != 0 && player.Group.GroupLooter == player.GUID) || (player.Group.GroupLooter == 0 && player.Group.Leader == player.GUID))
                {
                    ShortPacket pckMList = new ShortPacket(SMSG.LOOT_MASTER_LIST);
                    pckMList.Write((byte)player.Group.LivingMembers.Count);
                    foreach (PlayerObject plr in player.Group.LivingMembers)
                    {
                        pckMList.Write(plr.GUID);
                    }
                    player.BackLink.Client.Send(pckMList);
                }
                isMasterLoot = true;
            }

            if (obj.Looters == null)
                obj.Looters = new PooledList<PlayerReference>();


            bool exists = false;
            foreach (PlayerReference pref in obj.Looters)
                if (pref.GUID == player.GUID)
                {
                    exists = true;
                    break;
                }

            if (!exists)
                obj.Looters.Add(player.Reference);

            player.LastLoot = obj.Reference;

            pkg.Write((byte)(obj.Money > 0 ? 0x1 : 0x2));   //0- far away from loot,   2 - corpse loot,   3 - fish loot
            pkg.Write(obj.Money);

            if (obj.Loot == null || obj.Loot.Count == 0)
            {
                pkg.Write((byte)0);
                player.BackLink.Client.Send(pkg);
                if (obj is GameObject)
                {
                    player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
                    obj.Dispose();
                }
                return;
            }

            byte item_count = 0;
            pkg.Write(item_count);

            for (byte i = 0; i < obj.Loot.Count; i++)
            {
                LootHolder holder = obj.Loot[i];
                if (holder == null || holder.Taken)
                    continue;
                DBItem item = holder.Item;
                pkg.Write(i);
                pkg.Write(item.TemplateID);
                pkg.Write(item.StackCount);
                pkg.Write(item.Template.DisplayID);
                pkg.Write(0);
                pkg.Write(item.RandomPropertyID);
                pkg.Write((byte)(isMasterLoot ? 2 : (holder.Rolled ? 1 : 0)));
                item_count++;

                if (item_count > Constants.MaximumLoot)
                {
                    LogConsole.WriteLine(LogLevel.TRACE, "Loot object {0} has {1} items in loot!", ((ObjectBase)obj).Name,
                                         obj.Loot.Count);
                    break;
                }
            }
            pkg.Set(17, item_count);

            player.BackLink.Client.Send(pkg);
        }

        [PacketHandler(CMSG.LOOT)]
        public static void OnLoot(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;
            if (Client == null)
                return;
            ulong GUID = data.ReadUInt64();

            ObjectBase obj = Client.Player.MapTile.GetObject(GUID);
            if (obj == null)
            {
                ShortPacket w = new ShortPacket(SMSG.LOOT_RELEASE_RESPONSE);
                w.Write(GUID);
                w.Write((byte)1);
                client.Send(w);
                return;
            }

            // TODO: remove after test and call from mob kill event
            /*			if (Client.Player.Group != null && obj is LivingObject &&
                                (Client.Player.Group.LootMode == (byte)LOOT_MODE.GROUP_LOOT ||
                                    Client.Player.Group.LootMode == (byte)LOOT_MODE.NEED_BEFORE_GREED))
                            OnTargetDie(Client.Player.Group, obj as LivingObject);*/

            if (obj is ILootable)
                DoLoot((ILootable)obj, Client.Player);

            //CustomArrayList Looters = null;
            //if (obj is UnitBase)
            //{
            //    UnitBase unit = (UnitBase) obj;
            //    allow = allow && unit.Spawn != null;
            //    if (unit.AllowedLooter == Client.Player.GUID ||
            //        (unit.AllowedLooter == 0 && unit.AllowedLootGroup != 0 &&
            //         unit.AllowedLootGroup == Client.Character.GroupID))
            //        allow = allow && true;
            //    if (allow)
            //    {
            //        Loot = unit.Loot;
            //        Money = unit.Money;
            //        if (unit.Looters == null)
            //            unit.Looters = new CustomArrayList();
            //        Looters = unit.Looters;
            //    }
            //}
            //else if (obj is GameObject)
            //{
            //    GameObject go = (GameObject) obj;
            //    Loot = go.Loot;

            //    if (go.Looters == null)
            //        go.Looters = new CustomArrayList();
            //    Looters = go.Looters;

            //    //LogConsole.WriteLine(LogLevel.SYSTEM,"Show GO loot, items: "+(Loot==null?0:Loot.Count));
            //}
            //else
            //    return;

            //ShortPacket pkg = new ShortPacket(SMSG.LOOT_RESPONSE);

            //pkg.Write(GUID);

            //if (allow) // allow looting
            //    pkg.Write((byte) (Money > 0 ? 0x1 : 0x2));
            //else
            //{
            //    pkg.Write(0x0);
            //    client.Send(pkg);
            //    return;
            //}

            //Client.Player.LastLoot = GUID;
            //if (!Looters.Contains(Client.Player))
            //    Looters.Add(Client.Player);

            //pkg.Write(Money);
            //if (Loot == null || Loot.Count == 0)
            //{
            //    pkg.Write((byte) 0);
            //    client.Send(pkg);
            //    if (obj is GameObject)
            //    {
            //        Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
            //        obj.Dispose();
            //    }
            //}
            //else
            //{
            //    byte item_count = 0; // (byte)Loot.Count;

            //    pkg.Write(item_count);

            //    for (byte i = 0; i < Loot.Count; i++)
            //        if (Loot[i] != null)
            //        {
            //            if (((LootHolder) Loot[i]).Taken)
            //                continue;

            //            DBItem item = ((LootHolder) Loot[i]).Item;
            //            pkg.Write(i);
            //            pkg.Write(item.TemplateID);
            //            pkg.Write(item.StackCount);
            //            pkg.Write(item.Template.DisplayID);
            //            pkg.Write(item.Template.RandomProperties);
            //            pkg.Write(0);
            //            pkg.Write((byte) 0);
            //            item_count++;
            //        }
            //    pkg.Set(17, item_count);
            //    //				LogConsole.WriteLine(LogLevel.TRACE,"Items in loot of "+monster.Name +": "+item_count);
            //    client.Send(pkg);
            //}
        }

        [PacketHandler(CMSG.LOOT_RELEASE)]
        public static void OnLootRelease(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;

            if (Client == null || Client.Player.LastLoot == null || !Client.Player.LastLoot.IsAlive)
                return;

            ulong GUID = data.ReadUInt64();

            ObjectBase obj = Client.Player.MapTile.GetNearObject(GUID, Client.Player.Position);

            if (obj is ILootable)
            {
                if (((ILootable)obj).Looters != null)
                    foreach (PlayerReference looter in ((ILootable)obj).Looters)
                        if (looter.GUID == Client.Player.GUID)
                        {
                            ((ILootable)obj).Looters.Remove(looter);
                            break;
                        }
            }
            else
            {
                ItemObject iobj = Client.Player.Inventory.FindItem(GUID);
                if (iobj != null)
                {
                    ContainerObject container = (ContainerObject)Client.Player.Inventory.FindItem(iobj.Container);
                    if (container != null)
                    {
                        container.Inventory.DeleteItem(iobj.DBItem.OwnerSlot, true);
                        //CustomLog.WriteLine(Client.Player.Name + ": delete " + iobj.Name + " from " + container.Name + "(" + container.Template.ObjectId + ")", "Delete Container", "Logs");
                    }
                    else if (iobj.ContainedIn != null)
                    {
                        iobj.ContainedIn.DeleteItem(iobj.DBItem.OwnerSlot, true);
                        //CustomLog.WriteLine(Client.Player.Name + ": delete " + iobj.Name + " from " + Client.Player, "Delete Container", "Logs");
                    }
                }
                Client.Player.Inventory.UpdateInventory();
            }

            Client.Player.LastLoot = null;
            ShortPacket pkg = new ShortPacket(SMSG.LOOT_RELEASE_RESPONSE);
            pkg.Write(GUID);
            pkg.Write((byte)1);
            client.Send(pkg);
        }

        /** MAster loot features
         * */
        [PacketHandler(CMSG.LOOT_MASTER_GIVE)]
        public static void OnMasterLootGive(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;

            if (Client == null)
                return;
            ulong obgGUID = data.ReadUInt64();
            byte slot = data.ReadByte();
            ulong guid = data.ReadUInt64();

            ObjectBase obj = Client.Player.MapTile.GetObject(obgGUID);
            PlayerObject player = ClientManager.GetPlayer(guid);
            if (obj == null || player == null)
            {
                ShortPacket w = new ShortPacket(SMSG.LOOT_RELEASE_RESPONSE);
                w.Write(obgGUID);
                w.Write((byte)1);
                client.Send(w);
                return;
            }

            if (obj is ILootable)
            {
                if (Client.Player.Position.Distance(player.Position) < LOOT_MAX_DISTANCE)
                {
                    player.LastLoot = obj.Reference;
                    BinWriter tmp = new BinWriter();
                    tmp.Write(slot);
                    BinReader read = new BinReader(tmp);
                    OnAutostoreLoot(player.BackLink.Client, read);
                    player.LastLoot = null;
                }
                else
                {
                    // TODO: Temporrary notify , until not check how distances work on off
                    Chat.System(Client.Player.BackLink.Client, "Target player too far from you.");
                }
            }
        }

        [PacketHandler(CMSG.LOOT_METHOD)]
        public static void OnLootMethod(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;

            if (Client == null)
                return;

            int lootMode = data.ReadInt32();
            ulong toPromoteGuid = data.ReadUInt64();
            byte lootTresh = data.ReadByte();

            if (Client.Player.Group != null && Client.Player.Group.Leader == Client.Player.GUID)
            {
                Client.Player.Group.LootMode = (byte)lootMode;
                Client.Player.Group.LootTresh = (byte)lootTresh;
                if (toPromoteGuid != 0)
                    Client.Player.Group.GroupLooter = toPromoteGuid;
                Client.Player.Group.Update();
            }
        }

        [PacketHandler(CMSG.LOOT_ROLL)]
        public static void OnLootRoll(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;

            if (Client == null)
                return;

            ulong GUID = data.ReadUInt64();
            int rollID = data.ReadInt32();  // rollID
            byte type = data.ReadByte();  //  0 - pass, 1 - neeed . 2 - greed

            RollLoot rloot = (RollLoot)RollLoot.m_pRollLoots[rollID];
            if (rloot != null)
            {
                foreach (PlayerObject member in Client.Player.Group.LivingMembers)
                {
                    ShortPacket pckg = new ShortPacket(SMSG.LOOT_ROLL);
                    pckg.Write(member.GUID);
                    pckg.Write(1);
                    pckg.Write(Client.Player.GUID);
                    pckg.Write(rloot.Holder.Item.TemplateID);
                    pckg.Write(0);
                    pckg.Write(0);
                    pckg.Write(type == 1 ? (byte)0 : (byte)249);
                    pckg.Write(type == 1 ? (byte)0 : type);
                    member.BackLink.Client.Send(pckg);
                }

                rloot.HaveChoise(GUID, type);
            }



        }

        [PacketHandler(CMSG.RANDOM_ROLL)]
        public static void OnLootRandomRoll(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;

            if (Client == null || Client.Player.LastLoot == null || !Client.Player.LastLoot.IsAlive)
                return;

            //ulong GUID = data.ReadUInt64();
        }

        // ---------------------------------------------------------------------------------------



        public static void DoOpenLoot(ObjectBase caster, ObjectBase target, DBSpell spell)
        {
            if (caster is PlayerObject && target is ILootable)
            {
                OpenLoot loot = new OpenLoot((PlayerObject)caster, (ILootable)target, 1000);
                loot.Start();
            }
        }


        /**  Should be call when lootable creature die.
         * */
        public static void OnTargetDie(Group group, LivingObject target)
        {
            UnitBase unit = target as UnitBase;

            if (unit == null || group == null)
                return;

            if (unit.Loot == null || unit.Loot.Count == 0)
                return;

            if (group.LootMode != (byte)LOOT_MODE.GROUP_LOOT && group.LootMode != (byte)LOOT_MODE.NEED_BEFORE_GREED)
                return;

            // define items wich will be rolled.
            for (byte i = 0; i < unit.Loot.Count; i++)
            {
                LootHolder holder = unit.Loot[i];
                if (holder == null || holder.Taken)
                    continue;

                if (holder.Item.Template.OverallQuality >= group.LootTresh && RollLoot.m_pRollPerHolder[holder] == null /*UGLY*/ )
                {
                    holder.Rolled = true;
                    RollLoot rollEvt = new RollLoot(group, unit.Position, unit.MapTile.Map.MapID, holder, i);
                    rollEvt.Start();
                }
            }
        }



        public class RollLoot : Event
        {
            public static int m_lastRollID = 1;
            public static Hashtable m_pRollLoots = new Hashtable();

            // UGLY:  ������������ ��� �������� - �v� �� ��� ���v��v� ������� ������.
            public static Hashtable m_pRollPerHolder = new Hashtable();

            private int m_rollID;
            private int m_slotNum;
            private LootHolder m_holder;
            private Dictionary<ulong, int> m_rollers = new Dictionary<ulong, int>();
            private Group m_group;

            private uint m_worldId;


            public LootHolder Holder
            {
                get { return m_holder; }
            }

            public int Slot
            {
                get { return m_slotNum; }
            }

            // check if all rollers done choise
            public bool IsRollDone()
            {
                foreach (int value in m_rollers.Values)
                    if (value == -1)
                        return false;

                return true;
            }


            public RollLoot(Group group, Vector position, uint worldId, LootHolder hld, int slot)
                : base(TimeSpan.FromMinutes(1))
            {
                m_group = group;
                m_holder = hld;
                m_slotNum = slot;
                m_worldId = worldId;

                // UGLY: 
                m_pRollPerHolder.Add(hld, this);

                PooledList<PlayerObject> rollMembers = new PooledList<PlayerObject>();
                DBItemTemplate item = hld.Item.Template;
                foreach (PlayerObject member in m_group.LivingMembers)
                    if (member.MapTile.Map.MapID == m_worldId && position.Distance(member.Position) < LOOT_MAX_DISTANCE)
                    {
                        // Check for usble items
                        if (m_group.LootMode == (byte)LOOT_MODE.NEED_BEFORE_GREED)
                        {
                            if (member.Level >= item.ReqLevel &&
                                ((int)member.Class & item.AllowableClass) == (int)member.Class &&
                                ((int)member.Race & item.AllowableRace) == (int)member.Race)
                                rollMembers.Add(member);
                        }
                        else
                            rollMembers.Add(member);
                    }

                if (rollMembers.Count == 0)
                    rollMembers = m_group.LivingMembers;

                //  send roll invite to each player in group
                foreach (PlayerObject member in rollMembers)
                    if (member.MapTile.Map.MapID == m_worldId && position.Distance(member.Position) < LOOT_MAX_DISTANCE)
                    {
                        ShortPacket lootPckg = new ShortPacket(SMSG.LOOT_START_ROLL);
                        lootPckg.Write(member.GUID);
                        lootPckg.Write(m_lastRollID); //   roll unique ID
                        lootPckg.Write(m_holder.Item.TemplateID); // Item Template ID
                        lootPckg.Write(0); // X3
                        lootPckg.Write(m_holder.Item.RandomPropertyID); // Random Properties ID
                        lootPckg.Write(60000); // Roll Time
                        member.BackLink.Client.Send(lootPckg);
                        m_rollers[member.GUID] = -1; // -1 - not rolled, 0 - pass, 1 - need , 2 - greed 
                    }

                m_rollID = m_lastRollID;
                m_lastRollID++;
                m_pRollLoots[m_rollID] = this;
            }

            protected override void OnTick()
            {
            }

            protected override void OnFinish()
            {
                //  Check if player didnt roll within 60 sec, and mark it as passed rolling.
                Roll();
            }

            public void Roll()
            {
                ulong winnerGuid = 0;
                int rollDice = 0;

                //  roll need 
                foreach (KeyValuePair<ulong, int> pair in m_rollers)
                    if (pair.Value == 1)
                        foreach (PlayerObject plr in m_group.LivingMembers)
                        {
                            byte dice = (byte)Utility.Random(1, 100);
                            winnerGuid = dice > rollDice ? pair.Key : winnerGuid;
                            rollDice = dice > rollDice ? dice : rollDice;

                            ShortPacket pckg = new ShortPacket(SMSG.LOOT_ROLL);
                            pckg.Write(plr.GUID);
                            pckg.Write(m_rollID);
                            pckg.Write(pair.Key);
                            pckg.Write(m_holder.Item.TemplateID);
                            pckg.Write(0);
                            pckg.Write(m_holder.Item.RandomPropertyID);
                            pckg.Write(dice);
                            pckg.Write((byte)1); // need
                            plr.BackLink.Client.Send(pckg);
                        }

                //  have no players who NEED that item, then roll greed.
                if (winnerGuid == 0)
                    foreach (KeyValuePair<ulong, int> pair in m_rollers)
                        if (pair.Value == 2)
                            foreach (PlayerObject plr in m_group.LivingMembers)
                            {
                                byte dice = (byte)Utility.Random(1, 100);
                                winnerGuid = dice > rollDice ? pair.Key : winnerGuid;
                                rollDice = dice > rollDice ? dice : rollDice;

                                ShortPacket pckg = new ShortPacket(SMSG.LOOT_ROLL);
                                pckg.Write(plr.GUID);
                                pckg.Write(m_rollID);
                                pckg.Write(pair.Key);
                                pckg.Write(m_holder.Item.TemplateID);
                                pckg.Write(0);
                                pckg.Write(m_holder.Item.RandomPropertyID);
                                pckg.Write(dice);
                                pckg.Write((byte)2); // greed
                                plr.BackLink.Client.Send(pckg);
                            }

                // Send winner 

                if (winnerGuid != 0)
                {
                    foreach (PlayerObject plr in m_group.LivingMembers)
                    {
                        ShortPacket pckg = new ShortPacket(SMSG.LOOT_ROLL_WON);
                        pckg.Write(plr.GUID);
                        pckg.Write(m_rollID);
                        pckg.Write(m_holder.Item.TemplateID);
                        pckg.Write(0);
                        pckg.Write(m_holder.Item.RandomPropertyID);
                        pckg.Write(winnerGuid);
                        pckg.Write((byte)rollDice);
                        pckg.Write((byte)1); // win
                        plr.BackLink.Client.Send(pckg);
                    }

                    PlayerObject winner = ClientManager.GetPlayer(winnerGuid);
                    if (winner != null)
                    {
                        if (!m_holder.Taken && winner.AddItem(m_holder.Item))
                            m_holder.Taken = true;

                        ShortPacket pkg = new ShortPacket(SMSG.LOOT_REMOVED);
                        pkg.Write(Slot);

                        pkg.Aquire();
                        foreach (PlayerObject plr in m_group.LivingMembers)
                            if (plr != null && !plr.IsDisposed)
                                plr.BackLink.Client.Send(pkg);
                        pkg.Release();

                    }
                }
                else
                {
                    foreach (PlayerObject plr in m_group.LivingMembers)
                    {
                        ShortPacket pckg = new ShortPacket(SMSG.LOOT_ALL_PASSED);
                        pckg.Write(plr.GUID);
                        pckg.Write(m_rollID);
                        pckg.Write(m_holder.Item.TemplateID);
                        pckg.Write(0);
                        pckg.Write(m_holder.Item.RandomPropertyID);
                        plr.BackLink.Client.Send(pckg);
                    }
                    m_holder.Rolled = false;
                }

                //UGLY:
                m_pRollPerHolder.Remove(this);

            }

            internal void HaveChoise(ulong GUID, byte type)
            {
                m_rollers[GUID] = (int)type;
                if (IsRollDone())
                    Finish();
            }
        }


        public class OpenLoot : Event
        {
            private PlayerObject m_player;
            private ILootable m_target;

            public OpenLoot(PlayerObject player, ILootable target, int time)
                : base(TimeSpan.FromMilliseconds(time))
            {
                m_player = player;
                m_target = target;
            }

            protected override void OnTick()
            {
                if (m_player != null && !m_player.IsDisposed)
                    DoLoot(m_target, m_player);
            }
        }


    }
}