//
using System;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class Pet
	{
		[PacketHandler(CMSG.PET_ACTION)]
		public static void OnPetAction(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.Pet == null || Client.Player.Pet.Dead)
				return;
			/*ulong GUID=*/
			data.ReadUInt64();
			ushort flags = data.ReadUInt16();
			ushort flags2 = data.ReadUInt16();
			//LogConsole.WriteLine(LogLevel.SYSTEM, "Got pet command: " + flags + ", group: " + flags2);

			PetBase pet = Client.Player.Pet;
			switch (flags2)
			{
				case 0x700: // command
					switch (flags)
					{
						case 0: // stay
							pet.Stay();
							break;
						case 1: // follow
							pet.Follow();
							break;
						case 2: // attack
							if (Client.Player.Selection as LivingObject != null)
							{
								ShortPacket pkg = new ShortPacket(SMSG.AI_REACTION);
								pkg.Write(pet.GUID);
								pkg.Write(2);
								pet.MapTile.SendSurrounding(pkg, pet);
								pet.Attack((LivingObject) Client.Player.Selection);
							}
							break;
						case 3: // dismiss
							pet.Die();
							pet.Dispose();
							break;
						default:
							LogConsole.WriteLine(LogLevel.SYSTEM, "Unknown pet command: " + flags + ", group: " + flags2);
							break;
					}
					break;
				case 0x600: // behaivor
					switch (flags)
					{
						case 0: // passive
							pet.Passive();
							break;
						case 1: // defensive
							pet.Defensive();
							break;
						case 2: // aggressive
							pet.Aggressive();
							break;
						default:
							LogConsole.WriteLine(LogLevel.SYSTEM, "Unknown pet command: " + flags + ", group: " + flags2);
							break;
					}
					break;
				case 0x100: // cast
				case 0x4100: //cast
					if (pet.Creature.ObjectId == 4277)
						return;

					ushort spellId = flags;
					DBPetSpell mSpell = null;
					foreach(DBPetSpell spell in pet.DBPet.Spells)
						if (spell.SpellID == spellId)
						{
							mSpell = spell;
							break;
						}
					
					if (mSpell == null)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Casting unknown pet spell " + spellId);
						return;
					}
					DBSpell Spell = mSpell.Spell;
					if (mSpell.Cooldown > CustomDateTime.Now)
					{
						SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NOT_READY);
						return;
					}
					if (pet.Power < Spell.PowerCost)
					{
						SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_NO_POWER);
						return;
					}
					if (pet.Silenced)
					{
						SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_SILENCED);
						return;
					}

					if (pet.Stunned)
					{
						SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_STUNNED);
						return;
					}

					if (pet.NoControl)
					{
						SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_CONFUSED);
						return;
					}
					
					ObjectBase target = Client.Player.Selection;
					if (target == null)
						target = pet;

					if (spellId == 1604) // dazed
					{
						target = Client.Player;
						Client.Player.Health = 1;
					}
					
					
					if ((target is LivingObject) && Spell.CreatureType != 0)
					{
						int ctype = target is UnitBase ? 1 << (((UnitBase)target).CreatureType - 1) : 64;
						if ((Spell.CreatureType & ctype) != ctype)
						{
							SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_BAD_TARGETS);
							return;
						}
					}
					if (pet.Position.DistanceSqrd(target.Position) > Spell.MaxRange*Spell.MaxRange)
					{
						SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_OUT_OF_RANGE);
						return;
					}
					if (pet.Level < Spell.PlayerLevel && Spell.PlayerLevel <= 60)
					{
						SpellCastEvent.SpellCastResult(client, spellId, SpellFailedReason.SPELL_FAILED_LOW_CASTLEVEL);
						return;
					}
					
					int cooldown = Client.Player.SpellProcessor.Cooldown(Spell);
					if (cooldown <= 0)
						cooldown = 1000;
					mSpell.Cooldown = CustomDateTime.Now + TimeSpan.FromMilliseconds(cooldown);

					LogConsole.WriteLine(LogLevel.SYSTEM, "Casting pet spell " + spellId);

					pet.Power -= Spell.PowerCost;
					SpellCastEvent cast = new SingleTargetCast(pet, Spell, 0x02, target, false);
					cast.Start();

					ShortPacket cpkg = new ShortPacket(SMSG.COOLDOWN_EVENT);
					cpkg.Write((int) Spell.ObjectId);
					cpkg.Write(pet.GUID);
					client.Send(cpkg);
					break;
				default:
					LogConsole.WriteLine(LogLevel.SYSTEM, "Unknown pet command group: " + flags2 + ", command: " + flags);
					break;
			}
		}
	}
}