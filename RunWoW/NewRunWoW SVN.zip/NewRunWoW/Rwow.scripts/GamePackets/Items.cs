//
using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Inventory;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class Items
	{
		[PacketHandler(CMSG.DESTROYITEM)]
		public static void HandleDestroyItem(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;

			byte destbag = data.ReadByte();
			byte destslot = data.ReadByte();
			BaseInventory destinv = Client.Player.Inventory.GetSubContainer(destbag);
			destinv.DeleteItem(destslot, true);
			Client.Player.Save();
		}

		public static void SendChangeFail(ClientBase client, ItemObject src, ItemObject dest, BagResponseUpdateFields code)
		{
			ShortPacket pkg = new ShortPacket(SMSG.INVENTORY_CHANGE_FAILURE);
			pkg.Write((byte) code);
			pkg.Write((src != null ? src.GUID : 0));
			pkg.Write((dest != null ? dest.GUID : 0));
			pkg.Write((byte) 0);
			client.Send(pkg);
		}

		public static void SendChangeFail(ClientBase client, int param, ItemObject src, ItemObject dest, BagResponseUpdateFields code)
		{
			ShortPacket pkg = new ShortPacket(SMSG.INVENTORY_CHANGE_FAILURE);
			pkg.Write((byte) code);
			pkg.Write(param);
			pkg.Write((src != null ? src.GUID : 0));
			pkg.Write((dest != null ? dest.GUID : 0));
			pkg.Write((byte) 0);
			client.Send(pkg);
		}

		public static INVSLOT GetInventorySlot(DBItemTemplate it)
		{
			INVSLOT result = INVSLOT.BACKPACK_FIRST;
			switch (it.InvType)
			{
				case INVTYPE.BODY:
					result = INVSLOT.BODY;
					break;
				case INVTYPE.ROBE:
				case INVTYPE.CHEST:
					result = INVSLOT.CHEST;
					break;
				case INVTYPE.CLOAK:
					result = INVSLOT.BACK;
					break;
				case INVTYPE.FEET:
					result = INVSLOT.FEET;
					break;
				case INVTYPE.FINGER:
					result = INVSLOT.FINGER1;
					break;
				case INVTYPE.HAND:
					result = INVSLOT.HAND;
					break;
				case INVTYPE.HEAD:
					result = INVSLOT.HEAD;
					break;
				case INVTYPE.HOLDABLE:
					result = INVSLOT.OFFHAND;
					break;
				case INVTYPE.LEGS:
					result = INVSLOT.LEGS;
					break;
				case INVTYPE.NECK:
					result = INVSLOT.NECK;
					break;
				case INVTYPE.RANGED:
				case INVTYPE.THROWN:
				case INVTYPE.RANGEDRIGHT:
					result = INVSLOT.RANGED;
					break;
				case INVTYPE.SHIELD:
					result = INVSLOT.OFFHAND;
					break;
				case INVTYPE.TABARD:
					result = INVSLOT.TABARD;
					break;
				case INVTYPE.SHOULDER:
					result = INVSLOT.SHOULDER;
					break;
				case INVTYPE.TRINKET:
					result = INVSLOT.TRINKET1;
					break;
				case INVTYPE.WAIST:
					result = INVSLOT.WAIST;
					break;
				case INVTYPE.WRIST:
					result = INVSLOT.WRIST;
					break;
				default:
					switch (it.Class)
					{
						case ITEMCLASS.ARMOUR:
							if (it.ArmourSubClass == ARMOURSUBCLASS.SHIELD)
								result = INVSLOT.OFFHAND;
							break;
						case ITEMCLASS.WEAPON:
							switch (it.WeaponSubClass)
							{
								case WEAPONSUBCLASS.BOW:
								case WEAPONSUBCLASS.GUN:
								case WEAPONSUBCLASS.CROSSBOW:
								case WEAPONSUBCLASS.THROWN:
								case WEAPONSUBCLASS.WAND:
									result = INVSLOT.RANGED;
									break;
								case WEAPONSUBCLASS.DAGGER:	
									result = INVSLOT.OFFHAND;
									break;
								default:
									result = INVSLOT.MAINHAND;
									break;
							}
							break;
						case ITEMCLASS.QUIVER:
						case ITEMCLASS.CONTAINER:
							result = INVSLOT.BAGFIRST;
							break;
					}
					break;
			}
			return result;
		}

		private static void ProcessSwap(ClientBase client, INVSLOT srcslot, INVSLOT destslot)
		{
			ClientData Client = (ClientData) client.Data;

			ItemObject srcitem, destitem = null;
			srcitem = Client.Player.Inventory[srcslot];

			if (destslot != INVSLOT.MAX)
				destitem = Client.Player.Inventory[destslot];

			/*LogConsole.WriteLine(LogLevel.ECHO, "Equipping item " + srcitem == null
			                     	? "(null)"
			                     	:
			                     srcitem.Template.Name + " from slot " + srcslot + ", type: " + srcitem.Template.InvType +
			                     " to slot " + destslot);*/

			//Chat.System(client,"Equipping item "+srcitem==null?"(null)":srcitem.Template.Name+" from slot "+srcslot+", type: "+srcitem.Template.InvType+" to slot "+destslot);


			if (srcslot == destslot || srcitem == null || srcslot >= INVSLOT.MAX || destslot >= INVSLOT.MAX)
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_ERROR);
				return;
			}

			bool redress = false;

			if (srcslot <= INVSLOT.EQUIPPEDLAST)
			{
				if (destitem != null)
				{
					ItemObject tmpitem = srcitem;
					INVSLOT tmpslot = srcslot;
					srcitem = destitem;
					srcslot = destslot;
					destitem = tmpitem;
					destslot = tmpslot;
				} // Swap items if disequipping
				redress = true;
			}

			int itemAllowableClass = srcitem.DBItem.Template.AllowableClass;
			int itemAllowableRace = srcitem.DBItem.Template.AllowableRace;

			if (Constants.BurningCrusade && itemAllowableRace == 511)
				itemAllowableRace = 2047;
			
			int itemAllowableLvl = srcitem.DBItem.Template.ReqLevel;
			int charClass = 1 << ((int) Client.Player.Class - 1);
			int charRace = 1 << ((int) Client.Player.Race - 1);

			if (destslot <= INVSLOT.EQUIPPEDLAST)
			{
				redress = true;
				if (srcitem.Template.InvType == INVTYPE.NONE_EQUIP)
				{
					//Chat.System(client,"InvType = INVTYPE.NONE_EQUIP");
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EQUIPPABLE);
					return;
				}
				if (Client.Player.Level < itemAllowableLvl)
				{
					SendChangeFail(client, itemAllowableLvl, srcitem, destitem, BagResponseUpdateFields.BAG_LEVEL_MISMATCH);
					return;
				}
				if ((itemAllowableClass & charClass) != charClass)
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_CLASS_NOTALLOWED);
					return;
				}
				if ((itemAllowableRace & charRace) != charRace)
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_RACE_NOTALLOWED);
					return;
				}
				if (srcitem.Template.Rank != 0 && (srcitem.Template.Rank > Client.Player.PVPRank || Constants.BurningCrusade)) // TODO: allow honor items
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EQUIPPABLE);
					return;
				}
				if (srcitem.Template.Reputation > 0 || srcitem.Template.ReputationRank > 0 || srcitem.Template.CityRank > 0) // TODO: allow reputation items
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EQUIPPABLE);
					return;
				}

				if ((srcitem.DBItem.Template.Class == ITEMCLASS.WEAPON &&
				     srcitem.DBItem.Template.WeaponSubClass != WEAPONSUBCLASS.GENERIC) ||
				    (srcitem.DBItem.Template.Class == ITEMCLASS.ARMOUR &&
				     srcitem.DBItem.Template.ArmourSubClass != ARMOURSUBCLASS.GENERIC)
					)
				{
					PlayerSkill skill = Client.Player.Skills.SkillForItem(srcitem);
					if (skill == null)
					{
						SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_PROFICIENCY_NEEDED);
						return;
					}

					if (srcitem.Template.MinReqSkill != 0 && skill.Level < srcitem.Template.MinReqSkill)
					{
						SendChangeFail(client, skill.Level, srcitem, destitem, BagResponseUpdateFields.BAG_PROFICIENCY_NEEDED); /// TODO: skill level
						return;
					}
				}
				if (destitem != null)
					if (GetInventorySlot(srcitem.DBItem.Template) != GetInventorySlot(destitem.DBItem.Template))
					{
						SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_CANT_SWAP);
						return;
					}
			}
			if (
				((destslot >= INVSLOT.BAGFIRST) && (destslot <= INVSLOT.BAGLAST)) ||
				((destslot >= INVSLOT.BANKBAG_FIRST) && (destslot <= INVSLOT.BANKBAG_LAST))
				) //bag from backpack to slot
			{
				if (!(srcitem is ContainerObject))
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_A_CONTAINER);
					return;
				}
				else if (srcitem.Template.Class == ITEMCLASS.QUIVER)
					for (INVSLOT j = INVSLOT.BAGFIRST; j <= INVSLOT.BAGLAST; j++)
						if
							(
							j != destslot &&
							Client.Player.Inventory[j] != null &&
							Client.Player.Inventory[j].Template.Class == ITEMCLASS.QUIVER &&
							Client.Player.Inventory[j].Template.QuiverSubClass == srcitem.Template.QuiverSubClass
							)
							switch (srcitem.Template.QuiverSubClass)
							{
								case QUIVERSUBCLASS.AMMO:
									SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_ONLY_ONE_AMMO);
									return;
								case QUIVERSUBCLASS.BOLTS:
									SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_ONLY_ONE_BOLT);
									return;
								case QUIVERSUBCLASS.ARROWS:
								default:
									SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_ONLY_ONE_QUIVER);
									return;
							}
				if (destitem is ContainerObject && ((ContainerObject)destitem).Inventory.ItemCount > 0)
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EMPTY);
					return;
				}
				if (destslot >= INVSLOT.BANKBAG_FIRST && (int) destslot - (int) INVSLOT.BANKBAG_FIRST >= Client.Player.NumBankSlots)
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOBANKSLOT);
					return;
				}
			}
			if (
				((srcslot >= INVSLOT.BAGFIRST) && (srcslot <= INVSLOT.BAGLAST)) ||
				((srcslot >= INVSLOT.BANKBAG_FIRST) && (srcslot <= INVSLOT.BANKBAG_LAST))
				) //bag from slot to backpack
			{
				if (destitem != null)
				{
					if (!(destitem is ContainerObject))
					{
						SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_A_CONTAINER);
						return;
					}
					else if (destitem.Template.Class == ITEMCLASS.QUIVER)
						for (INVSLOT j = INVSLOT.BAGFIRST; j <= INVSLOT.BAGLAST; j++)
							if
								(
								j != srcslot &&
								Client.Player.Inventory[j] != null &&
								Client.Player.Inventory[j].Template.Class == ITEMCLASS.QUIVER &&
								Client.Player.Inventory[j].Template.QuiverSubClass == destitem.Template.QuiverSubClass
								)
								switch (destitem.Template.QuiverSubClass)
								{
									case QUIVERSUBCLASS.AMMO:
										SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_ONLY_ONE_AMMO);
										return;
									case QUIVERSUBCLASS.BOLTS:
										SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_ONLY_ONE_BOLT);
										return;
									case QUIVERSUBCLASS.ARROWS:
									default:
										SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_ONLY_ONE_QUIVER);
										return;
								}
				}
				if (srcitem is ContainerObject && ((ContainerObject)srcitem).Inventory.ItemCount > 0)
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EMPTY);
					return;
				}
			}
			if (destslot >= INVSLOT.BACKPACK_FIRST)
			{
				if ((srcitem is ContainerObject) && ((ContainerObject)srcitem).Inventory.ItemCount > 0)
				{
					SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EMPTY);
					return;
				}
			}

			switch (destslot)
			{
				case INVSLOT.OFFHAND:
					redress = true;

					if
						(
						srcitem.Template.InvType != INVTYPE.WEAPONOFFHAND &&
						srcitem.Template.InvType != INVTYPE.WEAPON &&
						srcitem.Template.InvType != INVTYPE.HOLDABLE &&
						srcitem.Template.InvType != INVTYPE.SHIELD
						)
					{
						//Chat.System(client,"Can't use it in second hand");
						SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_SLOT_MISMATCH);
						return;
					}
					if (Client.Player.Inventory[INVSLOT.MAINHAND] != null)
						if (Client.Player.Inventory[INVSLOT.MAINHAND].Template.InvType == INVTYPE.TWOHANDEDWEAPON)
						{
							SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_2HWEAPONBEINGWIELDED);
							return;
						}
						else if (srcitem.Template.InvType != INVTYPE.SHIELD && srcitem.Template.InvType != INVTYPE.HOLDABLE &&
						         Client.Player.Spells[SPELLSKILL.DUALWIELD] == null)
						{
							SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_2HWEAPON_SKILLNOTFOUND);
							return;
						}
					break;
				case INVSLOT.MAINHAND:
					redress = true;

					if (Client.Player.Inventory[INVSLOT.OFFHAND] != null)
					{
						if (srcitem.Template.InvType == INVTYPE.TWOHANDEDWEAPON)
						{
							SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_2HWEAPON_ITEMEXISTSINOFFHAND);
							return;
						}
						if
							(
								(
									Client.Player.Inventory[INVSLOT.OFFHAND].Template.InvType == INVTYPE.WEAPONOFFHAND ||
									Client.Player.Inventory[INVSLOT.OFFHAND].Template.InvType == INVTYPE.WEAPON
								)
								&& Client.Player.Spells[SPELLSKILL.DUALWIELD] == null
							)
						{
							SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_2HWEAPON_SKILLNOTFOUND);
							return;
						}
					}
					break;
			}

			Client.Player.Inventory.SwapItems((byte) srcslot, (byte) destslot, true);

			if (redress)
			{
				Console.WriteLine("REDRESS!!!");
				Client.Player.UnequipItems();
				Client.Player.EquipItems();
				Client.Player.Redress();
			}

			Client.Player.UpdateBags();

			if (redress)
				Client.Player.ForceUpdateData();
		}

		[PacketHandler(CMSG.SWAP_INV_ITEM)]
		public static void HandleSwapItem(ClientBase client, BinReader data, int msgID)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;

			INVSLOT srcslot = (INVSLOT) data.ReadByte();
			INVSLOT destslot = (INVSLOT) data.ReadByte();
			if (srcslot != destslot)
				ProcessSwap(client, srcslot, destslot);
		}

		[PacketHandler(CMSG.AUTOEQUIP_ITEM)]
		public static void HandleAutoEquipItem(ClientBase client, BinReader data, int msgID)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;

			byte srcbag = data.ReadByte();
			INVSLOT destslot = (INVSLOT) data.ReadByte();
			INVSLOT srcslot = destslot;
			BaseInventory srcinv = Client.Player.Inventory.GetSubContainer(srcbag);
			if (srcinv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown src bag " + srcbag);
				return;
			}
			ItemObject srcitem = srcinv[srcslot];
			if (srcinv != Client.Player.Inventory)
			{
				SendChangeFail(client, srcitem, null, BagResponseUpdateFields.BAG_ERROR);
				Chat.System(client, "You cant equip item from additiional bags yet.");
				return;
			}
			if (srcitem != null)
				destslot = GetInventorySlot(srcitem.Template);
			else
				return;
			
			bool invalid = false;
			switch (destslot)
			{
				case INVSLOT.BAGFIRST:
					for (; destslot <= INVSLOT.BAGLAST; destslot++)
						if (Client.Player.Inventory[destslot] == null)
							break;
					invalid = destslot > INVSLOT.BAGLAST;
					break;
				case INVSLOT.FINGER1:
					for (; destslot <= INVSLOT.FINGER2; destslot++)
						if (Client.Player.Inventory[destslot] == null)
							break;
					invalid = destslot > INVSLOT.FINGER2;
					break;
				case INVSLOT.TRINKET1:
					for (; destslot <= INVSLOT.TRINKET2; destslot++)
						if (Client.Player.Inventory[destslot] == null)
							break;
					invalid = destslot > INVSLOT.TRINKET2;
					break;
			}
			
			if (invalid)
				SendChangeFail(client, srcitem, null, BagResponseUpdateFields.BAG_NO_SLOTS_AVAILABLE);
			else
				ProcessSwap(client, srcslot, destslot);
		}

		[PacketHandler(CMSG.AUTOSTORE_BAG_ITEM)]
		public static void HandleAutostore(ClientBase client, BinReader data, int msgID)
		{
			ClientData Client = (ClientData) client.Data;
			byte srcbag = data.ReadByte();
			INVSLOT srcslot = (INVSLOT) data.ReadByte();
			INVSLOT destslot = (INVSLOT) data.ReadByte();
			BaseInventory srcinv = Client.Player.Inventory.GetSubContainer(srcbag);
			if (srcinv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown src bag " + srcbag);
				return;
			}
			ItemObject srcitem = srcinv[srcslot];
			ItemObject destitem = Client.Player.Inventory[destslot];
			if ((destslot < INVSLOT.BAGFIRST) || (destslot > INVSLOT.BAGLAST))
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_A_CONTAINER);
				return;
			}
			if (srcitem == null || destitem == null || !(destitem is ContainerObject))
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_A_CONTAINER);
				return;
			}
			ContainerObject cont = destitem as ContainerObject;
			if (cont == null)
				return;
			
			if (!cont.Inventory.AcceptItem(srcitem.DBItem))
			{
				SendChangeFail(client, srcitem, null, BagResponseUpdateFields.BAG_AMMO_ONLY);
				return;
			}
			
			if (cont.Inventory.CanAddItem(srcitem.DBItem))
			{
				ItemObject added = cont.Inventory.AddItem(srcitem.DBItem, false);
				srcinv.RemoveItem((int)srcslot, true);
				cont.Inventory.SendCreate(added);
				cont.UpdateData();
				//Client.Player.ForceUpdateData();
                Client.Player.UpdateBags();
            }
			else
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_FULL);
			}
		}

		[PacketHandler(CMSG.SPLIT_ITEM)]
		public static void HandleSplit(ClientBase client, BinReader data, int msgID)
		{
			ClientData Client = (ClientData) client.Data;
			byte srcbag = data.ReadByte();
			INVSLOT srcslot = (INVSLOT) data.ReadByte();
			byte destbag = data.ReadByte();
			INVSLOT destslot = (INVSLOT) data.ReadByte();
			byte count = data.ReadByte();

			if (count == 0)
				return;

			//LogConsole.WriteLine(LogLevel.SYSTEM,"Received split for "+srcslot+" to "+destslot+", count: "+count);
			BaseInventory srcinv = Client.Player.Inventory.GetSubContainer(srcbag);
			if (srcinv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown src bag " + srcbag);
				return;
			}
			BaseInventory destinv = Client.Player.Inventory.GetSubContainer(destbag);
			if (destinv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown dest bag " + destbag);
				return;
			}
			ItemObject srcitem = srcinv[srcslot];
			if (!destinv.AcceptItem(srcitem.DBItem))
			{
				SendChangeFail(client, srcitem, null, BagResponseUpdateFields.BAG_AMMO_ONLY);
				return;
			}
			if (srcitem.StackCount <= count)
			{
				SendChangeFail(client, srcitem, null, BagResponseUpdateFields.BAG_ITEM_TOO_FEW_TO_SPLIT);
				return;
			}
			if (destinv[destslot] != null)
			{
				if (destinv[destslot].Entry != srcitem.Entry || destinv[destslot].StackCount + count > srcitem.Template.MaxStack)
				{
					SendChangeFail(client, srcitem, destinv[destslot], BagResponseUpdateFields.BAG_ITEM_SPLIT_FAILED);
					return;
				}
				destinv[destslot].StackCount += count;
				destinv.UpdateItem((byte) destslot, true);
			}
			else
			{
				DBItem item = new DBItem(srcitem.Template);
				item.OwnerID = Client.Player.CharacterID;
				item.StackCount = count;
				DBManager.NewDBObject(item);
				Client.Player.Character.Items.Add(item);
			    
			    if ((byte)destslot == 255)
                    destinv.AddNewItem(item, true);
			    else
                    destinv.AddNewItem(item, true, (byte)destslot);
			}
			srcitem.StackCount -= count;
			srcinv.UpdateItem((byte) srcslot, true);
			Client.Player.ForceUpdateData();
            //Client.Player.UpdateBags();
        }

		[PacketHandler(CMSG.SWAP_ITEM)]
		public static void HandleSwap(ClientBase client, BinReader data, int msgID)
		{
			ClientData Client = (ClientData) client.Data;
			byte destbag = data.ReadByte();
			byte destslot = data.ReadByte();
			byte srcbag = data.ReadByte();
			byte srcslot = data.ReadByte();
			//ProcessSwap(client,(INVSLOT)((srcbag==255?0:(srcbag*20+100))+srcslot),(INVSLOT)((destbag==255?0:(destbag*20+100))+destslot));

			BaseInventory srcinv = Client.Player.Inventory.GetSubContainer(srcbag);
			if (srcinv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown src bag " + srcbag);
				return;
			}
			BaseInventory destinv = Client.Player.Inventory.GetSubContainer(destbag);
			if (destinv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown dest bag " + destbag);
				return;
			}

			bool redress = srcinv.Equipment(srcslot) || destinv.Equipment(destslot);

			if (srcbag == destbag)
			{
				srcinv.SwapItems(srcslot, destslot, true);
				if (redress)
					Client.Player.Redress();

				Client.Player.ForceUpdateData();
				return;
			}

			ItemObject srcitem = srcinv[srcslot];
			ItemObject destitem = destinv[destslot];
			if (srcitem == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown dest item in slot " + srcslot);
				return;
			}
			if (destslot < destinv.Divider || (srcslot < srcinv.Divider && destitem != null))
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_SLOT_MISMATCH);
				return;
			}
			if ((srcitem is ContainerObject) && ((ContainerObject)srcitem).Inventory.ItemCount > 0)
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EMPTY);
				return;
			}
			if ((destitem is ContainerObject) && ((ContainerObject)destitem).Inventory.ItemCount > 0)
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_NOT_EMPTY);
				return;
			}
			if (!destinv.AcceptItem(srcitem.DBItem))
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_AMMO_ONLY);
				return;
			}
			if (destitem != null && !srcinv.AcceptItem(destitem.DBItem))
			{
				SendChangeFail(client, srcitem, destitem, BagResponseUpdateFields.BAG_AMMO_ONLY);
				return;
			}
			ItemObject added = destinv.AddItem(srcitem.DBItem, false, destslot);
			if (added != null)
			{
				srcinv.RemoveItem(srcslot, true);

				srcinv.SendCreate(added);

				if (redress) 
					Client.Player.Redress();
				Client.Player.ForceUpdateData();

                //Client.Player.UpdateBags();
                return;
			}
			srcinv.RemoveItem(srcslot, false);
			if (srcinv.Equipment(srcslot) && !destinv.Equipment(destslot))
				srcitem.OnUnequip(Client.Player);

			if (destitem != null)
			{
				destinv.RemoveItem(destslot, false);
				if (destinv.Equipment(destslot) && !srcinv.Equipment(srcslot))
					destitem.OnUnequip(Client.Player);
			}

			destinv.AddNewItem(srcitem.DBItem, false, destslot);
			if (!srcinv.Equipment(srcslot) && destinv.Equipment(destslot))
				srcitem.OnEquip(Client.Player);

			if (destitem != null)
			{
				srcinv.AddNewItem(destitem.DBItem, false, srcslot);
				if (srcinv.Equipment(srcslot) && !destinv.Equipment(destslot))
					destitem.OnEquip(Client.Player);
			}

			if (redress)
				Client.Player.Redress();
			Client.Player.ForceUpdateData();
            //Client.Player.UpdateBags();

			//srcitem.o
			/*
			string result="Swap item: ";
			byte [] temp=data.ReadBytes((int)data.BaseStream.Length);
			for (int i=0;i<temp.Length;i++)	
				result+=string.Format("{0,2:X2} ", temp[i]);
			LogConsole.WriteLine(LogLevel.SYSTEM,result);
			*/
		}

		[PacketHandler(CMSG.OPEN_ITEM)]
		public static void HandleOpen(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			byte srcbag = data.ReadByte();
			INVSLOT srcslot = (INVSLOT) data.ReadByte();
			BaseInventory srcinv = Client.Player.Inventory.GetSubContainer(srcbag);
			if (srcinv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Operation with unknown src bag " + srcbag);
				return;
			}
			ItemObject srcitem = srcinv[srcslot];
			
			// TODO: skill raise
			if (srcitem.Template.Lock != 0)
				SendChangeFail(client, srcitem, null, BagResponseUpdateFields.BAG_ITEM_LOCKED);
			else
			{
				srcitem.GenerateLoot(Client.Player);
				Loot.DoLoot(srcitem, Client.Player);
				/*if (srcitem.ContainedIn != null)
					srcitem.ContainedIn.DeleteItem(srcitem.DBItem.OwnerSlot, true);
				srcitem.ContainedIn = null;*/
			}
		}
	}
}