using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunWoW.Spells;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class Talents
	{
		[PacketHandler(CMSG.LEARN_TALENT, ExecutionPriority.Pool)]
		public static void OnLearnTalent(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			int talentId = data.ReadInt32();
			int rank = data.ReadInt32();

			if (Client.Player.TalentPoints <= 0)
				return;

			Dictionary<ushort, ushort> ntalents = new Dictionary<ushort, ushort>();
			foreach (DBAbility ability in Client.Player.Character.Abilities)
				if (ability.TalentID != 0)
					ntalents[ability.TalentID] = ability.TalentID;

			if (ntalents.Count > 0)
			{
				int target = Client.Player.Level < 10 ? 0 : Client.Player.Level - 9;
				if (ntalents.Count > target)
				{
					LogConsole.WriteLine(LogLevel.ERROR, "Too much talents used: " + ntalents.Count);
					return;
				}
			}


			DBTalent Talent = (DBTalent) Database.Instance.FindObjectByKey(typeof (DBTalent), talentId);
			if (Talent == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Training unknown talent " + talentId);
				return;
			}
			ushort spellId = (ushort) Talent.SpellID[rank];
			if (spellId == 0)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "No spell for rank " + rank + " of talent " + talentId);
				return;
			}
			if (Client.Player.Spells[spellId] != null)
				return;
			DBSpell spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellId);
			if (spell == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "No spell for rank " + rank + " of talent " + talentId);
				return;
			}

			//	Chat.System(client,"Teaching talent with spell "+spellId+", level: "+Talent.Level+", rank: "+rank);
			int points = 0;
			bool hasprev = (Talent.ReqTalent == 0);
			IEnumerator e = Client.Player.Spells.Spells.Values.GetEnumerator();
			while (e.MoveNext())
			{
				DBAbility abl = e.Current as DBAbility;
				if (abl == null || abl.TalentID == 0)
					continue;
				DBTalent tal = (DBTalent) Database.Instance.FindObjectByKey(typeof (DBTalent), abl.TalentID);
				if (tal == null || tal.Tab != Talent.Tab)
					continue;
				if (!hasprev && tal.ObjectId == Talent.ReqTalent)
					hasprev = true;
				points += abl.Level;
			}
			if (!hasprev)
			{
				Chat.System(client, "You must know previous talent to learn this!");
				return;
			}
			if (points < Talent.Level*5)
			{
				Chat.System(client, "You must have " + Talent.Level*5 + " points in this tab!");
				return;
			}

			ShortPacket pkg = new ShortPacket(SMSG.LEARNED_SPELL);
			pkg.Write(spellId);
			pkg.Write((ushort) 0);
			client.Send(pkg);

			DBAbility talent = DBUtility.TalentOfChar(Client.Player.Character, spellId, (ushort) (rank + 1), (ushort) talentId);
			Client.Player.Spells.AddSpell(talent);

			if (rank > 0)
			{
				ushort old = (ushort) Talent.SpellID[rank - 1];
				if (Client.Player.Spells[old] != null)
				{
					pkg = new ShortPacket(SMSG.REMOVED_SPELL);
					pkg.Write(old);
					pkg.Write((ushort) 0);
					client.Send(pkg);
					Client.Player.Auras.CancelAuraForce(old);
					Client.Player.Spells.RemoveSpell(old);
					LogConsole.WriteLine(LogLevel.ECHO, "Removed old talent spell: " + old);
				}
			}

			if (talent.Spell != null && talent.Spell.Passive)
				SpellManager.SelfCast(Client.Player, talent.Spell);
			
			Client.Player.TalentPoints--;
			Client.Player.Redress();
			Client.Player.Save();
		}

		[PacketHandler(CMSG.UNLEARN_TALENTS, ExecutionPriority.Pool)]
		public static void OnUnlearnTalents(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			//Chat.System(client, "Unlearning talents!");

			ShortPacket confirm = new ShortPacket(SMSG.TALENT_WIPE_CONFIRM);
			confirm.Write(Client.Player.GUID);
			int wipeMoney = Client.Player.Character.TalentsWiped*50000;
			if (wipeMoney == 0)
				wipeMoney = 10000;

			if (wipeMoney > 50000)
				wipeMoney = 50000;
			confirm.Write(wipeMoney);
			client.Send(confirm);
		}

		[PacketHandler(CMSG.TALENT_WIPE_CONFIRM, ExecutionPriority.Pool)]
		public static void OnUnlearnConfirm(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			int wipeMoney = Client.Player.Character.TalentsWiped*50000;
			if (wipeMoney == 0)
				wipeMoney = 10000;

			if (wipeMoney > 50000)
				wipeMoney = 50000;

			if (Client.Player.Money < wipeMoney)
			{
				Chat.System(client, "You don't have money to wipe!");
				return;
			}

			Client.Player.Character.TalentsWiped++;
			Client.Player.Money -= wipeMoney;

			ArrayList toRemove = new ArrayList();
			IEnumerator e = Client.Player.Spells.Spells.Values.GetEnumerator();
			while (e.MoveNext())
			{
				DBAbility abl = e.Current as DBAbility;
				if (abl == null || abl.TalentID == 0)
					continue;
				/*DBTalent tal = (DBTalent) Database.Instance.FindObjectByKey(typeof (DBTalent), abl.TalentID);
				if (tal == null)
					continue;*/
				toRemove.Add(abl.SpellID);
			}
			foreach (ushort spell in toRemove)
			{
				Client.Player.Spells.RemoveSpell(spell);
				ShortPacket pkg = new ShortPacket(SMSG.REMOVED_SPELL);
				pkg.Write(spell);
				client.Send(pkg);
			}
			Client.Player.TalentPoints = Client.Player.Level - 9;
			Client.Player.RegisterPermanentMods();
			Client.Player.EquipItems();
			Client.Player.Redress();
			Client.Player.Save();
			Chat.System(client, "Talents wiped");
		}
	}
}