using System.Collections.Specialized;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Inventory;
using RunWoW.ServerDatabase;

namespace RunWoW.GamePackets
{
	public class TradeObjects
	{
		private static int Max = 7;

		public int Money = 0;
		public ItemObject[] Items = new ItemObject[Max];
		public bool Accepted = false;
	}

	public class TradeHelper
	{
		private HybridDictionary Objects;
		private PlayerObject[] Subjects;
		public int Iteration;

		public TradeHelper(PlayerObject one, PlayerObject another)
		{
			Objects = new HybridDictionary();
			Objects[one] = new TradeObjects();
			Objects[another] = new TradeObjects();
			Subjects = new PlayerObject[] {one, another};
			Iteration = 1;
		}

		public PlayerObject Opponent(PlayerObject one)
		{
			if (Subjects[0] == one)
				return Subjects[1];
			else if (Subjects[1] == one)
				return Subjects[0];
			else
				return null;
		}

		public TradeObjects this[PlayerObject player]
		{
			get { return Objects[player] as TradeObjects; }
		}

		public void SendUpdate()
		{
			Iteration++;
			TradeObjects to0 = Objects[Subjects[0]] as TradeObjects;
			TradeObjects to1 = Objects[Subjects[1]] as TradeObjects;
			to0.Accepted = false;
			to1.Accepted = false;
			SendUpdate(Subjects[0].BackLink.Client, Iteration, to1);
			SendUpdate(Subjects[1].BackLink.Client, Iteration, to0);
		}

		public void Exchange()
		{
			TradeObjects to0 = Objects[Subjects[0]] as TradeObjects;
			TradeObjects to1 = Objects[Subjects[1]] as TradeObjects;
			if (!to1.Accepted || !to0.Accepted)
				return;

			Subjects[0].Money += to1.Money - to0.Money;
			Subjects[1].Money += to0.Money - to1.Money;

			ExchangeItems(Subjects[0], to1);
			ExchangeItems(Subjects[1], to0);
		}

		private static void ExchangeItems(PlayerObject to, TradeObjects obj)
		{
			for (byte i = 0; i < obj.Items.Length - 1; i++)
			{
				if (obj.Items[i] == null)
					continue;
				int oldslot = obj.Items[i].DBItem.OwnerSlot;
				ItemObject item = to.Inventory.AddNewItem(obj.Items[i].DBItem, true);
				if (item != null)
				{
                    Database.Instance.ReindexObject("OwnerID", item.DBItem.OwnerID, to.CharacterID, item.DBItem);
					item.DBItem.OwnerID = to.CharacterID;
					obj.Items[i].ContainedIn.RemoveItem(oldslot, true);
				}
			}
		}

		private static void SendUpdate(ClientBase client, int iter, TradeObjects obj)
		{
			ShortPacket pkg = new ShortPacket(SMSG.TRADE_STATUS_EXTENDED);
			pkg.Write((byte) 1 /*num*/); // left-right?
			pkg.Write(iter);
			pkg.Write(iter);
			pkg.Write(obj.Money);
			pkg.Write(0);

			for (byte i = 0; i < obj.Items.Length; i++)
			{
				if (obj.Items[i] == null)
					continue;
				pkg.Write(i); // slot
				pkg.Write(obj.Items[i].Entry); // entry
				pkg.Write(obj.Items[i].Template.DisplayID); // display
				pkg.Write(obj.Items[i].StackCount);

				if (Constants.BurningCrusade)
				{
					for (int j = 0; j < 7; j++)
					{
						pkg.Write(obj.Items[i].Enchantments[j].ID);
						pkg.Write(obj.Items[i].Enchantments[j].Charges);
					}

					//pkg.Write(0);
					//pkg.Write(0);
					//pkg.Write(0);
					pkg.Write(0);
				} else
				{
					for (int j = 0; j < 7; j++)
						pkg.Write(obj.Items[i].Enchantments[j].ID);

					pkg.Write(new byte[20]); // properties ?
				}
			}
			client.Send(pkg);
		}

		public void SendStatus(int status)
		{
			if (Subjects[0] != null && Subjects[0].BackLink != null && Subjects[0].BackLink.Client != null)
				SendStatus(Subjects[0].BackLink.Client, status);
			if (Subjects[1] != null && Subjects[1].BackLink != null && Subjects[1].BackLink.Client != null)
				SendStatus(Subjects[1].BackLink.Client, status);
		}

		public static void SendStatus(ClientBase client, int status)
		{
			ShortPacket pkg = new ShortPacket(SMSG.TRADE_STATUS);
			pkg.Write((long) status);
			client.Send(pkg);
		}
	}

	[PacketHandlerClass()]
	public class TradeHandlers
	{
		[PacketHandler(CMSG.CANCEL_TRADE)]
		public static void CancelTrade(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null || Client.Player.TradeHelper == null)
				return;
			Client.Player.TradeHelper.SendStatus(3); //
			PlayerObject other = Client.Player.TradeHelper.Opponent(Client.Player);
			if (other != null)
				other.TradeHelper = null;
			Client.Player.TradeHelper = null;
		}

		[PacketHandler(CMSG.UNACCEPT_TRADE)]
		public static void UnacceptTrade(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.TradeHelper == null)
				return;
			//int iter=data.ReadInt32();
			TradeHelper Helper = Client.Player.TradeHelper;

			/*if (iter!=Helper.Iteration)
				return;*/
			Helper[Client.Player].Accepted = false;
		}

		[PacketHandler(CMSG.ACCEPT_TRADE)]
		public static void AcceptTrade(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.TradeHelper == null)
				return;
			int iter = data.ReadInt32();
			TradeHelper Helper = Client.Player.TradeHelper;

			if (iter != Helper.Iteration)
				return;
			PlayerObject other = Helper.Opponent(Client.Player);

			Helper[Client.Player].Accepted = true;
			if (!Helper[other].Accepted)
			{
				TradeHelper.SendStatus(other.BackLink.Client, 4);
				return;
			}
			Helper.Exchange();

			Client.Player.TradeHelper.SendStatus(8);
			Client.Player.TradeHelper = null;
			Client.Player.Redress();
			Client.Player.UpdateData();
			other.TradeHelper = null;
			other.Redress();
			other.UpdateData();
		}

		[PacketHandler(CMSG.BEGIN_TRADE)]
		public static void BeginTrade(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.TradeHelper == null)
				return;
			Client.Player.TradeHelper.SendStatus(2);
		}

		[PacketHandler(CMSG.INITIATE_TRADE)]
		public static void InitiateTrade(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
            if (Client == null || Client.Player == null || Client.Player.MapTile == null)
				return;

			ulong GUID = data.ReadUInt64();
		    
		    PlayerObject player;

            if (GUID == Client.Player.SelectionGUID && Client.Player.Selection is PlayerObject)
                player = (PlayerObject)Client.Player.Selection;
            else
                player = (PlayerObject) Client.Player.MapTile.GetObject(GUID, OBJECTTYPE.PLAYER);
		    
			if (player == null || player.IsDisposed)
			{
				TradeHelper.SendStatus(client, 0);
				//Chat.System("Player too far!");
				return;
			}

			if (!Faction.SameFaction(Client.Player.Faction, player.Faction)) // enemy
			{
				LogConsole.WriteLine(LogLevel.ECHO, "Inviting enemy player");
				TradeHelper.SendStatus(client, 0);
				return;
			}

			if (player.TradeHelper != null && player.TradeHelper.Opponent(player) != Client.Player)
			{
				TradeHelper.SendStatus(client, 0);
				return;
			}
			Client.Player.TradeHelper = player.TradeHelper = new TradeHelper(Client.Player, player);

			ShortPacket pkg = new ShortPacket(SMSG.TRADE_STATUS);
			pkg.Write(0x01);
			pkg.Write(Client.Player.GUID);
			player.BackLink.Client.Send(pkg);
		}

		// ? ????? ???? ????!!!//  (c) Druida
		// ? ???? ????!!! // (c) Nomad
		[PacketHandler(CMSG.SET_TRADE_GOLD)]
		public static void SetTradeGold(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.TradeHelper == null)
				return;
			
			int amount = data.ReadInt32();

			if (Client.Player.Money < amount || amount < 0)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "MoneyCheat: {0} trying to trade: {1}", Client.Player.Name, amount);
				return;
			}
			
			//LogConsole.WriteLine(LogLevel.TRACE,"TRADE ["+Client.Player.Name+"]:"+"set gold "+amount);
			if (Client.Player.TradeHelper[Client.Player].Money != amount)
			{
				Client.Player.TradeHelper[Client.Player].Money = amount;
				Client.Player.TradeHelper.SendUpdate();
			}
		}

		[PacketHandler(CMSG.CLEAR_TRADE_ITEM)]
		public static void ClearTradeItem(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.TradeHelper == null)
				return;

			byte num = data.ReadByte();
			//LogConsole.WriteLine(LogLevel.SYSTEM,"TRADE ["+Client.Player.Name+"]:"+"clear trade slot "+num);

			Client.Player.TradeHelper[Client.Player].Items[num] = null;
			Client.Player.TradeHelper.SendUpdate();
		}

		[PacketHandler(CMSG.SET_TRADE_ITEM)]
		public static void SetTradeItem(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.TradeHelper == null)
				return;
			byte num = data.ReadByte();
			byte pack = data.ReadByte();
			byte item = data.ReadByte();
			//LogConsole.WriteLine(LogLevel.SYSTEM,"TRADE ["+Client.Player.Name+"]:"+"set trade item "+item+" from pack "+pack+" to slot "+num);
			BaseInventory inv = Client.Player.Inventory.GetSubContainer(pack);
			if (inv == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Trading from unknown bag: " + pack);
				return;
			}

			if (num != 6 && inv[item].Soulbound)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Cheater {0} trying to sell soulbound item {1}", Client.Player.Name,
				                     inv[item].Name);
				return;
			}
			Client.Player.TradeHelper[Client.Player].Items[num] = inv[item];
			Client.Player.TradeHelper.SendUpdate();
		}
	}
}