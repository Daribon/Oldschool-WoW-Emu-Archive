//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.GamePackets
{
	public enum GuildEvent : byte
	{
		PROMOTION = 0,
		DEMOTION = 1,
		MOTD = 2,
		JOINED = 3,
		LEFT = 4,
		REMOVED = 5,
		LEADER_IS = 6,
		LEADER_CHANGED = 7,
		DISBANDED = 8,
		TABARDCHANGE = 9,
		OFFLINE = 13,
		ONLINE = 12
	}

	[PacketHandlerClass]
	public class Guild
	{
		[PacketHandler(CMSG.SAVE_GUILD_EMBLEM)]
		public static void OnGuildEmblem(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			ulong GUID = data.ReadUInt64();

			ShortPacket pkg = new ShortPacket(SMSG.SAVE_GUILD_EMBLEM);
			pkg.Write(GUID);

			if (Client.Player.Money < 100000)
			{
				pkg.Write(1);
				client.Send(pkg);
				Chat.System(client, "You must have 10 gold to change guild emblem!");
				return;
			}

			DBGuild guild = Client.Character.Guild;

			if (Client.Player.Character.ObjectId != guild.LeaderID)
			{
				pkg.Write(1);
				client.Send(pkg);
				Chat.System(client, "Only guild master can change guild emblem!");
				return;
			}

			pkg.Write(0);
			client.Send(pkg);

			guild.Icon = data.ReadUInt32();
			guild.IconColor = data.ReadUInt32();
			guild.Border = data.ReadUInt32();
			guild.BorderColor = data.ReadUInt32();
			guild.Color = data.ReadUInt32();

			DBManager.SaveDBObject(guild);

			Client.Player.Money -= 100000;

			updateGuild(guild);


			//Chat.System(client, "Guild emblem set");

			SendGuildEvent(guild, GuildEvent.TABARDCHANGE);
		}

		public static void CreateGuild(string guildName, PlayerObject guildMaster, ArrayList guildMembers)
		{
			DBGuild dbGuild = (DBGuild) Database.Instance.FindObjectByField(typeof (DBGuild), "Name", guildName);
			if (dbGuild != null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Guild already exists {0}!", guildName);
				return;
			}

			dbGuild = new DBGuild();
			dbGuild.Name = guildName;
			dbGuild.CreationDate = CustomDateTime.Now;
			dbGuild.LeaderID = guildMaster.CharacterID;
			dbGuild.MOTD = "Guild created";
			dbGuild.GuildInfo = "Guild Info";
			dbGuild.RankName[0] = "Guild Master";
			dbGuild.RankName[1] = "Officer";
			dbGuild.RankName[2] = "Newbie";
			dbGuild.RankFlags[0] = 127487;
			dbGuild.RankFlags[1] = 61455;
			dbGuild.RankFlags[2] = 67;
			dbGuild.MaxRank = 3;

			DBManager.NewDBObject(dbGuild);

			Dictionary<string, CharacterHolder> characters = new Dictionary<string, CharacterHolder>();
			CharacterHolder leader = null;

			foreach (ulong member in guildMembers)
			{
				DBCharacter chr;
				PlayerObject player = ClientManager.GetPlayer(member);

				if (player == null || player.Character == null || player.IsDisposed)
				{
					chr = ClientManager.GetCharacter((uint) member);
						//(DBCharacter) Database.Instance.FindObjectByKey(typeof (DBCharacter), (uint) member);
				}
				else
					chr = player.Character;

				if (chr == null)
				{
					LogConsole.WriteLine(LogLevel.WARNING, "Adding empty guild member {0}!", member);
					continue;
				}

				if (chr.GuildID != 0)
				{
					continue;
				}
				if (player != null)
				{
					player.GuildID = dbGuild.ObjectId;
					player.GuildRank = 2;
					player.Character.Guild = dbGuild;
					player.Save();
				}
				else
				{
					chr.GuildID = dbGuild.ObjectId;
					chr.Guild = dbGuild;
					chr.GuildRank = 2;
					DBManager.SaveDBObject(chr);
				}


				CharacterHolder holder = new CharacterHolder(chr);
				if (dbGuild.LeaderID == chr.ObjectId)
					leader = holder;

				characters.Add(holder.Name, holder);

				Database.Instance.ReindexObject("GuildID", 0, dbGuild.ObjectId, chr);
			}


			if (leader == null)
			{
				guildMaster.GuildID = dbGuild.ObjectId;
				guildMaster.GuildRank = 0;
				guildMaster.Character.Guild = dbGuild;
				guildMaster.Save();

				leader = new CharacterHolder(guildMaster.Character);
				characters.Add(leader.Name, leader);
			}
			else
				leader.GuildRank = guildMaster.GuildRank = 0;

			dbGuild.Leader = leader;

			Database.Instance.ReindexObject("GuildID", 0, dbGuild.ObjectId, guildMaster.Character);

			dbGuild.Characters = characters;

			updateGuild(dbGuild);

			SendGuildEvent(dbGuild, GuildEvent.MOTD);
		}

		#region Guild Information 

		[PacketHandler(CMSG.GUILD_ROSTER)]
		public static void OnGuildRoster(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			guildRoster(client, Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_QUERY)]
		public static void OnGuildQuery(ClientBase client, BinReader data)
		{
			uint guildId = data.ReadUInt32();
			DBGuild guild = (DBGuild) Database.Instance.FindObjectByKey(typeof (DBGuild), guildId);
			if (guild == null)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "Guid query for unknown guid" + guildId);
				return;
			}
			guildQuery(client, guild);
		}

		[PacketHandler(CMSG.GUILD_INFO)]
		public static void OnGuildInfo(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			resolveGuild(Client.Character.Guild, false);

			ShortPacket pkg = new ShortPacket(SMSG.GUILD_INFO);
			pkg.Write(Client.Character.Guild.Name);
			pkg.Write(Client.Character.Guild.CreationDate.Day);
			pkg.Write(Client.Character.Guild.CreationDate.Month);
			pkg.Write(Client.Character.Guild.CreationDate.Year);
			pkg.Write(Client.Character.Guild.Characters.Count);
			pkg.Write(Client.Character.Guild.Characters.Count);
			client.Send(pkg);
		}

		#endregion

		#region Guild Control

		[PacketHandler(CMSG.GUILD_MOTD)]
		public static void OnGuildMotd(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if ((Client.Character.Guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.SETMOTD) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			Client.Character.Guild.MOTD = data.ReadString(100);

			SendGuildEvent(Client.Character.Guild, GuildEvent.MOTD);
			DBManager.SaveDBObject(Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_CHANGEINFO)]
		public static void OnGuildChangeInfo(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if ((Client.Character.Guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.CHANGEINFO) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			Client.Character.Guild.GuildInfo = data.ReadString(100);

			guildRoster(client, Client.Character.Guild);
			//SendGuildEvent(Client.Character.Guild,  GuildEvent.);
			DBManager.SaveDBObject(Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_RANK)]
		public static void OnGuildRank(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if (Client.Character.Guild.LeaderID != Client.Character.ObjectId)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			uint rankId = data.ReadUInt32();
			uint flags = data.ReadUInt32();
			Client.Character.Guild.RankFlags[rankId] = flags;
			Client.Character.Guild.RankName[rankId] = data.ReadString(100);
			Client.Character.Guild.Dirty = true;
			guildQuery(client, Client.Character.Guild);
			guildRoster(client, Client.Character.Guild);
			DBManager.SaveDBObject(Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_ADD_RANK)]
		public static void OnGuildAddRank(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if (Client.Character.Guild.LeaderID != Client.Character.ObjectId)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			uint rankId = Client.Character.Guild.MaxRank;
			if (rankId == Client.Character.Guild.RankName.Length)
			{
				return;
			}
			Client.Character.Guild.MaxRank++;
			Client.Character.Guild.RankName[rankId] = data.ReadString(100);
			Client.Character.Guild.RankFlags[rankId] =
				(uint) (GUILD_RANK_FLAGS.GCHATLISTEN | GUILD_RANK_FLAGS.GCHATSPEAK);

			guildQuery(client, Client.Character.Guild);
			guildRoster(client, Client.Character.Guild);
			DBManager.SaveDBObject(Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_DEL_RANK)]
		public static void OnGuildDelRank(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if (Client.Character.Guild.LeaderID != Client.Character.ObjectId)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			if (Client.Character.Guild.MaxRank == 2)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.INTERNAL);
				return;
			}

			Client.Character.Guild.MaxRank--;

			guildQuery(client, Client.Character.Guild);
			guildRoster(client, Client.Character.Guild);
			DBManager.SaveDBObject(Client.Character.Guild);
		}

		#endregion

		#region Guild Members operations

		[PacketHandler(CMSG.GUILD_SET_PUBLIC_NOTE)]
		public static void OnGuildPublicNote(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			DBGuild guild = Client.Character.Guild;

			if (guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if ((guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.EPNOTE) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			string name = data.ReadString();

			resolveGuild(guild, false);

			if (!guild.Characters.ContainsKey(name))
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			CharacterHolder targetHolder = guild.Characters[name];

			DBCharacter targetMember = ClientManager.GetCharacter(targetHolder.ObjectId);

			string pnote = data.ReadString(100);

			targetMember.GuildPublicNote = pnote;

			targetHolder.Update(targetMember);

			DBManager.SaveDBObject(targetMember);

			guildRoster(client, Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_SET_OFFICER_NOTE)]
		public static void OnGuildOfficerNote(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			DBGuild guild = Client.Character.Guild;

			if (guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if ((guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.EOFFNOTE) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			string name = data.ReadString();

			resolveGuild(guild, false);

			if (!guild.Characters.ContainsKey(name))
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			CharacterHolder targetHolder = guild.Characters[name];

			DBCharacter targetMember = ClientManager.GetCharacter(targetHolder.ObjectId);

			string offnote = data.ReadString(100);

			targetMember.GuildOfficerNote = offnote;
			targetHolder.Update(targetMember);

			DBManager.SaveDBObject(targetMember);

			guildRoster(client, Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_PROMOTE)]
		public static void OnGuildPromote(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			DBGuild guild = Client.Character.Guild;

			if (guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if ((guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.PROMOTE) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			string name = data.ReadString();

			resolveGuild(guild, false);

			if (!guild.Characters.ContainsKey(name))
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			CharacterHolder targetHolder = guild.Characters[name];

			DBCharacter targetMember = ClientManager.GetCharacter(targetHolder.ObjectId);

			if (targetMember.GuildRank == 0)
			{
				return;
			}

			targetMember.GuildRank--;
			targetHolder.Update(targetMember);

			DBManager.SaveDBObject(targetMember);

			//SendGuildEvent(Client.Character.Guild, GuildEvent.PROMOTION, targetMember);
			guildRoster(client, Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_DEMOTE)]
		public static void OnGuildDeomote(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			DBGuild guild = Client.Character.Guild;

			if (guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if ((guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.DEMOTE) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			string name = data.ReadString();

			resolveGuild(guild, false);

			if (!guild.Characters.ContainsKey(name))
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			CharacterHolder targetHolder = guild.Characters[name];

			DBCharacter targetMember = ClientManager.GetCharacter(targetHolder.ObjectId);

			if (targetMember.GuildRank == Client.Character.Guild.MaxRank - 1)
			{
				return;
			}

			targetMember.GuildRank++;
			targetHolder.Update(targetMember);

			DBManager.SaveDBObject(targetMember);

			//SendGuildEvent(Client.Character.Guild, GuildEvent.DEMOTION, targetMember);
			guildRoster(client, Client.Character.Guild);
		}

		[PacketHandler(CMSG.GUILD_LEADER)]
		public static void OnGuildLeader(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			DBGuild guild = Client.Character.Guild;

			if (guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if (guild.LeaderID != Client.CharacterID)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			string name = data.ReadString();

			resolveGuild(guild, false);

			if (!guild.Characters.ContainsKey(name))
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			CharacterHolder targetHolder = guild.Characters[name];

			DBCharacter targetMember = ClientManager.GetCharacter(targetHolder.ObjectId);

			targetMember.GuildRank = 0;
			targetHolder.Update(targetMember);
			DBManager.SaveDBObject(targetMember);

			guild.Leader = targetHolder;
			guild.LeaderID = targetMember.ObjectId;
			DBManager.SaveDBObject(guild);

			Client.Character.GuildRank = 1;
			guild.Characters[Client.Character.Name].GuildRank = 1;

			SendGuildEvent(guild, GuildEvent.LEADER_CHANGED, targetMember);

			Client.Player.Save();

			updateGuild(guild);
			guildRoster(client, guild);
		}

		#endregion 

		#region Join/Leave guild

		[PacketHandler(CMSG.GUILD_LEAVE)]
		public static void OnGuildLeave(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			DBGuild guild = Client.Character.Guild;

			if (guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			resolveGuild(guild, false);

			bool last = guild.Characters.Count == 1;

			if (guild.LeaderID == Client.CharacterID && !last)
			{
				CommandResult(client, GUILD_COMMAND.QUIT, string.Empty, GUILD_COMMAND_RESULT.LEADER_LEAVE);
				return;
			}

			uint oldGuild = Client.Player.GuildID;

			Client.Player.GuildID = 0;
			Client.Player.GuildRank = 0;
			Client.Player.GuildTimestamp = CustomDateTime.Now;
			Client.Character.GuildOfficerNote = string.Empty;
			Client.Character.GuildPublicNote = string.Empty;

			Client.Player.UpdateData();
			Client.Player.Save();

			Database.Instance.ReindexObject("GuildID", oldGuild, 0, Client.Character);

			guild.Characters.Remove(Client.Player.Name);

			if (last)
				DBManager.EraseDBObject(guild);
			else
			{
				updateGuild(guild);
				SendGuildEvent(guild, GuildEvent.LEFT, Client.Character);
			}
		}

		[PacketHandler(CMSG.GUILD_REMOVE)]
		public static void OnGuildRemove(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			DBGuild guild = Client.Character.Guild;

			if (guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			string name = data.ReadString();

			if (name == Client.Player.Name)
			{
				OnGuildLeave(client, data);
				return;
			}

			if ((guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.REMOVE) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}


			resolveGuild(guild, false);

			if (!guild.Characters.ContainsKey(name))
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			CharacterHolder targetHolder = guild.Characters[name];

			DBCharacter targetMember = ClientManager.GetCharacter(targetHolder.ObjectId);

			targetMember.GuildID = 0;
			targetMember.GuildRank = 0;
			targetMember.GuildOfficerNote = string.Empty;
			targetMember.GuildPublicNote = string.Empty;
			targetMember.Guild = null;

			//targetHolder.Update(targetMember);

			DBManager.SaveDBObject(targetMember);

			Database.Instance.ReindexObject("GuildID", Client.Character.GuildID, 0, targetMember);

			guild.Characters.Remove(name);

			guildRoster(client, Client.Character.Guild);

			SendGuildEvent(Client.Character.Guild, /*GuildEvent.REMOVED*/ GuildEvent.LEFT, targetMember);

			ClientBase targetClient = ClientManager.GetClient(targetMember.ObjectId);

			if (targetClient != null && targetClient.Data != null)
			{
				((ClientData) targetClient.Data).Player.GuildTimestamp = CustomDateTime.Now;
				((ClientData) targetClient.Data).Player.UpdateData();
			}
		}

		[PacketHandler(CMSG.GUILD_INVITE)]
		public static void OnGuildInvite(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			if (Client.Character.Guild == null)
			{
				CommandResult(client, GUILD_COMMAND.CREATE, string.Empty, GUILD_COMMAND_RESULT.PLAYER_NOT_IN_GUILD);
				return;
			}

			if ((Client.Character.Guild.RankFlags[Client.Player.GuildRank] & (int) GUILD_RANK_FLAGS.INVITE) == 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, string.Empty, GUILD_COMMAND_RESULT.PERMISSIONS);
				return;
			}

			string player = data.ReadString();

			PlayerObject targetPlayer = ClientManager.GetPlayer(player);
			if (targetPlayer == null)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, player, GUILD_COMMAND_RESULT.PLAYER_NOT_FOUND);
				return;
			}

			if (targetPlayer.GuildID != 0)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, player, GUILD_COMMAND_RESULT.ALREADY_IN_GUILD_S);
				return;
			}

			if (!Faction.SameFaction(Client.Player.Faction, targetPlayer.Faction)) // enemy
			{
				CommandResult(client, GUILD_COMMAND.INVITE, player, GUILD_COMMAND_RESULT.NOT_ALLIED);
				return;
			}

			if (targetPlayer.GuildInvite != null && targetPlayer.GuildInvite.IsAlive)
			{
				CommandResult(client, GUILD_COMMAND.INVITE, player, GUILD_COMMAND_RESULT.ALREADY_INVITED_TO_GUILD);
				return;
			}

			targetPlayer.GuildInvite = Client.Player.Reference;

			ShortPacket invite = new ShortPacket(SMSG.GUILD_INVITE);
			invite.Write(Client.Player.Name);
			invite.Write(Client.Character.Guild.Name);
			targetPlayer.BackLink.Client.Send(invite);
		}

		[PacketHandler(CMSG.GUILD_DECLINE)]
		public static void OnGuildDecline(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null || Client.Player.GuildInvite == null ||
			    !Client.Player.GuildInvite.IsAlive)
				return;

			ShortPacket decline = new ShortPacket(SMSG.GUILD_DECLINE);
			decline.Write(Client.Player.Name);
			Client.Player.GuildInvite.Target.BackLink.Client.Send(decline);
			Client.Player.GuildInvite = null;
		}

		[PacketHandler(CMSG.GUILD_ACCEPT)]
		public static void OnGuildAccept(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null || Client.Player.GuildInvite == null ||
			    !Client.Player.GuildInvite.IsAlive)
			{
				Console.WriteLine("Got GUILD_ACCEPT for player not in guild");
				return;
			}

			DBGuild guild = Client.Player.GuildInvite.Target.Character.Guild;

			Client.Character.GuildOfficerNote = string.Empty;
			Client.Character.GuildPublicNote = string.Empty;
			Client.Character.Guild = guild;
			Client.Player.GuildID = guild.ObjectId;
			Client.Player.GuildRank = guild.MaxRank - 1;

			Client.Player.Save();

			Database.Instance.ReindexObject("GuildID", 0, guild.ObjectId, Client.Character);

			guild.Characters = null;

			SendGuildEvent(guild, GuildEvent.JOINED, Client.Character);

			updateGuild(guild);
		}

		#endregion

		#region Helpers

		public static void CommandResult(ClientBase client, GUILD_COMMAND command, string value,
		                                 GUILD_COMMAND_RESULT result)
		{
			ShortPacket pkg = new ShortPacket(SMSG.GUILD_COMMAND_RESULT);
			pkg.Write((int) command);
			pkg.Write(value);
			pkg.Write((int) result);
			client.Send(pkg);
		}

		private static void resolveGuild(DBGuild guild, bool force)
		{
			if (guild.Characters == null || force)
			{
				Dictionary<string, CharacterHolder> chars = new Dictionary<string, CharacterHolder>();
				ICollection dbChars = Database.Instance.FindObjectsByField(typeof (DBCharacter), "GuildID", guild.ObjectId);

				foreach (DBCharacter character in dbChars)
					if (character.GuildID == guild.ObjectId) // sanity check
					{
						CharacterHolder holder = new CharacterHolder(character);
						if (character.ObjectId == guild.LeaderID)
							guild.Leader = holder;
						chars[holder.Name] = holder;
					}

				guild.Characters = chars;
			}
		}

		private static void updateGuild(DBGuild guild)
		{
			resolveGuild(guild, false);

			foreach (CharacterHolder member in guild.Characters.Values)
			{
				ClientBase client = ClientManager.GetClient(member.ObjectId);
				if (client != null && client.Data != null)
				{
					((ClientData) client.Data).Player.GuildTimestamp = CustomDateTime.Now;
					((ClientData) client.Data).Player.UpdateData();
				}
			}
		}

		private static void guildQuery(ClientBase client, DBGuild guild)
		{
			ShortPacket pkg = new ShortPacket(SMSG.GUILD_QUERY_RESPONSE);
			pkg.Write(guild.ObjectId);
			pkg.Write(guild.Name);
			for (uint i = 0; i < 10; i++)
				if (guild.RankName[i] != null)
					pkg.Write(guild.RankName[i]);
				else
					pkg.Write(string.Empty);
			pkg.Write((uint) guild.Icon);
			pkg.Write((uint) guild.IconColor);
			pkg.Write((uint) guild.Border);
			pkg.Write((uint) guild.BorderColor);
			pkg.Write((uint) guild.Color);
			//pkg.Write((byte)0);
			client.Send(pkg);
		}

		private static void guildRoster(ClientBase client, DBGuild guild)
		{
			resolveGuild(guild, false);

			ShortPacket pkg = new ShortPacket(SMSG.GUILD_ROSTER);
			pkg.Write(guild.Characters.Count);
			pkg.Write(guild.MOTD);
			pkg.Write(guild.GuildInfo); // guild info
			pkg.Write(guild.MaxRank);
			for (uint i = 0; i < guild.MaxRank; i++)
				pkg.Write(guild.RankFlags[i]);

			foreach (CharacterHolder member in guild.Characters.Values)
			{
				pkg.Write((ulong) member.ObjectId);

				PlayerObject player = ClientManager.GetPlayer(member.ObjectId);
				if (player != null)
				{
					pkg.Write(true);
					pkg.Write(player.Name);
					pkg.Write(player.GuildRank);
					pkg.Write((byte) player.Level);
					pkg.Write((byte) player.Class);
					pkg.Write((uint) player.Zone);
					pkg.Write(player.Character.GuildPublicNote);
					pkg.Write(player.Character.GuildOfficerNote);
				}
				else
				{
					pkg.Write(false);
					pkg.Write(member.Name);
					pkg.Write(member.GuildRank);
					pkg.Write((byte) member.Level);
					pkg.Write((byte) member.Class); 
					pkg.Write((uint) member.Zone);
					//pkg.Write(((int) (10*member.LastAccess.Ticks/TimeSpan.TicksPerMillisecond) + 0x3EEEEEEE));
					pkg.Write( GetTimeCode( (DateTime.Now.Ticks -  member.LastAccess.Ticks) / TimeSpan.TicksPerMillisecond ));
					pkg.Write(member.GuildPublicNote);
					pkg.Write(member.GuildOfficerNote);
				}		
				
			}
			client.Send(pkg);
		}

		private static int GetTimeCode(long timemsec)
		{
			int hours	= (int)((timemsec/1000)/3600);
			int days	= hours / 24;
			int months  = days / 30;
			int years   = months / 12;

			if (hours == 0  )
				return 0;
			else if ( hours == 1 )
				return 0x3d2AAAAB;
			else if ( hours == 2 )
				return 0x3daaaaab;
			else if ( hours >= 3 && hours <= 5 )
				return 0x3E000000 + 0x2aaaab*(hours - 3);
			else if (hours >= 6 && hours <= 11)
				return 0x3e800000 + 0x155555 * (hours - 6);
			else if (hours >= 12 && hours <= 23 )
				return 0x3f000000 + 0xAAAAB * (hours - 12);
			else if (days == 1 )
				return 0x3f800000;
			else if ( days == 2 || days  == 3 )
				return 0x40000000 + 0x3FFFFF * (days - 2);
			else if (days >= 4 && days <= 7)
				return 0x40800000 + 0x1FFFFF * (days - 4);
			else if (days >= 8 && days <= 15)
				return 0x41000000 + 0x0FFFFF * (days - 8);
			else if (days >= 16 && days <= 30 )
				return 0x41800000 + 0x07FFFF * (days - 16);
			else if ( months == 1 )
				return 0x41F00000;
			else if (months == 2)
				return 0x42700000;
			else if (months == 3)
				return 0x42B40000;
			else if (months == 4)
				return 0x42F00000;
			else if (months >= 5 && months <= 8)
				return 0x43160000 + 0x1DFFFF * (months - 5);
			else if (months >= 9 && months <= 11)
				return 0x438e0000 + 0x0EFFFF * (months - 9);
			else if (years == 1)
				return 0x43bb0000;
			else if (years == 2)
				return 0x44368000;
			else if (years == 3)
				return 0x4488E000;
			
			return 0;
		}

		public static void SendGuildEvent(DBGuild guild, GuildEvent ev)
		{
			SendGuildEvent(guild, ev, null, null);
		}

		public static void SendGuildEvent(DBGuild guild, GuildEvent ev, DBCharacter member)
		{
			SendGuildEvent(guild, ev, member, null);
		}

		public static void SendGuildEvent(DBGuild guild, GuildEvent ev, DBCharacter member, ClientBase tclient)
		{
//!!! MAY BE WRONG !!!
			if (guild == null)
				return;

			resolveGuild(guild, false);

			ShortPacket pkg = new ShortPacket(SMSG.GUILD_EVENT);
			pkg.Write((byte) ev);

			string[] strings;
			switch (ev)
			{
				case GuildEvent.MOTD:
					strings = new string[] {guild.MOTD};
					break;
				case GuildEvent.JOINED:
				case GuildEvent.LEFT:
				case GuildEvent.ONLINE:
				case GuildEvent.OFFLINE:
					strings = new string[] {member.Name};
					break;
				case GuildEvent.PROMOTION:
				case GuildEvent.DEMOTION:
					strings = new string[] {member.Name, guild.RankName[member.GuildRank]};
					break;
				case GuildEvent.LEADER_CHANGED:
					strings = new string[] {guild.Leader == null ? string.Empty : guild.Leader.Name, member.Name};
					break;
				default:
					strings = new string[0];
					break;
			}
			pkg.Write((byte) strings.Length);
			for (int i = 0; i < strings.Length; i++)
				pkg.Write(strings[i]);

			pkg.Aquire();

			if (tclient != null)
				tclient.Send(pkg);
			else
				foreach (CharacterHolder character in guild.Characters.Values)
				{
					ClientBase client = ClientManager.GetClient(character.ObjectId);
					if (client != null)
						client.Send(pkg);
				}

			pkg.Release();
		}

		#endregion
	}
}