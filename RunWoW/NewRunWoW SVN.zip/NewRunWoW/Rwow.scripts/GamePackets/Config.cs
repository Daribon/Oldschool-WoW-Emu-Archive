//
using System;
using System.Security.Cryptography;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.ServerDatabase;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class ConfigHandler
	{
		private static MD5 md5 = new MD5CryptoServiceProvider();

		[PacketHandler(CMSG.REQUEST_ACCOUNT_DATA)]
		public static void OnRequestUIConfig(ClientBase client, BinReader data)
		{
			SendConfig(client, data.ReadInt32());
			return;
		}

		[PacketHandler(CMSG.UPDATE_ACCOUNT_DATA)]
		public static void OnSaveUIConfig(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Character == null)
				return;
			uint type = data.ReadUInt32() - 1;
			if (type >= Client.Character.UIConfig.Length)
			{
				Console.WriteLine("Got UI number {0}, while maximum is {1}", type, Client.Character.UIConfig.Length - 1);
				return;
			}

			int len = data.ReadInt32(); // uncompressed
			if (len != 0)
				Client.Character.UIConfig[type] = data.ReadBytes(data.Length - data.Position);
			else
				Client.Character.UIConfig[type] = null;

			DBManager.SaveDBObject(Client.Character);
		}


		[PacketHandler(CMSG.SET_ACTIONBAR_TOGGLES)]
		public static void ActionBarToggle(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			Client.Player.ActionBars = data.ReadByte();
			
		}

		public static void SendConfigCRC(ClientBase client)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;

			ShortPacket packet = new ShortPacket(SMSG.ACCOUNT_DATA_MD5);
//			foreach (byte[] data in Client.Character.UIConfig)
//				packet.Write(HashConfig(data));
			for (int i=0; i<32; i++)
				packet.Write(0);
			client.Send(packet);
		}

		private static byte[] HashConfig(byte[] data)
		{
			//if (data == null || data.Length <= 1)
				return new byte[0x10];
			//return md5.ComputeHash(data, 0, data.Length);
		}

		private static void SendConfig(ClientBase client, int type)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Character == null)
				return;
			byte[] data = Client.Character.UIConfig[type];
			ShortPacket packet = new ShortPacket(SMSG.UPDATE_ACCOUNT_DATA);
			packet.Write(type);
			if (data == null || data.Length <= 1)
				packet.Write(0);
			else
			{
				packet.Write(data.Length);
				packet.Write(data);
			}
			client.Send(packet);
		}
	}
}