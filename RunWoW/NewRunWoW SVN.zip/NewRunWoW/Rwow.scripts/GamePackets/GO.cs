using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.GameObjects;
using RunWoW.Objects;

namespace RunWoW.GamePackets
{
	[PacketHandlerClass()]
	public class GOItems
	{
		[PacketHandler(CMSG.GAMEOBJ_USE)]
		public static void HandleUseItem(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null || Client.Player.MapTile == null)
				return;
			ulong GUID = data.ReadUInt64();
			GameObject go = (GameObject) Client.Player.MapTile.GetObject(GUID, OBJECTTYPE.GAMEOBJECT);

			if (go == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Using unknown GO " + GUID);
				return;
			}
			GOManager.ProcessGOUse(Client.Player, go);
		}
	}
}