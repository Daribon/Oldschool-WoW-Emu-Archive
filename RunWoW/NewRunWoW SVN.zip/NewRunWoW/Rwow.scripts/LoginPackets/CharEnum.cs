//
using System;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.LoginPackets
{
	[PacketHandlerClass()]
	public class CharEnum
	{
		[PacketHandler(CMSG.CHAR_ENUM, ExecutionPriority.Pool)]
		public static void HandleCharEnum(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Account == null)
			{
				client.Close("HandleCharEnum: Not logged in.");
				return;
			}
			
			if (Client.Addons != null)
				initAddons(Client.Addons, Client.AddonsLength, client);

			if (Client.Account.Characters == null)
				Database.Instance.ResolveRelations(Client.Account, true);

			ShortPacket packet = new ShortPacket(SMSG.CHAR_ENUM);

			if (Client.Account.Characters == null)
			{
				LogConsole.WriteLine(LogLevel.ECHO, "No characters found");
				packet.Write((byte) 0);
				client.Send(packet);
				return;
			}
			packet.Write((byte) 0 /*Client.Account.Characters.Length*/);
			byte count = 0;
			foreach (DBCharacter character in Client.Account.Characters)
			{
				if (character != null && character.Active == 1 && !character.Name.StartsWith("deleted_"))
				{
					packet.Write((ulong) character.ObjectId);
					packet.Write(character.Name);
					packet.Write((byte) character.Race);
					packet.Write((byte) character.Class);
					packet.Write(character.Gender);
					packet.Write(character.Skin);
					packet.Write(character.Face);
					packet.Write(character.HairStyle);
					packet.Write(character.HairColor);
					packet.Write(character.FacialHairStyle);
					packet.Write((byte) character.Level);
					packet.Write(character.Zone);
					packet.Write(character.WorldMapID);
					packet.WriteVector(character.Position);
					packet.Write(character.GuildID);
					packet.Write((byte)0);	//unknown. 0x04 - CHAR_LOGIN_LOCKED_FOR_TRANSFER???
					packet.Write((byte)0);	//some flags
					packet.Write((byte)0);	//unknown
					packet.Write((byte)0);	//unknown. 0x01 - CHAR_LOGIN_LOCKED_BY_BILLING
//					packet.Write(1 /*character.DeathWorld == -1 ? 0 : 1*/);
					packet.Write((byte) 1 /*character.RestedPoints > 0 ? (byte)1 : (byte)3*/);
					//if (character.LastPetID != 0)
					//{
					//    DBPet pet = (DBPet)Database.Instance.FindObjectByKey(typeof(DBPet), character.LastPetID);
					//    w.Write(pet.Creature.DisplayID);
					//    w.Write(pet.Level);
					//    w.Write((int)pet.Creature.CreatureFamily);
					//}
					//else
					{
						packet.Write(0); // pet info id
						packet.Write(0); // pet level
						packet.Write(0); // pet family id
					}
					int pos = packet.Position;
					packet.Write(new byte[100]);

					if (character.Outfit[0] == -1)
					{
						if (character.Items == null)
							Database.Instance.ResolveRelations(character, typeof (DBItem));
						foreach (DBItem item in character.Items)
							if (item != null)
							{
								if (item.OwnerSlot > (int) INVSLOT.EQUIPPEDLAST)
									continue;
								if (item.ContainerID != 0 && item.ContainerID != (long) character.ObjectId)
									continue;
								if (item.Template == null)
								{
									LogConsole.WriteLine(LogLevel.ERROR, "Database error: Item missing template object.");
									continue;
								}
								packet.Set((int) (pos + item.OwnerSlot*5), item.Template.DisplayID);
								packet.Set((int) (pos + item.OwnerSlot*5 + 4), (byte) item.Template.InvType);

								character.Outfit[item.OwnerSlot] = item.Template.DisplayID;
							}
						if (character.Outfit[0] == -1)
							character.Outfit[0] = 0;
						character.Dirty = true;
						DBManager.SaveDBObject(character);
					}
					else
						for (int i = 0; i <= (int) INVSLOT.EQUIPPEDLAST; i++)
						{
							packet.Set(pos + i*5, character.Outfit[i]);
							packet.Set(pos + i*5 + 4, (byte) getSlotType((INVSLOT) i));
						}
					count++;
					if (count >= 10)
						break;
				}
			}

			packet.Set(4, count);
			Console.WriteLine("Characters found on account {0}: {1}, active: {2}", Client.Account.Name, Client.Account.Characters.Count, count);
			client.Send(packet);
		}

		private static INVTYPE getSlotType(INVSLOT slot)
		{
			switch (slot)
			{
				case INVSLOT.BACK:
					return INVTYPE.CLOAK;
				case INVSLOT.BODY:
					return INVTYPE.BODY;
				case INVSLOT.NECK:
					return INVTYPE.NECK;
				case INVSLOT.FEET:
					return INVTYPE.FEET;
				case INVSLOT.CHEST:
					return INVTYPE.CHEST;
				case INVSLOT.FINGER1:
				case INVSLOT.FINGER2:
					return INVTYPE.FINGER;
				case INVSLOT.HAND:
					return INVTYPE.HAND;
				case INVSLOT.HEAD:
					return INVTYPE.HEAD;
				case INVSLOT.LEGS:
					return INVTYPE.LEGS;
				case INVSLOT.TRINKET1:
				case INVSLOT.TRINKET2:
					return INVTYPE.TRINKET;
				case INVSLOT.WAIST:
					return INVTYPE.WAIST;
				case INVSLOT.WRIST:
					return INVTYPE.WRIST;
				case INVSLOT.OFFHAND:
					return INVTYPE.WEAPONOFFHAND;
				case INVSLOT.MAINHAND:
					return INVTYPE.WEAPONMAINHAND;
				case INVSLOT.RANGED:
					return INVTYPE.RANGED;
				case INVSLOT.SHOULDER:
					return INVTYPE.SHOULDER;
				case INVSLOT.TABARD:
					return INVTYPE.TABARD;
				default:
					return INVTYPE.NONE_EQUIP;
			}
		}


		private static void initAddons(byte[] compressed, int length, ClientBase client)
		{
			byte[] uncompressed = BufferPool.Instance.AquireBuffer(length);

			int nlength;
			ZLib.IODecompress(compressed, compressed.Length, uncompressed, out nlength);

			if (nlength != length)
			{
				LogConsole.WriteLine(LogLevel.ERROR,"Got bad addon data. Length {0}, uncompressed length {1}", compressed.Length, length);
				return;
			}

			ShortPacket addons = new ShortPacket(SMSG.ADDON_INFO); // addons

			BinReader data = new BinReader(uncompressed, length);

			while (data.BaseStream.Position < data.BaseStream.Length)
			{
				string name = data.ReadString();
				ulong crc = data.ReadUInt64();
				byte tmp = data.ReadByte();

				if (crc == 0x00000000A8A821FF)
				{
					LogConsole.WriteLine(LogLevel.ECHO, "Got blizzard addon {0}, crc 0x{1,16:X16}, tmp {2}", name, crc, tmp);
					addons.Write(0x0102);
					addons.Write(0);
				}
				else if (true)
				{
					LogConsole.WriteLine(LogLevel.TRACE, "Got non-blizzard addon {0}, crc 0x{1,16:X16}, tmp {2}", name, crc, tmp);

					addons.Write(0x010001);
				}
				else
				{
					addons.Write(0x0);
				}
			}

			addons.Write((byte) 0);

			client.Send(addons);

			BufferPool.Instance.ReleaseBuffer(uncompressed);
		}
	}
}
