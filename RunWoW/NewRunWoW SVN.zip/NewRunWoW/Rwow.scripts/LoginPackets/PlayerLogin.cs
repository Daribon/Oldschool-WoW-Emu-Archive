//
using System;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunWoW.World;
using RunWoW.WoWClasses;
using RunWoW.WoWRaces;

namespace RunWoW.LoginPackets
{
    [PacketHandlerClass()]
    public class PlayerLogin
    {
    	public static void WipeChar(DBCharacter character, string message, string reason)
    	{
			foreach (DBAbility ability in character.Abilities)
				Database.Instance.DeleteObject(ability);

			character.Abilities = null;
			character.Money = 0;
			character.Message = message;

			LogConsole.WriteLine(LogLevel.SYSTEM, "Wiped char {0} for {1}", character.Name, reason);
    	}
    	
        [PacketHandler(CMSG.PLAYER_LOGIN, ExecutionPriority.Pool)]
        public static void OnPlayerLogin(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData) client.Data;

            if (Client.Character != null)
            {
                client.Close("Tried to login another character.");
                return;
            }

            uint id = data.ReadUInt32();
            LogConsole.WriteLine(LogLevel.TRACE, "LoginClient:{0} CharID:{1}", Client.Account.Name, id);

            DateTime time = CustomDateTime.Now;
            DBCharacter character = null;

            foreach (DBCharacter nchar in Client.Account.Characters)
            {
            	ClientBase oldClient = ClientManager.GetClient(nchar.ObjectId);

				if (oldClient != null && !oldClient.Closed)
				{
					if (!client.RemoteEndPoint.Address.Equals(oldClient.RemoteEndPoint.Address))
					{
						ShortPacket packet = new ShortPacket(SMSG.AUTH_RESPONSE);
						packet.Write((byte)0x16);
						client.Send(packet);
						client.Close(string.Format("Account {0} tried to login with second char", Client.Account.Name));
						return;
					}
					else
						oldClient.Close("Other client logged in from same IP");
				}
		Console.WriteLine("ObjectId = {0}", nchar.ObjectId);
            	if (nchar.ObjectId == id)
                    character = nchar;
            }

            if (character == null)
            {
                client.Close("Failed to find character in database");
                return;
            }

        	Client.Account.Characters.Clear();
			Client.Account.Characters = null; // clean up unused chars
            /*if (c.AccountID != Client.Account.ObjectId)
			{
				client.Close("Tried to login another account's character.");
				return;
			}*/
            LogConsole.WriteLine(LogLevel.TRACE, "Character found in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

            //string[] RemoteIP = client.RemoteEndPoint.ToString().Split(':');
            //Client.Account.LastIP = RemoteIP[0];
            /*if(c.WorldMapID > 1)
			{
				client.Close(c.Name + " is has incorrect world map id.");
				return;
			}*/

			if (character.Items == null || character.Abilities == null || character.Actions == null)
				Database.Instance.ResolveRelations(character, true);

            LogConsole.WriteLine(LogLevel.TRACE, "Relations found in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

            ActionButtons actions = new ActionButtons(character);
            BaseRace bRace = Races.Instance[character.Race];
            BaseClass bClass = bRace.GetClass(character.Class);

			bool finish = false;
			Dictionary<ushort, ushort> ntalents = new Dictionary<ushort, ushort>();
			foreach (DBAbility ability in character.Abilities)
			{
				if (ability.Spell != null && ability.Spell.TempSkill != null)
					switch (ability.Spell.TempSkill.SkillID)
					{
						case (int)SKILL.BALANCE:
						case (int)SKILL.FERAL_COMBAT:
							if (character.Class != CLASS.DRUID)
							{
								WipeChar(character,
								         "� ������� ���� ������� ��� ����������, ��������� � ������ �� ������������� ���� � ������������ ������.",
								         "druid spells");
								finish = true;
							}
							break;
					}

				if (ability.TalentID != 0)
					ntalents[ability.TalentID] = ability.TalentID;
				
				if (finish)
					break;
			}

			if (ntalents.Count > 0)
			{
				int target = character.Level < 10 ? 0 : character.Level - 9;
				if (ntalents.Count + character.TalentPoints > target * 1.5)
					LogConsole.WriteLine(LogLevel.WARNING, "Player {0} has {1} talents on level {2}", character.Name, ntalents.Count + character.TalentPoints, character.Level);
			}
        	
            if (character.Abilities == null || character.Abilities.Count == 0) //new char
            {
                LogConsole.WriteLine(LogLevel.TRACE, "Creating start spells");
                bRace.AddSpells(character);
                bRace.AddSkills(character);
                bClass.AddSpells(character);
                bClass.AddSkills(character);

                foreach (DBAbility ability in character.Abilities)
                    if (ability.New)
                        DBManager.NewDBObject(ability);
                    else if (ability.Dirty)
                        DBManager.SaveDBObject(ability);

                character.TalentPoints = (byte) (character.Level < 10 ? 0 : character.Level - 9);
                character.ProfPoints = 2;
		if (character.Level == 1)
		{
			actions.SetStartActions();

            		ShortPacket prg = new ShortPacket(SMSG.TRIGGER_CINEMATIC);
			prg.Write(bRace.IntroMovie);
			client.Send(prg);
		}
                LogConsole.WriteLine(LogLevel.TRACE, "Created start spells in {0}",
                                     (CustomDateTime.Now - time).TotalMilliseconds);
            }
            else
            {
                int count = 0;
				            	
                for (int i = 0; i < character.Abilities.Count; i++)
                    switch (character.Abilities[i].SkillID)
                    {
                        case (int) SKILL.ALCHEMY:
                        case (int) SKILL.BLACKSMITHING:
                        case (int) SKILL.ENCHANTING:
                        case (int) SKILL.ENGENEERING:
                        case (int) SKILL.LEATHERWORKING:
                        case (int) SKILL.TAILORING:
                        case (int) SKILL.HERBALISM:
                        case (int) SKILL.MINING:
                        case (int) SKILL.SKINNING:
                        case (int) SKILL.JEWELCRAFTING:
                            count++;
                            break;
                    }

                //if (count < 2)
                    character.ProfPoints = (byte) (2 - count);

                if (character.TalentPoints == 255)
                    character.TalentPoints = (byte) (character.Level < 10 ? 0 : character.Level - 9);
            }


            /* else
			{
				bool found = false;
				for (int i = 0; i < c.Abilities.Length; i++)
					if (c.Abilities[i].SpellID == 6603)
					{
						found = true;
						break;
					}
				if (!found)
				{
					bRace.AddSpells(c);
					bClass.AddSpells(c); // fix wiped spells
					c.TalentPoints = c.Level < 10 ? 0 : c.Level - 9;
				}
			}*/
            bRace.CheckModel(character);
            bRace.FixClass(character);
            bRace.FixFaction(character);

            if (character.Strength == 0) // recalc char
                bRace.Stats(character);

            Client.Character = character;
            Client.Init();
            LogConsole.WriteLine(LogLevel.TRACE, "Registered player in world in {0}",
                                 (CustomDateTime.Now - time).TotalMilliseconds);
            Client.Player = ClientManager.RegisterPlayer(character, Client);
            if (Client.Player == null)
            {
            	// TODO: Send Login Failed packet
                client.Close("Player already in world!");
                return;
            }
            client.Send(actions.InitialActions());
            ConfigHandler.SendConfigCRC(client);

            ShortPacket w = new ShortPacket(SMSG.TUTORIAL_FLAGS);
            for (int i = 0; i < 8; i++)
                w.Write(character.TutorialFlags[i]);
        	
            client.Send(w);

            if (character.BindPoint.X == 0 && character.BindPoint.Y == 0 && character.BindPoint.Z == 0)
            {
                character.BindPoint = new Vector(Client.Player.bRace.StartPosition);
                character.BindZone = Client.Player.bRace.StartZone;
                character.BindWorld = Client.Player.bRace.StartWorld;
            }

            if (character.Facing > 10 || character.Facing < -10)
                character.Facing = 0;

            if (character.Position.Z > 100000 || character.Position.Z < -100000)
                character.Position.Z = 1;

            if (
                character.Position.X > 100000 || character.Position.Y > 100000 ||
                character.Position.X < -100000 || character.Position.Y < -100000
                )
            {
                character.Position = character.BindPoint;
                character.Zone = character.BindZone;
                character.WorldMapID = character.BindWorld;
            }

            ShortPacket bp = new ShortPacket(SMSG.BINDPOINTUPDATE);
            bp.WriteVector(character.BindPoint);
            bp.Write(character.BindWorld);
            bp.Write(character.BindZone);
            client.Send(bp);

            initFactions(client);
            initialSpells(client);

            // Send Server Time to the client
//            initTime(client);

            //initWorldState(client);

            //
            LogConsole.WriteLine(LogLevel.SYSTEM, "Preparation done in {0}",
                                 (CustomDateTime.Now - time).TotalMilliseconds);

            MapManager.PlayerEnterWorld(Client);
            LogConsole.WriteLine(LogLevel.SYSTEM, "Entered world in {0}", (CustomDateTime.Now - time).TotalMilliseconds);


            if (Client.Player.Character.GroupID != 0)
            {
                Client.Player.Group = GroupManager.FindGroup(Client.Player.Character.GroupID);
                if (Client.Player.Group != null && Client.Player.Group.UpdateMember(Client.Player))
                    Client.Player.Group.Update();
                else
                    Client.Player.Group = null;
            }

            Client.Player.AccessLvl = Client.Account.AccessLvl;
            Client.Player.Actions = actions;
            Client.Player.Skills.UpdateProficiencies();

            Chat.System(client, Constants.Greetings);
            Chat.System(client, Constants.Server + Constants.Version);
            Chat.System(client, Constants.Online + (ClientManager.OnlineCount));
        	
        	if (character.Message != string.Empty)
				Chat.System(client, character.Message);
        		
            if (Client.Account.Name == Client.Account.Password)
                Chat.System(client, Constants.NoPassword);
            Chat.System(client, Constants.AdditionalInfo);
            if (Constants.MoreInfo.Length > 0)
                Chat.System(client, Constants.MoreInfo);
			LogConsole.WriteLine(LogLevel.SYSTEM, "All done in {0}", (CustomDateTime.Now - time).TotalMilliseconds);

            Guild.SendGuildEvent(character.Guild, GuildEvent.MOTD, null, client);
            
        }

	[PacketHandler(CMSG.LOGOUT_REQUEST, ExecutionPriority.Pool)]
        public static void OnLogoutRequest(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData) client.Data;
            ShortPacket pkg = new ShortPacket(SMSG.LOGOUT_RESPONSE);
            pkg.Write(0);
            if (Client == null || Client.Player == null)
                return;

            if (Client.Player.Attacking || Client.Player.Casting)
            {
                pkg.Write((byte) 1); //Logout rejected
            }
            else
            {
                pkg.Write((byte) 0); //Logout accepted 
                Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);
                Client.Player.StandState = UNITSTANDSTATE.SITTING;
                Client.Player.UpdateData();
                Client.Player.CastEvent = new LogoutEvent(client);
                Client.Player.CastEvent.Start();
            }
            client.Send(pkg);
        }

	[PacketHandler(CMSG.PLAYER_LOGOUT, ExecutionPriority.Pool)]
        public static void OnPlayerLogout(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData) client.Data;
            if (Client == null || Client.Player == null)
                return;

            if (!Client.Player.GM)
                if (
					data != null ||
                    Client.Player.Attacking ||
                    !(Client.Player.CastEvent is LogoutEvent)
                    )
                {
                    client.Send(new ShortPacket(SMSG.LOGOUT_CANCEL_ACK));
                    return;
                }
            client.Send(new ShortPacket(SMSG.LOGOUT_COMPLETE));

            Console.WriteLine("Player " + Client.Player.Name + " trying to logout");
            ClientManager.UnregisterPlayer(Client.Player, true);
            Client.Cleanup(true);
        }

        [PacketHandler(CMSG.LOGOUT_CANCEL)]
        public static void OnLogoutCancel(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData) client.Data;
            if (Client == null || Client.Player == null)
                return;
            client.Send(new ShortPacket(SMSG.LOGOUT_CANCEL_ACK));
            Client.Player.CancelCast(SpellFailedReason.SPELL_FAILED_DONT_REPORT);
        }

        private static void initTime(ClientBase client)
        {
            /*DateTime time=CustomDateTime.Now;	
			uint timeSeq = 0;
			
			// 4 bytes of packed time data.  the bits are:	
			// high 2 bits - unknown
			timeSeq|=(uint)0;
			// next 5 bits - year
			timeSeq<<=5;
			timeSeq|=(uint)time.Year;
			// next 4 bits - month
			timeSeq<<=4;
			timeSeq|=(uint)time.Month;
			// next 7 bits - day of month
			timeSeq<<=7;
			timeSeq|=(uint)time.Day;
			// next 3 bits - day of week
			timeSeq<<=3;
			timeSeq|=(uint)time.DayOfWeek;
			// next 5 bits - hours
			timeSeq<<=5;
			timeSeq|=(uint)((time.Hour==0) ? 24 : time.Hour );
			//timeSeq|=(uint)time.Hour;
			// low 6 bits  - minutes
			timeSeq<<=6;
			timeSeq|=(uint)time.Minute;
                        */

            /*ShortPacket lts = new ShortPacket(SMSG.LOGIN_SETTIMESPEED);

            lts.Write(Utility.PreciseTimestamp());
            lts.Write((byte)0x89);
            lts.Write((byte)0x88);
            lts.Write((byte)0x88);
            lts.Write((byte)0x3c);
            client.Send(lts);*/

            ShortPacket pkg = new ShortPacket(SMSG.GAMETIME_UPDATE);
            pkg.Write(Utility.Timestamp());
            client.Send(pkg);
        }

        private static void initWorldState(ClientBase client)
        {
            ClientData Client = (ClientData) client.Data;

            ShortPacket pkg = new ShortPacket(SMSG.INIT_WORLD_STATES);
            pkg.Write(Client.Player.WorldMapID);
            pkg.Write((short)6/*Client.Player.Zone*/);
            for (int i = 0; i < 5; i++)
            {
                pkg.Write(2264 - i);
                pkg.Write(-1);
            }

            client.Send(pkg);
        }

		private static void initialSpells(ClientBase client)
		{
			ClientData Client = (ClientData) client.Data;

			ShortPacket pkg = new ShortPacket(SMSG.INITIAL_SPELLS);

			pkg.Write((byte) 0);
			pkg.Write((ushort) 0); //// Number of abilites/spells

			ushort count = 0;

			List<DBAbility> cooldowns = new List<DBAbility>();
			foreach (DBAbility ability in Client.Character.Abilities)
				if (ability.SpellID != 0)
				{
					pkg.Write(ability.SpellID);
					pkg.Write((ushort) 0xeeee); //unknown 0x0 or 0xeeee
					count++;

					if (ability.Cooldown > CustomDateTime.Now)
						cooldowns.Add(ability);
				}
			pkg.Set(5, count);

			pkg.Write((ushort)cooldowns.Count);
			foreach (DBAbility ability in cooldowns)
			{
				pkg.Write(ability.SpellID);

				if (ability.SpellID == 8690) // hearthstone, TODO: other items
				{
					pkg.Write((ushort) 6948); // item template
					pkg.Write((short) 0x24); // spell category
				} else
				{
					pkg.Write((ushort) 0); // item template
					pkg.Write((short) 0); // spell category
				}
				if (true)	//if (spell category)
				{
					pkg.Write(0);
					pkg.Write((int)(CustomDateTime.Now - ability.Cooldown).TotalMilliseconds);
				}
				else
				{
					pkg.Write((int)(CustomDateTime.Now - ability.Cooldown).TotalMilliseconds);
					pkg.Write(0);
				}
			}

			client.Send(pkg);
		}


    	private static void initFactions(ClientBase client)
        {
            ClientData Client = (ClientData) client.Data;
            
            ShortPacket w = new ShortPacket(SMSG.INITIALIZE_FACTIONS);
            
            w.Write(64/*Client.Player.Reputations.Reputations.Length*/);
            
            for (int i = 0; i < 64; i++)
                {
                    w.Write(Client.Player.Reputations.Reputations[i].State);
                    w.Write(Client.Player.Reputations.Reputations[i].Value);	//Standing in Mangos
                }
            client.Send(w);
        }
    }
}