//
using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.Objects;

namespace RunWoW.LoginPackets
{
	[ServerHandlerClass()]
	internal class FinishClass
	{
		[ServerHandler(IMSG.CLIENT_DISCONNECTED)]
		public static void CleanupClient(ClientBase client)
		{
			if (client != null && client.Data != null)
			{
				ClientData Client = (ClientData) client.Data;
				PlayerObject player = Client.Player;
				if (player != null)
				{
					string name = player.Name;
					Console.WriteLine("Player {0} logouting by disconnect", name);
					Client.Cleanup(player.ForceClean);
					ClientManager.UnregisterPlayer(player, player.ForceClean);
				}
				Client.Account = null;
				client.Data = null;
			}
		}
	}
}