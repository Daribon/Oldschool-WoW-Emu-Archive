using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Paladin : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.PALADIN; }
		}

		public Paladin(int BHealth, int BPower)
			: base(1.1f, 0.6f, 1.2f, 0.7f, 0.77f, POWERTYPE.MANA, BHealth, BPower, 2900, 2000, 6.0f, 7.0f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			//AddSpell(679,2); // Holy Strike
			AddSpell(20154, 2); // Seal
			AddSpell(635, 3); // Holy Light
			AddSpell(SPELLSKILL.BLOCK); // Block

			AddSkill(0, 184, 1, 1); // Combat
			AddSkill(0, 56, 1, 1); // Holy
			AddSkill(0, 257, 1, 1); // Protection
			AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
			AddSkill(SPELLSKILL.TWOHANDBLUNT, SKILL.TWOHANDBLUNT, 1, 300); // 2H Maces
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
			AddSkill(SPELLSKILL.LEATHER, SKILL.LEATHER, 1, 1); // Leather
			AddSkill(SPELLSKILL.MAIL, SKILL.MAIL, 1, 1); // Mail
			AddSkill(SPELLSKILL.SHIELD, SKILL.SHIELD, 1, 1); // Shield 
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Level*3 + Str*2 - 20;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 14 ? 18 : level + 4);
		}

		public override short PowerGain(int level)
		{
			return (short) (level <= 25 ? level + 17 : 42);
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return 15f + Spr/5f;
		}
	}
}