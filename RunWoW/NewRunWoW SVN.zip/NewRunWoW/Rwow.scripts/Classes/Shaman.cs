using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Shaman : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.SHAMAN; }
		}

		public Shaman(int BHealth, int BPower)
			: base(0.81f, 0.5f, 0.9f, 0.9f, 1.0f, POWERTYPE.MANA /*POWERTYPE.FOCUS*/, BHealth, BPower, 2000, 2000, 2.0f, 4.0f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(403, 2); // Lightning Bolt
			AddSpell(331, 3); // Healing Wave
			AddSpell(SPELLSKILL.BLOCK); // Block

			AddSkill(0, 375, 1, 1); // Elemental combat
			AddSkill(0, 373, 1, 1); // Enhancement*/
			AddSkill(SPELLSKILL.ONEHANDBLUNT, SKILL.ONEHANDBLUNT, 1, 300); // Maces
			AddSkill(SPELLSKILL.STAFF, SKILL.STAFF, 1, 300); // Staves
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
			AddSkill(SPELLSKILL.LEATHER, SKILL.LEATHER, 1, 1); // Leather
			AddSkill(SPELLSKILL.SHIELD, SKILL.SHIELD, 1, 1); // Shield
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Level*2 + Str*2 - 20;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 16 ? 17 : level + 1);
		}

		public override short PowerGain(int level)
		{
			return (short) (level <= 32 ? level + 19 : 52);
		}


		public override float CalculatePRegen(int Level, int Spr)
		{
			return 17f + Spr/5f;
		}
	}
}