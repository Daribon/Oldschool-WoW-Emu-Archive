using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Warlock : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.WARLOCK; }
		}

		public Warlock(int BHealth, int BPower)
			: base(0.37f, 0.4f, 0.7f, 1.2f, 0.7f, POWERTYPE.MANA, BHealth, BPower, 1600, 2000, 3.28f, 5.28f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(686, 3); // Shadow Bolt
			AddSpell(687, 4); // Demon Skin
			AddSpell(SPELLSKILL.SHOOT, 2); // Shoot

			AddSkill(0, 354, 1, 1); // Demonology
			AddSkill(0, 593, 1, 1); // Destruction
			AddSkill(SPELLSKILL.DAGGER, SKILL.DAGGER, 1, 300); // Daggers
			AddSkill(SPELLSKILL.WAND, SKILL.WAND, 1, 300); // Wands
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Str - 10;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 17 ? 15 : level - 2);
		}

		public override short PowerGain(int level)
		{
			return (short) (level <= 30 ? level + 21 : 51);
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return 15f + Spr/5f;
		}
	}
}