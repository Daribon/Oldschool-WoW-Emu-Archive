using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Druid : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.DRUID; }
		}

		public Druid(int BHealth, int BPower)
			: base(0.6f, 0.5f, 0.66f, 1.0f, 1.1f, POWERTYPE.MANA, BHealth, BPower, 2000, 2000, 2.0f, 4.0f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSkill(0, 574, 1, 1); // Balance
			AddSkill(0, 374, 1, 1); // Restoration

			AddSpell(5176, 3); // Wrath
			AddSpell(5185, 4); // Healing Touch

			AddSkill(SPELLSKILL.STAFF, SKILL.STAFF, 1, 300); // Staves
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
			AddSkill(SPELLSKILL.LEATHER, SKILL.LEATHER, 1, 1); // Leather
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Str*2 - 20;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 17 ? 17 : level);
		}

		public override short PowerGain(int level)
		{
			return (short) (level <= 25 ? level + 20 : 45);
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return 15f + Spr/5f;
		}
	}
}