using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Mage : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.MAGE; }
		}

		public Mage(int BHealth, int BPower)
			: base(0.14f, 0.2f, 0.33f, 1.44f, 1.33f, POWERTYPE.MANA, BHealth, BPower, 2000, 2000, 2.0f, 4.0f)
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(133, 3); // Fireball
			AddSpell(168, 4); // Frost Armor
			AddSpell(SPELLSKILL.SHOOT, 2); // Shoot

			AddSkill(0, 6, 1, 1); // Frost
			AddSkill(0, 8, 1, 1); // Fire
			AddSkill(SPELLSKILL.STAFF, SKILL.STAFF, 1, 300); // Staves
			AddSkill(SPELLSKILL.WAND, SKILL.WAND, 1, 300); // Wands
			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
		}

		
		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Str - 10;
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 25 ? 15 : level - 8);
		}

		public override short PowerGain(int level)
		{
			return (short) (level <= 27 ? level + 23 : 51);
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return 12.5f + Spr/4f;
		}
	}
}