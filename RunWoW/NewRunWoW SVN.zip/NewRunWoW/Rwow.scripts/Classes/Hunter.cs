//
using RunWoW.Common;

namespace RunWoW.WoWClasses
{
	public class Hunter : BaseClass
	{
		public override CLASS ClassID
		{
			get { return CLASS.HUNTER; }
		}

		public Hunter(int BHealth, int BPower)
			: base(0.49f, 1.3f, 0.89f, 0.6f, 0.66f, POWERTYPE.MANA, BHealth, BPower, 2000, 2000, 5.0f, 7.0f)
			//Focus is not avalible now. Mana is right.
		{
		}

		public override void InitNewbie()
		{
			base.InitNewbie();

			AddSpell(2973, 4); // Raptor Strike
			AddSpell(75, 3); // Auto Shot

			AddSkill(0, 50, 1, 1); // Beast Mastery
			AddSkill(0, 163, 1, 1); // Marksmanship
			AddSkill(0, 51, 1, 1); // Survival

			AddSkill(SPELLSKILL.CLOTH, SKILL.CLOTH, 1, 1); // Cloth
			AddSkill(SPELLSKILL.LEATHER, SKILL.LEATHER, 1, 1); // Leather
		}

		public override int CalculateAP(int Level, int Str, int Ag)
		{
			return Level*2 + Str + Ag - 20;
		}

		public override int CalculateRangedAP(int Level, int Str, int Ag)
		{
			return Level*2 + Ag*2 - 20;
		}

		public override float CalculateDodge(int Level, int Agi)
		{
			return (float) Agi/((float) Level*0.41f + 1.476f); // /26.5 for 60
		}

		public override short HealthGain(int level)
		{
			return (short) (level <= 13 ? 17 : level + 4);
		}

		public override short PowerGain(int level)
		{
			return (short) (level <= 27 ? level + 18 : 45);
		}

		public override float CalculatePRegen(int Level, int Spr)
		{
			return 15f + Spr/5f;
		}
	}
}