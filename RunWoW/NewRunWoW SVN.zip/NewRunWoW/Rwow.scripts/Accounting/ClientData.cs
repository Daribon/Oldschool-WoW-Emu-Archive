//
using System;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Objects;

namespace RunWoW.Accounting
{
	public class ClientData
	{
		private DBAccount m_account = null;
		private DBCharacter m_character = null;
		private PlayerObject m_player = null;

		private int m_delay = 0;

		private int m_clientTimeDelay = 0;

		private string m_LocalDefenseChannel = string.Empty;
		private DateTime m_lastLocalDefense;

		private DateTime m_connectTime;
		private DateTime m_lastMovement;
#if USE_IRC
	private IRCChat m_chat = null;
#endif
		private ClientBase m_client;
		private byte[] m_addons;
		private int m_addonsLength;

		private int m_clientVersion;
		
		public ClientData(ClientBase parent)
		{
			m_client = parent;
			m_connectTime = CustomDateTime.Now;
			m_lastMovement = CustomDateTime.Now;
		}

		public DateTime ConnectTime
		{
			get { return m_connectTime; }
		}

		public DateTime LastMovement
		{
			get { return m_lastMovement; }
			set { m_lastMovement = value; }
		}

		public DBAccount Account
		{
			get { return m_account; }
			set { m_account = value; }
		}

		public DBCharacter Character
		{
			get { return m_character; }
			set { m_character = value; }
		}

		public ClientBase Client
		{
			get { return m_client; }
		}

		public PlayerObject Player
		{
			get { return m_player; }
			set { m_player = value; }
		}

		public int Delay
		{
			get { return m_delay; }
			set { m_delay = value; }
		}
		
		public int ClientTimeDelay
		{
			get { return m_clientTimeDelay; }
			set { m_clientTimeDelay = value; }
		}

		public int ClientTime
		{
			get { return Utility.PreciseTimestamp() - m_clientTimeDelay; }
		}

		public int OwnTimestamp
		{
			get { return ClientTime + 2*m_delay + 1000; }
		}


#if USE_IRC
	public IRCChat Chat
		{
			get { return m_chat; }
		}
#endif

		public uint CharacterID
		{
			get { return m_character.ObjectId; }
		}

		public string LocalDefenseChannel
		{
			get { return m_LocalDefenseChannel; }
			set { m_LocalDefenseChannel = value; }
		}

		public DateTime LastLocalDefense
		{
			get { return m_lastLocalDefense; }
			set { m_lastLocalDefense = value; }
		}

		public byte[] Addons
		{
			get { return m_addons; }
			set { m_addons = value; }
		}

		public int AddonsLength
		{
			get { return m_addonsLength; }
			set { m_addonsLength = value; }
		}

		public int ClientVersion
		{
			get { return m_clientVersion; }
			set { m_clientVersion = value; }
		}

		public void Init()
		{
			if (m_character == null)
				return;
			m_character.RestedPoints +=
				(int) ((CustomDateTime.Now - m_character.LastAccess).TotalMilliseconds/Constants.MillisecondsPerRPoint);
			if (m_character.RestedPoints > Constants.MaximumRPoints)
				m_character.RestedPoints = Constants.MaximumRPoints;
#if USE_IRC
	m_chat = new IRCChat(Client);
			m_chat.Logon();
#endif
			Guild.SendGuildEvent(m_character.Guild, GuildEvent.ONLINE, m_character);
			Friends.FriendsState(FRIENDSTATUS.ONLINE, m_character);
		}

		public void Cleanup(bool force)
		{
			if (m_player != null && m_player.Character!=null && !m_player.Disposed)
			{
				Guild.SendGuildEvent(m_character.Guild, GuildEvent.OFFLINE, m_character);
				Friends.FriendsState(FRIENDSTATUS.OFFLINE, m_character);
				
				if (m_player.Pet != null)
					m_player.Pet.Dispose();

				if (m_character != null)
					m_character.LastAccess = CustomDateTime.Now;

				m_player.Save();

				if (force)
				{
					m_player.Dispose();
					m_player = null;
					m_character = null;
				}
				else
					m_player.Disconnect();
			}
#if USE_IRC
	if (m_chat != null)
			{
				m_chat.Logoff();
				m_chat = null;
			}
#endif
			//m_timedPackets.Clear();
			//m_timedArray = null;
		}

		#region Movement Queue

		private class MovementHolder
		{
			private ShortPacket m_packet;
			private DateTime m_launchTime;
			
			public ShortPacket Packet
			{
				get { return m_packet; }
			}

			public DateTime LaunchTime
			{
				get { return m_launchTime; }
			}

			public MovementHolder(ShortPacket packet, DateTime launchTime)
			{
				m_packet = packet;
				m_launchTime = launchTime;
			}
		}

		private class PositionHolder
		{
			private Vector m_position;
			private DateTime m_time;

			public Vector Position
			{
				get { return m_position; }
			}

			public DateTime Time
			{
				get { return m_time; }
			}

			public PositionHolder(Vector position, DateTime time)
			{
				m_position = position;
				m_time = time;
			}
		}

		/*private MovementHolder[] m_timedArray = new MovementHolder[100];
		private object m_timedSyncRooot = new object();
		private Stack<PositionHolder> m_timedPositions = new Stack<PositionHolder>(50);*/

		private static int MovementDelay = 400;

		public void AddMovementPacket(ShortPacket packet, int delay, int timePos)
		{
			int time = MovementDelay + delay + m_delay;
			packet.Set(timePos, Utility.PreciseTimestamp() + time + 100);

			Client.Send(packet);

			//MovementHolder holder = new MovementHolder(packet.Clone(), CustomDateTime.Now.AddMilliseconds(time));

			//bool added = false;
			//lock (m_timedSyncRooot)
			//    for (int i = 0; i < m_timedArray.Length; i++)
			//        if (m_timedArray[i] == null)
			//        {
			//            m_timedArray[i] = holder;
			//            added = true;
			//            break;
			//        }

			//ProcessMovementPackets();

			//if (!added)
			//    Client.Close("Movement buffer overload");
		}

		public void ProcessMovementPackets()
		{
			//if (Client == null)
			//    return;

			//LinkedList<MovementHolder> toSend = new LinkedList<MovementHolder>();

			//lock (m_timedArray)
			//for (int i = 0; i < m_timedArray.Length; i++)
			//{
			//    MovementHolder holder = m_timedArray[i];

			//    if (holder != null && holder.LaunchTime < CustomDateTime.Now)
			//    {
			//        m_timedArray[i] = null;

			//        bool added = false;
			//        if (toSend.Count > 0 && toSend.Last.Value.LaunchTime > holder.LaunchTime)
			//        {
			//            LinkedListNode<MovementHolder> node = toSend.First;
			//            while (node != null)
			//            {
			//                if (node.Value.LaunchTime > holder.LaunchTime)
			//                {
			//                    toSend.AddBefore(node, holder);
			//                    added = true;
			//                    break;
			//                }
			//                node = node.Next;
			//            }
			//        }

			//        if (!added)
			//            toSend.AddLast(holder);
			//    }
			//}

			//foreach (MovementHolder holder in toSend)
			//    Client.Send(holder.Packet);

		}

		public void AddMovementPosition(Vector position, int delay)
		{
			
			//lock (m_timedPositions)
			//{
			//    m_timedPositions.Push(new PositionHolder(position, CustomDateTime.Now.AddMilliseconds(delay)));

			//    if ((CustomDateTime.Now - m_timedPositions.Peek().Time).TotalSeconds > 2)
			//        m_timedPositions.Pop();
			//}
		}

		public Vector GetMovementPosition(DateTime time)
		{
			return m_player.Position;
			//lock (m_timedPositions)
			//{
			//    if (m_timedPositions.Count == 0)
			//        return m_player.Position;

			//    DateTime targetTime = time.AddMilliseconds(-MovementDelay - 1000);

			//    if (targetTime < m_timedPositions.Peek().Time)
			//        return m_player.Position;

			//    foreach (PositionHolder holder in m_timedPositions)
			//    {
			//        if (targetTime > holder.Time)
			//            continue;

			//        return holder.Position;
			//    }
			//    return m_player.Position;
			//}
		}

		#endregion
	}
}