//
using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.DB.DataTables;

namespace RunWoW.ServerDatabase
{
	public class AuthBase
	{
		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			DBFlags globalFlags = DBFlags.None;
			if (Constants.ExternalIndexes)
				globalFlags |= DBFlags.NoIndex;

			if (Constants.ForceFlushUpdates)
				globalFlags |= DBFlags.FlushUpdate;

			Database.Instance.RegisterDataObject<DBAccount>(globalFlags | DBFlags.DynCached | DBFlags.FlushLoad | DBFlags.FlushUpdate | DBFlags.ForceLoad | DBFlags.NoIndex, 0);
			Database.Instance.RegisterDataObject<DBCharacter>(globalFlags | DBFlags.DynCached | DBFlags.LargeUpdates, 0);
			Database.Instance.RegisterDataObject<DBFriendList>(globalFlags | DBFlags.DynCached | DBFlags.LargeUpdates, 0);
			Database.Instance.RegisterDataObject<DBAbility>(globalFlags | DBFlags.DynCached | DBFlags.LargeUpdates | DBFlags.NoIndex, 0);
			Database.Instance.RegisterDataObject<DBGuild>(globalFlags | DBFlags.DynCached , 0);
			Database.Instance.RegisterDataObject<DBActionButton>(globalFlags | DBFlags.DynCached | DBFlags.LargeUpdates | DBFlags.NoIndex, 0);
			Database.Instance.RegisterDataObject<DBItem>(globalFlags /*| DBFlags.FlushUpdate*/ | DBFlags.DynCached | DBFlags.LargeUpdates | DBFlags.NoIndex, 0);
			Database.Instance.RegisterDataObject<DBPet>(globalFlags | DBFlags.DynCached, 0);
			Database.Instance.RegisterDataObject<DBPetSpell>(globalFlags | DBFlags.DynCached | DBFlags.None, 0);
			Database.Instance.RegisterDataObject<DBMail>(globalFlags | DBFlags.DynCached/* | DBFlags.FlushUpdate*/, 0);
			Database.Instance.RegisterDataObject<DBMailMessage>(globalFlags | DBFlags.DynCached | DBFlags.FlushUpdate, 0);
			Database.Instance.RegisterDataObject<DBAuction>(globalFlags | DBFlags.DynCached | DBFlags.FlushUpdate, 0);
			Database.Instance.RegisterDataObject<DBBid>(globalFlags | DBFlags.DynCached/* | DBFlags.FlushUpdate*/, 0);
			Database.Instance.RegisterDataObject<DBQuestLog>(globalFlags | DBFlags.DynCached | DBFlags.LargeUpdates | DBFlags.NoIndex, 0);
		}

		[InitializeHandler(InitPass.Fourth)]
		public static void CoInitialize()
		{
		}
	}
}