//
using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunServer.Database;
using RunServer.Database.Connection;

namespace RunWoW.ServerDatabase
{
	public class Database
	{
		public static ObjectDatabase Instance;

		[InitializeHandler]
		public static void Initialize()
		{
			LogConsole.WriteLine(LogLevel.TRACE, "Loading database");
			try
			{
				Instance = new ObjectDatabase
					(new DataConnection[]
					 	{
					 		new DataConnection((ConnectionType) Constants.MainConnectionType, Constants.MainConnectionString),
					 		new DataConnection((ConnectionType) Constants.DynamicConnectionType, Constants.DynamicConnectionString),
					 	}
					);
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error: " + e);
				return;
			}
		}

		[InitializeHandler(InitPass.Third)]
		public static void CoInitialize()
		{
			LogConsole.WriteLine(LogLevel.TRACE, "Generating proxies");
			Instance.GenerateProxies();
			LogConsole.WriteLine(LogLevel.TRACE, "done");
			LogConsole.WriteLine(LogLevel.TRACE, "Resolving indexes");
			Instance.ResolveIndexes();
		}

		public static void DoFinalize()
		{
			LogConsole.WriteLine(LogLevel.SYSTEM, "Saving database");
			try
			{
				Instance.FlushTables();
					//WriteDatabaseTables();
				Instance = null;
				//System.GC.Collect();
			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error: " + e);
				return;
			}
		}

/*		public static void ConvertTo(ConnectionType ct,string par)
		{
			Instance.WriteDatabaseTableTo(new DataConnection(ct,par));
		}*/
	}
}