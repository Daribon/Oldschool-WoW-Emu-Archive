//
using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.DB.DataTables;
using RunWoW.World;

namespace RunWoW.ServerDatabase
{
	public class WorldBase
	{
		public static PooledList<DBLoot> WorldLoot;

		public static List<uint> Worlds = new List<uint>(new uint[] { 0, 1, 30, 37, 169, 269, 369, 449, 450, 489, 529, 530, 534, 559, 560});
		
		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			DBFlags cacheFlag = Constants.NoInnerCache ? DBFlags.None : DBFlags.Cached;

			Database.Instance.RegisterDataObject<DBQuest>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBCreature>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBMovepoint>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBMonsterSpell>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBSpawn>(DBFlags.None, 1);
			Database.Instance.RegisterDataObject<DBGameObject>(DBFlags.None, 1);
			Database.Instance.RegisterDataObject<DBWorldMap>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBAreaTrigger>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBArea>(cacheFlag, 1);
		}

		[InitializeHandler(InitPass.Fourth)]
		public static void CoInitialize()
		{
			try
			{
				Database.Instance.LoadDatabaseTable(typeof(DBQuest));
				Database.Instance.LoadDatabaseTable(typeof(DBItemLoot));
				Database.Instance.LoadDatabaseTable(typeof(DBItemTemplate));
				Database.Instance.LoadDatabaseTable(typeof(DBGOTemplate));

				Database.Instance.LoadDatabaseTable(typeof(DBItemRandomProperties));
				Database.Instance.LoadDatabaseTable(typeof(DBRandomGroup));

				Database.Instance.LoadDatabaseTable(typeof(DBSpellCost));
				Database.Instance.LoadDatabaseTable(typeof(DBNSkill));
				Database.Instance.LoadDatabaseTable(typeof(DBSpell));
				Database.Instance.LoadDatabaseTable(typeof(DBMonsterSpell));
				Database.Instance.LoadDatabaseTable(typeof(DBLoot));
				Database.Instance.LoadDatabaseTable(typeof(DBTrain));
				Database.Instance.LoadDatabaseTable(typeof(DBTrade));
				Database.Instance.LoadDatabaseTable(typeof(DBGOLoot));

				Database.Instance.LoadDatabaseTable(typeof(DBCreature));
				Database.Instance.LoadDatabaseTable(typeof(DBMovepoint));
				Database.Instance.LoadDatabaseTable(typeof(DBSpawn));
				Database.Instance.LoadDatabaseTable(typeof(DBGameObject));
				Database.Instance.LoadDatabaseTable(typeof(DBArea));
				Database.Instance.LoadDatabaseTable(typeof(DBAreaTrigger));
				Database.Instance.LoadDatabaseTable(typeof(DBWorldMap));

			}
			catch (Exception e)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error: " + e);
			}
			
			ICollection worldMaps = Database.Instance.SelectAllObjects(typeof(DBWorldMap));
			foreach (DBWorldMap worldMap in worldMaps)
			{
				LogConsole.WriteLine(LogLevel.SYSTEM, "Initing map " + worldMap.ObjectId);
				Database.Instance.ResolveRelations(worldMap, true);

				if (Worlds.Contains(worldMap.ObjectId))
				{
					MapManager.InitWorldMap(worldMap);
					worldMap.Spawns = null;
					worldMap.GameObjects = null;
				} else
					MapManager.InitInstanceMap(worldMap);


				//foreach(DBSpawn spawn in worldMap.Spawns)
				//    if (spawn.Active && !spawn.Resolved)
				//        Database.Instance.ResolveRelations(spawn, true);
				
				//foreach (DBGameObject go in worldMap.GameObjects) 
				//    if (go.Active && !go.Resolved)
				//        Database.Instance.ResolveRelations(go, true);
			}

			if (Constants.WorldLootGroupID != 0)
			{
				WorldLoot = (PooledList<DBLoot>)Database.Instance.FindObjectsByField(typeof(DBLoot), "LootGroupID", (uint)Constants.WorldLootGroupID);

				if (Constants.WorldLootDivider != 1f)
					foreach (DBLoot loot in WorldLoot)
					{
						loot.Percentage /= Constants.WorldLootDivider;
						loot.WorldLoot = true;
					}

				Console.WriteLine("Loaded {0} object to world loot list, group {1}", WorldLoot.Count, Constants.WorldLootGroupID);
			}

			Database.Instance.ReleaseDatabaseTable(typeof(DBSpawn));
			Database.Instance.ReleaseDatabaseTable(typeof(DBGameObject));
			Database.Instance.ReleaseDatabaseTable(typeof(DBMovepoint));
			Database.Instance.ReleaseDatabaseTable(typeof(DBMonsterSpell));
			Database.Instance.ReleaseDatabaseTable(typeof(DBLoot));
			Database.Instance.ReleaseDatabaseTable(typeof(DBText));
			Database.Instance.ReleaseDatabaseTable(typeof(DBDialog));
			Database.Instance.ReleaseDatabaseTable(typeof(DBSpeech));
			//Database.Instance.ReleaseDatabaseTable(typeof(DBTrade));
			//Database.Instance.ReleaseDatabaseTable(typeof(DBTrain));
			//Database.Instance.ReleaseDatabaseTable(typeof(DBGOLoot));
			//Database.Instance.ReleaseDatabaseTable(typeof(DBCreature));
			//Database.Instance.ReleaseDatabaseTable(typeof(DBGOTemplate));

			//try
			//{
			//    LogConsole.WriteLine(LogLevel.SYSTEM, "Loading auth DB");

			//    Database.Instance.LoadDatabaseTable(typeof(DBAbility));
			//    Database.Instance.LoadDatabaseTable(typeof(DBItem));
			//    Database.Instance.LoadDatabaseTable(typeof(DBPet));
			//    Database.Instance.LoadDatabaseTable(typeof(DBPetSpell));
			//    Database.Instance.LoadDatabaseTable(typeof(DBQuestLog));
			//    Database.Instance.LoadDatabaseTable(typeof(DBGuild));

			//    Database.Instance.LoadDatabaseTable(typeof(DBCharacter));
			//    Database.Instance.LoadDatabaseTable(typeof(DBFriendList));

			//    Database.Instance.LoadDatabaseTable(typeof(DBMail));
			//    Database.Instance.LoadDatabaseTable(typeof(DBMailMessage));
			//    Database.Instance.LoadDatabaseTable(typeof(DBAuction));
			//    Database.Instance.LoadDatabaseTable(typeof(DBBid));

			//    LogConsole.WriteLine(LogLevel.SYSTEM, "Done");
			//}
			//catch (Exception e)
			//{
			//    LogConsole.WriteLine(LogLevel.ERROR, "Error: " + e);
			//}

			GC.WaitForPendingFinalizers();
			GC.Collect();
			GC.WaitForPendingFinalizers();
			
			PooledList<DBWorldMap>.Pool.Free();
			PooledList<DBSpawn>.Pool.Free();
			PooledList<DBLoot>.Pool.Free();
			PooledList<DBGameObject>.Pool.Free();

			Console.WriteLine("Spawns left in memory: {0}", DBSpawn.Count);
		}
	}
}