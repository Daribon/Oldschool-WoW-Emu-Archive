using RunServer.Common.Attributes;
using RunServer.Database;
using RunWoW.DB.DataTables;

namespace RunWoW.ServerDatabase
{
	public class ItemBase
	{
		[InitializeHandler(InitPass.Second)]
		public static void Initialize()
		{
			DBFlags cacheFlag = Constants.NoInnerCache ? DBFlags.None : DBFlags.Cached;

			Database.Instance.RegisterDataObject<DBItemLoot>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBItemTemplate>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBGOTemplate>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBItemRandomProperties>(cacheFlag, 1);
			Database.Instance.RegisterDataObject<DBRandomGroup>(cacheFlag, 1);
		}
	}
}