//
using System;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Spells;
using RunWoW.World;

namespace RunWoW.Events
{
	public abstract class SpellCastEvent : Event
	{
		protected ObjectBase m_caster;

		protected PlayerObject m_player;
		protected LivingObject m_living;

		protected DBSpell m_spell;

		protected ushort m_flags;
		protected ushort m_anim1;
		protected ushort m_anim2;

		protected MapTile m_tile;

		protected bool m_channeled;

		protected int m_ammoid;
		protected int m_ammoit;

		protected int m_castTime;

		private int m_numberOfDelays;

		private bool m_itemCast;

		private bool m_partialEffect;

		protected Vector m_casterPosition;

		protected SpellFinishHandler m_onCastFinished;

		private SpellFailedReason m_failReason = SpellFailedReason.MAX;

		private static TimeSpan CastDelay(ObjectBase caster, DBSpell spell)
		{
			int castTime;
			TimeSpan result = TimeSpan.Zero;
			if (caster != null && caster is LivingObject)
			{
				LivingObject living = (LivingObject)caster;
				if (living.LastCast > CustomDateTime.Now)
					result += living.LastCast - CustomDateTime.Now;

				if (living.SpellProcessor != null)
					castTime = living.SpellProcessor.CastTime(spell);
				else
					castTime = spell.CastTime;
			}
			else
				castTime = spell.CastTime;

			if (castTime > 0)
				result += TimeSpan.FromMilliseconds(castTime);

			return result;
		}

		public SpellCastEvent(ObjectBase caster, DBSpell spell, ushort flags, bool itemCast)
			: base(CastDelay(caster, spell))
		{
			Priority = TimerPriority.TwentyFiveMS;

			m_itemCast = itemCast;
			m_spell = spell;
			m_caster = caster;
			m_flags = flags;
			m_tile = caster.MapTile;

			m_channeled = m_spell.Channeled;

			m_player = caster as PlayerObject;
			m_living = caster as LivingObject;

			m_casterPosition = caster.Position.Clone();

			int duration;
			if (m_living != null)
			{
				m_castTime = m_living.SpellProcessor.CastTime(spell);
				duration = m_living.SpellProcessor.Duration(spell);
			}
			else
			{
				m_castTime = spell.CastTime;
				duration = spell.Duration;
			}

			if (m_spell.Ranged)
			{
				m_anim1 = 0x22;
				m_anim2 = 0x120;
				if (m_player != null && m_player.Ammo != null)
				{
					m_ammoid = m_player.Ammo.Template.DisplayID;
					m_ammoit = (int)m_player.Ammo.Template.InvType;
				}
				else
				{
					m_ammoid = 0x176e;
					m_ammoit = 0x18;
				}
			}
			else
			{
				m_anim1 = 0x0100;
				m_anim2 = 0x0100;
			}

			if (m_spell.Fishing)
			{
				Interval = TimeSpan.FromMilliseconds(duration);
				Count = 2;
				m_anim1 = m_anim2 = 0x0180;
			}
			else if (m_channeled)
			{
				int period = 0;
				for (byte i = 0; i < 3; i++)
					if (m_spell.Effect[i].AuraPeriod > period)
						period = m_spell.Effect[i].AuraPeriod;

				if (period == 0) // channeling non-periodic spell??
					period = 1000;
				Interval = TimeSpan.FromMilliseconds(period);
				Count = duration / period + 1;
			}
			/*else
					this.Count = 1;*/
		}

		#region Static functions

		public static void SpellCastResult(ClientBase client, uint spellId, SpellFailedReason reason)
		{
			SpellCastResult(client, spellId, reason, -1);
		}

		public static void SpellCastResult(ClientBase client, uint spellId, SpellFailedReason reason, int param)
		{
			ShortPacket pkg = new ShortPacket(SMSG.CAST_RESULT);
			pkg.Write(spellId);
			if (reason == SpellFailedReason.MAX)
				pkg.Write((byte)0);
			else
			{
				pkg.Write((byte)2);
				pkg.Write((byte)reason);
				if (param != -1)
					pkg.Write(param);
			}

			client.Send(pkg);
		}

		public static void SendCoolDown(ClientBase client, ulong target, uint spellId, int cooldown)
		{
			if (cooldown <= 0)
				return;
			ShortPacket pkg = new ShortPacket(SMSG.SPELL_COOLDOWN);
			pkg.Write(target);
			pkg.Write(spellId);
			pkg.Write(cooldown);
			if (!Constants.BurningCrusade)
				client.Send(pkg);
		}

		public static void SendCoolDownEvent(ClientBase client, ulong target, uint spellId)
		{
			ShortPacket pkg = new ShortPacket(SMSG.COOLDOWN_EVENT);
			pkg.Write(spellId);
			pkg.Write(target);
			client.Send(pkg);
		}

		#endregion

		public void Interrupt(SpellFailedReason sresult)
		{
			Finish(sresult);
		}

		protected void Finish(SpellFailedReason sresult)
		{
			m_failReason = sresult;
			Finish(sresult != SpellFailedReason.MAX ? EventResult.ERROR : EventResult.COMPLETED);
		}

		protected override void OnFinish()
		{
			base.OnFinish();

			try
			{
				bool failed = m_failReason != SpellFailedReason.MAX;

				if (m_channeled)
				{
					if (m_living != null && m_living.Auras != null)
						m_living.Auras.CancelAuraForce(m_spell.SpellID);

					AreaAuraManager.CancelAreaAura(m_caster, m_spell.SpellID);
				}

				int cooldown = 0;

				if ((!failed || m_channeled || m_partialEffect) && m_living != null && m_living.SpellProcessor != null)
				{
					if (!m_itemCast)
					{
						int powerCost =
							m_living.SpellProcessor.PowerCost(m_spell, m_living.Level,
							                                  m_spell.PowerType == POWERTYPE.HEALTH ? m_living.MaxHealth : m_living.MaxPower);

						if (powerCost > 0)
						{
							if (m_spell.PowerType == POWERTYPE.HEALTH)
							{
								m_living.Health -= powerCost;
								if (m_living.Health <= 0)
									m_living.Health = 1;
							}
							else
							{
								m_living.Power -= powerCost;
								if (m_living.Power <= 0)
									m_living.Power = 0;
							}
						}
					}

					if (m_player != null && !m_player.IsDisposed)
					{
						for (int i = 0; i < m_spell.CraftReqs.Length; i++)
							if (m_spell.CraftReqs[i].ItemTemplateID != 0)
								m_player.Inventory.ConsumeItems(m_spell.CraftReqs[i].ItemTemplateID, m_spell.CraftReqs[i].Quantity);

						if (!m_spell.Craft && !m_spell.Food)
						{
							cooldown = m_player.SpellProcessor.Cooldown(m_spell) - m_castTime;

							if (cooldown <= 0)
								cooldown = 1000;
							if (cooldown > 0)
								m_player.Spells.SetCooldown(m_spell, cooldown);
						}
					}
				}
				else if (m_player != null && m_player.Spells != null)
					m_player.Spells.SetCooldown(m_spell, 800);

				if (m_player != null && !m_player.IsDisposed)
				{
					SpellCastResult(m_player.BackLink.Client, m_spell.SpellID, m_failReason);
					//SendCoolDown(m_player.BackLink.Client, m_player.GUID, m_spell.SpellID, m_player.SpellProcessor.Cooldown(m_spell));
					if (cooldown > 0)
						SendCoolDownEvent(m_player.BackLink.Client, m_player.GUID, m_spell.SpellID);

					if (m_channeled)
					{
						if (m_player.ChannelObject != null && m_player.ChannelObject != m_player)
						{
							LivingObject lchannel = m_player.ChannelObject as LivingObject;
							if (lchannel != null && !lchannel.Disposed && lchannel.Auras != null)
								lchannel.Auras.CancelAuraForce(m_spell.SpellID);
						}

						m_player.ChannelSpell = 0;

						if (!(m_player.ChannelObject is GameObject))
							m_player.ChannelObject = null;

						ShortPacket pkg = new ShortPacket(SMSG.CHANNEL_UPDATE);
						pkg.Write(0);
						m_player.BackLink.Client.Send(pkg);
					}
					m_player.CastEvent = null;
					m_player.UpdateData();
				}
				if (failed)
				{
					if (m_tile != null)
					{
						ShortPacket pkg = new ShortPacket(SMSG.SPELL_FAILURE);
						pkg.WriteGuid(m_caster.GUID);
						pkg.Write((uint) m_spell.SpellID);
						pkg.Write((byte) m_failReason);
						m_tile.SendSurrounding(pkg, m_caster);
					}
				}
				//m_tile = null;
				//m_caster = null;
				//m_player = null;
				//LogConsole.WriteLine(LogLevel.CHATTER,"Finished spell "+m_spell.SpellID);
			}
			catch(Exception ex)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Error at spell finish {0}", ex);
			}
			Dispose();
		}

		protected void SendSpellGo(ICollection<ulong> hit_targets, ICollection<ulong> miss_targets, ulong cast_target, Vector cast_src_point,
								   Vector cast_trg_point)
		{
			if (m_caster == null || m_tile == null || m_spell == null)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.SPELL_GO);
			pkg.WriteGuid(m_caster.GUID);
			pkg.WriteGuid(m_caster.GUID);
			pkg.Write((uint)m_spell.SpellID);
			pkg.Write(m_anim2);

			if (hit_targets != null)
			{
				pkg.Write((byte)hit_targets.Count); // targets affected
				foreach (ulong hit_target in hit_targets)
					pkg.Write(hit_target);
			}
			else
				pkg.Write((byte)0);

			if (miss_targets != null)
			{
				pkg.Write((byte)miss_targets.Count); //  miss coun
				foreach (ulong miss_target in miss_targets)
					pkg.Write(miss_target);
			}
			else
				pkg.Write((byte)0);

			pkg.Write(m_flags);
			if (
				(m_flags & 0x2) == 0x2 ||
				(m_flags & 0x10) == 0x10 ||
				(m_flags & 0x800) == 0x800 ||
				(m_flags & 0x1000) == 0x1000 ||
				(m_flags & 0x8000) == 0x8000
				) // item or unit
				pkg.WriteGuid(cast_target);
			if ((m_flags & 0x20) == 0x20) // source location
				pkg.WriteVector(cast_src_point);
			if ((m_flags & 0x40) == 0x40) // dest location
				pkg.WriteVector(cast_trg_point);

			if ((m_anim2 & 0x20) == 0x20)
			{
				pkg.Write(m_ammoid);
				pkg.Write(m_ammoit);
			}

			//LogConsole.WriteLine(LogLevel.ECHO,"Spell go "+m_spell.SpellID+", anim: "+m_anim1+", flags "+m_flags+", target "+cast_target+", src "+(cast_src_point==null?"null":cast_src_point.ToString())+", target "+(cast_trg_point==null?"null":cast_trg_point.ToString()));
			//            LogConsole.WriteLine(LogLevel.SYSTEM,"Spell go "+m_spell.SpellID+", anim: "+m_anim1);
			pkg.Aquire();
			m_tile.SendSurrounding(pkg, m_caster);
			if (m_player != null && !m_player.IsDisposed && m_player.MapTile != m_tile)
				m_player.BackLink.Client.Send(pkg);
			pkg.Release();
		}

		protected virtual void SendSpellStart(ulong target, ObjectBase otarget, Vector src_point, Vector trg_point)
		{
			if (m_caster == null || m_tile == null || m_spell == null)
				return;
			if (m_player != null && m_channeled)
			{
				ShortPacket pkg1 = new ShortPacket(SMSG.CHANNEL_START);
				pkg1.Write((uint)m_spell.SpellID);
				pkg1.Write(m_caster.SpellProcessor.Duration(m_spell));
				m_player.BackLink.Client.Send(pkg1);
				m_player.ChannelSpell = m_spell.SpellID;
				m_player.ChannelObject = otarget;
				m_player.UpdateData();
			}
			ShortPacket pkg = new ShortPacket(SMSG.SPELL_START);
			pkg.WriteGuid(m_caster.GUID);
			pkg.WriteGuid(m_caster.GUID);
			pkg.Write((uint)m_spell.SpellID);
			pkg.Write(m_anim1);
			pkg.Write(m_castTime);

			if (m_flags == 0x2 && target == 0) //self cast
				pkg.Write((ushort)0);
			else
			{
				pkg.Write(m_flags);
				if (
					/*(m_flags & 0x2) == 0x2 ||*/
					(m_flags & 0x10) == 0x10 ||
					(m_flags & 0x800) == 0x800 ||
					(m_flags & 0x1000) == 0x1000 ||
					(m_flags & 0x8000) == 0x8000
					) // item or unit
					pkg.Write(target);
				if ((m_flags & 0x20) == 0x20) // source location
					pkg.WriteVector(src_point);
				if ((m_flags & 0x40) == 0x40) // dest location
					pkg.WriteVector(trg_point);
			}
			if ((m_anim1 & 0x20) == 0x20)
			{
				pkg.Write(m_ammoid);
				pkg.Write(m_ammoit);
			}

			//LogConsole.WriteLine(LogLevel.TRACE,"Spell start "+m_spell.SpellID+", flags "+m_flags+", target "+target+", src "+(src_point==null?"null":src_point.ToString())+", target "+(trg_point==null?"null":trg_point.ToString()));
			pkg.Aquire();
			m_tile.SendSurrounding(pkg, m_caster);
			if (m_player != null && m_player.MapTile != m_tile)
				m_player.BackLink.Client.Send(pkg);
			pkg.Release();
		}

		public abstract void SendSpellStart();

		protected override bool OnStart()
		{
			if (m_living != null)
			{
				if (m_player != null && (m_spell.Flags[2] & 32) == 32)
					m_player.AddRangedDelay();
				else if (m_castTime > 0)
					m_living.LastCast = CustomDateTime.Now + TimeSpan.FromMilliseconds(m_castTime);
				else
					m_living.LastCast = CustomDateTime.Now;

				m_living.LastCastPower = m_spell.PowerCost;
			}
			SendSpellStart();
			return true;
		}
		
		public void DelayCast(int msec)
		{
			if (Finished || m_channeled || m_spell.CastTime == 0)
				return;
			
			if (msec > 2000)
				msec = 2000;
			if (m_numberOfDelays < 10)
				m_numberOfDelays++;
			else
				return;
			
			msec /= m_numberOfDelays;

			//if (Utility.Chance(m_caster.SpellProcessor.AvoidInterruptionChance(m_spell)))
			//    return;
			
			//			if (m_channeled)
			//			{
			//				//int nc = (int) (msec/this.Interval.TotalMilliseconds);
			//				//this.Index += nc;
			//				if (this.Index > this.Count)
			//					Finish(SpellFailedReason.SPELL_FAILED_ERROR/*INTERRUPTED_COMBAT*/);
			//				return;
			//			}
			//			else
			Prolongate(TimeSpan.FromMilliseconds(msec));

			if (m_player != null)
			{
				ShortPacket pkg = new ShortPacket(SMSG.SPELL_DELAYED);
				pkg.Write/*Guid*/(m_player.GUID);
				pkg.Write(msec);
				m_player.BackLink.Client.Send(pkg);
			}
		}

		protected SpellFailedReason ProcessCast(MapTile tile, ObjectBase target, ObjectBase castTarget, Vector point, out ICollection<ulong> laffected, out ICollection<ulong> lmissed)
		{
			SpellFailedReason result = SpellFailedReason.MAX;
			Dictionary<ulong, ObjectBase> affected = new Dictionary<ulong, ObjectBase>();
			Dictionary<ulong, bool> resisted = new Dictionary<ulong, bool>();

			for (byte i = 0; i < 3; i++)
			{
				if (Finished)
					break;

				if (m_spell.Effect[i].Type == 0)
					continue;
				
				bool area = m_spell.Effect[i].Type == SPELLEFFECT.AREA_AURA ||
				            m_spell.Effect[i].Type == SPELLEFFECT.PERSISTENT_AREA_AURA;

				if (area)
				{
					if (m_spell.Effect[i].Type == SPELLEFFECT.AREA_AURA)
						if (m_caster is LivingObject)
							AreaAuraManager.RegisterLivingAreaArea((LivingObject) m_caster, m_spell, i);
						else
							AreaAuraManager.RegisterObjectAreaArea(m_caster, m_spell, i);
					else if (m_spell.Effect[i].Type == SPELLEFFECT.PERSISTENT_AREA_AURA)
						AreaAuraManager.RegisterPersistentAreaArea(m_caster, m_spell, i, point);
				}


				SpellFailedReason dresult;
				ICollection<ObjectBase> ltargets = SpellManager.SpellTargets(tile, m_caster, target, point, m_spell, i, out dresult, area);
				if (dresult == SpellFailedReason.MAX && ltargets != null)
				{
					foreach (ObjectBase ltarget in ltargets)
						if (ltarget != null && !ltarget.IsDisposed)
						{
							if (ltarget is LivingObject && !((LivingObject)ltarget).Attackable && !m_spell.CastOnDead)
								continue;

							if (!resisted.ContainsKey(ltarget.GUID))
								resisted[ltarget.GUID] = SpellManager.CheckResist(m_caster, ltarget, m_spell);

							if (resisted[ltarget.GUID])
								continue;


							if (!area)
							//{
							//    if (m_spell.Effect[i].Type == SPELLEFFECT.AREA_AURA)
							//        if (m_caster is LivingObject)
							//            AreaAuraManager.RegisterLivingAreaArea((LivingObject)m_caster, m_spell, i);
							//        else
							//            AreaAuraManager.RegisterObjectAreaArea(m_caster, m_spell, i);
							//    else
							//        if (m_spell.Effect[i].Type == SPELLEFFECT.PERSISTENT_AREA_AURA)
							//            AreaAuraManager.RegisterPersistentAreaArea(m_caster, m_spell, i, point);

							//    affected[ltarget.GUID] = ltarget;
							//}
							//else
							{
								SpellFailedReason sresult = SpellManager.ProcessSpell(m_caster, ltarget, castTarget, m_spell, i, ref m_onCastFinished);
								if (sresult == SpellFailedReason.MAX)
								{
									affected[ltarget.GUID] = ltarget;

									if (m_caster is LivingObject && ltarget is LivingObject && SpellManager.HarmfulCast(m_spell, i))
										((LivingObject)ltarget).Attacked((LivingObject) m_caster);

									m_partialEffect = true;
								}
								else
									result = sresult;
							}
						}
				}
				else
					if (!area)
						result = dresult;
			}


			//if (m_spell.Effect[i].Type != 0)
			//{
			//    float radius = m_spell.Effect[i].Radius*m_spell.Effect[i].Radius;
			//    foreach (ObjectBase ltarget in targets)
			//        if (ltarget != null && !ltarget.IsDisposed)
			//        {
			//            if (radius > 0 && ltarget.Position.DistanceFlatSqrd(point) > radius)
			//                continue;
			//            SpellFailedReason nresult = SpellManager.ProcessSpell(m_caster, ltarget, m_spell, i, ref m_onCastFinished);
			//            if (nresult == SpellFailedReason.MAX)
			//                affected.Add(ltarget.GUID);
			//            else if (!region)
			//                result = nresult;
			//        }
			//}
			laffected = affected.Keys;
			lmissed = new List<ulong>();

			/*foreach (KeyValuePair<ulong, bool> pair in resisted)
			    if (pair.Value)
					m_tile.SendSurrounding(DamageLog.MagicResist(pair.Key, m_caster.GUID, m_spell.ObjectId), null);*/


			if (m_living != null)
				m_living.Cast(m_spell, affected.Values);
			
			return result;
		}
	}

	public class SingleTargetCast : SpellCastEvent
	{
		private ObjectBase m_target;
		private ObjectBase m_castTarget;
		
		public SingleTargetCast(ObjectBase caster, DBSpell spell, ushort flags, ObjectBase target, bool itemCast)
			: base(caster, spell, flags, itemCast)
		{
			if (target == null)
				m_target = caster;
			else
				m_target = target;

			m_castTarget = caster is PlayerObject
			               	? ((PlayerObject) caster).Selection == null ? target : ((PlayerObject) caster).Selection
			               	: null;

			//m_targetPoint = target.Position.Clone();
			//Primary = false;
			ExecPriority = ExecutionPriority.QCritical;
		}

		public override void SendSpellStart()
		{
			if (m_target != null)
				SendSpellStart(m_target == m_caster ? 0 : m_target.GUID, m_target, null, null);
		}

		protected override void OnTick()
		{
			if (m_spell.Fishing && Index == Count)
			{
				Finish(SpellFailedReason.MAX);
				return;
			}

			if (m_target == null || m_caster == null || m_tile == null || m_target.IsDisposed || m_caster.IsDisposed)
			{
				Finish(SpellFailedReason.SPELL_FAILED_ERROR);
				return;
			}

			if (m_living != null)
			{
				if (!m_living.Attackable)
				{
					Finish(SpellFailedReason.SPELL_FAILED_CASTER_DEAD);
					return;
				}
			}

			if (m_player != null && ((m_castTime > 0 || (m_spell.Flags[2] & 32) == 32) || m_channeled) && !m_casterPosition.Equals(m_player.Position)/* (m_caster.MovementFlags & 0x31) != 0*/)
			{
				Finish(SpellFailedReason.SPELL_FAILED_MOVING);
				return;
			}

			if (m_target is LivingObject && !((LivingObject)m_target).Attackable && !m_spell.CastOnDead)
			{
				if (m_channeled)
					Finish(SpellFailedReason.MAX);
				else
					Finish(SpellFailedReason.SPELL_FAILED_TARGETS_DEAD);
				return;
			}
			if (m_caster != m_target && !(m_target is ItemObject))
			{
				uint maxRange = m_living == null
				                	? m_spell.MaxRange == 0 ? 0 : m_spell.MaxRange + m_spell.MinRange
				                	: m_living.SpellProcessor.MaxRange(m_spell) + m_spell.MinRange;

				float rangesqrd = m_target.Position.DistanceFlatSqrd(m_casterPosition);


				if (maxRange > 0 && rangesqrd > maxRange*maxRange*2.25)
				{
					Finish(SpellFailedReason.SPELL_FAILED_OUT_OF_RANGE);
					return;
				}
				if (m_spell.MinRange > 0 && rangesqrd < m_spell.MinRange*m_spell.MinRange)
				{
					Finish(SpellFailedReason.SPELL_FAILED_TOO_CLOSE);
					return;
				}
				if (m_caster is PlayerObject &&
					m_spell.CastTime != 0 && m_living != null &&
				    (m_living.Position.DistanceFlat(m_target.Position) >
				     m_living.CombatReach + (m_target is LivingObject ? ((LivingObject) m_target).BoundingRadius : 2f)) &&
				    !m_living.Position.InFront(m_living.Facing, m_target.Position))
				{
					Finish(SpellFailedReason.SPELL_FAILED_UNIT_NOT_INFRONT);
					return;
				}
			}

			//LogConsole.WriteLine(LogLevel.SYSTEM,"Firing spell "+m_spell.Name +", target "+m_target);
			//LogConsole.WriteLine(LogLevel.CHATTER,"Casting spell "+m_spell.SpellID);

			m_caster.CastCount++;

			ICollection<ulong> affected, missed;
			SpellFailedReason result = ProcessCast(m_tile, m_target, m_castTarget, m_target.Position, out affected, out missed);

			if (m_onCastFinished != null)
				m_onCastFinished(m_caster, m_target, m_spell);

			if (result == SpellFailedReason.MAX)
			{
				if (m_spell.ChannelObject && m_player != null && m_player.ChannelObject != null)
				{
					m_flags = 0x40;
					SendSpellGo(null, null, 0, null, m_player.ChannelObject.Position);
				}
				else
					SendSpellGo(affected, missed, m_target.GUID, null, null);
			}

			if (!m_channeled || Index == Count) // last tick
				Finish(result);
		}
	}

	public class RegionCast : SpellCastEvent
	{
		private Vector m_src;
		private Vector m_target;

		public RegionCast(ObjectBase caster, DBSpell spell, ushort flags, Vector from, Vector to, bool itemCast)
			: base(caster, spell, flags, itemCast)
		{
			if (from == null)
				from = caster.Position.Clone();
			m_src = from;

			/*if (m_src.DistanceFlat(caster.Position) > spell.MaxRange)
				m_src = caster.Position.Clone();*/
			
			m_target = to;
			//Primary = false;
			ExecPriority = ExecutionPriority.QCritical;
		}

		public override void SendSpellStart()
		{
			SendSpellStart(0, null, m_src, m_target);
		}

		protected override void OnTick()
		{
			//LogConsole.WriteLine(LogLevel.SYSTEM,"Firing region spell "+m_spell.SpellID + ", count: "+ this.Count+ ", index " + this.Index);

			if (m_caster == null || m_tile == null || m_caster.IsDisposed)
			{
				Finish(SpellFailedReason.SPELL_FAILED_ERROR);
				return;
			}
			if (m_living != null && !m_living.Attackable)
			{
				Finish(SpellFailedReason.SPELL_FAILED_CASTER_DEAD);
				return;
			}

			float range = m_target.Distance(m_src);

			if (m_spell.MaxRange > 0 && range > m_spell.MaxRange)
			{
				Finish(SpellFailedReason.SPELL_FAILED_OUT_OF_RANGE);
				return;
			}

			if (m_spell.MinRange > 0 && range < m_spell.MinRange)
			{
				Finish(SpellFailedReason.SPELL_FAILED_TOO_CLOSE);
				return;
			}

			if (m_player != null && ((m_castTime > 0 || (m_spell.Flags[2] & 32) == 32) || m_channeled) && !m_casterPosition.Equals(m_player.Position)/* (m_caster.MovementFlags & 0x31) != 0*/)
				//if (m_player != null && ((m_castTime > 0 || (m_spell.Flags[2] & 32) == 32) || m_channeled) && /*!m_casterPosition.Equals(m_player.Position)*/ (m_caster.MovementFlags & 0x31) != 0)
			{
				Finish(SpellFailedReason.SPELL_FAILED_MOVING);
				return;
			}

			//LogConsole.WriteLine(LogLevel.CHATTER, "Casting spell " + m_spell.SpellID);
			m_tile = m_tile.Map.GetTileByLoc(m_target);

			//LogConsole.WriteLine(LogLevel.CHATTER, "Casting spell " + m_spell.SpellID);

			m_caster.CastCount++;
			
			ICollection<ulong> affected, missed;
			SpellFailedReason result = ProcessCast(m_tile, null, null, m_target, out affected, out missed);


			if (result == SpellFailedReason.MAX)
				SendSpellGo(affected, missed, 0, m_src, m_target);

			if (!m_channeled || Index == Count) // last tick
				Finish(result);
			/*else
			{
				if (m_caster.Position.DistanceAvr(m_casterPosition) > 0.1f)
					Finish(SpellFailedReason.SPELL_FAILED_MOVING);
			}*/
		}
	}
}