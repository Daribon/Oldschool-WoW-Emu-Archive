//
using System;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.Events
{
	public class MobileCombatEvent : BaseCombatEvent
	{
		private UnitBase m_attacker;
		private LivingObject m_target;

		private Vector m_lastAttacketPosition;
		private Vector m_lastTargetPosition;
		private float m_lastAttackerFacing;
		private float m_rangeSqrd;
		private float m_distance;

		public override LivingObject Target
		{
			get { return m_target; }
		}

		public MobileCombatEvent(UnitBase attacker, LivingObject target)
			: base(TimeSpan.Zero, TimeSpan.FromMilliseconds(Constants.CombatUpdateTime))
		{
			m_attacker = attacker;
			m_target = target;
			m_lastAttacketPosition = null;
			m_lastTargetPosition = null;

			MonsterMove.RotateTo(m_attacker, m_target.Position, true);

			m_rangeSqrd = m_attacker.CombatReach + m_target.BoundingRadius + 2.5f;
			m_rangeSqrd = m_rangeSqrd*m_rangeSqrd;

			if (m_attacker.LastHit + TimeSpan.FromMilliseconds(m_attacker.AttackTime) <= CustomDateTime.Now)
				HitOnce(m_attacker, m_target);

			ExecPriority = ExecutionPriority.Pool;
		}

		public override void ChangeTarget(LivingObject target)
		{
			m_target = target;
			m_lastTargetPosition = null;
			m_rangeSqrd = m_attacker.CombatReach + m_target.BoundingRadius + 2.5f;
			m_rangeSqrd = m_rangeSqrd*m_rangeSqrd;
			if (m_attacker.LastHit + TimeSpan.FromMilliseconds(m_attacker.AttackTime) <= CustomDateTime.Now)
				HitOnce(m_attacker, m_target);
		}

		protected override void OnFinish()
		{
			base.OnFinish();

			LogConsole.WriteLine(LogLevel.TRACE, "Combat finishing: " + Result);

			if (m_attacker != null)
				m_attacker.StopCombat();
			m_attacker = null;
			m_target = null;
			Dispose();
		}

		protected override void OnTick()
		{
			LogConsole.WriteLine(LogLevel.TRACE, "Combat tick {0}", Index);
			if (!CheckObjects(m_attacker, m_target))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}
			if (!m_attacker.Attackable)
			{
				Finish(EventResult.OWNER_DEAD);
				return;
			}
			if (m_attacker.Stunned || m_attacker.Pacified || m_attacker.NoControl)
			{
				Finish(EventResult.CANCELED);
				return;
			}
			if (!m_target.Attackable)
			{
				Finish(EventResult.TARGET_DEAD);
				return;
			}

			bool moved = false;

			if (m_lastAttacketPosition == null || m_lastAttackerFacing != m_attacker.Facing ||
			    !m_lastAttacketPosition.Equals(m_attacker.Position))
			{
				m_lastAttacketPosition = m_attacker.Position.Clone();
				m_lastAttackerFacing = m_attacker.Facing;
				moved = true;
			}
			if (m_lastTargetPosition == null || !m_lastTargetPosition.Equals(m_target.Position))
			{
				m_lastTargetPosition = m_target.Position.Clone();
				moved = true;
			}

			if (moved)
				m_distance = m_target.Position.DistanceSqrd(m_attacker.Position);

			if (m_distance > m_rangeSqrd)
				return;
			if (moved && !m_attacker.Moving)
				MonsterMove.RotateTo(m_attacker, m_target.Position, true);


			int attackTime = m_attacker.AttackTime;

			if (m_attacker.LastHit + TimeSpan.FromMilliseconds(attackTime) > CustomDateTime.Now)
				return;

			m_attacker.LastHit = CustomDateTime.Now;

			LogConsole.WriteLine(LogLevel.TRACE, "Combat hit by {0}", m_attacker);
			if (!m_attacker.SubmitMeleeDamage(m_target)) //dead
			{
				Finish(EventResult.COMPLETED);
				return;
			}
		}
	}
}