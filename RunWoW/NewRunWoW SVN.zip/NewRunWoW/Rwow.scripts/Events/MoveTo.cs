using System;
using RunWoW.Misc;
using RunWoW.Misc.Pathing;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.Events
{
	public class MoveToEvent : Event
	{
		private UnitBase m_unit;
		private bool m_run;

		private static float move_per_step = Constants.MonsterMoveStepRange;
		private static int time_per_check = Constants.MonsterMoveUpdateTime;
		private int time_per_step;
		private BasePath m_path;
		private DateTime m_last;
		private Vector m_dest;

		public MoveToEvent(UnitBase unit, Vector dest, bool run)
			: base(TimeSpan.Zero, TimeSpan.FromMilliseconds(time_per_check))
		{
			m_unit = unit;
			m_run = run;
			m_dest = dest;

			time_per_step = (int) Math.Round(move_per_step*1000/(run ? m_unit.RunningSpeed : m_unit.WalkSpeed));
			m_path = new DirectPath(unit.Position, null, move_per_step, 0f, 0f);
			m_last = CustomDateTime.Now;
			//Primary = false;
			ExecPriority = ExecutionPriority.Pool;
		}

		protected override bool OnStart()
		{
			bool result = base.OnStart();
			if (result)
				m_unit.Moving = true;
			return result;
		}

		protected override void OnFinish()
		{
			m_unit.Moving = false;
			base.OnFinish();
		}

		protected override void OnTick()
		{
			if (!CheckObjects(m_unit))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}
			if (m_unit.Stunned || m_unit.Rooted || m_unit.Pacified || m_unit.NoControl)
			{
				MonsterMove.FixPosition(m_unit);
				Finish(EventResult.CANCELED);
				return;
			}
			if (!m_unit.Attackable)
			{
				if (!m_path.Finished)
					MonsterMove.MoveTo(m_unit, m_unit.Position, m_run, m_unit.Facing, true); // fixes corpse sliding bug ?
				Finish(EventResult.OWNER_DEAD);
				return;
			}
			//if (!m_unit.MapTile.HasAjPlayers)
			//{
			//    m_unit.Position = m_dest.Clone();
			//    m_unit.MapTile.Map.Move(m_unit);
			//    Finish(EventResult.TARGET_TO_FAR);
			//}

			if (m_path.Recalc(m_dest))
			{
				LogConsole.WriteLine(LogLevel.ECHO, "FollowUnit: Got Target: {0}", m_path.To);
				MonsterMove.MoveTo(m_unit, m_path.Path, m_run, m_path.Direction, true);
				LogConsole.WriteLine(LogLevel.ECHO, "FollowUnit: Distance: {0} steps: {1}", m_path.Distance, m_path.Steps);
			}

			if ((m_path.Path.Count == 0) || m_path.Finished)
			{
				Finish(EventResult.COMPLETED);
				MonsterMove.MoveTo(m_unit, m_unit.Position, false, time_per_step, false);
				return;
			}
			
			int elapsed = (int) (CustomDateTime.Now - m_last).TotalMilliseconds;
			if (elapsed < time_per_step)
				return;
			int steps = (int) (elapsed/time_per_step);
			/*if (*/
			m_path.Advance(steps);/* == 0)*/
			//{
			//    m_unit.Position = m_path.Current;
			//    m_unit.MapTile.Map.Move(m_unit);
			//    MonsterMove.MoveTo(m_unit, m_unit.Position, false, time_per_step, false);
			//    Finish(EventResult.COMPLETED);
			//    return;
			//}
			m_unit.Position = m_path.Current;
			m_unit.MapTile.Map.Move(m_unit);
			m_last = CustomDateTime.Now;
			//LogConsole.WriteLine(LogLevel.ECHO,"FollowUnit: Advanced position by "+steps+" steps, from "+ oldpos+" to "+m_unit.Position );
		}
	}
}