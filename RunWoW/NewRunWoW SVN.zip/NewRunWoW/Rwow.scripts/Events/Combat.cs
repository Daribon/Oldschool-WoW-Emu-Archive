//
using System;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.Events
{
	public class CombatEvent : BaseCombatEvent
	{
		private PlayerObject m_attacker;
		private LivingObject m_target;

		private Vector m_lastAttackerPosition;
		private Vector m_lastTargetPosition;
		private float m_rangeSqrd;

		private bool m_hit;
		private SMSG m_failReason;
		private float m_lastAttackerFacing;
		private float m_distance;
		
		public override LivingObject Target
		{
			get { return m_target; }
		}

		public CombatEvent(PlayerObject attacker, LivingObject target)
			: base(TimeSpan.Zero, TimeSpan.FromMilliseconds(Constants.CombatUpdateTime))
		{
			m_attacker = attacker;
			m_target = target;
			m_lastAttackerPosition = null;
			m_lastTargetPosition = null;

			m_rangeSqrd = m_attacker.CombatReach + m_target.BoundingRadius + 3.5f;
			if (m_rangeSqrd < 5)
				m_rangeSqrd = 5f;

			m_rangeSqrd = m_rangeSqrd * m_rangeSqrd;

			m_hit = true;

			if (m_attacker.LastHit + TimeSpan.FromMilliseconds(attacker.AttackTime) <= CustomDateTime.Now)
				HitOnce(attacker, target);

			ExecPriority = ExecutionPriority.Pool;
		}

		public override void ChangeTarget(LivingObject target)
		{
			if (m_target == target)
				return;

			m_target = target;
			m_lastTargetPosition = null;
			m_rangeSqrd = m_attacker.CombatReach + m_target.BoundingRadius + 3.5f;
			m_rangeSqrd = m_rangeSqrd * m_rangeSqrd;
			if (m_attacker.LastHit + TimeSpan.FromMilliseconds(m_attacker.AttackTime) <= CustomDateTime.Now)
				HitOnce(m_attacker, m_target);
		}

		protected override void OnFinish()
		{
			base.OnFinish();

			LogConsole.WriteLine(LogLevel.TRACE, "Combat finishing: " + Result);
			if (m_attacker != null /* && m_attacker.Attackable && Result != EventResult.TERMINATED && m_attacker.Attacking*/)
			{
				m_attacker.StopCombat();
				//m_attacker.UpdateData();
			}
			m_attacker = null;
			m_target = null;
			Dispose();
		}

		protected override void OnTick()
		{
			LogConsole.WriteLine(LogLevel.TRACE, "Combat tick {0}", Index);
			if (!CheckObjects(m_attacker, m_target))
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}
			if (!m_attacker.Attackable)
			{
				Finish(EventResult.OWNER_DEAD);
				return;
			}
			if (m_attacker.Stunned || m_attacker.Pacified || m_attacker.NoControl)
			{
				Finish(EventResult.CANCELED);
				return;
			}
			if (!m_target.Attackable)
			{
				Finish(EventResult.TARGET_DEAD);
				return;
			}

			if (m_attacker.Casting)
				return;

			bool moved = false;
			if (m_lastAttackerPosition == null || m_lastAttackerFacing != m_attacker.Facing || !m_lastAttackerPosition.Equals(m_attacker.Position))
			{
				m_lastAttackerPosition = m_attacker.Position.Clone();
				m_lastAttackerFacing = m_attacker.Facing;
				moved = true;
			}
			if (m_lastTargetPosition == null || !m_lastTargetPosition.Equals(m_target.Position))
			{
				m_lastTargetPosition = m_target.Position.Clone();
				moved = true;
			}

			if (moved)
			{
				m_distance = m_target.Position.DistanceSqrd(m_attacker.Position);
			}

			if (m_distance > m_rangeSqrd)
			{
				m_failReason = SMSG.ATTACKSWING_NOTINRANGE;
				m_hit = false;
			}
			else
			{
				if (m_distance > m_target.BoundingRadius * m_target.BoundingRadius * 2 &&
				    !m_attacker.Position.InFront(m_attacker.Facing, m_target.Position))
				{
					m_failReason = SMSG.ATTACKSWING_BADFACING;

					m_hit = false;
				}
				else
					m_hit = true;
			}

			int attackTime = m_attacker.AttackTime;

			if (m_attacker.IsDualWield)
			{
				if (Utility.Chance(0.5))
					attackTime = m_attacker.OffHandAttackTime;

				attackTime /= 2;
			}

			if (m_attacker.LastHit + TimeSpan.FromMilliseconds(attackTime) > CustomDateTime.Now)
				return;

			m_attacker.LastHit = CustomDateTime.Now;

			if (!m_hit)
			{
				Combat.Fail(m_attacker, m_failReason);
				return;
			}

			LogConsole.WriteLine(LogLevel.TRACE, "Combat hit by {0}", m_attacker);

			if (m_attacker.NextHitSpell != null)
			{
				CastNextHit(m_attacker, m_target);

				if (m_target.Dead)
					Finish(EventResult.COMPLETED);

				return;
			}

			if(!m_attacker.SubmitMeleeDamage(m_target)) //dead
			{
				Finish(EventResult.COMPLETED);
				return;
			}
		}
	}
}