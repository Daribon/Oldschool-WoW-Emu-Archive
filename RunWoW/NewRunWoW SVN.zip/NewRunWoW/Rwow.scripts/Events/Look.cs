using System;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.Events
{
	public class LookEvent : Event
	{
		private UnitBase m_unit;
		private LivingObject m_living;

		public LookEvent(UnitBase unit, LivingObject living)
			: base(TimeSpan.FromMilliseconds(1), TimeSpan.FromMilliseconds(Constants.MobileLookDelay))
		{
			m_unit = unit;
			m_living = living;
			//Primary = false;
			ExecPriority = ExecutionPriority.Pool;
		}

		protected override void OnTick()
		{
			if (m_unit == null || m_living == null || m_unit.MapTile == null || m_living.MapTile == null)
			{
				Finish(EventResult.ERROR_WRONG_PARAMS);
				return;
			}
			if (m_unit.Dead)
			{
				Finish(EventResult.OWNER_DEAD);
				return;
			}
			if (!m_living.Attackable)
			{
				Finish(EventResult.TARGET_DEAD);
				return;
			}

			Vector v = m_living.Position;
			float distance = m_unit.Position.Distance(v);

			if (distance < Constants.VendorSightMinRange)
			{
				Finish(EventResult.COMPLETED);
				return;
			}
			if (distance > Constants.VendorSightRange)
			{
				Finish(EventResult.TARGET_TO_FAR);
				return;
			}

			MonsterMove.RotateTo(m_unit, v, false);
		}
	}
}