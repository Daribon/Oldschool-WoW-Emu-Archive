using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class SetAccessLevelCommand
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("setaccesslevel", "USAGE: '.setaccesslevel [new access level (digit)] [name] ' || or choose player and say '.setaccesslevel [new access level (digit)]'", new ChatCommand(OnSetAccessLevelCommand));
		}

		private static bool OnSetAccessLevelCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl != ACCESSLEVEL.ADMIN)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}

			Chat.System(client, "-------------------");


			string[] command = s.Split(new char[] {',', ' '});
			if (command.Length >= 3)
			{
				ClientBase client_to_work = ValidateUserByString(command[2], client);
				if (client_to_work != null)
				{
					ClientData client_to_work_cd = (ClientData) client_to_work.Data;

					int newlevel = int.Parse(command[1]);
					client_to_work_cd.Account.AccessLvl = (ACCESSLEVEL) (newlevel);
					client_to_work_cd.Player.Save();

					Chat.System(client, "Player " + client_to_work_cd.Player.Name + " set new accesslvl " + client_to_work_cd.Account.AccessLvl.ToString());
					Chat.System(client_to_work, "Your access level now set as " + client_to_work_cd.Account.AccessLvl.ToString());

					return true;
				}
			}
			else
			{
				if (command.Length == 2)
				{
					if (Client.Player.Selection is PlayerObject)
					{
						ClientBase client_to_work = ClientManager.GetClient(((PlayerObject) Client.Player.Selection).CharacterID);

						if (client != client_to_work)
						{
							ClientData client_to_work_cd = (ClientData) client_to_work.Data;

							int newlevel = int.Parse(command[1]);
							client_to_work_cd.Account.AccessLvl = (ACCESSLEVEL) (newlevel);

							client_to_work_cd.Player.Save();

							Chat.System(client, "Player " + client_to_work_cd.Player.Name + " set new accesslvl" + client_to_work_cd.Account.AccessLvl.ToString());
							Chat.System(client_to_work, "Your access level now set as " + client_to_work_cd.Account.AccessLvl.ToString());

							return true;
						}
						else
						{
							Chat.System(client, "Cannot set new access level to itself");
							return true;
						}
					}
					else
					{
						Chat.System(client, "You may set access level only for players");
					}
					return false;
				}
			}

			return false;

		}


		private static ClientBase ValidateUserByString(string _string, ClientBase client)
		{
			ClientData Client = (ClientData) client.Data;
			if (_string.ToLower() != Client.Player.Name.ToLower())
			{
				ClientBase cb_temp = ClientManager.GetClient(_string);

				if (cb_temp == null)
				{
					Chat.System(client, "No client found");
					return null;
				}
				else
				{
					ClientData cd_temp = (ClientData) cb_temp.Data;
					if (Client.Account.AccessLvl >= cd_temp.Account.AccessLvl)
					{
						Chat.System(client, "Client found");
						return cb_temp;
					}
					else
					{
						Chat.System(client, "You cannot set new accesslevel this player, because his access level higher that your");
						return null;
					}
				}
			}
			else
			{
				Chat.System(client, "Cannot set new accesslevel itself");
				return null;
			}

		}

	}
}

/*	public enum ACCESSLEVEL : byte 
	{ 
		BANNED=0, 
		NORMAL=2, 
		TEMPGM=5, 
		GM=6, 
		ADMIN=9, 
	}*/