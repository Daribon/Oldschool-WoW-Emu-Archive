using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Disconnect
	{
		private static ClientBase ValidateUserByString(string _string, ClientBase client)
		{
			ClientData Client = (ClientData) client.Data;
			if (_string.ToLower() != Client.Player.Name.ToLower())
			{
				ClientBase cb_temp = ClientManager.GetClient(_string);

				if (cb_temp == null)
				{
					Chat.System(client, "No client found: '" + _string + "'");
					return null;
				}
				else
				{
					return cb_temp;
				}
			}
			else
			{
				Chat.System(client, "Cannot kick itself, try EXIT button");
				return null;
			}

		}

		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("kick", "USAGE: '.kick [name]' || or choose player and say '.kick'", new ChatCommand(OnDisconnectCommand));
		}

		private static bool OnDisconnectCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			Chat.System(client, "-------------------");

			string[] command = s.Split(new char[] {',', ' '});
			if (command.Length >= 2)
			{
				ClientBase client_to_kick = ValidateUserByString(command[1], client);

				if (client_to_kick != null)
				{
					ClientData client_to_kick_cd = (ClientData) client_to_kick.Data;

					if (client_to_kick_cd.Account.AccessLvl < Client.Account.AccessLvl)
					{
						Chat.System(client, "You kicked " + client_to_kick_cd.Player.Name);
						client_to_kick.Close("GameMaster " + Client.Player.Name + " forced to disconnect " + client_to_kick_cd.Player.Name);
					}
					else
					{
						Chat.System(client, "Cannot kick him... " + client_to_kick_cd.Player.Name + " has more accesslevel that your");
					}

					return true;

				}
				else
				{
					//Chat.System(client, "No such player founded...");
					return false;
				}
			}
			else
			{
				if (Client.Player.Selection is PlayerObject)
				{
					ClientBase cb = ClientManager.GetClient(((PlayerObject) Client.Player.Selection).CharacterID);

					if (client != cb)
					{
						ClientData cd = (ClientData) cb.Data;

						if (cd.Account.AccessLvl < Client.Account.AccessLvl)
						{
							cb.Close("GameMaster " + Client.Player.Name + " forced to disconnect " + cd.Player.Name);
							Chat.System(client, "You kicked " + cd.Player.Name);
						}
						else
						{
							Chat.System(client, "Cannot kick him... " + cd.Player.Name + " has more accesslevel that your");
						}

						return true;


					}
					else
					{
						Chat.System(client, "Try push EXIT button :)");
						return true;
					}
				}
				else
				{
					Chat.System(client, "You may kick only players");
				}
				return false;

			}
		}

	}
}

/*	public enum ACCESSLEVEL : byte 
	{ 
		BANNED=0, 
		NORMAL=2, 
		TEMPGM=5, 
		GM=6, 
		ADMIN=9, 
	}*/