using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Vendors;

namespace RunWoW.ExternalScripts.GmCommands
{
	public class ForceSign
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("guildsign", "USAGE: ", new ChatCommand(OnSignCommand));
		}

		private static bool OnSignCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.DEVELOPER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}

			GuildMaster.ForcePetitionSign(client);
			return true;
		}
	}
}
