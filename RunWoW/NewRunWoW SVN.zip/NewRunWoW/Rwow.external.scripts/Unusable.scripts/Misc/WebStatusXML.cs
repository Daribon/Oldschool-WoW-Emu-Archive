using System;
using System.IO;
using System.Threading;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.LoginPackets;
using RunWoW.Map;
using RunWoW.Objects;

namespace RunWoW.Misc
{
	public class StatusXMLPage : Event
	{
		public static StatusXMLPage Instance = new StatusXMLPage();
		private static DateTime ServerStart = CustomDateTime.Now;

		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}

		public StatusXMLPage()
			: base(TimeSpan.FromSeconds(5.0), TimeSpan.FromMinutes(1.0))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			if (!Directory.Exists(Constants.StatusPath))
				Directory.CreateDirectory(Constants.StatusPath);

			using (StreamWriter op = new StreamWriter(Constants.StatusPath + Constants.StatusXMLFile))
			{
				int workers, ports;
				ThreadPool.GetAvailableThreads(out workers, out ports);

				op.WriteLine("<?xml version='1.0'?>");
				op.WriteLine("<rss version='2.0'>");
				op.WriteLine("<channel>");
				op.WriteLine("<server_details>");
				op.WriteLine("	<server_version>" + Constants.Version + "</server_version>");
				op.WriteLine("	<framework_version>" + Environment.Version + "</framework_version>");
				op.WriteLine("	<uptime>" + StatusUtility.FormatTimeSpan(CustomDateTime.Now - ServerStart) + "</uptime>");
				op.WriteLine("	<page_updated>" + CustomDateTime.Now + "</page_updated>");
				op.WriteLine("	<os_version>" + Environment.OSVersion + "</os_version>");
				op.WriteLine("	<memory_used>" + StatusUtility.FormatByteAmount(GC.GetTotalMemory(false)) + "</memory_used>");
				op.WriteLine("	<clients_online>" + ClientManager.OnlineCount + "</clients_online>");
				op.WriteLine("	<queue>" + AuthQueueEvent.Instance.Count + "</queue>");
				op.WriteLine("</server_details>");

				op.WriteLine("<player_list>");

				PooledList<PlayerObject> players = ClientManager.GetPlayerList();

				foreach (PlayerObject player in players)
				{
					op.Write("<player>");
					op.Write("<name>" + player.Name + "</name>");

					if (player.Character.Guild != null)
						op.Write("<guild>" + player.Character.Guild.Name + "</guild>");
					else
						op.Write("<guild></guild>");

					op.Write("<level>" + player.Level + "</level>");
					op.Write("<class>" + player.Class + "</class>");
					op.Write("<race>" + player.Race + "</race>");
					op.Write("<world>" + ((WorldMap.Worlds)player.WorldMapID) + "</world>");
					op.Write("<group>" + (player.Group == null ? "false" : "true") + "</group>");
					op.Write("</player>");
				}
				op.WriteLine("</player_list>");
				op.WriteLine("</channel>");
				op.WriteLine("</rss>");
			}
		}
	}
}