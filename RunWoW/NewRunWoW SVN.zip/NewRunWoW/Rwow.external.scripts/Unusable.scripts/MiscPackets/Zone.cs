//
using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Map;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class Zone
	{
		[PacketHandler(CMSG.ZONEUPDATE, ExecutionPriority.Pool)]
		public static void HandleZoneUpdate(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null || Client.Player == null || data == null)
				return;
			Client.Player.Zone = data.ReadUInt32();
			//Console.WriteLine("Zone packet length " + data.BaseStream.Length + ", position " + data.BaseStream.Position);

			float water = -1000f;
			int area = 0;

			//if (WorldMap.HasMap((int)Client.Player.WorldMapID))
				WorldMap.GetPoint((int)Client.Player.WorldMapID, Client.Player.Position.X,
				                  Client.Player.Position.Y, out water, out area, false);

			/*if (areaID != Client.Player.Zone)
				Console.WriteLine("Player " + Client.Player.Name + " entered area " + areaID);*/

			if (area == 0)
				area = (int)Client.Player.Zone;

			if (Client.Player.Area == null || Client.Player.Area.ObjectId != area)
				Client.Player.Area = (DBArea)Database.Instance.FindObjectByKey(typeof(DBArea), area);

			//Client.Player.Quests.CheckTrigger((uint) area, Client.Player.MapTile);

			Client.Player.UpdateData();

			if (Constants.BurningCrusade)
				Weather.SendWeather(client, Client.Player.Zone);

			//if (Client.Player.Area == null)
			//    if (Client.Player.Zones.AddZone(Client.Player.Area.AreaFlag))
			//        Explore(Client.Player, area, Client.Player.Area.Level);

			/*uint tmp=data.ReadUInt32();
			LogConsole.WriteLine(LogLevel.SYSTEM,"Location: "+tmp);*/
		}

		public static void Explore(PlayerObject player, int area, int level)
		{
			int exp = level * 10; // TODO: area experience
			player.Exp += exp;
			player.LevelUp();
			ShortPacket fs = new ShortPacket(SMSG.EXPLORATION_EXPERIENCE);
			fs.Write(area);
			fs.Write(exp);
			
			player.BackLink.Client.Send(fs);
		}
	}
}