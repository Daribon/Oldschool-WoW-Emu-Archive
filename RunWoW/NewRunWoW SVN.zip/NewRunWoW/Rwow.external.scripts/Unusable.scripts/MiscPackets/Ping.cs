using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class Ping
	{
		[PacketHandler(CMSG.PING, ExecutionPriority.Pool)]
		public static void HandlePing(ClientBase client, BinReader data)
		{
			ShortPacket packet = new ShortPacket(SMSG.PONG);
			packet.ProcessTime = CustomDateTime.Now;
			packet.InnerTime = data.InnerTime;
			packet.Write(data.ReadUInt32());
			client.Send(packet);
		}

		[PacketHandler(CMSG.MOVE_TIME_SKIPPED)]
		public static void HandleUnk(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null)
				return;

			/*ulong GUID = */data.ReadUInt64();
			Client.Delay = data.ReadInt32();
			/*string result="Packet 718: ";
			byte [] temp=data.ReadBytes((int)data.BaseStream.Length);
			for (int i=0;i<temp.Length;i++)	
				result+=string.Format("{0,2:X2} ", temp[i]);
			LogConsole.WriteLine(LogLevel.SYSTEM,result);*/
		}
	}
}