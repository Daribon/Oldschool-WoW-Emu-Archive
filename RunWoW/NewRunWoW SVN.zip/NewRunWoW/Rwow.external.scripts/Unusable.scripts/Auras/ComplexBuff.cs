using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class ComplexBuff : BaseAura
	{
		private Dictionary<MODIFIER,ModifierPair> m_modifiers;

		protected override bool AuraStart()
		{
			float value = Caster.SpellProcessor.FullValue(Spell, Effect);
			BitArray param = new BitArray(new int[]{SpellEffect.AuraParam});

			List<MODIFIER> indexes = new List<MODIFIER>();

			switch (SpellEffect.Aura)
			{
				case AURAEFFECT.MOD_RESISTANCE_PCT:
				case AURAEFFECT.MOD_BASE_RESISTANCE_PCT:
					if (param[0])
						indexes.Add(MODIFIER.PHYS_RES_PCT);

					if (param[1])
						indexes.Add(MODIFIER.HOLY_RES_PCT);

					if (param[2])
						indexes.Add(MODIFIER.FIRE_RES_PCT);

					if (param[3])
						indexes.Add(MODIFIER.NATURE_RES_PCT);

					if (param[4])
						indexes.Add(MODIFIER.FROST_RES_PCT);

					if (param[5])
						indexes.Add(MODIFIER.SHADOW_RES_PCT);

					if (param[6])
						indexes.Add(MODIFIER.ARCANE_RES_PCT);

					value /= 100f;
					break;
				case AURAEFFECT.MOD_RESIST:
				case AURAEFFECT.MOD_RESISTANCE_EXCLUSIVE:
				case AURAEFFECT.MOD_BASE_RESISTANCE:
					if (param[0])
						indexes.Add(MODIFIER.PHYS_RES);

					if (param[1])
						indexes.Add(MODIFIER.HOLY_RES);

					if (param[2])
						indexes.Add(MODIFIER.FIRE_RES);

					if (param[3])
						indexes.Add(MODIFIER.NATURE_RES);

					if (param[4])
						indexes.Add(MODIFIER.FROST_RES);

					if (param[5])
						indexes.Add(MODIFIER.SHADOW_RES);

					if (param[6])
						indexes.Add(MODIFIER.ARCANE_RES);
					break;

				case AURAEFFECT.MOD_RATINGS:
					if (param[0]) // Increase Weapon Rating  (Depends on weapon class)
					{
						// TODO: skill check
						indexes.Add(MODIFIER.WEAPON_RATING);
					}

					if (param[1]) // Defence Rating
						indexes.Add(MODIFIER.DEFENSE_RATING);

					if (param[2]) // Dodge Rating
						indexes.Add(MODIFIER.DODGE_RATING);

					if (param[3]) // Parry Rating
						indexes.Add(MODIFIER.PARRY_RATING);

					if (param[4]) // Block Rating
						indexes.Add(MODIFIER.BLOCK_RATING);

					if (param[5]) // Melee Hit Rating
						indexes.Add(MODIFIER.MELEE_HIT_RATING);

					if (param[6]) // Ranged Hit Rating
						indexes.Add(MODIFIER.RANGED_HIT_RATING);

					if (param[7]) // Spell Hit Rating
					{
						// TODO: use different schools
						if (Spell.School == 0)
							indexes.Add(MODIFIER.SPELL_HIT_RATING);
					}

					if (param[8]) // Melee Critical Hit Rating
						indexes.Add(MODIFIER.MELEE_CRIT_RATING);

					if (param[9]) // Ranged Critical Hit rating
						indexes.Add(MODIFIER.RANGED_CRIT_RATING);

					if (param[10]) // Spell Critical Strike Rating
					{
						// TODO: use different schools
						if (Spell.School == 0)
							indexes.Add(MODIFIER.SPELL_CRIT_RATING);
					}

					if (param[14] && param[15] && param[16]) // Resilence Rating
						indexes.Add(MODIFIER.RESILENCE_RATING);

					if (param[17]) // Melee Haste Rating
						indexes.Add(MODIFIER.MELEE_HASTE_RATING);

					if (param[18]) // Ranged Haste Rating
						indexes.Add(MODIFIER.RANGED_HASTE_RATING);

					if (param[19]) // Spell Haste Rating
						indexes.Add(MODIFIER.RANGED_HASTE_RATING);
					break;
				default:
					LogConsole.WriteLine(LogLevel.ERROR, "Unknown complex buff " + SpellEffect.Aura);
					return false;
			}

			m_modifiers = new Dictionary<MODIFIER, ModifierPair>();

			foreach (MODIFIER modifier in indexes)
				m_modifiers.Add(modifier,
				                LivingTarget.Modifiers.RegisterModifier(modifier, value,
				                                                        !Visible ? UnitModifiers.DefaultKey : EffectKey));

			Cancelable = value > 0;

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed || LivingTarget.Modifiers == null)
				return;

			foreach (KeyValuePair<MODIFIER, ModifierPair> pair in m_modifiers)
					LivingTarget.Modifiers.UnregisterModifier(pair.Key, pair.Value);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_BASE_RESISTANCE_PCT, new AuraCast(Apply<ComplexBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_RESISTANCE_PCT, new AuraCast(Apply<ComplexBuff>));

			AuraManager.RegisterAura(AURAEFFECT.MOD_RESIST, new AuraCast(Apply<ComplexBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_RESISTANCE_EXCLUSIVE, new AuraCast(Apply<ComplexBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_BASE_RESISTANCE, new AuraCast(Apply<ComplexBuff>));

			AuraManager.RegisterAura(AURAEFFECT.MOD_RATINGS, new AuraCast(Apply<ComplexBuff>));
		}
	}
}