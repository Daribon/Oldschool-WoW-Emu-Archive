//
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.SpellAuras
{
	public class HoverAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return false;

			ShortPacket pkg = new ShortPacket(SMSG.MOVE_SET_HOVER);
			pkg.WriteGuid(PlayerTarget.GUID);
			PlayerTarget.BackLink.Client.Send(pkg);
			return true;
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.MOVE_UNSET_HOVER);
			pkg.WriteGuid(PlayerTarget.GUID);
			PlayerTarget.BackLink.Client.Send(pkg);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.HOVER, new AuraCast(Apply<HoverAura>));
		}
	}
}