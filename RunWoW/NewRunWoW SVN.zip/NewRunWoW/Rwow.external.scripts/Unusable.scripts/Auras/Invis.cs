using System;
using System.Collections.Generic;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class InvisAura : BaseAura
	{
		private HitDelegate m_canceler;
		private MoveDelegate m_moveCanceler;

		protected override bool AuraStart()
		{
			switch (Spell.ObjectId)
			{
				case 743:
				case 20580: // Shadowmeld
					m_moveCanceler = new MoveDelegate(Cancel);
					LivingTarget.OnMove += m_moveCanceler;
					break;
				case 6298:
					//interrupts = true;
					if (PlayerTarget != null && PlayerTarget.Area != null && PlayerTarget.Area.ObjectId != 148)
						return false;
					break;
				case 11329:
					//interrupts = true;
					if (LivingTarget.Rooted)
					{
						LivingTarget.Rooted = false;
						LivingTarget.Flags &= ~4;
					}

					LivingTarget.StopCombat();

					if (LivingTarget.Attackers != null)
					{
						ICollection<LivingObject> toRemove = LivingTarget.Attackers.Values;
						foreach (LivingObject aobj in toRemove)
							aobj.RemoveAttacker(LivingTarget);
					}
					break;
			}

			LivingTarget.InvisLevel = 1;
			LivingTarget.MapTile.Map.Reenter(LivingTarget);

			m_canceler = new HitDelegate(Cancel);
			/*if (interrupts) // I think that non-gm invis should be interrupted in any case
			{*/
			LivingTarget.OnTakeDamage += m_canceler;
			/*}*/
			LivingTarget.OnSubmitDamage += m_canceler;

			return true;
		}

		private void Cancel(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			if (LivingTarget != null)
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		private bool Cancel(DateTime time)
		{
			if (LivingTarget != null)
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null && LivingTarget.MapTile != null)
			{
				if (LivingTarget.InvisLevel == 1) // for GMs
				{
					LivingTarget.InvisLevel = 0;
					LivingTarget.MapTile.Map.Reenter(LivingTarget);
				}

				LivingTarget.OnTakeDamage -= m_canceler;
				LivingTarget.OnSubmitDamage -= m_canceler;
				LivingTarget.OnMove -= m_moveCanceler;
			}
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.INVISIBILITY, new AuraCast(Apply<InvisAura>));
			AuraManager.RegisterAura(AURAEFFECT.STEALTH, new AuraCast(Apply<InvisAura>));
		}
	}
}