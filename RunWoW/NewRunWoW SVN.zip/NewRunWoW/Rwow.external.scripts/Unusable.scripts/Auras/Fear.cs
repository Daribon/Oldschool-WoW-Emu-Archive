using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Map;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Auras;

namespace RunWoW.SpellAuras
{
	public class FearAura : BaseAura
	{
		private HitDelegate m_canceler;
        private float m_pZ = -1;  // Previous Z position , if difference in terrain too much then do not move

        protected override bool AuraStart()
        {
			Recalc(1000, Spell.Duration);

			/// TODO: set correct flag
			LivingTarget.Flags |= 4;
            LivingTarget.StopCombat();
            LivingTarget.NoControl = true;

			if (Spell.Interrupts)
			{
				m_canceler = new HitDelegate(Cancel);
				LivingTarget.OnTakeDamage += m_canceler;
			}
            return true;
		}

        protected override void AuraTick()
		{
			if (LivingTarget != null && LivingCaster != null )
			{
			    float facing;
				if (LivingCaster.Target == 0)
			        facing = LivingTarget.Facing;
			    else
			        facing = LivingCaster.Facing;

			    facing += (float)Utility.Random(-Math.PI/5, Math.PI/5);
					
			    float range = Utility.Random(Constants.FearRunMinRange, Constants.FearRunMaxRange);
			    float x = LivingTarget.Position.X + (float)Math.Cos(facing) * range;
			    float y = LivingTarget.Position.Y + (float)Math.Sin(facing) * range;
			    float z = WorldMap.GetPoint((int)LivingTarget.MapTile.Map.MapID, x, y);
			    
			    if ( m_pZ == -1 )
			        m_pZ = z;
			    if (Math.Abs(m_pZ - z) < 3)
			    {
			        Vector newpos = new Vector(x, y, z);
			        MonsterMove.MoveTo(LivingTarget, newpos, true, false, true);
			    }
			    m_pZ = z;
			}
		}

		private void Cancel(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
	    {
	        LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
	    }

		protected override void AuraFinish()
		{
			if (LivingTarget == null)
				return;
			
			if (m_canceler != null)
				LivingTarget.OnTakeDamage -= m_canceler;

			LivingTarget.Flags &= ~4;
			LivingTarget.NoControl = false;

			// Target under textures
			float z = WorldMap.GetPoint((int)LivingTarget.MapTile.Map.MapID, LivingTarget.Position.X, LivingTarget.Position.Y);
			if (LivingTarget.Position.Z < z)
			{
				LivingTarget.Position.Z = z;
				LivingTarget.UpdateData();
			}

			// TODO: Return guards and NPC to spawn point after fear.
			if (LivingTarget is NPCBase || LivingTarget is GuardBase)
			{
				LivingTarget.Position = ((UnitBase)LivingTarget).Spawn.Position;
				LivingTarget.MapTile.Map.Reenter(LivingTarget);
			}
		}

	    public static SpellFailedReason Apply
	        (ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
	    {
			if (target is UnitBase && target.Level > 60 && ((UnitBase)target).Creature.Elite > 0)
				return SpellFailedReason.MAX;

	        if (target.Dead)
	            return SpellFailedReason.MAX;

	        if (target is PetBase && ((PetBase) target).Owner == caster)
	            return SpellFailedReason.MAX;

	        if (spell.AreaCast && Faction.SameFaction(target, caster))
	            return SpellFailedReason.MAX;

			uint world = caster.MapTile.Map.MapID;

	        if (world > 1 || !WorldMap.HasMap((int) world))
				return SpellFailedReason.MAX;

/*			if (caster is UnitBase && ((UnitBase)caster).Spawn != null && (((UnitBase)caster).Spawn.WorldMapID > 1 || !WorldMap.HasMap((int)((UnitBase)caster).Spawn.WorldMapID)))
				return SpellFailedReason.SPELL_FAILED_ONLY_OUTDOORS;*/
	    	
	        IAura aura = new FearAura();
	        aura.Init(caster, target, castTarget, spell, efnum);

	        AuraTickManager.Instance.Register(aura);
	        return SpellFailedReason.MAX;
	    }

	    [InitializeHandler(InitPass.Second)]
	    public new static void Initialize()
	    {
	        AuraManager.RegisterAura(AURAEFFECT.FEAR, new AuraCast(Apply));
	    }
	}
}