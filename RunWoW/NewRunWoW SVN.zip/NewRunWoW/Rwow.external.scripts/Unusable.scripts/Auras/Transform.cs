using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.SpellAuras
{
	public class TransformAura : BaseAura
	{
		private int m_displayId;

		private TransformAura(int displayID)
		{
			m_displayId = displayID;
		}

		protected override bool AuraStart()
		{
			if (LivingTarget == null)
				return false;

			LivingTarget.DisplayID = m_displayId;
			LivingTarget.TransformSpell = Spell.ObjectId;

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null)
				return;

			LivingTarget.DisplayID = LivingTarget.NativeDisplayID;
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			DBCreature creature =
				(DBCreature) Database.Instance.FindObjectByKey(typeof (DBCreature), spell.Effect[efnum].AuraParam);

			if (creature == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "No creature for transform: " + spell.Effect[efnum].AuraParam);
				creature = (DBCreature) Database.Instance.FindObjectByKey(typeof (DBCreature), 1933);
			}

			if (creature == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "No creature for transform: " + 1933);
				return SpellFailedReason.SPELL_FAILED_ERROR;
			}

			IAura aura = new TransformAura(creature.DisplayID);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.TRANSFORM, new AuraCast(Apply));
		}
	}
}