using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class MechanicResistAura : BaseAura
	{
		private float m_value;
		private ResistCheckDelegate m_resistCheck;

		protected override bool AuraStart()
		{
			m_value = SpellEffect.Value;

			m_resistCheck = new ResistCheckDelegate(ResistCheck);
			LivingTarget.OnResistCheck += m_resistCheck;
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null)
				LivingTarget.OnResistCheck -= m_resistCheck;
		}

		public float ResistCheck(DBSpell spell, ObjectBase enemy)
		{
			if (spell != null && spell.MechanicDispelType == (MechanicDispelType) SpellEffect.AuraParam)
				return m_value;

			return 0f;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_MECHANIC_RESISTANCE, new AuraCast(Apply<MechanicResistAura>));
		}
	}
}