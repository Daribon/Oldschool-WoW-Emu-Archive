using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.SpellAuras;
using RunWoW.Spells;

namespace RunWoW.ExternalScripts.Auras.Script
{
	internal class DeepWoundsScript : BaseAura
	{
		private DateTime m_lastProc;

		private HitDelegate m_placeDamage;

		private DBSpell m_dwSpell;

		protected override bool AuraStart()
		{
			if (Target == null || LivingCaster == null)
				return false;

			m_dwSpell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), SpellEffect.Spell);

			if (m_dwSpell == null)
				return false;

			m_placeDamage = new HitDelegate(OnPlaceHitProc);
			LivingTarget.OnSubmitDamage += m_placeDamage;
			m_lastProc = CustomDateTime.Now;
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null)
			{
				if (m_placeDamage != null)
					LivingTarget.OnSubmitDamage -= m_placeDamage;
			}
		}

		public void OnPlaceHitProc(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell,
		                           ObjectBase enemy, bool critical)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;

			if (!critical || damageType != DAMAGETYPE.PHYSICAL || category != DAMAGECATEGORY.MELEE)
				return;

			if (m_lastProc + TimeSpan.FromMilliseconds(Constants.SpellProcDelay) > CustomDateTime.Now)
				return;

			m_lastProc = CustomDateTime.Now;

			float sdamage = damage * m_dwSpell.Rank / 5f;

			if (sdamage == 0f)
				sdamage = damage;
			// TODO: think, how we can cast m_dwSpell with custom damage

			SpellManager.Cast(LivingCaster, lenemy, m_dwSpell);
			LivingTarget.SubmitPeriodicDamage(lenemy, m_dwSpell, m_dwSpell.School, sdamage, sdamage);
		}


		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAuraEffectPatch(12834, 0, new AuraCast(Apply<DeepWoundsScript>));
			AuraManager.RegisterAuraEffectPatch(12849, 0, new AuraCast(Apply<DeepWoundsScript>));
			AuraManager.RegisterAuraEffectPatch(12867, 0, new AuraCast(Apply<DeepWoundsScript>));
			AuraManager.RegisterAuraEffectPatch(23255, 0, new AuraCast(Apply<DeepWoundsScript>));
		}
	}
}