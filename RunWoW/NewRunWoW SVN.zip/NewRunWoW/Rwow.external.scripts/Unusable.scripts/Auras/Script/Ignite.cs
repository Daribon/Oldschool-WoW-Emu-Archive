//
using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.SpellAuras;
using RunWoW.Spells;

namespace RunWoW.ExternalScripts.Auras.Script
{
	// Ignite mage spell
	internal class IgniteScript : BaseAura
	{
		private static DBSpell s_igniteSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 12654);

		private DateTime m_lastProc;

		private HitDelegate m_placeDamage;

		protected override bool AuraStart()
		{
			if (Target == null || LivingCaster == null)
				return false;

			m_placeDamage = new HitDelegate(OnPlaceHitProc);
			LivingTarget.OnSubmitDamage += m_placeDamage;
			m_lastProc = CustomDateTime.Now;
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null)
			{
				if (m_placeDamage != null)
					LivingTarget.OnSubmitDamage -= m_placeDamage;
			}
		}

		public void OnPlaceHitProc(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell,
								   ObjectBase enemy, bool critical)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;

			if (!critical || damageType != DAMAGETYPE.FIRE)
				return;

			if (m_lastProc + TimeSpan.FromMilliseconds(Constants.SpellProcDelay) > CustomDateTime.Now)
				return;

			m_lastProc = CustomDateTime.Now;

			int efnum = -1;

			for (int i = 0; i < 3; i++)
				if (spell.Effect[i].Type == SPELLEFFECT.SCHOOL_DAMAGE)
				{
					efnum = i;
					break;
				}

			if (efnum == -1)
			{
				Console.WriteLine("Casting Ignite for non-damage spell {0}", spell.Name);
				return;
			}

			float sdamage = LivingCaster.SpellProcessor.FullDamage(spell, (byte)efnum) * Spell.Rank * 8f / 100f;

			// TODO: think, how we can cast spell 12654 with custom damage

			SpellManager.Cast(LivingCaster, lenemy, s_igniteSpell);
			LivingTarget.SubmitPeriodicDamage(lenemy, s_igniteSpell, s_igniteSpell.School, sdamage, sdamage);
		}


		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAuraEffectPatch(11119, 0, new AuraCast(Apply<IgniteScript>));
			AuraManager.RegisterAuraEffectPatch(11120, 0, new AuraCast(Apply<IgniteScript>));
			AuraManager.RegisterAuraEffectPatch(12846, 0, new AuraCast(Apply<IgniteScript>));
			AuraManager.RegisterAuraEffectPatch(12847, 0, new AuraCast(Apply<IgniteScript>));
			AuraManager.RegisterAuraEffectPatch(12848, 0, new AuraCast(Apply<IgniteScript>));
		}
	}
}