using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.SpellAuras
{
	public class WWalkAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return false;

			ShortPacket pkg = new ShortPacket(SMSG.MOVE_WATER_WALK);
			pkg.WriteGuid(PlayerTarget.GUID);
			PlayerTarget.BackLink.Client.Send(pkg);
			return true;
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.MOVE_LAND_WALK);
			pkg.WriteGuid(PlayerTarget.GUID);
			PlayerTarget.BackLink.Client.Send(pkg);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.WATER_WALK, new AuraCast(Apply<WWalkAura>));
		}
	}
}