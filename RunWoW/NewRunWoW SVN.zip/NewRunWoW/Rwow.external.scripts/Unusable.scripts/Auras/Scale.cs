using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class ScaleAura : BaseAura
	{
		private float m_oldValue;
		private HitDelegate m_canceler;

		protected override bool AuraStart()
		{
			if (Target == null)
				return false;
			
			m_oldValue = Target.Scale;

			Target.Scale += Target.Scale*(SpellEffect.Value/100f);

			if (Spell.Interrupts && LivingTarget != null)
			{
				m_canceler = new HitDelegate(Cancel);
				LivingTarget.OnTakeDamage += m_canceler;
			}
			return true;
		}

		private void Cancel(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		protected override void AuraFinish()
		{
			if (Target != null)
			{
				Target.Scale = m_oldValue;
				Target.UpdateData();
			}
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.SCALE, new AuraCast(Apply<ScaleAura>));
		}
	}
}