using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.SpellAuras
{
	public class FFallAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return false;

			ShortPacket pkg = new ShortPacket(SMSG.MOVE_FEATHER_FALL);
			pkg.WriteGuid(PlayerTarget.GUID);
			PlayerTarget.BackLink.Client.Send(pkg);
			return true;
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return;

			ShortPacket pkg = new ShortPacket(SMSG.MOVE_NORMAL_FALL);
			pkg.WriteGuid(PlayerTarget.GUID);
			PlayerTarget.BackLink.Client.Send(pkg);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.FEATHER_FALL, new AuraCast(Apply<FFallAura>));
		}
	}
}