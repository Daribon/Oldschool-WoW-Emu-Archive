using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class SilenceAura : BaseAura
	{
		private HitDelegate m_canceler;

		protected override bool AuraStart()
		{
			if (LivingTarget == null)
				return false;

			Cancelable = false;
			
			LivingTarget.Silenced = true;

			if (Spell.Interrupts)
			{
				m_canceler = new HitDelegate(Cancel);
				LivingTarget.OnTakeDamage += m_canceler;
			}

			if (PlayerTarget != null)
				PlayerTarget.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);
			
			return true;
		}


		private void Cancel(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return;

			LivingTarget.Silenced = false;

			if (m_canceler != null)
				LivingTarget.OnTakeDamage -= m_canceler;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.SILENCE, new AuraCast(Apply<SilenceAura>));
		}
	}
}