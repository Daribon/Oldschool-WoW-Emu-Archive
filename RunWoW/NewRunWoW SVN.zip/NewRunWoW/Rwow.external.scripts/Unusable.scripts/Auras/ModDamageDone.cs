using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class ModDamageDoneAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return false;

			if (LivingTarget.SpellProcessor is SpellModifiers)
				((SpellModifiers)LivingTarget.SpellProcessor).SetDamageModifier(SpellEffect.AuraParam, (int)SpellEffect.Value, !Visible);
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return;

			if (LivingTarget.SpellProcessor is SpellModifiers)
				((SpellModifiers)LivingTarget.SpellProcessor).RemoveDamageModifier(SpellEffect.AuraParam, (int)SpellEffect.Value, !Visible);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_DAMAGE_DONE, new AuraCast(Apply<ModDamageDoneAura>));
		}
	}
}