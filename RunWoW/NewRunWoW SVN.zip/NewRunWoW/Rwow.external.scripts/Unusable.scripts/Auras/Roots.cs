using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class RootAura : BaseAura
	{
		private HitDelegate m_canceler;

		protected override bool AuraStart()
		{
			if (LivingTarget == null || LivingTarget.Rooted)
				return false;

			Cancelable = false;

			LivingTarget.Flags |= 0x4000000;
			LivingTarget.Rooted = true;
			LivingTarget.MovementFlags &= ~31;

			if (PlayerTarget != null)
			{
				if (Constants.BurningCrusade)
				{
					/*ShortPacket pkg = new ShortPacket(SMSG.MOVE_ROOT);
					pkg.WriteGuid(PlayerTarget.GUID);
					pkg.Write(PlayerTarget.MovementFlags);
					int timePos = pkg.BaseStream.Position;
					pkg.Write(Utility.PreciseTimestamp());
					pkg.WriteVector(PlayerTarget.Position);
					pkg.Write(PlayerTarget.Facing);
					pkg.Write(0);

					PlayerTarget.MapTile.SendSurroundingTimed(pkg, PlayerTarget, null, timePos);*/
				}
				else
				{
					ShortPacket pkg = new ShortPacket(SMSG.MOVE_ROOT);
					pkg.Write(PlayerTarget.GUID);
					pkg.Write(2);
					PlayerTarget.BackLink.Client.Send(pkg);
				}
			}
			else
				MonsterMove.FixPosition(LivingTarget);

			if (Spell.Interrupts)
			{
				m_canceler = new HitDelegate(Cancel);
				LivingTarget.OnTakeDamage += m_canceler;
			}

			//if (PlayerTarget != null)
			//    PlayerTarget.CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);
			
			return true;
		}

		private void Cancel(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			if (damageType != Spell.School && Utility.Chance(damage/(LivingTarget.Level*30f)))
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget != null)
			{
				if (Constants.BurningCrusade)
				{
					/*ShortPacket pkg = new ShortPacket(SMSG.MOVE_UNROOT);
					pkg.WriteGuid(PlayerTarget.GUID);
					pkg.Write(PlayerTarget.MovementFlags);
					int timePos = pkg.BaseStream.Position;
					pkg.Write(0);
					pkg.WriteVector(PlayerTarget.Position);
					pkg.Write(PlayerTarget.Facing);
					pkg.Write(0);

					PlayerTarget.MapTile.SendSurroundingTimed(pkg, PlayerTarget, null, timePos);*/
				}
				else
				{
					ShortPacket pkg = new ShortPacket(SMSG.MOVE_UNROOT);
					pkg.Write(PlayerTarget.GUID);
					PlayerTarget.BackLink.Client.Send(pkg);
				}
			}

			LivingTarget.Flags &= 0x4000000;
			LivingTarget.Rooted = false;

			if (m_canceler != null)
				LivingTarget.OnTakeDamage -= m_canceler;
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			/*if (spell.School != DAMAGETYPE.FROST)
				if (caster is PlayerObject && ((PlayerObject) caster).WorldMapID > 1)
					return SpellFailedReason.SPELL_FAILED_ONLY_OUTDOORS;*/

			if (target is UnitBase && target.Level > 60 && ((UnitBase)target).Creature.Elite > 0)
				return SpellFailedReason.SPELL_FAILED_IMMUNE;

			IAura aura = new RootAura();
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.ROOT, new AuraCast(Apply));
		}
	}
}