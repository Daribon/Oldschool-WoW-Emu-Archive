using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.SpellAuras
{
	public class WaterBreathingAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return false;

			PlayerTarget.BreathUnderwater = true;

			return true;
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget != null && !PlayerTarget.IsDisposed)
				PlayerTarget.BreathUnderwater = false;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.WATER_BREATHING, new AuraCast(Apply<WaterBreathingAura>));
		}
	}
}