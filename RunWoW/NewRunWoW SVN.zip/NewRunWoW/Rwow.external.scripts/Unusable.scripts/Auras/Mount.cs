using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.SpellAuras
{
	public class MountAura : BaseAura
	{
		private HitDelegate m_canceler;
		private int m_mountId;

		public MountAura(int mountId)
		{
			m_mountId = mountId;
		}

		protected override bool AuraStart()
		{
			LivingTarget.Mount(m_mountId);

			if (PlayerTarget != null)
				PlayerTarget.MountSpell = Spell.ObjectId;

			m_canceler = new HitDelegate(CancelMount);
			LivingTarget.OnTakeDamage += m_canceler;

			return true;
		}

		private void CancelMount(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			if (Utility.Chance(damage/(LivingTarget.Level*20f)))
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return;

			LivingTarget.Unmount();
			LivingTarget.OnTakeDamage -= m_canceler;

			if (PlayerTarget != null)
				PlayerTarget.MountSpell = 0;
			
			LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			DBCreature creature =
				Database.Instance.FindObjectByKey(typeof (DBCreature), spell.Effect[efnum].AuraParam) as DBCreature;

			if (creature == null)
			{
				LogConsole.WriteLine(LogLevel.ECHO, "No creature for mount: " + spell.Effect[efnum].AuraParam);
				return SpellFailedReason.MAX;
			}
			else
				LogConsole.WriteLine(LogLevel.ECHO, "Mount {0} for {1}", creature.Name, target.Name);

			//if (target is PlayerObject)
			//{
			//    PlayerObject player = (PlayerObject) target;
			//    if (player.MountSpell != 0)
			//    {
			//        LogConsole.WriteLine(LogLevel.ERROR, "Speed Bug: " + player.Name);
			//        player.BackLink.Client.Close("GameMaster kicked" + player.Name);
			//        return SpellFailedReason.MAX;
			//    }
			//}

			IAura aura = new MountAura(creature.DisplayID);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOUNTED, new AuraCast(Apply));
		}
	}
}