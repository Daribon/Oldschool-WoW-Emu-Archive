//
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class DeathItemAura : BaseAura
	{
		protected override bool AuraStart()
		{
			return (LivingCaster is PlayerObject);
		}

		protected override void AuraTick()
		{
			if (!LivingTarget.Attackable)
				Finish();
		}

		protected override void AuraFinish()
		{
			PlayerObject player = ((PlayerObject) LivingCaster);
			if (LivingTarget.Dead && !player.Dead && player.BackLink != null &&
			    (LivingTarget.AllowedLooter == player.GUID ||
			     LivingTarget.AllowedLootGroup == player.Character.GroupID))
			{
				uint item = SpellEffect.Category;
				DBItem nitem = DBUtility.ItemOfChar(player.Character, item, INVSLOT.MAX, 1);
				nitem.Creator = player.CharacterID;
				if (!player.Inventory.CanAddItem(nitem))
				{
					Items.SendChangeFail(player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
				}
				else
				{
					player.Inventory.AddItem(nitem, true);
					player.UpdateData();
				}
			}
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.DEATH_ITEM, new AuraCast(Apply<DeathItemAura>));
		}
	}
}