using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.SpellAuras;
using RunServer.Common.Attributes;
//using RunWoW.ExternalScripts.ExternalDB;

namespace RunWoW.Spells
{
	public class AuraSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{

			//// check for creature type - need implement somewhere deeper
			//if (target is UnitBase && m_spell.CreatureType != 0 )
			//{
			//    UnitBase unit = (UnitBase)target;
			//    if ( !CastManager.IsValidCreatureType((CreatureType)unit.CreatureType,m_spell ))
			//        return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
			//}

			return AuraManager.ProcessAura(caster, target, castTarget, m_spell, effect);
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.AURA, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.AURA_NEW, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.AREA_AURA, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.PERSISTENT_AREA_AURA, new SpellCastOnLiving(Cast));
		}
	}
}