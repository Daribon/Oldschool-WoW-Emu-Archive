using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class ResurrectSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			LogConsole.WriteLine(LogLevel.SYSTEM, caster.Name + "Resurrecting " + target.Name);
			if (!target.Dead)
				return SpellFailedReason.SPELL_FAILED_TARGET_NOT_DEAD;
			PlayerObject Player = target as PlayerObject;
			if (Player == null)
				return SpellFailedReason.SPELL_FAILED_TARGET_NOT_PLAYER;

			Player.Dead = false;

			int health = 0;
			int mana = 0;
			int dam = 0;

			if (caster is LivingObject && caster.SpellProcessor != null)
				dam = caster.SpellProcessor.FullDamage(m_spell, effect);
			else
				dam = m_spell.Effect[effect].Damage + m_spell.Effect[effect].RandomDamage;

			if ((m_spell.Effect[effect].Type == SPELLEFFECT.SELF_RESURRECT || m_spell.Effect[effect].Type == SPELLEFFECT.SPIRIT_HEAL))
				dam = -dam;

			if (dam < 0) // percentage
			{
				health = -(int) (Player.MaxHealth*dam/100f);
				mana = -(int) (Player.MaxPower*dam/100f);
			}
			else
			{
				health = dam;
				mana = m_spell.Effect[effect].AuraParam;
			}
			if (Player.PowerType != POWERTYPE.RAGE && Player.PowerType != POWERTYPE.ENERGY)
				Player.Power = mana > Player.MaxPower ? Player.MaxPower : mana;

			Player.Health = health > Player.MaxHealth ? Player.MaxHealth : health;

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.RESURRECT, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.RESURRECT_NEW, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SELF_RESURRECT, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SPIRIT_HEAL, new SpellCastOnLiving(Cast));
		}
	}
}