using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;
//using RunWoW.ExternalScripts.ExternalDB;

namespace RunWoW.Spells
{
	public class OffensiveSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			if ((caster == target && m_spell.Effect[effect].Radius > 0) || (target is PetBase && ((PetBase) target).Owner == caster) || target.Dead)
				return SpellFailedReason.MAX;

			LivingObject lcaster = caster as LivingObject;

			//if (m_spell.CreatureType > 0 )
			//{
			//    if ( !(target is UnitBase) || !CastManager.IsValidCreatureType( (CreatureType)((UnitBase)target).Creature.CreatureType,m_spell) )
			//        return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
			//}

			if (Faction.SameFaction(target, caster))
				return SpellFailedReason.MAX;

			if (caster != target && lcaster!=null)
			{
				if (target is PlayerObject && !((PlayerObject)target).PvP)
					return SpellFailedReason.SPELL_FAILED_TARGET_IS_PLAYER;

				target.Attacked(lcaster);
			}

			int mindamage = caster.SpellProcessor.PureDamage(m_spell, effect);
			int maxdamage = caster.SpellProcessor.FullDamage(m_spell, effect);

			PlayerObject Player = caster as PlayerObject;
			if (Player != null && m_spell.Effect[effect].Combo != 0 && Player.ComboPoints > 0)
			{
				if (Player.ComboTarget == target.GUID)
				{
					mindamage += (int) (m_spell.Effect[effect].Combo*Player.ComboPoints);
					maxdamage += (int) (m_spell.Effect[effect].Combo*Player.ComboPoints);
				}
				Player.ComboPoints = 0;
				Player.ComboTarget = 0;
				Player.UpdateData();
			}


			if (lcaster != null && m_spell.Effect[effect].Type == SPELLEFFECT.POWER_BURN) // Burn mana
            {
                if (target.Power <= 0 || target.PowerType != lcaster.PowerType)
                    return SpellFailedReason.MAX;
                int powerdamage = Utility.Random(mindamage, maxdamage);
                target.Power -= powerdamage;
                target.Power = target.Power < 0 ? 0 : target.Power;

                powerdamage = (int)(powerdamage * m_spell.Effect[effect].Percent);

                lcaster.SubmitMagicDamage(target, m_spell, m_spell.School, powerdamage, powerdamage);
                
                //lcaster.Power += powerdamage;
                //lcaster.Power = lcaster.Power > lcaster.MaxPower?lcaster.MaxPower:lcaster.Power;
                //mindamage = powerdamage / 2;
                //maxdamage = mindamage;
                return SpellFailedReason.MAX;
            }


			if (m_spell.Effect[effect].Type == SPELLEFFECT.ENVIRONMENTAL_DAMAGE)
				target.TakeEnvironmentDamage(caster, m_spell, (DAMAGETYPE)5, mindamage, maxdamage);
			else
				if (lcaster != null)
				{
					// find correct target for spell
					//LivingObject pureTarget = CastManager.PureTarget(lcaster, target, m_spell.Effect[effect].TargetB);
					lcaster.SubmitMagicDamage(target, m_spell, m_spell.School, mindamage, maxdamage);
				}
				else
					target.TakeMagicDamage(caster, m_spell, m_spell.School, mindamage, maxdamage, 95.0f, 5.0f);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SCHOOL_DAMAGE, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.ENVIRONMENTAL_DAMAGE, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.POWER_BURN, new SpellCastOnLiving(Cast));
		}
	}
}