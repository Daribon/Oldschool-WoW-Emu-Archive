using System.Collections.Generic;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class HealSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			LivingObject lcaster = caster as LivingObject;


			int value = lcaster != null && lcaster.SpellProcessor != null
			            	?
								spell.Effect[effect].Type == SPELLEFFECT.HEAL_MAX_HEALTH ?
										lcaster.MaxHealth
			            			:
										lcaster.SpellProcessor.FullDamage(spell, effect)
			            	:
							spell.Effect[effect].Damage + spell.Effect[effect].RandomDamage;

			if (lcaster != null)
			{
				bool critical =
					Utility.Chance((lcaster is PlayerObject)
					               	? ((PlayerObject) lcaster).MagicCritChance/100f
					               	: 0.1f + (0.002f*(caster.Level - target.Level)));
				if (critical)
					value = value*3/2;
			}

			switch (spell.Effect[effect].Type)
			{
				case SPELLEFFECT.SCRIPT:
				case SPELLEFFECT.HEAL_HEALTH:
				case SPELLEFFECT.HEAL_MAX_HEALTH:

					if (target.Health == target.MaxHealth)
						return SpellFailedReason.SPELL_FAILED_ALREADY_AT_FULL_HEALTH;

					if (value + target.Health > target.MaxHealth)
						value = target.MaxHealth - target.Health;

					if (caster is LivingObject)
					{
						ICollection<LivingObject> toAttack = target.Attackers.Values;

						foreach (LivingObject attacker in toAttack)
							attacker.AddThreat(caster, value/2);
					}

					target.Health += value;

					return SpellFailedReason.MAX;
				case SPELLEFFECT.HEAL_POWER:
					LivingObject pureTarget = target;

					if (caster is LivingObject)
					{
						if (spell.Effect[effect].TargetB == (int) TARGET.TARGET_SELF)
							pureTarget = (LivingObject) caster;
					}

					if ((int) pureTarget.PowerType != spell.Effect[effect].AuraParam)
						return SpellFailedReason.MAX;

					if (pureTarget.Power == pureTarget.MaxPower)
						return SpellFailedReason.MAX;

					if (value + pureTarget.Power > pureTarget.MaxPower)
						value = pureTarget.MaxPower - pureTarget.Power;

					pureTarget.Power += value;

					return SpellFailedReason.MAX;
			}

			//caster.MapTile.SendSurrounding(DamageLog.Heal(target.GUID, caster.GUID, spell.ObjectId, value, critical), null);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.HEAL_HEALTH, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.HEAL_POWER, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.HEAL_MAX_HEALTH, new SpellCastOnLiving(Cast));
		}
	}
}