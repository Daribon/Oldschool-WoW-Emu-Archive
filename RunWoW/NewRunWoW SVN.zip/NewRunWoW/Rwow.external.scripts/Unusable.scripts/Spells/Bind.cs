using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells
{
	public class BindSpell
	{
		public static DBItemTemplate HearthstoneTemplate = DBUtility.GetTemplate(6948);

		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject Player = target as PlayerObject;
			if (Player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			Player.Character.BindPoint = Player.Position;
			Player.Character.BindZone = Player.Zone;
			Player.Character.BindWorld = Player.WorldMapID;
			ShortPacket bp = new ShortPacket(SMSG.BINDPOINTUPDATE);
			bp.WriteVector(Player.Character.BindPoint);
			bp.Write(Player.Character.BindWorld);
			bp.Write(Player.Character.BindZone); // Should be zone last
			Player.BackLink.Client.Send(bp);

			if (Player.Inventory.FindItem(6948) == null)
			{
				DBItem stone = new DBItem(HearthstoneTemplate);
				if (!Player.Inventory.CanAddItem(stone))
					Items.SendChangeFail(Player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
				else
				{
					stone.OwnerID = Player.CharacterID;
					DBManager.NewDBObject(stone);
					Player.Character.Items.Add(stone);
					Player.Inventory.AddNewItem(stone, true);
				}
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.BIND, new SpellCastOnLiving(Cast));
		}
	}
}