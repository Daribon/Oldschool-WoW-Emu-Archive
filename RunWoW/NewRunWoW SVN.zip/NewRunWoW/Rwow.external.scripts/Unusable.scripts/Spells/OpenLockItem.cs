using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GameObjects;
using RunWoW.GamePackets;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells
{
	public class OpenLockItem
	{
		public static SpellFailedReason Cast(ObjectBase caster, GameObject target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect, ref SpellFinishHandler linked)
		{
			int lockId = target.Template.Sound[0];
			PlayerObject player = caster as PlayerObject;

			if (player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			DBLock dbLock = (DBLock) Database.Instance.FindObjectByKey(typeof (DBLock), lockId);

			if (dbLock != null)
				switch (dbLock.Type)
				{
					case 1:
						switch (target.TypeID)
						{
							case (int) GameObjectType.Container:
							case (int) GameObjectType.QuestGiver:
								target.Opened(player);
								if (target.Loot == null)
									target.GenerateLoot();
								if (target.Loot != null && target.Loot.Count > 0)
									linked = new SpellFinishHandler(Loot.DoOpenLoot);
								if (target.TypeID == (int) GameObjectType.QuestGiver)
									QuestGameObject.Process(player, target);
								break;
							case (int) GameObjectType.Goober:
								ShortPacket pckg = new ShortPacket(SMSG.GAMEOBJECT_CUSTOM_ANIM);
								pckg.Write(target.GUID);
								pckg.Write(0);
								player.BackLink.Client.Send(pckg);
								// shoulbe some script processor here , because no link what to do next..
								break;
						}
						break;
				}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.OPEN_LOCK_ITEM, new SpellCastOnObject(Cast));
		}
	}
}