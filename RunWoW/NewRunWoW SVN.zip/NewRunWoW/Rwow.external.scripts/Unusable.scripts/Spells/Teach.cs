using System.Collections;
using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
    public class TeachSpell
    {
        public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell teachSpell, byte effect,
                                             ref SpellFinishHandler Linked)
        {
            ushort spellid = (ushort) teachSpell.Effect[effect].Spell;

			if (teachSpell.TargetSpell == null)
				teachSpell.TargetSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), spellid);

			if (teachSpell.TargetSpell == null)
                return SpellFailedReason.SPELL_FAILED_ERROR;

            if (target is PlayerObject)
            {
                PlayerObject Player = (PlayerObject) target;

                ShortPacket pkg = new ShortPacket(SMSG.LEARNED_SPELL);
                pkg.Write(spellid);
                pkg.Write((ushort) 0);
                Player.BackLink.Client.Send(pkg);

                // Hunter: Changed teachSpell to spell  because we have ReqSpell attributes only for final[non-teach] spells.
				DBAbility prev = Player.Spells[teachSpell.TargetSpell.ReqSpellID];

				ushort prevTalent = prev == null ? (ushort)0 : prev.TalentID;

                DBAbility ability;
                
                if (teachSpell.TargetSpell.TempSkill != null && teachSpell.TargetSpell.TempSkill.Craft != 2 && teachSpell.TargetSpell.TempSkill.Craft != 3)
                {
                    LogConsole.WriteLine(LogLevel.ECHO, "Player {0} teaching skill {1}", Player.Name, spellid);
                    ability = DBUtility.SkillOfChar(Player.Character, teachSpell.TargetSpell.TempSkill);

					Player.Skills.LoadSkill(ability);
					/*if (prev != null && Player.Skills[(SKILL)spell.TempSkill.SkillID] != null)
                        Player.Skills.LoadSkill(ability);
                    else
                        Player.Skills.AddSkill(ability);*/
                	
                	if (teachSpell.TargetSpell.HasEffect(SPELLEFFECT.PROFICIENCY))
                		Player.Skills.UpdateProficiencies();
                	
                    if (teachSpell.TargetSpell.TempSkill.Level == 1) // only for first spells
                    {
                        ICollection skills =
                            Database.Instance.FindObjectsByField(typeof (DBSSkill), "Skill_ID", teachSpell.TargetSpell.TempSkill.SkillID);

                        foreach (DBSSkill sspell in skills)
                            if (Player.Spells[(ushort) sspell.SpellID] == null)
                            {
                                ShortPacket pkg1 = new ShortPacket(SMSG.LEARNED_SPELL);
                                pkg1.Write(sspell.SpellID);
                                Player.BackLink.Client.Send(pkg1);
                                Player.Spells.AddSpell((ushort) sspell.SpellID);
                            }
                    }
                    Player.Spells.AddSpell(ability);
                }
                else
                {
                    LogConsole.WriteLine(LogLevel.TRACE, "Player {0} teaching spell {1}", Player.Name, spellid);
                	
                    ability = Player.Spells.AddSpell(spellid);
				}
                if (prev != null && prev.Spell.PowerCost == ability.Spell.PowerCost && prev.Type != ABILITYTYPE.SKILL && prev.Type != ABILITYTYPE.TALENT )
                {
                    //Player.Player.Skills.
                    Player.Spells.RemoveSpell(prev.SpellID);
                    ShortPacket pkgrem = new ShortPacket(SMSG.REMOVED_SPELL);
                    pkgrem.Write(prev.SpellID);
                    Player.BackLink.Client.Send(pkgrem);
                }

				if (ability != null && prevTalent != 0)
				{
					ability.TalentID = prevTalent;
					DBManager.SaveDBObject(ability);
				}

				if (ability != null && ability.Spell != null && ability.Spell.Passive)
					SpellManager.SelfCast(Player, ability.Spell);

                Player.Redress();
                Player.Save();
                //Player.UpdateData();
                Player.ForceUpdateData();

                return SpellFailedReason.MAX;
            }
            else if (target is PetBase)
            {
                PetBase pet = (PetBase) target;

                bool isNew = true;
                if (teachSpell.TargetSpell.ReqSpellID != 0)
                {
                    DBPetSpell oldSpell = null;
                    foreach (DBPetSpell old in pet.DBPet.Spells)
                        if (old.SpellID == teachSpell.TargetSpell.ReqSpellID)
                        {
                            oldSpell = old;
                            break;
                        }
                    if (oldSpell == null)
                        return SpellFailedReason.SPELL_FAILED_SPELL_UNAVAILABLE;
                    else
                    {
                        oldSpell.SpellID = spellid;
                        DBManager.SaveDBObject(oldSpell);
                        isNew = false;
                    }
                }

                if (isNew)
                    DBUtility.SpellOfPet(pet.DBPet, spellid);

                DBManager.SaveDBObject(pet.DBPet);
                pet.SendSpells();

                return SpellFailedReason.MAX;
            }
            else
            {
                LogConsole.WriteLine(LogLevel.ERROR, "Asked to teach non-player object with spell " + teachSpell.SpellID);
                return SpellFailedReason.SPELL_FAILED_ERROR;
            }
        }

        [InitializeHandler(InitPass.Third)]
        public static void Initialize()
        {
            SpellManager.RegisterSpell(SPELLEFFECT.TEACH, new SpellCastOnLiving(Cast));

			SpellManager.RegisterTargetPatch(33389, TARGET.ANY);
			SpellManager.RegisterTargetPatch(33392, TARGET.ANY);
			SpellManager.RegisterTargetPatch(34092, TARGET.ANY);
			SpellManager.RegisterTargetPatch(34093, TARGET.ANY);
        }
    }
}