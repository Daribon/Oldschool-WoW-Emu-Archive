using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class InstantKill
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			LivingObject ntarget = target;
			switch(m_spell.SpellID)
			{
                case 7812:
			    case 19438:
                case 19440:
                case 19441:
                case 19442:
                case 19443:
                    ntarget = caster as LivingObject;
                    break;
			}
		    
            if (ntarget == null || !ntarget.Attackable)
                return SpellFailedReason.SPELL_FAILED_ERROR;
				
			ntarget.Die();

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.INSTAKILL, new SpellCastOnLiving(Cast));
		}
	}
}
