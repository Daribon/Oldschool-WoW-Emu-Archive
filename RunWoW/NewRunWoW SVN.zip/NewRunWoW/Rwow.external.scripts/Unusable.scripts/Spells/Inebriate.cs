using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class Inebriate
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect,
		                                     ref SpellFinishHandler Linked)
		{
			PlayerObject player = target as PlayerObject;
			if (player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			int value = player.SpellProcessor.FullDamage(m_spell, effect) + player.Drunk;
			if (value > 255)
				value = 255;
			if (value < 0)
				value = 0;

			player.Drunk = (byte) value;

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.INEBRIATE, new SpellCastOnLiving(Cast));
		}
	}
}