using System.Collections.Generic;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class Skinning
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler linked)
		{
			PlayerObject Player = caster as PlayerObject;
			if (Player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			if (target == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			if (target.Flags == 0) // fast check
				return SpellFailedReason.SPELL_FAILED_TARGET_UNSKINNABLE;

			UnitBase unit = target as UnitBase;

			if (unit == null || ((unit.Flags & 0x4000000) == 0)) // nor beast, nor dragon
				return SpellFailedReason.SPELL_FAILED_TARGET_UNSKINNABLE;

			if ((unit.Loot != null && unit.Loot.Count > 0) || unit.Money > 0)
				return SpellFailedReason.SPELL_FAILED_TARGET_NOT_LOOTED;
			
			int slevel = Player.Skills.SkillLevel(SKILL.SKINNING);
			int templateId = 2934; // Ruined Leather Scraps
			DBItemTemplate template = null;
			if ((slevel < 50 && unit.Level > 10) || (slevel > 50 && slevel < unit.Level*5))
			{
				return SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT;
			}
			else
			{
				/// TODO: we can analyze loot table for all creatures and change loot category for hides, scales, etc.
				/// that way we can remove skinning loot from regular loot and make skinning loot without separate table
				//if (unit.CreatureType == 2 && Utility.Chance(0.8)) // dragon scale
				//    templateId = Utility.Chance(0.33) ? Utility.Chance(0.5) ? 15414 : 15415 : 15416;
				//else if (unit.CreatureFamily == 19 && Utility.Chance(0.8)) // scorpid scale
				//    templateId = 15408;
				//else if (unit.CreatureFamily == 20 && unit.Level >= 50 && Utility.Chance(0.8)) // turtle scale
				//    templateId = 8167;
				//else if (unit.Level < 5)
				//    templateId = Utility.Chance(0.5) ? 2934 : 4865;
				//else if (unit.Level < 16)
				//    templateId = Utility.Chance(0.5) ? 2318 : 783;
				//else if (unit.Level < 31)
				//    templateId = Utility.Chance(0.5) ? 2319 : 4232;
				//else if (unit.Level < 41)
				//    templateId = Utility.Chance(0.5) ? 4234 : 4235;
				//else if (unit.Level < 51)
				//    templateId = Utility.Chance(0.5) ? 4304 : 8169;
				//else
				//    templateId = Utility.Chance(0.5) ? 8170 : 8171;


				if (Utility.Chance((slevel - (unit.Level - 5) * 5f) / 50f) && unit.Spawn != null ) // 50% for same level mob, 100% for -5 level
				{
					List<DBItemTemplate> skinningLoot = new List<DBItemTemplate>();

					foreach (DBLoot loot in unit.Spawn.Loot)
					{
						if (loot == null || loot.Category != LootCategory.SKINNING)
							continue;
						skinningLoot.Add(loot.Target);
					}
					
					if(skinningLoot.Count == 0)
					{
						if (unit.Level < 5)
							templateId = Utility.Chance(0.5) ? 2934 : 4865;
						else if (unit.Level < 16)
							templateId = Utility.Chance(0.5) ? 2318 : 783;
						else if (unit.Level < 31)
							templateId = Utility.Chance(0.5) ? 2319 : 4232;
						else if (unit.Level < 41)
							templateId = Utility.Chance(0.5) ? 4234 : 4235;
						else if (unit.Level < 51)
							templateId = Utility.Chance(0.5) ? 4304 : 8169;
						else
							templateId = Utility.Chance(0.5) ? 8170 : 8171;
					} else
						template = skinningLoot[Utility.Random(0, skinningLoot.Count - 1)];
				} // else got 2934 

				if (Utility.Chance(slevel < 25 ? 1f : ((unit.Level + 10) * 5f - slevel) / 50f))
				{
					Player.RaiseSkill(Player.Skills[SKILL.SKINNING]);
					Player.UpdateData();
				}
			}

			if (template == null)
				template =(DBItemTemplate) Database.Instance.FindObjectByKey(typeof(DBItemTemplate), templateId);
			
			if (template == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "No template for skinning item {0}", templateId);
				return SpellFailedReason.SPELL_FAILED_ERROR;
			}
			
			DBItem item = new DBItem(template);
			item.StackCount = Utility.Random(1, 3);
			
			unit.Loot = new PooledList<LootHolder>();
			unit.Loot.Add(new LootHolder(item));
			unit.AllowedLooter = Player.GUID;
			unit.Flags = 0;

			linked = new SpellFinishHandler(Loot.DoOpenLoot);
			
			return SpellFailedReason.MAX;
			
			//DBItem loot = new DBItem(template);
			//loot.OwnerID = Player.CharacterID;
			//loot.StackCount = Utility.Random(1, 3);
			
			//if (Player.Inventory.CanAddItem(loot))
			//{
			//    target.Flags = 0;
			//    Player.Inventory.AddItem(loot, true);

			//    return SpellFailedReason.MAX;
			//}
			//if (Player.AddItem(template, Utility.Random(1, 3), false))
			//    return SpellFailedReason.MAX;
			//else
			//{
			//    Items.SendChangeFail(Player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
			//    return SpellFailedReason.SPELL_FAILED_DONT_REPORT;
			//}
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SKINNING, new SpellCastOnLiving(Cast));
		}
	}
}