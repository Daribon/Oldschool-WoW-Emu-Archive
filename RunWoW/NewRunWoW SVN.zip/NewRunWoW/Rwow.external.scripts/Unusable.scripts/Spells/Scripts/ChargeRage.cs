//
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells.Scripts
{
	public class ChargeRage
	{
		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
											 byte effect, ref SpellFinishHandler Linked)
		{
			if (caster is LivingObject)
			{
				LivingObject lcaster = caster as LivingObject;
				int npower = lcaster.SpellProcessor.FullValue(spell, effect);
				
				//int mod = ((SpellModifiers)lcaster.SpellProcessor).PowerCost
				if (lcaster.Auras.HasAura(12285))
					npower += 30;
				else if (lcaster.Auras.HasAura(12697))
					npower += 60;
				if (lcaster.Power + npower > lcaster.MaxPower)
					npower = lcaster.MaxPower - lcaster.Power;
				lcaster.Power += npower;
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 100, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 6178, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 11578, new ScriptSpellCast(Cast));
		}
	}
}