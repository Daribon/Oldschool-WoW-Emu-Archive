//
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells.Scripts
{
	public class Execute
	{
		public static uint ExecuteSpellId = 7160;
		public static DBSpell ExecuteSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), ExecuteSpellId);

		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			if (caster is PlayerObject && target is LivingObject)
			{
				PlayerObject player = (PlayerObject) caster;
				LivingObject ntarget = (LivingObject) target;
				if (ntarget.Health <= ntarget.MaxHealth/5) // If  target have less than 20% health make execute
				{
					int mindamage = player.SpellProcessor.PureDamage(spell, effect);
					int maxdamage = player.SpellProcessor.FullDamage(spell, effect);

					int damagePerRage = spell.Rank*3;
					int addDamage = (player.Power - spell.PowerCost)/10*damagePerRage;
					player.Power = 0;

					player.SubmitMeleeDamage(ntarget, ExecuteSpell, ExecuteSpell.School, mindamage + addDamage, maxdamage + addDamage,
					                         false);
				}
				else
				{
					return SpellFailedReason.SPELL_FAILED_CASTER_AURASTATE;
				}
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 5308, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 20658, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 20660, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 20661, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 20662, new ScriptSpellCast(Cast));
		}
	}
}