//
using System;
using RunServer.Common.Attributes;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells.Scripts
{
    public class EngineerDummySpells
    {
        public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
        {
            int targetSpell = 0;
            switch (m_spell.SpellID)
            {
                case 23074:  // Summon Arcanite Dragonling, 
                        targetSpell = 19804;
                    break;
                case 23075:  // Summon Mithrill Dragonling, 
                        targetSpell = 12749;
                    break;
                case 23076:  // Summon Mechanical Dragonling, 
                        targetSpell = 4073;
                    break;
                case 13120:  // Net-o-Matic
                    targetSpell = 13099;
                    break;
                case 23134:  // Goblin Bomb Dispenser
                    targetSpell = 13259;
                    break;
                    
                    
                
            }

            if (targetSpell != 0)
            {
                DBSpell spell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), targetSpell);
				SpellCastEvent summonSpell = new SingleTargetCast(caster, spell, 2, castTarget, false);
                summonSpell.SendSpellStart();
                summonSpell.FireEvent();
            }
            return SpellFailedReason.MAX;
        }

        [InitializeHandler(InitPass.Third)]
        public static void Initialize()
        {
            SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 23074, new ScriptSpellCast(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 23075, new ScriptSpellCast(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 23076, new ScriptSpellCast(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 13120, new ScriptSpellCast(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 23134, new ScriptSpellCast(Cast));
            
            
        }
    }
}
