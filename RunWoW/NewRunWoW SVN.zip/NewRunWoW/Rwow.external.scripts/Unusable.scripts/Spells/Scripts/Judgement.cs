using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells.Scripts
{
	public class Judgement
	{
		private static Dictionary<uint, DBSpell> m_judgementSpells = new Dictionary<uint, DBSpell>();

		static void registerJudgement(uint spellId, uint targetSpellId)
		{
			m_judgementSpells[spellId] = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), targetSpellId);
		}

		static Judgement()
		{
			//... of Righteousness
			registerJudgement(21084, 20187);
			registerJudgement(20287, 20280);
			registerJudgement(20288, 20281);
			registerJudgement(20289, 20282);
			registerJudgement(20290, 20283);
			registerJudgement(20291, 20284);
			registerJudgement(20292, 20285);
			registerJudgement(20293, 20286);
			registerJudgement(27155, 27157);

			//... of Wisdom
			registerJudgement(20166, 20268);
			registerJudgement(20356, 20352);
			registerJudgement(20357, 20353);
			registerJudgement(27166, 27165);

			//... of the Crusader
			registerJudgement(21082, 21183);
			registerJudgement(20162, 20188);
			registerJudgement(20305, 20300);
			registerJudgement(20306, 20301);
			registerJudgement(20307, 20302);
			registerJudgement(20308, 20303);
			registerJudgement(27158, 27159);


			//... of Justice
			registerJudgement(20164, 20184);
			registerJudgement(31895, 31896);

			//... of Command
			registerJudgement(20375, 20467);
			registerJudgement(20915, 20963);
			registerJudgement(20918, 20964);
			registerJudgement(20919, 20965);
			registerJudgement(20920, 20966);
			registerJudgement(27170, 27171);

			//... of Light
			registerJudgement(20165, 20267);
			registerJudgement(20347, 20341);
			registerJudgement(20348, 20342);
			registerJudgement(20349, 20343);
			registerJudgement(27160, 27163);

			//... of Blood
			registerJudgement(31892, 31898);

			//... of Vengeance
			registerJudgement(31801, 31804);
		}

		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell m_spell,
											 byte effect, ref SpellFinishHandler Linked)
		{
			LivingObject living = caster as LivingObject;

			if (living == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			DBSpell judgementSpell = null;
			uint sealSpellID = 0;
			foreach (uint aura in living.Auras.Auras)
				if (aura !=0 && m_judgementSpells.ContainsKey(aura))
				{
					judgementSpell = m_judgementSpells[aura];
					sealSpellID = aura;
					break;
				}

			if (judgementSpell == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			LogConsole.WriteLine(LogLevel.ECHO, "Judgement spell {0}[{1}] for seal {2}", judgementSpell.Name, judgementSpell.ObjectId, sealSpellID);

			living.Auras.CancelAuraForce(sealSpellID);

			SpellCastEvent cEvent = new SingleTargetCast(caster, judgementSpell, 2, target, false);
			cEvent.SendSpellStart();
			cEvent.FireEvent();
			
			return SpellFailedReason.MAX;
		}
	}
}