using System;
using System.Collections.Generic;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells
{
	public class Tame
	{
		private static List<uint> PetSummonSpells = new List<uint>(new uint[]
		                                                           	{
		                                                           		0,
		                                                           		4946, //				"Wolf"
		                                                           		7906, //				"Cat"
		                                                           		7912, //				"Spider"
		                                                           		7903, //				"Bear"
		                                                           		7905, //				"Boar"
		                                                           		7908, //				"Crocilisk"
		                                                           		7904, //				"Carrion Bird"
		                                                           		7907, //				"Crab"
		                                                           		7909, //				"Gorilla"
		                                                           		7910, //				"Raptor"
		                                                           		7913, //				"Tallstrider"
		                                                           		0,
		                                                           		0,
		                                                           		0,
		                                                           		0,
		                                                           		0,
		                                                           		0,
		                                                           		7911, //				"Scorpid"
		                                                           		7915, //				"Turtle"
		                                                           		0,
		                                                           		0,
		                                                           		0,
		                                                           		8276 //				"Hyena"
		                                                           	});

		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject player = caster as PlayerObject;
			if (player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			UnitBase unit = target as UnitBase;

			Console.WriteLine("Player {0} is taming target {1}", player.Name, target == null ? "(null)" : target.Name);

			if (unit == null || unit.CreatureType != 1)
				return SpellFailedReason.SPELL_FAILED_TARGET_ENRAGED;

			if (player.IsTaming != unit.GUID || (player.CastEvent != null && player.CastEvent.Index == 0))
			{
				player.IsTaming = unit.GUID;
				Console.WriteLine("Player {0} is started taming target {1}", player.Name, unit.Name);
			}
			else
			{
				if (target.Level > caster.Level)
					return SpellFailedReason.SPELL_FAILED_HIGHLEVEL;

				Console.WriteLine("Player {0} is finished taming target {1}", player.Name, unit.Name);

				uint nspell = unit.CreatureFamily <= 0 || unit.CreatureFamily >= PetSummonSpells.Count
				              	? 0
				              	: PetSummonSpells[unit.CreatureFamily];

				if (nspell == 0)
					return SpellFailedReason.SPELL_FAILED_TARGET_ENRAGED;

				CustomArrayList toRemove = new CustomArrayList();
				foreach (DBAbility spell in player.Spells.Spells.Values)
					if (PetSummonSpells.Contains(spell.ObjectId))
						toRemove.Add(spell.ObjectId);

				foreach (uint old in toRemove)
				{
					ShortPacket rpkg = new ShortPacket(SMSG.REMOVED_SPELL);
					rpkg.Write(old);
					player.BackLink.Client.Send(rpkg);
					player.Spells.RemoveSpell((ushort) old);
				}

				ShortPacket pkg = new ShortPacket(SMSG.LEARNED_SPELL);
				pkg.Write(nspell);
				player.BackLink.Client.Send(pkg);
				DBAbility summonSpell = player.Spells.AddSpell((ushort) nspell);

				PetBase oldpet = player.Pet;
				if (oldpet != null)
				{
					oldpet.Die();
					oldpet.Dispose();
				}

				uint creatureId = (uint) summonSpell.Spell.Effect[0].AuraParam;

				DBPet dbpet = null;
				foreach(DBPet dbPet in player.Character.PetList)
					if (dbPet.CreatureID == creatureId)
					{
						dbpet = dbPet;
						break;
					}
				
				if (dbpet != null && dbpet.Spells != null)
				{
					foreach (DBPetSpell spell in dbpet.Spells)
						Database.Instance.DeleteObject(spell);
					dbpet.Spells = null;
				}
				if (dbpet == null)
					dbpet = new DBPet();

				dbpet.OwnerID = player.Character.ObjectId;
				dbpet.CreatureID = creatureId;
				dbpet.TrueCreatureID = unit.Creature.ObjectId;
				dbpet.Happyness = 0;
				dbpet.Level = (uint) unit.Level;
				dbpet.Grows = true;
				dbpet.Name = unit.Name;

				if (dbpet.New)
				{
					DBManager.NewDBObject(dbpet);
					player.Character.PetList.Add(dbpet);
				}
				else
					DBManager.SaveDBObject(dbpet);

				DBUtility.SpellOfPet(dbpet, 2649); // growl

				DBCreature creature = unit.Creature;

				unit.Dispose();

				DBManager.SaveDBObject(dbpet);

				DBManager.SaveDBObject(player.Character);

				PetBase pet = new PetBase(creature, m_spell.ObjectId, dbpet, unit.Position, unit.Facing, player);

				player.Pet = pet;
				player.MapTile.Map.Enter(pet);
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.TAMECREATURE, new SpellCastOnLiving(Cast));
		}
	}
}