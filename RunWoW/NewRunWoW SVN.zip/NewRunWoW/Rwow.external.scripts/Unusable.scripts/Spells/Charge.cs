//
using System;
using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
    public class Charge
    {
        public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
        {
            if (caster == target || (target is PetBase && ((PetBase)target).Owner == caster) || target.Dead)
                return SpellFailedReason.MAX;

            PlayerObject player = caster as PlayerObject;
            if (player == null)
                return SpellFailedReason.SPELL_FAILED_ERROR; // only players make charge

			if (player.Attackers.LivingCount > 0)    //  TODO: Find a flags wich used when spell can`t be made in combat...
                return SpellFailedReason.SPELL_FAILED_AFFECTING_COMBAT;

            //ModifierPair mod = player.Modifiers.RegisterModifier(MODIFIER.SPEED_PCT, 2,0);
            //player.Redress();

            ChargeRun run = new ChargeRun(player,target);
            run.Start();
            return SpellFailedReason.MAX;
        }

        public class ChargeRun : Event
        {
            private PlayerObject m_owner;
            private LivingObject m_target;
			private int m_tries;

            public ChargeRun(PlayerObject owner,LivingObject target )
				: base(TimeSpan.FromMilliseconds(100) , TimeSpan.FromMilliseconds(300))
            {
                m_owner = owner;
                m_target = target;
            }

            protected override void OnTick()
            {
				if (!CheckObjects(m_owner, m_target))
				{
					Finish(EventResult.ERROR_WRONG_PARAMS);
					return;
				}
            	
				float dist = m_owner.Position.Distance(m_target.Position);
				float dist2 = m_owner.CombatReach + m_target.BoundingRadius;

				if (dist > dist2 * 2)
				{
					float x1 = m_owner.Position.X + (dist - dist2) * (m_target.Position.X - m_owner.Position.X) / dist;
					float y1 = m_owner.Position.Y + (dist - dist2) * (m_target.Position.Y - m_owner.Position.Y) / dist;

					Vector mToRun = new Vector(x1, y1, m_target.Position.Z);
					MonsterMove.MoveTo(m_owner, mToRun, true, 300, true);

					m_target.Attacked(m_owner);
					
				}
				else if (dist < dist2 * 2 || m_tries > 5 )
				{
					Finish(EventResult.COMPLETED);	
				}
				m_tries++;
            }

            protected override void OnFinish()
            {
				if (m_target.IsDisposed || m_owner.IsDisposed)
					return;
            	
            	CombatEvent.HitOnce(m_owner, m_target);
                m_owner.StartCombat(m_target);
            }

        }


        [InitializeHandler(InitPass.Third)]
        public static void Initialize()
        {
            SpellManager.RegisterSpell(SPELLEFFECT.CHARGE, new SpellCastOnLiving(Cast));
        }
    }
}