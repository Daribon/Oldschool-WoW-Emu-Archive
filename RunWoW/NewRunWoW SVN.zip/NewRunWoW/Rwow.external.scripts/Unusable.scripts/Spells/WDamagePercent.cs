using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class WeaponDamagePercent
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			LivingObject lcaster = caster as LivingObject;

			if (lcaster == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			PlayerObject player = caster as PlayerObject;

			//if (target is UnitBase)
			//{
			//    UnitBase targetMonster = target as UnitBase;
			//    if (!targetMonster.Attacking)
			//        targetMonster.StartCombat(lcaster);
			//    else
			//        targetMonster.StartFightEvent(lcaster);
			//}

			float damage = spell.Effect[effect].Value/100f;

			if (spell.Category == 8388612 /*&& spell.Flags[2] & 1048576 != 0*/) // 0x800004 - Stab category , 1048576 - Behind
			{
				if (lcaster.Position.InFront(lcaster.Facing, target.Position))
				{
					double tFacing = target.Facing < 0 ? 2*Math.PI + target.Facing : target.Facing;
					double cFacing = lcaster.Facing < 0 ? 2*Math.PI + lcaster.Facing : lcaster.Facing;

					if (Math.Abs((cFacing - tFacing)) >= 2) // !~ 120 degress in back of target
						return SpellFailedReason.SPELL_FAILED_NOT_BEHIND;
				}
				else
					return SpellFailedReason.SPELL_FAILED_NOT_BEHIND;
			}

			lcaster.LastHit = CustomDateTime.Now;

			if (spell.Ranged && player != null)
			{
				if (player.HasRangedAmmo())
				{
					player.ConsumeRangedAmmo();
					player.SubmitRangedDamage(target, spell, spell.School, damage);
					if ((spell.Flags[2] & 32) == 32)
						Linked = new SpellFinishHandler(WeaponDamageP.StartAutoShot);
					player.AddRangedDelay();
				}
				else
					return SpellFailedReason.SPELL_FAILED_NO_AMMO;
			}
			else
				lcaster.SubmitMeleeDamage(target, spell, spell.School, damage);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.WEAPON_DAMAGEP2, new SpellCastOnLiving(Cast));
		}
	}
}