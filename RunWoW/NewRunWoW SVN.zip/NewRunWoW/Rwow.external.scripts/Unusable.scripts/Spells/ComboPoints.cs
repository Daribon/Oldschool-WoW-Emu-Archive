using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class ComboPoints
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject player = caster as PlayerObject;
			if (player == null || target == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			byte old = player.ComboTarget == target.GUID ? player.ComboPoints : (byte) 0;
			if (old >= 5)
				return SpellFailedReason.MAX;
			player.ComboTarget = target.GUID;
			player.ComboPoints = (byte) (old + m_spell.Effect[effect].Value);
			player.ForceUpdateData();
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.ADD_COMBO_POINTS, new SpellCastOnLiving(Cast));
		}
	}
}