//
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunServer.Common.Attributes;
using RunWoW.Spells.Scripts;

namespace RunWoW.Spells
{
	public class ScriptSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte effect, ref SpellFinishHandler Linked)
		{
			switch (spell.SpellID)
			{
				case 5699: // normal
					return CreateItemSpell.CraftItem((PlayerObject) caster, 5509, 1);
				case 6201: // minor
					return CreateItemSpell.CraftItem((PlayerObject) caster, 5512, 1);
				case 6202: // lesser
					return CreateItemSpell.CraftItem((PlayerObject) caster, 5511, 1);
				case 11729: // greater
					return CreateItemSpell.CraftItem((PlayerObject) caster, 5510, 1);
				case 11730: // major
					return CreateItemSpell.CraftItem((PlayerObject) caster, 9421, 1);
				case 27230: // master
					return CreateItemSpell.CraftItem((PlayerObject) caster, 9421, 1); // TODO
				case 20271: // Judgement
					return Judgement.Cast(caster, target, castTarget, spell, effect, ref Linked);
				default:
					if (spell.SpellGroup == 242 || spell.SpellGroup == 70)
						return HealSpell.Cast(castTarget, target, castTarget, spell, effect, ref Linked);
					break;
			}

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SCRIPT, new SpellCastOnLiving(Cast));
		    
		}
	}
}