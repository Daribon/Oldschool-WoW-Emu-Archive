using System;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class Enchant
	{
		public static SpellFailedReason Cast(ObjectBase caster, ItemObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject Player = caster as PlayerObject;
			if (Player == null || target == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			if (target.Enchanted && target.Enchantments[0].ID == m_spell.Effect[effect].AuraParam)
				return SpellFailedReason.SPELL_FAILED_ITEM_ALREADY_ENCHANTED;

            if ((m_spell.RequiredItemClass > 0 && m_spell.RequiredItemClass != (int)target.Template.Class) )
                return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;

            if (m_spell.RequiredItemClass == 2) // Weapon
            {
                int itemTypeBit = 1 << target.Template.SubClass;
                if ((m_spell.RequiredItemSubclass & itemTypeBit) != itemTypeBit)
                {
                    return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
                }
            }  
		    
		    if ( m_spell.InventoryTypeTarget != 0 )
		    {
		        int itemTypeBit = 1 << (int)target.Template.InvType;
                if ((m_spell.InventoryTypeTarget & itemTypeBit) != itemTypeBit)
		        {
                    return SpellFailedReason.SPELL_FAILED_BAD_TARGETS;
		        }
		    }


			if (m_spell.TempSkill != null && m_spell.Effect[effect].Type != SPELLEFFECT.ENCHANT_ITEM_TEMPORARY )
			{
				PlayerSkill skill = Player.Skills[(SKILL) m_spell.TempSkill.SkillID];
				if ( skill == null || skill.Level < m_spell.TempSkill.Level)
					return SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT;

				// 100% chance
				
				//float cchance = m_spell.TempSkill.Level == 0 ? 1f : (Skill.Level - m_spell.TempSkill.Level + 10f)/20f;

				//if (!Utility.Chance(cchance))
				//    return SpellFailedReason.SPELL_FAILED_TRY_AGAIN;

				float rchance = (float) (m_spell.TempSkill.MaxLevel - skill.Level)/((float) (m_spell.TempSkill.MaxLevel - m_spell.TempSkill.Level));
				if (Utility.Chance(rchance))
					Player.RaiseSkill(skill);
			}
			int time = 0;

			if (m_spell.Effect[effect].Type == SPELLEFFECT.ENCHANT_ITEM_TEMPORARY)
				time = 30*60*1000; //Player.SpellProcessor.FullDamage(m_spell, effect);

			DBEnchantment enchant = (DBEnchantment) Database.Instance.FindObjectByKey(typeof (DBEnchantment), m_spell.Effect[effect].AuraParam);
			if (enchant == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			LogConsole.WriteLine(LogLevel.ECHO, "Enchanting Item " + target.Name + " with " + enchant.Name);

			int charges = 0;
			
			if (m_spell.TempSkill != null && m_spell.TempSkill.SkillID == (int)SKILL.POISONS)
				charges = 40;
			
			target.SetEnchant(0, enchant, TimeSpan.FromMilliseconds(time), charges);
			target.UpdateData();

			Player.UnequipItems(false);
			Player.EquipItems(false);

			Player.Redress();
			
			Player.VItems.Update();
			Player.ForceUpdateData();

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.ENCHANT_ITEM, new SpellCastOnItem(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.ENCHANT_ITEM_TEMPORARY, new SpellCastOnItem(Cast));
		}
	}
}