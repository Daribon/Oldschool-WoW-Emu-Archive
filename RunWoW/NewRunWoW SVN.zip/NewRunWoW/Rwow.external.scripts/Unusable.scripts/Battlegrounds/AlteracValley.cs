namespace RunWoW.ExternalScripts.Battlegrounds
{
	internal class AlteracValley : Battleground
	{
		protected override void Join(BGPlayer player, bool action)
		{
		}

		protected override void Leave(BGPlayer player)
		{
		}

		public override uint WorldNumberID
		{
			get { return 1; }
		}

		public override uint WorldMapID
		{
			get { return 30; }
		}

		public override uint ZoneID
		{
			get { return 0; }
		}
	}
}