using System;
using System.Collections;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.ExternalScripts.Battlegrounds
{
	internal abstract class Battleground
	{
		protected BGQueue m_pQueue;
		protected DateTime m_pBGStartTime  = CustomDateTime.Now;
        protected DateTime m_pBGFinishTime = CustomDateTime.Now;
		protected BG_STATUS m_pStatus = BG_STATUS.INITIAL;

        public short m_pScoreAlliance = 0;
		public short m_pScoreHorde = 0;

        protected Vector[] m_pAlliesStartPoints;
        protected Vector[] m_pHordesStartPoints;
		

	    public short GetTemScore( FACTION f)
	    {
            return BattleManager.IsAlliance(f) ? m_pScoreAlliance : m_pScoreHorde;
	    }

		public abstract uint WorldMapID { get; }
		public abstract uint ZoneID { get; }
		public abstract uint WorldNumberID { get; }


		public DateTime StartTime
		{
			get { return m_pBGStartTime; }
			set { m_pBGStartTime = value; }
		}
	    
		public DateTime FinishTime
		{
            get { return m_pBGFinishTime; }
		    set { m_pBGFinishTime = value; }
		}
	    
		//  Only one instance of each BG Type can be created for now..
		public int NumberID
		{
			get { return 1; }
		}

		
		public BGQueue Queue
		{
			get { return m_pQueue; }
		}

	    // Little bit crap but if bg finished Draw can`t be..
        public byte WinnerSide
        {
            get { return m_pScoreAlliance > m_pScoreHorde ? (byte)1 : (byte)0; }
        }

		public BG_TYPE Type
		{
			get
			{
				if (this is WarsongGulch)
					return BG_TYPE.WARSONG_GULCH;
				if (this is ArathiBasin)
					return BG_TYPE.ARATHI_BASIN;
				if (this is AlteracValley)
					return BG_TYPE.ALTERAC_VALLEY;
				return BG_TYPE.UNKNOWN;
			}
		}

		protected abstract void Join(BGPlayer player, bool action);

		protected abstract void Leave(BGPlayer player);

		public virtual void JoinPlayer(PlayerObject player, bool action)
		{
			Join( CreatePlayer(player), action);
		}

		public virtual void LeavePlayer(PlayerObject player)
		{
			BGPlayer pl = GetPlayer(player);
			Leave(pl);
		}

		public virtual void LeaveBGPlayer(BGPlayer pl)
		{
			Leave(pl);
		}
		

        protected void TeleportAllPlayers(BG_TELEPORT_TO to)
        {
            foreach (BGPlayer bp in Queue.ActivePlayers)
                TeleportPlayer(bp, to);
        }
	    
        protected void TeleportPlayer(BGPlayer player, BG_TELEPORT_TO to)
        {
            switch (to)
            {
                case BG_TELEPORT_TO.HOME:
            		
            		if (player.HomePosition == null)
            		{
            			player.HomePosition = player.Player.BindPoint;
            			player.HomeWorldID = player.Player.Character.BindWorld;
            		}
            			
					if (player.Player != null)
						Teleport.TeleportTo(player.HomePosition, player.HomeWorldID, player.Player);
					else if (player.Character != null )// Teleport offline
					{
						player.Character.Position	= player.HomePosition;
						player.Character.WorldMapID = player.HomeWorldID;
						DBManager.SaveDBObject(player.Character);
					}
                    break;
                case BG_TELEPORT_TO.BG_START:
					// TODO:  IsAlliance work incorrect  Faction.IsAlliance(player.Faction)
					bool isAlliance = BattleManager.IsAlliance(player.Faction);
					Teleport.TeleportTo(isAlliance
					                    	?
					                    m_pAlliesStartPoints[Utility.Random(0, m_pAlliesStartPoints.Length - 1)]
					                    	:
                                        m_pHordesStartPoints[Utility.Random(0, m_pHordesStartPoints.Length - 1)],
                        WorldMapID,player.Player);
                    break;
            }
        }
	    

		public virtual QUEUE_STATUS QueueStatus(PlayerObject player)
		{
			return m_pQueue.GetQueueStatus( GetPlayer(player) );
		}

		public virtual BG_STATUS GameStatus()
		{									
			return m_pStatus;
		}
		
		public virtual void ChangeStatus( BG_STATUS stat )
		{
			m_pStatus = stat;
		}
		
		internal BGPlayer GetPlayer(PlayerObject player)
		{
			return (BGPlayer)Queue.GetPlayer(player);
		}

		internal BGPlayer CreatePlayer(PlayerObject player)
		{
			return (BGPlayer)Queue.CreateBGPlayer(player);
		}

        internal void RemovePlayer(PlayerObject player)
        {
            Queue.ErasePlayer(player);
        }
	    

		// 
		public static GameObject GetNearGO(int x, int y,uint WorldMapID,int goID )
		{
			MapInstance mInstance = MapManager.GetWorldMap(WorldMapID, 0);
			if (mInstance != null)
			{
				MapTile mapTile = mInstance.GetTileByLoc(x,y);
				if (mapTile != null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection != null)
						foreach (GameObject gameObject in collection)
							if (gameObject != null && gameObject.Template.ObjectId == goID)
								return gameObject;
				}
			}
			return null;
		}

		public void ChangeGoState(int x, int y, int goID, int state)
		{
			MapInstance mInstance = (MapInstance) MapManager.GetWorldMap((uint) WorldMapID, 0);
			if (mInstance != null)
			{
				MapTile mapTile = mInstance.GetTileByLoc(x, y);
				if (mapTile != null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection != null)
						foreach (GameObject gameObject in collection)
							if (gameObject != null && gameObject.Template.ObjectId == goID)
							{
								gameObject.State = state;
								gameObject.UpdateData();
								break;
							}
				}
			}
		}

		public void RemoveGO(int goID)
		{
			MapInstance mInstance = (MapInstance) MapManager.GetWorldMap((uint) WorldMapID, 0);

			if (mInstance != null)
			{
				for (int x = 0; x < -mInstance.BottomX; x += mInstance.TileSize)
				{
					for (int y = 0; y < -mInstance.BottomY; y += mInstance.TileSize)
					{
						MapTile mapTile = mInstance.GetTileByLoc(x, y);
						if (mapTile != null)
						{
							ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
							if (collection != null)
								foreach (GameObject gameObject in collection)
									if (gameObject != null && gameObject.Template.ObjectId == goID)
									{
										gameObject.Dispose();
										break;
									}
						}
					}
				}
			}
		}

		public void SpawnGO(int goID,Vector pos)
		{
			MapInstance mInstance = (MapInstance) MapManager.GetWorldMap((uint) WorldMapID, 0);
			if (mInstance != null)
			{
				MapTile mapTile = mInstance.GetTileByLoc((int)pos.X, (int)pos.Y);
				if (mapTile != null)
				{
					DBGOTemplate templ = (DBGOTemplate)Database.Instance.FindObjectByKey(typeof(DBGOTemplate), goID );
					if (templ == null)
						return;

					DBGameObject obj = new DBGameObject();
					obj.Level = 1;
					obj.Position = pos;
					obj.TemplateID = templ.ObjectId;
					obj.Template = templ;
					obj.Facing = 0;
					obj.WorldMapID = (uint)WorldMapID;
					GameObject go = new GameObject(obj, -1, mapTile.Map );
					go.Faction = FACTION.NONE;
					go.UpdateData();
				}
			}
		}

	    protected void SendMessage( string msg, int color,  BGPlayer plr )
	    {
            byte code = (byte)(BattleManager.IsAlliance(plr.Faction) ? 83 : 84);
            ShortPacket pMessage = new ShortPacket(SMSG.MESSAGECHAT);
            pMessage.Write(code);
            pMessage.Write((int)0);
            pMessage.Write(plr.Player.GUID);
            pMessage.Write(color);
            pMessage.Write(msg);
            pMessage.Write((byte)0);
            SendBGPackets(pMessage);
	    }

		protected void PlaySound(SOUND sound)
		{
			ShortPacket pck = new ShortPacket( SMSG.PLAY_SOUND );
			pck.Write((int)sound);
			SendBGPackets(pck);
		}

		protected void SendBGPackets(ShortPacket pckg)
		{
			pckg.Aquire();
			foreach (BGPlayer bp in Queue.ActivePlayers)
				bp.Player.BackLink.Client.Send(pckg);
			pckg.Release();
		}

		// Look for entered triggers 
		public virtual bool EnterTrigger(DBAreaTrigger Trigger, PlayerObject player)
		{
			// Nothing todo in base
            return true;
		}

		public virtual void CancelAura(uint Spell, LivingObject m_unit)
		{
			// Nothing todo in base
		}
	}

	internal class BGPlayer
	{
		private PlayerObject m_pPlayer;
		private DateTime m_pJoinTime = CustomDateTime.Now;
		private DateTime m_pInviteTime = CustomDateTime.Now;
		private QUEUE_STATUS m_pQueueStatus = QUEUE_STATUS.NOT_IN_QUEUE;
		private FACTION m_pFaction = FACTION.NONE;
		private Vector m_pHomePosition;
		private uint m_pHomeWorldID;
		private DBCharacter m_pCharacter;


		private uint m_pKills = 0;
		private uint m_pDeaths = 0;
		private uint m_pHonrKills = 0;

		private int mFlagCaptures = 0;
		private int mFlagReturn = 0;
	    
	    // 396      -  6.6 per level capture (60)
	    // 198      -  3.3 per level Winning match
	    
	    
        public int GetHonorBonus( Battleground bg )
        {
            int bonus = (int) (bg.GetTemScore(Faction) * m_pPlayer.Level * 6.6 + .5);
            int side = BattleManager.IsAlliance(Faction)?1:0;
            bonus += (int)(bg.GameStatus() == BG_STATUS.FINISH && bg.WinnerSide == side ? m_pPlayer.Level*3.3 : 0);
            return bonus;
        }
	    
        public DBCharacter Character
        {
			get { return m_pCharacter; }
        }

		
        public Vector HomePosition
        {
            get { return m_pHomePosition; }
            set { m_pHomePosition = value; }
        }

        public uint KillingBlows
        {
            get { return m_pKills; }
            set { m_pKills = value; }
        }

        public uint Deaths
        {
            get { return m_pDeaths; }
            set { m_pDeaths = value; }
        }

        public uint HonorKills
        {
            get { return m_pHonrKills; }
            set { m_pHonrKills = value; }
        }
	    
        public uint HomeWorldID
        {
            get { return m_pHomeWorldID; }
            set { m_pHomeWorldID = value; }
        }
	    
		public int FlagsCaptured
		{
			get { return mFlagCaptures; }
			set { mFlagCaptures = value; }
		}

		public int FlagsReturned
		{
			get { return mFlagReturn; }
			set { mFlagReturn = value; }
		}

		public QUEUE_STATUS Status
		{
			get { return m_pQueueStatus; }
			set { m_pQueueStatus = value; }
		}

		public DateTime JoinTime
		{
			get { return m_pJoinTime; }
			set { m_pJoinTime = value; }
		}

		public DateTime InviteTime
		{
			get { return m_pInviteTime; }
			set { m_pInviteTime = value; }
		}

		public PlayerObject Player
		{
			get { return m_pPlayer; }
		}

		public BGPlayer(PlayerObject player)
		{
			m_pPlayer = player;
			m_pFaction = m_pPlayer.Faction;
			m_pCharacter = m_pPlayer.Character;
		}

		public FACTION Faction
		{
			get { return m_pFaction; }
		}
		
		public void Release ()
		{
			m_pCharacter = null;
			m_pPlayer = null;
			m_pHomePosition = null;
		}
	}
}
