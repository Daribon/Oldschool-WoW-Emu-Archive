//
using System;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ExternalScripts.GameObjects;
using RunWoW.GameObjects;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerScripts.Misc;
using RunWoW.Spells;

namespace RunWoW.ExternalScripts.Battlegrounds
{
	internal class WarsongGulch : Battleground, IGoober
	{
		//public static int MIN_PLAYERS_TO_START = 1;

		public static object[] m_pDoors = new object[]
			{
				new int[] {179918, 1503, 1493},
				new int[] {179919, 1492, 1457},
				new int[] {179920, 1468, 1494},
				new int[] {179921, 1471, 1458}
			};

		public static object[] m_pFlagSpawn = new object[]
			{
				new float[] {179830, 1540.42f, 1481.32f, 351.828f},
				new float[] {179831, 916.023f, 1434.4f, 345.413f}
			};

		private Vector m_pAlianceDropPoint = new Vector();
		private Vector m_pHordeDropPoint = new Vector();

		private Vector m_pRessurectPoint = new Vector(1260.741f, 1445.095f, 313.737f);

		private DeathDelegate m_pOnDeath;

		private BG_FLAG_STATUS mHordeFlagStatus = BG_FLAG_STATUS.ON_BASE;
		private BG_FLAG_STATUS mAlliesFlagStatus = BG_FLAG_STATUS.ON_BASE;

		private ulong mHordeFlagHolder = 0;
		private ulong mAllianceFlagHolder = 0;

		private CustomArrayList m_pRessurectQueue = new CustomArrayList();
		private WarsongRessurect m_pRessurectEvent;
		private int m_RespawnTime = 30;


		public WarsongGulch()
		{
			GooberGameObject.SetHandler(179830, this);
			GooberGameObject.SetHandler(179831, this);
			GooberGameObject.SetHandler(179785, this);
			GooberGameObject.SetHandler(179786, this);

			m_pOnDeath = new DeathDelegate(OnPlayerDeath);
			// init start points
			m_pAlliesStartPoints = new Vector[]
				{
					new Vector(1525, 1488, 353), new Vector(1528, 1457, 353),
					new Vector(1519, 1467, 353), new Vector(1530, 1456, 363)
				};

			m_pHordesStartPoints = new Vector[]
				{
					new Vector(931, 1439, 346), new Vector(931, 1425, 346),
					new Vector(941, 1429, 346), new Vector(926, 1458, 357)
				};

			m_pQueue = new BGQueue(this, 10);
			m_pQueue.Start();
			ChangeStatus(BG_STATUS.INITIAL);
			//new WarsongTimer(this).Start();

			m_pRessurectEvent = new WarsongRessurect(this);
			m_pRessurectEvent.Start();
		}

		protected override void Join(BGPlayer player, bool action)
		{
			if (player.Status == QUEUE_STATUS.NOT_IN_QUEUE)
			{
				player.JoinTime = CustomDateTime.Now;
				if (action)
				{
					Queue.AddToGame(player);
					player.HomePosition = player.Player.Position.Clone();
					player.HomeWorldID = player.Player.WorldMapID;
					player.Player.OnDeath += m_pOnDeath;
					TeleportPlayer(player, BG_TELEPORT_TO.BG_START);
					SendInitStatus(player);
				}
				else
				{
					Queue.AddToWait(player);
					Chat.System(player.Player.BackLink.Client, "You are " + Queue.m_pWaitQueue.Count + " in waiting queue.");
					Chat.System(player.Player.BackLink.Client,
					            "Waiting Alliance: " + Queue.m_pWaitQueue.Alliance + ",  Hordes." + Queue.m_pWaitQueue.Horde);
					Chat.System(player.Player.BackLink.Client, "Game Status: " + m_pStatus);
				}
			}
		}

		protected override void Leave(BGPlayer player)
		{
			if (player != null && player.Player != null && !player.Player.Disposed && player.Status != QUEUE_STATUS.NOT_IN_QUEUE)
			{
				if (player.Player.WorldMapID == WorldMapID)
					TeleportPlayer(player, BG_TELEPORT_TO.HOME);
				player.Player.OnDeath -= m_pOnDeath;
				player.Status = QUEUE_STATUS.NOT_IN_QUEUE;
				SendInitStatusFinish(player);
				BattleManager.Status(player.Player.BackLink.Client, null);
			}
			
			// check if leaving player have flag and then drop it.
			if (player != null && player.Player != null && player.Player.GUID == mAllianceFlagHolder || player.Player.GUID == mHordeFlagHolder )
			{
				if (BattleManager.IsAlliance(player.Faction))
				{
					// Spawn Horde Flag on base
					RemoveGO(179786);
					float[] goData = (float[])m_pFlagSpawn[1];
					SpawnGO((int)goData[0], new Vector(goData[1], goData[2], goData[3]));
					mHordeFlagStatus = BG_FLAG_STATUS.ON_BASE;
					mHordeFlagHolder = 0;
					SendInitStatus();
					PlaySound(SOUND.PVPFlagReturnedHorde);
					SendMessage(BGConstants.MSG_RETURN_HORDE_FLAG, 47, player);
					
					if (player.Player != null && !player.Player.Disposed )
						player.Player.Auras.CancelAuraForce(23333);
				} else
				{
					// Spawn Alliance Flag on base
					RemoveGO(179785);
					float[] goData = (float[])m_pFlagSpawn[0];
					SpawnGO((int)goData[0], new Vector(goData[1], goData[2], goData[3]));
					mAlliesFlagStatus = BG_FLAG_STATUS.ON_BASE;
					mAllianceFlagHolder = 0;
					SendInitStatus();
					PlaySound(SOUND.PVPFlagReturnedAlliance);
					SendMessage(BGConstants.MSG_RETURN_ALLIANCE_FLAG, 50, player);
					
					if (player.Player != null && !player.Player.Disposed)
						player.Player.Auras.CancelAuraForce(23335);
				}
			}
			Queue.Remove(player);
		}

		protected void LeaveAll()
		{
			CustomArrayList removeList = new CustomArrayList();
			lock (Queue.ActivePlayers)
			{
				foreach (BGPlayer bp in Queue.ActivePlayers)
					removeList.Add(bp);
			}

			foreach (BGPlayer bp in removeList)
				Leave(bp);
		}

		public override uint WorldMapID
		{
			get { return 489; } // Warsong Gulch map id
		}

		public override uint WorldNumberID
		{
			get { return 2; } // Warsong Gulch map id
		}

		public override uint ZoneID
		{
			get { return 3277; }
		}

		public override void ChangeStatus(BG_STATUS status)
		{
			if (m_pStatus != BG_STATUS.PROCESS && status == BG_STATUS.PROCESS) // change state to begin game
			{
				GameBegin();
			}
			else if (status != BG_STATUS.PROCESS)
			{
				ResetObjects();
			}

			m_pStatus = status;
		}


		/** Init objects , variables, set flags to their pos
		 */

		private void GameBegin()
		{
			RemoveGO(179830);
			RemoveGO(179831);
			RemoveGO(179785);
			RemoveGO(179786);

			for (int i = 0; i < m_pFlagSpawn.Length; i++)
			{
				float[] goData = (float[]) m_pFlagSpawn[i];
				SpawnGO((int) goData[0], new Vector(goData[1], goData[2], goData[3]));
			}
			OpenGates();

			lock (m_pRessurectQueue)
			{
				m_pRessurectQueue.Clear();
			}

			//BG_FLAG_STATUS mHordeFlagStatus = BG_FLAG_STATUS.ON_BASE;
			//BG_FLAG_STATUS mAlliesFlagStatus = BG_FLAG_STATUS.ON_BASE;

			m_pScoreAlliance = 0;
			m_pScoreHorde = 0;
		}

		private void ResetObjects()
		{
			RemoveGO(179830);
			RemoveGO(179831);
			RemoveGO(179785);
			RemoveGO(179786);
			CloseGates();
		}


		private void CloseGates()
		{
			for (int i = 0; i < m_pDoors.Length; i++)
			{
				int[] obj = (int[]) m_pDoors[i];
				ChangeGoState(obj[1], obj[2], obj[0], 1);
			}
		}

		private void OpenGates()
		{
			for (int i = 0; i < m_pDoors.Length; i++)
			{
				int[] obj = (int[]) m_pDoors[i];
				ChangeGoState(obj[1], obj[2], obj[0], 0);
			}
		}


		public override void CancelAura(uint spell, LivingObject target)
		{
			if (m_pStatus != BG_STATUS.PROCESS)
				return;
			if (!(target is PlayerObject && Queue.GetPlayer((PlayerObject) target) != null))
				return;

			switch (spell)
			{
				case 23333: // Horde drop flag
					if (mHordeFlagStatus == BG_FLAG_STATUS.ON_PLAYER)
					{
						//SpellManager.Cast(target, target, 23334);
						if (((PlayerObject)target).WorldMapID == WorldMapID)
						{
							SpawnGO(179786, target.Position.Clone());
							mHordeFlagStatus = BG_FLAG_STATUS.ON_GROUND;
							SendInitStatus();
							mHordeFlagHolder = 0;
							SendMessage(BGConstants.MSG_DROP_HORDE_FLAG, 34, Queue.GetPlayer((PlayerObject)target));
						} else
						{
							RemoveGO(179786);
							float[] goData = (float[])m_pFlagSpawn[1];
							SpawnGO((int)goData[0], new Vector(goData[1], goData[2], goData[3]));
							mHordeFlagStatus = BG_FLAG_STATUS.ON_BASE;
							mHordeFlagHolder = 0;
							SendInitStatus();
							PlaySound(SOUND.PVPFlagReturnedHorde);
						}
					}
					break;
				case 23335: // Alliance  drop flag
					if (mAlliesFlagStatus == BG_FLAG_STATUS.ON_PLAYER)
					{
						//SpellManager.Cast(target, target, 23336);
						if (((PlayerObject)target).WorldMapID == WorldMapID)
						{
							SpawnGO(179785, target.Position.Clone());
							mAlliesFlagStatus = BG_FLAG_STATUS.ON_GROUND;
							mAllianceFlagHolder = 0;
							SendInitStatus();
							SendMessage(BGConstants.MSG_DROP_ALLIANCE_FLAG, 37, GetPlayer((PlayerObject) target));
						} else
						{
							RemoveGO(179785);
							float[] goData = (float[])m_pFlagSpawn[0];
							SpawnGO((int)goData[0], new Vector(goData[1], goData[2], goData[3]));
							mAlliesFlagStatus = BG_FLAG_STATUS.ON_BASE;
							mAllianceFlagHolder = 0;
							SendInitStatus();
							PlaySound(SOUND.PVPFlagReturnedAlliance);
							SendMessage(BGConstants.MSG_RETURN_ALLIANCE_FLAG, 50,  GetPlayer((PlayerObject) target));
						}
					}
					break;
			}
		}

		/**  Take flag actions
		 */

		public void GooberSelect(LivingObject user, GameObject go)
		{
			if (m_pStatus != BG_STATUS.PROCESS)
				return;

			if (!(user is PlayerObject))
				return;

			BGPlayer bPlayer = GetPlayer((PlayerObject) user);

			if (bPlayer != null)
			{
				uint templateID = go.DBGameObject.TemplateID;

				switch (templateID)
				{
					case 179830: // alliance flag

						//  Capture flag - only horde can get allince flag
						if (BattleManager.IsHorde(bPlayer.Faction))
						{
							SpellManager.Cast(go, user, 23335); // Get flag
							RemoveGO(179830);
							mAlliesFlagStatus = BG_FLAG_STATUS.ON_PLAYER;
							mAllianceFlagHolder = user.GUID;

							PlaySound(SOUND.PVPFlagTakenHorde);
							SendMessage(BGConstants.MSG_PICKUP_ALLIANCE_FLAG, 39, bPlayer);
							SendInitStatus();
							//BattleManager.SendUpdateWorldStateToAll(this, WORLD_UPDATE_INDEX.ALLIANCE_FLAG_PICKUP, WORLD_STATE_CATEGORIES.WARSONG_BG, 1);
						}
						break;
					case 179831: // Horde flag
						//  Capture flag - only ally can get horde flag
						if (BattleManager.IsAlliance(bPlayer.Faction))
						{
							SpellManager.Cast(go, user, 23333); // Get flag
							RemoveGO(179831);
							mHordeFlagStatus = BG_FLAG_STATUS.ON_PLAYER;
							mHordeFlagHolder = user.GUID;

							PlaySound(SOUND.PVPFlagTakenAlliance);
							SendMessage(BGConstants.MSG_PICKUP_HORDE_FLAG, 36, bPlayer);

							SendInitStatus();
							//BattleManager.SendUpdateWorldStateToAll(this, WORLD_UPDATE_INDEX.HORDE_FLAG_PICKUP,WORLD_STATE_CATEGORIES.WARSONG_BG, 0);
						}
						break;
					case 179785: // Alliance drop flag
						//  Return / get flag
						if (BattleManager.IsAlliance(bPlayer.Faction)) // Return flag
						{
							RemoveGO(179785);

							// Spawn Alliance Flag on base
							float[] goData = (float[]) m_pFlagSpawn[0];
							SpawnGO((int) goData[0], new Vector(goData[1], goData[2], goData[3]));

							mAlliesFlagStatus = BG_FLAG_STATUS.ON_BASE;
							mAllianceFlagHolder = 0;
							bPlayer.FlagsReturned++;

							SendInitStatus();
							PlaySound(SOUND.PVPFlagReturnedAlliance);
							SendMessage(BGConstants.MSG_RETURN_ALLIANCE_FLAG, 50, bPlayer);
							//BattleManager.SendUpdateWorldStateToAll(this, WORLD_UPDATE_INDEX.ALLIANCE_FLAG_PICKUP, WORLD_STATE_CATEGORIES.WARSONG_BG, -1);
						}
						else // Take flag from ground
						{
							SpellManager.Cast(go, user, 23335); // Get flag
							RemoveGO(179785);
							mAlliesFlagStatus = BG_FLAG_STATUS.ON_PLAYER;
							mAllianceFlagHolder = user.GUID;

							PlaySound(SOUND.PVPFlagTakenHorde);
							SendMessage(BGConstants.MSG_PICKUP_ALLIANCE_FLAG, 39, bPlayer);
							SendInitStatus();
							//BattleManager.SendUpdateWorldStateToAll(this, WORLD_UPDATE_INDEX.ALLIANCE_FLAG_PICKUP, WORLD_STATE_CATEGORIES.WARSONG_BG, 1);
						}
						break;
					case 179786: // Horde drop flag

						//  Return / get flag
						if (BattleManager.IsHorde(bPlayer.Faction)) // Return flag
						{
							RemoveGO(179786);

							// Spawn Horde Flag on base
							float[] goData = (float[]) m_pFlagSpawn[1];
							SpawnGO((int) goData[0], new Vector(goData[1], goData[2], goData[3]));

							mHordeFlagStatus = BG_FLAG_STATUS.ON_BASE;
							mHordeFlagHolder = 0;
							bPlayer.FlagsReturned++;

							SendInitStatus();
							PlaySound(SOUND.PVPFlagReturnedHorde);
							SendMessage(BGConstants.MSG_RETURN_HORDE_FLAG, 47, bPlayer);
							//BattleManager.SendUpdateWorldStateToAll(this, WORLD_UPDATE_INDEX.HORDE_FLAG_PICKUP, WORLD_STATE_CATEGORIES.WARSONG_BG, -1);
						}
						else // Take flag from ground
						{
							SpellManager.Cast(go, user, 23333); // Get flag
							RemoveGO(179786);
							mHordeFlagStatus = BG_FLAG_STATUS.ON_PLAYER;
							mHordeFlagHolder = user.GUID;

							SendInitStatus();
							PlaySound(SOUND.PVPFlagTakenAlliance);
							SendMessage(BGConstants.MSG_PICKUP_HORDE_FLAG, 36, bPlayer);
							//BattleManager.SendUpdateWorldStateToAll(this, WORLD_UPDATE_INDEX.HORDE_FLAG_PICKUP, WORLD_STATE_CATEGORIES.WARSONG_BG, 1);
						}
						break;
				}
			}
		}

		public override bool EnterTrigger(DBAreaTrigger Trigger, PlayerObject player)
		{
			switch (Trigger.ObjectId)
			{
				case 3669: // Horde  leave BG
				case 3671: // Allies leave BG
					BGPlayer bp = GetPlayer(player);
					if (bp != null)
					{
						Leave(bp);
						SpellManager.Cast(player, player, 26013);
					}
					return false;
			}
			if (m_pStatus != BG_STATUS.PROCESS && !Trigger.Enabled)
				return true;

			bool retBool = true;

			/*
			ShortPacket pck1 = new ShortPacket((SMSG)707);
			pck1.Write(1545);    //  Take flag - world state update
			pck1.Write(0xFFFFFFFF);
			SendBGPackets(pck1);
			*/

			switch (Trigger.ObjectId)
			{
				case 3647: // return horde point
					{
						BGPlayer bPlayer = GetPlayer(player);
						// If player is BG member
						if (bPlayer != null)
						{
							// If player is horde and have flag..
							if (BattleManager.IsHorde(bPlayer.Faction) && player.Auras.HasAura(23335))
							{
								// Score event 
								if (mHordeFlagStatus == BG_FLAG_STATUS.ON_BASE)
								{
									mAlliesFlagStatus = BG_FLAG_STATUS.ON_BASE;
									mAllianceFlagHolder = 0;
									// Spawn alliance Flag on base
									float[] goData = (float[]) m_pFlagSpawn[0];
									SpawnGO((int) goData[0], new Vector(goData[1], goData[2], goData[3]));
									ScoreEvent(bPlayer);

									player.Auras.CancelAuraForce(23335);

									SendInitStatus();
									PlaySound(SOUND.PVPFlagCapturedHorde);
									SendMessage(BGConstants.MSG_CAPTURE_ALLIANCE_FLAG, 31, bPlayer);
								}
								else
								{
									Chat.System(player.BackLink.Client, "Return your flag first");
								}
							}
						}
						break;
					}
				case 3646: // return alliance point
					{
						BGPlayer bPlayer = GetPlayer(player);
						// If player is BG member
						if (bPlayer != null)
						{
							// If player is alliance and have flag..
							if (BattleManager.IsAlliance(bPlayer.Faction) && player.Auras.HasAura(23333))
							{
								// Score event 
								if (mAlliesFlagStatus == BG_FLAG_STATUS.ON_BASE)
								{
									mHordeFlagStatus = BG_FLAG_STATUS.ON_BASE;
									mHordeFlagHolder = 0;
									// Spawn horde Flag on base
									float[] goData = (float[]) m_pFlagSpawn[1];
									SpawnGO((int) goData[0], new Vector(goData[1], goData[2], goData[3]));

									// score event
									ScoreEvent(bPlayer);

									player.Auras.CancelAuraForce(23333);

									SendInitStatus();
									PlaySound(SOUND.PVPFlagCapturedAlliance);
									SendMessage(BGConstants.MSG_CAPTURE_HORDE_FLAG, 28, bPlayer);
								}
								else
								{
									Chat.System(player.BackLink.Client, "Return your flag first");
								}
							}
						}
						break;
					}
				case 3654: // bg entrance, TODO: should show BG enter queue dialog.
					retBool = false;
					break;
			}

			return retBool;
		}

		private bool OnPlayerDeath(LivingObject victim, ObjectBase killer)
		{
			PlayerObject deadPlayer = victim as PlayerObject;
			if (deadPlayer.Auras.HasAura(23335))
				deadPlayer.Auras.CancelAuraForce(23335);
			if (deadPlayer.Auras.HasAura(23333))
				deadPlayer.Auras.CancelAuraForce(23333);

			BGPlayer bpDead = GetPlayer(deadPlayer);
			if (bpDead != null)
				bpDead.Deaths++;

			if (killer is PlayerObject)
			{
				BGPlayer bp = GetPlayer(((PlayerObject) killer));
				if (bp != null)
				{
					if (bp.Player.Level <= deadPlayer.Level)
						bp.HonorKills++;
					bp.KillingBlows++;
				}
			}
			//SpellManager.Cast(deadPlayer, deadPlayer, 2584);
			lock (m_pRessurectQueue)
			{
				m_pRessurectQueue.Add(deadPlayer);
			}
			return true;
		}

		/** Increase score value and check for game over. 
		 */

		private void ScoreEvent(BGPlayer bPlayer)
		{
			if (BattleManager.IsAlliance(bPlayer.Faction))
				m_pScoreAlliance++;
			else
				m_pScoreHorde++;

			bPlayer.FlagsCaptured++;

			if (m_pScoreAlliance == 3 || m_pScoreHorde == 3) // TODO: should be 3
				FinishGame();
		}

		/*    Finish Game, send finish packets, change BG state
		 */

		private void FinishGame()
		{
			//  play winning sound
			PlaySound(m_pScoreAlliance > m_pScoreHorde ? SOUND.PVPVictoryAlliance : SOUND.PVPVictoryHorde);

			ChangeStatus(BG_STATUS.FINISH);

			ApplyRewards();

			FinishTime = CustomDateTime.Now;
			// Update status screen for all bg players
			BattleManager.UpdateStatusAll(this);
			BattleManager.SendStatisticUpdate(this);


			// Initiate finish event ( complete finish in 2 min )
			FinishWarsongEvent fw = new FinishWarsongEvent(this);
			fw.Start();
		}

		public void ApplyRewards()
		{
			//TODO:
		}

		private void SendInitStatus()
		{
			SendInitStatus(null);
		}

		private void SendInitStatusFinish(BGPlayer bPlayer)
		{
			WORLD_UPDATE_INDEX[] idxs = {
			                            	(WORLD_UPDATE_INDEX) 0xD8,
			                            	(WORLD_UPDATE_INDEX) 0xD7,
			                            	(WORLD_UPDATE_INDEX) 0xD6,
			                            	(WORLD_UPDATE_INDEX) 0xD5,
			                            	(WORLD_UPDATE_INDEX) 0xD3,
			                            	(WORLD_UPDATE_INDEX) 0xD4
			                            };
			WORLD_STATE_CATEGORIES[] ctgories = {
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8
			                                    };
			short[] values = new short[] {0, 0, 0, 0, 0, 0};

			if (bPlayer != null)
			{
				if ( bPlayer.Player != null && !bPlayer.Player.Disposed )
					BattleManager.SendInitWorldState(bPlayer.Player.BackLink.Client, bPlayer.Player.WorldMapID, ZoneID, idxs, ctgories,
				                                 values);
			}
			else
				BattleManager.SendInitWorldStateToAll(this, idxs, ctgories, values);
		}

		private void SendInitStatus(BGPlayer bPlayer)
		{
		
			
			WORLD_UPDATE_INDEX[] idxs = {
			                            	(WORLD_UPDATE_INDEX)0xD8,
			                            	(WORLD_UPDATE_INDEX)0xD7,
			                            	(WORLD_UPDATE_INDEX)0xD6,
			                            	(WORLD_UPDATE_INDEX)0xD5,
			                            	(WORLD_UPDATE_INDEX)0xD3,
			                            	(WORLD_UPDATE_INDEX)0x23,  // - enable ally score val: 1 show, 2 flag picked
			                            	(WORLD_UPDATE_INDEX)0x22,  // - enable horde score
			                            	(WORLD_UPDATE_INDEX)0xD4,
			                            	WORLD_UPDATE_INDEX.SHOW_SCORE_BOARD,
			                            	WORLD_UPDATE_INDEX.FLAGS_TO_FINISH_GAME,
			                            	WORLD_UPDATE_INDEX.HORDE_CAPTURE_FLAG,
			                            	WORLD_UPDATE_INDEX.ALLIANCE_CAPTURE_FLAG,
			                            	WORLD_UPDATE_INDEX.HORDE_FLAG_PICKUP,
			                            	WORLD_UPDATE_INDEX.ALLIANCE_FLAG_PICKUP
			                            };

			WORLD_STATE_CATEGORIES[] ctgories = {
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 9,
			                                    	(WORLD_STATE_CATEGORIES) 9,
			                                    	(WORLD_STATE_CATEGORIES) 8,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6
			                                    };
			short[] values = new short[]
				{ 0,0,0,0,0,  (short) (1 + (mHordeFlagStatus == BG_FLAG_STATUS.ON_PLAYER ? 1 : 0)), (short) (1 + (mAlliesFlagStatus == BG_FLAG_STATUS.ON_PLAYER ? 1 : 0)), 0,
					2, 3, m_pScoreHorde, m_pScoreAlliance,
					(short) (mHordeFlagStatus == BG_FLAG_STATUS.ON_PLAYER ? 1 : 0),
					(short) (mAlliesFlagStatus == BG_FLAG_STATUS.ON_PLAYER ? 1 : 0)
				};
			
			
			/*
			WORLD_UPDATE_INDEX[] idxs = {
			                            	WORLD_UPDATE_INDEX.SHOW_SCORE_BOARD,
			                            	WORLD_UPDATE_INDEX.FLAGS_TO_FINISH_GAME,
			                            	WORLD_UPDATE_INDEX.HORDE_CAPTURE_FLAG,
			                            	WORLD_UPDATE_INDEX.ALLIANCE_CAPTURE_FLAG,
			                            	WORLD_UPDATE_INDEX.HORDE_FLAG_PICKUP,
			                            	WORLD_UPDATE_INDEX.ALLIANCE_FLAG_PICKUP
			                            };

			WORLD_STATE_CATEGORIES[] ctgories = {
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6,
			                                    	(WORLD_STATE_CATEGORIES) 6
			                                    };
			short[] values = new short[]
				{
					2, 3, m_pScoreHorde, m_pScoreAlliance,
					(short) (mHordeFlagStatus == BG_FLAG_STATUS.ON_PLAYER ? 1 : 0),
					(short) (mAlliesFlagStatus == BG_FLAG_STATUS.ON_PLAYER ? 1 : 0)
				};
			*/
			if (bPlayer != null)
				BattleManager.SendInitWorldState(bPlayer.Player.BackLink.Client, WorldMapID, ZoneID, idxs, ctgories, values);
			else
				BattleManager.SendInitWorldStateToAll(this, idxs, ctgories, values);
		}


		internal class WarsongRessurect : Event
		{
			private WarsongGulch m_pWarsong;

			public WarsongRessurect(WarsongGulch bg)
				: base(TimeSpan.FromSeconds(0), TimeSpan.FromSeconds(1))
			{
				m_pWarsong = bg;
			}

			protected override void OnTick()
			{
				if (m_pWarsong.m_RespawnTime-- <= 0)
				{
					// Do ressurect players... TODO: need check distance to spirit healer
					m_pWarsong.m_RespawnTime = 30;
					lock (m_pWarsong.m_pRessurectQueue)
					{
						foreach (PlayerObject player in m_pWarsong.m_pRessurectQueue)
						{
							if (player != null && !player.Disposed && player.WorldMapID == m_pWarsong.WorldMapID)
							{
								player.Dead = false;
								player.Health = player.MaxHealth;
								if (player.PowerType != POWERTYPE.RAGE)
									player.Power = player.MaxPower;
							}
						}
						m_pWarsong.m_pRessurectQueue.Clear();
					}
				}
				else
				{
					lock (m_pWarsong.m_pRessurectQueue)
					{
						// Send event for ressurect
						foreach (PlayerObject player in m_pWarsong.m_pRessurectQueue)
						{
							if (player != null && !player.Disposed)
							{
								try
								{
									ShortPacket pckg = new ShortPacket((SMSG) 740);
									pckg.Write(player.GUID);
									pckg.Write(m_pWarsong.m_RespawnTime*1000);
									player.BackLink.Client.Send(pckg);
								}
								catch (Exception e)
								{
									CustomLog.WriteLine("WarsongGulth:WarsongRessurect:OnTick " + player, "BG", "BGLogs");
								}
							}
						}
					}
				}
			}
		}

		// check some non standart situations, TODO: remove in future
		internal class WarsongTimer : Event
		{
			private WarsongGulch m_pWarsong;

			public WarsongTimer(WarsongGulch bg)
				: base(TimeSpan.FromSeconds(0), TimeSpan.FromSeconds(20))
			{
				m_pWarsong = bg;
			}

			protected override void OnTick()
			{
				if (m_pWarsong.GameStatus() == BG_STATUS.PROCESS)
				{
					BGPlayer pFlag1 = null;
					BGPlayer pFlag2 = null;
					foreach (BGPlayer bp in m_pWarsong.Queue.ActivePlayers)
					{
						if (bp.Player != null && !bp.Player.Disposed && bp.Player.Auras.HasAura(23333))
							pFlag1 = bp;
						else if (bp.Player != null && !bp.Player.Disposed && bp.Player.Auras.HasAura(23335))
							pFlag2 = bp;
					}

					if (m_pWarsong.mHordeFlagStatus == BG_FLAG_STATUS.ON_PLAYER && pFlag1 == null)
					{
						m_pWarsong.RemoveGO(179786);
						// Spawn Horde Flag on base
						float[] goData = (float[]) m_pFlagSpawn[1];
						m_pWarsong.SpawnGO((int) goData[0], new Vector(goData[1], goData[2], goData[3]));
						m_pWarsong.mHordeFlagStatus = BG_FLAG_STATUS.ON_BASE;
						m_pWarsong.mHordeFlagHolder = 0;
						m_pWarsong.SendInitStatus();
					}
					else if (m_pWarsong.mAlliesFlagStatus == BG_FLAG_STATUS.ON_PLAYER && pFlag2 == null)
					{
						m_pWarsong.RemoveGO(179785);
						float[] goData = (float[]) m_pFlagSpawn[0];
						m_pWarsong.SpawnGO((int) goData[0], new Vector(goData[1], goData[2], goData[3]));
						m_pWarsong.mAlliesFlagStatus = BG_FLAG_STATUS.ON_BASE;
						m_pWarsong.mAllianceFlagHolder = 0;
						m_pWarsong.SendInitStatus();
					}
				}
			}
		}


		internal class FinishWarsongEvent : Event
		{
			private WarsongGulch m_pWarsong;

			public FinishWarsongEvent(WarsongGulch bg)
				: base(TimeSpan.FromMinutes(2))
			{
				m_pWarsong = bg;
			}

			protected override void OnTick()
			{
				base.Finish();
			}

			protected override void OnFinish()
			{
				// Remove exist players from BG
				m_pWarsong.TeleportAllPlayers(BG_TELEPORT_TO.HOME);
				m_pWarsong.LeaveAll();
				m_pWarsong.ChangeStatus(BG_STATUS.INITIAL);
				base.OnFinish();
			}
		}
	}
}