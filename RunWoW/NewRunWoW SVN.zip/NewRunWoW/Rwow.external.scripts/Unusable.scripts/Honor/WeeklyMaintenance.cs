﻿using System;
using System.Collections;
using System.Collections.Generic;
using RunServer.Common;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;

namespace RunWoW.ExternalScripts.Honor
{
	[ServerHandlerClass()]
	internal class WeeklyMaintenance
	{
		public static int MIN_RANKED_KILLS = 15;

		//RP получаемые игроками попавшими в брейкпоинт, и определяющие участки линейности
		private static int[] RPs =
			new int[] {13000, 12000, 11000, 10000, 9000, 8000, 7000, 6000, 5000, 4000, 3000, 2000, 1000, 400, 0};

		//относительные брейкпоинты по WS
		private static double[] BPs =
			new double[] {0.0, 0.003, 0.008, 0.02, 0.035, 0.06, 0.1, 0.159, 0.228, 0.327, 0.436, 0.566, 0.697, 0.845, 1.0};

		[ServerHandler(IMSG.RECALC_HONOR)]
		public static void CalcWeeklyStanding(ClientBase client)
		{
			/* HK - количество Honor Kills игрока
			 * CP - количество Contribution Points игрока
			 * Luck - "удача" игрока
			 * WS - Weekly Standing - место в недельном рейтинге игрока
			 * RP - Rank Points - очки ранга полученные игроком по итогам WS
			 * 
			*/

			//таблицу пишем в файл d:\honor.csv который затем сможем просмотреть в MS Excel
//System.IO.StreamWriter sw = new System.IO.StreamWriter("d:\\honor.csv", false);

			//определяем максимальные количества CP и HK набранных игроками (чисто для статистики)
			ICollection allCharacters =
				Database.Instance.SelectObjects(typeof (DBCharacter), "Honor >= 0 AND IsActive=1 ORDER BY Honor DESC");
			List<DBCharacter> rankedChars = new List<DBCharacter>();
			int CPMax = 0;
			int HKMax = 0;
			int decay;
			int delta;

			foreach (DBCharacter chr in allCharacters)
			{
				if (chr != null)
				{
					if (chr.HKills >= 15)
					{
						CPMax = CPMax < chr.Honor ? chr.Honor : CPMax;
						HKMax = HKMax < chr.HKills ? chr.HKills : HKMax;
						rankedChars.Add(chr);
					}
					else
					{
						//падение не участвующих в Викли Стэндинге игроков
						decay = (int) Math.Round(0.2*chr.RPAll);
						delta = -decay;
						if (decay < 0)
						{
							delta = delta/2;
						}
						if (decay < -2500)
						{
							delta = -2500;
						}
						chr.RPAll += delta; //TODO:надо как-то прокоммитить ещё

						Database.Instance.SaveObject(chr);
					}
				}
			}

			//int PlayersNum = m_pAllCharracters.Count; //количество игроков

			int j = 0;
			foreach (DBCharacter chr in rankedChars)
			{
				j++;
				chr.WeeklyStanding = j;
			}

			//количество игроков, участвующих в рейтинге
			int NR = rankedChars.Count;

			//абсолютные брейкпоинты по WS
			int[] WSs = new int[BPs.Length];
			WSs[0] = 1;
			for (int i = 1; i < BPs.Length; i++)
			{
				WSs[i] = (int) Math.Round(NR*BPs[i]);
				if (WSs[i] <= WSs[i - 1])
					WSs[i] = WSs[i - 1] + 1;
			}


			j = 0;
			//перебираем брейкпоинты
			for (int i = 0; i < WSs.Length - 1; i++)
			{
				int WS = j + 1;
				if ((rankedChars[WSs[i] - 1]).Honor == (rankedChars[WSs[i + 1] - 1]).Honor)
					while (WS <= WSs[i + 1] && WS >= WSs[i] && j < NR)
					{
						//считаем RP                   (брейкпоинт) + (отклонение             от            брейкпоинта)  *  (тангенс       угла       наклона       прямой       соединяющих       брейкпоинты)
						int RP = (int) Math.Round((float) (RPs[i + 1] + (RPs[i] - RPs[i + 1])/(WSs[i] - WSs[i + 1])));

						rankedChars[j].RankPoints = RP;
						WS = j + 1;

						decay = rankedChars[j].RPAll/5;
						delta = RP - decay;
						if (delta < 0)
						{
							delta = delta/2;
						}
						if (delta < -2500)
						{
							delta = -2500;
						}
						rankedChars[j].RPAll += delta;

						rankedChars[j].PVPRank = DBUtility.RP2Rank(rankedChars[j]);
						j++;
					}
				else
					//перебираем игроков занявших места от следующего до текущего брейкпоинта
					while (WS <= WSs[i + 1] && WS >= WSs[i] && j < NR)
					{
						//считаем RP                   (брейкпоинт) + (отклонение             от            брейкпоинта)  *  (тангенс       угла       наклона       прямой       соединяющих       брейкпоинты)
						int RP =
							(int)
							Math.Round(
								(float)
								(RPs[i + 1] +
								 (rankedChars[j].Honor - rankedChars[WSs[i + 1] - 1].Honor)*
								 (RPs[i] - RPs[i + 1])/
								 (rankedChars[WSs[i] - 1].Honor - rankedChars[WSs[i + 1] - 1].Honor)));

						rankedChars[j].RankPoints = RP;
						WS = j + 1;

						decay = rankedChars[j].RPAll/5;
						delta = RP - decay;
						if (delta < 0)
						{
							delta = delta/2;
						}
						if (delta < -2500)
						{
							delta = -2500;
						}

						rankedChars[j].RPAll = rankedChars[j].RPAll + delta;

						rankedChars[j].PVPRank = DBUtility.RP2Rank(rankedChars[j]);
						j++;
					}
			}
			//пишем файл. d:\honor.csv результат смотреть в MS Excele
//			sw.WriteLine("WS;Name;RP;CP;RPAll;Rank"); //TODO: remove
			foreach (DBCharacter chr in rankedChars)
			{
//sw.WriteLine(chr.WeeklyStanding.ToString() + ";" + chr.Name + ";" + chr.RankPoints.ToString() + ";" + chr.Honor.ToString() + ";" + chr.RPAll.ToString() + ";" + chr.PVPRank.ToString());
				DBManager.SaveDBObject(chr);
			}
//			sw.Close();
			Database.Instance.FlushTables();
			Console.WriteLine("Honor calculation done.");
		}
	}
}