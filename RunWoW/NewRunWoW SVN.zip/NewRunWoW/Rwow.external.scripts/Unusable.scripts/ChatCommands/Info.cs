using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.AI;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Info
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("info", "No target selected", new ChatCommand(OnInfo));
		}

		private static bool OnInfo(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			if (Client.Player.Selection == null)
				return false;
			ObjectBase o = Client.Player.Selection;
			Chat.System(client, string.Format("Selected object {0} of type {1}, class: {2}, position: {3}", o.GUID, o.ObjectType, o.GetType().Name, o.Position));
			if (o is LivingObject)
			{
				LivingObject l = o as LivingObject;
				Chat.System(client, string.Format("Name: {0}, Faction: {1}, Flags: {2}, Level: {3}, MaxHealth {4}, MovementFlags {5}", l.Name, l.Faction, l.Flags, l.Level, l.MaxHealth, l.MovementFlags));
				if (o.ObjectType == OBJECTTYPE.UNIT)
				{
					UnitBase u = (UnitBase) o;
					Chat.System(client, string.Format("Title: {0},NpcFlags: {1}, BehaivorID: {2}, CreatureID:{3}, LootGroupID: {4}, TextID:{5}", u.Creature.Title, u.NPC_Flags, u.Spawn.BehaivorID, u.Spawn.CreatureID, u.Spawn.LootGroupID, u.Spawn.TextID));
					/*if (u is MonsterBase)
						Chat.System(client, "State: " + ((MonsterBase)u).Behaivor.State + ", Event - " + ((MonsterBase)u).Behaivor.Event);**/
				}
				else if (o.ObjectType == OBJECTTYPE.PLAYER)
				{
					PlayerObject p = (PlayerObject) o;
					Chat.System(client, string.Format("Race: {0}, Class: {1}, PlayerFlags: {2}", p.Race, p.Class, p.PlayerFlags));
					if (p.BackLink != null)
						Chat.System(client,
						            string.Format("Delay: {0}, Time: {1}", p.BackLink.Delay,
						                          new DateTime(p.BackLink.ClientTime*TimeSpan.TicksPerMillisecond).ToString(
						                          	"HH:mm:ss.ffff")));
				}
			}
			return true;
		}
	}
}