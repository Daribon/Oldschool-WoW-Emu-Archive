using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Summon
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("summon", "USAGE: .summon <name> - summon offline player", new ChatCommand(OnSummon));
		}

		private static bool OnSummon(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			string[] split = input.Split(new char[] {'=', ' '});
			if (split.Length != 2)
				return false;

			PlayerObject p = ClientManager.GetPlayer(split[1]);
			if (p != null)
			{
				Teleport.TeleportTo(Client.Player.Position, Client.Player.MapTile.Map, p);
				Chat.System(client, "Player " + split[1] + " is moved online");
				return true;
			}

			bool done = false;
			DBCharacter c = (DBCharacter) Database.Instance.FindObjectByField(typeof (DBCharacter), "Name", split[1]);
			if (c != null)
			{
				c.Position = Client.Player.Position;
				c.WorldMapID = Client.Player.WorldMapID;
				DBManager.SaveDBObject(c);
				done = true;
			}

			if (!done)
				Chat.System(client, "Unknown player " + split[1] + "!");
			else
				Chat.System(client, "Player moved offline");
			return done;
		}

	}
}