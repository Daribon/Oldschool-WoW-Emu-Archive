using System.Collections;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.ExternalScripts.MiscPackets;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.ChatCommands
{
	public class Tickets
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("gm", "No unit selected", new ChatCommand(OnSet));
		}

		private static bool OnSet(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine(
				"Chat command: " + input + ", Selection: " +
				(Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			PlayerObject p = Client.Player;

			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: gm <command> value");
				Chat.System(client, "GM command can be one of: list, complete");
				return true;
			}

			ArrayList tickets = new ArrayList();
			foreach (GMTicket.Ticket ticket in GMTicket.Tickets.Values)
				tickets.Add(ticket);

			tickets.Sort(new TicketComparer());


			//Chat.System(client, "Setting property " + command[1] + " to " + command[2]);
			switch (command[1].ToLower())
			{
//gm tckinfo ��� ������������� ���� �� ������ gmtckinfo#23424#dfsdfsdfssssssssssssssssssssssssssssdfsdfsdfssdfsdfsd    gmtckinfo#ticketCoord#ticketDescription
				case "tckinfo":
					{
						int guid = int.Parse(command[2]);
						for (int i = 0; i < tickets.Count; i++)
						{
							GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];
							if (t.GUID == guid)
							{
								string sout = "gmtckinfo#" + (int) t.Position.X + " "
								              + (int) t.Position.Y + " "
								              + (int) t.Position.Z + " "
								              + (int) t.WorldMapID + "#"
								              + t.Text;

								//Chat.System(client, "Ticket " + t.GUID + "info:\r\n |cffffffff" + t.Text + "|r");
								Chat.System(client, sout);
								return true;
							}
						}
						Chat.System(client, "No valid tickets found.");
					}
					break;
				case "tcklist":
					{
						string sout = "";
						for (int i = 0; i < tickets.Count; i++)
						{
							GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];
							PlayerObject player = ClientManager.GetPlayer((uint) t.OwnerID);
							DBCharacter owner = player != null
							                    	? player.Character
							                    	: (DBCharacter) Database.Instance.FindObjectByKey(typeof (DBCharacter), t.OwnerID);
							string color = GetColor(t);
							string stype = GMTicket.GetTicketTypeString(t);

							string sonline = "|cffff0000[offline]|r";
							if (owner != null)
								sonline = player != null ? "|cff00ff00[online]|r " : "|cffff0000[offline]|r";

							sout += "gmtcklist";
							sout += "#" + t.GUID;
							sout += "#" + owner.Name;
							sout += "#" + sonline + " |cff" + color + stype + "|r";
							sout += "#" + t.Time + "\n";
						}
						//Chat.System(client, sonline + " " + ColorString(color, t.GUID + " | " + owner.Name + " | " + stype + " | created at: " + t.Time));

						if (sout.Length <= 0)
							sout = "gmtcklist#empty";

						Chat.System(client, sout);
					}
					break;
				case "list":
					for (int i = 0; i < tickets.Count; i++)
					{
						GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];

						PlayerObject player = ClientManager.GetPlayer((uint) t.OwnerID);
						DBCharacter owner = player != null
						                    	? player.Character
						                    	: (DBCharacter) Database.Instance.FindObjectByKey(typeof (DBCharacter), t.OwnerID);
						string color = GetColor(t);
						string stype = GMTicket.GetTicketTypeString(t);

						if (owner != null)
						{
							string sonline = player != null ? "|cff00ff00[*]|r" : "|cffff0000[*]|r";
							Chat.System(client,
							            sonline + " " +
							            ColorString(color, t.GUID + " | " + owner.Name + " | " + stype + " | created at: " + t.Time));
						}
					}
					break;
				case "del":
					{
						int guid = int.Parse(command[2]);
						for (int i = 0; i < tickets.Count; i++)
						{
							GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];
							if (t.GUID == guid)
							{
								GMTicket.RejectTicket(t, p);
								return true;
							}
						}
						Chat.System(client, "No valid tickets found.");
					}
					break;
				case "close":
					{
						int guid = int.Parse(command[2]);
						for (int i = 0; i < tickets.Count; i++)
						{
							GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];
							if (t.GUID == guid)
							{
								GMTicket.CloseTicket(t, p);
								return true;
							}
						}
						Chat.System(client, "No valid tickets found.");
					}
					break;
				case "go":
					{
						int guid = int.Parse(command[2]);
						for (int i = 0; i < tickets.Count; i++)
						{
							GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];
							if (t.GUID == guid)
							{
								Teleport.TeleportTo(t.Position, (uint) t.WorldMapID, p);
								return true;
							}
						}
					}
					break;
				case "gochar":
					{
						int guid = int.Parse(command[2]);
						for (int i = 0; i < tickets.Count; i++)
						{
							GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];
							PlayerObject player = ClientManager.GetPlayer((uint) t.OwnerID);
							DBCharacter owner = player != null
							                    	? player.Character
							                    	: (DBCharacter) Database.Instance.FindObjectByKey(typeof (DBCharacter), t.OwnerID);

							Vector pos = player != null ? player.Position : owner != null ? owner.Position : null;
							uint worldId = player != null ? player.WorldMapID : owner != null ? owner.WorldMapID : (uint) 0;
							if (pos != null)
							{
								Teleport.TeleportTo(pos, worldId, p);
							}
						}
					}
					break;
				case "details":
				case "info":
					{
						int guid = int.Parse(command[2]);
						for (int i = 0; i < tickets.Count; i++)
						{
							GMTicket.Ticket t = (GMTicket.Ticket) tickets[i];
							if (t.GUID == guid)
							{
								Chat.System(client, "Ticket " + t.GUID + "info:\r\n |cffffffff" + t.Text + "|r");
								return true;
							}
						}
						Chat.System(client, "No valid tickets found.");
					}
					break;
				default:
					Chat.System(client, "Unknown command");
					return true;
			}
			return true;
		}

		public static string ColorString(string color, string text)
		{
			return "|cff" + color + " " + text + "|r";
		}

		private static string GetColor(GMTicket.Ticket t)
		{
			switch (t.Type)
			{
				case (int) GMTicket.GM_TICKET_TYPE.STUCK:
				case (int) GMTicket.GM_TICKET_TYPE.ACCOUNT:
				case (int) GMTicket.GM_TICKET_TYPE.CHARACTER:
					return "FF0000";
				case (int) GMTicket.GM_TICKET_TYPE.NON_QUEST_NPC:
					return "20FFFF";
				case (int) GMTicket.GM_TICKET_TYPE.QUEST_NPC:
					return "00FF00";
			}
			return "A0A0FF";
		}

		internal class TicketComparer : IComparer
		{
			public TicketComparer()
			{
			}

			// Methods
			public virtual int Compare(object x, object y)
			{
				GMTicket.Ticket tik1 = (GMTicket.Ticket) x;
				GMTicket.Ticket tik2 = (GMTicket.Ticket) y;
				return Comparer.Default.Compare(tik2.Time, tik1.Time);
			}
		}
	}
}