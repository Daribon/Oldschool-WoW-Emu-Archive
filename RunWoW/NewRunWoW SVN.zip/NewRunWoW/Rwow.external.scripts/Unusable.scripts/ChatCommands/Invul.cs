using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Invul
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("invul", "", new ChatCommand(OnInvul));
		}

		private static bool OnInvul(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			Client.Player.Invul = !Client.Player.Invul;
			Chat.System(client, "Invul mode " + (Client.Player.Invul ? "on" : "off"));
			return true;
		}
	}
}