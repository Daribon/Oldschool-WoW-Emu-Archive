using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class GOSpawn
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("gospawn", "gospawn GOID level [loot]", new ChatCommand(OnGOSpawn));
		}

		private static bool OnGOSpawn(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			string[] command = input.Split(new char[] {',', ' '});

			if (command.Length < 3)
				return false;

			uint gid;
			int level = 0;
			uint loot = 0;
			try
			{
				gid = uint.Parse(command[1]);
				level = int.Parse(command[2]);
				
				if (command.Length>=4)
					loot = uint.Parse(command[3]);
			}
			catch (Exception)
			{
				return false;
			}

			DBGOTemplate template = (DBGOTemplate) Database.Instance.FindObjectByKey(typeof (DBGOTemplate), gid);
			if (template == null)
			{
				Chat.System(client, "Unknown GOID!");
				return true;
			}
			DBGameObject go = new DBGameObject();
			go.Template = template;
			go.TemplateID = gid;
			go.Position = Client.Player.Position;
			go.Facing = Client.Player.Facing;
			go.Level = level;
			go.QuestID = template.ObjectId;
			go.LootGroupID = loot == 0 ? template.LootGroupId == 0 ? template.ObjectId : template.LootGroupId : loot;
			go.WorldMapID = Client.Player.WorldMapID;

			DBManager.NewDBObject(go);

			GameObject gameObject = new GameObject(go);
			Client.Player.MapTile.Map.Enter(gameObject);

			DBManager.SaveDBObject(go);
			Chat.System(client, string.Format("Spawned GO: {0}, Level: {1}", gameObject.Name, level));
			return true;
		}
	}
}
