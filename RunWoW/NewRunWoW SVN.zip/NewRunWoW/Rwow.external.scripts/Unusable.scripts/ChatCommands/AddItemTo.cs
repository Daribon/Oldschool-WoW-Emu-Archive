//
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunServer.Common;
using RunWoW.Objects;

namespace RunWoW.ChatCommands
{
	public class AddItemTo
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("additemto", "additemto <id>", new ChatCommand(OnAddItem));
		}

		private static bool OnAddItem(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				return false;
			}
			int itemid = 0;
			try
			{
				itemid = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid item id!");
				return true;
			}

			DBItemTemplate template = (DBItemTemplate)Database.Instance.FindObjectByKey(typeof(DBItemTemplate), itemid);

			if (template == null)
			{
				Chat.System(client, "Not valid item id!");
				return true;
			}

			int count = 1;
            try
            {
				count = int.Parse(command[2]);
            }
            catch
			{}

			if (!(Client.Player.Selection is PlayerObject))
			{
				Chat.System(client, "No player selected. Add to self");
				if (!Client.Player.AddItem(template, count, false))
				{
					Chat.System(client, "Cannot add item!");
					return true;
				}
			}
			else
			{
				if (!((PlayerObject)Client.Player.Selection).AddItem(template, count, false))
				{
					Chat.System(client, "Cannot add item!");
					return true;
				}
			}

			if (Client.Account.AccessLvl > ACCESSLEVEL.GM)
			{
				ItemObject item = Client.Player.Inventory.FindItem((int)template.ObjectId);
				if (item != null)
				{
					item.StaticFlags = 0;
					Client.Player.Inventory.UpdateInventory();
				}
			}
			
			//if (Client.Account.AccessLvl > ACCESSLEVEL.GM)
			//{
			//    item.StaticFlags = 0;
			//    Client.Player.Inventory.UpdateInventory();
			//}

			return true;
		}
	}
}