using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.ChatCommands
{
	public class BInfo
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("binfo", "No target selected", new ChatCommand(OnInfo));
		}

		private static bool OnInfo(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine(
				"Chat command: " + input + ", Selection: " +
				(Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			MonsterBase monster = Client.Player.Selection as MonsterBase;

			if (monster == null)
				return false;

			Chat.System(client,
			            string.Format("Selected mobile {0}, behaivor {1}, position: {2}", monster.Name, monster.Behaivor.GetType().Name, monster.Position));
			Chat.System(client, string.Format("Attacking {0}, Casting {1}, Moving {2}", monster.Attacking, monster.Casting, monster.Moving));
			LivingObject ggr = monster.Attackers.MostAggressive;
			Chat.System(client, string.Format("Attackers {0}, Most Aggresive {1}", monster.Attackers.LivingCount, ggr == null ? "(null)" : ggr.Name));
			Chat.System(client,
			            string.Format("ActionState {0}, AttackState {1}, behaivor.Event {2}, enemy {3}, behaivor state {4}",
						monster.Behaivor.ActionState(), monster.Behaivor.AttackState(), monster.Behaivor.Event != null ? monster.Behaivor.Event.GetType().Name: "(null)",
			                          monster.Behaivor.Enemy == null ? "(null)" : monster.Behaivor.Enemy.Name, monster.Behaivor.State));

			return true;
		}
	}
}