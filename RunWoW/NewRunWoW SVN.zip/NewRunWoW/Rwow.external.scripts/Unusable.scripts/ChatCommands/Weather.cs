using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;

namespace RunWoW.ChatCommands
{
	public class WeatherCommand
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("weather", "weather <type>", new ChatCommand(OnWeather));
		}

		private static bool OnWeather(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.DEVELOPER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine(
				"Chat command: " + input + ", Selection: " +
				(Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: weather <type>");
				return true;
			}
			int type = 0;
			try
			{
				type = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid weather id!");
				return true;
			}
			DBArea area = (DBArea) Database.Instance.FindObjectByKey(typeof (DBArea), Client.Player.Zone);
			if (area == null)
			{
				Chat.System(client, "Current zone unknown!");
				return true;
			}

			area.Weather = (WeatherType) type;
			DBManager.SaveDBObject(area);
			Weather.ForceSetWeather(client, Client.Player.Zone);
			return true;
		}
	}
}