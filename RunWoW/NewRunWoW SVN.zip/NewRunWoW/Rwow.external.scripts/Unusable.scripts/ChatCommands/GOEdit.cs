using System.Collections;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;
using RunServer.Common;
using System;

namespace RunWoW.ChatCommands
{
	public class GOEdit
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("goedit", "<go_id> command", new ChatCommand(OnGOEdit));
		}

		private static bool OnGOEdit(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});
			if (command.Length < 3)
			{
				Chat.System(client, "Format: goedit <property> value");
				return true;
			}
			GameObject go = null;
			double rng = double.MaxValue;

			foreach (MapTile mapTile in Client.Player.MapTile.Adjacents.Tiles)
				if (mapTile!=null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection!=null)
						foreach (GameObject gameObject in collection)
						if (gameObject != null)
						{
							double nrng = gameObject.Position.DistanceSqrd(Client.Player.Position);
							if (nrng < rng)
							{
								rng = nrng;
								go = gameObject;
							}
						}
				}

			if (go == null)
			{
				Chat.System(client, "No game Objects found!");
				return true;
			}
			Chat.System(client, "Setting property " + command[1] + " to " + command[2]);
			switch (command[1].ToLower())
			{
				case "flags":
					go.Flags = uint.Parse(command[2]);
					break;
				case "level":
					go.Level = int.Parse(command[2]);
					break;
				case "state":
					go.State = int.Parse(command[2]);
					break;
				case "dflags":
					go.DynamicFlags = int.Parse(command[2]);
					break;
				case "time":
					go.Timestamp = int.Parse(command[2]);
					break;
				case "faction":
					go.Faction = (FACTION) int.Parse(command[2]);
					break;
				case "loot":
					go.DBGameObject.LootGroupID = uint.Parse(command[2]);
					go.DBGameObject.Loot = null;
					go.Loot = null;

					Database.Instance.ResolveRelations(go.DBGameObject, typeof(DBGOLoot));
					Database.Instance.SaveObject(go.DBGameObject);
					
					break;
				case "axis":
					if (command.Length < 4)
					{
						Chat.System(client, "Usage:  .goedit axis [axis] angle");
						return true;
					}
					string axis  = command[2];
					int angle = int.Parse(command[3]);
					float rad = (float)Math.Sin((float)(angle * Math.PI / 360));

					//float angle = float.Parse(command[3]);
					//float rad = (float)(angle * Math.PI / 180);
					//float rad = angle;
					
					float[] rotate  =  go.Rotation;

					/*
					 // z rotate
					   y = o.y0*Math.cos(angleZ)+o.x0*Math.sin(angleZ);
					   x = o.x0*Math.cos(angleZ)-o.y0*Math.sin(angleZ);
					   // y rotate
					   z = o.z0*Math.cos(angleY)-x*Math.sin(angleY);
					   x = x*Math.cos(angleY)+o.z0*Math.sin(angleY);
					   // x rotate
					   oy = y;
					   y = y*Math.cos(angleX)-z*Math.sin(angleX);
					   z = oy*Math.sin(angleX)+z*Math.cos(angleX);
					 * 
					   depth = 1/(1-z/perspective);
					   o.x = x*fscale;
					   o.y = y*fscale;
					   o.z = z*fscale;* 
					 * */
					// .goedit axis x 100

					if (axis.ToLower().Equals("x"))
						rotate[0] = rad;
					else if (axis.ToLower().Equals("y"))
						rotate[1] = rad;
					else if (axis.ToLower().Equals("z"))
						rotate[2] = rad;

					//else if (axis.ToLower().Equals("w"))
					//	rotate[3] = rad;

					//rotate[3] = (1-(rotate[0]^2+rotate[1]^2+rotate[2]^2)^0.6;
					float dat = (float)1 - (rotate[0] * rotate[0] + rotate[1] * rotate[1] + rotate[2] * rotate[2]);
					rotate[3] = (float)Math.Sqrt(Math.Abs(dat))*Math.Sign(dat); 
					//sign(1-(sin(rotation0)^2+sin(rotation1)^2+sin(rotation2)^2)

					go.Rotation = rotate;
					go.UpdateData();
					Client.Player.MapTile.Map.Reenter(go);
					
					return true;
				default:
					Chat.System(client, "Unknown propetry");
					return true;
			}
			go.UpdateData();
			/*DBManager.SaveDBObject(go.GOTemplate);
			DBManager.SaveDBObject(go.);*/
			return true;
		}
	}
}