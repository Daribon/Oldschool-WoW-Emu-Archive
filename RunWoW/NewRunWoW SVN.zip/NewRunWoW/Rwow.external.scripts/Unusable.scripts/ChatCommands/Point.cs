using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Point
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("point", "USAGE: .point <id>", new ChatCommand(OnPoint));
		}

		private static bool OnPoint(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
				return false;

			uint number = 0;
			try
			{
				number = uint.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid point id!");
				return true;
			}
			if (Client.Account.AccessLvl < ACCESSLEVEL.DEVELOPER && (number <=10 || number >=1030))
			{
				Chat.System(client, "You can't set system points!");
				return true;
			}

			DBPoint Point = (DBPoint) Database.Instance.FindObjectByKey(typeof (DBPoint), number);
			if (Point == null)
			{
				Point = new DBPoint();
				Point.ObjectId = number;
			}

			Point.Position = Client.Player.Position;
			Point.WorldMapID = Client.Player.WorldMapID;

			if (Point.New)
				DBManager.NewDBObject(Point);
			else
				DBManager.SaveDBObject(Point);
			Chat.System(client, "Point " + number + " saved");
			return true;
		}
	}
}