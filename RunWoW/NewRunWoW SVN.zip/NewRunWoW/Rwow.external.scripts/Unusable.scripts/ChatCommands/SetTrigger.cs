using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class SetTrigger
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("settrigger", "USAGE: .settrigger <id>", new ChatCommand(OnSetTrigger));
		}

		private static bool OnSetTrigger(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
				return false;

			uint number = 0;
			try
			{
				number = uint.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid trigger id!");
				return true;
			}
			float shift = 0f;
			if (command.Length>2)
			{
				try
				{
					shift = float.Parse(command[2]);
				}
				catch
				{
					Chat.System(client, "Not valid shift!");
					return true;
				}
			}

			DBAreaTrigger Trigger = (DBAreaTrigger) Database.Instance.FindObjectByKey(typeof (DBAreaTrigger), number);
			if (Trigger == null)
			{
				//Chat.System(client, "Not valid trigger id!");
				//return true;
				Trigger = new DBAreaTrigger();
				Trigger.ObjectId = number;
			}

			Trigger.Position = Client.Player.Position.Clone();
			Trigger.Position.Z += shift;
			Trigger.WorldMapID = Client.Player.WorldMapID;
			Trigger.Facing = Client.Player.Facing;
			Trigger.Enabled = true;

			if (Trigger.New)
				DBManager.NewDBObject(Trigger);
			else
				DBManager.SaveDBObject(Trigger);
			Chat.System(client, "Trigger " + number + " saved");
			return true;
		}
	}
}