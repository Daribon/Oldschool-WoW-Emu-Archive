using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Rename
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("rename", "No player selected", new ChatCommand(OnRename));
		}

		private static bool OnRename(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			PlayerObject p = Client.Player.Selection as PlayerObject;

			if (p == null)
				return false;

			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: rename <new name>");
				return true;
			}

			if (Database.Instance.FindObjectByField(typeof(DBCharacter), "Name", command[1]) != null)
			{
				Chat.System(client, "Player with that name already exists");
				return true;
			}
			
			Chat.System(client, "Setting Name from " + p.Name + " to " + command[1]);
			p.Name = command[1];
			p.UpdateData();

			DBManager.SaveDBObject(p.Character);
			return true;
		}
	}
}