using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Goto
	{
		public static void Initialize()
		{
            ChatManager.RegisterChatCommand("go", "USAGE: .goto - move to selection, .goto <x> <y> <z> [world] [instance]- move to position, .goto <name> - move to player, .goto <number> - move to point", new ChatCommand(OnGoto));
			ChatManager.RegisterChatCommand("goto", "USAGE: .goto - move to selection, .goto <x> <y> <z> [world] [instance] - move to position, .goto <name> - move to player, .goto <number> - move to point", new ChatCommand(OnGoto));
		}

		private static bool OnGoto(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			string[] split = input.Split(new char[] {'=', ' '});

			uint world;
			uint instance = 0;
			float x;
			float y;
			float z;

			switch (split.Length)
			{
					// '.goto <x> <y> <z> [world]'
				case 4:
				case 5:
				case 6:
					x = float.Parse(split[1]);
					y = float.Parse(split[2]);
					z = float.Parse(split[3]);
					world = split.Length >= 5 ? uint.Parse(split[4]) : Client.Player.WorldMapID;
					instance = split.Length >= 6 ? uint.Parse(split[6]) : Client.Player.MapInstanceID;

					/*if (world!=0 && world!=1 && world !=369)
						{
							Chat.System(client, "Invalid world. Use '0' for Azxeroth or '1' for Kalimdor");
							return false;
						}*/
					break;
					//'.goto [name]'
					//choose <player> or <object> and say '.goto'
				case 1:
				case 2:
					ObjectBase wo;
					wo = split.Length == 2 ? ClientManager.GetPlayer(split[1]) : Client.Player.Selection;

                    if (wo == null)
                    {
                        if (split.Length == 2)
                        {
                            try
                            {
                                int number = int.Parse(split[1]);

                                DBPoint Point = null;
                                if ( number >= 0 )
                                    Point = (DBPoint)Database.Instance.FindObjectByKey(typeof(DBPoint), number);
                                if (Point == null)
                                    throw new Exception();
                                if (MapManager.GetWorldMap(Point.WorldMapID, 0) == null)
                                    throw new Exception();
                                Teleport.TeleportTo(Point.Position, Point.WorldMapID, Client.Player);
                                return true;
                            }
                            catch (FormatException)
                            {
                                Chat.System(client, "Point number " + split[1]  + " is incorrect");
                            }
                            catch (Exception)
                            {
                                DBCharacter character = (DBCharacter)Database.Instance.FindObjectByField(typeof(DBCharacter), "Name", split[1]);
                                if (character != null)
                                {
                                    try
                                    {
                                        x = character.Position.X;
                                        y = character.Position.Y;
                                        z = character.Position.Z;
                                        world = character.WorldMapID;
                                        Vector vector = new Vector(x, y, z);
                                        Teleport.TeleportTo(vector, world, Client.Player);
                                        return true;
                                    }
                                    catch
                                    {
                                        Chat.System(client, "Player " + split[1] + " error.");
                                        return false;
                                    }
                                }
                            }
                        }
                        else
                            Chat.System(client, "Can't move to this object");
                        return false;
                    }

					x = wo.Position.X;
					y = wo.Position.Y;
					z = wo.Position.Z;
					world = wo.MapTile.Map.MapID;
					instance = wo.MapTile.Map.InstanceID;

					break;

					//error!
				default:
					Chat.System(client, "Invalid number of parameters!");
					return false;
			}
			Vector vec = new Vector(x, y, z);
			Teleport.TeleportTo(vec, MapManager.GetWorldMap(world, instance), Client.Player);
			return true;
		}
	}
}