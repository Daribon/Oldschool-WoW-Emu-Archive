using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunWoW.World;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Trigger
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("trigger", "id", new ChatCommand(OnTrigger));
		}

		private static bool OnTrigger(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: trigger <triggerid>");
				LogConsoleGM.WriteLine("Format: trigger <triggerid>", Client.Account.Name);
				return true;
			}
			uint area;
			try
			{
				area = uint.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid trigger id!");
				LogConsoleGM.WriteLine("Not valid trigger id!", Client.Account.Name);
				return true;
			}
			DBAreaTrigger Trigger = (DBAreaTrigger) Database.Instance.FindObjectByKey(typeof (DBAreaTrigger), area);
			if (Trigger == null)
			{
				Chat.System(client, "Not valid trigger id!");
				LogConsoleGM.WriteLine("Not valid trigger id!", Client.Account.Name);
				return true;
			}
			/*if (Trigger.Redirect!=0)
			{
				Trigger=(DBAreaTrigger)Database.Instance.FindObjectByKey(typeof(DBAreaTrigger),Trigger.Redirect);
				if (Trigger==null||!Trigger.Enabled)
					return false;
			}*/
			Chat.System(client, string.Format("Entering trigger {0},map: {1}", area, (Trigger.WorldMapID)));
			LogConsoleGM.WriteLine(string.Format("Entering trigger {0},map: {1}", area, (Trigger.WorldMapID)), Client.Account.Name);
			LogConsole.WriteLine(LogLevel.SYSTEM, "Trigger {0},map: {1}", area, (Trigger.WorldMapID));

			if (MapManager.GetWorldMap(Trigger.WorldMapID, 0) == null)
				return false;

			if (Trigger.Facing != 0)
				Client.Player.Facing = Trigger.Facing;

			Teleport.TeleportTo(Trigger.Position, Trigger.WorldMapID, Client.Player);
			return true;
		}
	}
}