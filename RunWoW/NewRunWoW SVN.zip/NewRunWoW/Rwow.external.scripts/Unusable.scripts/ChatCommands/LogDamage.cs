using RunWoW.Accounting;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class LogDamage
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("logdamage", "", new ChatCommand(OnLogDamage));
		}

		private static bool OnLogDamage(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;
			Client.Player.LogDamage = !Client.Player.LogDamage;
			Chat.System(client, "Log damage mode " + (Client.Player.LogDamage ? "on" : "off"));
			return true;
		}
	}
}