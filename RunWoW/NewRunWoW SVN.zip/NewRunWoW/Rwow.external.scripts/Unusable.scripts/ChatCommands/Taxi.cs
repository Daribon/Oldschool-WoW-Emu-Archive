using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunWoW.World;

namespace RunWoW.ChatCommands
{
	public class Taxi
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("taxi", "USAGE: .taxi <number> - move to point", new ChatCommand(OnTaxi));
		}

		private static bool OnTaxi(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine(
				"Chat command: " + input + ", Selection: " +
				(Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
				return false;

			uint number;
			try
			{
				number = uint.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid taxi id!");
				return true;
			}

			DBTaxiNode node = (DBTaxiNode) Database.Instance.FindObjectByKey(typeof (DBTaxiNode), number);
			if (node == null)
			{
				Chat.System(client, "Not valid taxi id!");
				return true;
			}
			if (MapManager.GetWorldMap(node.WorldMapID, 0) == null)
			{
				Chat.System(client, "Not valid taxi world!");
				return true;
			}
			
			Teleport.TeleportTo(node.Position, node.WorldMapID, Client.Player);
			return true;
		}
	}
}