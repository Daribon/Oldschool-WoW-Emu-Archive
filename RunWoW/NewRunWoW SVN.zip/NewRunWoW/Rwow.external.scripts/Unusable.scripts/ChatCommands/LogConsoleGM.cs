using RunWoW.ServerScripts.Misc;

namespace RunWoW.ChatCommands
{
	public class LogConsoleGM
	{
		private static string DefaultLogPath = "GM_Logs";

		public static void WriteLine(string text, string name)
		{
			CustomLog.WriteLine(text, name, DefaultLogPath);
		}
	}
}