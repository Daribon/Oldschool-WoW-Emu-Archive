using RunWoW.Accounting;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class SuicideCommand
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("suicide", "kills you", new ChatCommand(OnSuicideCommand));
		}

		private static bool OnSuicideCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Player.Character.WorldMapID == 13 || Client.Player.Character.WorldMapID == 29)
			{
				Chat.System(client, "You cannot escape from the prison!");
				return true;
			}
			
			if (Client.Player.Dead)
				Client.Player.TeleportToHealer();
			//Chat.System(client, "You are already dead!");
			else
				Client.Player.Dead = true;
			return true;
		}
	}
}