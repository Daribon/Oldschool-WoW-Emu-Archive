using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GameObjects;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunWoW.Spells;

namespace RunWoW.ExternalScripts.GameObjects
{
    public class ContainerGameObject
    {
        public static void Process(LivingObject user, GameObject go)
        {
            PlayerObject player = user as PlayerObject;
            if (player == null)
                return;

            int type = go.Template.Sound[0];

            DBLock dbLock = (DBLock) Database.Instance.FindObjectByKey(typeof (DBLock), type);
            
            if (dbLock != null)
                switch(dbLock.Type)
                {
                    case 0: // chests
                        break;
                    case 1: // locked chests
                        //int key = dbLock.Target[0];
                        /// TODO: check key, etc.
                        break;
                    case 2: // gather
                        int spellId = 0;
                        switch(dbLock.Target[0])
                        {
                            case 1: // pick lock
                                PlayerSkill lockpicking = player.Skills[SKILL.LOCKPICKING];
                                if (lockpicking != null)
                                    spellId = lockpicking.Ability.SpellID;
                                break;
                            case 2: // herbalism
                                PlayerSkill herbalism = player.Skills[SKILL.HERBALISM];
                                if (herbalism != null)
                                    spellId = herbalism.Ability.SpellID;
                                break;
                            case 3: // mining
                                PlayerSkill mining = player.Skills[SKILL.MINING];
                                if (mining != null)
                                    spellId = mining.Ability.SpellID;
                                break;
                            case 4: // disarm trap
                                break;
                            case 10: // quick open
                                break;
                            case 12: // open tinkering
                                break;
                            case 19: // fishing
                                PlayerSkill fishing = player.Skills[SKILL.FISHING];
                                if (fishing != null)
                                    spellId = fishing.Ability.SpellID;
                                break;
                        }
                        
                        if (spellId != 0)
                            SpellManager.Cast(user, go, spellId);
                        break;
                }
            
            StaticGameObject.Process(user, go);
        }

        [InitializeHandler(InitPass.Third)]
        public static void Initialize()
        {
            GOManager.RegisterType(GameObjectType.Container, new GameObjectAction(Process));
        }
    }
}
