using System;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.GameObjects
{
    public class StaticGameObject : Event
    {
        private GameObject mGameObject = null;

        public StaticGameObject(GameObject go) : base(TimeSpan.FromSeconds(10))
        {
            mGameObject = go;
        }

        public static void Process(LivingObject user, GameObject go)
        {
            //PlayerObject player = (PlayerObject)user;
            go.State = go.State == 1 ? 0 : 1;
            go.UpdateData();
            StaticGameObject sGo = new StaticGameObject(go);
            sGo.Start();
        }

        protected override void OnTick()
        {
            base.Finish();
        }

        protected override void OnFinish()
        {
            mGameObject.State = mGameObject.State == 1 ? 0 : 1;
            mGameObject.UpdateData();
            mGameObject = null;
            base.OnFinish();
        }

        [InitializeHandler(InitPass.Third)]
        public static void Initialize()
        {
            GOManager.RegisterType(GameObjectType.Static, new GameObjectAction(Process));
            //GOManager.RegisterType(GameObjectType.Container, new GameObjectAction(Process));
        }
    }
}