using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.Spells;
using RunWoW.Misc;

namespace RunWoW.GameObjects
{
	public class PortalGameObject
	{
		public static void Process(LivingObject user, GameObject go)
		{
			int spellId = go.Template.Sound[0];
			DBSpell spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellId);
			if (spell == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Casting unknown portal spell " + spellId);
				return;
			}

			PlayerObject userPlayer = user as PlayerObject;

			PlayerObject creator = null;

			if (go.Creator != 0)
			{
				creator = ClientManager.GetPlayer(go.Creator);
				if (creator == null)
				{
					if (userPlayer != null)
						Chat.System(userPlayer.BackLink.Client, "Can`t use that portal.");
					return;
				}
			}

			if (creator == null || creator.SameGroup(user))
				SpellManager.Cast(go, user, spell);
			else
				if (userPlayer != null)
					Chat.System(userPlayer.BackLink.Client, "You are not in portal creator party.");
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			GOManager.RegisterType(GameObjectType.Portal, new GameObjectAction(Process));
		}
	}
}