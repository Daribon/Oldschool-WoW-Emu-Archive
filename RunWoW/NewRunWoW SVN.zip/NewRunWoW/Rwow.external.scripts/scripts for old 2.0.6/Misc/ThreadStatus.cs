//
using System;
using System.Collections;
using System.Diagnostics;
using System.IO;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Map;
using RunWoW.Objects;
using RunWoW.World;

namespace RunWoW.Misc
{
	
	public class ThreadStatusPage : Event
	{
		private static ThreadStatusPage Instance = new ThreadStatusPage();
		
		private Hashtable LastTimes = new Hashtable();
		private DateTime LastTick = CustomDateTime.Now;
		private TimeSpan TotalTime = TimeSpan.Zero;

		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}

		public ThreadStatusPage()
			: base(TimeSpan.FromSeconds(120), TimeSpan.FromSeconds(60))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
			if (!Directory.Exists(Constants.StatusPath))
				Directory.CreateDirectory(Constants.StatusPath);
		}

		protected override void OnTick()
		{
			Process m_process = Process.GetCurrentProcess();
			DateTime now = CustomDateTime.Now;
			using (StreamWriter op = new StreamWriter(Constants.StatusPath + Constants.ThreadStatusFile))
			{
				op.WriteLine("<HEAD><META HTTP-EQUIV='Refresh' CONTENT='30' /></HEAD>");
				op.WriteLine(
					"<h2 style='color:white'><center>World of Warcraft Server Thread Status: &nbsp<img src='http://wowserver.wnet.ua/stat.aspx'></center></h2>");
				op.WriteLine("<style>");
				op.WriteLine("TD.head {");
				op.WriteLine("   color: white;");
				op.WriteLine("   font: bold;");
				op.WriteLine("   background: #222222;");
				op.WriteLine("}");
				op.WriteLine("TD.head1 {");
				op.WriteLine("   color: white;");
				op.WriteLine("   font: bold;");
				op.WriteLine("}");
				op.WriteLine("</style>");
				op.WriteLine("   <table style='border: 1px Gray solid;' width='100%' cellspacing='1'>");
				op.WriteLine("      <tr><td class='head' colspan=4><center>General Information</center></td></tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Total CPU load</td><td>{0}</td>", StatusUtility.FormatCPULoad(m_process.TotalProcessorTime, TotalTime, LastTick, now));
				op.WriteLine("         <td class='head1'>Average CPU load</td><td>{0}</td>", StatusUtility.FormatCPULoad(m_process.TotalProcessorTime, TimeSpan.Zero, m_process.StartTime, now));
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Total threads</td><td>{0}</td>", m_process.Threads.Count);
				op.WriteLine("         <td class='head1'>Total timers</td><td>{0}</td>", Timer.TimerCount);
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Bytes sent last minute</td><td>{0}</td>", StaticCounters.SendBytes);
				op.WriteLine("         <td class='head1'>Packets sent last minute</td><td>{0}</td>", StaticCounters.SendPackets);
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Running Timers</td><td>{0}</td>", Timer.RunningTimers);
				op.WriteLine("         <td class='head1'>Loaded ADT tiles</td><td>{0}</td>", WorldMap.LoadedTiles);
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Total clients online</td><td>{0}</td>", ClientManager.OnlineCount);
				op.WriteLine("         <td class='head1'>Total clients offline</td><td>{0}</td>", ClientManager.OfflineCount);
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Heap buffers allocated</td><td>{0}</td>", HeapBuffer.Allocated);
				op.WriteLine("         <td class='head1'>Heap buffers released</td><td>{0}</td>", HeapBuffer.Released);
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>VirtualHeap used</td><td>{0}</td>", StatusUtility.FormatByteAmount((int)HeapBuffer.BytesUsed));
				op.WriteLine("         <td class='head1'>GC Heap used</td><td>{0}</td>", StatusUtility.FormatByteAmount(GC.GetTotalMemory(false)));
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Mobiles awakened</td><td>{0}</td>", UnitBase.Awakened);
				op.WriteLine("         <td class='head1'>Mobiles sleeping</td><td>{0}</td>", UnitBase.Sleeping);
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Azeroth active tiles</td><td>{0}</td>", MapManager.GetWorldMap(0, 0).Updater.Active);
				op.WriteLine("         <td class='head1'>Azeroth behaivors</td><td>{0}</td>", MapManager.GetWorldMap(0, 0).Behaivor.BehaivorsActive);
				op.WriteLine("      </tr>");
				op.WriteLine("      <tr>");
				op.WriteLine("         <td class='head1'>Kalimdor active tiles</td><td>{0}</td>", MapManager.GetWorldMap(1, 0).Updater.Active);
				op.WriteLine("         <td class='head1'>Kalimdor behaivors</td><td>{0}</td>", MapManager.GetWorldMap(1, 0).Behaivor.BehaivorsActive);
				op.WriteLine("      </tr>");

				/*RunServer.Database.CountedObject.Instances.Lock();
					foreach (KeyValuePair<Type, int> pair in RunServer.Database.CountedObject.Instances)
					{
						op.WriteLine("      <tr>");
						op.WriteLine("         <td class='head1'>Objects of type {0}</td><td>{1}</td>", pair.Key.Name, pair.Value);
						op.WriteLine("      </tr>");
					}
					RunServer.Database.CountedObject.Instances.Unlock();*/

				//lock(ObjectManager.Table)
				//{
				//    IDictionaryEnumerator de = ObjectManager.Table.GetEnumerator();
				//    while (de.MoveNext())
				//    {
				//        op.WriteLine("      <tr>");
				//        op.WriteLine("         <td class='head1'>Objects of type {0}</td><td>{1}</td>", de.Key.ToString(), de.Value.ToString());
				//        if (de.Key == typeof (PlayerObject))
				//            op.WriteLine("         <td>{0}</td>", ObjectManager.PlayerTable.Count.ToString());
				//        op.WriteLine("      </tr>");
				//    }
				//}

				//if (ObjectManager.PlayerTable.Count != ClientManager.Online.Count)
				//{
				//    IDictionaryEnumerator de = ObjectManager.PlayerTable.GetEnumerator();
				//    while (de.MoveNext())
				//        if (ClientManager.Online[de.Key] == null)
				//        {
				//            op.WriteLine("      <tr>");
				//            op.WriteLine("         <td class='head1'>Player {0}</td><td>{1}</td>", de.Key.ToString(), de.Value.ToString());
				//            op.WriteLine("      </tr>");
				//        }
				//}


				op.WriteLine("   </table>");
				op.WriteLine("   <br>");


				op.WriteLine("   <table style='border: 1px Gray solid;' width='100%' cellspacing='1' cellpadding='2'>");
				op.WriteLine("      <tr>");
				op.WriteLine(
					"         <td class='head' width='1%'>&nbsp;Thread ID</td><td class='head' width='1%'>&nbsp;State</td><td class='head' width='15%'>&nbsp;Name</td><td class='head' width='20%'>&nbsp;Last&job</td><td class='head' width='15%'>&nbsp;Current Jobs</td><td class='head' width='20%'>&nbsp;Running Time</td><td class='head' width='20%'>&nbsp;Processor Time</td><td class='head' width='10%'>&nbsp;CPU usage</td><td class='head' width='10%'>&nbsp;Average CPU usage</td>");
				op.WriteLine("      </tr>");

				Hashtable NewTimes = new Hashtable();
				IEnumerator e = m_process.Threads.GetEnumerator();
				while (e.MoveNext())
				{
					ProcessThread thread = (ProcessThread) e.Current;
					//if (
					//    StatusUtility.GetCPULoad(thread.TotalProcessorTime, LastTimes[thread.Id], now, LastTick) > 0.5f &&
					//        thread.Id != AppDomain.GetCurrentThreadId()
					//    )
					//{
					//    op.Write("<tr bgcolor=#101010>");
					//}
					//else

					ThreadInfo info = ThreadHelper.GetThread(thread.Id);
					
					op.Write("<tr>");
					op.Write("<td>{0}</td>", thread.Id);
					op.Write("<td>{0}</td>", thread.ThreadState.ToString());
					op.Write("<td>{0}</td>", info.Name);
					op.Write("<td>{0}</td>", info.LastJobTime == DateTime.MinValue ? "none" : StatusUtility.FormatTimeSpan(now - info.LastJobTime));
					op.Write("<td>{0}</td>", info.CurrentJobName);
					op.Write("<td>{0}</td>", StatusUtility.FormatTimeSpan(now - thread.StartTime));
					op.Write("<td>{0}</td>", StatusUtility.FormatTimeSpan(thread.TotalProcessorTime));
					op.Write("<td>{0}</td>", StatusUtility.FormatCPULoad(thread.TotalProcessorTime, LastTimes[thread.Id], LastTick, now));
					op.Write("<td>{0}</td>", StatusUtility.FormatCPULoad(thread.TotalProcessorTime, TimeSpan.Zero, thread.StartTime, now));
					op.Write("</tr>");
					NewTimes[thread.Id] = thread.TotalProcessorTime;
				}
				op.WriteLine("</table>");
				LastTimes = NewTimes;
				LastTick = now;
				TotalTime = m_process.TotalProcessorTime;
			}
		}
	}
}