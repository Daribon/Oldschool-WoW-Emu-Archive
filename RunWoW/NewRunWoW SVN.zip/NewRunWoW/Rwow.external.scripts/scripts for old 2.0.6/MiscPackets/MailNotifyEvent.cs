using System;
using System.Collections;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Accounting;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.MiscPackets;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.ExternalScripts.MiscPackets
{
	public class MailNotifyEvent : Event
	{
		private static MailNotifyEvent Instance = new MailNotifyEvent();

		public MailNotifyEvent() : base(TimeSpan.FromMinutes(1.0), TimeSpan.FromMinutes(5.0))
		{
			Priority = TimerPriority.OneMinute;
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			PooledList<PlayerObject> players = ClientManager.GetPlayerList();
			foreach (PlayerObject player in players)
				{
					if (Mail.GetUnreadMail(player.CharacterID, false).Length > 0)
						Mail.MailNotifyPlayer(player.CharacterID);
				}
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}

	public class MailProcessEvent : Event
	{
		private static MailProcessEvent Instance = new MailProcessEvent();
		//public MailProcessEvent() : base(TimeSpan.FromSeconds(1.0), TimeSpan.FromSeconds(20.0))
		public MailProcessEvent() : base(TimeSpan.FromHours(1.0), TimeSpan.FromHours(1.0))
		{
			ExecPriority = ExecutionPriority.QSeparate;
		}

		protected override void OnTick()
		{
			ICollection pMails = Database.Instance.SelectObjects(typeof (DBMail), string.Format("COD > {0} AND DispatchTime <= {1}", 0, Database.Instance.PrepareData(typeof (DBMail), CustomDateTime.Now)));
			
			foreach (DBMail mail in pMails)
			{
				if (mail.Time < CustomDateTime.Now)
				{
					float DaysLeft = Mail.MGetMailExpirationTime(mail);
					if (DaysLeft <= 0)
					{
						//  We need return COD mail to owner if it expires
						if (mail.COD != 0)
						{
							Mail.ReturnCODMail(mail);
						}
					}
				}
			}

            /*  Remove old mails ,  manually  , not checked for time loss
            double timein = new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds;
            // read all mails 
            ArrayList allMails = Database.Instance.SelectAllObjects(typeof(DBMail));
            foreach (DBMail mail in allMails)
            {
                float DaysLeft = Mail.MGetMailExpirationTime(mail);
                if ( DaysLeft <= 0 )
                {
                        //  We need return COD mail to owner if it expires
                        if (mail.COD != 0)
                        {
                            Mail.ReturnCODMail(mail);
                        } else // Delete mail if it not COD and expires
                        {
                            DBManager.EraseDBObject(mail);
                            DBMailMessage MailMessage = (DBMailMessage)Database.Instance.FindObjectByKey(typeof(DBMailMessage), mail.MessageID);
                            if (MailMessage != null)
                                DBManager.EraseDBObject(MailMessage);
                        }
                }
            }
            Console.WriteLine("Mail process delete time: " + (new TimeSpan(CustomDateTime.Now.Ticks).TotalMilliseconds - timein));            
            */
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			Instance.Start();
		}

		public static void DoFinalize()
		{
			if (Instance != null)
				Instance.Finish();
		}
	}
}