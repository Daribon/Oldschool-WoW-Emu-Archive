//
using System;
using System.Collections.Generic;
using System.Text;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Misc;
using System.Collections;
using RunWoW.Objects;
using RunServer.Common.Attributes;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;
using RunWoW.ServerScripts.Misc;

namespace RunWoW.ExternalScripts.MiscPackets
{
	[PacketHandlerClass]
    class GMTicket
    {
        private static int TICKET_LIVE_TIME = (int)TimeSpan.FromMinutes( 60 ).TotalMilliseconds;
        private static Hashtable m_pTickets = new Hashtable();

        public static Hashtable Tickets
        {
            get { return m_pTickets; }
            set { m_pTickets = value; }
        }


        public enum GM_TICKET_CREATE : int
        {
            OK = 2,
            ALREADY_HAVE = 1,
            ERROR_CREATING = 3,
            ERROR_UPDATING = 5,
        }

        public enum GM_TICKET_TYPE : int
        {
            STUCK = 1,
            HARRASMENT = 2,
            GUILD = 3,
            ITEM = 4,
            ENVIROMENT = 5,
            NON_QUEST_NPC = 6,
            QUEST_NPC = 7,
            ACCOUNT = 9,
            CHARACTER = 10,
        }

        

        [PacketHandler(CMSG.GMTICKET_CREATE)]
        public static void TicketCreate(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;
            int helpCode = (int)data.ReadByte();
			data.ReadByte();
			data.ReadInt16();
            data.ReadInt32();
            data.ReadInt32();
            data.ReadInt32();
            char subgroup = (char)data.ReadByte();
            string helptext = data.ReadString();
            helptext = UTF8Encoding.UTF8.GetString(data.GetBuffer(), data.Position - helptext.Length - 1, helptext.Length);
            string sysString = data.ReadString();

            if (m_pTickets[Client.Player.CharacterID] != null)
            {
                SendTicketCreate(client, (int)GM_TICKET_CREATE.ALREADY_HAVE );
                return;
            }

            Ticket ticket = new Ticket(helptext, helpCode, Client.Player.CharacterID, Client.Player.Position.Clone(),(int) Client.Player.WorldMapID );
            m_pTickets.Add(Client.Player.CharacterID, ticket);
            SendTicketCreate(client, (int)GM_TICKET_CREATE.OK );

            GMBroadcast("|cffff0000!!!!  New " + GetTicketTypeString(ticket) + " ticket created by |r " + Client.Player.Name);
			GMBroadcast("gmtckupdate");

            LogConsole.WriteLine(LogLevel.SYSTEM, Client.Player.Name + ": create " + GetTicketTypeString(ticket) + " ticket.");
        }

        private static void SendTicketCreate(ClientBase client, int p)
        {
            ShortPacket pckg = new ShortPacket(SMSG.GMTICKET_CREATE);
            pckg.Write(p); 
            client.Send(pckg);
            //Chat.System(client, "GM Ticket created , please wait for GM support.");
        }

        [PacketHandler(CMSG.GMTICKET_GETTICKET)]
        public static void SystemStatus(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;

            Ticket ticket = (Ticket)m_pTickets[Client.Player.CharacterID];

            ShortPacket pckg = new ShortPacket(SMSG.GMTICKET_GETTICKET);
            if (ticket != null)
            {
                pckg.Write(6);	//status
                pckg.Write(ticket.Text);
                pckg.Write((byte)7);	//ticket category
                pckg.Write((int)0);	//unknown
                pckg.Write((short)0);	//const
                pckg.Write((int)49024);	//const
                pckg.Write((int)49024);	//const
            }
            else
                pckg.Write(10);	//status
//!!!            client.Send(pckg);
        }

        [PacketHandler(CMSG.GMTICKET_SYSTEMSTATUS)]
        public static void GetTicket(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;
            //data.ReadInt32();
            ShortPacket pckg = new ShortPacket(SMSG.GMTICKET_SYSTEMSTATUS);
            pckg.Write(1);
            client.Send(pckg);
        }

        [PacketHandler(CMSG.GMTICKET_UPDATETEXT)]
        public static void UpdateText(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;
            byte unk1 = data.ReadByte();
            string helptext = data.ReadString();
            helptext = UTF8Encoding.UTF8.GetString(data.GetBuffer(), data.Position - helptext.Length - 1, helptext.Length);

            Ticket ticket = (Ticket)m_pTickets[Client.Player.CharacterID];

            if (ticket != null)
                ticket.Text = helptext;

            ShortPacket pckg = new ShortPacket(SMSG.GMTICKET_UPDATETEXT);
            pckg.Write(0);
            client.Send(pckg);
			GMBroadcast("gmtckupdate");
        }

        [PacketHandler(CMSG.GMTICKET_DELETETICKET)]
        public static void DeleteTicket(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;

            Ticket ticket = (Ticket)m_pTickets[Client.Player.CharacterID];

            int ret = 0;
            if (ticket != null)
            {
                ret = 9;
                m_pTickets.Remove(Client.Player.CharacterID);
            }

            ShortPacket pckg = new ShortPacket(SMSG.GMTICKET_DELETETICKET);
            pckg.Write(ret);
            client.Send(pckg);

            GMBroadcast("|cff50ff00!!!!  Player " + Client.Player.Name  + " abandoned his ticket.|r ");
			GMBroadcast("gmtckupdate");
        }


        [PacketHandler(CMSG.GM_ACCOUNT_ONLINE)]
        public static void AccountOnline(ClientBase client, BinReader data)
        {
            ClientData Client = (ClientData)client.Data;
            data.ReadInt32();
        }



        public static void CloseTicket(Ticket t, PlayerObject gm)
        {
            PlayerObject player = ClientManager.GetPlayer((uint)t.OwnerID);
            DBCharacter owner = player != null ? player.Character : (DBCharacter)Database.Instance.FindObjectByKey(typeof(DBCharacter), t.OwnerID);
            if (owner != null)
            {
                m_pTickets.Remove(t.OwnerID);
				if (gm != null)
					Chat.System(gm.BackLink.Client, "Ticket " + t.GUID + " closed.");
                if (player != null)
                {
                    ShortPacket pckg = new ShortPacket(SMSG.GMTICKET_GETTICKET);
                    pckg.Write(2);
                    pckg.Write("");
                    pckg.Write((byte)1);
                    player.BackLink.Client.Send(pckg);
					if (gm != null)
						Chat.System(player.BackLink.Client, "Your ticket was closed by GM: " + gm.Name);
					GMBroadcast("gmtckupdate");
                    //LogConsole.WriteLine(LogLevel.SYSTEM, gm.Name + ": close " + GetTicketTypeString(t) + "ticket created by " + owner.Name);
					if (gm != null)
						CustomLog.WriteLine("Closed: " + GetTicketTypeString(t) + " ticket, created by " + owner.Name + "\r\n" + t.Text , gm.Name, "GMTicketLog");
                }
            }
        }

        public static void RejectTicket(Ticket t, PlayerObject gm)
        {
            PlayerObject player = ClientManager.GetPlayer((uint)t.OwnerID);
            DBCharacter owner = player != null ? player.Character : (DBCharacter)Database.Instance.FindObjectByKey(typeof(DBCharacter), t.OwnerID);
            if (owner != null)
            {
                m_pTickets.Remove(t.OwnerID);
            	if ( gm != null )
					Chat.System(gm.BackLink.Client, "Ticket " + t.GUID + " has been rejected.");
                if (player != null)
                {
                    ShortPacket pckg = new ShortPacket(SMSG.GMTICKET_GETTICKET);
                    pckg.Write(2);
                    pckg.Write("");
                    pckg.Write((byte)1);
                    player.BackLink.Client.Send(pckg);
                	if (gm != null)
						Chat.System(player.BackLink.Client, "Your ticket was rejected by GM: " + gm.Name);
					GMBroadcast("gmtckupdate");
                    //LogConsole.WriteLine(LogLevel.SYSTEM, gm.Name + ": reject " + GetTicketTypeString(t) + "ticket created by " + owner.Name);
                	if ( gm != null )
						CustomLog.WriteLine("Rejected: " + GetTicketTypeString(t) + " ticket, created by " + owner.Name + "\r\n" + t.Text, gm.Name, "GMTicketLog");
                }
            }
        }

        public static void GMBroadcast( string message)
        {
			PooledList<PlayerObject> list = ClientManager.GetPlayerList();
			foreach (PlayerObject player in list)
                if (player.AccessLvl > ACCESSLEVEL.FEATURED)
                {
                    Chat.System(player.BackLink.Client, message );
                }
        }


        public static string GetTicketTypeString(Ticket t)
        {
            switch (t.Type)
            {
                case (int)GMTicket.GM_TICKET_TYPE.STUCK:
                    return "Stuck Trouble";
                case (int)GMTicket.GM_TICKET_TYPE.ACCOUNT:
                    return "Account Problem";
                case (int)GMTicket.GM_TICKET_TYPE.ENVIROMENT:
                    return "Enviroment Problem";
                case (int)GMTicket.GM_TICKET_TYPE.GUILD:
                    return "Guild Problem";
                case (int)GMTicket.GM_TICKET_TYPE.HARRASMENT:
                    return "Harrasment Problem";
                case (int)GMTicket.GM_TICKET_TYPE.ITEM:
                    return "Item Problem";
                case (int)GMTicket.GM_TICKET_TYPE.NON_QUEST_NPC:
                    return "Non Quest NPC Problem";
                case (int)GMTicket.GM_TICKET_TYPE.QUEST_NPC:
                    return "Quest NPC Problem";
                case (int)GMTicket.GM_TICKET_TYPE.CHARACTER:
                    return "Charracter Problem";
            }
            return "Unknown Trouble";
        }


        public class Ticket
        {
            static int lastTicketID = 1;
            int m_guid;
            int m_type;
            string m_text;
            DateTime m_createdTime;
            Vector m_position;
            int m_WorldMapID;

            uint m_ownerID;
            public Ticket(string text,int code, uint ownerid,Vector pos,int map)
            {
                m_text = text;
                m_guid = lastTicketID++;
                m_ownerID = ownerid;
                m_createdTime = CustomDateTime.Now;
                m_type = code;
                m_position = pos;
                m_WorldMapID = map;
            }

            public int WorldMapID
            {
                get { return m_WorldMapID; }
            }

            public Vector Position
            {
                get { return m_position; }
            }

            public uint OwnerID
            {
                get { return m_ownerID; }
                set { m_ownerID = value; }
            }

            public string Text
            {
                get { return m_text; }
                set { m_text = value;}
            }

            public int Type
            {
                get { return m_type; }
                set { m_type = value; }
            }

            public DateTime Time
            {
                get { return m_createdTime; }
                set { m_createdTime = value; }
            }

            public int GUID
            {
                get { return m_guid; }
            }

        }

	    public class TicketCleanEvent: Event
	    {
            private static TicketCleanEvent Instance = new TicketCleanEvent();

		    public TicketCleanEvent() : base(TimeSpan.FromMinutes(10.0), TimeSpan.FromMinutes(30.0))
		    {
			    ExecPriority = ExecutionPriority.QSeparate;
		    }

		    protected override void OnTick()
		    {
                foreach (object key in GMTicket.Tickets.Keys)
                {
                    Ticket ticket = (Ticket)GMTicket.Tickets[key];
                    if (ticket != null && ticket.Type == (int)GM_TICKET_TYPE.STUCK)
                    {
                        if (ticket.Time < CustomDateTime.Now.AddMinutes(-TICKET_LIVE_TIME))
                        {
                            GMTicket.Tickets.Remove(key);
                        }
                    }
                }
            }

            [InitializeHandler(InitPass.Fourth)]
            public static void Initialize()
            {
                Instance.Start();
            }

            public static void DoFinalize()
            {
                if (Instance != null)
                    Instance.Finish();
            }
        }

    }
}
