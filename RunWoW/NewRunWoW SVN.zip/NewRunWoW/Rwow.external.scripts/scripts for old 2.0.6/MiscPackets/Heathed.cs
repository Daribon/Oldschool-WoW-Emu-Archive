using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class Heathed
	{
		[PacketHandler(CMSG.SETSHEATHED)]
		public static void HandleHeathed(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			Client.Player.Sheathed = (byte) data.ReadInt32();
			Client.Player.UpdateData();
		}
	}
}