using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.ServerDatabase;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class CancelAura
	{
		[PacketHandler(CMSG.CANCEL_AURA)]
		public static void OnCancelAura(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;
			//Hexdump.ToConsole(data);
			uint spell = data.ReadUInt32();
			if (spell == OtherBase.GhostSpell.ObjectId || spell == OtherBase.GhostWispSpell.ObjectId)
				return;
			LogConsole.WriteLine(LogLevel.SYSTEM, "Cancelling aura " + spell);
			Client.Player.Auras.CancelAura(spell);
			Client.Player.Redress();
			Client.Player.UpdateData();
		}
	}
}