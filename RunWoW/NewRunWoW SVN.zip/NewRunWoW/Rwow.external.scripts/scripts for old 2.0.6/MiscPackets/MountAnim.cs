using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class MountAnim
	{
		[PacketHandler(CMSG.MOUNTSPECIAL_ANIM)]
		public static void HandleSpectilAnim(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;

			if (Client == null)
				return;

			//ulong GUID = data.ReadUInt64();
			//int code = data.ReadInt32();
			
			ShortPacket pkg = new ShortPacket(SMSG.MOUNTSPECIAL_ANIM);
			pkg.Write(Client.Player.GUID);
			//pkg.Write(code);
			
			Client.Player.MapTile.SendSurrounding(pkg, Client.Player);
		}
	}
}
