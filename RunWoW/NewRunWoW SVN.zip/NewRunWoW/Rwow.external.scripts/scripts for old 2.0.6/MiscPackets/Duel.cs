using System;
using System.Collections.Generic;
using System.Text;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Objects;
using RunWoW.Misc;
using RunWoW.DB.DataTables;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;
using RunWoW.Map;
using System.Collections;
using RunWoW.WoWRaces;

namespace RunWoW.ExternalScripts.MiscPackets
{
    [PacketHandlerClass()]
    class Duel
    {
        public static CustomArrayList m_pDuels = new CustomArrayList();
        public static uint DUEL_COUNTDOWN_TIME = 3000;
        public static float MAX_DUEL_DISTANCE = 20;
		private static CustomArrayList toRemove = new CustomArrayList();
		private static Hashtable m_pDuelsTable = new Hashtable();
        

        [PacketHandler(CMSG.DUEL_ACCEPTED)]
        public static void AcceptDuel(ClientBase client, BinReader data )
        {
            ClientData Client = (ClientData)client.Data;
            if (Client == null || Client.Player == null)
                return;

            ulong goguid = data.ReadUInt64();

			GameObject go = (GameObject)Client.Player.MapTile.GetObject(goguid, OBJECTTYPE.GAMEOBJECT);

			ShortPacket panim = new ShortPacket(SMSG.GAMEOBJECT_SPAWN_ANIM);
			panim.Write(go.GUID);
			Client.Player.MapTile.SendSurrounding(panim,Client.Player);

			DuelHandler duelHandler = (DuelHandler)m_pDuelsTable[goguid];

            ShortPacket pckgCount = new ShortPacket(SMSG.DUEL_COUNTDOWN);
            pckgCount.Write(DUEL_COUNTDOWN_TIME);
			duelHandler.Player1.BackLink.Client.Send(pckgCount);

            pckgCount = new ShortPacket(SMSG.DUEL_COUNTDOWN);
            pckgCount.Write(DUEL_COUNTDOWN_TIME);
			duelHandler.Player2.BackLink.Client.Send(pckgCount);

            duelHandler.StartDuel();
        }

		public static void RegisterDuel(PlayerObject p1, PlayerObject p2,GameObject go)
		{
			DuelHandler dhandler = new DuelHandler(p1, p2, go);
			m_pDuels.Add(dhandler);
			m_pDuelsTable.Add(go.GUID, dhandler);
		}

        public static GameObject CreateFlagObject( PlayerObject p1,PlayerObject p2)
        {

            DBGOTemplate templ = (DBGOTemplate)Database.Instance.FindObjectByKey(typeof(DBGOTemplate), 21680 );
			if (templ == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "ERROR: Duel flag template not exists {0}!", 21680);
				return null;
			}

			//float dist = p1.Position.Distance(p2.Position);
			//float dist2 = dist/2;
			//float x = p1.Position.X + (dist - dist2) * (p2.Position.X - p1.Position.X) / dist;
			//float y = p1.Position.Y + (dist - dist2) * (p2.Position.Y - p1.Position.Y) / dist;
			float x = p1.Position.X / 2 + p2.Position.X / 2;
			float y = p1.Position.Y / 2 + p2.Position.Y / 2;
        	float z = p1.Position.Z/2 + p2.Position.Z/2;
			if (WorldMap.HasMap((int)p1.WorldMapID))
			{
				float nz = WorldMap.GetPoint((int)p1.WorldMapID, x, y);
				if (Math.Abs(z - nz) < 5)  //  If we in  Storm or Ironforge z - returns incorrect value
					z = nz;
			}
			
				

            Vector mFlagPos = new Vector(x, y, z);

            DBGameObject obj = new DBGameObject();
            obj.Level = 0;
            obj.Position = mFlagPos;
            obj.TemplateID = templ.ObjectId;
            obj.Template = templ;
            obj.WorldMapID = p1.WorldMapID;
            GameObject go = new GameObject(obj, -1, p1.MapTile.Map);
            go.Creator = p1.GUID;
            go.Faction = 0/*p1.Faction*/;
            return go;
        }

        [PacketHandler(CMSG.DUEL_CANCELLED)]
        public static void CancelDuel(ClientBase client, BinReader data)
        {
            ulong arbitrGuid = data.ReadUInt64();


			DuelHandler duelHandler = (DuelHandler)m_pDuelsTable[arbitrGuid];


            try
            {
                PlayerObject requester = duelHandler.Player1;
                if ( requester != null )
                    Chat.System(requester.BackLink.Client, "Player " + ((ClientData)client.Data).Player.Name + " reject your duel request.");

                m_pDuels.Remove(duelHandler);
                m_pDuelsTable.Remove(duelHandler.ArbiterObject.GUID);
                duelHandler.Destroy();
            }
            catch (Exception e)
            {
                LogConsole.WriteLine(LogLevel.ERROR,
                                     "Can`t find duel handler for " + arbitrGuid + " total handlers:" +
                                     m_pDuelsTable.Count + "\n" + e.ToString());
            }

        }

        public class DuelCheckEvent : Event
        {
            private static DuelCheckEvent Instance = new DuelCheckEvent();

            //public AuctionNotifyEvent() : base(TimeSpan.FromSeconds(1.0), TimeSpan.FromSeconds(60.0))
            public DuelCheckEvent() : base(TimeSpan.FromSeconds(1.0), TimeSpan.FromSeconds(1.0))
            {
                Priority = TimerPriority.OneSecond;
                ExecPriority = ExecutionPriority.QSeparate;
            }

            protected override void OnTick()
            {
                foreach (DuelHandler dhandler in m_pDuels)
                {
                    // Player disconnected
                    if (dhandler.Player1 == null || dhandler.Player1.IsDisposed || dhandler.Player1.BackLink == null ||
                        dhandler.Player2 == null || dhandler.Player2.IsDisposed || dhandler.Player2.BackLink == null)
                    {
                        SendComplete(dhandler.Player1, dhandler.Player2);
                        toRemove.Add(dhandler);
                    }

                    if (!dhandler.IsDuelStart && toRemove.Count == 0 )
                        continue;
                    

                    // check for dist , if someone leave the area - he loose
                    if ( !toRemove.Contains(dhandler) && !dhandler.InBounds(dhandler.Player1) && dhandler.Player1OutboundTime == 0 )
                    {                                                                                                         
                        ShortPacket pckg = new ShortPacket(SMSG.DUEL_OUTOFBOUNDS);
                        pckg.Write(dhandler.Player1.GUID);
                        dhandler.Player1.BackLink.Client.Send(pckg);
                        dhandler.Player1OutboundTime ++;
                    }

                    if ( !toRemove.Contains(dhandler) && !dhandler.InBounds(dhandler.Player2) && dhandler.Player2OutboundTime == 0)
                    {
                        ShortPacket pckg = new ShortPacket(SMSG.DUEL_OUTOFBOUNDS);
                        pckg.Write(dhandler.Player2.GUID);
                        dhandler.Player2.BackLink.Client.Send(pckg);
                        dhandler.Player2OutboundTime++;
                    }


                    if ( !toRemove.Contains(dhandler) && dhandler.Player1OutboundTime != 0)
                    {
                        // player returns to zone
                        if (dhandler.InBounds(dhandler.Player1))
                        {
                            ShortPacket pckg = new ShortPacket(SMSG.DUEL_INBOUNDS);
                            pckg.Write(dhandler.Player1.GUID);
                            dhandler.Player1.BackLink.Client.Send(pckg);
                            dhandler.Player1OutboundTime = 0;
                        }
                        else if ( dhandler.Player1OutboundTime >= 10 )
                        {
                            SendWinner(dhandler.Player2, dhandler.Player1);
                            SendComplete(dhandler.Player1, dhandler.Player2);
                            toRemove.Add(dhandler);
                        } else
                            dhandler.Player1OutboundTime++;
                    }


                    if (!toRemove.Contains(dhandler) && dhandler.Player2OutboundTime != 0 )
                    {
                        // player returns to zone
                        if (dhandler.InBounds(dhandler.Player2))
                        {
                            ShortPacket pckg = new ShortPacket(SMSG.DUEL_INBOUNDS);
                            pckg.Write(dhandler.Player2.GUID);
                            dhandler.Player2.BackLink.Client.Send(pckg);
                            dhandler.Player2OutboundTime = 0;
                        }
                        else if (dhandler.Player2OutboundTime >= 10)
                        {
                            SendWinner(dhandler.Player1, dhandler.Player2);
                            SendComplete(dhandler.Player1,dhandler.Player2);
                            toRemove.Add(dhandler);
                        }
                        else
                            dhandler.Player2OutboundTime++;
                    }

                    if (!toRemove.Contains(dhandler))
                    {
                        // if player death or close to death
                        PlayerObject winner = dhandler.Player1.Health <= 1 ? dhandler.Player2 : dhandler.Player2.Health <= 1 ? dhandler.Player1 : null;
                        if (winner != null)
                        {
                            SendWinner(dhandler.Player1.Health <= 1?dhandler.Player2:dhandler.Player1, dhandler.Player1.Health <= 1?dhandler.Player1:dhandler.Player2);
                            SendComplete(dhandler.Player1, dhandler.Player2);
                            toRemove.Add(dhandler);
                        }
                    }
                }

                foreach (DuelHandler dRemove in toRemove)
                {
                    if (dRemove != null && dRemove.ArbiterObject != null)
                    {
                        m_pDuels.Remove(dRemove);
                        m_pDuelsTable.Remove(dRemove.ArbiterObject.GUID);
                        dRemove.Destroy();
                    } else
                    {
                        LogConsole.WriteLine(LogLevel.ERROR, "DuelCheckEvent:OnTick: Duel Arbiter is NULL" + dRemove);
                    }
                }

                toRemove.Clear();
            }

            [InitializeHandler(InitPass.Third)]
            public static void Initialize()
            {
                Instance.Start();
            }

            public static void DoFinalize()
            {
                if (Instance != null)
                    Instance.Finish();
            }

            private void SendComplete(PlayerObject player1, PlayerObject player2)
            {
                ShortPacket pckg = new ShortPacket(SMSG.DUEL_COMPLETE);
                pckg.Write((byte)0);
                if (player1 != null && !player1.IsDisposed && player1.BackLink != null)
                    player1.BackLink.Client.Send(pckg);

                pckg = new ShortPacket(SMSG.DUEL_COMPLETE);
                pckg.Write((byte)0);
                if (player2 != null && !player2.IsDisposed && player2.BackLink != null)
                    player2.BackLink.Client.Send(pckg);
            }

            private void SendWinner(PlayerObject win,PlayerObject lose)
            {
                ShortPacket pckg = new ShortPacket(SMSG.DUEL_WINNER);
                pckg.Write((byte)0);
                pckg.Write(win.Name);
                pckg.Write(lose.Name);
                win.MapTile.SendSurrounding(pckg, win);
            }

        }

        internal static bool IsDueling( PlayerObject player)
        {
            foreach (DuelHandler dhandler in m_pDuels)
            {
                if (dhandler.Player1.Equals(player) || dhandler.Player2.Equals(player))
                {
                    return true;
                }
            }
            return false;
        }
    }

    class DuelHandler
    {
		bool m_isDuelStart = false;
        PlayerObject m_player1;
        PlayerObject m_player2;
        GameObject m_duelFlag;
        int m_secInOut1 = 0;
        int m_secInOut2 = 0;
		int m_p1StoredFlags = 0;
		int m_p2StoredFlags = 0;



		public bool IsDuelStart
        {
            get { return m_isDuelStart; }
			set { m_isDuelStart = value; }
        }

        public int Player1OutboundTime
        {
            get { return m_secInOut1; }
            set { m_secInOut1 = value; }
        }

        public int Player2OutboundTime
        {
            get { return m_secInOut2; }
            set { m_secInOut2 = value; }
        }

        public PlayerObject Player1
        {
            get { return m_player1; }
        }

        public PlayerObject Player2
        {
            get { return m_player2; }
        }

        public GameObject ArbiterObject
        {
            get { return m_duelFlag; }
        }

        public DuelHandler(PlayerObject p1, PlayerObject p2, GameObject go)
        {
            m_player1 = p1;
            m_player2 = p2;
            m_duelFlag = go;
            
        }

        public void StartDuel()
        {
            IsDuelStart = true;

            m_player1.DuelArbiter = m_duelFlag.GUID;
            m_player2.DuelArbiter = m_duelFlag.GUID;
            m_player1.DuelTeam = 1;
            m_player2.DuelTeam = 2;

            // ?: if player have other flags then duel team is not work correctly
			//m_player1.PvP = true;
			//m_player2.PvP = true;
			m_p1StoredFlags = m_player1.Flags;
			m_p2StoredFlags = m_player2.Flags;
            m_player1.Flags = 0x1008;
			m_player2.Flags = 0x1008;

			//m_player1.BackLink.Client.Send(new CompressedA9Packet(m_player2.SingleFieldPacket((int)UNITFIELDS.DYNAMIC_FLAGS)));
			//m_player2.BackLink.Client.Send(new CompressedA9Packet(m_player1.SingleFieldPacket((int)UNITFIELDS.DYNAMIC_FLAGS)));

			//m_player1.Faction = (FACTION)168;
			//m_player1.StartCombat(m_player2);

			m_player1.UpdateData();
			m_player2.UpdateData();
            
            
            //m_player1.PvP = true;
            //m_player2.PvP = true;
            //m_player1.Flags = 4096;  
            //m_player2.Flags = 4096;
            
			//m_player1.Faction = (FACTION)1621; // set enemy  flag for duel first team
			//m_player2.Faction = (FACTION)1622; // set enemy  flag for duel second team
            
            //m_player1.UpdateData();
            //m_player2.UpdateData();
        }
        internal bool InBounds( PlayerObject player)
        {
            return player.Position.Distance(ArbiterObject.Position) <= Duel.MAX_DUEL_DISTANCE;
        }


        internal void Destroy()
        {
            
            ShortPacket panim = new ShortPacket(SMSG.GAMEOBJECT_DESPAWN_ANIM);
            panim.Write(m_duelFlag.GUID);
            m_duelFlag.MapTile.SendSurrounding(panim, m_player1);


            if (IsDuelStart)
            {
                if (m_player1 != null && !m_player1.IsDisposed && m_player1.BackLink != null)
                {
                    //m_player1.PvP = false;
					m_player1.Flags = m_p1StoredFlags;
                    
                    BaseRace pRace = Races.Instance[m_player1.Character.Race];
                    pRace.FixFaction(m_player1.Character);
                    m_player1.Faction = m_player1.Character.Faction;

                    m_player1.DuelArbiter = 0;
                    m_player1.DuelTeam = 0;

                    if (m_player1.Dead)
                    {
                        m_player1.Dead = false;
                        m_player1.Health = m_player1.MaxHealth / 10;
                    }
                    m_player1.StopCombat();
                    
                    m_player1.UpdateData();
                    DBManager.SaveDBObject(m_player1.Character);
                }


                if (m_player2 != null && !m_player2.IsDisposed && m_player2.BackLink != null)
                {
                    //m_player2.PvP = false;
                    //m_player2.Flags = 0;
					m_player2.Flags = m_p2StoredFlags;
                    BaseRace pRace = Races.Instance[m_player2.Character.Race];
                    pRace.FixFaction(m_player2.Character);
                    m_player2.Faction = m_player2.Character.Faction;
                    
                    m_player2.DuelArbiter = 0;
                    m_player2.DuelTeam = 0;

                    if (m_player2.Dead)
                    {
                        m_player2.Dead = false;
                        m_player2.Health = m_player2.MaxHealth / 10;
                    }
					m_player2.StopCombat();
                    
                    m_player2.UpdateData();
                    DBManager.SaveDBObject(m_player2.Character);
                    
                }
            }


            m_duelFlag.Dispose();
            m_duelFlag = null;
            m_player1 = null;
            m_player2 = null;
        }
    }
}
