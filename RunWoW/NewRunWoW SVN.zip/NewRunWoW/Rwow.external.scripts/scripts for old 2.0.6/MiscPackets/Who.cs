using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class Who
	{
		[PacketHandler(CMSG.WHO)]
		public static void SendWhoList(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			ShortPacket pkg = new ShortPacket(SMSG.WHO);
			PooledList<PlayerObject> allPlayers = ClientManager.GetPlayerList();

			CustomArrayList players = new CustomArrayList();
			foreach(PlayerObject player in allPlayers)
				if (Faction.SameFaction(player.Faction, Client.Player.Faction) && !player.GM && player.Zone == Client.Player.Zone)
					players.Add(player);
			
			int count = players.Count;
			if (count >= 50)
				count = 50;
			
			pkg.Write(count);
			pkg.Write(players.Count);


			for (int i = 0; i < count; i++)
			{
				PlayerObject player = (PlayerObject)players[i];

				pkg.Write(player.Name);

				if (player.Character.Guild != null)
					pkg.Write(player.Character.Guild.Name);
				else
					pkg.Write(string.Empty);
				pkg.Write((int)player.Level);
				pkg.Write((int)player.Class);
				pkg.Write((int)player.Race);
				pkg.Write((int)(player.Area!=null ? player.Area.ObjectId : player.Zone));
			}
			client.Send(pkg);
			Chat.System(client, Constants.Online + (ClientManager.OnlineCount));
			
			players.Dispose();
		}
	}
}