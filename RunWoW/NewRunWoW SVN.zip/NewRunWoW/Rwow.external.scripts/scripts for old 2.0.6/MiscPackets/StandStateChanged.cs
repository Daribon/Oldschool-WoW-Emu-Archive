using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.Objects;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class StandStateChange
	{
		[PacketHandler(CMSG.STANDSTATECHANGE)]
		public static void OnStandStateChange(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			if (Client.Player.MountDisplayID != 0)
				return;
			/*if (Client.Player.Attacking)
			{
				ShortPacket pkg=new ShortPacket(SMSG.STANDSTATE_CHANGE_FAILURE);
				pkg.Write(Client.Player.GUID);
				pkg.Write((byte)0);
				client.Send(pkg);
				return;
			}*/
			UNITSTANDSTATE ss = (UNITSTANDSTATE) data.ReadByte();
			Client.Player.StandState = ss;
			Client.Player.ForceUpdateData();
		}
	}
}