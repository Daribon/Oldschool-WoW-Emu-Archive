using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;

namespace RunWoW.ExternalScripts.MiscPackets
{
#if BURNING_CRUSADE
    [PacketHandlerClass()]
    public class ReputationFaction
    {
		[PacketHandler((CMSG)792)]
		public static void OnWatchedFaction(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData)client.Data;
			if (Client == null || Client.Player == null)
				return;

			uint faction = data.ReadUInt32();
			//System.Console.WriteLine("Setting wf to " + faction);
			Client.Player.WatchedFaction = faction;
			Client.Player.ForceUpdateData();
		}
    }
#endif
}
