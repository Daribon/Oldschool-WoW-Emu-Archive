using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class PvP
	{
		[PacketHandler(CMSG.ENABLE_PVP)]
		public static void HandleEnablePvP(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;
			Client.Player.PvP = true;
			Client.Player.UpdateData();
		}

		/*[PacketHandler(CMSG.DISABLE_PVP)]
		static void HandleDisablePvP(ClientBase client, BinReader data)
		{
			ClientData Client=(ClientData)client.Data;
			if (Client==null||Client.Player==null)
				return;
			Client.Player.PvP=false;
			Client.Player.UpdateData();
		}*/
	}
}