using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class SetAmmo
	{
		[PacketHandler(CMSG.SET_AMMO)]
		private static void OnSetAmmo(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null)
				return;
			//Hexdump.ToConsole(data);
			Client.Player.LookSetAmmo(data.ReadInt32());
			Client.Player.UpdateData();
		}
	}
}