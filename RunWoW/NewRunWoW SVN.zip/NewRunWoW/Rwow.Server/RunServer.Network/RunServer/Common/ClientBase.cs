//
namespace RunServer.Common
{
    using RunServer.Network;
    using System;
    using System.Collections;
    using System.Net.Sockets;
    using System.Runtime.CompilerServices;
    using System.Threading;

    public abstract class ClientBase : NetworkClient
    {
        private volatile bool m_authenticated;
        private object[] m_data;
        private volatile bool m_firstPacket;
        protected int m_headerSize;
        private byte[] m_lastHeader;
        private int m_lastSize;
        protected BufferQueue m_packetReceiveQueue;
        protected BufferQueue m_packetSendQueue;
        private volatile object m_readLock;

        public ClientBase(Socket sock, ServerBase parent, bool useData) : this(sock, 4, parent, useData)
        {
        }

        public ClientBase(Socket sock, int headerSize, ServerBase parent, bool extData) : base(sock, parent, BufferPool.Instance.AquireBuffer(Utility.ReceiveBufferSize))
        {
            this.m_firstPacket = true;
            this.m_readLock = new object();
            this.m_headerSize = headerSize;
            this.m_packetSendQueue = new BufferQueue();
            this.m_packetReceiveQueue = new BufferQueue();
            this.m_data = new object[extData ? 1 : 5];
            this.m_lastHeader = new byte[this.m_headerSize];
        }

        public override void Close()
        {
            BufferPool.Instance.ReleaseBuffer(base.ReceiveBuffer);
            base.Close();
        }

        public override void DataSent(byte[] buffer, int bytes)
        {
            base.DataSent(buffer, bytes);
            BufferPool.Instance.ReleaseBuffer(buffer);
        }

        public override void EnqueueIncomingData(int length)
        {
            this.m_packetReceiveQueue.Enqueue(new HeapBuffer(base.ReceiveBuffer, 0, length), length);
            base.GotActivity();
        }

        public abstract void EnqueueIncomingPacket(BinReader data);
        private void EnqueueOutgoingData(byte[] buffer, int length)
        {
            if ((!base.Closed && (buffer != null)) && (length >= 1))
            {
                this.m_packetSendQueue.Enqueue(new HeapBuffer(buffer, 0, length), length);
            }
        }

        private void EnqueueOutgoingData(HeapBuffer buffer, int length)
        {
            if (!buffer.Disposed && (buffer.Length != 0))
            {
                if (base.Closed || (length == 0))
                {
                    buffer.Dispose();
                }
                else
                {
                    this.m_packetSendQueue.Enqueue(buffer, length);
                }
            }
        }

        public unsafe bool FlushReceive()
        {
            if (base.Closed)
            {
                return true;
            }
            if (!base.Parent.AsyncReceive && !base.Parent.RequestData(this))
            {
                return true;
            }
            if (((this.EncodedLength != 0) && !this.m_firstPacket) && !this.m_authenticated)
            {
                return true;
            }
        Label_0045:
            if (base.Closed)
            {
                return true;
            }
            if (this.m_lastSize == 0)
            {
                if (!this.m_packetReceiveQueue.Dequeue(this.m_lastHeader, this.m_headerSize))
                {
                    goto Label_0151;
                }
                this.m_lastSize = this.PacketSize(this.m_lastHeader);
                if (this.m_lastSize == -1)
                {
                    return false;
                }
            }
            if (this.m_packetReceiveQueue.Length >= (this.m_lastSize - this.m_headerSize))
            {
                byte* data = stackalloc byte[(1 * (this.m_lastSize - this.m_headerSize))];
                if (this.m_packetReceiveQueue.Dequeue(data, this.m_lastSize - this.m_headerSize))
                {
                    HeapBuffer heapBuffer = new HeapBuffer(this.m_lastSize);
                    heapBuffer.WriteData(this.m_lastHeader, 0, this.m_headerSize, 0);
                    heapBuffer.WriteData(data, 0, this.m_lastSize - this.m_headerSize, this.m_headerSize);
                    this.EnqueueIncomingPacket(new HeapBinReader(heapBuffer, this.m_lastSize));
                    this.m_lastSize = 0;
                    if (!this.m_firstPacket)
                    {
                        goto Label_0045;
                    }
                    this.m_firstPacket = false;
                    if (this.EncodedLength == 0)
                    {
                        goto Label_0045;
                    }
                    return true;
                }
            }
        Label_0151:
            return true;
        }

        public override void FlushSend()
        {
            if (Interlocked.CompareExchange(ref this.Sending, 1, 0) == 0)
            {
                int minSize = this.m_packetSendQueue.Length;
                if (minSize == 0)
                {
                    base.Sending = 0;
                }
                else
                {
                    if (minSize > Utility.SendBufferSize)
                    {
                        minSize = Utility.SendBufferSize;
                    }
                    byte[] data = BufferPool.Instance.AquireBuffer(minSize);
                    if (!this.m_packetSendQueue.Dequeue(data, minSize))
                    {
                        BufferPool.Instance.ReleaseBuffer(data);
                        base.Sending = 0;
                    }
                    else
                    {
                        base.Parent.SendData(this, data, 0, minSize, true);
                    }
                }
            }
        }

        public virtual int PacketSize(byte[] header)
        {
            int num = BitConverter.ToInt32(header, 0);
            if ((num <= 0xffff) && (num >= 0))
            {
                return (num + header.Length);
            }
            return -1;
        }

        public abstract void ProcessPacket(BinReader data);
        public void Send(byte[] data)
        {
            this.EnqueueOutgoingData(data, data.Length);
        }

        public virtual void Send(IPacket packet)
        {
            throw new Exception("Don't know how to send packet of type " + packet.GetType().Name);
        }

        public void Send(ICollection packets)
        {
            if ((packets != null) && (packets.Count != 0))
            {
                foreach (IPacket packet in packets)
                {
                    this.Send(packet);
                }
            }
        }

        public void Send(HeapBuffer buffer, int length)
        {
            this.EnqueueOutgoingData(buffer, length);
        }

        public void Send(byte[] data, int size)
        {
            this.EnqueueOutgoingData(data, size);
        }

        public bool Authenticated
        {
            get
            {
                return this.m_authenticated;
            }
            set
            {
                this.m_authenticated = value;
            }
        }

        public object Data
        {
            get
            {
                return this.m_data[0];
            }
            set
            {
                this.m_data[0] = value;
            }
        }

        public object[] DataArray
        {
            get
            {
                return this.m_data;
            }
            set
            {
                this.m_data = value;
            }
        }

        protected virtual int EncodedLength
        {
            get
            {
                return 0;
            }
        }

        public bool FirstPacket
        {
            get
            {
                return this.m_firstPacket;
            }
            set
            {
                this.m_firstPacket = value;
            }
        }

        public int SendLength
        {
            get
            {
                return this.m_packetSendQueue.Length;
            }
        }
    }
}

