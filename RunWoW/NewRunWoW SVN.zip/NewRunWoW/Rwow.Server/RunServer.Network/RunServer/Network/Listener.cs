﻿namespace RunServer.Network
{
    using RunServer.Common;
    using System;
    using System.Collections;
    using System.Net;
    using System.Net.Sockets;

    public class Listener : IDisposable
    {
        private System.Collections.Queue m_accepted;
        private bool m_Disposed = false;
        private static System.Net.Sockets.Socket[] m_EmptySockets = new System.Net.Sockets.Socket[0];
        private System.Net.Sockets.Socket m_listener;
        private AsyncCallback m_OnAccept;
        private int m_ThisPort;

        public Listener()
        {
            this.m_OnAccept = new AsyncCallback(this.OnAccept);
            this.m_accepted = System.Collections.Queue.Synchronized(new System.Collections.Queue());
        }

        private System.Net.Sockets.Socket Bind(IPAddress ip, int port)
        {
            IPEndPoint localEP = new IPEndPoint(ip, port);
            System.Net.Sockets.Socket state = new System.Net.Sockets.Socket(AddressFamily.InterNetwork, SocketType.Stream, ProtocolType.Tcp);
            try
            {
                state.Bind(localEP);
                state.Listen(500);
                state.BeginAccept(this.m_OnAccept, state);
                return state;
            }
            catch
            {
                try
                {
                    state.Shutdown(SocketShutdown.Both);
                    state.Close();
                }
                catch (SocketException)
                {
                }
                return null;
            }
        }

        public void Dispose()
        {
            if (!this.m_Disposed)
            {
                this.m_Disposed = true;
                if (this.m_listener != null)
                {
                    try
                    {
                        this.m_listener.Shutdown(SocketShutdown.Both);
                        this.m_listener.Close();
                    }
                    catch (SocketException)
                    {
                    }
                    this.m_listener = null;
                }
            }
        }

        public void Listen(int port)
        {
            this.m_ThisPort = port;
            this.m_listener = this.Bind(IPAddress.Any, port);
            try
            {
                IPHostEntry hostEntry = Dns.GetHostEntry(Dns.GetHostName());
                ArrayList list = new ArrayList();
                list.Add(IPAddress.Loopback);
                Console.WriteLine("Address: {0}:{1}", IPAddress.Loopback, port);
                IPAddress[] addressList = hostEntry.AddressList;
                for (int i = 0; i < addressList.Length; i++)
                {
                    if (!list.Contains(addressList[i]))
                    {
                        list.Add(addressList[i]);
                        Console.WriteLine("Address: {0}:{1}", addressList[i], port);
                    }
                }
            }
            catch (Exception)
            {
                this.Dispose();
                throw;
            }
        }

        private void OnAccept(IAsyncResult asyncResult)
        {
            if (this.m_listener != null)
            {
                ThreadHelper.RegisterName("Accept Callback");
                try
                {
                    System.Net.Sockets.Socket socket = this.m_listener.EndAccept(asyncResult);
                    SetSocketOptions(socket);
                    this.m_accepted.Enqueue(socket);
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Exception while accepting socket: " + exception);
                }
                if (this.m_listener != null)
                {
                    this.m_listener.BeginAccept(this.m_OnAccept, this.m_listener);
                }
            }
        }

        private static void SetSocketOptions(System.Net.Sockets.Socket socket)
        {
            socket.NoDelay = !Utility.UseNagle;
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveBuffer, Utility.ReceiveBufferSize);
            socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendBuffer, Utility.SendBufferSize);
            if (Utility.SendTimeout > 0)
            {
                socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.SendTimeout, Utility.SendTimeout);
            }
            if (Utility.ReceiveTimeout > 0)
            {
                socket.SetSocketOption(SocketOptionLevel.Socket, SocketOptionName.ReceiveTimeout, Utility.ReceiveTimeout);
            }
        }

        public object[] Slice()
        {
            int count = this.m_accepted.Count;
            if (count == 0)
            {
                return m_EmptySockets;
            }
            object[] objArray = new object[count];
            for (int i = 0; i < count; i++)
            {
                objArray[i] = this.m_accepted.Dequeue();
            }
            return objArray;
        }

        public IPEndPoint LocalEndPoint
        {
            get
            {
                return (IPEndPoint) this.m_listener.LocalEndPoint;
            }
        }

        public System.Net.Sockets.Socket Socket
        {
            get
            {
                return this.m_listener;
            }
        }

        public int UsedPort
        {
            get
            {
                return this.m_ThisPort;
            }
        }
    }
}

