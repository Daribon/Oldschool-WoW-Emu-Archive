//
namespace RunServer.Network
{
    using RunServer.Common;
    using System;
    using System.Collections;
    using System.Net;
    using System.Net.Sockets;
    using System.Runtime.CompilerServices;

    public abstract class NetworkServer
    {
        private bool m_asyncReceive = true;
        protected NetworkClient[] m_clients = new NetworkClient[0x800];
        private System.Collections.Queue m_disposed = System.Collections.Queue.Synchronized(new System.Collections.Queue());
        private RunServer.Network.Listener m_listener;
        private AsyncCallback m_OnReceive;
        private AsyncCallback m_OnSend;
        private System.Collections.Queue m_received = System.Collections.Queue.Synchronized(new System.Collections.Queue());
        public static volatile int ReceiveCalled;
        public static volatile int SendCalled;

        public NetworkServer()
        {
            this.m_OnReceive = new AsyncCallback(this.OnClientReceive);
            this.m_OnSend = new AsyncCallback(this.OnClientSend);
            this.m_listener = new RunServer.Network.Listener();
        }

        public void AsyncSend(object state)
        {
            AsyncSendParams AsyncpParams = (AsyncSendParams) state;
            try
            {
                int bytes = AsyncpParams.Client.Socket.Send(AsyncpParams.Buffer, AsyncpParams.Offset, AsyncpParams.Length, SocketFlags.Partial);
                AsyncpParams.Client.DataSent(AsyncpParams.Buffer, bytes);
            }
            catch (SocketException exception)
            {
                this.OnClientException(AsyncpParams.Client, exception);
            }
            AsyncpParams.Client.Sending = 0;
        }

        private void ClientCheck(NetworkClient client, object param)
        {
            if (!client.Closed && (((client.Socket == null) || !client.Socket.Connected) || client.Idle))
            {
                this.OnClientException(client, new Exception("Client clean up"));
            }
        }

        private void Close(NetworkClient client)
        {
            if (client.Closing)
            {
                client.Closed = true;
                client.Close();
                try
                {
                    client.Socket.Shutdown(SocketShutdown.Both);
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Exception while socket shutdown: " + exception);
                }
                try
                {
                    client.Socket.Close();
                }
                catch (Exception exception2)
                {
                    Console.WriteLine("Exception while socket closing: " + exception2);
                }
                this.OnClientDropped(client);
            }
        }

        protected abstract NetworkClient CreateClient(Socket socket);
        protected void Enumerate(ClientOperationDelegate Operation, object param)
        {
            for (int i = 0; i < this.m_clients.Length; i++)
            {
                if (this.m_clients[i] != null)
                {
                    Operation(this.m_clients[i], param);
                }
            }
        }

        protected virtual void OnClientDropped(NetworkClient client)
        {
            if ((client != null) && (client.ID != -1))
            {
                this.m_clients[client.ID] = null;
            }
        }

        public void OnClientException(NetworkClient client, Exception e)
        {
            if ((client != null) && !client.Closed)
            {
                client.Closing = true;
                Console.WriteLine("Client {0} exception {1}", client.RemoteEndPoint, e.Message);
                this.m_disposed.Enqueue(client);
            }
        }

        protected void OnClientReceive(IAsyncResult asyncResult)
        {
            ThreadHelper.RegisterName("Receive Callback");
            this.ProcessReceive(asyncResult);
        }

        protected void OnClientSend(IAsyncResult asyncResult)
        {
            ThreadHelper.RegisterName("Send Callback");
            AsyncSendParams asyncState = (AsyncSendParams) asyncResult.AsyncState;
            asyncState.Client.Sending = 0;
            try
            {
                int bytes = asyncState.Client.Socket.EndSend(asyncResult);
                asyncState.Client.DataSent(asyncState.Buffer, bytes);
                if (!asyncState.Client.Closed && (bytes <= 0))
                {
                    throw new Exception("Disconnected while sending");
                }
            }
            catch (SocketException exception)
            {
                this.OnClientException(asyncState.Client, exception);
            }
            catch (Exception exception2)
            {
                this.OnClientException(asyncState.Client, exception2);
            }
        }

        private void ProcessReceive(IAsyncResult asyncResult)
        {
            NetworkClient asyncState = (NetworkClient) asyncResult.AsyncState;
            try
            {
                SocketError errorCode;
                int length = asyncState.Socket.EndReceive(asyncResult, out errorCode);
                if (asyncState.Closed)
                {
                    return;
                }
                if (length <= 0)
                {
                    throw new Exception("Disconnected while receiving, code " + errorCode);
                }
                asyncState.EnqueueIncomingData(length);
            }
            catch (Exception exception)
            {
                this.OnClientException(asyncState, exception);
                return;
            }
            this.RequestData(asyncState);
        }

        public bool RequestData(NetworkClient client)
        {
            if (client.Closed)
            {
                return false;
            }
            try
            {
                if (this.m_asyncReceive)
                {
                    client.Socket.BeginReceive(client.ReceiveBuffer, 0, client.ReceiveBuffer.Length, SocketFlags.None, this.m_OnReceive, client);
                }
                else
                {
                    int size = client.Socket.Available;
                    if (size == 0)
                    {
                        return true;
                    }
                    if (size > client.ReceiveBuffer.Length)
                    {
                        size = client.ReceiveBuffer.Length;
                    }
                    size = client.Socket.Receive(client.ReceiveBuffer, 0, size, SocketFlags.None);
                    client.EnqueueIncomingData(size);
                }
                return true;
            }
            catch (Exception exception)
            {
                this.OnClientException(client, exception);
                return false;
            }
        }

        public void SendData(NetworkClient client, byte[] buffer, int offset, int length, bool async)
        {
            if (!client.Closed && (length != 0))
            {
                AsyncSendParams state = new AsyncSendParams(client, buffer, offset, length);
                try
                {
                    client.Socket.BeginSend(state.Buffer, state.Offset, state.Length, SocketFlags.None, this.m_OnSend, state);
                }
                catch (SocketException exception)
                {
                    this.OnClientException(client, exception);
                }
            }
        }

        public bool SliceAccepted()
        {
            object[] objArray = this.m_listener.Slice();
            for (int i = 0; i < objArray.Length; i++)
            {
                NetworkClient client = this.CreateClient((Socket) objArray[i]);
                if (client != null)
                {
                    for (int j = 0; j < this.m_clients.Length; j++)
                    {
                        if (this.m_clients[j] == null)
                        {
                            this.m_clients[j] = client;
                            client.ID = j;
                            break;
                        }
                    }
                    this.RequestData(client);
                }
            }
            return true;
        }

        public bool SliceDisposed()
        {
            this.Enumerate(new ClientOperationDelegate(this.ClientCheck), null);
            int count = this.m_disposed.Count;
            if (count != 0)
            {
                while (count > 0)
                {
                    NetworkClient client = (NetworkClient) this.m_disposed.Dequeue();
                    this.Close(client);
                    count--;
                }
                return true;
            }
            return false;
        }

        public void SliceReceived()
        {
            int count = this.m_received.Count;
            if (count != 0)
            {
                while (count-- > 0)
                {
                    IAsyncResult asyncResult = (IAsyncResult) this.m_received.Dequeue();
                    this.ProcessReceive(asyncResult);
                }
            }
        }

        public virtual void Start(int port)
        {
            this.m_listener.Listen(port);
        }

        public virtual void Stop()
        {
            this.Enumerate(new ClientOperationDelegate(NetworkServer.Terminate), null);
            this.m_listener.Dispose();
        }

        private static void Terminate(NetworkClient client, object param)
        {
            if (((client != null) && client.Closed) && (client.Socket != null))
            {
                try
                {
                    client.Socket.Shutdown(SocketShutdown.Both);
                }
                catch (Exception exception)
                {
                    Console.WriteLine("Exception while socket shutdown: " + exception);
                }
                try
                {
                    client.Socket.Close();
                }
                catch (Exception exception2)
                {
                    Console.WriteLine("Exception while socket closing: " + exception2);
                }
            }
        }

        public bool AsyncReceive
        {
            get
            {
                return this.m_asyncReceive;
            }
            protected set
            {
                this.m_asyncReceive = value;
            }
        }

        public RunServer.Network.Listener Listener
        {
            get
            {
                return this.m_listener;
            }
        }

        public IPEndPoint LocalEndPoint
        {
            get
            {
                return this.m_listener.LocalEndPoint;
            }
        }

        public class AsyncSendParams
        {
            private byte[] m_buffer;
            private NetworkClient m_client;
            private int m_length;
            private int m_offset;

            public AsyncSendParams(NetworkClient client, byte[] buffer, int offset, int length)
            {
                this.m_client = client;
                this.m_buffer = buffer;
                this.m_offset = offset;
                this.m_length = length;
            }

            public byte[] Buffer
            {
                get
                {
                    return this.m_buffer;
                }
            }

            public NetworkClient Client
            {
                get
                {
                    return this.m_client;
                }
            }

            public int Length
            {
                get
                {
                    return this.m_length;
                }
            }

            public int Offset
            {
                get
                {
                    return this.m_offset;
                }
            }
        }
    }
}

