﻿namespace RunServer.Network
{
    using System;

    public enum CloseState : byte
    {
        Closed = 2,
        Closing = 1,
        None = 0
    }
}

