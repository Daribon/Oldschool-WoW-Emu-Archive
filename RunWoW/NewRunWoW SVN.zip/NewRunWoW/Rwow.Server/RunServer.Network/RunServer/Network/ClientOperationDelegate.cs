﻿namespace RunServer.Network
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void ClientOperationDelegate(NetworkClient client, object param);
}

