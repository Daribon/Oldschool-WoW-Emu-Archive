﻿namespace RunServer.Common
{
    using System;
    using System.Collections.Generic;

    internal class PacketStatCompararer : IComparer<Statistics.PacketStat>
    {
        public int Compare(Statistics.PacketStat x, Statistics.PacketStat y)
        {
            return Comparer<double>.Default.Compare(x.AverageValue, y.AverageValue);
        }
    }
}

