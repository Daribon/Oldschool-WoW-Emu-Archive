﻿namespace RunServer.Common
{
    using System;

    public class GenericItemPool<T>
    {
        private int m_initialCapacity;
        private FastLockQueue<T> m_items;
        private int m_maximumCapacity;

        public GenericItemPool(int initialCapacity, int maximumCapacity)
        {
            this.m_initialCapacity = initialCapacity;
            this.m_maximumCapacity = maximumCapacity;
            this.m_items = new FastLockQueue<T>();
        }

        public T AquireItem()
        {
            if (this.m_items.Count == 0)
            {
                for (int i = 0; i < this.m_initialCapacity; i++)
                {
                    this.m_items.Enqueue(this.constructItem());
                }
            }
            T local = this.m_items.Dequeue();
            if (local == null)
            {
                return this.constructItem();
            }
            return local;
        }

        protected virtual void cleanItem(T item)
        {
        }

        protected virtual T constructItem()
        {
            return (T) Activator.CreateInstance(typeof(T));
        }

        protected virtual void destroyItem(T item)
        {
        }

        public void ReleaseItem(T item)
        {
            if (item != null)
            {
                if (this.m_items.Count < this.m_maximumCapacity)
                {
                    this.cleanItem(item);
                    this.m_items.Enqueue(item);
                }
                else
                {
                    this.destroyItem(item);
                }
            }
        }
    }
}

