﻿namespace RunServer.Common
{
    using System;

    internal class LinkedArray<T>
    {
        public T[] Data;
        public LinkedArray<T> Next;

        public LinkedArray() : this(10, null)
        {
        }

        public LinkedArray(int initialSize) : this(initialSize, null)
        {
        }

        public LinkedArray(int initialSize, LinkedArray<T> next)
        {
            this.Data = new T[initialSize];
            this.Next = next;
        }
    }
}

