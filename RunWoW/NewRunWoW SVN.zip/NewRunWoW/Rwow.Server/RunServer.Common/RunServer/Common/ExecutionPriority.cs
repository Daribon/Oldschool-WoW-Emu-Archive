//
namespace RunServer.Common
{
    using System;

    public enum ExecutionPriority
    {
        Max = 11,
        None = -1,
        Packet = 1,
        Pool = 2,
        QCritical = 5,
        QCriticalSecond = 11,
        QPrimary = 0,
        QSeparate = 3,
        QSeparateSecond = 4
    }
}

