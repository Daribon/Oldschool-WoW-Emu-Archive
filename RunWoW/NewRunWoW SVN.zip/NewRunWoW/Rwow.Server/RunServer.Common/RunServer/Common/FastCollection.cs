﻿namespace RunServer.Common
{
    using System;
    using System.Collections;
    using System.Reflection;
    using System.Runtime.CompilerServices;

    public class FastCollection<T> : IEnumerable where T: IGuidable
    {
        public T[] InnerArray;
        private int m_count;
        private int m_last;
        private SimpleSpinLock m_lock;
        private static T[] s_emptyArray;
        private static GenericPool<T> s_pool;

        static FastCollection()
        {
            FastCollection<T>.s_pool = new GenericPool<T>(5, 0x3e8, 20);
            FastCollection<T>.s_emptyArray = new T[0];
        }

        public FastCollection() : this(0)
        {
        }

        public FastCollection(int count)
        {
            if (count > 0)
            {
                this.InnerArray = FastCollection<T>.s_pool.AquireBuffer(count);
            }
            else
            {
                this.InnerArray = FastCollection<T>.s_emptyArray;
            }
            this.m_lock = new SimpleSpinLock();
        }

        public void Add(T obj)
        {
            this.m_lock.Enter();
            try
            {
                if (this.m_count < this.m_last)
                {
                    for (int i = this.m_last / 2; i < this.m_last; i++)
                    {
                        if (this.InnerArray[i] == null)
                        {
                            this.InnerArray[i] = obj;
                            this.m_count++;
                            return;
                        }
                    }
                }
                this.ensureCapacity(this.m_last + 1);
                this.InnerArray[this.m_last] = obj;
                this.m_count++;
                this.m_last++;
            }
            finally
            {
                this.m_lock.Exit();
            }
        }

        public void Clear()
        {
            if ((this.InnerArray != null) && (this.InnerArray != FastCollection<T>.s_emptyArray))
            {
                FastCollection<T>.s_pool.ReleaseBuffer(this.InnerArray);
                this.InnerArray = null;
            }
            this.InnerArray = FastCollection<T>.s_emptyArray;
        }

        private void ensureCapacity(int length)
        {
            if ((this.InnerArray == null) || (length > this.InnerArray.Length))
            {
                if ((this.InnerArray != null) && (this.InnerArray.Length > 0))
                {
                    T[] sourceArray = this.InnerArray;
                    this.InnerArray = FastCollection<T>.s_pool.AquireBuffer(length);
                    Array.Copy(sourceArray, this.InnerArray, this.m_last);
                    FastCollection<T>.s_pool.ReleaseBuffer(sourceArray);
                }
                else
                {
                    this.InnerArray = FastCollection<T>.s_pool.AquireBuffer(length);
                }
            }
        }

        public void Enumerate(ItemOperation operation)
        {
            this.m_lock.Enter();
            try
            {
                for (int i = 0; i < this.InnerArray.Length; i++)
                {
                    if ((this.InnerArray[i] != null) && !operation(this.InnerArray[i]))
                    {
                        return;
                    }
                }
            }
            finally
            {
                this.m_lock.Exit();
            }
        }

        ~FastCollection()
        {
            if ((this.InnerArray != null) && (this.InnerArray != FastCollection<T>.s_emptyArray))
            {
                FastCollection<T>.s_pool.ReleaseBuffer(this.InnerArray);
                this.InnerArray = null;
            }
        }

        public IEnumerator GetEnumerator()
        {
            return this.InnerArray.GetEnumerator();
        }

        public void Remove(T obj)
        {
            this.m_lock.Enter();
            try
            {
                for (int i = 0; i < this.InnerArray.Length; i++)
                {
                    if ((this.InnerArray[i] != null) && this.InnerArray[i].Equals(obj))
                    {
                        this.InnerArray[i] = default(T);
                        this.m_count--;
                        if (i == (this.m_last - 1))
                        {
                            this.m_last--;
                        }
                        break;
                    }
                }
                if (this.m_count == 0)
                {
                    this.InnerArray = FastCollection<T>.s_emptyArray;
                    this.m_last = 0;
                }
            }
            finally
            {
                this.m_lock.Exit();
            }
        }

        public void Remove(ulong GUID)
        {
            this.m_lock.Enter();
            try
            {
                for (int i = 0; i < this.InnerArray.Length; i++)
                {
                    if ((this.InnerArray[i] != null) && (this.InnerArray[i].GUID == GUID))
                    {
                        this.InnerArray[i] = default(T);
                        this.m_count--;
                        if (i == (this.m_last - 1))
                        {
                            this.m_last--;
                        }
                        break;
                    }
                }
                if (this.m_count == 0)
                {
                    this.InnerArray = FastCollection<T>.s_emptyArray;
                    this.m_last = 0;
                }
            }
            finally
            {
                this.m_lock.Exit();
            }
        }

        public void RemoveAt(int i)
        {
            this.m_lock.Enter();
            try
            {
                if (this.InnerArray[i] != null)
                {
                    this.InnerArray[i] = default(T);
                    this.m_count--;
                }
            }
            finally
            {
                this.m_lock.Exit();
            }
        }

        private static int roundLength(int length)
        {
            return (((length + 0x80) - 1) & -128);
        }

        public int Count
        {
            get
            {
                return this.m_count;
            }
        }

        public T this[ulong GUID]
        {
            get
            {
                T local;
                this.m_lock.Enter();
                try
                {
                    for (int i = this.InnerArray.Length - 1; i >= 0; i--)
                    {
                        if ((this.InnerArray[i] != null) && (this.InnerArray[i].GUID == GUID))
                        {
                            return this.InnerArray[i];
                        }
                    }
                    local = default(T);
                }
                finally
                {
                    this.m_lock.Exit();
                }
                return local;
            }
        }

        public T this[int index]
        {
            get
            {
                return this.InnerArray[index];
            }
            set
            {
                this.InnerArray[index] = value;
            }
        }

        public int Last
        {
            get
            {
                return this.m_last;
            }
        }

        public delegate bool ItemOperation(T item);
    }
}

