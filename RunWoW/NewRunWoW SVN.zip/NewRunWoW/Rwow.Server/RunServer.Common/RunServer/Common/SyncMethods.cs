﻿namespace RunServer.Common
{
    using System;
    using System.Threading;

    public static class SyncMethods
    {
        public static bool CAS<T>(ref T location, T comparand, T newValue) where T: class
        {
            return (comparand == Interlocked.CompareExchange<T>(ref location, newValue, comparand));
        }
    }
}

