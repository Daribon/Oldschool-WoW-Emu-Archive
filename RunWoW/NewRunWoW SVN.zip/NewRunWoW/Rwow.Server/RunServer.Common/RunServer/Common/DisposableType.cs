//
namespace RunServer.Common
{
    using System;
    using System.Threading;

    public abstract class DisposableType : IDisposable
    {
        private long m_releasedFlag;

        protected DisposableType()
        {
        }

        public void Close()
        {
            this.Dispose();
        }

        public void Dispose()
        {
            if (Interlocked.CompareExchange(ref this.m_releasedFlag, (long) 1, (long) 0) == 0)
            {
                GC.SuppressFinalize(this);
                this.Dispose(true);
            }
        }

        protected abstract void Dispose(bool disposing);
        ~DisposableType()
        {
            if (Interlocked.CompareExchange(ref this.m_releasedFlag, (long) 1, (long) 0) == 0)
            {
                this.Dispose(false);
            }
        }

        public bool Disposed
        {
            get
            {
                return (Interlocked.Read(ref this.m_releasedFlag) == 1);
            }
        }
    }
}

