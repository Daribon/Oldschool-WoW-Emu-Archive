//
namespace RunServer.Common
{
    using System;

    public class BufferPool : GenericPool<byte>
    {
        public static int InitialBufferSize = 0x1c8;
        private static int InitialCapacity = 200;
        public static BufferPool Instance = new BufferPool(InitialCapacity, MaximumCapacity, InitialBufferSize);
        private static int MaximumCapacity = 0x1770;

        private BufferPool(int initialCapacity, int maximumCapacity, int initialBufferSize) : base(initialCapacity, maximumCapacity, initialBufferSize)
        {
        }
    }
}

