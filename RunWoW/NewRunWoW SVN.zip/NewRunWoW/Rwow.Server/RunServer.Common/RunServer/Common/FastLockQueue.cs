//
namespace RunServer.Common
{
    using System;
    using System.Threading;

    public class FastLockQueue<T>
    {
        private int m_count;
        private SingleLinkNode<T> m_head;
        private SingleLinkNode<T> m_tail;

        public FastLockQueue()
        {
            this.m_head = new SingleLinkNode<T>();
            this.m_tail = this.m_head;
            this.m_count = 0;
        }

        public T Dequeue()
        {
            T item = default(T);
            bool flag = false;
            while (!flag)
            {
                SingleLinkNode<T> comparand = this.m_head;
                SingleLinkNode<T> tail = this.m_tail;
                SingleLinkNode<T> newValue = comparand.Next;
                if (comparand == this.m_head)
                {
                    if (comparand == tail)
                    {
                        if (newValue == null)
                        {
                            return default(T);
                        }
                        SyncMethods.CAS<SingleLinkNode<T>>(ref this.m_tail, tail, newValue);
                    }
                    else
                    {
                        item = newValue.Item;
                        flag = SyncMethods.CAS<SingleLinkNode<T>>(ref this.m_head, comparand, newValue);
                    }
                }
            }
            if (item != null)
            {
                Interlocked.Decrement(ref this.m_count);
            }
            return item;
        }

        public void Enqueue(T item)
        {
            SingleLinkNode<T> comparand = null;
            SingleLinkNode<T> newValue = null;
            SingleLinkNode<T> node3 = new SingleLinkNode<T>();
            node3.Item = item;
            bool flag = false;
            while (!flag)
            {
                comparand = this.m_tail;
                newValue = comparand.Next;
                if (this.m_tail == comparand)
                {
                    if (newValue == null)
                    {
                        flag = SyncMethods.CAS<SingleLinkNode<T>>(ref this.m_tail.Next, null, node3);
                    }
                    else
                    {
                        SyncMethods.CAS<SingleLinkNode<T>>(ref this.m_tail, comparand, newValue);
                    }
                }
            }
            SyncMethods.CAS<SingleLinkNode<T>>(ref this.m_tail, comparand, node3);
            Interlocked.Increment(ref this.m_count);
        }

        public int Count
        {
            get
            {
                return this.m_count;
            }
        }
    }
}

