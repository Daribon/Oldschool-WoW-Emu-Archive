﻿namespace RunServer.Common
{
    using System;
    using System.Collections.Generic;
    using System.Diagnostics;
    using System.IO;

    public class PerformanceHelper
    {
        public static Dictionary<string, long> PacketTimes = new Dictionary<string, long>();

        public static void DumpInfo(TextWriter writer)
        {
            Process currentProcess = Process.GetCurrentProcess();
            lock (PacketTimes)
            {
                foreach (KeyValuePair<string, long> pair in PacketTimes)
                {
                    writer.WriteLine("{0}: {1}", pair.Key, getProcessorUsage(currentProcess, pair.Value));
                }
            }
        }

        private static ProcessThread getCurrentProcessThread()
        {
            foreach (ProcessThread thread in Process.GetCurrentProcess().Threads)
            {
                if (thread.Id == AppDomain.GetCurrentThreadId())
                {
                    return thread;
                }
            }
            throw new Exception("Could not find current thread!");
        }

        public static long GetProcessorTime()
        {
            return getCurrentProcessThread().TotalProcessorTime.Ticks;
        }

        public static string getProcessorUsage(Process process, long interval)
        {
            return string.Format("{0:#0.####%}", ((float) interval) / ((float) process.TotalProcessorTime.Ticks));
        }

        public static void RegisterTime(string type, long start, long end)
        {
            lock (PacketTimes)
            {
                long num = 0;
                if (PacketTimes.ContainsKey(type))
                {
                    num = PacketTimes[type];
                }
                num += end - start;
                PacketTimes[type] = num;
            }
        }
    }
}

