//
namespace RunServer.Common
{
    using System;
    using System.IO;
    using System.Text;
    using System.Threading;

    public class LogConsole : TextWriter
    {
        private TextWriter m_console;
        private TextWriter m_output;
        private RunServer.Common.LogLevel m_verbose;
        private static LogConsole s_instance;

        private LogConsole() : this("Logs", "unknown", RunServer.Common.LogLevel.MAX)
        {
        }

        public LogConsole(string LogPath, string Name, RunServer.Common.LogLevel verbose)
        {
            this.m_verbose = verbose;
            if (!Directory.Exists(LogPath))
            {
                Directory.CreateDirectory(LogPath);
            }
            StreamWriter writer = new StreamWriter(Path.Combine(LogPath, string.Format("{1}_{0}.log", CustomDateTime.Now.ToLongDateString(), Name)), true, System.Text.Encoding.GetEncoding(0x4e3));
            writer.AutoFlush = false;
            this.m_output = TextWriter.Synchronized(writer);
            this.m_output.WriteLine("Log started on {0}, verbose level {1}", CustomDateTime.Now, this.m_verbose);
            this.m_output.WriteLine();
            if (System.Console.Out.GetType() == typeof(LogConsole))
            {
                this.m_console = ((LogConsole) System.Console.Out).Console;
            }
            else
            {
                this.m_console = System.Console.Out;
            }
            System.Console.SetOut(this);
            s_instance = this;
        }

        public override void Write(char text)
        {
            this.m_output.Write(text);
        }

        public static void Write(RunServer.Common.LogLevel level, string text)
        {
            if (level <= Instance.Verbose)
            {
                Instance.Write(text);
            }
        }

        public override void WriteLine(string line)
        {
            int managedThreadId = Thread.CurrentThread.ManagedThreadId;
            string text = string.Format("[{0}({1})] {2}", CustomDateTime.NowString, managedThreadId, line);
            this.m_output.WriteLine(text);
            this.m_console.WriteLine(text);
        }

        public static void WriteLine(RunServer.Common.LogLevel level, string text)
        {
            if (level <= Instance.Verbose)
            {
                Instance.WriteLine(text);
            }
        }

        public override void WriteLine(string line, params object[] args)
        {
            this.WriteLine(string.Format(line, args));
        }

        public static void WriteLine(RunServer.Common.LogLevel level, string line, params object[] args)
        {
            if (level <= Instance.Verbose)
            {
                Instance.WriteLine(string.Format(line, args));
            }
        }

        public TextWriter Console
        {
            get
            {
                return this.m_console;
            }
        }

        public override System.Text.Encoding Encoding
        {
            get
            {
                return System.Text.Encoding.Default;
            }
        }

        public static LogConsole Instance
        {
            get
            {
                if (s_instance == null)
                {
                    LogConsole console1 = new LogConsole();
                    s_instance = console1;
                    return console1;
                }
                return s_instance;
            }
        }

        public RunServer.Common.LogLevel Verbose
        {
            get
            {
                return this.m_verbose;
            }
        }
    }
}

