﻿namespace RunServer.Common
{
    using System;
    using System.Collections;

    public class ThreadHelper
    {
        private static Hashtable m_threads = Hashtable.Synchronized(new Hashtable());

        public static ThreadInfo GetThread()
        {
            return GetThread(AppDomain.GetCurrentThreadId());
        }

        public static ThreadInfo GetThread(int tid)
        {
            if (m_threads.ContainsKey(tid))
            {
                return (ThreadInfo) m_threads[tid];
            }
            lock (m_threads.SyncRoot)
            {
                if (!m_threads.ContainsKey(tid))
                {
                    object obj3;
                    m_threads[tid] = obj3 = new ThreadInfo(tid);
                    return (ThreadInfo) obj3;
                }
                return (ThreadInfo) m_threads[tid];
            }
        }

        public static void RegisterJob(string name)
        {
        }

        public static void RegisterName(string name)
        {
            GetThread().Name = name;
        }
    }
}

