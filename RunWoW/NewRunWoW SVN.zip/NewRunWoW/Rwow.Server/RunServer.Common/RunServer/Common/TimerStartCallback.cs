﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool TimerStartCallback();
}

