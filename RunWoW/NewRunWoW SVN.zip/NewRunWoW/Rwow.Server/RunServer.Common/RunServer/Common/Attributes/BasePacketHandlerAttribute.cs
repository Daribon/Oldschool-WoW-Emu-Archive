//
namespace RunServer.Common.Attributes
{
    using RunServer.Common;
    using System;

    [AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
    public class BasePacketHandlerAttribute : Attribute
    {
        private int m_msgID;
        private ExecutionPriority m_priority;

        public BasePacketHandlerAttribute(int msgID)
        {
            m_priority = ExecutionPriority.Packet;
            m_msgID = msgID;
        }

        public BasePacketHandlerAttribute(int msgID, ExecutionPriority priority)
        {
            m_priority = ExecutionPriority.Packet;
            m_msgID = msgID;
            m_priority = priority;
        }

        public int MsgID
        {
            get
            {
                return m_msgID;
            }
        }

        public ExecutionPriority Priority
        {
            get
            {
                return m_priority;
            }
        }
    }
}