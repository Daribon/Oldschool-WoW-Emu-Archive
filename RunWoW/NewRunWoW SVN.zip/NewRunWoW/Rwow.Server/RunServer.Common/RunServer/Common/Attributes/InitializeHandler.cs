//
namespace RunServer.Common.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
    public class InitializeHandler : Attribute
    {
        private int m_pass;

        public InitializeHandler()
        {
            m_pass = 0;
        }

        public InitializeHandler(InitPass pass)
        {
            m_pass = (int) pass;
        }

        public InitializeHandler(int pass)
        {
            m_pass = pass;
        }

        public int Pass
        {
            get
            {
                return m_pass;
            }
        }
    }
}