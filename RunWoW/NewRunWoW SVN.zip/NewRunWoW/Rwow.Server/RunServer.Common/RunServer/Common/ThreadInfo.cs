﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.CompilerServices;

    public class ThreadInfo
    {
        private string m_currentJobName = string.Empty;
        private int m_id;
        private DateTime m_lastJobTime = DateTime.MinValue;
        private string m_name = string.Empty;
        private volatile int m_totalJobs;

        public ThreadInfo(int id)
        {
            this.m_id = id;
        }

        public string CurrentJobName
        {
            get
            {
                return this.m_currentJobName;
            }
            set
            {
                this.m_currentJobName = value;
            }
        }

        public int ID
        {
            get
            {
                return this.m_id;
            }
        }

        public DateTime LastJobTime
        {
            get
            {
                return this.m_lastJobTime;
            }
            set
            {
                this.m_lastJobTime = value;
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                this.m_name = value;
            }
        }

        public int TotalJobs
        {
            get
            {
                return this.m_totalJobs;
            }
            set
            {
                this.m_totalJobs = value;
            }
        }
    }
}

