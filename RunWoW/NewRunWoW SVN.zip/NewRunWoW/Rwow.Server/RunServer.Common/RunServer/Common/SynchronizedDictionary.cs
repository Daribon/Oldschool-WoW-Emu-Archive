﻿namespace RunServer.Common
{
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using System.Runtime.CompilerServices;
    using System.Threading;

    public class SynchronizedDictionary<TKey, TValue> : Dictionary<TKey, TValue>
    {
        private ReaderWriterLock m_rwLock;
        private volatile int m_userLock;

        public SynchronizedDictionary()
        {
            this.m_rwLock = new ReaderWriterLock();
        }

        public SynchronizedDictionary(int capacity) : base(capacity)
        {
            this.m_rwLock = new ReaderWriterLock();
        }

        public void Add(TKey key, TValue value)
        {
            if (this.m_userLock == Thread.CurrentThread.ManagedThreadId)
            {
                base.Add(key, value);
            }
            else
            {
                this.m_rwLock.AcquireWriterLock(-1);
                base.Add(key, value);
                this.m_rwLock.ReleaseWriterLock();
            }
        }

        public void Clear()
        {
            if (this.m_userLock == Thread.CurrentThread.ManagedThreadId)
            {
                base.Clear();
            }
            else
            {
                this.m_rwLock.AcquireWriterLock(-1);
                base.Clear();
                this.m_rwLock.ReleaseWriterLock();
            }
        }

        public bool ContainsKey(TKey key)
        {
            if (this.m_userLock == Thread.CurrentThread.ManagedThreadId)
            {
                return base.ContainsKey(key);
            }
            this.m_rwLock.AcquireReaderLock(-1);
            bool flag = base.ContainsKey(key);
            this.m_rwLock.ReleaseReaderLock();
            return flag;
        }

        public void Lock()
        {
            this.m_rwLock.AcquireWriterLock(-1);
            this.m_userLock = Thread.CurrentThread.ManagedThreadId;
        }

        public void ReadLock()
        {
            this.m_rwLock.AcquireReaderLock(-1);
            this.m_userLock = Thread.CurrentThread.ManagedThreadId;
        }

        public void ReadUnlock()
        {
            this.m_userLock = 0;
            this.m_rwLock.ReleaseReaderLock();
        }

        public bool Remove(TKey key)
        {
            if (this.m_userLock == Thread.CurrentThread.ManagedThreadId)
            {
                return base.Remove(key);
            }
            this.m_rwLock.AcquireReaderLock(-1);
            if (!base.ContainsKey(key))
            {
                this.m_rwLock.ReleaseReaderLock();
                return false;
            }
            this.m_rwLock.UpgradeToWriterLock(-1);
            base.Remove(key);
            this.m_rwLock.ReleaseWriterLock();
            return true;
        }

        public void Unlock()
        {
            this.m_userLock = 0;
            this.m_rwLock.ReleaseWriterLock();
        }

        public TValue this[TKey key]
        {
            get
            {
                if (this.m_userLock == Thread.CurrentThread.ManagedThreadId)
                {
                    return base[key];
                }
                this.m_rwLock.AcquireReaderLock(-1);
                if (!base.ContainsKey(key))
                {
                    this.m_rwLock.ReleaseReaderLock();
                    throw new KeyNotFoundException();
                }
                TValue local = base[key];
                this.m_rwLock.ReleaseReaderLock();
                return local;
            }
            set
            {
                if (this.m_userLock == Thread.CurrentThread.ManagedThreadId)
                {
                    base[key] = value;
                }
                else
                {
                    this.m_rwLock.AcquireReaderLock(-1);
                    if (base.ContainsKey(key))
                    {
                        base[key] = value;
                        this.m_rwLock.ReleaseReaderLock();
                    }
                    else
                    {
                        this.m_rwLock.UpgradeToWriterLock(-1);
                        base[key] = value;
                        this.m_rwLock.ReleaseWriterLock();
                    }
                }
            }
        }
    }
}

