﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.InteropServices;
    using System.Threading;

    [StructLayout(LayoutKind.Sequential)]
    public struct SpinLock
    {
        private const int c_lsFree = 0;
        private const int c_lsOwned = 1;
        private int m_LockState;
        private static readonly bool IsSingleCpuMachine;
        public void Enter()
        {
            Thread.BeginCriticalRegion();
            while (Interlocked.Exchange(ref this.m_LockState, 1) != 0)
            {
                while (Thread.VolatileRead(ref this.m_LockState) == 1)
                {
                    StallThread();
                }
            }
        }

        public void Exit()
        {
            Interlocked.Exchange(ref this.m_LockState, 0);
            Thread.EndCriticalRegion();
        }

        private static void StallThread()
        {
            if (IsSingleCpuMachine)
            {
                SwitchToThread();
            }
            else
            {
                Thread.SpinWait(1);
            }
        }

        [DllImport("kernel32", ExactSpelling=true)]
        private static extern void SwitchToThread();
        static SpinLock()
        {
            IsSingleCpuMachine = Environment.ProcessorCount == 1;
        }
    }
}

