﻿namespace RunServer.Common
{
    using RunServer.Common.Attributes;
    using System;
    using System.Collections;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Threading;

    public class ScriptAssembly
    {
        private ArrayList assemblies = new ArrayList();
        private ArrayList[] initializers = new ArrayList[MaxPass];
        private static int MaxPass = 5;

        public void AddAssembly(Assembly assembly)
        {
            this.assemblies.Add(assembly);
        }

        public Type GetType(string name)
        {
            foreach (Assembly assembly in this.assemblies)
            {
                Type type = assembly.GetType(name);
                if (type != null)
                {
                    return type;
                }
            }
            return null;
        }

        private void InitType(TypeMethodPair pair)
        {
            try
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.TRACE, string.Concat(new object[] { "Invoking ", pair.Container, ":", pair.Handler }));
                pair.Handler.Invoke(pair.Container, new object[0]);
            }
            catch (Exception exception)
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.ERROR, "Exception at 'Initialize', : " + exception);
                throw exception;
            }
        }

        public virtual void Load()
        {
            foreach (Assembly assembly in this.assemblies)
            {
                foreach (Type type in assembly.GetTypes())
                {
                    this.LoadType(type);
                }
            }
            for (int i = 0; i < MaxPass; i++)
            {
                if (this.initializers[i] != null)
                {
                    foreach (TypeMethodPair pair in this.initializers[i])
                    {
                        this.InitType(pair);
                    }
                }
            }
        }

        protected virtual void LoadType(Type type)
        {
            if (type.IsClass)
            {
                foreach (MethodInfo info in type.GetMethods(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
                {
                    InitializeHandler[] customAttributes = (InitializeHandler[]) info.GetCustomAttributes(typeof(InitializeHandler), true);
                    if ((info.Name == "Initialize") || (customAttributes.Length > 0))
                    {
                        int index = (customAttributes.Length == 0) ? 0 : customAttributes[0].Pass;
                        if (this.initializers[index] == null)
                        {
                            this.initializers[index] = new ArrayList();
                        }
                        this.initializers[index].Add(new TypeMethodPair(type, info));
                    }
                }
            }
        }

        public virtual void Unload()
        {
            foreach (Assembly assembly in this.assemblies)
            {
                foreach (Type type in assembly.GetTypes())
                {
                    this.UnloadType(type);
                }
            }
            this.assemblies.Clear();
        }

        protected virtual void UnloadType(Type type)
        {
            if (type.IsClass)
            {
                foreach (MethodInfo info in type.GetMethods(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
                {
                    if (info.Name == "DoFinalize")
                    {
                        try
                        {
                            info.Invoke(null, new object[0]);
                        }
                        catch (ThreadAbortException)
                        {
                        }
                        catch (Exception exception)
                        {
                            LogConsole.WriteLine(RunServer.Common.LogLevel.ERROR, "Exception at 'Finalize': " + exception);
                            throw exception;
                        }
                    }
                }
            }
        }

        public ArrayList Assemblies
        {
            get
            {
                return this.assemblies;
            }
        }

        [StructLayout(LayoutKind.Sequential)]
        protected struct TypeMethodPair
        {
            public Type Container;
            public MethodInfo Handler;
            public ExecutionPriority Priority;
            public string Text;
            public TypeMethodPair(Type type, MethodInfo method) : this(type, method, ExecutionPriority.QPrimary, string.Empty)
            {
            }

            public TypeMethodPair(Type type, MethodInfo method, ExecutionPriority priority, string text)
            {
                this.Container = method.IsStatic ? null : type;
                this.Handler = method;
                this.Priority = priority;
                this.Text = text;
            }
        }
    }
}

