﻿namespace RunWoW.Common
{
    using System;

    public enum ARMOURSUBCLASS
    {
        GENERIC,
        CLOTH,
        LEATHER,
        MAIL,
        PLATE,
        BUCKLER,
        SHIELD
    }
}

