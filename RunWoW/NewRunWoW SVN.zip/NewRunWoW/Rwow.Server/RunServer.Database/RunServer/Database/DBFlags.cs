//
namespace RunServer.Database
{
    using System;

    [Flags]
    public enum DBFlags : byte
    {
        Cached = 1,
        DynCached = 8,
        FlushLoad = 0x40,
        FlushUpdate = 0x20,
        ForceLoad = 4,
        Hashed = 2,
        LargeUpdates = 0x10,
        NoIndex = 0x80,
        None = 0
    }
}

