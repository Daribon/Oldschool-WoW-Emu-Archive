﻿namespace RunServer.Database.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class RelationAttribute : Attribute
    {
        private bool autoDelete = false;
        private bool autoLoad = true;
        private bool autoSave = true;
        private string localField = null;
        private bool m_useZero = false;
        private string remoteField = null;

        public bool AutoDelete
        {
            get
            {
                return this.autoDelete;
            }
            set
            {
                this.autoDelete = value;
            }
        }

        public bool AutoLoad
        {
            get
            {
                return this.autoLoad;
            }
            set
            {
                this.autoLoad = value;
            }
        }

        public bool AutoSave
        {
            get
            {
                return this.autoSave;
            }
            set
            {
                this.autoSave = value;
            }
        }

        public string LocalField
        {
            get
            {
                return this.localField;
            }
            set
            {
                this.localField = value;
            }
        }

        public string RemoteField
        {
            get
            {
                return this.remoteField;
            }
            set
            {
                this.remoteField = value;
            }
        }

        public bool UseZero
        {
            get
            {
                return this.m_useZero;
            }
            set
            {
                this.m_useZero = value;
            }
        }
    }
}

