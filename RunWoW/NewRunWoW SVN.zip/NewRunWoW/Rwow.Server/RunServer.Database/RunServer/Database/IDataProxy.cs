//
namespace RunServer.Database
{
    using System;

    public interface IDataProxy
    {
        void FillObject(DataObject obj, object[] data);
        object[] GetValues(DataObject obj);
        void ResolveRelations(DataObject obj, ObjectDatabase db, bool force, Type targetType);
        void SetRelationCollection(DataObject obj, Type targetType, Array data);
    }
}

