//
namespace RunServer.Database
{
    using RunServer.Database.Connection;
    using System;
    using System.Collections;
    using System.Runtime.InteropServices;

    internal interface IObjectTable
    {
        void AddNewObject(DataObject subject);
        void CreateDatabaseTable();
        bool CreateTable();
        void DeleteObject(DataObject subject);
        void Export(DataConnection connection);
        void Flush();
        void FlushDynamic();
        DataObject GetObject(uint objectId);
        ICollection GetObjects(string query);
        ICollection GetObjects(object[][] n_objects);
        ICollection GetObjects(string query, bool paged, int pageNum, int pageSize, out int total);
        ICollection GetObjectsByField(string field, object key);
        ICollection GetObjectsPage(string query, int pageNum, int pageSize, out int total);
        object[][][] GetRelatedObjects(IDictionary[] fields, object key);
        string PrepareData(object data);
        void ReindexObject(string field, object oldkey, object newkey, uint id);
        void ReleaseTable();
        DataObject ReloadObject(DataObject obj);
        void ResolveIndexes();
        void SaveObject(DataObject subject);
        ICollection SelectAllObjects();

        bool Cached { get; }

        bool DynCached { get; }

        IDictionary Fields { get; }

        bool ForceLoad { get; }

        bool FullCache { get; set; }

        string Key { get; }

        IDataProxy Proxy { get; set; }

        string ResolveProcedure { get; }

        Type[] ResolveTypes { get; }
    }
}

