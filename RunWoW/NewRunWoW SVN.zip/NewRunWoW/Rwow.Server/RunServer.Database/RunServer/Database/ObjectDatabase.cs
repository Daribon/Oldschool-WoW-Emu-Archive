//
namespace RunServer.Database
{
    using RunServer.Database.Connection;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Runtime.InteropServices;

    public class ObjectDatabase
    {
        private DataConnection[] m_connections;
        private ProxyManager m_proxyMan;
        private Dictionary<Type, IObjectTable> m_tables;
        private static ObjectDatabase s_instance;

        public ObjectDatabase(DataConnection Connection) : this(new DataConnection[] { Connection })
        {
        }

        public ObjectDatabase(DataConnection[] Connections)
        {
            this.m_tables = new Dictionary<Type, IObjectTable>();
            this.m_connections = Connections;
            this.m_proxyMan = new ProxyManager();
            s_instance = this;
        }

        public void AddNewObject(DataObject dataObject)
        {
            if (dataObject == null)
            {
                throw new DatabaseException("Asked to add null object");
            }
            if (!this.m_tables.ContainsKey(dataObject.GetType()))
            {
                throw new DatabaseException("Unknown object type " + dataObject.GetType());
            }
            this.m_tables[dataObject.GetType()].AddNewObject(dataObject);
        }

        public void AddObjectToArray<T>(ref T[] array, T obj)
        {
            List<T> list = new List<T>(array);
            if (!list.Contains(obj))
            {
                list.Add(obj);
                array = list.ToArray();
            }
        }

        public void CreateTables()
        {
            Dictionary<Type, IObjectTable>.ValueCollection.Enumerator enumerator = this.m_tables.Values.GetEnumerator();
            try
            {
                while (enumerator.MoveNext())
                {
                    if (!enumerator.Current.CreateTable())
                    {
                        return;
                    }
                }
            }
            finally
            {
                enumerator.Dispose();
            }
        }

        public void DeleteObject(DataObject dataObject)
        {
            if (dataObject == null)
            {
                throw new DatabaseException("Asked to delete null object");
            }
            if (!this.m_tables.ContainsKey(dataObject.GetType()))
            {
                throw new DatabaseException("Unknown object type " + dataObject.GetType());
            }
            this.m_tables[dataObject.GetType()].DeleteObject(dataObject);
        }

        public DataObject FindObjectByField(Type objectType, string Field, object Key)
        {
            if (!this.m_tables.ContainsKey(objectType))
            {
                throw new DatabaseException("Unknown object type " + objectType);
            }
            IObjectTable table = this.m_tables[objectType];
            if (Field == table.Key)
            {
                return this.FindObjectByKey(objectType, Key);
            }
            foreach (DataObject obj2 in this.FindObjectsByField(objectType, Field, Key))
            {
                return obj2;
            }
            return null;
        }

        public DataObject FindObjectByKey(Type objectType, object key)
        {
            uint objectId;
            if ((key == null) || (key == DBNull.Value))
            {
                return null;
            }
            try
            {
                objectId = (uint) Convert.ChangeType(key, typeof(uint));
            }
            catch
            {
                throw new DatabaseException(string.Format("Wrong key {0}, type {1} while loading type {2}", key, key.GetType(), objectType));
            }
            if (!this.m_tables.ContainsKey(objectType))
            {
                throw new DatabaseException("Unknown object type " + objectType);
            }
            DataObject obj2 = this.m_tables[objectType].GetObject(objectId);
            if ((obj2 != null) && !obj2.Resolved)
            {
                this.ResolveRelations(obj2);
            }
            return obj2;
        }

        public ICollection FindObjectsByField(Type objectType, string Field, object Key)
        {
            if (!this.m_tables.ContainsKey(objectType))
            {
                throw new DatabaseException("Unknown object type " + objectType);
            }
            ICollection objectsByField = this.m_tables[objectType].GetObjectsByField(Field, Key);
            if (objectsByField == null)
            {
                return this.SelectObjects(objectType, (Key.GetType() == typeof(string)) ? string.Format("{0} = '{1}'", Field, Key) : string.Format("{0} = {1}", Field, Key));
            }
            foreach (DataObject obj2 in objectsByField)
            {
                if ((obj2 != null) && !obj2.Resolved)
                {
                    this.ResolveRelations(obj2);
                }
            }
            return objectsByField;
        }

        public void FlushTables()
        {
            foreach (IObjectTable table in this.m_tables.Values)
            {
                table.Flush();
                table.FlushDynamic();
            }
        }

        public void GenerateProxies()
        {
            this.GenerateProxies(string.Empty);
        }

        public void GenerateProxies(string name)
        {
            this.m_proxyMan.Compile(name);
        }

        public void LoadDatabaseTable(Type Type)
        {
            if (!this.m_tables.ContainsKey(Type))
            {
                throw new DatabaseException("Unknown object type " + Type);
            }
            IObjectTable table = this.m_tables[Type];
            if (table.Cached || table.DynCached)
            {
                ICollection objects = table.GetObjects(string.Empty);
                table.FullCache = true;
                this.ResolveIndexes();
                Console.WriteLine("Cached {0} objects of type {1}", objects.Count, Type);
            }
        }

        public string PrepareData(Type objectType, object data)
        {
            if (!this.m_tables.ContainsKey(objectType))
            {
                throw new DatabaseException("Unknown object type " + objectType);
            }
            return this.m_tables[objectType].PrepareData(data);
        }

        public void RegisterDataObject<T>(DBFlags Flags) where T: DataObject
        {
            this.RegisterDataObject<T>(Flags, 0);
        }

        public void RegisterDataObject<T>(DBFlags Flags, int DB) where T: DataObject
        {
            if (this.m_tables.ContainsKey(typeof(T)))
            {
                throw new DatabaseException(string.Format("Type {0} already registered", typeof(T)));
            }
            if (DB >= this.m_connections.Length)
            {
                throw new DatabaseException(string.Format("Connection number {0}is out of range for Type {1}", DB, typeof(T)));
            }
            this.m_tables[typeof(T)] = new ObjectTable<T>(Flags, this.m_connections[DB], this.m_proxyMan);
        }

        public void ReindexObject(string field, object oldkey, object newkey, DataObject dataObject)
        {
            if (dataObject == null)
            {
                throw new DatabaseException("Asked to reindex null object");
            }
            if (!this.m_tables.ContainsKey(dataObject.GetType()))
            {
                throw new DatabaseException("Unknown object type " + dataObject.GetType());
            }
            this.m_tables[dataObject.GetType()].ReindexObject(field, oldkey, newkey, dataObject.ObjectId);
        }

        public void ReleaseDatabaseTable(Type Type)
        {
            if (!this.m_tables.ContainsKey(Type))
            {
                throw new DatabaseException("Unknown object type " + Type);
            }
            IObjectTable table = this.m_tables[Type];
            if (table.Cached)
            {
                table.ReleaseTable();
            }
        }

        public void ReloadObject(DataObject dataObject)
        {
            if (dataObject == null)
            {
                throw new DatabaseException("Asked to reload null object");
            }
            if (!this.m_tables.ContainsKey(dataObject.GetType()))
            {
                throw new DatabaseException("Unknown object type " + dataObject.GetType());
            }
            this.m_tables[dataObject.GetType()].ReloadObject(dataObject);
        }

        public void RemoveObjectFromArray<T>(ref T[] array, T obj)
        {
            List<T> list = new List<T>(array);
            if (list.Contains(obj))
            {
                list.Remove(obj);
                array = list.ToArray();
            }
        }

        public void ResolveIndexes()
        {
            Dictionary<Type, IObjectTable>.ValueCollection.Enumerator enumerator = this.m_tables.Values.GetEnumerator();
            try
            {
                while (enumerator.MoveNext())
                {
                    enumerator.Current.ResolveIndexes();
                }
            }
            finally
            {
                enumerator.Dispose();
            }
        }

        public void ResolveRelations(DataObject obj)
        {
            if (obj != null)
            {
                if (!this.m_tables.ContainsKey(obj.GetType()))
                {
                    throw new DatabaseException(string.Format("Unknown object type {0}", obj.GetType()));
                }
                this.ResolveRelations(this.m_tables[obj.GetType()], obj, this.m_tables[obj.GetType()].ForceLoad, null);
            }
        }

        public void ResolveRelations(DataObject obj, bool force)
        {
            if (obj != null)
            {
                if (!this.m_tables.ContainsKey(obj.GetType()))
                {
                    throw new DatabaseException(string.Format("Unknown object type {0}", obj.GetType()));
                }
                this.ResolveRelations(this.m_tables[obj.GetType()], obj, force, null);
            }
        }

        public void ResolveRelations(DataObject obj, Type target)
        {
            if (obj != null)
            {
                if (!this.m_tables.ContainsKey(obj.GetType()))
                {
                    throw new DatabaseException(string.Format("Unknown object type {0}", obj.GetType()));
                }
                this.ResolveRelations(this.m_tables[obj.GetType()], obj, true, target);
            }
        }

        private void ResolveRelations(IObjectTable table, DataObject obj, bool force, Type target)
        {
            if (((!obj.Resolved || force) || (target != null)) && (table.Proxy != null))
            {
                if ((((target == null) && force) && ((table.ResolveProcedure != null) && (table.ResolveTypes != null))) && (table.ResolveTypes.Length > 0))
                {
                    IDictionary[] fields = new IDictionary[table.ResolveTypes.Length];
                    for (int i = 0; i < fields.Length; i++)
                    {
                        fields[i] = this.m_tables[table.ResolveTypes[i]].Fields;
                    }
                    DateTime now = DateTime.Now;
                    object[][][] relatedObjects = table.GetRelatedObjects(fields, (int) obj.ObjectId);
                    TimeSpan span = (TimeSpan) (DateTime.Now - now);
                    double totalMilliseconds = span.TotalMilliseconds;
                    if (totalMilliseconds > 300)
                    {
                        Console.WriteLine("Executing stored proc for objects of type {0} took {1}ms", obj.GetType().Name, totalMilliseconds);
                    }
                    if (relatedObjects != null)
                    {
                        for (int j = 0; j < fields.Length; j++)
                        {
                            ICollection objects = this.m_tables[table.ResolveTypes[j]].GetObjects(relatedObjects[j]);
                            foreach (DataObject obj2 in objects)
                            {
                                if (!obj2.Resolved)
                                {
                                    this.ResolveRelations(obj2);
                                }
                            }
                            table.Proxy.SetRelationCollection(obj, table.ResolveTypes[j], (Array) objects);
                        }
                    }
                    else
                    {
                        Console.WriteLine("Warining: connection does not support stored procedures for type {0}", obj.GetType().Name);
                    }
                }
                table.Proxy.ResolveRelations(obj, this, force, target);
                obj.Resolved = true;
            }
        }

        public void SaveObject(DataObject dataObject)
        {
            if (dataObject == null)
            {
                throw new DatabaseException("Asked to save null object");
            }
            if (!this.m_tables.ContainsKey(dataObject.GetType()))
            {
                throw new DatabaseException("Unknown object type " + dataObject.GetType());
            }
            this.m_tables[dataObject.GetType()].SaveObject(dataObject);
        }

        public ICollection SelectAllObjects(Type objectType)
        {
            if (!this.m_tables.ContainsKey(objectType))
            {
                throw new DatabaseException("Unknown object type " + objectType);
            }
            IObjectTable table = this.m_tables[objectType];
            if (!table.FullCache)
            {
                return this.SelectObjects(objectType, string.Empty);
            }
            return table.SelectAllObjects();
        }

        public ICollection SelectObjects(Type objectType, string statement)
        {
            if (!this.m_tables.ContainsKey(objectType))
            {
                throw new DatabaseException("Unknown object type " + objectType);
            }
            ICollection objects = this.m_tables[objectType].GetObjects(statement);
            foreach (DataObject obj2 in objects)
            {
                if ((obj2 != null) && !obj2.Resolved)
                {
                    this.ResolveRelations(obj2);
                }
            }
            return objects;
        }

        public ICollection SelectObjectsPage(Type objectType, string query, int pageNum, int pageSize, out int total)
        {
            if (!this.m_tables.ContainsKey(objectType))
            {
                throw new DatabaseException("Unknown object type " + objectType);
            }
            ICollection is2 = this.m_tables[objectType].GetObjectsPage(query, pageNum, pageSize, out total);
            foreach (DataObject obj2 in is2)
            {
                if ((obj2 != null) && !obj2.Resolved)
                {
                    this.ResolveRelations(obj2);
                }
            }
            return is2;
        }

        public void WriteDatabaseTable(Type Type)
        {
            if (!this.m_tables.ContainsKey(Type))
            {
                throw new DatabaseException("Asked to save not registered table");
            }
            this.m_tables[Type].Flush();
        }

        public void WriteDatabaseTables()
        {
            Dictionary<Type, IObjectTable>.ValueCollection.Enumerator enumerator = this.m_tables.Values.GetEnumerator();
            try
            {
                while (enumerator.MoveNext())
                {
                    enumerator.Current.Flush();
                }
            }
            finally
            {
                enumerator.Dispose();
            }
        }

        public void WriteDatabaseTablesTo(DataConnection connection)
        {
            Dictionary<Type, IObjectTable>.ValueCollection.Enumerator enumerator = this.m_tables.Values.GetEnumerator();
            try
            {
                while (enumerator.MoveNext())
                {
                    enumerator.Current.Export(connection);
                }
            }
            finally
            {
                enumerator.Dispose();
            }
        }

        public static ObjectDatabase Instance
        {
            get
            {
                return s_instance;
            }
        }
    }
}

