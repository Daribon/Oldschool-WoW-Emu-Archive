﻿namespace RunServer.Database.MemberValues
{
    using System;
    using System.Reflection;

    public class EnumFieldMemberValue : FieldMemberValue
    {
        public EnumFieldMemberValue(FieldInfo info) : base(info)
        {
        }

        public override Type GetValueType()
        {
            return Enum.GetUnderlyingType(base.m_info.FieldType);
        }

        public override void SetValue(object obj, object value)
        {
            base.m_info.SetValue(obj, Enum.ToObject(base.m_info.FieldType, value));
        }
    }
}

