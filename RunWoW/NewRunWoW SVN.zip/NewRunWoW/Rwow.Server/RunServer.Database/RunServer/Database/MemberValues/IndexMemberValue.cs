﻿namespace RunServer.Database.MemberValues
{
    using RunServer.Database.Attributes;
    using System;
    using System.Reflection;

    public class IndexMemberValue : MemberValue
    {
        private int m_index;
        private MemberValue m_memberValue;

        public IndexMemberValue(MemberValue memberValue, int index)
        {
            this.m_memberValue = memberValue;
            this.m_index = index;
        }

        public override string GetName()
        {
            return (this.m_memberValue.GetName() + "_" + this.m_index);
        }

        public override object GetValue(object obj)
        {
            Array array = this.m_memberValue.GetValue(obj) as Array;
            if (array != null)
            {
                return array.GetValue(this.m_index);
            }
            return null;
        }

        public override Type GetValueType()
        {
            return this.m_memberValue.GetValueType().GetElementType();
        }

        public override void SetValue(object obj, object value)
        {
            Array array = this.m_memberValue.GetValue(obj) as Array;
            if (array != null)
            {
                array.SetValue(value, this.m_index);
            }
        }

        public override MemberValueAttribute Attribute
        {
            get
            {
                return this.m_memberValue.Attribute;
            }
            set
            {
                this.m_memberValue.Attribute = value;
            }
        }

        public int Index
        {
            get
            {
                return this.m_index;
            }
        }

        public override System.Reflection.MemberInfo MemberInfo
        {
            get
            {
                return this.m_memberValue.MemberInfo;
            }
        }
    }
}

