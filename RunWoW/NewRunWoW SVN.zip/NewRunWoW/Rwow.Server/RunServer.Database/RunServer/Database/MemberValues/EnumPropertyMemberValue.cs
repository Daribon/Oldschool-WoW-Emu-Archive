﻿namespace RunServer.Database.MemberValues
{
    using System;
    using System.Reflection;

    public class EnumPropertyMemberValue : PropertyMemberValue
    {
        public EnumPropertyMemberValue(PropertyInfo info) : base(info)
        {
        }

        public override Type GetValueType()
        {
            return Enum.GetUnderlyingType(base.m_info.PropertyType);
        }

        public override void SetValue(object obj, object value)
        {
            base.m_info.SetValue(obj, Enum.ToObject(base.m_info.PropertyType, value), null);
        }
    }
}

