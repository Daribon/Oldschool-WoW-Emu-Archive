//
namespace RunServer.Database.Connection
{
    using System;
    using System.Collections;
    using System.IO;
    using System.Runtime.InteropServices;
    using System.Text;

    public class ConnectionMySQLText : ConnectionBase
    {
        public ConnectionMySQLText(string connectionString) : base(connectionString)
        {
        }

        public override void CreateTable(string TableName, IDictionary fields, string keyField)
        {
        }

        public override void DeleteObjects(string TableName, ICollection keys, IDictionary fields, string keyField)
        {
            using (StreamWriter writer = new StreamWriter(base.ConnString, true))
            {
                string format = base.GetDeleteString(TableName, keyField);
                StringBuilder builder = new StringBuilder();
                foreach (object obj2 in keys)
                {
                    builder.AppendFormat("{0}, ", this.ProcessType(obj2));
                }
                writer.WriteLine(string.Format(format, builder.ToString(0, builder.Length - 2)));
            }
        }

        protected override string GetInsertString(string TableName, IDictionary fields)
        {
            if (!base.Cache(ConnectionBase.OpType.Insert).ContainsKey(TableName))
            {
                string text2;
                string text = string.Format("INSERT INTO {0} ( {1} ) VALUES ", this.QuoteObject(TableName), base.GetFieldsString(fields, string.Empty));
                base.Cache(OpType.Insert)[TableName] = text2 = text;
                return text2;
            }
            return base.Cache(OpType.Insert)[TableName];
        }

        public override object GetMaxValue(string TableName, string Field)
        {
            return 0;
        }

        public override object GetRecordCount(string TableName)
        {
            return 0;
        }

        public static void Init()
        {
            ConnectionHandler.RegisterHandler(ConnectionType.DATABASE_MYSQL_TEXT, typeof(ConnectionMySQLText));
        }

        public override void InsertObjects(string TableName, object[][] objects, IDictionary fields)
        {
            using (StreamWriter writer = new StreamWriter(base.ConnString, true, Encoding.Default, 0x100000))
            {
                string insertString = this.GetInsertString(TableName, fields);
                string template = base.GetFieldsString(TableName, fields);
                writer.WriteLine(insertString);
                int index = 0;
                while (index < objects.Length)
                {
                    writer.Write(base.FormatDBString(template, objects[index]));
                    if ((index > 0) && ((index % 0x2710) == 0))
                    {
                        writer.WriteLine(";");
                        writer.Flush();
                        if (index != (objects.Length - 1))
                        {
                            writer.WriteLine(insertString);
                        }
                        Console.WriteLine("Progress {0:0.0%}", ((double) index) / ((double) objects.Length));
                    }
                    else if (index != (objects.Length - 1))
                    {
                        writer.WriteLine(", ");
                    }
                    index++;
                }
                if ((index > 0) && ((index % 0x2710) != 0))
                {
                    writer.WriteLine(";");
                }
            }
        }

        public override string QuoteObject(string obj)
        {
            return ("`" + obj + "`");
        }

        public override string QuoteString(string obj)
        {
            return ("'" + obj.Replace(@"\", @"\\").Replace("'", @"\'").Replace("`", @"\`") + "'");
        }

        public override object[][] SelectObjects(string TableName, IDictionary fields, string where)
        {
            return new object[0][];
        }

        public override object[][] SelectObjects(string TableName, string query, string where)
        {
            return new object[0][];
        }

        public override object[][] SelectObjects(string TableName, ICollection keys, IDictionary fields, string keyField)
        {
            return new object[0][];
        }

        public override object[][] SelectObjectsPaged(string TableName, IDictionary fields, string where, int pageNum, int pageSize, out int totalRecords)
        {
            throw new NotImplementedException();
        }

        public override void UpdateObjects(string TableName, object[][] objects, IDictionary fields, string keyField)
        {
            using (StreamWriter writer = new StreamWriter(base.ConnString, true))
            {
                string template = base.GetUpdateString(TableName, fields, keyField);
                for (int i = 0; i < objects.Length; i++)
                {
                    writer.WriteLine(base.FormatDBString(template, objects[i]));
                }
            }
        }
    }
}

