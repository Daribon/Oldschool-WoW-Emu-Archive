//
namespace RunServer.Database.Connection
{
    using MySql.Data;
    using MySql.Data.MySqlClient;
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Data;
    using System.Runtime.InteropServices;
    using System.Text;

    public class ConnectionMySQL : ConnectionBase
    {
        private Queue<StringBuilder> m_strings;
        private static int MaximumQueryString = 0x50000;

        public ConnectionMySQL(string connectionString) : base(connectionString)
        {
            this.m_strings = new Queue<StringBuilder>();
        }

        protected StringBuilder AllocBuilder()
        {
            if (this.m_strings.Count > 0)
            {
                lock (this.m_strings)
                {
                    if (this.m_strings.Count > 0)
                    {
                        return this.m_strings.Dequeue();
                    }
                }
            }
            return new StringBuilder(MaximumQueryString);
        }

        public override void CreateTable(string TableName, IDictionary fields, string keyField)
        {
            string text = (string.Empty + "CREATE TABLE ") + this.QuoteObject(TableName) + " ( ";
            IDictionaryEnumerator enumerator = fields.GetEnumerator();
            while (enumerator.MoveNext())
            {
                text = (text + this.QuoteObject(enumerator.Key.ToString()) + " ") + TypeString((Type) enumerator.Value);
                if (enumerator.Key.ToString() == keyField)
                {
                    text = text + " NOT NULL";
                }
                text = text + ", ";
            }
            text = (text + " PRIMARY KEY (" + this.QuoteObject(keyField) + ")") + " ) ";
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    command.CommandText = text;
                    command.ExecuteNonQuery();
                }
            }
        }

        public override void DeleteObjects(string TableName, ICollection keys, IDictionary fields, string keyField)
        {
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    string format = base.GetDeleteString(TableName, keyField);
                    StringBuilder builder = new StringBuilder();
                    foreach (object obj2 in keys)
                    {
                        builder.AppendFormat("{0}, ", this.ProcessType(obj2));
                    }
                    command.CommandText = string.Format(format, builder.ToString(0, builder.Length - 2));
                    command.ExecuteNonQuery();
                }
            }
        }

        protected override string GetInsertString(string TableName, IDictionary fields)
        {
            if (!base.Cache(ConnectionBase.OpType.Insert).ContainsKey(TableName))
            {
                string text2;
                string text = string.Format("INSERT INTO {0} ( {1} ) VALUES ", this.QuoteObject(TableName), base.GetFieldsString(fields, string.Empty));
                base.Cache(OpType.Insert)[TableName] = text2 = text;
                return text2;
            }
            return base.Cache(OpType.Insert)[TableName];
        }

        public override object GetMaxValue(string TableName, string Field)
        {
            object obj2;
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    command.CommandText = string.Format(format, "MAX(" + this.QuoteObject(Field) + ")", "1=1");
                    obj2 = command.ExecuteScalar();
                }
            }
            return obj2;
        }

        public override object GetRecordCount(string TableName)
        {
            object obj2;
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    command.CommandText = string.Format(format, "COUNT(*)", "1=1");
                    obj2 = command.ExecuteScalar();
                }
            }
            return obj2;
        }

        public static void Init()
        {
            ConnectionHandler.RegisterHandler(ConnectionType.DATABASE_MYSQL, typeof(ConnectionMySQL));
        }

        public override void InsertObjects(string TableName, object[][] objects, IDictionary fields)
        {
            if (objects.Length > 0)
            {
                using (MySqlConnection connection = new MySqlConnection(base.ConnString))
                {
                    connection.Open();
                    using (MySqlTransaction transaction = connection.BeginTransaction())
                    {
                        using (MySqlCommand command = connection.CreateCommand())
                        {
                            //command.set_Transaction((IDbTransaction) transaction);
                            command.Transaction = transaction;
                            command.CommandTimeout = 0;
                            string insertString = this.GetInsertString(TableName, fields);
                            string template = base.GetFieldsString(TableName, fields);
                            StringBuilder buider = this.AllocBuilder();
                            buider.Append(insertString);
                            for (int i = 0; i < objects.Length; i++)
                            {
                                buider.Append(base.FormatDBString(template, objects[i]));
                                if (buider.Length > MaximumQueryString)
                                {
                                    command.CommandText = buider.ToString();
                                    command.ExecuteNonQuery();
                                    buider.Length = 0;
                                    if (i != (objects.Length - 1))
                                    {
                                        buider.Append(insertString);
                                    }
                                }
                                else if (i != (objects.Length - 1))
                                {
                                    buider.Append(",");
                                }
                            }
                            if (buider.Length > 0)
                            {
                                command.CommandText = buider.ToString();
                                command.ExecuteNonQuery();
                            }
                            this.ReleaseBuilder(buider);
                            transaction.Commit();
                        }
                    }
                }
            }
        }

        public override string QuoteObject(string obj)
        {
            return ("`" + obj + "`");
        }

        public override string QuoteString(string obj)
        {
            return ("'" + obj.Replace(@"\", @"\\").Replace("'", @"\'").Replace("`", @"\`") + "'");
        }

        protected void ReleaseBuilder(StringBuilder buider)
        {
            buider.Length = 0;
            this.m_strings.Enqueue(buider);
        }

        public override object[][][] SelectMultipleObjects(string procedureName, IDictionary[] fields, string keyField, object key)
        {
            object[][][] objArray3;
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    command.CommandText = procedureName;
                    command.CommandType = CommandType.StoredProcedure;
                    command.Parameters.Add(new MySqlParameter("@" + keyField, key));
                    for (int i = 0; i < fields.Length; i++)
                    {
                        command.Parameters.Add(new MySqlParameter("@fields_" + i, base.GetFieldsString(fields[i], string.Empty)));
                    }
                    List<object[]>[] listArray = new List<object[]>[fields.Length];
                    for (int j = 0; j < listArray.Length; j++)
                    {
                        listArray[j] = new List<object[]>();
                    }
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        int index = 0;
                        do
                        {
                            while (reader.Read())
                            {
                                object[] values = new object[reader.FieldCount];
                                reader.GetValues(values);
                                listArray[index].Add(values);
                            }
                            index++;
                        }
                        while (reader.NextResult());
                    }
                    object[][][] objArray2 = new object[fields.Length][][];
                    for (int k = 0; k < objArray2.Length; k++)
                    {
                        objArray2[k] = listArray[k].ToArray();
                    }
                    objArray3 = objArray2;
                }
            }
            return objArray3;
        }

        public override object[][] SelectObjects(string TableName, IDictionary fields, string where)
        {
            return this.SelectObjects(TableName, base.GetFieldsString(fields, string.Empty), where);
        }

        public override object[][] SelectObjects(string TableName, string query, string where)
        {
            object[][] objArray2;
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    command.CommandText = string.Format(format, query, (where == string.Empty) ? "1=1" : where);
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        ArrayList list = new ArrayList();
                        while (reader.Read())
                        {
                            object[] values = new object[reader.FieldCount];
                            reader.GetValues(values);
                            list.Add(values);
                        }
                        objArray2 = (object[][]) list.ToArray(typeof(object[]));
                    }
                }
            }
            return objArray2;
        }

        public override object[][] SelectObjects(string TableName, ICollection keys, IDictionary fields, string keyField)
        {
            object[][] objArray2;
            if (keys.Count == 0)
            {
                Console.WriteLine("Error: Asked to select data from table {0} with 0 keys", TableName);
                return new object[0][];
            }
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    string format = base.GetSelectString(TableName, fields, keyField);
                    StringBuilder builder = new StringBuilder();
                    foreach (object obj2 in keys)
                    {
                        builder.AppendFormat("{0}, ", this.ProcessType(obj2));
                    }
                    command.CommandText = string.Format(format, builder.ToString(0, builder.Length - 2));
                    using (IDataReader reader = command.ExecuteReader())
                    {
                        ArrayList list = new ArrayList();
                        while (reader.Read())
                        {
                            object[] values = new object[reader.FieldCount];
                            reader.GetValues(values);
                            list.Add(values);
                        }
                        objArray2 = (object[][]) list.ToArray(typeof(object[]));
                    }
                }
            }
            return objArray2;
        }

        public override object[][] SelectObjectsPaged(string TableName, IDictionary fields, string where, int pageNum, int pageSize, out int totalRecords)
        {
            object[][] objArray2;
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlCommand command = connection.CreateCommand())
                {
                    command.CommandTimeout = 0;
                    string format = base.GetQueryString(TableName);
                    command.CommandText = string.Format(format, "Count(*)", (where == string.Empty) ? "1=1" : where);
                    totalRecords = (int) command.ExecuteScalar();
                }
                using (MySqlCommand command2 = connection.CreateCommand())
                {
                    command2.CommandTimeout = 0;
                    string queryString = base.GetQueryString(TableName);
                    command2.CommandText = string.Format("{0} LIMIT {1}, {2}", string.Format(queryString, base.GetFieldsString(fields, string.Empty), (where == string.Empty) ? "1=1" : where), pageNum * pageSize, pageSize);
                    using (IDataReader reader = command2.ExecuteReader())
                    {
                        ArrayList list = new ArrayList();
                        while (reader.Read())
                        {
                            object[] values = new object[reader.FieldCount];
                            reader.GetValues(values);
                            list.Add(values);
                        }
                        objArray2 = (object[][]) list.ToArray(typeof(object[]));
                    }
                }
            }
            return objArray2;
        }

        private static string TypeString(Type type)
        {
            if ((((type == typeof(int)) || (type == typeof(uint))) || ((type == typeof(byte)) || (type == typeof(sbyte)))) || ((type == typeof(short)) || (type == typeof(ushort))))
            {
                return "int";
            }
            if ((type == typeof(long)) || (type == typeof(ulong)))
            {
                return "bigint";
            }
            if (((type == typeof(float)) || (type == typeof(double))) || (type == typeof(decimal)))
            {
                return "float";
            }
            if (type == typeof(DateTime))
            {
                return "date";
            }
            if (type == typeof(byte[]))
            {
                return "text";
            }
            return "varchar(100)";
        }

        public override void UpdateObjects(string TableName, object[][] objects, IDictionary fields, string keyField)
        {
            using (MySqlConnection connection = new MySqlConnection(base.ConnString))
            {
                connection.Open();
                using (MySqlTransaction transaction = connection.BeginTransaction())
                {
                    using (MySqlCommand command = connection.CreateCommand())
                    {
                        //command.set_Transaction((IDbTransaction) transaction);
                        command.Transaction = transaction;
                        command.CommandTimeout = 0;
                        string template = base.GetUpdateString(TableName, fields, keyField);
                        StringBuilder buider = this.AllocBuilder();
                        for (int i = 0; i < objects.Length; i++)
                        {
                            buider.Append(base.FormatDBString(template, objects[i]));
                            if (buider.Length > MaximumQueryString)
                            {
                                command.CommandText = buider.ToString();
                                command.ExecuteNonQuery();
                                buider.Length = 0;
                            }
                        }
                        if (buider.Length > 0)
                        {
                            command.CommandText = buider.ToString();
                            command.ExecuteNonQuery();
                        }
                        this.ReleaseBuilder(buider);
                        transaction.Commit();
                    }
                }
            }
        }
    }
}

