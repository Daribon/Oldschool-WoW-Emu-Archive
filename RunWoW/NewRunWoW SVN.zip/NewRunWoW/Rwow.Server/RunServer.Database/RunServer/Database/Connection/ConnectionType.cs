//
namespace RunServer.Database.Connection
{
    using System;

    public enum ConnectionType
    {
        DATABASE_XML,
        DATABASE_MYSQL,
        DATABASE_ODBC_TT,
        DATABASE_ODBC,
        DATABASE_MSSQL,
        DATABASE_ORACLE,
        DATABASE_MYSQL_TEXT,
        DATABASE_TT,
        PIPE,
        DATABASE_FIREBIRD
    }
}

