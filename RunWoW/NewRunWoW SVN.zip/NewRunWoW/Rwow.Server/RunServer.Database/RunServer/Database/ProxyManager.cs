//
namespace RunServer.Database
{
    using Microsoft.CSharp;
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using System;
    using System.CodeDom.Compiler;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;

    public class ProxyManager
    {
        private ArrayList m_assemblies;
        private TempFileCollection m_files = new TempFileCollection();
        private Hashtable m_names = new Hashtable();
        private Hashtable m_proxies = new Hashtable();

        public ProxyManager()
        {
            this.m_files.KeepFiles = false;
            this.m_assemblies = new ArrayList();
            this.m_assemblies.Add(base.GetType().Assembly);
        }

        public void Compile(string name)
        {
            CompilerParameters options = new CompilerParameters();
            options.GenerateInMemory = true;
            options.GenerateExecutable = false;
            options.WarningLevel = 4;
            options.OutputAssembly = "RunServer.DBProxy.dll";
            options.TempFiles = new TempFileCollection(Environment.GetEnvironmentVariable("TEMP"));
            foreach (Assembly assembly in this.m_assemblies)
            {
                options.ReferencedAssemblies.Add(assembly.CodeBase.Replace("file:///", ""));
            }
            CodeDomProvider provider = new CSharpCodeProvider();
            string[] fileNames = new string[this.m_files.Count];
            this.m_files.CopyTo(fileNames, 0);
            CompilerResults results = provider.CompileAssemblyFromFile(options, fileNames);
            if (results.Errors.Count > 0)
            {
                string text = string.Empty;
                foreach (string text2 in results.Output)
                {
                    text = text + text2 + Environment.NewLine;
                }
                Console.WriteLine(text);
                throw new DatabaseException("Cannot compile proxies: " + text);
            }
            this.m_files.Delete();
            foreach (Type type in results.CompiledAssembly.GetTypes())
            {
                if (this.m_names.ContainsKey(type.Name))
                {
                    this.m_proxies[this.m_names[type.Name]] = Activator.CreateInstance(type);
                }
            }
        }

        public void FillObject(DataObject obj, object[] data)
        {
            IDataProxy proxy = this[obj.GetType()];
            if (proxy != null)
            {
                proxy.FillObject(obj, data);
            }
        }

        private static void GenerateFill(TextWriter writer, Type type, List<FieldHolder> records)
        {
            writer.WriteLine("\t\tpublic void FillObject(DataObject obj, object[] data)");
            writer.WriteLine("\t\t{");
            writer.WriteLine("\t\t\t{0} nobj = obj as {0};\n", type.Name);
            for (int i = 0; i < records.Count; i++)
            {
                FieldHolder holder = records[i];
                if (holder.Type != typeof(bool))
                {
                    string text = holder.Type.IsEnum ? Enum.GetUnderlyingType(holder.Type).Name : holder.Type.Name;
                    writer.WriteLine("\t\t\t\tnobj.{0} = ({1})DBConvert.ChangeType(data[{2}], typeof({3}));", new object[] { holder.Name, holder.Type.Name, i, text });
                }
                else
                {
                    writer.WriteLine("\t\t\t\tnobj.{0} = (int)DBConvert.ChangeType(data[{1}], typeof(int)) > 0;", holder.Name, i);
                }
            }
            writer.WriteLine("\n\t\t\tnobj.ObjectId = DBConvert.ToUInt32(data[{0}]);", records.Count);
            writer.WriteLine("\t\t}\n");
        }

        private static void GenerateFooter(TextWriter writer)
        {
            writer.WriteLine("\t}\n");
            writer.WriteLine("}\n");
        }

        private static void GenerateGet(TextWriter writer, Type type, List<FieldHolder> records)
        {
            writer.WriteLine("\t\tpublic object[] GetValues(DataObject obj)");
            writer.WriteLine("\t\t{");
            writer.WriteLine("\t\t\t{0} nobj = obj as {0};\n", type.Name);
            writer.WriteLine("\t\t\tobject [] result = new object[{0}];\n", records.Count + 1);
            for (int i = 0; i < records.Count; i++)
            {
                FieldHolder holder = records[i];
                writer.WriteLine("\t\t\tresult[{0}] = nobj.{1};", i, holder.Name);
            }
            writer.WriteLine("\n\t\t\tresult[{0}] = nobj.ObjectId;", records.Count);
            writer.WriteLine("\n\t\t\treturn result;");
            writer.WriteLine("\t\t}\n");
        }

        private void GenerateHeader(TextWriter writer, Type type, ArrayList namespaces)
        {
            foreach (string text in namespaces)
            {
                writer.WriteLine("using {0};", text);
            }
            writer.WriteLine("\nnamespace {0}.Proxies\n{{", base.GetType().Namespace);
            writer.WriteLine("\tpublic class {0}Proxy : IDataProxy", type.Name);
            writer.WriteLine("\t{\n");
        }

        public void GenerateProxy(Type type)
        {
            List<FieldHolder> records = new List<FieldHolder>();
            List<RelationFieldHolder> relations = new List<RelationFieldHolder>();
            ArrayList namespaces = new ArrayList();
            namespaces.Add(base.GetType().Namespace);
            this.m_names.Add(type.Name + "Proxy", type);
            this.processType(type, records, relations, namespaces, string.Empty);
            string path = string.Format(@"{0}\{1}Proxy.cs", this.m_files.TempDir, type.Name);
            using (FileStream stream = new FileStream(path, FileMode.Create, FileAccess.Write))
            {
                using (TextWriter writer = new StreamWriter(stream))
                {
                    this.GenerateHeader(writer, type, namespaces);
                    GenerateFill(writer, type, records);
                    GenerateGet(writer, type, records);
                    GenerateRelations(writer, type, relations);
                    GenerateSetRelation(writer, type, relations);
                    GenerateFooter(writer);
                }
            }
            this.m_files.AddFile(path, false);
        }

        private static void GenerateRelations(TextWriter writer, Type type, List<RelationFieldHolder> relations)
        {
            writer.WriteLine("\t\tpublic void ResolveRelations(DataObject obj, ObjectDatabase db, bool force, Type targetType)");
            writer.WriteLine("\t\t{");
            writer.WriteLine("\t\t\t{0} nobj = obj as {0};\n", type.Name);
            foreach (RelationFieldHolder holder in relations)
            {
                writer.WriteLine("\t\t\tif ((targetType == typeof({0})) || (force{1}))", holder.Type.Name, holder.Attribute.AutoLoad ? string.Format(" || (nobj.{0} == null)", holder.Name) : string.Empty);
                if (!holder.Attribute.UseZero)
                {
                    writer.WriteLine("\t\t\tif (nobj.{0} != 0)", holder.Attribute.LocalField);
                }
                switch (holder.ArrayType)
                {
                    case 1:
                    {
                        writer.WriteLine("\t\t\t\tnobj.{0} = ({1}[])(new ArrayList(db.FindObjectsByField(typeof({1}), \"{2}\", nobj.{3})).ToArray(typeof({1})));", new object[] { holder.Name, holder.Type.Name, holder.Attribute.RemoteField, holder.Attribute.LocalField });
                        continue;
                    }
                    case 2:
                    {
                        writer.WriteLine("\t\t\t\tnobj.{0} = (PooledList<{1}>)db.FindObjectsByField(typeof({1}), \"{2}\", nobj.{3});", new object[] { holder.Name, holder.Type.Name, holder.Attribute.RemoteField, holder.Attribute.LocalField });
                        continue;
                    }
                }
                writer.WriteLine("\t\t\t\tnobj.{0} = ({1})db.FindObjectByField(typeof({1}), \"{2}\", nobj.{3});", new object[] { holder.Name, holder.Type.Name, holder.Attribute.RemoteField, holder.Attribute.LocalField });
            }
            writer.WriteLine("\t\t}\n");
        }

        private static void GenerateSetRelation(TextWriter writer, Type type, List<RelationFieldHolder> relations)
        {
            writer.WriteLine("\t\tpublic void SetRelationCollection(DataObject obj, Type targetType, Array data)");
            writer.WriteLine("\t\t{");
            writer.WriteLine("\t\t\t{0} nobj = obj as {0};\n", type.Name);
            foreach (RelationFieldHolder holder in relations)
            {
                switch (holder.ArrayType)
                {
                    case 1:
                    {
                        writer.WriteLine("\t\t\tif (targetType == typeof({0}))", holder.Type.Name);
                        writer.WriteLine("\t\t\t\tnobj.{0} = ({1}[])data;", holder.Name, holder.Type.Name);
                        continue;
                    }
                    case 2:
                    {
                        writer.WriteLine("\t\t\tif (targetType == typeof({0}))", holder.Type.Name);
                        writer.WriteLine("\t\t\t\tnobj.{0} = new PooledList<{1}>(({1}[])data);", holder.Name, holder.Type.Name);
                        continue;
                    }
                }
            }
            writer.WriteLine("\t\t}\n");
        }

        public object[] GetValues(DataObject obj)
        {
            IDataProxy proxy = this[obj.GetType()];
            if (proxy != null)
            {
                return proxy.GetValues(obj);
            }
            return null;
        }

        private static bool isComplexType(Type type)
        {
            if ((!type.IsPrimitive && !type.IsEnum) && (!type.IsArray && (type != typeof(string))))
            {
                return (type != typeof(DateTime));
            }
            return false;
        }

        private void parseDataElements(MemberInfo member, List<FieldHolder> records, List<RelationFieldHolder> relations, ArrayList namespaces, string preffix)
        {
            Type propertyType;
            object[] customAttributes = member.GetCustomAttributes(typeof(DataElementAttribute), true);
            if (customAttributes.Length != 0)
            {
                if (member is PropertyInfo)
                {
                    propertyType = ((PropertyInfo) member).PropertyType;
                    goto Label_0045;
                }
                if (member is FieldInfo)
                {
                    propertyType = ((FieldInfo) member).FieldType;
                    goto Label_0045;
                }
            }
            return;
        Label_0045:
            if (!namespaces.Contains(propertyType.Namespace))
            {
                namespaces.Add(propertyType.Namespace);
            }
            if (!this.m_assemblies.Contains(propertyType.Assembly))
            {
                this.m_assemblies.Add(propertyType.Assembly);
            }
            if ((propertyType.BaseType != null) && !this.m_assemblies.Contains(propertyType.BaseType.Assembly))
            {
                this.m_assemblies.Add(propertyType.BaseType.Assembly);
            }
            DataElementAttribute attribute = (DataElementAttribute) customAttributes[0];
            string name = member.Name;
            if (preffix != string.Empty)
            {
                name = preffix + "." + name;
            }
            if (propertyType.IsArray && (attribute.ArraySize != 0))
            {
                Type type = propertyType.GetElementType();
                if (isComplexType(type))
                {
                    for (int i = 0; i < attribute.ArraySize; i++)
                    {
                        this.processType(type, records, relations, namespaces, string.Format("{0}[{1}]", name, i));
                    }
                }
                else
                {
                    for (int j = 0; j < attribute.ArraySize; j++)
                    {
                        records.Add(new FieldHolder(string.Format("{0}[{1}]", name, j), type));
                    }
                }
            }
            else if (isComplexType(propertyType))
            {
                this.processType(propertyType, records, relations, namespaces, name);
            }
            else
            {
                records.Add(new FieldHolder(name, propertyType));
            }
        }

        private void parseRelations(MemberInfo member, ArrayList namespaces, List<RelationFieldHolder> relations)
        {
            Type propertyType;
            RelationAttribute attr;
            object[] customAttributes = member.GetCustomAttributes(typeof(RelationAttribute), true);
            if (customAttributes.Length != 0)
            {
                if (member is PropertyInfo)
                {
                    propertyType = ((PropertyInfo) member).PropertyType;
                    goto Label_0045;
                }
                if (member is FieldInfo)
                {
                    propertyType = ((FieldInfo) member).FieldType;
                    goto Label_0045;
                }
            }
            return;
        Label_0045:
            attr = (RelationAttribute) customAttributes[0];
            byte arrayType = 0;
            if (propertyType.IsArray)
            {
                arrayType = 1;
                propertyType = propertyType.GetElementType();
            }
            else if (propertyType.IsGenericType)
            {
                arrayType = 2;
                propertyType = propertyType.GetGenericArguments()[0];
                if (!namespaces.Contains(typeof(PooledList<object>).Namespace))
                {
                    namespaces.Add(typeof(PooledList<object>).Namespace);
                }
                if (!this.m_assemblies.Contains(typeof(PooledList<object>).Assembly))
                {
                    this.m_assemblies.Add(typeof(PooledList<object>).Assembly);
                }
            }
            relations.Add(new RelationFieldHolder(member.Name, propertyType, attr, arrayType));
            if (!namespaces.Contains(typeof(ArrayList).Namespace))
            {
                namespaces.Add(typeof(ArrayList).Namespace);
            }
        }

        private void processType(Type type, List<FieldHolder> records, List<RelationFieldHolder> relations, ArrayList namespaces, string preffix)
        {
            if (!namespaces.Contains(type.Namespace))
            {
                namespaces.Add(type.Namespace);
            }
            if (!this.m_assemblies.Contains(type.Assembly))
            {
                this.m_assemblies.Add(type.Assembly);
            }
            foreach (MemberInfo info in type.GetMembers(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            {
                this.parseDataElements(info, records, relations, namespaces, preffix);
                this.parseRelations(info, namespaces, relations);
            }
        }

        public void Register(Type type, IDataProxy proxy)
        {
            lock (this.m_proxies)
            {
                this.m_proxies[type] = proxy;
            }
        }

        public void Unregister(Type type)
        {
            lock (this.m_proxies)
            {
                this.m_proxies.Remove(type);
            }
        }

        public IDataProxy this[Type type]
        {
            get
            {
                lock (this.m_proxies)
                {
                    if (this.m_proxies.ContainsKey(type))
                    {
                        return (IDataProxy) this.m_proxies[type];
                    }
                    Console.WriteLine("No proxy for type {0}", type);
                    return null;
                }
            }
        }

        private class FieldHolder
        {
            public string Name;
            public System.Type Type;

            public FieldHolder(string name, System.Type type)
            {
                this.Name = name;
                this.Type = type;
            }
        }

        private class RelationFieldHolder
        {
            public byte ArrayType;
            public RelationAttribute Attribute;
            public string Name;
            public System.Type Type;

            public RelationFieldHolder(string name, System.Type type, RelationAttribute attr, byte arrayType)
            {
                this.Name = name;
                this.Type = type;
                this.Attribute = attr;
                this.ArrayType = arrayType;
            }
        }
    }
}

