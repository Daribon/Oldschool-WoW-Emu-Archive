using System;
using System.Collections;
using System.Collections.Generic;
using System.Text;
using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Map;
using RunWoW.Misc;
using RunWoW.MiscPackets;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.ExternalScripts.MiscPackets
{
	[PacketHandlerClass]
	internal class AuctionHouse
	{
		public static int AUCTION_LIST_SIZE = 50;

		public enum AUCTION_MAIL_TYPE
		{
			OUTBID = 0,
			WON = 1,
			SUCCESS = 2,
			EXPIRED = 3,
			CANCELLED = 5,
		}

		public enum AUCTION_HOUSE
		{
			STORMWIND = 1,
			IRONFORGE = 2,
			DARNASUS = 3,
			UNDERCITY = 4,
			THUNDERBLUFF = 5,
			ORGRIMMAR = 6,
			GOBLIN = 7,
		}

		public enum AUCTION_COMMAND
		{
			CREATED = 0,
			CANCELLED = 1,
			BID_ACCEPTED = 2,
		}

		public enum AUCTION_ERR
		{
			BAG_FULL = 1,
			INTERNAL_ERR = 2,
			NO_MONEY = 3,
			ITEM_NOT_FOUND = 4,
			BID_TO_LOW = 5,
			BID_INCREMENT_TOO_SMALL = 7,
			CANNOT_BID_OWN_AUCTION = 10,
			TRIAL_ACCOUNT = 13,
		}

		[PacketHandler(CMSG.AUCTION_LIST_BIDDER_ITEMS, ExecutionPriority.Pool)]
		public static void GetBidderItems(ClientBase client, BinReader data)
		{
			//int id = data.ReadInt32();
		}

		[PacketHandler(CMSG.AUCTION_LIST_ITEMS, ExecutionPriority.Pool)]
		public static void DoListItems(ClientBase client, BinReader data)
		{
			ulong guid = data.ReadUInt64();
			int start = data.ReadInt32();
			string criteria = data.ReadString();
			byte minLevel = data.ReadByte();
			byte maxLevel = data.ReadByte();
			int slot_id = data.ReadInt32();
			int rootFolder = data.ReadInt32();
			int subFolder = data.ReadInt32();
			int rarity = data.ReadInt32();
			int showUsable = data.ReadByte();
			maxLevel = maxLevel == 0 ? (byte) 0xFF : maxLevel;
			minLevel = minLevel == 1 ? (byte) 0 : minLevel;

			long timein = CustomDateTime.Now.Ticks;

			ClientData Client = (ClientData) client.Data;
			PlayerObject Player = Client.Player;

			int pool_id = GetPoolID((UnitBase)Player.GetNearUnit(guid));

			// prepare where clause
			StringBuilder where = new StringBuilder();
			//string where = string.Empty;

			if (minLevel != 0)
				where.AppendFormat(" AND ItemLevel >= {0}", minLevel);
			if (maxLevel != 0xFF)
				where.AppendFormat(" AND ItemLevel <= {0}", maxLevel);
			if (rootFolder != -1)
				where.AppendFormat(" AND ItemClass = {0}", rootFolder);
			if (subFolder != -1)
				where.AppendFormat(" AND ItemSubClass = {0}", subFolder);
			if (rarity != -1)
				where.AppendFormat(" AND ItemQuality = {0}", rarity);
			if (slot_id != -1)
				where.AppendFormat(" AND ItemInventoryType = {0}", slot_id);
			
			if (criteria.Length > 0)
				where.AppendFormat(" AND ItemName LIKE '%{0}%'", criteria.Replace("'", "''"));

			ICollection auctions =
				Database.Instance.SelectObjects(typeof (DBAuction),
				                                string.Format(
				                                	"AuctionPoolID={0} AND ExpirationTime > {1} {2} ORDER BY Auction_ID DESC", pool_id,
				                                	Database.Instance.PrepareData(typeof (DBAuction), CustomDateTime.Now), where));
			
			int auctions_total = auctions.Count;
			int auctions_in_list = auctions.Count - start;
			auctions_in_list = auctions_in_list > AUCTION_LIST_SIZE ? AUCTION_LIST_SIZE : auctions_in_list;

			ShortPacket pckg = new ShortPacket(SMSG.AUCTION_LIST_RESULT);

			pckg.Write(auctions_in_list); //  Auction items count in current list
			int i = 0;
			int end = start + auctions_in_list;
			foreach (DBAuction auction in auctions)
			{
				if (i >= start)
					WriteAuctionItem(auction, pckg);

				if (i++ >= end - 1)
					break;
			}

			pckg.Write(auctions_total); //  Items total
			//pckg.Write(-1); //  Items total
			client.Send(pckg);
			LogConsole.WriteLine(LogLevel.TRACE,
			                     "Auction search  process time: " +
			                     (new TimeSpan(CustomDateTime.Now.Ticks - timein).TotalMilliseconds));
		}

		private static void WriteAuctionItem(DBAuction auction, ShortPacket pkg)
		{
			ICollection bids = Database.Instance.FindObjectsByField(typeof (DBBid), "AuctionID", auction.ObjectId);
			DBBid highBid = null;

			foreach (DBBid bid in bids)
				if (highBid == null || highBid.BidAmount < bid.BidAmount)
					highBid = bid;

			pkg.Write((int) auction.ObjectId); // Auction ID
			pkg.Write(auction.ItemTemplateID); // item template id
			
			if (Constants.BurningCrusade)
			{
				if (auction.Item == null)
					Database.Instance.ResolveRelations(auction, typeof(DBItem));

				if (auction.Item == null)
					pkg.Write(new byte[72]);
				else
				{
					for (int i = 0; i < 7; i++)
					{
						pkg.Write(auction.Item.Enchantments[i].ID);
						pkg.Write(auction.Item.Enchantments[i].Charges);
					}

					// gems?
					pkg.Write(0);
					pkg.Write(0);
					pkg.Write(0);
					pkg.Write(0);
				}
			} else
				pkg.Write(auction.ItemEnchantments); // Enchant

			pkg.Write(auction.ItemRandomProperties); // Random Enchant ( of the ... ) 
			pkg.Write(0); // ???  - ������ �������� ��� �� :)
			pkg.Write(auction.ItemStackCount); // items in stack
			pkg.Write(0);
			pkg.Write(0);  // new ???
			pkg.Write((ulong) auction.OwnerID); // Owner ID
			pkg.Write(auction.StartPrice); // Start Bid  ?
			pkg.Write(CalcBidIncrement(auction.StartPrice)); // Bid minimum increment 
			pkg.Write(auction.BuyOutPrice); // Buy Out Price
			pkg.Write((int) (new TimeSpan(auction.ExpirationTime.Ticks - CustomDateTime.Now.Ticks).TotalMilliseconds));
			//Time to expire  in msecs
			pkg.Write(highBid != null ? highBid.BidderID : 0); // Bidder ID
			pkg.Write(0); // ???
			pkg.Write(highBid != null ? highBid.BidAmount : 0); // current bid
		}


		[PacketHandler(CMSG.AUCTION_LIST_OWNER_ITEMS, ExecutionPriority.Pool)]
		public static void DoListOwnAuctions(ClientBase client, BinReader data)
		{
			ulong guid = data.ReadUInt64();
			int start_from = data.ReadInt32();

			long timein = CustomDateTime.Now.Ticks;
			ClientData Client = (ClientData) client.Data;
			PlayerObject Player = Client.Player;
			int pool_id = GetPoolID((UnitBase)Player.GetNearUnit(guid));


			List<DBAuction> myAuctions = new List<DBAuction>();

			ICollection auctions = Database.Instance.FindObjectsByField(typeof (DBAuction), "OwnerID", Player.CharacterID);
			foreach (DBAuction auction in auctions)
				if (auction.PoolID == pool_id)
					myAuctions.Add(auction);

			int auctions_in_list = myAuctions.Count - start_from;
			auctions_in_list = auctions_in_list > AUCTION_LIST_SIZE ? AUCTION_LIST_SIZE : auctions_in_list;

			ShortPacket pckg = new ShortPacket(SMSG.AUCTION_OWNER_LIST_RESULT);

			pckg.Write(auctions_in_list); //  Bids in list
			for (int i = start_from; i < start_from + auctions_in_list; i++)
			{
				WriteAuctionItem(myAuctions[i], pckg);
			}
			pckg.Write(myAuctions.Count); //  Bids count
			client.Send(pckg);
			LogConsole.WriteLine(LogLevel.TRACE,
			                     "Auction: Own auctions process time: " +
			                     new TimeSpan(CustomDateTime.Now.Ticks - timein).TotalMilliseconds);
		}


		[PacketHandler(CMSG.AUCTION_LIST_BIDDER_ITEMS, ExecutionPriority.Pool)]
		public static void DoListBids(ClientBase client, BinReader data)
		{
			ulong guid = data.ReadUInt64();
			int start = data.ReadInt32();

			long timein = CustomDateTime.Now.Ticks;

			ClientData Client = (ClientData) client.Data;
			PlayerObject Player = Client.Player;

			ICollection placedBids = Database.Instance.FindObjectsByField(typeof (DBBid), "BidOwnerID", Player.CharacterID);

			Hashtable mUsedCheck = new Hashtable();

			CustomArrayList mAuctionsUsed = new CustomArrayList();

			int pool_id = GetPoolID((UnitBase) Player.GetNearUnit(guid));

			foreach (DBBid bid in placedBids)
			{
				if (mUsedCheck.ContainsKey(bid.AuctionID))
					continue;

				/// FUCK!!! this shit will read 100-200 auctions from DB without caching
				/// Update: tweaked it slightly to check before search
				DBAuction auction = (DBAuction) Database.Instance.FindObjectByKey(typeof (DBAuction), bid.AuctionID);

				if (auction != null && !mUsedCheck.ContainsKey(auction.ObjectId) && auction.PoolID == pool_id)
				{
					mUsedCheck.Add(auction.ObjectId, "");
					mAuctionsUsed.Add(auction);
				}
			}
			mUsedCheck.Clear();
			//mUsedCheck  = null;

			int auctions_in_list = mAuctionsUsed.Count - start;
			auctions_in_list = auctions_in_list > AUCTION_LIST_SIZE ? AUCTION_LIST_SIZE : auctions_in_list;

			ShortPacket pckg = new ShortPacket(SMSG.AUCTION_BIDDER_LIST_RESULT);

			pckg.Write(auctions_in_list); //  Bids in list
			for (int i = start; i < start + auctions_in_list; i++)
			{
				WriteAuctionItem((DBAuction) mAuctionsUsed[i], pckg);
			}
			pckg.Write(mAuctionsUsed.Count); //  Bids count
			client.Send(pckg);
			LogConsole.WriteLine(LogLevel.TRACE,
			                     "Auction: Bid list process time: " +
			                     new TimeSpan(CustomDateTime.Now.Ticks - timein).TotalMilliseconds);
		}

		[PacketHandler(CMSG.AUCTION_PLACE_BID, ExecutionPriority.Pool)]
		public static void PlaceBid(ClientBase client, BinReader data)
		{
			ulong guid = data.ReadUInt64();
			int auctionId = data.ReadInt32();
			int bidAmount = data.ReadInt32();

			ClientData Client = (ClientData) client.Data;
			PlayerObject Player = Client.Player;

			// Too high bid - need log
			if (bidAmount > 50000000 || bidAmount < 0)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Auction:PlaceBid(): Too high bid. ({0}) Char: {1}:{2} bid amount: {3}",
				                     auctionId, Player.Name, ((ClientData) client.Data).Account.LastIP, bidAmount);
			}


			int house = GetAuctionHouseZone(guid, client);

			DBAuction auction = (DBAuction) Database.Instance.FindObjectByKey(typeof (DBAuction), auctionId);

			if (auction == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Auction:PlaceBid(): Invalid Auction ID. ({0}) Char: {1} bid amount: {2}",
				                     auctionId, Player.Name, bidAmount);
				CommandResponse(client, auctionId, 0, AUCTION_ERR.INTERNAL_ERR);
				return;
			}

			DBItem item = (DBItem) Database.Instance.FindObjectByKey(typeof (DBItem), auction.ItemID);

			if (item == null)
			{
				CommandResponse(client, auctionId, 0, AUCTION_ERR.INTERNAL_ERR);
				return;
			}

			DBCharacter AuctionOwner = ClientManager.GetCharacter(auction.OwnerID);

			if (AuctionOwner == null)
			{
				CommandResponse(client, auctionId, 0, AUCTION_ERR.INTERNAL_ERR);
				return;
			}

			// I hate it
			// TODO: Rebuild it to use ICollection and foreach

			ICollection existingBids = Database.Instance.FindObjectsByField(typeof (DBBid), "AuctionID", auctionId);

			int bid_Increment = existingBids.Count == 0 ? 0 : CalcBidIncrement(auction.StartPrice);

			DBBid PreviousBid = null;

			foreach (DBBid bid in existingBids)
				if (bid.BidderID == Player.CharacterID)
				{
					PreviousBid = bid;
					break;
				}


			DBBid highBid = null;

			// Determine high bidder 
			foreach (DBBid bid in existingBids)
				if (highBid == null || bid.BidAmount > highBid.BidAmount)
					highBid = bid;


			if (bidAmount < auction.StartPrice || (highBid != null && bidAmount <= highBid.BidAmount))
			{
				CommandResponse(client, auctionId, 0, AUCTION_ERR.BID_TO_LOW);
				return;
			}

			if ((bidAmount - auction.StartPrice) < bid_Increment)
			{
				CommandResponse(client, auctionId, 0, AUCTION_ERR.BID_INCREMENT_TOO_SMALL);
				return;
			}

			if (AuctionOwner.AccountID == Player.Character.AccountID && Player.AccessLvl < ACCESSLEVEL.GM)
			{
				CommandResponse(client, auctionId, 0, AUCTION_ERR.CANNOT_BID_OWN_AUCTION);
				return;
			}

			bidAmount = (bidAmount >= auction.BuyOutPrice && auction.BuyOutPrice != 0) ? (int) auction.BuyOutPrice : bidAmount;

			int bid_diff = (int) (PreviousBid != null ? bidAmount - PreviousBid.BidAmount : 0);
			int toPay = bid_diff != 0 ? bid_diff : bidAmount;
			if (Player.Money < toPay)
			{
				CommandResponse(client, auctionId, 0, AUCTION_ERR.NO_MONEY);
				return;
			}

			Player.Money -= toPay;
			Player.Redress();
			Player.UpdateData();
			Player.Save();

			// Buy out item 
			if (auction.BuyOutPrice > 0 && bidAmount >= auction.BuyOutPrice)
			{
				foreach (DBBid bid in existingBids)
				{
					// Create return money to bidder via mail 

					if (PreviousBid == null || PreviousBid.ObjectId != bid.ObjectId)
					{
						Mail.CreateAuctionMail(bid.BidderID, null, item.TemplateID, (int) bid.BidAmount,
						                       (int) AUCTION_MAIL_TYPE.OUTBID, house, "");
						NotifyBidder(auction.ObjectId, bid.BidderID, bidAmount, item);
					}

					DBManager.EraseDBObject(bid);
				}


				// Auction Won mail for winner.
				string m_breport = string.Format("          {0}:{1}:{2}", auction.OwnerID.ToString("x"), bidAmount, bidAmount);
				//    seller:sale_price:buy_type:deposit:auction_cut

				Mail.CreateAuctionMail(Player.CharacterID, item, item.TemplateID, 0, (int) AUCTION_MAIL_TYPE.WON, house,
				                       m_breport);

				NotifyBidder(auction.ObjectId, Player.CharacterID, 0, item);

				// Auction success mail for seller.
				// Calc Cut Fee
				int cut = CalcCutFee(auction, house, bidAmount);
				int deposit = CalcDeposit(item.Template.SellPrice, (int) auction.TradeTime, house);
				int winmoney = bidAmount - cut + deposit;

				string m_report =
					string.Format("          {0}:{1}:{2}:{3}:{4}", Player.CharacterID.ToString("x"), bidAmount, bidAmount, deposit, cut);
				//    seller:sale_price:buy_type:deposit:auction_cut

				Mail.CreateAuctionMail(auction.OwnerID, null, item.TemplateID, winmoney, (int) AUCTION_MAIL_TYPE.SUCCESS, house,
				                       m_report);

				DBManager.EraseDBObject(auction);
				NotifyOwner(auction.ObjectId, auction.OwnerID, bidAmount, item);
				return;
			}


			//Return money to previous bidders
			foreach (DBBid bid in existingBids)
			{
				//Mail.CreateAuctionMail( bidderChar, null, (int)item.TemplateID, (int)ExistenBids[i].BidAmount, (int)AUCTION_MAIL_TYPE.OUTBID, house, "");
				//DBManager.EraseDBObject(ExistenBids[i]);
				if (bid.BidderID != Player.CharacterID)
					NotifyBidder(auction.ObjectId, bid.BidderID, bidAmount, item);
			}

			if (PreviousBid == null)
			{
				DBBid obj = new DBBid();
				obj.AuctionID = (uint) auctionId;
				obj.BidderID = Player.CharacterID;
				obj.BidAmount = (uint) bidAmount;
				DBManager.NewDBObject(obj);
				auction.LastBid = obj.BidAmount;
			}
			else
			{
				PreviousBid.BidAmount = (uint) bidAmount;
				DBManager.SaveDBObject(PreviousBid);
				auction.LastBid = PreviousBid.BidAmount;
			}

			DBManager.SaveDBObject(auction);

			CommandResponse(client, auctionId, AUCTION_COMMAND.BID_ACCEPTED, 0);
		}

		public static int CalcCutFee(DBAuction auction, int house, int winbid)
		{
			double time_passed = new TimeSpan(auction.ExpirationTime.Ticks - CustomDateTime.Now.Ticks).TotalMinutes;

			time_passed = time_passed < 0 ? 0 : time_passed;
			double buy_modifier = 1 - time_passed/auction.TradeTime;
			int retval = (int) ((house != 7 ? 0.05 : 0.15)*winbid*buy_modifier);

			return retval;
		}

		[PacketHandler(CMSG.AUCTION_SELL_ITEM, ExecutionPriority.Pool)]
		public static void DoCreateAuction(ClientBase client, BinReader data)
		{
			ulong guid = data.ReadUInt64();
			ulong item_guid = data.ReadUInt64();
			int start_bid = data.ReadInt32();
			int buy_out = data.ReadInt32();
			int time = data.ReadInt32();

			ClientData Client = (ClientData) client.Data;
			PlayerObject Player = Client.Player;

			ItemObject pItem = Player.Inventory.FindItem(item_guid);

			if (pItem == null)
			{
				LogConsole.WriteLine(LogLevel.WARNING, "Auction:DoCreateAuction():Invalid Item ID. (" + item_guid + ")");
				CommandResponse(client, 0, 0, AUCTION_ERR.ITEM_NOT_FOUND);
				return;
			}

			if (pItem.Soulbound)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Cheat:" + Player.Name + ":Try send soulbound item via auction.");
				return;
			}


			int house = GetAuctionHouseZone((ulong) guid, client);

			int deposit = CalcDeposit(pItem.Template.SellPrice, time, house);

			if (Player.Money < deposit)
			{
				CommandResponse(client, 0, 0, AUCTION_ERR.NO_MONEY);
				return;
			}

			Player.Money -= (int) deposit;

			UnitBase unit = (UnitBase) Player.GetNearUnit(guid);
			int pool_id = GetPoolID(unit);
			//int faction = Faction.IsAlliance(unit.Faction) ? 1 : Faction.IsHorde(unit.Faction) ? 2 : 0;

			// Calc Deposit value
			//double modifier = time == 120 ? .05 : time == 480 ? 0.2 : 0.6;
			//modifier = faction == 0 ? modifier*5 : modifier;


			//Move item to hidden container , also update player 
			Mail.HideItem(Player, pItem);

			DBAuction auction = new DBAuction();
			auction.BuyOutPrice = (uint) buy_out;
			auction.CreateTime = CustomDateTime.Now;
			auction.ExpirationTime = CustomDateTime.Now.AddMinutes(time);
			auction.TradeTime = (uint) time;
			auction.ItemID = pItem.DBItem.ObjectId;
			auction.OwnerID = Player.CharacterID;
			auction.PoolID = (uint) pool_id;
			auction.StartPrice = (uint) start_bid;
			auction.House = (uint) house;
			auction.LastBid = 0;

			auction.ItemClass = (uint) pItem.DBItem.Template.Class;
			auction.ItemSubClass = (uint) pItem.DBItem.Template.SubClass;
			auction.ItemInventoryType = (uint) pItem.DBItem.Template.InvType;
			auction.ItemLevel = (uint) pItem.DBItem.Template.ReqLevel;
			auction.ItemEnchantments = (uint) pItem.Enchantments[0].ID;
			auction.ItemRandomProperties = (uint) pItem.DBItem.RandomPropertyID;
			auction.ItemName = (string) pItem.DBItem.Template.Name;
			auction.ItemQuality = (uint) pItem.DBItem.Template.OverallQuality;
			auction.ItemStackCount = (uint) pItem.DBItem.StackCount;
			auction.ItemTemplateID = (uint) pItem.DBItem.TemplateID;

			auction.ItemStackCount = auction.ItemStackCount < 1 ? 1 : auction.ItemStackCount;
			DBManager.NewDBObject(auction);

			CommandResponse(client, (int) auction.ObjectId, AUCTION_COMMAND.CREATED, 0);
		}


		[PacketHandler(CMSG.AUCTION_REMOVE_ITEM, ExecutionPriority.Pool)]
		public static void DoCancelAuction(ClientBase client, BinReader data)
		{
			ulong guid = data.ReadUInt64();
			int auction_id = data.ReadInt32();

			DBAuction Auction = (DBAuction) Database.Instance.FindObjectByKey(typeof (DBAuction), auction_id);
			// Create Cancelled mail for auc owner
			DBItem item = (DBItem) Database.Instance.FindObjectByKey(typeof (DBItem), Auction.ItemID);


			ICollection bids = Database.Instance.FindObjectsByField(typeof (DBBid), "AuctionID", Auction.ObjectId);

			DBBid highBid = null;

			// Determine high bidder 
			foreach (DBBid bid in bids)
				if (highBid == null || bid.BidAmount > highBid.BidAmount)
					highBid = bid;

			ClientData Client = (ClientData) client.Data;
			PlayerObject Player = Client.Player;

			// If we have Bid on this auction - player should pay 5% penalty to cancel this.
			if (highBid != null)
			{
				int penalty = (int) (highBid.BidAmount*0.05);
				if (Player.Money < penalty)
				{
					CommandResponse(client, auction_id, 0, AUCTION_ERR.NO_MONEY);
					return;
				}

				Player.Money -= penalty;
				Player.Redress();
				Player.UpdateData();
				Player.Save();

				// remove all bids
				foreach (DBBid bid in bids)
				{
					// Create return money to bidder mail 
					Mail.CreateAuctionMail(bid.BidderID, null, item.TemplateID, (int) bid.BidAmount,
					                       (int) AUCTION_MAIL_TYPE.CANCELLED, GetAuctionHouseZone(guid, client), "");
					DBManager.EraseDBObject(bid);
				}
			}

			Mail.CreateAuctionMail(Player.CharacterID, item, item.TemplateID, 0, (int) AUCTION_MAIL_TYPE.CANCELLED,
			                       GetAuctionHouseZone(guid, client), "");

			DBManager.EraseDBObject(Auction);

			CommandResponse(client, auction_id, AUCTION_COMMAND.CANCELLED, 0);
			return;
		}


		public static void NotifyOwner(uint auctionId, uint charguid, int bid, DBItem item)
		{
			ClientBase client = ClientManager.GetClient(charguid);
			// Notify client if he is online.
			if (client != null)
			{
				ShortPacket pckg = new ShortPacket(SMSG.AUCTION_OWNER_NOTIFICATION);
				pckg.Write(auctionId); // auction ID
				pckg.Write(bid); // sold price - if 0 - expired
				pckg.Write(0);
				pckg.Write(0);
				pckg.Write(0);
				pckg.Write(item.TemplateID); // item id
				pckg.Write(item.RandomPropertyID); //  Random enchantement
				client.Send(pckg);
			}
		}


		public static void NotifyBidder(uint auctionId, uint charguid, int bid, DBItem item)
		{
			ClientBase client = ClientManager.GetClient(charguid);
			// Notify client if he is online.
			if (client != null)
			{
				ShortPacket pckg = new ShortPacket(SMSG.AUCTION_BIDDER_NOTIFICATION);
				pckg.Write(2);
				pckg.Write(auctionId);
				pckg.Write(((ClientData) client.Data).Player.CharacterID); // player id ????
				pckg.Write(0);
				pckg.Write(bid); // 0 - won auction, > 0 - outbid auction, 
				pckg.Write(0);
				pckg.Write(item.TemplateID); // item id
				pckg.Write(item.RandomPropertyID); //  Random enchantement
				client.Send(pckg);
			}
		}


		public static void CommandResponse(ClientBase client, int auctionId, object response, object err)
		{
			ShortPacket pckg = new ShortPacket(SMSG.AUCTION_COMMAND_RESULT);
			pckg.Write(auctionId);
			pckg.Write((int) response);
			pckg.Write((int) err);
			client.Send(pckg);
		}

		/* Returns auction house.
        */

		public static int GetAuctionHouseZone(ulong npc, ClientBase client)
		{
			ClientData Client = (ClientData) client.Data;
			float water = -1000f;
			int area = 0;
			WorldMap.GetPoint((int) Client.Player.WorldMapID, Client.Player.Position.X,
			                  Client.Player.Position.Y, out water, out area, false);

			int ret = 0;

			switch (area)
			{
				case 1519:
				case 1617: // ?? real areaid returns from function above
					ret = (int) AUCTION_HOUSE.STORMWIND;
					break;
				case 1537:
				case 1:
				case 138: // ?? real areaid returns from function above
					ret = (int) AUCTION_HOUSE.IRONFORGE;
					break;
				case 1657:
				case 1662: // ?? real areaid returns from function above
					ret = (int) AUCTION_HOUSE.DARNASUS;
					break;
				case 1497:
				case 153:
				case 1339: // ?? real areaid returns from function above
					ret = (int) AUCTION_HOUSE.UNDERCITY;
					break;
				case 1637:
				case 14:
				case 370: // ?? real areaid returns from function above
					ret = (int) AUCTION_HOUSE.ORGRIMMAR;
					break;
				case 1638:
				case 215:
				case 820: // ?? real areaid returns from function above
					ret = (int) AUCTION_HOUSE.THUNDERBLUFF;
					break;
				default:
					ret = (int) AUCTION_HOUSE.GOBLIN;
					break;
			}
			return ret;
		}

		/* Calculates dposit required for item , depends from auction house and time
        */

		public static int CalcDeposit(int price, int time, int house)
		{
			double percent = 0.05;
			switch (time)
			{
				case 120:
					percent = 0.05;
					break;
				case 480:
					percent = 0.2;
					break;
				case 1440:
					percent = 0.6;
					break;
			}
			percent = house == (int) AUCTION_HOUSE.GOBLIN ? percent*5 : percent;
			return (int) (price*percent);
		}

		/* Calculates minimum bid increment, depends from start bid (5% and cut low coins)
        */

		private static int CalcBidIncrement(uint price)
		{
			return (int) (Math.Floor(price/200f))*10;
		}

		/* Returns auction pool id by Unit
        */

		private static int GetPoolID(UnitBase unit)
		{
			if (unit == null) return -1;
			int poolid = Faction.IsAlliance(unit.Faction) ? 1 : Faction.IsHorde(unit.Faction) ? 2 : 0;
			return poolid;
		}
	}
}