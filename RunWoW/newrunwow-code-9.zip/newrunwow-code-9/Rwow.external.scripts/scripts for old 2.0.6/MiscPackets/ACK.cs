using RunServer.Common;
using RunWoW.Common;

namespace RunWoW.MiscPackets
{
	[PacketHandlerClass()]
	public class ACK
	{
		[PacketHandler(CMSG.FORCE_RUN_SPEED_CHANGE_ACK, ExecutionPriority.Pool)]
		public static void OnForceSpeedChange(ClientBase client, BinReader data)
		{
			/*ClientData Client = (ClientData) client.Data;

			if (Client == null || Client.Player == null)
				return;

			ulong GUID = data.ReadUInt64();
			float speed1 =  data.ReadSingle();
			float speed2 =  data.ReadSingle();*/
			//Console.WriteLine("Speed ack for player: {0}, from {1}, to {2}", GUID, speed1, speed2); 

			//LogConsole.WriteLine(LogLevel.SYSTEM,"Speed ACK: " + Hexdump.ToString(data.GetBuffer(),data.BaseStream.Length));
		}

		[PacketHandler(CMSG.FORCE_RUN_BACK_SPEED_CHANGE_ACK, ExecutionPriority.Pool)]
		public static void OnForceRBSpeedChange(ClientBase client, BinReader data)
		{
		}
	}
}