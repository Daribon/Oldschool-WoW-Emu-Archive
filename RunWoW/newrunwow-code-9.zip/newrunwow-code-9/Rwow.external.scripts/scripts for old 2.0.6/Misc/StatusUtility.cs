using System;

namespace RunWoW.Misc
{
	public class StatusUtility
	{
		public static string FormatByteAmount(long totalBytes)
		{
			if (totalBytes > 1000000000)
				return String.Format("{0:F1} GB", (double)totalBytes / 1073741824);

			if (totalBytes > 1000000)
				return String.Format("{0:F1} MB", (double)totalBytes / 1048576);

			if (totalBytes > 1000)
				return String.Format("{0:F1} KB", (double)totalBytes / 1024);

			return String.Format("{0} Bytes", totalBytes);
		}

		public static string FormatTimeSpan(TimeSpan ts)
		{
			return
				String.Format("{0:D2}d {1:D2}h {2:D2}m {3:D2}s {4:D3}ms", ts.Days, ts.Hours % 24, ts.Minutes % 60, ts.Seconds % 60,
							  ts.Milliseconds);
		}

		public static string FormatCPULoad(TimeSpan Ts, object lastTs, DateTime from, DateTime to)
		{
			return string.Format("{0:#0.##%}", GetCPULoad(Ts, lastTs, from, to));
		}

		public static float GetCPULoad(TimeSpan Ts, object lastTs, DateTime from, DateTime to)
		{
			float cpu = 0f;
			if (lastTs != null)
				cpu = (float)(Ts - ((TimeSpan)lastTs)).Ticks / (float)(to - from).Ticks;
			if (cpu < 0)
				cpu = 0f;
			return cpu;
		}
	}
}
