//
using System;
using RunServer.Database.Attributes;
using RunServer.Database;
using RunWoW.ServerDatabase;

namespace RunWoW.DB.DataTables
{
	[DataTable(TableName = "ItemRandomProperties")]
	public class DBItemRandomProperties : DBBase
	{
		[DataElement(Name = "Enchantment", ArraySize = 3)]
		public int[] m_effects = new int[3];

		[DataElement(Name = "Suffix")]
		public string m_suffix;

		[DataElement(Name = "Flags")]
		public int m_flags;


		public int[] EnchantEffect
		{
			get { return m_effects; }
		}

		public string Suffix
		{
			get { return m_suffix; }
		}

		public int Flags
		{
			get { return m_flags; }
		}

		public static void Initialize()
		{
			Database.Instance.RegisterDataObject<DBItemRandomProperties>(DBFlags.NoIndex, 1);
		}
	}
}
