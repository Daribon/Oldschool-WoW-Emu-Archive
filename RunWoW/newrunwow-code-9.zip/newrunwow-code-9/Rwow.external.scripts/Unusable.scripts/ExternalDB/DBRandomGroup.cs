//
using System;
using RunServer.Database.Attributes;
using RunServer.Database;
using RunWoW.ServerDatabase;

namespace RunWoW.DB.DataTables
{
	[DataTable(TableName = "RandomPropertiesGroups")]
	public class DBRandomGroup : DBBase
	{
		[DataElement(Name = "GroupID")]
		public int m_groupID;

		[DataElement(Name = "ItemRandomPropertiesID")]
		public int m_propID;

		[DataElement(Name = "Percent")]
		public float m_percent;
		

		public int GroupID
		{
			get { return m_groupID; }
		}

		public int RandomProperiesID
		{
			get { return m_propID; }
		}

		public float Percent
		{
			get { return m_percent; }
		}
		
		public static void Initialize()
		{
			Database.Instance.RegisterDataObject<DBRandomGroup>(DBFlags.NoIndex, 1);
		}
	}
}
