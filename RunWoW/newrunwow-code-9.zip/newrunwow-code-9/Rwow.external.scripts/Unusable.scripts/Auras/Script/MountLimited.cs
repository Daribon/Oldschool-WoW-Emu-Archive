using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.SpellAuras;

namespace RunWoW.ExternalScripts.Auras.Script
{
	// Disable AnQiraj mounts outside the AnQiraj temple. 
	internal class MountLimited : BaseAura
	{
		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			PlayerObject player = caster as PlayerObject;
			
			if (player != null)
				if (player.WorldMapID != 531)
				{
					Chat.System(player.BackLink.Client, "Can be mounted only in Temple Of Ahn`Qiraj.");
					return SpellFailedReason.MAX;
				}

			if (efnum == 0)
				MountAura.Apply(caster, target, castTarget, spell, efnum);
			else
				if (efnum == 1)
					Apply<SpeedAura>(caster, target, castTarget, spell, efnum);
			
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAuraEffectPatch(25953, 0, new AuraCast(Apply));
			AuraManager.RegisterAuraEffectPatch(25953, 1, new AuraCast(Apply));
			AuraManager.RegisterAuraEffectPatch(26054, 0, new AuraCast(Apply));
			AuraManager.RegisterAuraEffectPatch(26054, 1, new AuraCast(Apply));
			AuraManager.RegisterAuraEffectPatch(26056, 0, new AuraCast(Apply));
			AuraManager.RegisterAuraEffectPatch(26056, 1, new AuraCast(Apply));
			AuraManager.RegisterAuraEffectPatch(26055, 0, new AuraCast(Apply));
			AuraManager.RegisterAuraEffectPatch(26055, 1, new AuraCast(Apply));
		}
	}
}