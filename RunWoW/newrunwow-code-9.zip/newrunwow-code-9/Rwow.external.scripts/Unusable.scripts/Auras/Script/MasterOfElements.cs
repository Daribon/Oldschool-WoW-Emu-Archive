using System;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.SpellAuras;
using RunWoW.Spells;

namespace RunWoW.ExternalScripts.Auras.Script
{
	// Master of Elements mage spell 
	internal class MoEScript : BaseAura
	{
		private static DBSpell s_moeSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), 29077);
		
		private DateTime m_lastProc;

		private HitDelegate m_placeDamage;

		protected override bool AuraStart()
		{
			if (Target == null || LivingCaster == null)
				return false;

					m_placeDamage = new HitDelegate(OnPlaceHitProc);
					LivingTarget.OnSubmitDamage += m_placeDamage;
			m_lastProc = CustomDateTime.Now;
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null)
			{
				if (m_placeDamage != null)
					LivingTarget.OnSubmitDamage -= m_placeDamage;
			}
		}

		public void OnPlaceHitProc(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;

			if (!critical || (damageType != DAMAGETYPE.FIRE && damageType != DAMAGETYPE.FROST))
				return;
			
			if (m_lastProc + TimeSpan.FromMilliseconds(Constants.SpellProcDelay) > CustomDateTime.Now)
				return;

			m_lastProc = CustomDateTime.Now;

			int value = (int) (spell.PowerCost*SpellEffect.Value/100f);

			if (value + LivingCaster.Power > LivingCaster.MaxPower)
				value = LivingCaster.MaxPower - LivingCaster.Power;

			// TODO: think, how we can cast spell 29077 with custom value

			SpellManager.Cast(LivingCaster, LivingCaster, s_moeSpell);
			LivingCaster.Power += value;

			LivingCaster.UpdateData();
		}


		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAuraEffectPatch(29074, 0, new AuraCast(Apply<MoEScript>));
			AuraManager.RegisterAuraEffectPatch(29075, 0, new AuraCast(Apply<MoEScript>));
			AuraManager.RegisterAuraEffectPatch(29076, 0, new AuraCast(Apply<MoEScript>));
		}
	}
}