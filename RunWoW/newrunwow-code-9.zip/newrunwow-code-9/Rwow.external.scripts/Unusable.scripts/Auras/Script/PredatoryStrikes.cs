using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.SpellAuras;

namespace RunWoW.ExternalScripts.Auras.Script
{
	// Ignite mage spell
	internal class PredatoryStrikesScript : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerTarget == null)
				return false;

			PlayerTarget.FeralAPBonus = Spell.Rank/2f;
			return true;
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget != null)
				PlayerTarget.FeralAPBonus = 0;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAuraEffectPatch(16972, 0, new AuraCast(Apply<PredatoryStrikesScript>));
			AuraManager.RegisterAuraEffectPatch(16974, 0, new AuraCast(Apply<PredatoryStrikesScript>));
			AuraManager.RegisterAuraEffectPatch(16975, 0, new AuraCast(Apply<PredatoryStrikesScript>));
		}
	}
}