//
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.Spells;
using RunWoW.World;

namespace RunWoW.SpellAuras
{
	public class SShiftAura : BaseAura
	{
		private uint m_lspell;
		private int m_display;
		private ShapeshiftForm m_form;
		private POWERTYPE m_oldpowertype;

		private HitDelegate m_canceler;
		private CastDelegate m_castCanceler;

		public SShiftAura(ShapeshiftForm form)
		{
			m_form = form;
		}

		protected override bool AuraStart()
		{
			if (LivingTarget == null)
				return false;

			int n_display = 0;
			POWERTYPE newpower = POWERTYPE.MAX;

			switch (m_form)
			{
				case ShapeshiftForm.FORM_CAT:
					m_lspell = 3025;

					if (PlayerTarget != null && PlayerTarget.Character.Race == RACE.NIGHTELF)
						n_display = 892;
					else
						n_display = 8571;

					newpower = POWERTYPE.ENERGY;
					break;
				case ShapeshiftForm.FORM_TREE:
					m_lspell = 3122;
					break;
				case ShapeshiftForm.FORM_TRAVEL:
					m_lspell = 5419;
					n_display = 1043;
					break;
				case ShapeshiftForm.FORM_AQUA:
					m_lspell = 5421;
					n_display = 2428;

					if (PlayerTarget != null)
					{
						ShortPacket pkg = new ShortPacket(SMSG.STOP_MIRROR_TIMER);
						pkg.Write(1);
						PlayerTarget.BackLink.Client.Send(pkg);
					}
					break;
				case ShapeshiftForm.FORM_BEAR:
					m_lspell = 1178;

					if (PlayerTarget != null && PlayerTarget.Character.Race == RACE.NIGHTELF)
						n_display = 2281;
					else
						n_display = 2289;

					newpower = POWERTYPE.RAGE;
					break;
				case ShapeshiftForm.FORM_DIREBEAR:
					m_lspell = 9635;

					if (PlayerTarget != null && PlayerTarget.Character.Race == RACE.NIGHTELF)
						n_display = 2281;
					else
						n_display = 2289;

					newpower = POWERTYPE.RAGE;
					break;
				case ShapeshiftForm.FORM_MOONKIN:
					m_lspell = 24905;

					if (PlayerTarget != null && PlayerTarget.Character.Race == RACE.NIGHTELF)
						n_display = 15374;
					else
						n_display = 15375;

					break;
				case ShapeshiftForm.FORM_FLIGHT:
					m_lspell = 33948;
					break;
				case ShapeshiftForm.FORM_CREATUREBEAR:
					m_lspell = 2882;
					break;
				case ShapeshiftForm.FORM_DEFENSIVESTANCE:
					m_lspell = 7376;
					break;
				case ShapeshiftForm.FORM_BERSERKERSTANCE:
					m_lspell = 7381;
					break;
				case ShapeshiftForm.FORM_STEALTH:
					m_lspell = 2426;
					break;
				case ShapeshiftForm.FORM_GHOSTWOLF:
					n_display = 2446;
					break;
			}

			if (n_display != 0)
			{
				m_display = LivingTarget.DisplayID;
				LivingTarget.DisplayID = n_display;
			}

			if (m_lspell != 0)
			{
				DBSpell lspell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), m_lspell);
				if (lspell == null)
				{
					LogConsole.WriteLine(LogLevel.ERROR, "Linked spell not found " + m_lspell);
					m_lspell = 0;
				}
				else
					SpellManager.SelfCast(LivingTarget, lspell);
			}

			if (newpower != POWERTYPE.MAX)
			{
				if (PlayerTarget != null)
				{
					PlayerTarget.bOriginalClass = PlayerTarget.bClass;
					PlayerTarget.bClass = (newpower == POWERTYPE.RAGE)
					                      	? PlayerTarget.bRace.GetClass(CLASS.WARRIOR)
					                      	: PlayerTarget.bRace.GetClass(CLASS.ROGUE);
					PlayerTarget.HiddenPower = PlayerTarget.Power;
				}

				m_oldpowertype = LivingTarget.PowerType;
				LivingTarget.Power = 0;
				LivingTarget.PowerType = newpower;
				LivingTarget.Redress();
			}
			else
				m_oldpowertype = POWERTYPE.MAX;

			LivingTarget.SShift = (byte) m_form;

			if (Spell.Stealth)
			{
				IPacket pkg = null;// obj.DestroyPacket;

				foreach (MapTile tile in LivingTarget.MapTile.Adjacents.Tiles)
					if (tile != null && tile.Players != null)
						for (int i = 0; i < tile.Players.Last; i++)
						{
							PlayerObject player = tile.Players.InnerArray[i];
							if (player != null && !player.IsDisposed && player.CanSee_Destroy(LivingTarget))
							{
								if (pkg == null)
								{
									pkg = LivingTarget.DestroyPacket;
									pkg.Aquire();
								}
								player.BackLink.Client.Send(pkg);
							}
						}

				if (pkg != null)
					pkg.Release();
				
				LivingTarget.SFlags = 238;
				LivingTarget.Flags |= 0x2000000;
				LivingTarget.RunPose = 2;
				
				//LivingTarget.MapTile.Map.Reenter(LivingTarget);

				m_canceler = new HitDelegate(CancelStealth);
				m_castCanceler = new CastDelegate(CancelStealth);
				LivingTarget.OnSubmitDamage += m_canceler;
				LivingTarget.OnTakeDamage += m_canceler;
				LivingTarget.OnCast += m_castCanceler;
			}

			if (PlayerTarget != null)
				PlayerTarget.MountSpell = Spell.ObjectId;

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed)
				return;

			if (m_canceler != null)
			{
				LivingTarget.OnSubmitDamage -= m_canceler;
				LivingTarget.OnTakeDamage -= m_canceler;
			}

			if (m_castCanceler != null)
			{
				LivingTarget.OnCast -= m_castCanceler;
			}

			if (PlayerTarget != null)
				PlayerTarget.MountSpell = 0;

			if (m_display != 0)
			{
				LivingTarget.DisplayID = m_display;

				// OK, let's comment that shit.. But this make druid an umba-class
				//if (player != null)
				//{
				//    player.RegisterPermanentMods();
				//    player.EquipItems();
				//    player.Redress();
				//}
			}

			if (m_lspell != 0)
				LivingTarget.Auras.CancelAuraForce(m_lspell);

			if (m_oldpowertype != POWERTYPE.MAX)
			{
				if (PlayerTarget != null)
				{
					PlayerTarget.Power = PlayerTarget.HiddenPower;
					PlayerTarget.bClass = PlayerTarget.bOriginalClass;
				}

				LivingTarget.PowerType = m_oldpowertype;

				LivingTarget.Redress();
			}

			LivingTarget.SShift = 0;

			if (Spell.Stealth)
			{
				LivingTarget.SFlags = 0;
				LivingTarget.Flags &= ~0x2000000;
				LivingTarget.RunPose = 0;

				if (LivingTarget.MapTile != null)
				{
					IPacket create = null;

					foreach (MapTile tile in LivingTarget.MapTile.Adjacents.Tiles)
						if (tile != null && tile.Players != null)
							for (int i = 0; i < tile.Players.Last; i++)
							{
								PlayerObject player = tile.Players.InnerArray[i];
								if (player != null && !player.IsDisposed && player.CanSee_Create(LivingTarget))
								{
									if (create == null)
									{
										create = new CompressedA9Packet(LivingTarget.CreatePacketSmall);
										create.Aquire();
									}
									player.BackLink.Client.Send(create);
								}
							}

					if (create != null)
						create.Release();
				}
				/*try
				{
					LivingTarget.MapTile.Map.Reenter(LivingTarget);
				}
				catch (Exception exc)
				{
					LogConsole.WriteLine(LogLevel.ERROR, exc.StackTrace);
				}*/
			}

			if (PlayerTarget != null)
				SpellCastEvent.SendCoolDownEvent(PlayerTarget.BackLink.Client, PlayerTarget.GUID, Spell.ObjectId);
		}

		private void CancelStealth()
		{
			LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}

		private void CancelStealth(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell, ObjectBase enemy, bool critical)
		{
			if (spell == null || (spell.ObjectId != Spell.ObjectId && spell.ObjectId != m_lspell))
				CancelStealth();
		}

		private void CancelStealth(DBSpell spell, ObjectBase enemy)
		{
			if (spell.ObjectId != Spell.ObjectId && spell.ObjectId != m_lspell)
				CancelStealth();
		}

		public static SpellFailedReason
			Apply(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			ShapeshiftForm form = (ShapeshiftForm) spell.Effect[efnum].AuraParam;

			PlayerObject player = target as PlayerObject;

			if (player != null)
				switch (form)
				{
					case ShapeshiftForm.FORM_AQUA:
						if (!player.InWater)
							return SpellFailedReason.SPELL_FAILED_ONLY_UNDERWATER;
						goto case ShapeshiftForm.FORM_CAT;

					case ShapeshiftForm.FORM_CAT:
					case ShapeshiftForm.FORM_BEAR:
					case ShapeshiftForm.FORM_DIREBEAR:
					case ShapeshiftForm.FORM_TRAVEL:
					case ShapeshiftForm.FORM_TREE:
					case ShapeshiftForm.FORM_MOONKIN:
						if (player.Class != CLASS.DRUID)
							return SpellFailedReason.SPELL_FAILED_DONT_REPORT;
						break;
				}

			if (player != null && player.SShift == (byte) form)
			{
				target.Auras.Unregister(0, player.MountSpell);
				return SpellFailedReason.MAX;
			}

			IAura aura = new SShiftAura(form);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_SHAPESHIFT, new AuraCast(Apply));
		}
	}
}