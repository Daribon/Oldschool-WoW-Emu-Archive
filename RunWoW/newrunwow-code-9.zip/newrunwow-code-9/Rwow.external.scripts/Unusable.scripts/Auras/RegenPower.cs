using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.SpellAuras
{
	public class RegenPowerAura : BaseAura
	{
		private float m_amount;

		protected override bool AuraStart()
		{
			if (LivingTarget == null || Caster == null)
				return false;

			if (SpellEffect.AuraPeriod == 0)
			{
				Recalc(1000, Spell.Duration);
				m_amount = SpellEffect.Value / 5;
				m_amount = Caster.SpellProcessor.ProcessDamage(Spell, m_amount, Count);
			}
			else
			{
				Recalc(SpellEffect.AuraPeriod, Spell.Duration);

				if (SpellEffect.Aura == AURAEFFECT.PERIODIC_ENERGIZE)
					m_amount = Caster.SpellProcessor.FullDamage(Spell, Effect);
				else
					m_amount = Caster.SpellProcessor.PeriodicDamage(Spell, Effect, Count, 0);
			}

			if (m_amount <= 0)
				m_amount = 1;

			if (Spell.Food &&
			    (LivingTarget.StandState == UNITSTANDSTATE.STANDING || LivingTarget.StandState == UNITSTANDSTATE.KNEEL)
				)
			{
				LivingTarget.StandState = UNITSTANDSTATE.SITTING;
				LivingTarget.UpdateData();
			}

			return true;
		}

		protected override void AuraTick()
		{
			if (LivingTarget == null || !LivingTarget.Attackable)
			{
				Finish();
				return;
			}

			if (Spell.Food &&
			    (LivingTarget.StandState == UNITSTANDSTATE.STANDING || LivingTarget.StandState == UNITSTANDSTATE.KNEEL)
				)
			{
				Finish();
				return;
			}

			int value = (int) m_amount;

			if (value + LivingTarget.Power > LivingTarget.MaxPower)
				value = LivingTarget.MaxPower - LivingTarget.Power;

			if (value > 0)
				LivingTarget.Power += value;

			if (Spell.Food && base.Count % 5 == 0 && PlayerTarget != null && !PlayerTarget.IsDisposed)
			{
				ShortPacket pkg = new ShortPacket(SMSG.PLAY_SPELL_VISUAL);
				pkg.Write(Target.GUID);
				pkg.Write(438);
				PlayerTarget.BackLink.Client.Send(pkg);
			}
		}

		public static SpellFailedReason Apply(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell,
		                                      byte efnum)
		{
			if ((int) target.PowerType != spell.Effect[efnum].AuraParam)
				return SpellFailedReason.SPELL_FAILED_ALREADY_AT_FULL_POWER;
			
			if (caster is LivingObject && spell.SpellID == 2687) // Bloodrage do not cast aura if health not enough
			{
				int am = ((LivingObject) caster).MaxHealth/10;
				if (((LivingObject) caster).Health < am)
					return SpellFailedReason.MAX;
			}

			IAura aura = new RegenPowerAura();
			aura.Init(caster, target, castTarget, spell, efnum);
			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_POWER_REGEN, new AuraCast(Apply));
			AuraManager.RegisterAura(AURAEFFECT.PERIODIC_ENERGIZE, new AuraCast(Apply));
		}
	}
}