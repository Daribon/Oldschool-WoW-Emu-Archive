using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Auras;

namespace RunWoW.SpellAuras
{
	public class ManaShieldAura : BaseAura
	{
		private float m_value;
		private AbsorbCheckDelegate m_absorber;

        protected override bool AuraStart()
        {
            m_value = SpellEffect.Value;
			m_absorber = new AbsorbCheckDelegate(ApplyAbsorb);
			LivingTarget.OnAbsorbCheck += m_absorber;
            return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null)
                LivingTarget.OnAbsorbCheck -= m_absorber;
		}

		public void ApplyAbsorb(DAMAGETYPE damageType, bool spell, float damage, float resisted, out float absorbed)
		{
		    
			if (damageType == DAMAGETYPE.PHYSICAL)
			{
				float avalue = m_value;
				if (avalue > LivingTarget.Power/2)
                    avalue = LivingTarget.Power / 2;

				if (avalue > damage - resisted)
					absorbed = damage - resisted;
				else
					absorbed = avalue;

				m_value -= absorbed;

                LivingTarget.Power -= (int)(absorbed * 2);

				if (m_value <= 0)
                    LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
			}
			else
				absorbed = 0;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
            AuraManager.RegisterAura(AURAEFFECT.MANA_SHIELD, new AuraCast(Apply<ManaShieldAura>));
		}
	}
}