using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;

namespace RunWoW.SpellAuras
{
	public class TrackAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerTarget == null)
				return false;
			
			if (SpellEffect.Aura == AURAEFFECT.TRACK_CREATURES)
				PlayerTarget.TrackCreatures |= 1 << (SpellEffect.AuraParam - 1);
			else
				PlayerTarget.TrackResources |= 1 << (SpellEffect.AuraParam - 1);

			PlayerTarget.UpdateData();
			return true;
		}

		protected override void AuraFinish()
		{
			if (SpellEffect.Aura == AURAEFFECT.TRACK_CREATURES)
				PlayerTarget.TrackCreatures &= ~(1 << (SpellEffect.AuraParam - 1));
			else
				PlayerTarget.TrackResources &= ~(1 << (SpellEffect.AuraParam - 1));

			PlayerTarget.UpdateData();
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.TRACK_RESOURCES, new AuraCast(Apply<TrackAura>));
			AuraManager.RegisterAura(AURAEFFECT.TRACK_CREATURES, new AuraCast(Apply<TrackAura>));
		}
	}
}