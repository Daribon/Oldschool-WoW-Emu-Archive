using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.SpellAuras
{
	public class PeriodicSpellAura : BaseAura
	{
		private DBSpell m_targetSpell;

		private int m_fullDamage;
		private int m_tickCount = 1;
		private float m_PreviousDamage = 0;

		private PeriodicSpellAura(DBSpell targetSpell)
		{
			m_targetSpell = targetSpell;
		}

		protected override bool AuraStart()
		{
			if (Spell.Channeled) // TODO: remake channeled spells
			{
				AuraTick();
				return false;
			}
			else
			{
				m_fullDamage = (int) (SpellEffect.Value*Count);
				m_tickCount = Count;
				m_PreviousDamage = 0;
			}
			return true;
		}

		protected override void AuraTick()
		{
			if (
				LivingCaster == null ||
				LivingCaster.IsDisposed ||
				!LivingCaster.Attackable ||
				(LivingTarget != null && LivingTarget.Dead))
			{
				Finish();
				return;
			}

			// hrdcode for curse of agony (calc formula here instad of use dummy spell for each cast)
			switch (Spell.ObjectId)
			{
					// Curse of agony
				case 980:
				case 1014:
				case 6217:
				case 11711:
				case 11712:
				case 11713:
					int m_currentTick = m_tickCount - Count + 1;
					float a = 2f*m_fullDamage/m_tickCount/m_tickCount;
					float b = -a/10;
					float c = (m_fullDamage - b*Count*Count/2)*3/m_tickCount/m_tickCount/m_tickCount;
					float d = m_currentTick*m_currentTick*(c*m_currentTick/3f + b/2f);
					float damage = d - m_PreviousDamage;
					damage = damage < 1 ? 1 : damage;
					m_PreviousDamage = d;
					//damage = 0;	  // temporarry block damage
					LivingCaster.SubmitMagicDamage(LivingTarget, Spell, m_targetSpell.School, damage, damage);
					break;
			}

			SpellCastEvent cEvent = new SingleTargetCast(Caster, m_targetSpell, 2, CastTarget, false);
			cEvent.SendSpellStart();
			cEvent.FireEvent();
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null && LivingTarget.Auras != null)
				LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
		}


		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			DBSpell targetSpell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spell.Effect[efnum].Spell);
			if (targetSpell == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Trigger spell not found " + spell.Effect[efnum].Spell);
				return SpellFailedReason.SPELL_FAILED_UNKNOWN;
			}

			IAura aura = new PeriodicSpellAura(targetSpell);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.TRIGGER_PERIODIC_SPELL, new AuraCast(Apply));
		}
	}
}