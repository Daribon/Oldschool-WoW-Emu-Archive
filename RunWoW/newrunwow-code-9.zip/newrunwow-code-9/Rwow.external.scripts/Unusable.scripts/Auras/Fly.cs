using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Misc;

namespace RunWoW.SpellAuras
{
	public class FlyAura : BaseAura
	{
		protected override bool AuraStart()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return false;

			ShortPacket pkg = new ShortPacket((SMSG)835);
			pkg.WriteGuid(PlayerTarget.GUID);
			pkg.Write(2);
			PlayerTarget.BackLink.Client.Send(pkg);

			Teleport.SpeedChange(PlayerTarget, 30f, (SMSG)897); // TODO: move to another aura

			return true;
		}

		protected override void AuraFinish()
		{
			if (PlayerTarget == null || PlayerTarget.IsDisposed)
				return;

			ShortPacket pkg = new ShortPacket((SMSG)836);
			pkg.WriteGuid(PlayerTarget.GUID);
			PlayerTarget.BackLink.Client.Send(pkg);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.FLIGHT, new AuraCast(Apply<FlyAura>));
		}
	}
}