//
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.Objects.Misc;

namespace RunWoW.SpellAuras
{
	public class SimpleBuff : BaseAura
	{
		private ModifierPair m_mod;
		private MODIFIER m_index;

		protected override bool AuraStart()
		{
			float value = Caster.SpellProcessor.FullValue(Spell, Effect);

			switch (SpellEffect.Aura)
			{
				case AURAEFFECT.MOD_INCREASE_HEALTH:
					m_index = MODIFIER.MAX_HEALTH;
					break;
				case AURAEFFECT.MOD_INCREASE_ENERGY:
					m_index = MODIFIER.MAX_POWER;
					break;
				case AURAEFFECT.MOD_INCREASE_HEALTH_PERCENT:
					m_index = MODIFIER.MAX_HEL_PCT;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_INCREASE_ENERGY_PERCENT:
					m_index = MODIFIER.MAX_POW_PCT;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_DODGE_PERCENT:
					m_index = MODIFIER.DODGE_PCT;
					break;
				case AURAEFFECT.MOD_CRIT_PERCENT:
					m_index = MODIFIER.CRIT_PCT;
					break;
				case AURAEFFECT.MOD_TOTAL_THREAT:
					m_index = MODIFIER.THREAT;
					break;
				case AURAEFFECT.THREAT:
					m_index = MODIFIER.THREAT_PCT;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_SPELL_CRIT_CHANCE:
					m_index = MODIFIER.MAGIC_CRIT_PCT;
					break;
				case AURAEFFECT.MOD_PARRY_PERCENT:
					m_index = MODIFIER.PARRY_PCT;
					break;
				case AURAEFFECT.MOD_DAMAGE_DONE_PERCENT:
					m_index = MODIFIER.DAMAGE_PCT;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_OFFHAND_DAMAGE_PCT:
					m_index = MODIFIER.OFFHAND_DAMAGE_PCT;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_ATTACK_POWER:
					m_index = MODIFIER.ATTACK_POW;
					break;
				case AURAEFFECT.MOD_RANGED_ATTACK_POWER:
					m_index = MODIFIER.RANGED_POW;
					break;
				case AURAEFFECT.MOD_REGEN_PERCENT:
					m_index = MODIFIER.HEALTH_REGEN;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_POWER_REGEN_PERCENT:
					m_index = MODIFIER.POWER_REGEN;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_RAGE_GENERATION:
					m_index = MODIFIER.RAGE_GEN_PCT;
					value /= 100f;
					break;
				case AURAEFFECT.MOD_HIT_CHANCE:
					switch(Spell.ObjectId)
					{
						case 30816:
						case 30818:
						case 30819:
						case 30820:
						case 30821:
							m_index = MODIFIER.OFFHAND_DAMAGE_PCT;
							break;
						default:
							m_index = MODIFIER.HIT_PCT;
							break;
					}
					break;
				case AURAEFFECT.MOD_SPELL_HIT_CHANCE:
					m_index = MODIFIER.MAGIC_HIT_PCT;
					break;
				case AURAEFFECT.ATTACKSPEED:
				case AURAEFFECT.MOD_HASTE:
					m_index = MODIFIER.MELEE_HASTE_PCT;
					break;
                default:
					LogConsole.WriteLine(LogLevel.ERROR, "Unknown simple buff " + SpellEffect.Aura);
					return false;
			}
			m_mod =
				LivingTarget.Modifiers.RegisterModifier(m_index, value, !Visible ? UnitModifiers.DefaultKey : EffectKey);

			Cancelable = value > 0;

			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget == null || LivingTarget.IsDisposed || LivingTarget.Modifiers == null)
				return;
			
			LivingTarget.Modifiers.UnregisterModifier(m_index, m_mod);
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.MOD_INCREASE_HEALTH, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_INCREASE_ENERGY, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_INCREASE_HEALTH_PERCENT, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_INCREASE_ENERGY_PERCENT, new AuraCast(Apply<SimpleBuff>));
			
			AuraManager.RegisterAura(AURAEFFECT.MOD_CRIT_PERCENT, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_DODGE_PERCENT, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_PARRY_PERCENT, new AuraCast(Apply<SimpleBuff>));
			
			AuraManager.RegisterAura(AURAEFFECT.MOD_DAMAGE_DONE_PERCENT, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_OFFHAND_DAMAGE_PCT, new AuraCast(Apply<SimpleBuff>));
			
			AuraManager.RegisterAura(AURAEFFECT.MOD_ATTACK_POWER, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_RANGED_ATTACK_POWER, new AuraCast(Apply<SimpleBuff>));
			
			AuraManager.RegisterAura(AURAEFFECT.ATTACKSPEED, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_HASTE, new AuraCast(Apply<SimpleBuff>));
                                                
			AuraManager.RegisterAura(AURAEFFECT.MOD_REGEN_PERCENT, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_POWER_REGEN_PERCENT, new AuraCast(Apply<SimpleBuff>));

			AuraManager.RegisterAura(AURAEFFECT.MOD_SPELL_CRIT_CHANCE, new AuraCast(Apply<SimpleBuff>));

			AuraManager.RegisterAura(AURAEFFECT.MOD_RAGE_GENERATION, new AuraCast(Apply<SimpleBuff>));
			
			AuraManager.RegisterAura(AURAEFFECT.MOD_HIT_CHANCE, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.MOD_SPELL_HIT_CHANCE, new AuraCast(Apply<SimpleBuff>));

			AuraManager.RegisterAura(AURAEFFECT.MOD_TOTAL_THREAT, new AuraCast(Apply<SimpleBuff>));
			AuraManager.RegisterAura(AURAEFFECT.THREAT, new AuraCast(Apply<SimpleBuff>));
		}
	}
}