using System;
using System.Collections;
using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Auras;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.SpellAuras
{
	public class TriggerSpellAura : BaseAura
	{
		private CastDelegate m_cast;
		private HitDelegate m_takeDamage;
		private HitDelegate m_placeDamage;
		private HitDelegate m_casterTakeDamage;

		private DBSpell m_targetSpell;
		private float m_chance;
		private BitArray m_bitflags;

		private DateTime m_lastProc;

		private int m_charges;

		private string m_spellName;
		private bool m_critical;

		private TimeSpan m_procDelay;


		private TriggerSpellAura(DBSpell mtspell, bool critical)
		{
			m_targetSpell = mtspell;
			m_critical = critical;
		}

		protected override bool AuraStart()
		{
			if (Spell.Name.StartsWith("Improved "))
				m_spellName = Spell.Name.Substring("Improved ".Length);
			else
				m_spellName = string.Empty;

			m_charges = Spell.ProcCharges;
			m_chance = (Spell.ProcChance == 101 ? m_targetSpell.ProcChance : Spell.ProcChance) / 100f;

			/*if (Spell.ProcChance == 101 && m_targetSpell.ProcChance == 101)
				m_chance = 0.01f;

			if (m_chance == 1f && (Spell.ProcFlags & 20) == 20)
				m_chance = 0.04f;

			if (m_targetSpell.ObjectId == 5530) // Mace Specialization fix
				m_chance = Spell.Rank / 50f;*/

			if (TriggerDamage.PPMSpells.ContainsKey(Spell.ObjectId))
				m_procDelay = TimeSpan.FromSeconds(60 / TriggerDamage.PPMSpells[Spell.ObjectId]);
			else
				m_procDelay = TimeSpan.FromMilliseconds(Constants.SpellProcDelay);


			m_bitflags = new BitArray(new int[] { Spell.ProcFlags });


			// Didn`t find in spells flags wich means cancel aura after one shot.. used bit 15 - seems correct, but.. TODO
			m_charges = (m_bitflags[15] && m_charges == 0) ? 1 : m_charges;

			if (m_chance <= 0f)
			{
				if (m_charges > 0)
					m_chance = 1f;
				else
				{
					LogConsole.WriteLine(LogLevel.ERROR, "Spell {0} has zero proc chance!", m_targetSpell.Name);
					return false;
				}
			}

			LogConsole.WriteLine(LogLevel.ECHO, "Registering proc spell {0}. flags {1}", Spell, Spell.ProcFlags);
			/*
			 * 
			 * Burning Crusade Proc Flags
			 * 0 - none
			 * 1 - on opponent kill
			 * 2:4 - on submit damage (melee)
			 * 3:8 - on take damage (melee)
			 * 4:16 - on submit damage (used with 3)
			 * 5:32 - on take damage (used with 8)
			 * 6:64 - on submit ranged damage
			 * 7:128 - on take randed damage
			 * 8:256 - on submit magic damage
			 * 9:512 - on take magic damage
			 * 10:1024 - combo proc
			 * 11:2048 - none
			 * larger - some complex flags
			 */

			if (Spell.ProcFlags == 0x15550) // cast
			{
				m_cast = new CastDelegate(OnCastProc);
				LivingTarget.OnCast += m_cast;
			}
			else
			{
				if (
					m_bitflags[2] ||
					m_bitflags[4] ||
					m_bitflags[6] ||
					m_bitflags[8] ||
					m_bitflags[10] ||
					m_bitflags[12] ||
					m_bitflags[16]
					)
				{
					m_placeDamage = new HitDelegate(OnPlaceHitProc);
					LivingTarget.OnSubmitDamage += m_placeDamage;
				}

				if (
					m_bitflags[3] ||
					m_bitflags[5] ||
					m_bitflags[7] ||
					m_bitflags[9]
					)
				{
					m_takeDamage = new HitDelegate(OnTakeHitProc);
					LivingTarget.OnTakeDamage += m_takeDamage;
				}
			}

			m_lastProc = CustomDateTime.Now;
			return true;
		}

		protected override void AuraFinish()
		{
			if (LivingTarget != null)
			{
				if (m_placeDamage != null)
					LivingTarget.OnSubmitDamage -= m_placeDamage;
				if (m_takeDamage != null)
					LivingTarget.OnTakeDamage -= m_takeDamage;
				if (m_cast != null)
					LivingTarget.OnCast -= m_cast;

				if (LivingCaster != null && m_casterTakeDamage != null)
					LivingCaster.OnTakeDamage -= m_casterTakeDamage;
			}
		}

		public void OnTakeHitProc(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell,
								  ObjectBase enemy, bool critical)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;

			if (m_lastProc + m_procDelay > CustomDateTime.Now)
				return;

			/// TODO: refactor this
			if (
					(m_bitflags[3] && category == DAMAGECATEGORY.MELEE) ||
					(m_bitflags[5] && category == DAMAGECATEGORY.MELEE) ||
					(m_bitflags[7] && category == DAMAGECATEGORY.RANGED) ||
					(m_bitflags[9] && category == DAMAGECATEGORY.MAGIC)
				)
			{
				m_lastProc = CustomDateTime.Now;

				if (Utility.Chance(m_chance + 0.02f * (LivingTarget.Level - enemy.Level)))
				{
					SpellCastEvent cEvent = new SingleTargetCast(LivingTarget, m_targetSpell, 2, enemy, false);
					cEvent.SendSpellStart();
					cEvent.FireEvent();

					if (m_charges > 0)
					{
						m_charges--;
						if (m_charges == 0)
							LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
					}
				}
			}
		}

		public void OnPlaceHitProc(DAMAGETYPE damageType, DAMAGECATEGORY category, float damage, DBSpell spell,
								   ObjectBase enemy, bool critical)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;

			if (m_spellName != string.Empty && spell != null && m_spellName != spell.Name)
				return;

			if (m_lastProc + m_procDelay > CustomDateTime.Now)
				return;

			if (PlayerTarget != null && (Spell.RequiredItemClass != -1 || (spell != null && spell.RequiredItemClass != -1)))
			{
				ItemObject weapon = PlayerTarget.Inventory[INVSLOT.MAINHAND];
				if (weapon == null)
					return;

				DBSpell toCheck = spell != null && Spell.RequiredItemClass == -1 ? spell : Spell;

				if (!toCheck.AcceptItem(weapon.Template))
					return;
			}

			if (m_critical && !critical)
				return;

			/// TODO: refactor this
			if (
					(m_bitflags[2] && category == DAMAGECATEGORY.MELEE) ||
					(m_bitflags[4] && category == DAMAGECATEGORY.MELEE) ||
					(m_bitflags[6] && category == DAMAGECATEGORY.RANGED) ||
					(m_bitflags[8] && category == DAMAGECATEGORY.MAGIC)
				)
			{
				m_lastProc = CustomDateTime.Now;


				if (Utility.Chance(m_chance))
				{
					SpellCastEvent cEvent = new SingleTargetCast(LivingTarget, m_targetSpell, 2, enemy, false);
					cEvent.SendSpellStart();
					cEvent.FireEvent();

					if (m_charges != 0)
					{
						m_charges--;
						if (m_charges == 0)
							LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
					}
				}
			}
		}

		public void OnCastProc(DBSpell spell, ObjectBase enemy)
		{
			LivingObject lenemy = enemy as LivingObject;

			if (lenemy == null || !lenemy.Attackable || lenemy.IsDisposed)
				return;


			if (m_lastProc + m_procDelay > CustomDateTime.Now)
				return;

			if (m_spellName != string.Empty && m_spellName != spell.Name)
				return;

			m_lastProc = CustomDateTime.Now;

			if (Utility.Chance(m_chance))
			{
				SpellCastEvent cEvent = new SingleTargetCast(LivingTarget, m_targetSpell, 2, enemy, false);
				cEvent.SendSpellStart();
				cEvent.FireEvent();

				if (m_charges != 0)
				{
					m_charges--;
					if (m_charges == 0)
						LivingTarget.Auras.CancelAuraForce(Spell.ObjectId);
				}
			}
		}

		public static SpellFailedReason Apply
			(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte efnum)
		{
			DBSpell targetSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), spell.Effect[efnum].Spell);

			if (targetSpell == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "Trigger spell not found " + spell.Effect[efnum].Spell);
				return SpellFailedReason.SPELL_FAILED_UNKNOWN;
			}

			if (spell.MaxRange > 0)
			{
				float dist = caster.Position.Distance(target.Position);
				if (dist > spell.MaxRange)
					return SpellFailedReason.SPELL_FAILED_OUT_OF_RANGE;
				else if (dist < spell.MinRange)
					return SpellFailedReason.SPELL_FAILED_TOO_CLOSE;
			}

			bool critical = false;
			switch (spell.ObjectId)
			{
				// Flurry
				case 16256:
				case 16281:
				case 16282:
				case 16283:
				case 16284:
					critical = true;
					break;
			}

			IAura aura = new TriggerSpellAura(targetSpell, critical);
			aura.Init(caster, target, castTarget, spell, efnum);

			AuraTickManager.Instance.Register(aura);
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Second)]
		public new static void Initialize()
		{
			AuraManager.RegisterAura(AURAEFFECT.TRIGGER_SPELL, new AuraCast(Apply));
		}
	}
}