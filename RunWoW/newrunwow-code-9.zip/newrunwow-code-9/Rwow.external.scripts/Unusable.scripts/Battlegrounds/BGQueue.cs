using System;
using System.Collections.Generic;
using System.Text;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using System.Collections;
using RunWoW.ServerScripts.Misc;

namespace RunWoW.ExternalScripts.Battlegrounds
{
	class BGQueue : Event
	{
		public QueueList m_pWaitQueue = new QueueList();
		public QueueList m_pActiveQueue = new QueueList();
		public QueueList m_pInviteQueue = new QueueList();
		private int m_pPlayersPerSide = 10;
		private int m_pMinPlayersToStart = 5;
		//private int m_pMinPlayersToStart = 0;		
		private Battleground m_pBGInstance;
		protected ArrayList m_pTimeWait = new ArrayList();
		protected int m_pAvTime = 0;

		public static Hashtable m_pBGPlayerTable = new Hashtable();

		public ArrayList ActivePlayers 
		{
			get { return m_pActiveQueue; }
		}

		public int ActiveHordeCount
		{
			get { return m_pActiveQueue.Horde; }
		}

		public int ActiveAllianceCount
		{
			get { return m_pActiveQueue.Alliance; }
		}
		
		public BGQueue( Battleground bg, int pperside )  : base(TimeSpan.FromSeconds(0), TimeSpan.FromSeconds(5))
		{
			m_pPlayersPerSide = pperside;
			m_pBGInstance = bg;
		}

		public BGPlayer CreateBGPlayer(PlayerObject player)
		{
			if (!m_pBGPlayerTable.Contains(player.GUID))
			{
				BGPlayer bPlayer = new BGPlayer(player);
				m_pBGPlayerTable.Add(player.GUID, bPlayer);
				return bPlayer;
			}
			return (BGPlayer)m_pBGPlayerTable[player.GUID];
		}

		public BGPlayer GetPlayer(PlayerObject player)
		{
			if (player != null )
				return (BGPlayer)m_pBGPlayerTable[player.GUID];
			return null;
		}

        public void ErasePlayer(PlayerObject player)
        {
            try
            {
				BGPlayer bp = GetPlayer(player);
				if (bp != null)
				{
					m_pBGPlayerTable.Remove(player.GUID);
					bp.Release();
				}
            }
            catch (Exception e)
            {
                //LogConsole.Write( LogLevel.ERROR, e.ToString());
				CustomLog.WriteLine(e.ToString(), "BG", "BGLogs");
            }
        }
	    
		public int AverageTime()
		{
			// TODO: Need calc average time , how long wait until player can enter to BG
			if (m_pAvTime == 0 && m_pTimeWait.Count > 0 )
			{
				int ret = 0;
				foreach(int time in m_pTimeWait)
					ret += time;
				m_pAvTime = ret/m_pTimeWait.Count;
			}
			return m_pAvTime;
		}

		internal QUEUE_STATUS GetQueueStatus(BGPlayer player)
		{
			if (m_pActiveQueue.Contains(player))
				return QUEUE_STATUS.IN_ACTION;

			if (m_pWaitQueue.Contains(player))
				return QUEUE_STATUS.WAIT_IN_QUEUE;

			return QUEUE_STATUS.NOT_IN_QUEUE;
		}

		internal void AddToWait(BGPlayer player)
		{
			Remove(player, false);
			player.Status = QUEUE_STATUS.WAIT_IN_QUEUE;
			m_pWaitQueue.Add(player);
		}

		internal void AddToGame(BGPlayer player)
		{
			Remove(player,false);
			player.Status = QUEUE_STATUS.IN_ACTION;
			m_pActiveQueue.Add(player);
			
			int jTime = (int) new TimeSpan(CustomDateTime.Now.Ticks - player.JoinTime.Ticks).TotalMilliseconds;
			m_pTimeWait.Add(jTime);
			if ( m_pTimeWait.Count > 10 )
				m_pTimeWait.Remove(m_pTimeWait[0]);
		}

		internal void Remove(BGPlayer player )
		{
			Remove(player, true);
		}
		
		internal void Remove(BGPlayer player , bool erase)
		{
			if (player == null) return;
			
			if (m_pWaitQueue.Contains(player))
				m_pWaitQueue.Remove(player);
			else if (m_pActiveQueue.Contains(player))
				m_pActiveQueue.Remove(player);
			else if (m_pInviteQueue.Contains(player))
				m_pInviteQueue.Remove(player);
			player.Status = QUEUE_STATUS.NOT_IN_QUEUE;
			if (erase )
				ErasePlayer(player.Player);
		}

		protected override void OnTick()
		{
			// free active and wait queue from disconnected players 
			lock (m_pActiveQueue)
			{
				for (int i = m_pActiveQueue.Count - 1; i >= 0; i--)
				{
					BGPlayer player = (BGPlayer)m_pActiveQueue[i];
					if (player.Player == null || player.Player.IsDisposed || player.Player.WorldMapID != m_pBGInstance.WorldMapID )
					{
						//Remove(player);
						m_pBGInstance.LeaveBGPlayer(player);
						CustomLog.WriteLine("Remove player from active queue: " + player, "BG", "BGLogs");
					}
				}
			}

			lock (m_pWaitQueue)
			{
				for (int i = m_pWaitQueue.Count - 1; i >= 0; i--)
				{
					BGPlayer player = (BGPlayer)m_pWaitQueue[i];
					if (player.Player == null || player.Player.IsDisposed)
					{
						Remove(player);
						CustomLog.WriteLine("Remove player from waiting queue: " + player, "BG", "BGLogs");
						
					}
				}
			}


			// check if player too long in invite state or disconnected
			lock (m_pInviteQueue)
			{
				for (int i = m_pInviteQueue.Count - 1; i >= 0; i--)
				{
					BGPlayer player = (BGPlayer)m_pInviteQueue[i];

					int timeInInvite = (int)(new TimeSpan(CustomDateTime.Now.Ticks - player.InviteTime.Ticks).TotalMilliseconds );

					if (player.Player == null || player.Player.IsDisposed || timeInInvite > BGConstants.WAIT_INVITE_TIME)
					{
						if (player.Player != null && !player.Player.IsDisposed)
							BattleManager.Status(player.Player.BackLink.Client, null);
						Remove(player);
					}
				}
			}

			int allyFreeSpace	= m_pPlayersPerSide - m_pActiveQueue.Alliance	+ m_pInviteQueue.Alliance;
			int hordeFreeSpace	= m_pPlayersPerSide - m_pActiveQueue.Horde		+ m_pInviteQueue.Horde;

			allyFreeSpace	= m_pBGInstance.GameStatus() != BG_STATUS.PROCESS ? 0 : allyFreeSpace;
			hordeFreeSpace	= m_pBGInstance.GameStatus() != BG_STATUS.PROCESS ? 0 : hordeFreeSpace;
			// invite some new players to game

			// lock wait que - due we notify player and this action can cause modify this queue
			lock (m_pWaitQueue )
			{
				lock (m_pInviteQueue)
				{
					if (allyFreeSpace > 0 || hordeFreeSpace > 0 )
					{
						foreach (BGPlayer player in m_pWaitQueue )
						{
							if (BattleManager.IsAlliance(player.Player.Faction))
							{
								if ( m_pActiveQueue.Alliance < m_pPlayersPerSide )
								{
									player.Status = QUEUE_STATUS.INVITED;
									player.InviteTime = CustomDateTime.Now;
									BattleManager.Status(player.Player.BackLink.Client, null);
									m_pInviteQueue.Add(player);
									CustomLog.WriteLine("Invite a player: " + player.Player.Name + " , " + hordeFreeSpace + " , " + allyFreeSpace, "BG", "BGLogs");
									allyFreeSpace--;
									if (allyFreeSpace <= 0)
										break;
								} 
							} else
							{
								if (m_pActiveQueue.Horde < m_pPlayersPerSide)
								{
									player.Status = QUEUE_STATUS.INVITED;
									player.InviteTime = CustomDateTime.Now;
									BattleManager.Status(player.Player.BackLink.Client, null);
									CustomLog.WriteLine("Invite h player: " + player.Player.Name + " , " + hordeFreeSpace + " , " + allyFreeSpace, "BG", "BGLogs");
									m_pInviteQueue.Add(player);
									hordeFreeSpace--;
									if (hordeFreeSpace <= 0)
										break;
								}
							}
						}
					}

					foreach (BGPlayer bp in m_pInviteQueue)
					{
						if ( m_pWaitQueue.Contains(bp) )
							m_pWaitQueue.Remove(bp);
					}
					
					
				}
			}
			//----------------------------------------------------------------------------


			// if we have enough free space - invite players in wait queue to join for game.



			// move waiting players to acitve queue  if Bg ready for play

			/*
			lock (m_pWaitQueue)
			{
				lock (m_pActiveQueue)
				{
					if (m_pBGInstance.GameStatus() == BG_STATUS.PROCESS)
					{
						for (int i = 0; i < m_pWaitQueue.Count; i++)
						{
							BGPlayer player = (BGPlayer)m_pWaitQueue[i];

							if ((allyFreeSpace > 0 && BattleManager.IsAlliance(player.Player.Faction)) ||
							    (hordeFreeSpace > 0 && BattleManager.IsHorde(player.Player.Faction)))
							{
								m_pWaitQueue.Remove(player);
								BattleManager.Status(player.Player.BackLink.Client, null);
								m_pInviteQueue.Add(player);
								i--;
							}
						}
					}
				}
			}
			*/
			
			// Initial start game
			if ( m_pBGInstance.GameStatus() == BG_STATUS.INITIAL )
			{
				if (m_pWaitQueue.Alliance >= m_pMinPlayersToStart && m_pWaitQueue.Horde >= m_pMinPlayersToStart)
				{
					m_pBGInstance.StartTime = CustomDateTime.Now;
					m_pBGInstance.ChangeStatus(BG_STATUS.PROCESS);
				} else if ( m_pWaitQueue.Alliance == 1 )
				{
					//m_pBGInstance.StartTime = CustomDateTime.Now;
					//m_pBGInstance.ChangeStatus(BG_STATUS.PROCESS);
				}
			}
			
			
		}

		public class QueueList : ArrayList
		{
			int allyCount	= 0;
			int hordeCount	= 0;

			public int Alliance
			{
				get { return allyCount; }
			}

			public int Horde
			{
				get { return hordeCount; }
			}

			public void Add(BGPlayer player) 
			{
				base.Add(player);
				if (BattleManager.IsAlliance(player.Faction))
					allyCount++;
				else
					hordeCount++;

				if ( !m_pBGPlayerTable.Contains(player.Player.GUID) )
					m_pBGPlayerTable.Add(player.Player.GUID, player);
			}

			public void Remove(BGPlayer player)
			{
				base.Remove(player);
				if (BattleManager.IsAlliance(player.Faction))
					allyCount--;
				else
					hordeCount--;

				player.Status = QUEUE_STATUS.NOT_IN_QUEUE;
				m_pBGPlayerTable.Remove(player);
			}

		}

	}
}
