using System;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Hearthstone
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("hearthstone", "", new ChatCommand(OnHearthstone));
		}

		private static bool OnHearthstone(ClientBase client, string input)
		{
			ClientData Client = (ClientData)client.Data;

			ItemObject hs = Client.Player.Inventory.FindItem(6948);
			if (hs != null)
				if (hs.Cooldown > CustomDateTime.Now)
					SpellCastEvent.SpellCastResult(client, 0, SpellFailedReason.SPELL_FAILED_ITEM_NOT_READY);
				else
					GamePackets.Spells.DoCastItem(client, hs, 0, 2, null, null, null, CustomDateTime.Now);
			/*else
						Teleport.TeleportTo(Client.Player.Character.BindPoint,Client.Player.Character.BindWorld,Client.Player);*/
			else
				Chat.System(client, "You do not have a hearthstone!");
			return true;
		}

	}
}