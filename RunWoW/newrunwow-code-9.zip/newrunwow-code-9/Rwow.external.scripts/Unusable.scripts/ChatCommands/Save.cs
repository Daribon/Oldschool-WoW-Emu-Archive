using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Save
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("save", "", new ChatCommand(OnSave));
		}

		private static bool OnSave(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			Database.Instance.WriteDatabaseTables();
			Chat.System(client, "Database saved");
			
			return true;
		}
	}
}