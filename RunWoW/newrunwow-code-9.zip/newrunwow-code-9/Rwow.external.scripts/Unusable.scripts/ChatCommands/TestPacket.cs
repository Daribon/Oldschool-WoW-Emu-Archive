using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;

namespace RunWoW.ChatCommands
{
	public class TestPacket
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("test", "cast <packerid>", new ChatCommand(OnTest));
		}

		private static bool OnTest(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine(
				"Chat command: " + input + ", Selection: " +
				(Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: cast <spellid>");
				return true;
			}
			int packetid = 0;
			try
			{
				packetid = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid packet id!");
				return true;
			}

			ShortPacket pkg = new ShortPacket((SMSG) packetid);
			pkg.WriteGuid(Client.Player.GUID);
			client.Send(pkg);

			return true;
		}
	}
}