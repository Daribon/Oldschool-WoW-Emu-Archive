using System.Collections;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.World;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class GORemove
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("goremove", "", new ChatCommand(OnGORemove));
		}

		private static bool OnGORemove(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			GameObject go = null;
			double rng = double.MaxValue;

			foreach (MapTile mapTile in Client.Player.MapTile.Adjacents.Tiles)
				if (mapTile!=null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection!=null)
						foreach (GameObject gameObject in collection)
						if (gameObject != null)
						{
							double nrng = gameObject.Position.DistanceSqrd(Client.Player.Position);
							if (nrng < rng)
							{
								rng = nrng;
								go = gameObject;
							}
						}
				}

			if (go == null)
			{
				Chat.System(client, "No game Objects found!");
				return true;
			}

			DBManager.EraseDBObject(go.DBGameObject);
			go.Dispose();
			
			Chat.System(client, "Removed object " + go.Name);
			return true;
		}
	}
}