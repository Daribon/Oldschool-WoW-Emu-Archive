using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class HonourKills
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("kills", "", new ChatCommand(OnHonourKills));
			ChatManager.RegisterChatCommand("hkills", "", new ChatCommand(OnHonourKills));
		}

		private static bool OnHonourKills(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			Chat.System(client, "Honourable kills: " + Client.Player.Character.HKills);
			Chat.System(client, "Dishonourable kills: " + Client.Player.Character.DHKills);
			Chat.System(client, "Honor points: " + Client.Player.Character.Honor);
			Chat.System(client, "Weekly Rank points: " + Client.Player.Character.RPAll);
			Chat.System(client, "Rank points: " + Client.Player.Character.RankPoints);
			return true;
		}

	}

}