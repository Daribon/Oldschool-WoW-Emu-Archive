using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common;
using RunWoW.Spells;

namespace RunWoW.ChatCommands
{
	public class CastCommand
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("cast", "cast <spellid>", new ChatCommand(OnCast));
		}

		private static bool OnCast(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: cast <spellid>");
				return true;
			}
			int spellid = 0;
			try
			{
				spellid = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid spell id!");
				return true;
			}
			DBSpell spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellid);
			if (spell == null)
			{
				Chat.System(client, "Not valid spell id!");
				return true;
			}
			ObjectBase target = Client.Player.Selection;
			if (target == null)
			{
				Chat.System(client, "No target selected!");
				return true;
			}
			SpellManager.Cast(Client.Player, target, spell);
			/*
			SpellCastEvent steach = new SingleTargetCast(Client.Player, spell, 2, target);
			steach.SendSpellStart();
			steach.FireEvent();
			*/
			return true;
		}
	}
}