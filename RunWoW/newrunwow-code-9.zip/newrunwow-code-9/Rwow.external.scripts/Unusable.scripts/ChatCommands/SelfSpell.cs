using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Misc;
using RunWoW.ServerDatabase;
using RunServer.Common;
using RunWoW.Spells;

namespace RunWoW.ChatCommands
{
	public class SelfSpell
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("selfspell", "", new ChatCommand(OnSelfSpell));
		}

		private static bool OnSelfSpell(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: selfspell <spellid>");
				return true;
			}
			int spellid = 0;
			try
			{
				spellid = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid spell id!");
				return true;
			}
			DBSpell spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellid);
			if (spell == null)
			{
				Chat.System(client, "Not valid spell id!");
				return true;
			}
			SpellCastEvent steach = new SingleTargetCast(Client.Player, spell, 2, Client.Player, false);
			steach.SendSpellStart();
			steach.FireEvent();
			//SpellManager.SelfCast(Client.Player, spell);
			return true;
		}
	}
}