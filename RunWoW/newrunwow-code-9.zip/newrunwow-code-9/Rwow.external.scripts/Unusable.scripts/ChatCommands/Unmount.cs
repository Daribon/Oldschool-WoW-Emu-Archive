using RunWoW.Accounting;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Unmount
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("Unmount", "unmounts", new ChatCommand(OnUnmount));
		}

		private static bool OnUnmount(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Player.MountSpell != 0)
				Client.Player.Auras.CancelAuraForce(Client.Player.MountSpell);
			else
				if (!Client.Player.IsFlying)
					Client.Player.Unmount();
			/*Client.Player.Modifiers.UnregisterAllModifiers(MODIFIER.SPEED_PCT);
			Client.Player.UpdateData();*/
			return true;
		}
	}
}