using System;
using System.Collections;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.World;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class GOInfo
	{
        static string[] ObjectTypes = new string[] { "DOOR", "BUTTON", "QUEST GIVER", "CHEST", "BINDER", "GENERIC",
                                               "TRAP", "CHAIR","SPELL FOCUS","TEXT","GOOBER","TRANSPORT",
                                               "AREA DAMAGE","CAMERA","MAP OBJECT","MO TRANSPORT", "DUEL ARBITER",
                                               "FISHING NODE","RITUAL","MAILBOX","AUCTION HOUSE","GUARD POST",
                                               "SPELL CASTER","MEETING STONE"};
	    
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("goinfo", "", new ChatCommand(OnGOInfo));
		}

		private static bool OnGOInfo(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			GameObject go = null;
			double rng = double.MaxValue;

			foreach (MapTile mapTile in Client.Player.MapTile.Adjacents.Tiles)
				if (mapTile!=null)
				{
					ICollection collection = mapTile.GetObjects(OBJECTTYPE.GAMEOBJECT);
					if (collection!=null)
						foreach (GameObject gameObject in collection)
						if (gameObject != null)
						{
							double nrng = gameObject.Position.DistanceSqrd(Client.Player.Position);
							if (nrng < rng)
							{
								rng = nrng;
								go = gameObject;
							}
						}
				}

			if (go == null)
			{
				Chat.System(client, "No game Objects found!");
				return true;
			}
            Chat.System(client, "Selected object " + go.Entry + " of type " + go.ObjectType + " (" + ObjectTypes[go.TypeID] +  ") , class: " + go.GetType().ToString() + " , position: " + go.Position);
			Chat.System(client, "Name: " + go.Template.Name + ", Faction: " + go.Faction + ", Flags: " + go.Flags + ", Level: " + go.Level + ", DynamicFlags " + go.DynamicFlags + ", State " + go.State + ", Timestamp " + go.Timestamp);
			Chat.System(client, "QuestID: " + go.DBGameObject.QuestID);

			if (go.DBGameObject.QuestID != 0)
			{
				if (go.DBGameObject.StartQuests != null && go.DBGameObject.StartQuests.Count > 0)
				{
					Chat.System(client, "StartQuests: ");
					foreach (DBQuest quest in go.DBGameObject.StartQuests)
					{
						Chat.System(client, quest.ObjectId + ":  " + quest.Name);
					}
				}

				if (go.DBGameObject.StartQuests != null && go.DBGameObject.StartQuests.Count > 0)
				{
					Chat.System(client, "EndQuests: ");
					foreach (DBQuest quest in go.DBGameObject.EndQuests)
					{
						Chat.System(client, quest.ObjectId + ":  " + quest.Name);
					}
				}
			}
			return true;
		}
	}
}