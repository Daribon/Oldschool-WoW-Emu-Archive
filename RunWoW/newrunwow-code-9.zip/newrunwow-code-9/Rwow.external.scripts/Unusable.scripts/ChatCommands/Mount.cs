using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Mount
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("Mount", "Makes you mounted", new ChatCommand(OnMount));
		}

		private static bool OnMount(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			string[] command = input.Split(new char[] {'=', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Format: mount <mountid>");
				return true;
			}
			int mountid = 0;
			try
			{
				mountid = int.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid mount id!");
				return true;
			}
			if (Client.Player.Selection == null || Client.Player.Selection == Client.Player)
			{
				Client.Player.Modifiers.RegisterModifier(MODIFIER.SPEED_PCT, 1.5f, 0);
				Client.Player.Redress();
				Client.Player.Mount(mountid);
			}
			else
				(Client.Player.Selection as LivingObject).Mount(mountid);
			return true;
		}
	}
}