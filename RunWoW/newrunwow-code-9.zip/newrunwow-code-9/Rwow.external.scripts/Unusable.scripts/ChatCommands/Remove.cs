using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.DB.DataTables;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class Remove
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("remove", "No target selected", new ChatCommand(OnRemove));
		}

		private static bool OnRemove(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.GM)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			LogConsoleGM.WriteLine("Chat command: " + input + ", Selection: " + (Client.Player.Selection == null ? "null" : Client.Player.Selection.Name), Client.Account.Name);

			if (Client.Player.Selection == null)
				return false;

			Chat.System(client, "Selected object " + Client.Player.Selection.GUID + " of type " + Client.Player.Selection.ObjectType + ", class: " + Client.Player.Selection.GetType());

			UnitBase unit = Client.Player.Selection as UnitBase;

			if (unit != null)
			{
				DBSpawn spawn = unit.Spawn;
                Database.Instance.ResolveRelations(spawn, typeof(DBMovepoint));
					foreach(DBMovepoint mp in spawn.Movepoints)
						DBManager.EraseDBObject(mp);
				DBManager.EraseDBObject(spawn);
				unit.MapTile.Map.Leave(unit);
				Client.Player.Selection = null;
			}

			return true;
		}
	}
}