using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.DB.DataTables;
using RunWoW.Misc;

namespace RunWoW.ChatCommands
{
	public class Shoot
	{
		public static void Initialize()
		{
			//ChatManager.RegisterChatCommand("shoot", "shoot spell_id", new ChatCommand(OnShoot));
		}

		private static bool OnShoot(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;

			string[] command = input.Split(new char[] { '=', ' ' });

			if (command.Length < 2)
			{
				Chat.System(client, "Format: shoot spell_id");
				return true;
			}
			
			ushort spellid = 0;
			try
			{
				spellid = ushort.Parse(command[1]);
			}
			catch
			{
				Chat.System(client, "Not valid spell id!");
				return true;
			}

			DBAbility ability = Client.Player.Spells[spellid];
			if (ability == null)
			{
				Chat.System(client, "You do not have that spell!");
				return true;
			}
			
			if (!ability.Spell.Ranged)
			{
				Chat.System(client, "Not ranged spell!");
				return true;
			}

			GamePackets.Spells.DoSpellCast(client, spellid, 2, Client.Player.SelectionGUID, null, null, Client.Player.Selection, CustomDateTime.Now);
			return true;
		}
	}
}