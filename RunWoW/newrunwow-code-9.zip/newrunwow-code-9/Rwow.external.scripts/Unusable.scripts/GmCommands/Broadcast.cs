using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class BroadcastCommand
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("broadcastGM", "USAGE: '.broadcastGM [message]' for tell only for TEMPGM's and higher", new ChatCommand(OnBroadcastCommand));
			ChatManager.RegisterChatCommand("broadcast", "USAGE: '.broadcast [message]' for tell everyone", new ChatCommand(OnBroadcastCommand));
		}

		private static bool OnBroadcastCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			string[] command = s.Split(new char[] {',', ' '});

			if (command.Length < 2)
			{
				Chat.System(client, "Not enough parameters!");
				return false;
			}

			string nname = command[1];
			for (int i = 2; i < command.Length; i++)
				nname = nname + " " + command[i];
			Chat.System(nname);
			return true;
		}


	}
}