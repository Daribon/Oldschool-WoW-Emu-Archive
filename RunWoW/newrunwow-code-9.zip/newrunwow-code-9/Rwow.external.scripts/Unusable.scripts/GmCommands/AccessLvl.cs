using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common;

namespace RunWoW.ChatCommands
{
	public class AccessLvlCommand
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("accesslvl", "(view access level of player) USAGE: '.accesslvl [name]' || or choose player and type '.accesslvl' (for view current player access level) || or use '.accessvl' (for view your access level)", new ChatCommand(OnAccessLvlCommand));
		}

		private static bool OnAccessLvlCommand(ClientBase client, string s)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}
			Chat.System(client, "-------------------");

			string[] command = s.Split(new char[] {',', ' '});
			if (command.Length >= 2)
			{
				ClientBase client_to_work = ValidateUserByString(command[1], client);
				if (client_to_work != null)
				{
					ClientData client_to_work_cd = (ClientData) client_to_work.Data;

					Chat.System(client, "Player " + client_to_work_cd.Player.Name + " has accesslvl " + client_to_work_cd.Account.AccessLvl.ToString());

					return true;
				}
			}
			else
			{
				if (command.Length == 1)
				{
					if (Client.Player.Selection is PlayerObject)
					{
						ClientBase client_to_work = ClientManager.GetClient(((PlayerObject) Client.Player.Selection).CharacterID);

						ClientData client_to_work_cd = (ClientData) client_to_work.Data;
						Chat.System(client, "Player " + client_to_work_cd.Player.Name + " has accesslvl " + client_to_work_cd.Account.AccessLvl.ToString());
					}
					else
					{
						Chat.System(client, "Your access level is: " + Client.Account.AccessLvl.ToString());
					}
					return true;
				}
			}

			return false;

		}


		private static ClientBase ValidateUserByString(string _string, ClientBase client)
		{
			ClientData Client = (ClientData) client.Data;

			ClientBase cb_temp = ClientManager.GetClient(_string);

			if (cb_temp == null)
			{
				Chat.System(client, "No client found");
				return null;
			}
			else
			{
				ClientData cd_temp = (ClientData) cb_temp.Data;
				if (Client.Account.AccessLvl >= cd_temp.Account.AccessLvl)
				{
					return cb_temp;
				}
				else
				{
					Chat.System(client, "You cannot set new accesslevel this player, because his access level higher that your");
					return null;
				}
			}

		}

		/*ClientData Client=(ClientData)client.Data;			
			Chat.System(client, "AccessLvl of " + Client.Player.Name + " is: " + Client.Account.AccessLvl.ToString());
			
			return true;
			*/
	}
}