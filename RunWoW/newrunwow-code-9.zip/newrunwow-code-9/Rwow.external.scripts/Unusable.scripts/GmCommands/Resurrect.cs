using RunServer.Common;
using RunWoW.Accounting;
using RunWoW.Common;
using RunWoW.Misc;
using RunWoW.Objects;

namespace RunWoW.ExternalScripts.GmCommands
{
	public class Resurrect
	{
		public static void Initialize()
		{
			ChatManager.RegisterChatCommand("resurrect", "", new ChatCommand(OnResurrectCommand));
			ChatManager.RegisterChatCommand("ress", "", new ChatCommand(OnResurrectCommand));
		}

		private static bool OnResurrectCommand(ClientBase client, string input)
		{
			ClientData Client = (ClientData) client.Data;

			if (Client.Account.AccessLvl < ACCESSLEVEL.SEER)
			{
				Chat.System(client, "You do not have access to this command");
				return true;
			}

			if (Client.Player.Selection is PlayerObject)
				((PlayerObject) Client.Player.Selection).Dead = false;
			else
			{
				if (Client.Player.Dead)
					Client.Player.Dead = false;
				else
				{
					Chat.System(client, "No player selected");
					return true;
				}
			}

			return false;
		}
	}
}