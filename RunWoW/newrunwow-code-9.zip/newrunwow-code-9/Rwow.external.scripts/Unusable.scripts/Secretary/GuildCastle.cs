using RunServer.Common.Attributes;
using RunWoW.AI;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.ExternalScripts.Secretary
{
	public class GuildCastle
	{
		private static bool GuildCastleHandler(SecretaryBase secretary, PlayerObject player, ItemObject letter)
		{
			Chat.MonsterSay(secretary, player, "������ ��� ��������� ����� ��� ���������. ��� �����, ��� �����!");
			return true;
		}


		[InitializeHandler(InitPass.Fourth)]
		public static void Initialize()
		{
			SecretaryBase.RegisterSecretarySubject("Guild House", new SecretaryDelegate(GuildCastleHandler));
			SecretaryBase.RegisterSecretarySubject("Guild Base", new SecretaryDelegate(GuildCastleHandler));
			SecretaryBase.RegisterSecretarySubject("Guild Castle", new SecretaryDelegate(GuildCastleHandler));
			SecretaryBase.RegisterSecretarySubject("Guild Zone", new SecretaryDelegate(GuildCastleHandler));
			SecretaryBase.RegisterSecretarySubject("Guild Island", new SecretaryDelegate(GuildCastleHandler));
		}
	}
}