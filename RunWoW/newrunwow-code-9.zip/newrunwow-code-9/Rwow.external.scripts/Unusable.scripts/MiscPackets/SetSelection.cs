using RunWoW.Accounting;
using RunWoW.Common;
using RunServer.Common;

namespace WorldScripts.MiscPackets
{
	[PacketHandlerClass()]
	public class SetSelection
	{
		[PacketHandler(CMSG.SET_SELECTION)]
		public static void OnSetSelection(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;

			ulong guid = data.ReadUInt64();
			if (guid == Client.Player.Target)
			    return; // ??/
			/*Client.Player.ComboTarget = 0;
			Client.Player.ComboPoints = 0;*/
			Client.Player.Selection = guid == 0 || Client.Player.MapTile == null? null : Client.Player.MapTile.GetFarObject(guid);
			Client.Player.UpdateData();
		}

		[PacketHandler(CMSG.SET_TARGET)]
		public static void OnSetTarget(ClientBase client, BinReader data)
		{
			ClientData Client = (ClientData) client.Data;
			if (Client == null || Client.Player == null)
				return;

			ulong guid = data.ReadUInt64();
			if (guid == Client.Player.Target)
				return;
			Client.Player.Target = guid;
			/*if (guid!=Client.Player.ComboTarget)
			{
				Client.Player.ComboTarget = guid;
				Client.Player.ComboPoints = 0;
			}*/
			Client.Player.UpdateData();
		}
	}
}