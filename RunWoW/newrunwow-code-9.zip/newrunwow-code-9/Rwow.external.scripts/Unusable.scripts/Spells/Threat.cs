using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class ThreatSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			LivingObject lcaster = caster as LivingObject;

			if (lcaster == null)
				return SpellFailedReason.MAX;

			if (target is PlayerObject && !((PlayerObject) target).PvP)
				return SpellFailedReason.SPELL_FAILED_TARGET_IS_PLAYER;

			target.AddThreat(lcaster, lcaster.SpellProcessor.RandomDamage(m_spell, effect), 0f);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.THREAT, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.THREAT_ALL, new SpellCastOnLiving(Cast));
		}
	}
}