using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class CreateItemSpell
	{
		public static SpellFailedReason CraftItem(PlayerObject Player, uint item, int quantity)
		{
			DBItemTemplate template = (DBItemTemplate)Database.Instance.FindObjectByKey(typeof(DBItemTemplate), item);

			if (template == null)
			{
				LogConsole.WriteLine(LogLevel.ERROR, "No template for craft item {0}", item);
				return SpellFailedReason.SPELL_FAILED_ERROR;
			}

			if (template.MaxCount > 0) // Check for unique
			{
				if (Player.Inventory.CountItems((int)item) >= template.MaxCount)
					return SpellFailedReason.SPELL_FAILED_TOO_MANY_OF_ITEM;
			}
			
			if (Player.AddItem(template, quantity, true))
				return SpellFailedReason.MAX;
			else
			{
				Items.SendChangeFail(Player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
				return SpellFailedReason.SPELL_FAILED_DONT_REPORT;
			}
		}
		
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject Player = caster as PlayerObject;
			if (Player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			int item = (int) m_spell.Effect[effect].Category;
			LogConsole.WriteLine(LogLevel.ECHO, "Try creating item {0} by spell {1}", item, m_spell.ObjectId);
			if (item == 0)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			int quantity = m_spell.Effect[effect].Damage + m_spell.Effect[effect].RandomDamage;
			if (quantity <= 0)
				quantity = 1;

			PlayerSkill skill = null;

			if (m_spell.TempSkill == null)
			{
				if (m_spell.Flags[0] == 0x10000 && quantity == 1 && Player.Inventory.FindItem(item) != null)
					return SpellFailedReason.SPELL_FAILED_TOO_MANY_OF_ITEM;
			} else
			{
				skill = Player.Skills[(SKILL) m_spell.TempSkill.SkillID];
				if (skill == null || skill.Value < m_spell.TempSkill.Level)
					return SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT;
			}

			SpellFailedReason result = CraftItem(Player, (uint)item, quantity);

			if (skill != null && result == SpellFailedReason.MAX)
			{
				//float cchance = m_spell.TempSkill.Level == 0 ? 1f : (Skill.Level - m_spell.TempSkill.Level + 10f)/20f;
				//if (!Utility.Chance(cchance))
				//	return SpellFailedReason.SPELL_FAILED_TRY_AGAIN;

				float rchance = (float) (m_spell.TempSkill.MaxLevel - skill.Value)/((float) (m_spell.TempSkill.MaxLevel - m_spell.TempSkill.Level));
				if (Utility.Chance(rchance))
					Player.RaiseSkill(skill);
				Player.UpdateData();
			}
			

			/*if (result == SpellFailedReason.MAX)
				Player.MapTile.SendSurrounding(DamageLog.SpellLogExecute(caster.GUID, item, m_spell.ObjectId, SPELLEFFECT.CREATE_ITEM), null);*/
			
			return result;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.CREATE_ITEM, new SpellCastOnLiving(Cast));
		}
	}
}