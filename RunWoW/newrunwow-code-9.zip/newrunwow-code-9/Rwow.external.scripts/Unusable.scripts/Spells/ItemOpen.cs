using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells
{
	public class ItemOpen
	{
		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject player = caster as PlayerObject;
			if (player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			
			if (target is GameObject)
				return GOOpen.Cast(caster, (GameObject)target, castTarget, spell, effect, ref Linked);
			
			ItemObject item = target as ItemObject;
			if (item == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			LogConsole.WriteLine(LogLevel.ECHO, "Player {0} is looting Locked Item {1}", player.Name, item.Name);

			DBLock dlock = (DBLock) Database.Instance.FindObjectByKey(typeof (DBLock), item.Template.Lock);

			if (dlock != null)
			{
				//if (dlock.Target[0] != 0 && Player.Inventory.FindItem(dlock.Target[0]) == null)
				//	return SpellFailedReason.SPELL_FAILED_DONT_REPORT;

				if (spell.TempSkill != null)
				{
					PlayerSkill skill = player.Skills[(SKILL) spell.TempSkill.SkillID];
					if (skill == null)
						return SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT;

					int slevel = skill.Level;
					
					if (slevel < dlock.Level[1])
						return SpellFailedReason.SPELL_FAILED_LEVEL_REQUIREMENT;
					if (slevel < player.Level*5)
					{
						int smin = dlock.Level[1];
						int smax = smin + 75; //  25 per color orange, yellow, green, gray
						float colorPart = (smax - smin)*0.25f;
						int color = (int) (4 - (slevel - smin)/colorPart); //0 gray, 1 green, 2-yellow, 3 - Orange

						if (color == 3 && Utility.Chance(0.5f)) // 50% chance to fail on orange items
							return SpellFailedReason.SPELL_FAILED_TRY_AGAIN;

						if (color > 0 && Utility.Chance((color + 1)*0.25f))
							// Raise skill only on Orange-Green   , Orange - 100%, Yellow - 75%, Green 50%
						{
							player.RaiseSkill(skill);
							player.UpdateData();
						}
					}
				}

				if (item.Loot == null)
					item.GenerateLoot(player);

				Linked = new SpellFinishHandler(Loot.DoOpenLoot);
			}

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.OPEN_LOCK, 1804, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.OPEN_LOCK, 6461, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.OPEN_LOCK, 6463, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.OPEN_LOCK, 8917, new ScriptSpellCast(Cast));
		}
	}
}