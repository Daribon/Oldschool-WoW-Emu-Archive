using System;
using RunWoW.AI;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class SummonTotemSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject Player = caster as PlayerObject;
			if (Player == null || Player.MapTile == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			int creatureId = m_spell.Effect[effect].AuraParam;
			if (creatureId == 0)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			DBCreature creature = (DBCreature)Database.Instance.FindObjectByKey(typeof(DBCreature), creatureId);
			if (creature == null)
			{
				creature = (DBCreature)Database.Instance.FindObjectByKey(typeof(DBCreature), 2523); // searing totem model
				LogConsole.WriteLine(LogLevel.SYSTEM, "WARNING: Summoned totem without template: " + creatureId);
				//return SpellFailedReason.SPELL_FAILED_ERROR;
			}
			
			Vector pos = new Vector(Player.Position.X + (float)Math.Cos(Player.Facing) * 2, Player.Position.Y + (float)Math.Sin(Player.Facing) * 2, Player.Position.Z);
			
			ushort totemSpell = 133;
			bool offensive = true;

			// TODO: create new table for totems or use MonsterSpell for them
			
			switch (m_spell.SpellID)
			{
				case 1535: //Fire Nova Totem 1
					totemSpell = 8349;
					break;
				case 8498: //Fire Nova Totem 2
					totemSpell = 8502;
					break;
				case 8499: //Fire Nova Totem 3
					totemSpell = 8503;
					break;
				case 11314: //Fire Nova Totem 4
					totemSpell = 11306;
					break;
				case 11315: //Fire Nova Totem 5
					totemSpell = 11307;
					break;
			        
				case 2484: //Earthbind Totem
					totemSpell = 3600;
					offensive = false;
					break;
				case 15786: //Earthbind Totem
					totemSpell = 3600;
					offensive = false;
					break;
			        
				case 5394: //Healing Stream Totem 1
					totemSpell = 5672;
					offensive = false;
					break;
				case 6375: //Healing Stream Totem 2
					totemSpell = 6371;
					offensive = false;
					break;
				case 6377: //Healing Stream Totem 3
					totemSpell = 6372;
					offensive = false;
					break;
				case 10462: //Healing Stream Totem 4
					totemSpell = 10460;
					offensive = false;
					break;
				case 10463: //Healing Stream Totem 5
					totemSpell = 10461;
					offensive = false;
					break;

                case 12506: //Atal'ai Skeleton Totem
                    totemSpell = 12504;
                    offensive = false;
                    break;

                case 23422: //Corrupted Healing Stream Totem
                    totemSpell = 10461;
                    offensive = false;
                    break;

                case 23420: //Corrupted Stoneskin Totem
                    totemSpell = 10405;
                    offensive = false;
                    break;

                case 23423: //Corrupted Windfury Totem
                    totemSpell = 10610;
                    offensive = false;
                    break;

                case 8170: //Corrupted Windfury Totem
                    totemSpell = 8171;
                    offensive = false;
                    break;

                case 8262: //Elemental Protection Totem
                    totemSpell = 8263;
                    offensive = false;
                    break;

                case 8184 : //Fire Resistance Totem Rank 1
                    totemSpell = 8185;
                    offensive = false;
                    break;
                case 10537: //Fire Resistance Totem Rank 2
                    totemSpell = 10534;
                    offensive = false;
                    break;
                case 10538: //Fire Resistance Totem Rank 3
                    totemSpell = 10535;
                    offensive = false;
                    break;
			        
                case 8227: //Flametongue Totem Rank 1
                    totemSpell = 8230;
                    offensive = false;
                    break;
                case 8249: //Flametongue Totem Rank 2
                    totemSpell = 8250;
                    offensive = false;
                    break;
                case 10526: //Flametongue Totem Rank 3
                    totemSpell = 10521;
                    offensive = false;
                    break;
                case 16387: //Flametongue Totem Rank 4
                    totemSpell = 15036;
                    offensive = false;
                    break;

                case 8181: //Frost Resistance Totem Rank 1
                    totemSpell = 8182;
                    offensive = false;
                    break;
                case 10478: //Frost Resistance Totem Rank 2
                    totemSpell = 10476;
                    offensive = false;
                    break;
                case 10479: //Frost Resistance Totem Rank 3
                    totemSpell = 10477;
                    offensive = false;
                    break;

                case 8835: //Grace of Air Totem Rank 1
                    totemSpell = 8836;
                    offensive = false;
                    break;
                case 10627: //Grace of Air Totem Rank 2
                    totemSpell = 10626;
                    offensive = false;
                    break;
                case 25359: //Grace of Air Totem Rank 3
                    totemSpell = 25360;
                    offensive = false;
                    break;

                case 8177: //Grounding Totem
                    totemSpell = 8179;
                    offensive = false;
                    break;

                case 11899: //Healing Ward
                    totemSpell = 5608;
                    offensive = false;
                    break;
                case 6274: //Healing Ward
                    totemSpell = 5608;
                    offensive = false;
                    break;
                case 5605: //Healing Ward
                    totemSpell = 5608;
                    offensive = false;
                    break;
                case 4971: //Healing Ward
                    totemSpell = 5608;
                    offensive = false;
                    break;

                case 24309: //Powerful Healing Ward
                    totemSpell = 24310;
                    offensive = false;
                    break;

                case 15869: //Superior Healing Ward
                    totemSpell = 15872;
                    offensive = false;
                    break;
			        

                case 8264: //Lava Spout Totem
                    totemSpell = 8265;
                    break;

                case 8190: //Magma Totem Rank 1
                    totemSpell = 8187;
                    break;
                case 10585: //Magma Totem Rank 3
                    totemSpell = 10579;
                    break;
                case 10586: //Magma Totem Rank 2
                    totemSpell = 10580;
                    break;
                case 10587: //Magma Totem Rank 4
                    totemSpell = 10581;
                    break;

                case 24854: //Mana Spring Totem Rank 0
                    totemSpell = 24853;
                    offensive = false;
                    break;
                case 5675: //Mana Spring Totem Rank 1
                    totemSpell = 24853;
                    offensive = false;
                    break;
                case 10495: //Mana Spring Totem Rank 2
                    totemSpell = 10491;
                    offensive = false;
                    break;
                case 10496: //Mana Spring Totem Rank 3
                    totemSpell = 10493;
                    offensive = false;
                    break;
                case 10497: //Mana Spring Totem Rank 4
                    totemSpell = 10494;
                    offensive = false;
                    break;

                case 16190: //Mana Tide Totem Rank 1
                    totemSpell = 16191;
                    offensive = false;
                    break;
                case 17354: //Mana Tide Totem Rank 2
                    totemSpell = 17355;
                    offensive = false;
                    break;
                case 17359: //Mana Tide Totem Rank 3
                    totemSpell = 17360;
                    offensive = false;
                    break;
			        
                case 15787: //Moonflare Totem
                    totemSpell = 15789;
                    break;

                case 10595: //Nature Resistance Totem 1
                    totemSpell = 10596;
                    offensive = false;
                    break;
                case 10600: //Nature Resistance Totem 2
                    totemSpell = 10598;
                    offensive = false;
                    break;
                case 10601: //Nature Resistance Totem 3
                    totemSpell = 10599;
                    offensive = false;
                    break;

                case 8166: //Poison Cleansing Totem
                    totemSpell = 8168;
                    offensive = false;
                    break;

                case 15038: //Scorching Totem
                    totemSpell = 17195; 
                    break;

                case 3599: //Searing Totem  1
                    totemSpell = 3606;
                    break;
                case 6363: //Searing Totem  2
                    totemSpell = 6350;
                    break;
                case 6364: //Searing Totem  3
                    totemSpell = 6351;
                    break;
                case 6365: //Searing Totem  4
                    totemSpell = 6352;
                    break;
                case 10437: //Searing Totem  5
                    totemSpell = 10435;
                    break;
                case 10438: //Searing Totem  6
                    totemSpell = 10436;
                    break;

                case 5730: //Stoneclaw Totem 1
                    totemSpell = 5729;
                    break;
                case 6390: //Stoneclaw Totem 2
                    totemSpell = 6393;
                    break;
                case 6391: //Stoneclaw Totem 3
                    totemSpell = 6394;
                    break;
                case 6392: //Stoneclaw Totem 4
                    totemSpell = 6395;
                    break;
                case 10427: //Stoneclaw Totem 5
                    totemSpell = 10424;
                    break;
                case 10428: //Stoneclaw Totem 6
                    totemSpell = 10424;
                    break;

                case 8071: //Stoneskin Totem 1
                    totemSpell = 8072;
                    offensive = false;
                    break;
                case 8154: //Stoneskin Totem 2
                    totemSpell = 8156;
                    offensive = false;
                    break;
                case 8155: //Stoneskin Totem 3
                    totemSpell = 8157;
                    offensive = false;
                    break;
                case 10406: //Stoneskin Totem 4
                    totemSpell = 10403;
                    offensive = false;
                    break;
                case 10407: //Stoneskin Totem 5
                    totemSpell = 10404;
                    offensive = false;
                    break;
                case 10408: //Stoneskin Totem 6
                    totemSpell = 10405;
                    offensive = false;
                    break;

                case 8075: //Strength of Earth Totem 1
                    totemSpell = 8076;
                    offensive = false;
                    break;
                case 8160: //Strength of Earth Totem 2
                    totemSpell = 8162;
                    offensive = false;
                    break;
                case 8161: //Strength of Earth Totem 3
                    totemSpell = 8163;
                    offensive = false;
                    break;
                case 10442: //Strength of Earth Totem 4
                    totemSpell = 10441;
                    offensive = false;
                    break;
                case 25361: //Strength of Earth Totem 5
                    totemSpell = 25362;
                    offensive = false;
                    break;

                case 18975: //Summon Ice Totem
                    totemSpell = 18978;
                    break;

                case 22047: //Testing Totem
                    totemSpell = 22048;
                    break;

                case 25908: //Tranquil Air Totem
                    totemSpell = 25909;
			        offensive = false;
                    break;

                case 8143: //Tremor Totem
                    totemSpell = 8146;
			        offensive = false;
                    break;

                case 8512: //Windfury Totem Rank 1
                    totemSpell = 8514;
			        offensive = false;
                    break;
                case 10613: //Windfury Totem Rank 2
                    totemSpell = 10607;
                    offensive = false;
                    break;
                case 10614: //Windfury Totem Rank 3
                    totemSpell = 10611;
                    offensive = false;
                    break;

                case 15107: //Windwall Totem Rank 1
                    totemSpell = 15108;
                    offensive = false;
                    break;
                case 15111: //Windwall Totem Rank 2
                    totemSpell = 15109;
                    offensive = false;
                    break;
                case 15112: //Windwall Totem Rank 3
                    totemSpell = 15110;
                    offensive = false;
                    break;

                case 23034: //Battle Standart
                    totemSpell = 23033;
                    offensive = false;
                    break;
                case 23035: //Battle Standart
                    totemSpell = 23033;
                    offensive = false;
                    break;
                case 23538: //Battle Standart
                    totemSpell = 23576;
                    offensive = false;
                    break;
                case 23539: //Battle Standart
                    totemSpell = 23574;
                    offensive = false;
                    break;
            }

			int life = caster.SpellProcessor.FullDamage(m_spell, effect);
			TotemBase totem = new TotemBase(creature, m_spell.ObjectId, pos, Player.Facing, Player, totemSpell, offensive, m_spell.Duration, life);
			
			Player.MapTile.Map.Enter(totem);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_TOTEM, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_TOTEM_SLOT_1, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_TOTEM_SLOT_2, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_TOTEM_SLOT_3, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_TOTEM_SLOT_4, new SpellCastOnLiving(Cast));
		}
	}
}