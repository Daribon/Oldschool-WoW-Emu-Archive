using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.World;

namespace RunWoW.Spells.Scripts
{
	// this spell is not part of World of Warcraft game =)
	public class CustomPortal
	{
		private const uint PortalSpellId = 6700;

		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
											 byte effect, ref SpellFinishHandler Linked)
		{
			GameObject portal = caster as GameObject;

			if (portal == null)
				return SpellFailedReason.MAX;

			PlayerObject player = target as PlayerObject;

			if (player == null)
				return SpellFailedReason.MAX;

			if (player.WorldMapID == 13 || player.WorldMapID == 29)
			{
				Chat.System(player.BackLink.Client, "You cannot escape from the prison!");
				return SpellFailedReason.MAX;
			}

			Teleport.TeleportTo(portal.PortalTarget, MapManager.GetWorldMap(portal.PortalWorld, portal.PortalInstance), player, false);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, PortalSpellId, new ScriptSpellCast(Cast));
		}
	}
}