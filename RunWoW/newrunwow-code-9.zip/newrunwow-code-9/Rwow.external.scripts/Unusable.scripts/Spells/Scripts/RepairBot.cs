using System;
using RunWoW.Common;
using RunWoW.Objects;
using RunWoW.AI;
using RunWoW.ServerDatabase;
using RunWoW.DB.DataTables;
using RunServer.Common;
using RunWoW.Misc;
using RunWoW.Spells;
using RunServer.Common.Attributes;

namespace RunWoW.ExternalScripts.Spells.Scripts
{
    class RepairBot
    {

        public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
        {
            int num = m_spell.Effect[effect].AuraParam;
            if (num == 0)
                return SpellFailedReason.SPELL_FAILED_ERROR;

            DBCreature creature = (DBCreature)Database.Instance.FindObjectByKey(typeof(DBCreature), num);
            if (creature == null)
            {
                LogConsole.WriteLine(LogLevel.SYSTEM, "Summoned creature without template: " + num);
                return SpellFailedReason.SPELL_FAILED_ERROR;
            }

            Vector pos = new Vector(caster.Position.X + (float)Math.Cos(caster.Facing) * 2, caster.Position.Y + (float)Math.Sin(caster.Facing) * 2, caster.Position.Z);

            DBSpawn s = new DBSpawn(creature, ((PlayerObject)caster).WorldMapID, caster.Facing, pos);

            UnitBase u = AIManager.CreateMobile(s);
            ((PlayerObject)caster).MapTile.Map.Enter(u);

            BotDeadEvent botDeadEvent = new BotDeadEvent(u);
            botDeadEvent.Start();
            return SpellFailedReason.MAX;
        }
        
        [InitializeHandler(InitPass.Third)]
        public static void Initialize()
        {
            SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_WILD, 22700, new ScriptSpellCast(Cast));
        }
        
    }

    public class BotDeadEvent : Event
    {
        UnitBase m_Bot;
        public BotDeadEvent(UnitBase bot)
            : base(TimeSpan.FromMinutes(10.0))
        {
            m_Bot = bot;
        }

        protected override void OnTick()
        {
            if (m_Bot != null && !m_Bot.Dead)
            {
                DBManager.EraseDBObject(m_Bot.Spawn);
                m_Bot.StopCombat();
                m_Bot.Health = 0;
                m_Bot.Die();
                m_Bot.MapTile.Map.Leave(m_Bot);
                m_Bot = null;
                Finish();
            }
        }
    }
}
