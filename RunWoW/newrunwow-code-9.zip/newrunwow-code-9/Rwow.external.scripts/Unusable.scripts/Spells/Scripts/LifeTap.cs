using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells.Scripts
{
	public class LifeTap
	{
		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
		                                     byte effect, ref SpellFinishHandler Linked)
		{
			if (caster is LivingObject)
			{
				LivingObject lcaster = caster as LivingObject;

				if (lcaster.Power >= lcaster.MaxPower)
					return SpellFailedReason.SPELL_FAILED_ALREADY_AT_FULL_POWER;

				int damage = spell.Effect[effect].RandomDamage + spell.Effect[effect].Damage;

				if (damage > lcaster.Health)
					damage = damage - lcaster.Health;

				lcaster.Health -= damage;

				int npower = lcaster.Power + damage;
				if (npower > lcaster.MaxPower)
					npower = lcaster.MaxPower;

				lcaster.Power = npower;
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 1454, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 1455, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 1456, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 11687, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 11688, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 11689, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, 27222, new ScriptSpellCast(Cast));
		}
	}
}