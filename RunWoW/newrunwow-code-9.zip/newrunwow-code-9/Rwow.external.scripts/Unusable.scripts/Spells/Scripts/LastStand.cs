using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Events;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells.Scripts
{
	public class LastStand
	{
		public static uint LastStandSpellId = 12976;
		public static DBSpell LastStandSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), LastStandSpellId);

		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
											 byte effect, ref SpellFinishHandler Linked)
		{
			if (caster is LivingObject)
			{
				SpellCastEvent cast = new SingleTargetCast(caster, LastStandSpell, 2, target, false);
				cast.FireEvent();
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, LastStandSpellId, new ScriptSpellCast(Cast));
		}
	}
}