using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;
using RunWoW.Objects.Misc;
using RunWoW.ServerDatabase;
using RunWoW.AI;
using RunWoW.Misc;

namespace RunWoW.Spells.Scripts
{
	public class Bloodthirst
	{
		public static int[] m_healPart = new int[] { 23885 , 23886 , 23887 , 23888 , 25252 , 30339 };
		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell,
											 byte effect, ref SpellFinishHandler Linked)
		{

			LivingObject ltarget = target as LivingObject;

			if ((caster == target && spell.Effect[effect].Radius > 0) || 
			    (target is PetBase && ((PetBase)target).Owner == caster) ||
				ltarget ==  null || ltarget.Dead )
				return SpellFailedReason.MAX;

			PlayerObject pcaster = caster as PlayerObject;
			
			if (pcaster == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			if (Faction.SameFaction(target, caster))
				return SpellFailedReason.MAX;

			if (caster != target)
			{
				if (target is PlayerObject && !((PlayerObject)target).PvP)
					return SpellFailedReason.SPELL_FAILED_TARGET_IS_PLAYER;
				ltarget.Attacked(pcaster);
			}

			//int damage = pcaster.SpellProcessor.PureDamage(m_spell, effect);
			int damage = (pcaster.AttackPower + pcaster.AttackPowerModifier)*
			             (spell.Effect[effect].Value) / 100;


			pcaster.SubmitMagicDamage(ltarget, spell, spell.School, damage, damage);

			int healSpell = m_healPart[spell.Rank - 1];
			SpellManager.Cast(pcaster, pcaster, healSpell);
			
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.SCHOOL_DAMAGE, 23881, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SCHOOL_DAMAGE, 23892, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SCHOOL_DAMAGE, 23893, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SCHOOL_DAMAGE, 23894, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SCHOOL_DAMAGE, 25251, new ScriptSpellCast(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SCHOOL_DAMAGE, 30335, new ScriptSpellCast(Cast));
		}
	}
}