using System;
using RunServer.Common.Attributes;
using RunWoW.AI;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.Objects;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells.Scripts
{
	public class Snowball
	{
		public static uint SnowballSpellId = 21343;
		public static DBSpell SnowballSpell = (DBSpell)Database.Instance.FindObjectByKey(typeof(DBSpell), SnowballSpellId);

		public static SpellFailedReason Cast(ObjectBase caster, ObjectBase target, ObjectBase castTarget, DBSpell spell, byte effect, ref SpellFinishHandler Linked)
		{
			if (target is NPCBase || target is GuardBase)
			{
				SpellCastEvent snowball = new SingleTargetCast(target, spell, 2, caster, false);
				snowball.Delay = TimeSpan.FromSeconds(2);
				snowball.Start();
			}
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, SnowballSpellId, new ScriptSpellCast(Cast));

			SpellManager.RegisterTargetPatch(SnowballSpellId, TARGET.ANY);
		}
	}
}
