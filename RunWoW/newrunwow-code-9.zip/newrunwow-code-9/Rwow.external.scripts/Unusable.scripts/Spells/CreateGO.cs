//
using System;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Map;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class CreateGO
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject Player = caster as PlayerObject;
			if (Player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;


            // -----------------------------------------
            if ( m_spell.SpellID == 698 )   /// TODO: Temporary disabled Ritual of Summoning
                return SpellFailedReason.SPELL_FAILED_ERROR;
            // -----------------------------------------


			float range = m_spell.Fishing ? Utility.Random(m_spell.MinRange, m_spell.MaxRange) : 1.0f;

			Vector pos = new Vector(Player.Position.X + (float) Math.Cos(Player.Facing)*range, Player.Position.Y + (float) Math.Sin(Player.Facing)*range, Player.Position.Z);
			
			int areaId = 0;
			
			if (m_spell.Fishing)
			{
				float water;
				float z = WorldMap.GetPoint((int)Player.WorldMapID, pos.X, pos.Y, out water, out areaId, true);

				if (water == float.NaN || water == float.MinValue || water < -1000f || z >= water)
					return SpellFailedReason.SPELL_FAILED_NOT_FISHABLE;

				pos.Z = water;

			}

			DBGOTemplate templ = (DBGOTemplate) Database.Instance.FindObjectByKey(typeof (DBGOTemplate), m_spell.Effect[effect].AuraParam);
			if (templ == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			DBGameObject obj = new DBGameObject();
			if (m_spell.Fishing)
			{
				DBArea area = (DBArea)Database.Instance.FindObjectByKey(typeof(DBArea), areaId);
				if (area == null || area.FishGroupID == 0)
					return SpellFailedReason.SPELL_FAILED_NO_FISH;
				obj.LootGroupID = area.FishGroupID;
				obj.Level = area.Level;
			} else
				obj.Level = Player.Level;
			
			obj.Position = pos;
			obj.TemplateID = templ.ObjectId;
			obj.Template = templ;
			obj.Facing = Player.Facing;
			obj.WorldMapID = Player.WorldMapID;
			GameObject go = new GameObject(obj, m_spell.Fishing ? -1 : m_spell.Duration, Player.MapTile.Map);
			
			if (Player.ChannelObject is GameObject && ((GameObject) Player.ChannelObject).DBGameObject == null)
				Player.ChannelObject.Dispose();
			
			go.Creator = Player.GUID;
			go.Faction = Player.Faction;
			Player.ChannelObject = go;

			if (m_spell.Fishing)
				Linked = new SpellFinishHandler(StartFishTimer);

			return SpellFailedReason.MAX;
		}

		private static void StartFishTimer(ObjectBase caster, ObjectBase target, DBSpell spell)
		{
			PlayerObject player = caster as PlayerObject;
			
			if (player!=null && player.ChannelObject is GameObject)
			{
				FishTimer fish = new FishTimer((GameObject)player.ChannelObject, player);
				fish.Start();
			}
		}

		public class FishTimer : Event
		{
			private GameObject m_obj;
			private PlayerObject m_owner;
			private Vector m_tpos;
			private float m_chance;
			private Event m_cast;

			public FishTimer(GameObject obj, PlayerObject owner)
				: base(TimeSpan.FromMilliseconds(Constants.FishingStart), TimeSpan.FromMilliseconds(Constants.FishingUpdateTime))
			{
				m_obj = obj;
				m_owner = owner;
				m_tpos = m_obj.Position.Clone();
				m_owner.UpdateData();
				m_cast = m_owner.CastEvent;
				float sl = owner.Skills.SkillLevel(SKILL.FISHING)/5f;
				if (sl < 5)
					sl = 5f;
				m_chance = sl/(obj.Level*20f);
			}

			protected override void OnTick()
			{
				if (m_obj == null || m_cast == null || m_cast.Finished)
					Finish(EventResult.COMPLETED);
				if (m_obj != null && !m_obj.Used && Utility.Chance(m_chance))
				{
					ShortPacket pkg = new ShortPacket(SMSG.GAMEOBJECT_CUSTOM_ANIM);
					pkg.Write(m_obj.GUID);
					pkg.Write(0);
					m_owner.BackLink.Client.Send(pkg);
					m_obj.Timestamp = Utility.Timestamp();
					m_obj.UseTime = CustomDateTime.Now;
					m_obj.Used = true;
					m_obj.UpdateData();
				}
			}

			public Vector TargetPosition
			{
				get { return m_tpos; }
			}

			protected override void OnFinish()
			{
				base.OnFinish();
				if (m_obj != null)
				{
					if (m_obj.Loot != null) // oops =)
					{
						ShortPacket packet = new ShortPacket(SMSG.LOOT_RELEASE_RESPONSE);
						packet.Write(m_obj.GUID);
						packet.Write((byte) 1);
						m_owner.BackLink.Client.Send(packet);
					}
					m_obj.Dispose();
					if (m_owner != null)
					{
						m_owner.ChannelObject = null;
						m_owner.UpdateData();
					}
				}
			}

		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.CREATE_GO, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_OBJECT_SLOT_1, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_OBJECT_SLOT_2, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_OBJECT_SLOT_3, new SpellCastOnLiving(Cast));
			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_OBJECT_SLOT_4, new SpellCastOnLiving(Cast));

			SpellManager.RegisterSpell(SPELLEFFECT.SUMMON_OBJECT_WILD, new SpellCastOnLiving(Cast));
		}
	}
}