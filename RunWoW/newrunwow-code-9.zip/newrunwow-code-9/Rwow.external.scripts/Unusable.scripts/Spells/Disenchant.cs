using RunServer.Database;
using System.Collections;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.GamePackets;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.Objects.Player;
using RunWoW.ServerDatabase;

namespace RunWoW.Spells
{
	using DisenchantReagent=ElementPair;
	using RunServer.Common.Attributes;

	public class Disenchant
	{
		public static SpellFailedReason Cast(ObjectBase caster, ItemObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			LogConsole.WriteLine(LogLevel.SYSTEM, "Disenchanting Item " + target.Name);
			PlayerObject Player = caster as PlayerObject;
			if (Player == null || target == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			ICollection objs = Database.Instance.FindObjectsByField(typeof (DBDisenchant), "ItemTemplate_ID", target.Entry);
			
			DBDisenchant disenchant = null;

			foreach (DBDisenchant dis in objs)
			{
				disenchant = dis; // TODO: Select by random prop
				break;
			}

			if (disenchant == null)
				return SpellFailedReason.SPELL_FAILED_CANT_BE_DISENCHANTED;


			/// TODO: refactor
			//ItemObject targetIn = target.ContainedIn.GetItem(target.DBItem.OwnerSlot);
			ItemObject targetIn = Player.Inventory.FindItem(target.GUID);// target.ContainedIn.GetItem(target.DBItem.OwnerSlot);
			if ( targetIn == null || targetIn.GUID != target.GUID)
				return SpellFailedReason.MAX;

			targetIn.ContainedIn.RemoveItem(targetIn.DBItem.OwnerSlot, true);
			targetIn.ContainedIn.UpdateInventory();
			DBManager.EraseDBObject(targetIn.DBItem);
			
			/// /TODO: refactor

			foreach (DisenchantReagent reg in disenchant.Reagents)
				if (reg.ID != 0)
				{
					int count = Utility.Random(0, 3);
					if (count == 0)
						continue;
					
					DBItemTemplate template = (DBItemTemplate)Database.Instance.FindObjectByKey(typeof(DBItemTemplate), reg.ID);
					
					if (template == null)
					{
						LogConsole.WriteLine(LogLevel.ERROR, "Tempalte not found for disenchant reagint " + reg.ID);
						continue;
					}
					
					if (!Player.AddItem(template, count, false))
						break;
						
					//DBItem nitem = DBUtility.ItemOfChar(Player.Character, reg.ID, INVSLOT.MAX, count);
					//if (Player.Inventory.AddItem(nitem, true) == null)
					//{
					//    Database.Instance.RemoveObjectFromRelations(Player.Character, nitem);
					//    DBManager.EraseDBObject(nitem);
					//    Items.SendChangeFail(Player.BackLink.Client, null, null, BagResponseUpdateFields.BAG_INV_FULL);
					//    return SpellFailedReason.SPELL_FAILED_DONT_REPORT;
					//}
				}
			
			
			PlayerSkill Skill = Player.Skills[SKILL.ENCHANTING];
			if (Utility.Chance((75f - Skill.Level)/75f))
				Player.RaiseSkill(Skill);
			
			Player.UpdateData();
			//Player.Inventory.UpdateInventory();
			//Player.Save();
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DISENCHANT, new SpellCastOnItem(Cast));
		}
	}
}