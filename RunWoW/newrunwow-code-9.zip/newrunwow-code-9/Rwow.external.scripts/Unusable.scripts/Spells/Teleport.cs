using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class TeleportSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject player = target as PlayerObject;

			if (player == null)
				return SpellFailedReason.MAX;

			if (player.WorldMapID == 13 || player.WorldMapID == 29)
			{
				Chat.System(player.BackLink.Client, "You cannot escape from the prison!");
				return SpellFailedReason.MAX;
			}

			switch (spell.ObjectId)
			{
				case 3561: // Stormwind
				case 17334:
					Teleport.TeleportTo(new Vector(-8960.1f, 516.3f, 96.3f), 0, player);
					break;
				case 3562: // Ironforge
				case 17607:
					Teleport.TeleportTo(new Vector(-5032.2f, -819.1f, 495.2f), 0, player);
					break;
				case 3563: // Undercity
				case 17611:
					Teleport.TeleportTo(new Vector(1819.7f, 238.8f, 60.5f), 0, player);
					break;
				case 3565: // Darnassus
				case 17608:
					Teleport.TeleportTo(new Vector(9951.792969f, 2145.915771f, 1327.724854f), 1, player);
					break;
				case 3566: // Thunder Bluff
				case 17610:
					Teleport.TeleportTo(new Vector(-1391.0f, 140.0f, 22.478f), 1, player);
					break;
				case 3567: // Orgrimmar
				case 17609:
					Teleport.TeleportTo(new Vector(1552.499268f, -4420.658691f, 8.948024f), 1, player);
					break;
				case 18960: // Moonglade
					Teleport.TeleportTo(new Vector(7980.842285f, -2501.763428f, 487.576508f), 1, player);
					break;
				case 8690: // heartstone 
				case 556: // astral recall
					Teleport.TeleportTo(player.Character.BindPoint, player.Character.BindWorld, player);
					player.Zone = player.Character.BindZone;
					break;
				case 21128: //   Maraudon
					Teleport.TeleportTo(new Vector(-1425.138f, 2956.439f, 134.5824f), 1, player);
					break;
				case 32270: //   Silvermoon
				case 32272: //   Silvermoon
					Teleport.TeleportTo(new Vector(9698.5f, -7032.6f, 14.41f), 530, player);
					break;
				case 32268: //   Exodar
				case 32271: //   Exodar
					Teleport.TeleportTo(new Vector(-4004.2f, -11878.4f, -1f), 530, player);
					break;
			}

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.TELEPORT, new SpellCastOnLiving(Cast));
		}
	}
}