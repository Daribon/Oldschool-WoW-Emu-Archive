using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class Interrupt
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell,
											 byte effect, ref SpellFinishHandler Linked)
		{
			if (target == null || target.Disposed)
				return SpellFailedReason.SPELL_FAILED_ERROR;

			if (target is PlayerObject)
				((PlayerObject) target).CancelCast(SpellFailedReason.SPELL_FAILED_INTERRUPTED);
			else
			{
				// TODO: Monster cast interruption
			}

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.INTERRUPT_CAST, new SpellCastOnLiving(Cast));
		}
	}
}