using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Objects;

namespace RunWoW.Spells
{
	public class DispellMechanicSpell
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell spell,
											 byte effect, ref SpellFinishHandler linked)
		{
			target.Auras.RemoveAuras(spell.Effect[effect].Value,
									 (MechanicDispelType)spell.Effect[effect].AuraParam);

			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.DISPEL_MECHANIC, new SpellCastOnLiving(Cast));
		}
	}
}