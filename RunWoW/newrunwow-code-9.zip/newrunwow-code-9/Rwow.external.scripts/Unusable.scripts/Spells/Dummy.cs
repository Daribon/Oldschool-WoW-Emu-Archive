using RunServer.Common;
using RunServer.Common.Attributes;
using RunWoW.Common;
using RunWoW.DB.DataTables;
using RunWoW.Events;
using RunWoW.ExternalScripts.MiscPackets;
using RunWoW.Misc;
using RunWoW.Objects;
using RunWoW.ServerDatabase;
using RunWoW.SpellAuras;

namespace RunWoW.Spells
{
    public class DummySpell
    {
        public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget,
                                             DBSpell m_spell,
                                             byte effect, ref SpellFinishHandler Linked)
        {
            PlayerObject player = caster as PlayerObject;
            int spellId = m_spell.SpellID;
            switch (spellId)
            {
                case 13535: // weird, but better than DB modification

                    LogConsole.WriteLine(LogLevel.ECHO, "Casting taming instead of dummy for {0} to {1}", caster.Name,
                                         target.Name);
                    SpellManager.Cast(caster, target, 13481);
                    break;
                case 20473: // Holy Shock Dummy / cast or heal or damage depends from target
                case 20929:
                case 20930:
                    if (player != null)
                    {
                        int spellToCast = -1;

                        //Console.WriteLine("Casting holy shock");
                        //LivingObject selection = null;
                        //if (player.Selection is LivingObject)
                        //    selection = (LivingObject) player.Selection;
                        //else
                        //    return SpellFailedReason.SPELL_FAILED_UNKNOWN;

                        if (!Faction.SameFaction(target, player)) // - Do damage
                            spellToCast = spellId == 20473
                                              ? 25912
                                              : spellId == 20929 ? 25911 : spellId == 20930 ? 25902 : -1;
                        else
                            spellToCast = spellId == 20473
                                              ? 25914
                                              : spellId == 20929 ? 25913 : spellId == 20930 ? 25903 : -1;

                        if (spellToCast != -1)
                        {
                            DBSpell spell = (DBSpell) Database.Instance.FindObjectByKey(typeof (DBSpell), spellToCast);
							SpellCastEvent steach = new SingleTargetCast(player, spell, 2, target, false);
                            steach.SendSpellStart();
                            steach.FireEvent();
                        }
                    }
                    break;
                case 7266: // Request Duel 
                    {
                        if (player != null && target is PlayerObject && caster != target)
                        {
                            if (player.WorldMapID <= 1)
                            {
                                PlayerObject pCaster = (PlayerObject) caster;
                                PlayerObject pTarget = (PlayerObject) target;

                                // Do not allow duels if players in same group
                                if (pCaster.SameGroup(pTarget))
                                {
                                    Chat.System(pCaster.BackLink.Client, "Duel is not allowed while you in same group.");
                                    Chat.System(pTarget.BackLink.Client, "Duel is not allowed while you in same group.");
                                    return SpellFailedReason.SPELL_FAILED_UNKNOWN;
                                }

                                if (!Duel.IsDueling(pCaster) && !Duel.IsDueling(pTarget))
                                {
                                    GameObject go = Duel.CreateFlagObject(pCaster, pTarget);
                                    Duel.RegisterDuel(pCaster, pTarget, go);
                                    ShortPacket pckg = new ShortPacket(SMSG.DUEL_REQUESTED);
                                    pckg.Write(go.GUID);
                                    pckg.Write(caster.GUID);
                                    pTarget.BackLink.Client.Send(pckg);
                                }
                            }
                        }
                    }
                    break;
            }
            return SpellFailedReason.MAX;
        }

        [InitializeHandler(InitPass.Third)]
        public static void Initialize()
        {
            SpellManager.RegisterSpell(SPELLEFFECT.DUMMY, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DODGE, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.EVADE, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.PARRY, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.BLOCK, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.WEAPON, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DEFENSE, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.PROFICIENCY, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.LANGUAGE, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DUAL_WIELD, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.ATTACK, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.DUEL, new SpellCastOnLiving(Cast));
            SpellManager.RegisterSpell(SPELLEFFECT.SKILL, new SpellCastOnLiving(Cast));

            //SpellManager.RegisterTargetPatch(7266, TARGET.TARGET_SINGLE_ALLY); // duel fix

            SpellManager.RegisterTargetPatch(13535, TARGET.TARGET_SINGLE_ENEMY); // taming fix
            SpellManager.RegisterTargetPatch(13481, TARGET.TARGET_SINGLE_ENEMY); // taming fix
        }
    }
}