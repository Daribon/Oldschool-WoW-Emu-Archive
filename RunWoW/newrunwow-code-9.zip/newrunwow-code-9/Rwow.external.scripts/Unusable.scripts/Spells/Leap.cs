using System;
using RunWoW.Common;
using RunServer.Common;
using RunWoW.DB.DataTables;
using RunWoW.Map;
using RunWoW.Misc;
using RunWoW.Objects;
using RunServer.Common.Attributes;

namespace RunWoW.Spells
{
	public class Leap
	{
		public static SpellFailedReason Cast(ObjectBase caster, LivingObject target, ObjectBase castTarget, DBSpell m_spell, byte effect, ref SpellFinishHandler Linked)
		{
			PlayerObject player = caster as PlayerObject;
			
			if (player == null)
				return SpellFailedReason.SPELL_FAILED_ERROR;
			
			if (player.IsFlying)
				return SpellFailedReason.SPELL_FAILED_NOT_ON_TAXI;

			float range = m_spell.Effect[effect].Radius;

			Vector pos = new Vector(player.Position.X + (float) Math.Cos(player.Facing)*range, player.Position.Y + (float) Math.Sin(player.Facing)*range, player.Position.Z);

			float z = WorldMap.GetPoint((int) player.MapTile.Map.MapID, pos.X, pos.Y);
            if (z == float.NaN || z - pos.Z > 5f || pos.Z - z > 100f )
            {
            	Chat.System(player.BackLink.Client, "You cannot blink here!");
            	return SpellFailedReason.SPELL_FAILED_DONT_REPORT;
            }

			pos.Z = z;

            Teleport.TeleportTo(pos, player.MapTile.Map, player, false);

			player.UpdateData();
			
			return SpellFailedReason.MAX;
		}

		[InitializeHandler(InitPass.Third)]
		public static void Initialize()
		{
			SpellManager.RegisterSpell(SPELLEFFECT.LEAP, new SpellCastOnLiving(Cast));
		}
	}
}
