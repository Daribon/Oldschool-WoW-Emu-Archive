//
namespace RunWoW.Server
{
    using System;

    public class ServerWarning : Exception
    {
        public ServerWarning(string msg) : base(msg)
        {
        }
    }
}

