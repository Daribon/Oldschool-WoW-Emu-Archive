﻿namespace RunServer.Common
{
    using System;
    using System.Collections;
    using System.Collections.Generic;
    using System.Collections.ObjectModel;
    using System.Diagnostics;
    using System.Reflection;
    using System.Runtime.InteropServices;
    using System.Threading;

    [Serializable, DebuggerDisplay("Count = {Count}")]
    public class PooledList<T> : IList<T>, ICollection<T>, IEnumerable<T>, IList, ICollection, IEnumerable
    {
        [NonSerialized]
        private object _syncRoot;
        private T[] m_items;
        private int m_size;
        private int m_version;
        private static T[] s_emptyArray;
        private static GenericPool<T> s_pool;

        static PooledList()
        {
            PooledList<T>.s_pool = new GenericPool<T>(5, 0x7d0, 200);
            PooledList<T>.s_emptyArray = new T[0];
        }

        public PooledList()
        {
            this.m_items = PooledList<T>.s_emptyArray;
        }

        public PooledList(IEnumerable<T> collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            ICollection<T> is2 = collection as ICollection<T>;
            if (is2 != null)
            {
                int minSize = is2.Count;
                this.m_items = PooledList<T>.s_pool.AquireBuffer(minSize);
                is2.CopyTo(this.m_items, 0);
                this.m_size = minSize;
            }
            else
            {
                this.m_size = 0;
                this.m_items = PooledList<T>.s_pool.AquireBuffer();
                using (IEnumerator<T> enumerator = collection.GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        this.Add(enumerator.Current);
                    }
                }
            }
        }

        public PooledList(int capacity)
        {
            if (capacity < 0)
            {
                throw new ArgumentOutOfRangeException("capacity", "Small");
            }
            this.m_items = PooledList<T>.s_pool.AquireBuffer(capacity);
        }

        public void Add(T item)
        {
            this.EnsureCapacity(this.m_size + 1);
            this.m_items[this.m_size++] = item;
            this.m_version++;
        }

        public void AddRange(IEnumerable<T> collection)
        {
            this.InsertRange(this.m_size, collection);
        }

        public ReadOnlyCollection<T> AsReadOnly()
        {
            return new ReadOnlyCollection<T>(this);
        }

        public int BinarySearch(T item)
        {
            return this.BinarySearch(0, this.Count, item, null);
        }

        public int BinarySearch(T item, IComparer<T> comparer)
        {
            return this.BinarySearch(0, this.Count, item, comparer);
        }

        public int BinarySearch(int index, int count, T item, IComparer<T> comparer)
        {
            if ((index < 0) || (count < 0))
            {
                throw new ArgumentOutOfRangeException((index < 0) ? "index" : "count", "");
            }
            if ((this.m_size - index) < count)
            {
                throw new ArgumentException("index and count do not denote a valid range of elements");
            }
            return Array.BinarySearch<T>(this.m_items, index, count, item, comparer);
        }

        public void Clear()
        {
            if ((this.m_items != null) && (this.m_items != PooledList<T>.s_emptyArray))
            {
                Array.Clear(this.m_items, 0, this.m_size);
                this.m_size = 0;
            }
            this.m_version++;
        }

        public bool Contains(T item)
        {
            if (item == null)
            {
                for (int i = 0; i < this.m_size; i++)
                {
                    if (this.m_items[i] == null)
                    {
                        return true;
                    }
                }
                return false;
            }
            EqualityComparer<T> comparer = EqualityComparer<T>.Default;
            for (int j = 0; j < this.m_size; j++)
            {
                if (comparer.Equals(this.m_items[j], item))
                {
                    return true;
                }
            }
            return false;
        }

        public PooledList<TOutput> ConvertAll<TOutput>(Converter<T, TOutput> converter)
        {
            if (converter == null)
            {
                throw new ArgumentNullException("converter");
            }
            PooledList<TOutput> list = new PooledList<TOutput>(this.m_size);
            for (int i = 0; i < this.m_size; i++)
            {
                list.m_items[i] = converter(this.m_items[i]);
            }
            list.m_size = this.m_size;
            return list;
        }

        public void CopyTo(T[] array)
        {
            this.CopyTo(array, 0);
        }

        public void CopyTo(T[] array, int arrayIndex)
        {
            Array.Copy(this.m_items, 0, array, arrayIndex, this.m_size);
        }

        public void CopyTo(int index, T[] array, int arrayIndex, int count)
        {
            if ((this.m_size - index) < count)
            {
                throw new ArgumentException("index and count do not denote a valid range of elements");
            }
            Array.Copy(this.m_items, index, array, arrayIndex, count);
        }

        private void EnsureCapacity(int min)
        {
            if (this.m_items.Length < min)
            {
                int minSize = (this.m_items.Length == 0) ? 4 : (this.m_items.Length * 2);
                if (minSize < min)
                {
                    minSize = min;
                }
                T[] destinationArray = PooledList<T>.s_pool.AquireBuffer(minSize);
                Array.Copy(this.m_items, destinationArray, this.m_items.Length);
                PooledList<T>.s_pool.ReleaseBuffer(this.m_items);
                this.m_items = destinationArray;
                this.Capacity = destinationArray.Length;
            }
        }

        public bool Exists(Predicate<T> match)
        {
            return (this.FindIndex(match) != -1);
        }

        ~PooledList()
        {
            if ((this.m_items != null) && (this.m_items != PooledList<T>.s_emptyArray))
            {
                Array.Clear(this.m_items, 0, this.m_items.Length);
                PooledList<T>.s_pool.ReleaseBuffer(this.m_items);
                this.m_items = null;
            }
        }

        public T Find(Predicate<T> match)
        {
            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            for (int i = 0; i < this.m_size; i++)
            {
                if (match(this.m_items[i]))
                {
                    return this.m_items[i];
                }
            }
            return default(T);
        }

        public PooledList<T> FindAll(Predicate<T> match)
        {
            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            PooledList<T> list = new PooledList<T>();
            for (int i = 0; i < this.m_size; i++)
            {
                if (match(this.m_items[i]))
                {
                    list.Add(this.m_items[i]);
                }
            }
            return list;
        }

        public int FindIndex(Predicate<T> match)
        {
            return this.FindIndex(0, this.m_size, match);
        }

        public int FindIndex(int startIndex, Predicate<T> match)
        {
            return this.FindIndex(startIndex, this.m_size - startIndex, match);
        }

        public int FindIndex(int startIndex, int count, Predicate<T> match)
        {
            if (startIndex > this.m_size)
            {
                throw new ArgumentOutOfRangeException("startIndex", "Index out of range");
            }
            if ((count < 0) || (startIndex > (this.m_size - count)))
            {
                throw new ArgumentOutOfRangeException("count", "Count out of range");
            }
            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            int num = startIndex + count;
            for (int i = startIndex; i < num; i++)
            {
                if (match(this.m_items[i]))
                {
                    return i;
                }
            }
            return -1;
        }

        public T FindLast(Predicate<T> match)
        {
            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            for (int i = this.m_size - 1; i >= 0; i--)
            {
                if (match(this.m_items[i]))
                {
                    return this.m_items[i];
                }
            }
            return default(T);
        }

        public int FindLastIndex(Predicate<T> match)
        {
            return this.FindLastIndex(this.m_size - 1, this.m_size, match);
        }

        public int FindLastIndex(int startIndex, Predicate<T> match)
        {
            return this.FindLastIndex(startIndex, startIndex + 1, match);
        }

        public int FindLastIndex(int startIndex, int count, Predicate<T> match)
        {
            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            if (this.m_size == 0)
            {
                if (startIndex != -1)
                {
                    throw new ArgumentOutOfRangeException("startIndex", "Index out of range");
                }
            }
            else if (startIndex >= this.m_size)
            {
                throw new ArgumentOutOfRangeException("startIndex", "Index out of range");
            }
            if ((count < 0) || (((startIndex - count) + 1) < 0))
            {
                throw new ArgumentOutOfRangeException("count", "Count out of range");
            }
            int num = startIndex - count;
            for (int i = startIndex; i > num; i--)
            {
                if (match(this.m_items[i]))
                {
                    return i;
                }
            }
            return -1;
        }

        public void ForEach(Action<T> action)
        {
            if (action == null)
            {
                throw new ArgumentNullException("match");
            }
            for (int i = 0; i < this.m_size; i++)
            {
                action(this.m_items[i]);
            }
        }

        public Enumerator<T> GetEnumerator()
        {
            return new Enumerator<T>((PooledList<T>) this);
        }

        public PooledList<T> GetRange(int index, int count)
        {
            if ((index < 0) || (count < 0))
            {
                throw new ArgumentOutOfRangeException((index < 0) ? "index" : "count", "");
            }
            if ((this.m_size - index) < count)
            {
                throw new ArgumentException("index and count do not denote a valid range of elements");
            }
            PooledList<T> list = new PooledList<T>(count);
            Array.Copy(this.m_items, index, list.m_items, 0, count);
            list.m_size = count;
            return list;
        }

        public int IndexOf(T item)
        {
            return Array.IndexOf<T>(this.m_items, item, 0, this.m_size);
        }

        public int IndexOf(T item, int index)
        {
            if (index > this.m_size)
            {
                throw new ArgumentOutOfRangeException("index", "Index out of range");
            }
            return Array.IndexOf<T>(this.m_items, item, index, this.m_size - index);
        }

        public int IndexOf(T item, int index, int count)
        {
            if (index > this.m_size)
            {
                throw new ArgumentOutOfRangeException("index", "Index out of range");
            }
            if ((count < 0) || (index > (this.m_size - count)))
            {
                throw new ArgumentOutOfRangeException("count", "Count out of range");
            }
            return Array.IndexOf<T>(this.m_items, item, index, count);
        }

        public void Insert(int index, T item)
        {
            if (index > this.m_size)
            {
                throw new ArgumentOutOfRangeException("index", "");
            }
            if (this.m_size == this.m_items.Length)
            {
                this.EnsureCapacity(this.m_size + 1);
            }
            if (index < this.m_size)
            {
                Array.Copy(this.m_items, index, this.m_items, index + 1, this.m_size - index);
            }
            this.m_items[index] = item;
            this.m_size++;
            this.m_version++;
        }

        public void InsertRange(int index, IEnumerable<T> collection)
        {
            if (collection == null)
            {
                throw new ArgumentNullException("collection");
            }
            if (index > this.m_size)
            {
                throw new ArgumentOutOfRangeException("index", "Index out of range");
            }
            ICollection<T> is2 = collection as ICollection<T>;
            if (is2 != null)
            {
                int count = is2.Count;
                if (count > 0)
                {
                    this.EnsureCapacity(this.m_size + count);
                    if (index < this.m_size)
                    {
                        Array.Copy(this.m_items, index, this.m_items, index + count, this.m_size - index);
                    }
                    if (this == is2)
                    {
                        Array.Copy(this.m_items, 0, this.m_items, index, index);
                        Array.Copy(this.m_items, (int) (index + count), this.m_items, (int) (index * 2), (int) (this.m_size - index));
                    }
                    else
                    {
                        T[] array = new T[count];
                        is2.CopyTo(array, 0);
                        array.CopyTo(this.m_items, index);
                    }
                    this.m_size += count;
                }
            }
            else
            {
                using (IEnumerator<T> enumerator = collection.GetEnumerator())
                {
                    while (enumerator.MoveNext())
                    {
                        this.Insert(index++, enumerator.Current);
                    }
                }
            }
            this.m_version++;
        }

        private static bool IsCompatibleObject(object value)
        {
            return ((value is T) || ((value == null) && !typeof(T).IsValueType));
        }

        public int LastIndexOf(T item)
        {
            return this.LastIndexOf(item, this.m_size - 1, this.m_size);
        }

        public int LastIndexOf(T item, int index)
        {
            if (index >= this.m_size)
            {
                throw new ArgumentOutOfRangeException("index", "Index out of range");
            }
            return this.LastIndexOf(item, index, index + 1);
        }

        public int LastIndexOf(T item, int index, int count)
        {
            if (this.m_size == 0)
            {
                return -1;
            }
            if ((index < 0) || (count < 0))
            {
                throw new ArgumentOutOfRangeException((index < 0) ? "index" : "count", "");
            }
            if ((index >= this.m_size) || (count > (index + 1)))
            {
                throw new ArgumentOutOfRangeException((index >= this.m_size) ? "index" : "count", "");
            }
            return Array.LastIndexOf<T>(this.m_items, item, index, count);
        }

        public bool Remove(T item)
        {
            int index = this.IndexOf(item);
            if (index >= 0)
            {
                this.RemoveAt(index);
                return true;
            }
            return false;
        }

        public int RemoveAll(Predicate<T> match)
        {
            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            int index = 0;
            while ((index < this.m_size) && !match(this.m_items[index]))
            {
                index++;
            }
            if (index >= this.m_size)
            {
                return 0;
            }
            int num2 = index + 1;
            while (num2 < this.m_size)
            {
                while ((num2 < this.m_size) && match(this.m_items[num2]))
                {
                    num2++;
                }
                if (num2 < this.m_size)
                {
                    this.m_items[index++] = this.m_items[num2++];
                }
            }
            Array.Clear(this.m_items, index, this.m_size - index);
            int num3 = this.m_size - index;
            this.m_size = index;
            this.m_version++;
            return num3;
        }

        public void RemoveAt(int index)
        {
            if (index >= this.m_size)
            {
                throw new ArgumentOutOfRangeException();
            }
            this.m_size--;
            if (index < this.m_size)
            {
                Array.Copy(this.m_items, index + 1, this.m_items, index, this.m_size - index);
            }
            this.m_items[this.m_size] = default(T);
            this.m_version++;
        }

        public void RemoveRange(int index, int count)
        {
            if ((index < 0) || (count < 0))
            {
                throw new ArgumentOutOfRangeException((index < 0) ? "index" : "count", "");
            }
            if ((this.m_size - index) < count)
            {
                throw new ArgumentException("index and count do not denote a valid range of elements");
            }
            if (count > 0)
            {
                this.m_size -= count;
                if (index < this.m_size)
                {
                    Array.Copy(this.m_items, index + count, this.m_items, index, this.m_size - index);
                }
                Array.Clear(this.m_items, this.m_size, count);
                this.m_version++;
            }
        }

        public void Reverse()
        {
            this.Reverse(0, this.Count);
        }

        public void Reverse(int index, int count)
        {
            if ((index < 0) || (count < 0))
            {
                throw new ArgumentOutOfRangeException((index < 0) ? "index" : "count", "");
            }
            if ((this.m_size - index) < count)
            {
                throw new ArgumentException("index and count do not denote a valid range of elements");
            }
            Array.Reverse(this.m_items, index, count);
            this.m_version++;
        }

        public void Sort()
        {
            this.Sort(0, this.Count, null);
        }

        public void Sort(IComparer<T> comparer)
        {
            this.Sort(0, this.Count, comparer);
        }

        public void Sort(Comparison<T> comparison)
        {
            if (comparison == null)
            {
                throw new ArgumentNullException("match");
            }
            if (this.m_size > 0)
            {
                Array.Sort<T>(this.m_items, 0, this.m_size, Comparer<T>.Default);
            }
        }

        public void Sort(int index, int count, IComparer<T> comparer)
        {
            if ((index < 0) || (count < 0))
            {
                throw new ArgumentOutOfRangeException((index < 0) ? "index" : "count", "");
            }
            if ((this.m_size - index) < count)
            {
                throw new ArgumentException("index and count do not denote a valid range of elements");
            }
            Array.Sort<T>(this.m_items, index, count, comparer);
            this.m_version++;
        }

        IEnumerator<T> IEnumerable<T>.GetEnumerator()
        {
            return new Enumerator<T>((PooledList<T>) this);
        }

        void ICollection.CopyTo(Array array, int arrayIndex)
        {
            if ((array != null) && (array.Rank != 1))
            {
                throw new ArgumentException("");
            }
            try
            {
                Array.Copy(this.m_items, 0, array, arrayIndex, this.m_size);
            }
            catch (ArrayTypeMismatchException)
            {
                throw new ArgumentException("");
            }
        }

        IEnumerator IEnumerable.GetEnumerator()
        {
            return new Enumerator<T>((PooledList<T>) this);
        }

        int IList.Add(object item)
        {
            PooledList<T>.VerifyValueType(item);
            this.Add((T) item);
            return (this.Count - 1);
        }

        bool IList.Contains(object item)
        {
            if (PooledList<T>.IsCompatibleObject(item))
            {
                return this.Contains((T) item);
            }
            return false;
        }

        int IList.IndexOf(object item)
        {
            if (PooledList<T>.IsCompatibleObject(item))
            {
                return this.IndexOf((T) item);
            }
            return -1;
        }

        void IList.Insert(int index, object item)
        {
            PooledList<T>.VerifyValueType(item);
            this.Insert(index, (T) item);
        }

        void IList.Remove(object item)
        {
            if (PooledList<T>.IsCompatibleObject(item))
            {
                this.Remove((T) item);
            }
        }

        public T[] ToArray()
        {
            T[] destinationArray = new T[this.m_size];
            Array.Copy(this.m_items, 0, destinationArray, 0, this.m_size);
            return destinationArray;
        }

        public void TrimExcess()
        {
            int num = (int) (this.m_items.Length * 0.9);
            if (this.m_size < num)
            {
                this.Capacity = this.m_size;
            }
        }

        public bool TrueForAll(Predicate<T> match)
        {
            if (match == null)
            {
                throw new ArgumentNullException("match");
            }
            for (int i = 0; i < this.m_size; i++)
            {
                if (!match(this.m_items[i]))
                {
                    return false;
                }
            }
            return true;
        }

        private static void VerifyValueType(object value)
        {
            if (!PooledList<T>.IsCompatibleObject(value))
            {
                throw new ArgumentException(string.Format("{0} {1}", value, typeof(T)));
            }
        }

        public int Capacity
        {
            get
            {
                return this.m_items.Length;
            }
            set
            {
                if (value != this.m_items.Length)
                {
                    if (value < this.m_size)
                    {
                        throw new ArgumentOutOfRangeException("value", "");
                    }
                    if (value > 0)
                    {
                        T[] destinationArray = PooledList<T>.s_pool.AquireBuffer(value);
                        if (this.m_size > 0)
                        {
                            Array.Copy(this.m_items, 0, destinationArray, 0, this.m_size);
                        }
                        if (this.m_items != null)
                        {
                            PooledList<T>.s_pool.ReleaseBuffer(this.m_items);
                        }
                        this.m_items = destinationArray;
                    }
                    else
                    {
                        this.m_items = PooledList<T>.s_emptyArray;
                    }
                }
            }
        }

        public int Count
        {
            get
            {
                return this.m_size;
            }
        }

        public T this[int index]
        {
            get
            {
                if (index >= this.m_size)
                {
                    throw new ArgumentOutOfRangeException();
                }
                return this.m_items[index];
            }
            set
            {
                if (index >= this.m_size)
                {
                    throw new ArgumentOutOfRangeException();
                }
                this.m_items[index] = value;
                this.m_version++;
            }
        }

        public static GenericPool<T> Pool
        {
            get
            {
                return PooledList<T>.s_pool;
            }
        }

        bool ICollection<T>.IsReadOnly
        {
            get
            {
                return false;
            }
        }

        bool ICollection.IsSynchronized
        {
            get
            {
                return false;
            }
        }

        object ICollection.SyncRoot
        {
            get
            {
                if (this._syncRoot == null)
                {
                    Interlocked.CompareExchange(ref this._syncRoot, new object(), null);
                }
                return this._syncRoot;
            }
        }

        bool IList.IsFixedSize
        {
            get
            {
                return false;
            }
        }

        bool IList.IsReadOnly
        {
            get
            {
                return false;
            }
        }

        object IList.this[int index]
        {
            get
            {
                return this[index];
            }
            set
            {
                PooledList<T>.VerifyValueType(value);
                this[index] = (T) value;
            }
        }

        [Serializable, StructLayout(LayoutKind.Sequential)]
        public struct Enumerator<ET> : IEnumerator<ET>, IDisposable, IEnumerator
        {
            private PooledList<ET> list;
            private int index;
            private int version;
            private ET current;
            internal Enumerator(PooledList<ET> list)
            {
                this.list = list;
                this.index = 0;
                this.version = list.m_version;
                this.current = default(ET);
            }

            public void Dispose()
            {
            }

            public bool MoveNext()
            {
                if (this.version != this.list.m_version)
                {
                    throw new InvalidOperationException("");
                }
                if (this.index < this.list.m_size)
                {
                    this.current = this.list.m_items[this.index];
                    this.index++;
                    return true;
                }
                this.index = this.list.m_size + 1;
                this.current = default(ET);
                return false;
            }

            public ET Current
            {
                get
                {
                    return this.current;
                }
            }
            object IEnumerator.Current
            {
                get
                {
                    if ((this.index == 0) || (this.index == (this.list.m_size + 1)))
                    {
                        throw new InvalidOperationException("");
                    }
                    return this.Current;
                }
            }
            void IEnumerator.Reset()
            {
                if (this.version != this.list.m_version)
                {
                    throw new InvalidOperationException("");
                }
                this.index = 0;
                this.current = default(ET);
            }
        }
    }
}

