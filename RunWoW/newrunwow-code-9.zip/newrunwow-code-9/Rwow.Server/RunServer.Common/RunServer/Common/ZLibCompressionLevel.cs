//
namespace RunServer.Common
{
    using System;

    public enum ZLibCompressionLevel
    {
        Z_BEST_COMPRESSION = 9,
        Z_BEST_SPEED = 1,
        Z_DEFAULT_COMPRESSION = -1,
        Z_NO_COMPRESSION = 0
    }
}

