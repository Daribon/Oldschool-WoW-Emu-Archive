//
namespace RunServer.Common
{
    using System;

    public class BinWriter : InnerBinWriter
    {
        public static int DefaultBufferSize = 0x200;
        private HeapBuffer m_heapBuffer;

        public BinWriter() : this(DefaultBufferSize)
        {
        }

        public BinWriter(int size) : base(size)
        {
            this.m_heapBuffer = new HeapBuffer(size);
        }

        public HeapBuffer Delegate()
        {
            HeapBuffer heapBuffer = this.m_heapBuffer;
            this.m_heapBuffer = null;
            return heapBuffer;
        }

        protected override void Dispose(bool disposing)
        {
            lock (this)
            {
                if (this.m_heapBuffer != null)
                {
                    this.m_heapBuffer.Dispose();
                    this.m_heapBuffer = null;
                }
            }
        }

        protected override void EnsureCapacity(int length)
        {
            if (length > base.Capacity)
            {
                int num = ((length + DefaultBufferSize) - 1) & -DefaultBufferSize;
                HeapBuffer buffer = new HeapBuffer(num);
                buffer.WriteData(this.m_heapBuffer.Handle, 0, base.Length, 0);
                this.m_heapBuffer.Dispose();
                this.m_heapBuffer = buffer;
                base.Capacity = num;
            }
        }

        public override byte[] GetBuffer()
        {
            return this.m_heapBuffer.ToBytes(base.Length);
        }

        public IntPtr GetHandle()
        {
            lock (this)
            {
                return ((this.m_heapBuffer == null) ? IntPtr.Zero : this.m_heapBuffer.Handle);
            }
        }

        public override void Write(bool value)
        {
            this.Write(value ? ((byte) 1) : ((byte) 0));
        }

        public override unsafe void Write(byte value)
        {
            this.EnsureCapacity(base.Position + 1);
            m_heapBuffer.WriteData(new byte[]{value}, 0, 1, base.Position);
            base.Position++;
//            m_heapBuffer[base.Position++] = value;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
        }

        public override unsafe void Write(char value)
        {
            this.EnsureCapacity(base.Position + 1);
            m_heapBuffer.WriteData(new byte[]{(byte)value}, 0, 1, base.Position);
//            *((short*) (this.m_heapBuffer.Handle.ToPointer() + base.Position)) = value;
            base.Position++;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
        }

        public override unsafe void Write(double value)
        {
            this.EnsureCapacity(base.Position + 8);
            byte[] value_byte = new byte[8];
            value_byte = BitConverter.GetBytes(value);
            m_heapBuffer.WriteData(value_byte, 0, 8, base.Position);
//            *((double*) (this.m_heapBuffer.Handle.ToPointer() + base.Position)) = value;
            base.Position += 8;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
        }

        public override unsafe void Write(short value)
        {
            this.EnsureCapacity(base.Position + 2);
            m_heapBuffer.WriteData(new byte[]{(byte)(value % 256), (byte)((value >> 8) % 256)}, 0, 2, base.Position);
//            *((short*) (this.m_heapBuffer.Handle.ToPointer() + base.Position)) = value;
            base.Position += 2;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
//            Write((byte)(value % 256));
//            Write((byte)((value >> 8) % 256));
        }

        public override unsafe void Write(int value)
        {
            this.EnsureCapacity(base.Position + 4);
            m_heapBuffer.WriteData(new byte[]{(byte) (value % 256), (byte) ((value >> 8) % 256),
              (byte) ((value >> 16) % 256), (byte) ((value >> 24) % 256)}, 0, 4, base.Position);
//            *((int*) (this.m_heapBuffer.Handle.ToPointer() + base.Position)) = value;
            base.Position += 4;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
//            Write((byte) (value % 256));
//            Write((byte) ((value >> 8) % 256));
//            Write((byte) ((value >> 16) % 256));
//            Write((byte) ((value >> 24) % 256));
        }

        public override unsafe void Write(long value)
        {
            this.EnsureCapacity(base.Position + 8);
            m_heapBuffer.WriteData(new byte[]{(byte) (value % 256), (byte) ((value >> 8) % 256),
              (byte) ((value >> 16) % 256), (byte) ((value >> 24) % 256),
              (byte) ((value >> 32) % 256), (byte) ((value >> 40) % 256),
              (byte) ((value >> 48) % 256), (byte) ((value >> 56) % 256)}, 0, 8, base.Position);
//            *((long*) (this.m_heapBuffer.Handle.ToPointer() + base.Position)) = value;
            base.Position += 8;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
        }

        public override void Write(sbyte value)
        {
            this.Write((byte) value);
        }

        public override unsafe void Write(float value)
        {
            this.EnsureCapacity(base.Position + 4);
            byte[] value_byte = new byte[4];
            value_byte = BitConverter.GetBytes(value);
            m_heapBuffer.WriteData(value_byte, 0, 4, base.Position);
//            *((float*) (this.m_heapBuffer.Handle.ToPointer() + base.Position)) = value;
            base.Position += 4;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
        }

        public override void Write(ushort value)
        {
            this.Write((short) value);
        }

        public override void Write(uint value)
        {
            this.Write((int) value);
        }

        public override void Write(ulong value)
        {
            this.Write((long) value);
        }

        public void Write(IntPtr data, int len)
        {
            this.EnsureCapacity(base.Position + len);
            this.m_heapBuffer.WriteData(data, 0, len, base.Position);
            base.Position += len;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
        }

        public override void Write(byte[] data, int offset, int len)
        {
            this.EnsureCapacity(base.Position + len);
            this.m_heapBuffer.WriteData(data, offset, len, base.Position);
            base.Position += len;
            if (base.Position > base.Length)
            {
                base.Length = base.Position;
            }
        }
    }
}

