//
namespace RunServer.Common
{
    using System;
    using System.Collections.Generic;

    public class BufferQueue
    {
        private Queue<HeapBuffer> m_buffers = new Queue<HeapBuffer>();
        private int m_length;

        public unsafe bool Dequeue(byte* data, int length)
        {
            lock (this.m_buffers)
            {
                if (length > this.m_length)
                {
                    return false;
                }
                int offset = 0;
                while (offset < length)
                {
                    HeapBuffer buffer = this.m_buffers.Peek();
                    if (buffer == null)
                    {
                        throw new Exception("Goint to read empty data from BufferQueue!");
                    }
                    int num2 = length - offset;
                    if (num2 > (buffer.DataLength - buffer.DataOffset))
                    {
                        num2 = buffer.DataLength - buffer.DataOffset;
                    }
                    buffer.ReadData(data, offset, num2, buffer.DataOffset);
                    offset += num2;
                    buffer.DataOffset += num2;
                    if (buffer.DataOffset >= buffer.DataLength)
                    {
                        HeapBuffer buffer2 = this.m_buffers.Dequeue();
                        if (buffer2 != buffer)
                        {
                            throw new Exception("BufferQueue is broken!");
                        }
                        buffer2.Dispose();
                    }
                }
                this.m_length -= length;
            }
            return true;
        }

        public bool Dequeue(byte[] data, int length)
        {
            lock (this.m_buffers)
            {
                if (length > this.m_length)
                {
                    return false;
                }
                int offset = 0;
                while (offset < length)
                {
                    HeapBuffer buffer = this.m_buffers.Peek();
                    if (buffer == null)
                    {
                        throw new Exception("Goint to read empty data from BufferQueue!");
                    }
                    int num2 = length - offset;
                    if (num2 > (buffer.DataLength - buffer.DataOffset))
                    {
                        num2 = buffer.DataLength - buffer.DataOffset;
                    }
                    buffer.ReadData(data, offset, num2, buffer.DataOffset);
                    offset += num2;
                    buffer.DataOffset += num2;
                    if (buffer.DataOffset >= buffer.DataLength)
                    {
                        HeapBuffer buffer2 = this.m_buffers.Dequeue();
                        if (buffer2 != buffer)
                        {
                            throw new Exception("BufferQueue is broken!");
                        }
                        buffer2.Dispose();
                    }
                }
                this.m_length -= length;
            }
            return true;
        }

        public void Enqueue(HeapBuffer buffer, int length)
        {
            lock (this.m_buffers)
            {
                this.m_buffers.Enqueue(buffer);
                buffer.DataLength = length;
                this.m_length += length;
            }
        }

        public int Length
        {
            get
            {
                return this.m_length;
            }
        }
    }
}

