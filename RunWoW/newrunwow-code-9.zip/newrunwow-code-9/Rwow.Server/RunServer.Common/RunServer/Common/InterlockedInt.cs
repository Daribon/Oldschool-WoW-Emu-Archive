﻿namespace RunServer.Common
{
    using System;
    using System.Runtime.InteropServices;
    using System.Threading;

    [StructLayout(LayoutKind.Sequential)]
    public struct InterlockedInt
    {
        private int m_value;
        public InterlockedInt(int value)
        {
            this.m_value = value;
        }

        public void Add(int value)
        {
            int comparand;
            int num2;
            do
            {
                comparand = this.m_value;
                num2 = comparand + value;
            }
            while (comparand != Interlocked.CompareExchange(ref this.m_value, num2, comparand));
        }

        public void Sub(int value)
        {
            this.Add(-value);
        }

        public void Increment()
        {
            Interlocked.Increment(ref this.m_value);
        }

        public void Decrement()
        {
            Interlocked.Decrement(ref this.m_value);
        }

        public static explicit operator int(InterlockedInt ii)
        {
            return ii.m_value;
        }

        public override string ToString()
        {
            int num = (int) this;
            return num.ToString();
        }
    }
}

