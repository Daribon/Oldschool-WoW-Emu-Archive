﻿namespace RunServer.Common
{
    using System;
    using System.Threading;

    public class SimpleMonitorLock
    {
        private object m_syncRoot = new object();

        public void Enter()
        {
            Monitor.Enter(this.m_syncRoot);
        }

        public void Exit()
        {
            Monitor.Exit(this.m_syncRoot);
        }
    }
}

