//
namespace RunServer.Common
{
    using System;

    public interface IJob
    {
        void Execute(object state);

        bool Empty { get; }

        RunServer.Common.ExecutionPriority ExecutionPriority { get; }

        string Name { get; }

        int OwnerCode { get; }
    }
}

