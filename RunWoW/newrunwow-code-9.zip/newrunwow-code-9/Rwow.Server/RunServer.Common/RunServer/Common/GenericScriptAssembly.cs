//
namespace RunServer.Common
{
    using System;
    using System.Collections.Generic;
    using System.Reflection;
    using RunServer.Common.Attributes;

    public class GenericScriptAssembly<ClassAttribute, HandlerAttribute> : ScriptAssembly where ClassAttribute: Attribute where HandlerAttribute: BasePacketHandlerAttribute
    {
        private Dictionary<int, ScriptAssembly.TypeMethodPair> m_packetHandlers;

        public GenericScriptAssembly()
        {
            this.m_packetHandlers = new Dictionary<int, ScriptAssembly.TypeMethodPair>();
        }

        public bool Contains(int ID)
        {
            return this.m_packetHandlers.ContainsKey(ID);
        }

        public bool Handle(object client, int id, BinReader reader)
        {
            if (((client != null) && (reader != null)) && (reader.Length >= 4))
            {
                Console.WriteLine("Handling packet with id {0}", id);
                if (this.m_packetHandlers.ContainsKey(id))
                {
                    ScriptAssembly.TypeMethodPair pair = this.m_packetHandlers[id];
                    long ticks = DateTime.Now.Ticks;
                    if (pair.Handler.GetParameters().Length == 3)
                    {
                        pair.Handler.Invoke(pair.Container, new object[] { client, reader, id });
                    }
                    else
                    {
                        pair.Handler.Invoke(pair.Container, new object[] { client, reader });
                    }
                    int time = (int) TimeSpan.FromTicks(DateTime.Now.Ticks - ticks).TotalMilliseconds;
                    if (time > 10)
                    {
                        Statistics.AddPacketTime(id, time);
                    }
                    if (time > 500)
                    {
                        Console.WriteLine("warning, Invoking handler {0} for {1} ms", id, time);
                    }
                    return true;
                }
                LogConsole.WriteLine(RunServer.Common.LogLevel.WARNING, string.Concat(new object[] { ">> Handler not found for ", id, ", length ", reader.Length }));
            }
            return false;
        }

        protected override void LoadType(Type type)
        {
            base.LoadType(type);
            ClassAttribute[] customAttributes = (ClassAttribute[]) type.GetCustomAttributes(typeof(ClassAttribute), true);
            if (customAttributes.Length != 0)
            {
                foreach (MethodInfo info in type.GetMethods(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
                {
                    HandlerAttribute[] localArray2 = (HandlerAttribute[]) info.GetCustomAttributes(typeof(HandlerAttribute), true);
                    foreach (HandlerAttribute local in localArray2)
                    {
                        this.RegisterPacketHandler(local.MsgID, type, info, local.Priority, local.ToString());
                    }
                }
            }
        }

        public ExecutionPriority PacketPriority(int ID)
        {
            if (!this.m_packetHandlers.ContainsKey(ID))
            {
                return ExecutionPriority.Packet;
            }
            return this.m_packetHandlers[ID].Priority;
        }

        public void RegisterPacketHandler(int ID, Type type, MethodInfo method, ExecutionPriority priority, string text)
        {
            this.m_packetHandlers[ID] = new ScriptAssembly.TypeMethodPair(type, method, priority, text);
            LogConsole.WriteLine(RunServer.Common.LogLevel.ECHO, "Registered Handler for packet " + text);
        }

        protected override void UnloadType(Type type)
        {
            ClassAttribute[] customAttributes = (ClassAttribute[]) type.GetCustomAttributes(typeof(ClassAttribute), true);
            if (customAttributes.Length != 0)
            {
                foreach (MethodInfo info in type.GetMethods(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Static | BindingFlags.Instance))
                {
                    HandlerAttribute[] localArray2 = (HandlerAttribute[]) info.GetCustomAttributes(typeof(HandlerAttribute), true);
                    foreach (HandlerAttribute local in localArray2)
                    {
                        this.UnregisterPacketHandler(local.MsgID);
                    }
                }
            }
            base.UnloadType(type);
        }

        public void UnregisterPacketHandler(int ID)
        {
            this.m_packetHandlers.Remove(ID);
        }
    }
}

