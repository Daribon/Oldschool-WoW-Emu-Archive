﻿namespace RunServer.Common
{
    using System;

    public abstract class ManagedDisposableType : IDisposable
    {
        private bool m_disposed;

        protected ManagedDisposableType()
        {
        }

        public void Close()
        {
            this.Dispose();
        }

        public void Dispose()
        {
            if (!this.Disposed)
            {
                this.Dispose(true);
                this.m_disposed = true;
            }
        }

        protected abstract void Dispose(bool disposing);

        public bool Disposed
        {
            get
            {
                return this.m_disposed;
            }
        }
    }
}

