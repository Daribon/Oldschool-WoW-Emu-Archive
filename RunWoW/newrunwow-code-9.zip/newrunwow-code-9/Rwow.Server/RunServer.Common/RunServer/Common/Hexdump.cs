﻿namespace RunServer.Common
{
    using System;
    using System.Text;

    public class Hexdump
    {
        private static RunServer.Common.LogLevel logLevel = RunServer.Common.LogLevel.ECHO;

        public static void ToConsole(BinReader data)
        {
            int position = data.Position;
            data.Position = 0;
            ToConsole(data.ReadBytes(data.Length), data.Length);
            data.Position = position;
        }

        public static void ToConsole(string msg, byte val)
        {
            Console.Write(msg);
            Console.WriteLine("0x{0,2:X2}", val);
        }

        public static void ToConsole(string msg, short val)
        {
            Console.WriteLine("0x{0,4:X4}", val);
        }

        public static void ToConsole(string msg, int val)
        {
            LogConsole.Write(logLevel, msg);
            Console.WriteLine("0x{0,8:X8}", val);
        }

        public static void ToConsole(string msg, long val)
        {
            LogConsole.Write(logLevel, msg);
            Console.WriteLine("0x{0,16:X16}", val);
        }

        public static void ToConsole(string msg, float val)
        {
            LogConsole.Write(logLevel, msg);
            byte[] bytes = BitConverter.GetBytes(val);
            Console.WriteLine("{1} ({0})", BitConverter.ToString(bytes), val);
        }

        public static void ToConsole(string msg, ushort val)
        {
            LogConsole.Write(logLevel, msg);
            Console.WriteLine("0x{0,4:X4}", val);
        }

        public static void ToConsole(string msg, uint val)
        {
            LogConsole.Write(logLevel, msg);
            Console.WriteLine("0x{0,8:X8}", val);
        }

        public static void ToConsole(byte[] buffer, int len)
        {
            LogConsole.Write(logLevel, ToString(buffer, len));
        }

        public static void ToConsole(string msg, ulong val)
        {
            LogConsole.Write(logLevel, msg);
            Console.WriteLine("0x{0,16:X16}", val);
        }

        public static void ToConsole(string msg, byte[] buffer, int len)
        {
            LogConsole.WriteLine(logLevel, msg);
            LogConsole.Write(logLevel, ToString(buffer, len));
        }

        public static string ToString(byte[] buffer, int len)
        {
            uint num4 = (uint) (len / 0x10);
            if ((len % 0x10) != 0)
            {
                num4++;
            }
            StringBuilder builder = new StringBuilder((int) (num4 * 0x4e));
            uint num2 = 0;
            for (uint i = 0; num2 < num4; i += 0x10)
            {
                uint index;
                builder.Append(string.Format("{0,4:X4}   ", i));
                for (index = i; index < (i + 8); index++)
                {
                    if (index < len)
                    {
                        builder.Append(string.Format("{0,2:X2} ", buffer[index]));
                    }
                    else
                    {
                        builder.Append(' ', 3);
                    }
                }
                builder.Append(' ', 2);
                for (index = i + 8; index < (i + 0x10); index++)
                {
                    if (index < len)
                    {
                        builder.Append(string.Format("{0,2:X2} ", buffer[index]));
                    }
                    else
                    {
                        builder.Append(' ', 3);
                    }
                }
                builder.Append(' ', 2);
                for (index = i; index < (i + 0x10); index++)
                {
                    if (index < len)
                    {
                        if ((buffer[index] >= 0x20) && (buffer[index] < 0x7f))
                        {
                            builder.Append((char) buffer[index]);
                        }
                        else
                        {
                            builder.Append('.');
                        }
                    }
                    else
                    {
                        builder.Append(' ');
                    }
                }
                builder.Append(Environment.NewLine);
                num2++;
            }
            return builder.ToString();
        }
    }
}

