//
namespace RunServer.Common
{
    using System;

    internal class SingleLinkNode<T>
    {
        public T Item;
        public SingleLinkNode<T> Next;
    }
}

