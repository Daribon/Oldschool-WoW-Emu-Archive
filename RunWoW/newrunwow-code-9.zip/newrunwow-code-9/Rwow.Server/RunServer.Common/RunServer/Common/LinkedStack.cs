﻿namespace RunServer.Common
{
    using System;

    public class LinkedStack<T>
    {
        private int m_growthSize;
        private int m_offset;
        private LinkedArray<T> m_stack;

        public T Pop()
        {
            if (this.m_offset == this.m_growthSize)
            {
                this.m_stack = this.m_stack.Next;
                this.m_offset = 0;
                this.m_growthSize = this.m_growthSize >> 1;
            }
            return this.m_stack.Data[this.m_offset++];
        }

        public void Push(T value)
        {
            if (this.m_offset == 0)
            {
                this.m_growthSize = this.m_growthSize << 1;
                this.m_stack = new LinkedArray<T>(this.m_growthSize, this.m_stack);
                this.m_offset = this.m_growthSize;
            }
            this.m_offset--;
            this.m_stack.Data[this.m_offset] = value;
        }

        public int GrowthSize
        {
            get
            {
                return this.m_growthSize;
            }
        }
    }
}

