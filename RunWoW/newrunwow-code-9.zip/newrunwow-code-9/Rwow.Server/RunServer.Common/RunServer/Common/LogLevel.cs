//
namespace RunServer.Common
{
    using System;

    public enum LogLevel : byte
    {
        NONE = 0,
        SYSTEM = 1,
        ERROR = 2,
        WARNING = 3,
        PRINT = 4,
        TRACE = 5,
        ECHO = 6,
        CHATTER = 7,
        MAX = 9
    }
}

