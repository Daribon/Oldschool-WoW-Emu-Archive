//
namespace RunServer.Common
{
    using System;
    using System.Runtime.InteropServices;
    using System.Security;

    public class HeapBuffer : DisposableType
    {
        public static int Allocated;
        public static InterlockedInt BytesUsed;
        private int m_dataLength;
        private IntPtr m_handle;
        private int m_length;
        private int m_offset;
        public static int Released;

        public HeapBuffer(int length)
        {
            this.m_handle = IntPtr.Zero;
            this.m_handle = Alloc(length);
            this.m_length = length;
            BytesUsed.Add(this.m_length);
            Allocated++;
        }

        public HeapBuffer(IntPtr handle, int length)
        {
            this.m_handle = IntPtr.Zero;
            this.m_handle = handle;
            this.m_length = length;
            BytesUsed.Add(this.m_length);
            Allocated++;
        }

        public HeapBuffer(byte[] data, int start, int length) : this(length)
        {
            this.WriteData(data, start, length, 0);
        }

        public static IntPtr Alloc(int size)
        {
            return Marshal.AllocHGlobal(size);
        }

        protected override void Dispose(bool disposing)
        {
            if (this.m_handle != IntPtr.Zero)
            {
                BytesUsed.Add(-this.m_length);
                Free(this.m_handle);
                Released++;
                this.m_handle = IntPtr.Zero;
            }
        }

        public static void Free(IntPtr ptr)
        {
            Marshal.FreeHGlobal(ptr);
        }

        [SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll", EntryPoint="GlobalAlloc")]
        public static extern IntPtr HeapAlloc(uint flags, uint size);
        [SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll", EntryPoint="GlobalFree")]
        public static extern void HeapFree(IntPtr ptr);
        [SuppressUnmanagedCodeSecurity, DllImport("kernel32.dll", EntryPoint="RtlMoveMemory")]
        public static extern void MoveMemory(IntPtr dest, IntPtr src, int size);
        public unsafe void ReadData(byte[] data, int offset, int length, int sourceOffset)
        {
            fixed (byte* numRef = data)
            {
                MoveMemory((IntPtr) (numRef + offset), (IntPtr) (this.m_handle.ToInt32() + sourceOffset), length);
            }
        }

        public unsafe void ReadData(byte* pdata, int offset, int length, int sourceOffset)
        {
            MoveMemory((IntPtr) (pdata + offset), (IntPtr) (this.m_handle.ToInt32() + sourceOffset), length);
        }

        public void Realloc(int length)
        {
            if (length >= this.m_length)
            {
                if (this.m_handle == IntPtr.Zero)
                {
                    this.m_handle = Alloc(length);
                }
                else
                {
                    IntPtr dest = Alloc(length);
                    MoveMemory(dest, this.m_handle, this.m_length);
                    Free(this.m_handle);
                    this.m_handle = dest;
                }
                BytesUsed.Add(-this.m_length);
                this.m_length = length;
                BytesUsed.Add(this.m_length);
            }
        }

        public byte[] ToBytes(int length)
        {
            if (this.m_handle == IntPtr.Zero)
            {
                return null;
            }
            byte[] data = new byte[length];
            this.ReadData(data, 0, length, 0);
            return data;
        }

        public void WriteData(IntPtr data, int offset, int length, int sourceOffset)
        {
            MoveMemory((IntPtr) (this.m_handle.ToInt32() + sourceOffset), (IntPtr) (data.ToInt32() + offset), length);
        }

        public unsafe void WriteData(byte* pdata, int offset, int length, int sourceOffset)
        {
            MoveMemory((IntPtr) (this.m_handle.ToInt32() + sourceOffset), (IntPtr) (pdata + offset), length);
        }

        public unsafe void WriteData(byte[] data, int offset, int length, int sourceOffset)
        {
            fixed (byte* numRef = data)
            {
                MoveMemory((IntPtr) (this.m_handle.ToInt32() + sourceOffset), (IntPtr) (numRef + offset), length);
            }
        }

        internal int DataLength
        {
            get
            {
                return this.m_dataLength;
            }
            set
            {
                this.m_dataLength = value;
            }
        }

        internal int DataOffset
        {
            get
            {
                return this.m_offset;
            }
            set
            {
                this.m_offset = value;
            }
        }

        public IntPtr Handle
        {
            get
            {
                return this.m_handle;
            }
        }

        public int Length
        {
            get
            {
                return this.m_length;
            }
        }
    }
}

