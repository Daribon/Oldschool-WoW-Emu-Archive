//
namespace RunServer.Common
{
    using System;

    public enum ZLibError
    {
        Z_BUF_ERROR = -5,
        Z_DATA_ERROR = -3,
        Z_ERRNO = -1,
        Z_MEM_ERROR = -4,
        Z_NEED_DICT = 2,
        Z_OK = 0,
        Z_STREAM_END = 1,
        Z_STREAM_ERROR = -2,
        Z_VERSION_ERROR = -6
    }
}

