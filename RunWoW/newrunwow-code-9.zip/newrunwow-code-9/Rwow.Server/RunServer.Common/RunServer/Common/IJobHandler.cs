﻿namespace RunServer.Common
{
    using System;

    public interface IJobHandler
    {
        void AddJob(IJob job);
    }
}

