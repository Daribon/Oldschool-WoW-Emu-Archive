//
namespace RunServer.Common
{
    using System;
    using System.Runtime.InteropServices;
    using System.Security;

    public class ZLibDll
    {
        [SuppressUnmanagedCodeSecurity, DllImport("zlib")]
        public static extern ZLibError compress(byte[] dest, ref int destLength, byte[] source, int sourceLength);
        [SuppressUnmanagedCodeSecurity, DllImport("zlib")]
        public static extern ZLibError compress2(byte[] dest, ref int destLength, IntPtr source, int sourceLength, ZLibCompressionLevel level);
        [SuppressUnmanagedCodeSecurity, DllImport("zlib")]
        public static extern ZLibError compress2(byte[] dest, ref int destLength, byte[] source, int sourceLength, ZLibCompressionLevel level);
        [SuppressUnmanagedCodeSecurity, DllImport("zlib")]
        public static extern ZLibError compress2(IntPtr dest, ref int destLength, IntPtr source, int sourceLength, ZLibCompressionLevel level);
        [SuppressUnmanagedCodeSecurity, DllImport("zlib")]
        public static extern ZLibError uncompress(byte[] dest, ref int destLen, byte[] source, int sourceLen);
        [SuppressUnmanagedCodeSecurity, DllImport("zlib")]
        public static extern string zlibVersion();
    }
}

