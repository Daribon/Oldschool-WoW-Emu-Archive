﻿namespace RunServer.Common
{
    using System;
    using System.Collections;

    public class CustomArrayList : PooledList<object>
    {
        public CustomArrayList()
        {
        }

        public CustomArrayList(ICollection collection) : base((collection != null) ? collection.Count : 0)
        {
            this.AddRange(collection);
        }

        public CustomArrayList(int length) : base(length)
        {
        }

        public void AddRange(ICollection objs)
        {
            if (objs != null)
            {
                IEnumerator enumerator = objs.GetEnumerator();
                while (enumerator.MoveNext())
                {
                    base.Add(enumerator.Current);
                }
            }
        }

        public void Dispose()
        {
            if (base.Count > 0)
            {
                base.Clear();
            }
        }

        public Array ToArray(Type type)
        {
            object[] objArray = new object[base.Count];
            base.CopyTo(objArray);
            Array destinationArray = Array.CreateInstance(type, base.Count);
            Array.Copy(objArray, destinationArray, base.Count);
            return destinationArray;
        }
    }
}

