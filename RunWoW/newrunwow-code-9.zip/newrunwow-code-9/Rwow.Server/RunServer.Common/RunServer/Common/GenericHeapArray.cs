﻿namespace RunServer.Common
{
    using System;
    using System.Reflection;

    public abstract class GenericHeapArray<T> : IDisposable
    {
        private HeapBuffer m_heapBuffer;
        private int m_height;
        private int m_sizeOf;
        private int m_width;

        public GenericHeapArray(int size, int sizeOf)
        {
            this.m_width = size;
            this.m_height = 1;
            this.m_sizeOf = sizeOf;
            this.m_heapBuffer = new HeapBuffer(size * sizeOf);
        }

        public GenericHeapArray(int width, int height, int sizeOf)
        {
            this.m_width = width;
            this.m_height = height;
            this.m_sizeOf = sizeOf;
            this.m_heapBuffer = new HeapBuffer((width * height) * sizeOf);
        }

        public GenericHeapArray(int width, int height, T value, int sizeOf)
        {
            this.m_width = width;
            this.m_height = height;
            this.m_sizeOf = sizeOf;
            this.m_heapBuffer = new HeapBuffer((width * height) * sizeOf);
            T[] array = new T[width * height];
            for (int i = 0; i < array.Length; i++)
            {
                array[i] = value;
            }
            this.Copy(array, 0, this.m_heapBuffer.Handle, array.Length);
        }

        protected abstract void Copy(IntPtr source, T[] array, int index, int count);
        protected abstract void Copy(T[] array, int index, IntPtr target, int count);
        public void Dispose()
        {
            if (this.m_heapBuffer != null)
            {
                this.m_heapBuffer.Dispose();
                this.m_heapBuffer = null;
            }
        }

        ~GenericHeapArray()
        {
            this.Dispose();
        }

        public T[] GetQuad(int x, int y)
        {
            if (((x < 0) || (y < 0)) || ((x >= (this.m_width - 1)) || (y >= (this.m_height - 1))))
            {
                throw new IndexOutOfRangeException();
            }
            T[] array = new T[4];
            this.Copy((IntPtr) (this.m_heapBuffer.Handle.ToInt32() + ((x + (y * this.m_width)) * this.m_sizeOf)), array, 0, 2);
            this.Copy((IntPtr) (this.m_heapBuffer.Handle.ToInt32() + ((x + ((y + 1) * this.m_width)) * this.m_sizeOf)), array, 2, 2);
            return array;
        }

        public T this[int pos]
        {
            get
            {
                if ((pos < 0) || (pos >= (this.m_width * this.m_height)))
                {
                    throw new IndexOutOfRangeException();
                }
                T[] array = new T[1];
                this.Copy((IntPtr) (this.m_heapBuffer.Handle.ToInt32() + (pos * this.m_sizeOf)), array, 0, 1);
                return array[0];
            }
            set
            {
                T[] array = new T[] { value };
                this.Copy(array, 0, (IntPtr) (this.m_heapBuffer.Handle.ToInt32() + (pos * this.m_sizeOf)), 1);
            }
        }

        public T this[int x, int y]
        {
            get
            {
                if (((x < 0) || (y < 0)) || ((x >= this.m_width) || (y >= this.m_height)))
                {
                    throw new IndexOutOfRangeException();
                }
                T[] array = new T[1];
                this.Copy((IntPtr) (this.m_heapBuffer.Handle.ToInt32() + ((x + (y * this.m_width)) * this.m_sizeOf)), array, 0, 1);
                return array[0];
            }
            set
            {
                T[] array = new T[] { value };
                this.Copy(array, 0, (IntPtr) (this.m_heapBuffer.Handle.ToInt32() + ((x + (y * this.m_width)) * this.m_sizeOf)), 1);
            }
        }
    }
}

