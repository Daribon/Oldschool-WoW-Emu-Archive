﻿namespace RunServer.Common
{
    using System;
    using System.Xml;

    public class Config
    {
        protected XmlDocument m_document = new XmlDocument();
        private string m_file;

        public Config(string file)
        {
            this.m_file = file;
            try
            {
                this.m_document.Load(file);
            }
            catch (Exception)
            {
                this.SetDefaultValues();
                this.Save();
            }
        }

        public void Save()
        {
            this.m_document.Save(this.m_file);
        }

        public virtual void SetDefaultValues()
        {
        }

        public XmlDocument Document
        {
            get
            {
                return this.m_document;
            }
        }
    }
}

