//
namespace RunServer.Common
{
    using System;
    using System.Runtime.InteropServices;

    public class HeapBinReader : BinReader
    {
        private HeapBuffer m_heapBuffer;

        public HeapBinReader(HeapBuffer heapBuffer, int length) : base(length)
        {
            this.m_heapBuffer = heapBuffer;
        }

        public override void Clean()
        {
            if (this.m_heapBuffer != null)
            {
                this.m_heapBuffer.Dispose();
                this.m_heapBuffer = null;
            }
        }

        ~HeapBinReader()
        {
            this.Clean();
        }

        public override byte[] GetBuffer()
        {
            return this.m_heapBuffer.ToBytes(base.Length);
        }

        public override bool ReadBoolean()
        {
            return (this.ReadBytes(1)[0] != 0);
        }

        public override byte ReadByte()
        {
            return this.ReadBytes(1)[0];
        }

        public override byte[] ReadBytes(int length)
        {
            byte[] destination = new byte[length];
            Marshal.Copy((IntPtr) (this.m_heapBuffer.Handle.ToInt32() + base.Position), destination, 0, length);
            base.Position += length;
            return destination;
        }

        /*public override unsafe double ReadDouble()
        {
            float num = *((float*) (this.m_heapBuffer.Handle.ToPointer() + base.Position));
            base.Position += 4;
            return (double) num;
        }*/

        /*public override unsafe short ReadInt16()
        {
            short num = *((short*) (this.m_heapBuffer.Handle.ToPointer() + base.Position));
            base.Position += 2;
            return num;
        }*/

        /*public override unsafe int ReadInt32()
        {
            int num = *((int*) (this.m_heapBuffer.Handle.ToPointer() + base.Position));
            base.Position += 4;
            return num;
        }*/

        /*public override unsafe long ReadInt64()
        {
            long num = *((long*) (this.m_heapBuffer.Handle.ToPointer() + base.Position));
            base.Position += 8;
            return num;
        }*/

        public override sbyte ReadSByte()
        {
            return (sbyte) this.ReadBytes(1)[0];
        }

        /*public override unsafe float ReadSingle()
        {
            float num = *((float*) (this.m_heapBuffer.Handle.ToPointer() + base.Position));
            base.Position += 4;
            return num;
        }*/

        public override ushort ReadUInt16()
        {
            return (ushort) this.ReadInt16();
        }

        public override uint ReadUInt32()
        {
            return (uint) this.ReadInt32();
        }

        public override ulong ReadUInt64()
        {
            return (ulong) this.ReadInt64();
        }
    }
}

