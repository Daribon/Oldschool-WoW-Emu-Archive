//
using System;
using System.Runtime.InteropServices;
using ICSharpCode.SharpZipLib.Zip.Compression;

namespace RunServer.Common
{
    public class ZLib
    {
        private static ZLibCompressionLevel CLevel = ZLibCompressionLevel.Z_BEST_SPEED;
        private static GenericItemPool<Deflater> s_deflaterPool = new GenericItemPool<Deflater>(1, 20);
        private static GenericItemPool<Inflater> s_inflaterPool = new GenericItemPool<Inflater>(1, 20);

        public static void IOCompress(byte[] input, int len, byte[] output, out int deflatedLength)
        {
            Deflater item = s_deflaterPool.AquireItem();
            item.SetInput(input, 0, len);
            item.Finish();
            deflatedLength = item.Deflate(output, 0, output.Length);
            item.Reset();
            s_deflaterPool.ReleaseItem(item);
        }

        public static void IODecompress(byte[] input, int len, byte[] output, out int inflatedLength)
        {
            Inflater item = s_inflaterPool.AquireItem();
            item.SetInput(input, 0, len);
            inflatedLength = item.Inflate(output, 0, output.Length);
            item.Reset();
            s_inflaterPool.ReleaseItem(item);
        }

        public static int TargetCompress(IntPtr input, int offset, int len, IntPtr output, int bufferLength)
        {
            int destLength = bufferLength;
            ZLibDll.compress2(output, ref destLength, input, len, CLevel);
            return destLength;
        }

        public static int TargetCompress(byte[] input, int offset, int len, byte[] output, int bufferLength)
        {
            int destLength = bufferLength;
            ZLibDll.compress2(output, ref destLength, input, len, CLevel);
            return destLength;
        }
    }
}

