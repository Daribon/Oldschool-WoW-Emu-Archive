﻿namespace RunServer.Common
{
    public class FastQueue : FastLockQueue<object>
    {
    }
}

