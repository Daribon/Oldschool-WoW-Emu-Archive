﻿namespace RunWoW.Common
{
    using RunServer.Common.Attributes;
    using System;

    [AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
    public class ServerHandler : BasePacketHandlerAttribute
    {
        public ServerHandler(IMSG msgID) : base((int) msgID)
        {
        }
    }
}

