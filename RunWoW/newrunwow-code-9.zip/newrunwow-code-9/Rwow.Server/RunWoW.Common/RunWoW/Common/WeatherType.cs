//
namespace RunWoW.Common
{
    using System;

    public enum WeatherType
    {
        NONE,
        RAIN,
        SNOW,
        SANDSTORM
    }
}

