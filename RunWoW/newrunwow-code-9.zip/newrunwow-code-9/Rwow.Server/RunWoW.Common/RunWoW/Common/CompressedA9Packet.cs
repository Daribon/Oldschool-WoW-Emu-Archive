//
namespace RunWoW.Common
{
    using RunServer.Common;
    using System;
    using System.Collections;

    public class CompressedA9Packet : IPacket
    {
        private static int CompressBoundary = 160;
        private ShortPacket m_body;

        public CompressedA9Packet(A9Packet packet)
        {
            this.Write(new A9Packet[] { packet });
        }

        public CompressedA9Packet(IList packets)
        {
            this.Write(packets);
        }

        public void Aquire()
        {
            if (this.m_body != null)
            {
                this.m_body.Aquire();
            }
        }

        public void Finish()
        {
        }

        public byte[] GetBuffer()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public IntPtr GetHandle()
        {
            throw new Exception("The method or operation is not implemented.");
        }

        public void Release()
        {
            if (this.m_body != null)
            {
                this.m_body.Release();
            }
        }

        private void Write(IList packets)
        {
            int num;
            if (this.m_body != null)
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.ERROR, "Writing to finished packet!");
                return;
            }
            if ((packets == null) || (packets.Count == 0))
            {
                return;
            }
            if (packets.Count == 1)
            {
                A9Packet packet = packets[0] as A9Packet;
                if (packet == null)
                {
                    return;
                }
                lock (packet)
                {
                    if ((!packet.Disposed && (packet.GetHandle() != IntPtr.Zero)) && (packet.Length > 0))
                    {
                        if (packet.Length >= CompressBoundary)
                        {
                            goto Label_00D7;
                        }
                        this.m_body = new ShortPacket(SMSG.UPDATE_OBJECT);
                        this.m_body.Write(1);
                        this.m_body.Write((byte) 0);
                        this.m_body.Write(packet.GetHandle(), packet.Length);
                        if (!packet.DoNotDispose)
                        {
                            packet.Dispose();
                        }
                    }
                    return;
                }
            }
        Label_00D7:
            num = 0;
            foreach (A9Packet packet2 in packets)
            {
                if (((packet2 != null) && !packet2.Disposed) && ((packet2.GetHandle() != IntPtr.Zero) && (packet2.Length > 0)))
                {
                    num += packet2.Length;
                }
            }
            BinWriter writer = new BinWriter(num + 6);
            writer.Write(0);
            writer.Write((byte) 0);
            int num2 = 0;
            for (int i = 0; i < packets.Count; i++)
            {
                A9Packet packet3 = packets[i] as A9Packet;
                if (packet3 != null)
                {
                    lock (packet3)
                    {
                        if ((!packet3.Disposed && (packet3.GetHandle() != IntPtr.Zero)) && (packet3.Length > 0))
                        {
                            writer.Write(packet3.GetHandle(), packet3.Length);
                            if (!packet3.DoNotDispose)
                            {
                                packet3.Dispose();
                            }
                            num2++;
                        }
                    }
                }
            }
            if (num2 != 0)
            {
                int deflatedLength;
                writer.Set(0, num2);
                byte[] output = BufferPool.Instance.AquireBuffer(writer.Length + 9);
                ZLib.IOCompress(writer.GetBuffer(), writer.Length, output, out deflatedLength);
                this.m_body = new ShortPacket(SMSG.COMPRESSED_UPDATE_OBJECT, deflatedLength + 9);
                this.m_body.Write(writer.Length);
                this.m_body.Write(output, deflatedLength);
                this.m_body.Finish();
                writer.Dispose();
                BufferPool.Instance.ReleaseBuffer(output);
            }
            else
            {
                writer.Dispose();
            }
        }

        public ShortPacket Body
        {
            get
            {
                return this.m_body;
            }
        }

        public bool Empty
        {
            get
            {
                return (this.m_body == null);
            }
        }

        public int Length
        {
            get
            {
                throw new Exception("The method or operation is not implemented.");
            }
        }
    }
}

