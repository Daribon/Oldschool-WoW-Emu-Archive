﻿namespace RunWoW.Common
{
    using System;

    public enum VICTIMSTATE : uint
    {
        BLOCK = 5,
        DEFLECT = 8,
        DODGE = 2,
        EVADE = 6,
        IMMUNE = 7,
        INTERRUPT = 4,
        MAX = 9,
        NONE = 0,
        NORMAL = 1,
        PARRY = 3
    }
}

