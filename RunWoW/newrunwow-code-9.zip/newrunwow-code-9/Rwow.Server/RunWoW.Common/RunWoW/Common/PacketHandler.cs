//
namespace RunWoW.Common
{
    using RunServer.Common;
    using RunServer.Common.Attributes;
    using System;

    [AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
    public class PacketHandler : BasePacketHandlerAttribute
    {
        public PacketHandler(CMSG msgID) : base((int) msgID)
        {
        }

        public PacketHandler(CMSG msgID, ExecutionPriority priority) : base((int) msgID, priority)
        {
        }

        public override string ToString()
        {
            return ((CMSG) base.MsgID).ToString();
        }
    }
}

