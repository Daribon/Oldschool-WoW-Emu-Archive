﻿namespace RunWoW.Common
{
    using System;

    public enum HIER_OBJECTTYPE
    {
        CONTAINER = 7,
        CORPSEOBJECT = 0x81,
        DYNAMICOBJECT = 0x41,
        GAMEOBJECT = 0x21,
        ITEM = 3,
        OBJECT = 1,
        PLAYER = 0x19,
        UNIT = 9
    }
}

