﻿namespace RunWoW.Common
{
    using System;

    public enum RESTEDSTATE : byte
    {
        EXHAUSTED = 5,
        NORMAL = 3,
        RESTED = 2,
        TIRED = 4,
        WELLRESTED = 1
    }
}

