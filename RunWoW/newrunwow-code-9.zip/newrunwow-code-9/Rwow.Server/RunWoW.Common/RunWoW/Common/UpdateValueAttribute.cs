﻿namespace RunWoW.Common
{
    using System;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property, AllowMultiple=true, Inherited=true)]
    public class UpdateValueAttribute : Attribute
    {
        private int m_arraySize;
        private int m_bytesIndex;
        private int m_field;
        private int m_numSubFields;
        private Type m_onlyfortype;
        private bool m_private;
        private int m_shortsIndex;

        public UpdateValueAttribute()
        {
            this.m_field = -1;
            this.m_numSubFields = -1;
            this.m_arraySize = -1;
        }

        public UpdateValueAttribute(object field)
        {
            this.m_field = -1;
            this.m_numSubFields = -1;
            this.m_arraySize = -1;
            this.m_field = Convert.ToInt32(field);
        }

        public int ArraySize
        {
            get
            {
                return this.m_arraySize;
            }
            set
            {
                this.m_arraySize = value;
            }
        }

        public int BytesIndex
        {
            get
            {
                return this.m_bytesIndex;
            }
            set
            {
                this.m_bytesIndex = value;
            }
        }

        public int Field
        {
            get
            {
                return this.m_field;
            }
            set
            {
                this.m_field = value;
            }
        }

        public int NumSubFields
        {
            get
            {
                return this.m_numSubFields;
            }
            set
            {
                this.m_numSubFields = value;
            }
        }

        public Type OnlyForType
        {
            get
            {
                return this.m_onlyfortype;
            }
            set
            {
                this.m_onlyfortype = value;
            }
        }

        public bool Private
        {
            get
            {
                return this.m_private;
            }
            set
            {
                this.m_private = value;
            }
        }

        public int ShortsIndex
        {
            get
            {
                return this.m_shortsIndex;
            }
            set
            {
                this.m_shortsIndex = value;
            }
        }
    }
}

