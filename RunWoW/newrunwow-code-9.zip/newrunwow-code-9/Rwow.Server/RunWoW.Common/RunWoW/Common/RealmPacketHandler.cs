//
namespace RunWoW.Common
{
    using RunServer.Common.Attributes;
    using System;

    [AttributeUsage(AttributeTargets.Method, AllowMultiple=true)]
    public class RealmPacketHandler : BasePacketHandlerAttribute
    {
        public RealmPacketHandler(RMSG msgID) : base((int) msgID)
        {
        }
    }
}

