﻿namespace RunWoW.Common
{
    using System;

    public enum GameObjectType
    {
        Static,
        Dynamic,
        QuestGiver,
        Container,
        Binder,
        Sign,
        Trap,
        Chair,
        Anvil,
        TextPage,
        Goober,
        Transport,
        AreaDamage,
        Camera,
        MapObject,
        Zeppelin,
        DuelFlag,
        FishingBobber,
        Ritual,
        Mailbox,
        Auction,
        GuardPost,
        Portal,
        MeetingStone
    }
}

