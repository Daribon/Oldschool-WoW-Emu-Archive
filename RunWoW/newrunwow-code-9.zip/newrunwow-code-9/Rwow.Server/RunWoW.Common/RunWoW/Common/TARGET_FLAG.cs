﻿namespace RunWoW.Common
{
    using System;

    public enum TARGET_FLAG
    {
        TARGET_FLAG_DEST_LOCATION = 0x40,
        TARGET_FLAG_ITEM = 0x1010,
        TARGET_FLAG_OBJECT = 0x800,
        TARGET_FLAG_SELF = 0,
        TARGET_FLAG_SOURCE_LOCATION = 0x20,
        TARGET_FLAG_STRING = 0x2000,
        TARGET_FLAG_UNIT = 2
    }
}

