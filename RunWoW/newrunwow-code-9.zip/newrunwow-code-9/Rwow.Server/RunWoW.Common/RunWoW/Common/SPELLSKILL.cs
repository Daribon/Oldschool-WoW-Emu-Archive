﻿namespace RunWoW.Common
{
    using System;

    public enum SPELLSKILL : ushort
    {
        ATTACK = 0x19cb,
        BLOCK = 0x6b,
        BOW = 0x108,
        CLOTH = 0x2376,
        CROSSBOW = 0x1eef,
        DAGGER = 0x49c,
        DODGE = 0x51,
        DUALWIELD = 0x2a2,
        LEATHER = 0x2375,
        MAIL = 0x2221,
        NONE = 0,
        ONEHANDAXE = 0xc4,
        ONEHANDBLUNT = 0xc6,
        ONEHANDSWORD = 0xc9,
        PARRY = 0xc37,
        PLATEMAIL = 750,
        POLEARMS = 200,
        SHIELD = 0x239c,
        SHOOT = 0x139b,
        STAFF = 0xe3,
        THROW = 0xacc,
        THROWN = 0xa07,
        TWOHANDAXE = 0xc5,
        TWOHANDBLUNT = 0xc7,
        TWOHANDSWORD = 0xca,
        UNARMED = 0xcb,
        WAND = 0x1391
    }
}

