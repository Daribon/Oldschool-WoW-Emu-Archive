﻿namespace RunWoW.Common
{
    using RunServer.Common;
    using System;

    public class UpdateVector : Vector
    {
        public UpdateVector()
        {
        }

        public UpdateVector(Vector other) : base(other)
        {
        }

        public UpdateVector(float x, float y, float z) : base(x, y, z)
        {
        }

        [UpdateValue(Field=0)]
        public override float X
        {
            get
            {
                return base.X;
            }
            set
            {
                base.X = value;
            }
        }

        [UpdateValue(Field=1)]
        public override float Y
        {
            get
            {
                return base.Y;
            }
            set
            {
                base.Y = value;
            }
        }

        [UpdateValue(Field=2)]
        public override float Z
        {
            get
            {
                return base.Z;
            }
            set
            {
                base.Z = value;
            }
        }
    }
}

