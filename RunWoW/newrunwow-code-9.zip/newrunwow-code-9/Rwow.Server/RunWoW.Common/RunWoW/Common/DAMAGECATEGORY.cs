﻿namespace RunWoW.Common
{
    using System;

    public enum DAMAGECATEGORY
    {
        MELEE,
        RANGED,
        MAGIC,
        PERIODIC,
        ENVIRONMENTAL
    }
}

