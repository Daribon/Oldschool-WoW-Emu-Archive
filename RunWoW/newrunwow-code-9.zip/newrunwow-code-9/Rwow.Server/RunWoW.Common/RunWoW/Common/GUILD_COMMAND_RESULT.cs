﻿namespace RunWoW.Common
{
    using System;

    public enum GUILD_COMMAND_RESULT
    {
        ALREADY_IN_GUILD = 2,
        ALREADY_IN_GUILD_S = 3,
        ALREADY_INVITED_TO_GUILD = 5,
        GUILD_RANK_IN_USE = 0x12,
        INTERNAL = 1,
        INVITED_TO_GUILD = 4,
        LEADER_LEAVE = 8,
        NAME_EXISTS = 7,
        NAME_INVALID = 6,
        NOT_ALLIED = 12,
        PERMISSIONS = 8,
        PLAYER_ALREADY_NOOB = 14,
        PLAYER_IGNORING_YOU = 0x13,
        PLAYER_NO_MORE_IN_GUILD = 0,
        PLAYER_NOT_FOUND = 11,
        PLAYER_NOT_IN_GUILD = 9,
        PLAYER_NOT_IN_GUILD_S = 10,
        PLAYER_RANK_TO_HIGH = 13,
        TEMPORARY_ERROR = 0x11
    }
}

