//
namespace RunWoW.Common
{
    using System;

    public enum POWERTYPE : sbyte
    {
        HEALTH = -2,
        MANA = 0,
        RAGE = 1,
        FOCUS = 2,
        ENERGY = 3,
        MAX = 4
    }
}

