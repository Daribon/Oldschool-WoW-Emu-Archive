﻿namespace RunWoW.Common
{
    using System;

    public enum INVTYPE
    {
        AMMO = 0x18,
        BAG = 0x12,
        BODY = 4,
        CHEST = 5,
        CLOAK = 0x10,
        FEET = 8,
        FINGER = 11,
        HAND = 10,
        HEAD = 1,
        HOLDABLE = 0x17,
        LEGS = 7,
        MAX = 0x1b,
        NECK = 2,
        NONE_EQUIP = 0,
        NUM_TYPES = 0x1b,
        RANGED = 15,
        RANGEDRIGHT = 0x1a,
        ROBE = 20,
        SHIELD = 14,
        SHOULDER = 3,
        TABARD = 0x13,
        THROWN = 0x19,
        TRINKET = 12,
        TWOHANDEDWEAPON = 0x11,
        WAIST = 6,
        WEAPON = 13,
        WEAPONMAINHAND = 0x15,
        WEAPONOFFHAND = 0x16,
        WRIST = 9
    }
}

