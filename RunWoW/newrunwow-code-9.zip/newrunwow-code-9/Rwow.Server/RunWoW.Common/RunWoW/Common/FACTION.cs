//
namespace RunWoW.Common
{
    using System;

    public enum FACTION
    {
        NONE = 0,
        HUMAN = 1,
        ORC = 2,
        DWARF = 3,
        NIGHTELF = 4,
        UNDEAD = 5,
        TAUREN = 6,
        STORMWIND = 12,
        ORGRIMMAR = 29,
        IRONFORGE = 55,
        GNOMEREGAN_EXILES = 64,
        UNDERCITY = 68,
        DARNASSUS = 80,
        THUNDER_BLUFF = 104,
        GNOME = 115,
        TROLL = 116,
        DARSPEAR_TROLLS = 126,
        SILVERMOON = 1602,
        BLOODELF = 1610,
        DRAENEI = 1629,
        EXODAR = 1638
    }
}

