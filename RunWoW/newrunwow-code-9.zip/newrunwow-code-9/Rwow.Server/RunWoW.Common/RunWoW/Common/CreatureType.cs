//
namespace RunWoW.Common
{
    using System;

    public enum CreatureType
    {
        BEAST = 1,
        DRAGONKIN = 2,
        DEMON = 3,
        ELEMENTAL = 4,
        GIANT = 5,
        UNDEAD = 6,
        HUMANOID = 7,
        CRITTER = 8,
        MECHANICAL = 9,
        NOT_SPECIFIED = 10,
        TOTEM = 11
    }
}

