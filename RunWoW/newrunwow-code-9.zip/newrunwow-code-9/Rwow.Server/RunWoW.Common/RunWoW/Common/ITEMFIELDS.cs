//
namespace RunWoW.Common
{
    using System;

    public enum ITEMFIELDS
    {
        START = 6,
        OWNER = 6,
        CONTAINED = 8,
        CREATOR = 10,
        GIFTCREATOR = 12,
        STACK_COUNT = 14,
        DURATION = 15,
        SPELL_CHARGES = 16,
        FLAGS = 21,
        ENCHANTMENTS = 22,
        PROPERTY_SEED = 55,
        RANDOM_PROPERTIES_ID = 56,
        ITEM_TEXT_ID = 57,
        DURABILITY = 58,
        MAX_DURABILITY = 59,
        MAX = 59
    }
}
