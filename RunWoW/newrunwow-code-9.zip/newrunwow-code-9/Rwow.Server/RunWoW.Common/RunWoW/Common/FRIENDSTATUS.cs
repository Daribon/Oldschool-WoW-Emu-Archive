﻿namespace RunWoW.Common
{
    using System;

    public enum FRIENDSTATUS : byte
    {
        ADDED_OFFLINE = 7,
        ADDED_ONLINE = 6,
        ALREADY = 8,
        DB_ERROR = 0,
        ENEMY = 10,
        IGNORE_ADDED = 15,
        IGNORE_ALREADY = 14,
        IGNORE_FULL = 11,
        IGNORE_NOT_FOUND = 13,
        IGNORE_REMOVED = 0x10,
        IGNORE_SELF = 12,
        LIST_FULL = 1,
        NOT_FOUND = 4,
        OFFLINE = 3,
        ONLINE = 2,
        REMOVED = 5,
        SELF = 9
    }
}

