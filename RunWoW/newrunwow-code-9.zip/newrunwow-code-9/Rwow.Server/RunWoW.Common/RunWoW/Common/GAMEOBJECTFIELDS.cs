﻿namespace RunWoW.Common
{
    using System;

    public enum GAMEOBJECTFIELDS
    {
        ANIMPROGRESS = 0x18,
        ARTKIT = 0x17,
        CREATEDBY = 6,
        DISPLAYID = 8,
        DYN_FLAGS = 0x13,
        FACING = 0x12,
        FACTION = 20,
        FLAGS = 9,
        LEVEL = 0x16,
        MAX = 0x19,
        PADDING = 0x19,
        POS = 15,
        ROTATION = 10,
        START = 6,
        STATE = 14,
        TYPE_ID = 0x15
    }
}

