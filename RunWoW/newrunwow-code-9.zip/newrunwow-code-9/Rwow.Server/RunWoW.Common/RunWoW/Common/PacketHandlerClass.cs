﻿namespace RunWoW.Common
{
    using System;

    [AttributeUsage(AttributeTargets.Class, AllowMultiple=true)]
    public class PacketHandlerClass : Attribute
    {
    }
}

