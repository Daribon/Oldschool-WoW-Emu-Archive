﻿namespace RunWoW.Common
{
    using System;

    public enum QuestStatus
    {
        None = 0,
        LowLevel = 1,
        Incomplete = 3,
        CompleteRep = 4,
        Available = 5,
        AvailableRep = 6,
        Complete = 7
    }
}

