﻿namespace RunWoW.Common
{
    using System;

    public enum DYNAMICOBJECTFIELDS
    {
        BYTES = 8,
        CASTER = 6,
        FACING = 14,
        MAX = 15,
        PADDING = 15,
        POS_X = 11,
        POS_Y = 12,
        POS_Z = 13,
        RADIUS = 10,
        SPELLID = 9,
        START = 6
    }
}

