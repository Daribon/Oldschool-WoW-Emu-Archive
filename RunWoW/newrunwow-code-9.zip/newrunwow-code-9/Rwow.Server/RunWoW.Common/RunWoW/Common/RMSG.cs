//
namespace RunWoW.Common
{
    using System;

    public enum RMSG
    {
        REALM_CHALLENGE = 0,
        REALM_PROOF = 1,
        REALM_RECODE_CHALLENGE = 2,
        REALM_RECODE_PROOF = 3,
        REALM_REALMLIST_REQUEST = 0x10
    }
}

