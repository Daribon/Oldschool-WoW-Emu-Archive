//
namespace RunWoW.Common
{
    using RunServer.Common;
    using System;

    public class A9Packet : BinWriter
    {
        private bool m_doNotDispose;

        public A9Packet() : base(0)
        {
        }

        public A9Packet(int size) : base(size)
        {
        }

        public bool DoNotDispose
        {
            get
            {
                return this.m_doNotDispose;
            }
            set
            {
                this.m_doNotDispose = value;
            }
        }
    }
}

