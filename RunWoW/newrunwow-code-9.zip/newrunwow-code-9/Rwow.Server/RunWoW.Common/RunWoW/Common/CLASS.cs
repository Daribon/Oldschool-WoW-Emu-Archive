//
namespace RunWoW.Common
{
    using System;

    public enum CLASS : byte
    {
        ANY = 0,
        WARRIOR = 1,
        PALADIN = 2,
        HUNTER = 3,
        ROGUE = 4,
        PRIEST = 5,
        SHAMAN = 7,
        MAGE = 8,
        WARLOCK = 9,
        DRUID = 11,
        MAX = 12
    }
}

