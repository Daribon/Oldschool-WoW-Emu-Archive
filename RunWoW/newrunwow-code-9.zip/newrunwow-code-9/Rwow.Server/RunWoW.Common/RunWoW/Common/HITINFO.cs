﻿namespace RunWoW.Common
{
    using System;

    [Flags]
    public enum HITINFO
    {
        ABSORB = 0x20,
        CRITICALHIT = 0x80,
        CRUSHING = 0x8000,
        GLANSING = 0x4000,
        LEFTSWING = 4,
        MISS = 0x10,
        NOACTION = 0x10000,
        NORMALSWING = 0,
        NORMALSWING2 = 2,
        NOSOUND = 0x80000,
        RESIT = 0x40
    }
}

