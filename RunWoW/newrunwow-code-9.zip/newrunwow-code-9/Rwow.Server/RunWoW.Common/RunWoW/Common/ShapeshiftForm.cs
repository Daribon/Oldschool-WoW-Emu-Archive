﻿namespace RunWoW.Common
{
    using System;

    public enum ShapeshiftForm
    {
        FORM_AMBIENT = 6,
        FORM_AQUA = 4,
        FORM_BATTLESTANCE = 0x11,
        FORM_BEAR = 5,
        FORM_BERSERKERSTANCE = 0x13,
        FORM_CAT = 1,
        FORM_CREATUREBEAR = 14,
        FORM_DEFENSIVESTANCE = 0x12,
        FORM_DIREBEAR = 8,
        FORM_FLIGHT = 0x1d,
        FORM_GHOSTWOLF = 0x10,
        FORM_GHOUL = 7,
        FORM_MOONKIN = 0x1f,
        FORM_SHADOW = 0x1c,
        FORM_STEALTH = 30,
        FORM_TRAVEL = 3,
        FORM_TREE = 2
    }
}

