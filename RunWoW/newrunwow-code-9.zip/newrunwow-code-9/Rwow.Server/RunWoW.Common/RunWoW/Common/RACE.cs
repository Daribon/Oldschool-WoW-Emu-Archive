﻿namespace RunWoW.Common
{
    using System;

    public enum RACE : byte
    {
        ANY = 0,
        HUMAN = 1,
        ORC = 2,
        DWARF = 3,
        NIGHTELF = 4,
        UNDEAD = 5,
        TAUREN = 6,
        GNOME = 7,
        TROLL = 8,
        GOBLIN = 9,
        BLOODELF = 10,
        DRAENEI = 11,
        MAX = 12
    }
}

