﻿namespace RunWoW.Common
{
    using System;
    using System.Threading;

    public class StaticCounters
    {
        private static int s_sendBytes;
        private static int s_sendPackets;

        public static void IncSendBytes(int value)
        {
            Interlocked.Add(ref s_sendBytes, value);
        }

        public static void IncSendPackets()
        {
            Interlocked.Increment(ref s_sendPackets);
        }

        public static int SendBytes
        {
            get
            {
                return Interlocked.Exchange(ref s_sendBytes, 0);
            }
        }

        public static int SendPackets
        {
            get
            {
                return Interlocked.Exchange(ref s_sendPackets, 0);
            }
        }
    }
}

