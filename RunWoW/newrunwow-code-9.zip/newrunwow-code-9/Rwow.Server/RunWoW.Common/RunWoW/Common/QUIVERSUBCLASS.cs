﻿namespace RunWoW.Common
{
    using System;

    public enum QUIVERSUBCLASS
    {
        NONE,
        BOLTS,
        ARROWS,
        AMMO
    }
}

