﻿namespace RunWoW.Common
{
    using System;

    public enum CHATMESSAGETYPE
    {
        SAY,
        PARTY,
        RAID,
        GUILD,
        OFFICER,
        YELL,
        WHISPER,
        WHISPER_INFORM,
        EMOTE,
        TEXT_EMOTE,
        SYSTEM,
        MONSTER_SAY,
        MONSTER_YELL,
        MONSTER_EMOTE,
        CHANNEL,
        CHANNEL_JOIN,
        CHANNEL_LEAVE,
        CHANNEL_LIST,
        CHANNEL_NOTICE,
        CHANNEL_NOTICE_USER,
        AFK,
        DND,
        IGNORED,
        SKILL,
        LOOT,
        COMBAT_MISC_INFO,
        MONSTER_WHISPER,
        MAX
    }
}

