namespace RunWoW.Common
{
    using System;

    public class WoWVersion
    {
        public const bool BurningCrusade = true;
        public const bool Version205 = true;
    }
}

