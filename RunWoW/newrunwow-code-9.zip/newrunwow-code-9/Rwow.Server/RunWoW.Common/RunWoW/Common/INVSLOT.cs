//
namespace RunWoW.Common
{
    using System;

    public enum INVSLOT : byte
    {
        EQUIPPEDFIRST = 0,
        HEAD = 0,
        NECK = 1,
        SHOULDER = 2,
        BODY = 3,
        CHEST = 4,
        WAIST = 5,
        LEGS = 6,
        FEET = 7,
        WRIST = 8,
        HAND = 9,
        FINGER1 = 10,
        FINGER2 = 11,
        TRINKET1 = 12,
        TRINKET2 = 13,
        BACK = 14,
        MAINHAND = 15,
        OFFHAND = 16,
        RANGED = 17,
        TABARD = 18,
        EQUIPPEDLAST = 18,

        NONE_EQUIPFIRST = 19,
        BAGFIRST = 19,
        BAGLAST = 22,
        BACKPACK_FIRST = 23,
        BACKPACK_LAST = 38,
        BANKGENERIC_FIRST = 39,
        BANKGENERIC_LAST = 66,
        BANKBAG_FIRST = 67,
        BANKBAG_LAST = 74,
        MAX = 75,
        PLAYER_INVENTORY_SLOTS = 86,
    }
}

