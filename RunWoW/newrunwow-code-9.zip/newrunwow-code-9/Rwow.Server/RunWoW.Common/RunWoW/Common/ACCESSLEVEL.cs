//
namespace RunWoW.Common
{
    using System;

    public enum ACCESSLEVEL
    {
        BANNED = 0,
        GUEST = 1,
        NORMAL = 2,
        FEATURED = 3,
        SEER = 4,
        GM = 5,
        DEVELOPER = 6,
        ADMIN = 7,
        GOD = 9
    }
}

