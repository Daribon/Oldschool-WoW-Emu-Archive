﻿namespace RunWoW.Common
{
    using System;

    public enum TRAINER_TYPE
    {
        CLASS,
        TALENT,
        SKILL
    }
}

