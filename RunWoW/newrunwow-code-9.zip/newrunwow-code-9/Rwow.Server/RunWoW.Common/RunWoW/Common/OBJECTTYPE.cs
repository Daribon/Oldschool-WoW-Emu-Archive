﻿namespace RunWoW.Common
{
    using System;

    public enum OBJECTTYPE
    {
        OBJECT,
        ITEM,
        CONTAINER,
        UNIT,
        PLAYER,
        GAMEOBJECT,
        DYNAMICOBJECT,
        CORPSEOBJECT,
        MAX
    }
}

