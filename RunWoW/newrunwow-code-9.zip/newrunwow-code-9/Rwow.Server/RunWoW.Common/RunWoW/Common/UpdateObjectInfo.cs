//
namespace RunWoW.Common
{
    using RunServer.Common;
    using System;
    using System.IO;
    using System.Reflection;

    public class UpdateObjectInfo
    {
        private byte m_blockSize;
        private UpdateFieldInfo[] m_fields;
        private int m_maxFields;
        private Type m_type;

        public UpdateObjectInfo(Type type)
        {
            object[] customAttributes = type.GetCustomAttributes(typeof(UpdateObjectAttribute), true);
            if ((customAttributes == null) || (customAttributes.Length == 0))
            {
                throw new UpdateManagerException(string.Format("Trying to register type {0} whithout update object attribute!", type));
            }
            UpdateObjectAttribute attribute = (UpdateObjectAttribute) customAttributes[0];
            this.m_maxFields = attribute.MaxFields + 1;
            this.m_blockSize = (byte) ((this.m_maxFields + 0x1f) / 0x20);
            this.m_fields = new UpdateFieldInfo[this.m_maxFields];
            this.m_type = type;
            this.ProcessFields(type);
        }

        public static int GetTypeSize(Type type)
        {
            if (type.IsEnum)
            {
                type = Enum.GetUnderlyingType(type);
            }
            if (((type == typeof(int)) || (type == typeof(uint))) || (type == typeof(float)))
            {
                return 4;
            }
            if ((type == typeof(byte)) || (type == typeof(sbyte)))
            {
                return 1;
            }
            if ((type == typeof(short)) || (type == typeof(ushort)))
            {
                return 2;
            }
            if ((type != typeof(long)) && (type != typeof(ulong)))
            {
                throw new UpdateManagerException("Unknown type " + type);
            }
            return 8;
        }

        private void ProcessFields(Type type)
        {
            this.ProcessFields(type, 0, null);
        }

        private void ProcessFields(Type type, int shift, CustomMemberInfo path)
        {
            if (type.BaseType != null)
            {
                this.ProcessFields(type.BaseType, shift, path);
            }
            foreach (MemberInfo info in type.GetMembers(BindingFlags.NonPublic | BindingFlags.Public | BindingFlags.Instance))
            {
                object[] customAttributes = info.GetCustomAttributes(typeof(UpdateValueAttribute), true);
                if ((customAttributes != null) && (customAttributes.Length != 0))
                {
                    Type fieldType;
                    if (info is FieldInfo)
                    {
                        fieldType = ((FieldInfo) info).FieldType;
                    }
                    else
                    {
                        if (!(info is PropertyInfo))
                        {
                            goto Label_0388;
                        }
                        fieldType = ((PropertyInfo) info).PropertyType;
                    }
                    foreach (UpdateValueAttribute attribute in customAttributes)
                    {
                        if (((attribute.OnlyForType == null) || (attribute.OnlyForType == this.m_type)) || this.m_type.IsSubclassOf(attribute.OnlyForType))
                        {
                            int num = ((attribute.Field == -1) ? 0 : attribute.Field) + shift;
                            if (fieldType.IsArray)
                            {
                                if (attribute.ArraySize == -1)
                                {
                                    throw new UpdateManagerException("ArraySize was not set on " + type.Name + "." + info.Name);
                                }
                                if (attribute.Field == -1)
                                {
                                    throw new UpdateManagerException("Field was not set on the array " + type.Name + "." + info.Name);
                                }
                                Type elementType = fieldType.GetElementType();
                                if (elementType.IsPrimitive)
                                {
                                    int num2 = GetTypeSize(elementType) / 4;
                                    for (int i = 0; i < attribute.ArraySize; i++)
                                    {
                                        UpdateFieldInfo info2;
                                        int num4 = num + (num2 * i);
                                        if (num4 >= this.m_fields.Length)
                                        {
                                            throw new UpdateManagerException(string.Format("Field index out of bounds {2} {0} for.{1}", type.Name, info.Name, num4));
                                        }
                                        if (this.m_fields[num4] == null)
                                        {
                                            this.m_fields[num4] = info2 = new UpdateFieldInfo(num4);
                                        }
                                        else
                                        {
                                            info2 = this.m_fields[num4];
                                        }
                                        info2.AddSubField(elementType, new CustomMemberInfo(info, path, i, attribute.BytesIndex + (attribute.ShortsIndex * 2)), attribute.Private);
                                        LogConsole.WriteLine(RunServer.Common.LogLevel.ECHO, "Registered field {0}, for type {1} in type {2}", new object[] { num4, type, this.m_type });
                                    }
                                }
                                else
                                {
                                    if (attribute.NumSubFields == -1)
                                    {
                                        throw new UpdateManagerException(string.Format("NumFields was not set on the subclass array {0}.{1}", type.Name, info.Name));
                                    }
                                    for (int j = 0; j < attribute.ArraySize; j++)
                                    {
                                        this.ProcessFields(elementType, num + (j * attribute.NumSubFields), new CustomMemberInfo(info, path, j));
                                    }
                                }
                            }
                            else if (fieldType.IsClass)
                            {
                                this.ProcessFields(fieldType, num, new CustomMemberInfo(info, path));
                            }
                            else
                            {
                                UpdateFieldInfo info3;
                                if (attribute.Field == -1)
                                {
                                    throw new UpdateManagerException(string.Format("Field was not set on the array {0}.{1}", type.Name, info.Name));
                                }
                                if (num >= this.m_fields.Length)
                                {
                                    throw new UpdateManagerException(string.Format("Field index out of bounds {2} {0} for.{1}", type.Name, info.Name, num));
                                }
                                if (this.m_fields[num] == null)
                                {
                                    this.m_fields[num] = info3 = new UpdateFieldInfo(num);
                                }
                                else
                                {
                                    info3 = this.m_fields[num];
                                }
                                info3.AddSubField(fieldType, new CustomMemberInfo(info, path, -1, attribute.BytesIndex + (attribute.ShortsIndex * 2)), attribute.Private);
                                LogConsole.WriteLine(RunServer.Common.LogLevel.ECHO, "Registered field {0}, for type {1} in type {2}", new object[] { num, type, this.m_type });
                            }
                        }
                    }
                Label_0388:;
                }
            }
        }

        public byte BlockSize
        {
            get
            {
                return this.m_blockSize;
            }
        }

        internal UpdateFieldInfo this[int index]
        {
            get
            {
                return this.m_fields[index];
            }
        }

        public int MaxFields
        {
            get
            {
                return this.m_maxFields;
            }
        }

        internal class ArrayFieldGetter : UpdateObjectInfo.IValueGetter
        {
            public static UpdateObjectInfo.ArrayFieldGetter Instance = new UpdateObjectInfo.ArrayFieldGetter();

            public object GetValue(object holder, MemberInfo member, int index)
            {
                return ((Array) ((FieldInfo) member).GetValue(holder)).GetValue(index);
            }
        }

        internal class ArrayPropertyGetter : UpdateObjectInfo.IValueGetter
        {
            public static UpdateObjectInfo.ArrayPropertyGetter Instance = new UpdateObjectInfo.ArrayPropertyGetter();

            public object GetValue(object holder, MemberInfo member, int index)
            {
                return ((Array) ((PropertyInfo) member).GetValue(holder, null)).GetValue(index);
            }
        }

        internal class CustomMemberInfo
        {
            private int m_index;
            private MemberInfo m_memberInfo;
            private UpdateObjectInfo.CustomMemberInfo[] m_memberTree;
            private UpdateObjectInfo.CustomMemberInfo m_parent;
            private int m_shift;
            private System.Type m_type;
            private UpdateObjectInfo.IValueGetter m_valueGetter;

            public CustomMemberInfo(MemberInfo memberInfo, UpdateObjectInfo.CustomMemberInfo parent) : this(memberInfo, parent, -1, 0)
            {
            }

            public CustomMemberInfo(MemberInfo memberInfo, UpdateObjectInfo.CustomMemberInfo parent, int index) : this(memberInfo, parent, index, 0)
            {
            }

            public CustomMemberInfo(MemberInfo memberInfo, UpdateObjectInfo.CustomMemberInfo parent, int index, int shift)
            {
                this.m_memberInfo = memberInfo;
                this.m_parent = parent;
                this.m_index = index;
                this.m_shift = shift;
                if (this.m_memberInfo is FieldInfo)
                {
                    this.m_type = ((FieldInfo) this.m_memberInfo).FieldType;
                    if (this.m_type.IsArray && (index != -1))
                    {
                        this.m_valueGetter = UpdateObjectInfo.ArrayFieldGetter.Instance;
                    }
                    else if (this.m_type.IsEnum)
                    {
                        this.m_type = Enum.GetUnderlyingType(this.m_type);
                        this.m_valueGetter = new UpdateObjectInfo.EnumFieldGetter(this.m_type);
                    }
                    else
                    {
                        this.m_valueGetter = UpdateObjectInfo.SimpleFieldGetter.Instance;
                    }
                }
                else
                {
                    if (!(this.m_memberInfo is PropertyInfo))
                    {
                        throw new UpdateManagerException("Unknown member info type " + this.m_memberInfo);
                    }
                    this.m_type = ((PropertyInfo) this.m_memberInfo).PropertyType;
                    if (this.m_type.IsArray && (index != -1))
                    {
                        this.m_valueGetter = UpdateObjectInfo.ArrayPropertyGetter.Instance;
                    }
                    else if (this.m_type.IsEnum)
                    {
                        this.m_type = Enum.GetUnderlyingType(this.m_type);
                        this.m_valueGetter = new UpdateObjectInfo.EnumPropertyGetter(this.m_type);
                    }
                    else
                    {
                        this.m_valueGetter = UpdateObjectInfo.SimplePropertyGetter.Instance;
                    }
                }
            }

            public string GenerateName()
            {
                string text = string.Empty;
                if (this.m_memberTree == null)
                {
                    text = text + "." + this.m_memberInfo.Name;
                }
                else
                {
                    for (int i = this.m_memberTree.Length - 1; i >= 0; i--)
                    {
                        text = text + ((this.m_memberTree[i] == this) ? ("." + this.m_memberInfo.Name) : this.m_memberTree[i].GenerateName());
                    }
                }
                if (this.m_type.IsArray && (this.m_index != -1))
                {
                    object obj2 = text;
                    text = string.Concat(new object[] { obj2, "[", this.m_index, "]" });
                }
                return text;
            }

            public void GenerateTree()
            {
                if (this.m_memberTree == null)
                {
                    UpdateObjectInfo.CustomMemberInfo item = this;
                    CustomArrayList list = new CustomArrayList();
                    while (item != null)
                    {
                        list.Add(item);
                        item = item.Parent;
                    }
                    this.m_memberTree = (UpdateObjectInfo.CustomMemberInfo[]) list.ToArray(typeof(UpdateObjectInfo.CustomMemberInfo));
                }
            }

            public string GenerateType()
            {
                if (this.m_valueGetter is UpdateObjectInfo.EnumFieldGetter)
                {
                    return ("(" + this.m_type.Name + ")");
                }
                if (this.m_valueGetter is UpdateObjectInfo.EnumPropertyGetter)
                {
                    return ("(" + this.m_type.Name + ")");
                }
                return string.Empty;
            }

            public object GetSingleValue(object holder)
            {
                return this.m_valueGetter.GetValue(holder, this.m_memberInfo, this.m_index);
            }

            public object GetValue(object holder)
            {
                this.GenerateTree();
                for (int i = this.m_memberTree.Length - 1; i >= 0; i--)
                {
                    holder = this.m_memberTree[i].GetSingleValue(holder);
                }
                return holder;
            }

            public int Index
            {
                get
                {
                    return this.m_index;
                }
            }

            public UpdateObjectInfo.CustomMemberInfo Parent
            {
                get
                {
                    return this.m_parent;
                }
            }

            public int Shift
            {
                get
                {
                    return this.m_shift;
                }
            }

            public System.Type Type
            {
                get
                {
                    return this.m_type;
                }
            }
        }

        internal class EnumFieldGetter : UpdateObjectInfo.IValueGetter
        {
            private Type m_underlyingType;

            public EnumFieldGetter(Type underlyingType)
            {
                this.m_underlyingType = underlyingType;
            }

            public object GetValue(object holder, MemberInfo member, int index)
            {
                return Convert.ChangeType(((FieldInfo) member).GetValue(holder), this.m_underlyingType);
            }

            public Type UnderlyingType
            {
                get
                {
                    return this.m_underlyingType;
                }
            }
        }

        internal class EnumPropertyGetter : UpdateObjectInfo.IValueGetter
        {
            private Type m_underlyingType;

            public EnumPropertyGetter(Type underlyingType)
            {
                this.m_underlyingType = underlyingType;
            }

            public object GetValue(object holder, MemberInfo member, int index)
            {
                return Convert.ChangeType(((PropertyInfo) member).GetValue(holder, null), this.m_underlyingType);
            }

            public Type UnderlyingType
            {
                get
                {
                    return this.m_underlyingType;
                }
            }
        }

        internal interface IValueGetter
        {
            object GetValue(object holder, MemberInfo member, int index);
        }

        internal class SimpleFieldGetter : UpdateObjectInfo.IValueGetter
        {
            public static UpdateObjectInfo.SimpleFieldGetter Instance = new UpdateObjectInfo.SimpleFieldGetter();

            public object GetValue(object holder, MemberInfo member, int index)
            {
                return ((FieldInfo) member).GetValue(holder);
            }
        }

        internal class SimplePropertyGetter : UpdateObjectInfo.IValueGetter
        {
            public static UpdateObjectInfo.SimplePropertyGetter Instance = new UpdateObjectInfo.SimplePropertyGetter();

            public object GetValue(object holder, MemberInfo member, int index)
            {
                return ((PropertyInfo) member).GetValue(holder, null);
            }
        }

        internal class UpdateFieldInfo
        {
            private bool m_doubleField;
            private int m_field;
            private int m_maskIndexFirst;
            private int m_maskIndexSecond;
            private byte m_maskValueFirst;
            private byte m_maskValueSecond;
            private CustomArrayList m_members;
            private bool m_private;

            public UpdateFieldInfo(int field)
            {
                this.m_field = field;
                this.m_private = false;
                this.m_members = new CustomArrayList();
                this.m_maskValueFirst = (byte) (((int) 1) << (field % 8));
                this.m_maskIndexFirst = field / 8;
            }

            public void AddSubField(Type type, UpdateObjectInfo.CustomMemberInfo member, bool isPrivate)
            {
                PooledList<object>.Enumerator<object> enumerator = this.m_members.GetEnumerator();
                try
                {
                    while (enumerator.MoveNext())
                    {
                        UpdateObjectInfo.CustomMemberInfo info = (UpdateObjectInfo.CustomMemberInfo) enumerator.Current;
                        if ((info.Shift == member.Shift) && (info.Index == member.Index))
                        {
                            return;
                        }
                    }
                }
                finally
                {
                    enumerator.Dispose();
                }
                this.m_members.Add(member);
                if (!this.m_doubleField && ((member.Shift > 3) || (UpdateObjectInfo.GetTypeSize(type) > 4)))
                {
                    this.m_doubleField = true;
                    this.m_maskIndexSecond = this.m_maskIndexFirst + (this.m_field % 2);
                    this.m_maskValueSecond = (byte) (((int) 1) << ((this.m_field + 1) % 8));
                }
                if (!this.m_private && isPrivate)
                {
                    this.m_private = true;
                }
            }

            public void GenerateCode(TextWriter writer, string tabs, string binWriter, string nobj, string mask)
            {
                writer.Write(tabs);
                writer.WriteLine("{0}[{1}] |= {2};", mask, this.m_maskIndexFirst, this.m_maskValueFirst);
                if (this.m_doubleField)
                {
                    writer.Write(tabs);
                    writer.WriteLine("{0}[{1}] |= {2};", mask, this.m_maskIndexSecond, this.m_maskValueSecond);
                }
                UpdateObjectInfo.CustomMemberInfo info = (UpdateObjectInfo.CustomMemberInfo) this.m_members[0];
                if ((((this.m_members.Count == 1) && (info.Type != typeof(byte))) && ((info.Type != typeof(sbyte)) && (info.Type != typeof(short)))) && (info.Type != typeof(ushort)))
                {
                    info.GenerateTree();
                    writer.Write(tabs);
                    writer.WriteLine("{0}.Write({1}{2}{3});", new object[] { binWriter, info.GenerateType(), nobj, info.GenerateName() });
                }
                else
                {
                    UpdateObjectInfo.CustomMemberInfo[] infoArray;
                    bool flag = false;
                    if ((info.Type == typeof(byte)) || (info.Type == typeof(sbyte)))
                    {
                        infoArray = new UpdateObjectInfo.CustomMemberInfo[this.m_doubleField ? 8 : 4];
                        flag = true;
                    }
                    else
                    {
                        if ((info.Type != typeof(short)) && (info.Type != typeof(ushort)))
                        {
                            throw new Exception("Got several MembeInfos of type " + info.Type);
                        }
                        infoArray = new UpdateObjectInfo.CustomMemberInfo[this.m_doubleField ? 4 : 2];
                    }
                    PooledList<object>.Enumerator<object> enumerator = this.m_members.GetEnumerator();
                    try
                    {
                        while (enumerator.MoveNext())
                        {
                            UpdateObjectInfo.CustomMemberInfo info2 = (UpdateObjectInfo.CustomMemberInfo) enumerator.Current;
                            infoArray[flag ? info2.Shift : (info2.Shift / 2)] = info2;
                        }
                    }
                    finally
                    {
                        enumerator.Dispose();
                    }
                    for (int i = 0; i < infoArray.Length; i++)
                    {
                        writer.Write(tabs);
                        if (infoArray[i] != null)
                        {
                            infoArray[i].GenerateTree();
                            writer.WriteLine("{0}.Write({1}{2}{3});", new object[] { binWriter, infoArray[i].GenerateType(), nobj, infoArray[i].GenerateName() });
                        }
                        else
                        {
                            writer.WriteLine("{0}.Write(({1})0);", binWriter, info.Type.Name);
                        }
                    }
                }
            }

            public void WriteValue(object holder, BinWriter w, byte[] mask)
            {
                int position = w.Position;
                mask[this.m_maskIndexFirst] = (byte) (mask[this.m_maskIndexFirst] | this.m_maskValueFirst);
                if (this.m_doubleField)
                {
                    mask[this.m_maskIndexSecond] = (byte) (mask[this.m_maskIndexSecond] | this.m_maskValueSecond);
                }
                w.Write(new byte[this.m_doubleField ? 8 : 4]);
                for (int i = 0; i < this.m_members.Count; i++)
                {
                    UpdateObjectInfo.CustomMemberInfo info = (UpdateObjectInfo.CustomMemberInfo) this.m_members[i];
			LogConsole.WriteLine(LogLevel.ECHO, "VALUE = "+info.GetValue(holder));
                    w.SetObject(position + info.Shift, info.GetValue(holder));
                }
            }

            public bool Private
            {
                get
                {
                    return this.m_private;
                }
            }
        }
    }
}

