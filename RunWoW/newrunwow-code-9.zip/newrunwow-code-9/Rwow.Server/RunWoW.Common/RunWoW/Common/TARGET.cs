﻿namespace RunWoW.Common
{
    using System;

    public enum TARGET
    {
        ANY = 0,
        TARGET_AREA_ENEMY = 15,
        TARGET_AREA_ENEMY_CHANNEL = 0x1c,
        TARGET_AREA_ENEMY_INSTANT = 0x10,
        TARGET_AREA_ENEMY_TARGET = 0x35,
        TARGET_AREA_PARTY = 20,
        TARGET_AREA_PARTY2 = 0x25,
        TARGET_CHAIN = 0x2d,
        TARGET_DY_OBJ = 0x2f,
        TARGET_GOITEM = 0x1a,
        TARGET_INFRONT_ENEMIES = 0x18,
        TARGET_MINION = 0x20,
        TARGET_NEAR_ENEMIES = 0x16,
        TARGET_PET = 5,
        TARGET_SELF = 1,
        TARGET_SELF_FISHING = 0x27,
        TARGET_SINGLE_ALLY = 4,
        TARGET_SINGLE_ENEMY = 6,
        TARGET_SINGLE_ENEMY2 = 0x19,
        TARGET_SINGLE_FRIEND = 0x15,
        TARGET_SINGLE_FRIEND2 = 0x39,
        TARGET_SINGLE_GO = 0x17,
        TARGET_SINGLE_PARTY = 0x23,
        TARGET_TOTEM_AIR = 0x2b,
        TARGET_TOTEM_EARTH = 0x29,
        TARGET_TOTEM_FIRE = 0x2c,
        TARGET_TOTEM_WATER = 0x2a
    }
}

