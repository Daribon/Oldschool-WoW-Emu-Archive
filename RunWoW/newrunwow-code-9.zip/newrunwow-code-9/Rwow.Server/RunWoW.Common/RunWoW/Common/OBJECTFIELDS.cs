﻿namespace RunWoW.Common
{
    using System;

    public enum OBJECTFIELDS
    {
        GUID = 0,
        HIER_TYPE = 2,
        ENTRY = 3,
        SCALE = 4,
        PADDING = 5,
        MAX = 5
    }
}

