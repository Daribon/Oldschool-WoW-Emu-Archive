﻿namespace RunWoW.Common
{
    using System;

    public enum MechanicDispelType
    {
        CHARM = 1,
        FEAR = 5,
        FREEZE = 13,
        HORROR = 0x18,
        INCAPACITATE = 14,
        MOUNT = 0x15,
        NONE = 0,
        POLYMORPH = 0x11,
        ROOT = 7,
        SHIELD = 0x13,
        SLEEP = 10,
        SNARE = 11,
        STUN = 12
    }
}

