//
namespace RunWoW.Common
{
    using System;

    public enum DAMAGETYPE
    {
        PHYSICAL,
        HOLY,
        FIRE,
        NATURE,
        FROST,
        SHADOW,
        ARCANE,
        MAX
    }
}

