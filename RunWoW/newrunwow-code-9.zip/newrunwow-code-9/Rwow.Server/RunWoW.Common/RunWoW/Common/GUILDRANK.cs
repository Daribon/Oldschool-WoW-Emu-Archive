﻿namespace RunWoW.Common
{
    using System;

    public enum GUILDRANK
    {
        GM,
        OFFICER,
        VETERAN,
        MEMBER,
        INITIATE
    }
}

