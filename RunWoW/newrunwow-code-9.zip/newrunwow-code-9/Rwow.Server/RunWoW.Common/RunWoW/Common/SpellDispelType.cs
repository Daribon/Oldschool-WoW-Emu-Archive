﻿namespace RunWoW.Common
{
    using System;

    public enum SpellDispelType
    {
        NONE,
        MAGIC,
        CURSE,
        DISEASE,
        POISON,
        STEALTH,
        INVISIBILITY,
        ALL,
        SPECIAL,
        FRENZY,
        TRINKETS
    }
}

