//
namespace RunWoW.Common
{
    using System;

    [AttributeUsage(AttributeTargets.Class)]
    public class UpdateObjectAttribute : Attribute
    {
        private int m_maxFields = -1;

        public int MaxFields
        {
            get
            {
                return this.m_maxFields;
            }
            set
            {
                this.m_maxFields = value;
            }
        }
    }
}

