﻿namespace RunWoW.Common
{
    using System;

    public enum PROJECTILESUBCLASS
    {
        WAND,
        BOLT,
        ARROW,
        BULLET,
        THROWN
    }
}

