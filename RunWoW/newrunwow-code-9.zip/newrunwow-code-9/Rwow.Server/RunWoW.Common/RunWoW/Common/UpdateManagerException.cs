﻿namespace RunWoW.Common
{
    using System;

    public class UpdateManagerException : ApplicationException
    {
        public UpdateManagerException(string message) : base(message)
        {
        }

        public UpdateManagerException(string message, Exception e) : base(message, e)
        {
        }
    }
}

