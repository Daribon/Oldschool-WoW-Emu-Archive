﻿namespace RunWoW.Common
{
    using System;

    public enum IMSG
    {
        CLIENT_CONNECTED,
        CLIENT_DISCONNECTED,
        SERVER_EXITING,
        SERVER_RESTARTING,
        PARSE_WDB,
        FORCE_SAVE,
        RELOAD_ACCOUNTS,
        RECALC_HONOR
    }
}

