//
namespace RunWoW.Common
{
    using System;

    public enum WeatherSound
    {
        NONE = 0,
        RAINHEAVY = 0x2157,
        RAINLIGHT = 0x2155,
        RAINMEDIUM = 0x2156,
        SANDSTORMHEAVY = 0x216e,
        SANDSTORMLIGHT = 0x216c,
        SANDSTORMMEDIUM = 0x216d,
        SNOWHEAVY = 0x215a,
        SNOWLIGHT = 0x2158,
        SNOWMEDIUM = 0x2159
    }
}

