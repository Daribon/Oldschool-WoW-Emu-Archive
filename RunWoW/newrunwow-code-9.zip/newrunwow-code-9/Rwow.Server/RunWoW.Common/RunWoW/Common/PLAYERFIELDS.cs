//
namespace RunWoW.Common
{
    using System;

    public enum PLAYERFIELDS
    {
        START                              = 0x00E2,
        DUEL_ARBITER                       = 0x00E2, // 2 4 1
        FLAGS                              = 0x00E4, // 1 1 1
        GUILD_ID                            = 0x00E5, // 1 1 1
        GUILD_RANK                          = 0x00E6, // 1 1 1
        BYTES_1                              = 0x00E7, // 1 5 1
        BYTES_2                            = 0x00E8, // 1 5 1
        BYTES_3                            = 0x00E9, // 1 5 1
        DUEL_TEAM                          = 0x00EA, // 1 1 1
        GUILD_TIMESTAMP                    = 0x00EB, // 1 1 1
        QUEST_LOG                      = 0x00EC, // 1 1 64
        VISIBLE_ITEM             = 0x0137, // 2 4 1
        CHOSEN_TITLE                       = 0x0267, // 1 1 1
        INV_SLOTS                = 0x0268, // 46 4 2
        PACK_SLOT                  = 0x0296, // 32 4 2
        BANK_SLOT                  = 0x02B6, // 56 4 2
        BANKBAG_SLOT               = 0x02EE, // 14 4 2
        VENDORBUYBACK_SLOT         = 0x02FC, // 24 4 2
        KEYRING_SLOT               = 0x0314, // 64 4 2
        FARSIGHT                           = 0x0354, // 2 4 2
        KNOWN_TITLES                = 0x0356, // 2 4 2
        XP                                 = 0x0358, // 1 1 2
        NEXT_LEVEL_XP                      = 0x0359, // 1 1 2
        SKILL_INFO                     = 0x035A, // 384 2 2
        TALENT_POINTS                  = 0x04DA, // 1 1 2
        PROF_POINTS                  = 0x04DB, // 1 1 2
        TRACK_CREATURES                    = 0x04DC, // 1 1 2
        TRACK_RESOURCES                    = 0x04DD, // 1 1 2
        BLOCK_PERCENTAGE                   = 0x04DE, // 1 3 2
        DODGE_PERCENTAGE                   = 0x04DF, // 1 3 2
        PARRY_PERCENTAGE                   = 0x04E0, // 1 3 2
        CRIT_PERCENTAGE                    = 0x04E1, // 1 3 2
        RANGED_CRIT_PERCENTAGE             = 0x04E2, // 1 3 2
        OFFHAND_CRIT_PERCENTAGE            = 0x04E3, // 1 3 2
        SPELL_CRIT_PERCENTAGE             = 0x04E4, // 7 3 2

    // custom
        HOLY_CRIT_PERCENTAGE         = 0X04E5,
        FIRE_CRIT_PERCENTAGE         = 0X04E6,
        NATURE_CRIT_PERCENTAGE       = 0X04E7,
        FROST_CRIT_PERCENTAGE        = 0X04E8,
        SHADOW_CRIT_PERCENTAGE       = 0X04E9,
        ARCANE_CRIT_PERCENTAGE       = 0X04EA,

        EXPLORED_ZONES                   = 0x04EB, // 64 5 2
        REST_STATE_EXPERIENCE              = 0x052B, // 1 1 2
        COINAGE                      = 0x052C, // 1 1 2
        MOD_DAMAGE_DONE_POS = 0x52D,
        DAMAGEMODSPOSITIVE0       = 0x52D,
        DAMAGEMODSPOSITIVE1     = 0x52E,
        DAMAGEMODSPOSITIVE2     = 0x52F,
        DAMAGEMODSPOSITIVE3     = 0x530,
        DAMAGEMODSPOSITIVE4     = 0x531,
        DAMAGEMODSPOSITIVE5     = 0x532,
        DAMAGEMODSPOSITIVE6     = 0x533,
        MOD_DAMAGE_DONE_NEG = 0x534,
        DAMAGEMODSNEGATIVE0 = 0x534,
        DAMAGEMODSNEGATIVE1 = 0x535,
        DAMAGEMODSNEGATIVE2 = 0x536,
        DAMAGEMODSNEGATIVE3 = 0x537,
        DAMAGEMODSNEGATIVE4 = 0x538,
        DAMAGEMODSNEGATIVE5 = 0x539,
        DAMAGEMODSNEGATIVE6 = 0x53A,
        MOD_DAMAGE_DONE_PCT = 0x53B,
        DAMAGEMODSPCT0 = 0x53B,
        DAMAGEMODSPCT1 = 0x53C,
        DAMAGEMODSPCT2 = 0x53D,
        DAMAGEMODSPCT3 = 0x53E,
        DAMAGEMODSPCT4 = 0x53F,
        DAMAGEMODSPCT5 = 0x540,
        DAMAGEMODSPCT6 = 0x541,
        MOD_HEALING_DONE_POS         = 0x0542, // 1 1 2
        MOD_TARGET_RESISTANCE        = 0x0543, // 1 1 2
        BYTES_4                        = 0x0544, // 1 5 2
        AMMO_ID                            = 0x0545, // 1 1 2
        SELF_RES_SPELL                     = 0x0546, // 1 1 2
        PVP_MEDALS                   = 0x0547, // 1 1 2
        BUYBACK_PRICE              = 0x0548, // 12 1 2
        BUYBACK_TIMESTAMP          = 0x0554, // 12 1 2
        KILLS                        = 0x0560, // 1 2 2
        TODAY_CONTRIBUTION           = 0x0561, // 1 1 2
        YESTERDAY_CONTRIBUTION       = 0x0562, // 1 1 2
        HONORBALE_KILLS     = 0x0563, // 1 1 2
        BYTES_5                       = 0x0564, // 1 5 2
        WATCHED_FACTION_INDEX        = 0x0565, // 1 1 2
        COMBAT_RATING              = 0x0566, // 23 1 2

    // custom
        ALL_WEAPONS_SKILL_RATING     = 0x566,
        DEFENCE_SKILL_RATING         = 0x567,
        DODGE_RATING                 = 0x568,
        PARRY_RATING                 = 0x569,
        BLOCK_RATING                 = 0x56A,
        HIT_MELEE_RATING             = 0x56B,
        HIT_RANGED_RATING            = 0x56C,
        HIT_SPELL_RATING             = 0x56D,
        CRIT_MELEE_RATING            = 0x56E,
        CRIT_RANGED_RATING           = 0x56F,
        CRIT_SPELL_RATING            = 0x570,
        HIT_TAKEN_MELEE_RATING       = 0x571,
        HIT_TAKEN_RANGED_RATING      = 0x572,
        HIT_TAKEN_SPELL_RATING       = 0x573,
        CRIT_TAKEN_MELEE_RATING      = 0x574,
        CRIT_TAKEN_RANGED_RATING     = 0x575,
        CRIT_TAKEN_SPELL_RATING      = 0x576,
        HASTE_MELEE_RATING           = 0x577,
        HASTE_RANGED_RATING          = 0x578,
        HASTE_SPELL_RATING           = 0x579,
        MELEE_WEAPON_SKILL_RATING    = 0x57A,
        OFFHAND_WEAPON_SKILL_RATING  = 0x57B,
        RANGED_WEAPON_SKILL_RATING   = 0x57C,

        ARENA_TEAM_INFO          = 0x057D, // 15 1 2

    // custom
        ARENA_TEAM_ID_2v2            = ARENA_TEAM_INFO,
        ARENA_TEAM_ID_3v3            = ARENA_TEAM_INFO+5,
        ARENA_TEAM_ID_5v5            = ARENA_TEAM_INFO+10,

        HONOR_CURRENCY               = 0x058C, // 1 1 2
        ARENA_CURRENCY               = 0x058D, // 1 1 2
        MOD_MANA_REGEN               = 0x058E, // 1 3 2
        MOD_MANA_REGEN_INTERRUPT     = 0x058F, // 1 3 2
        MAX_LEVEL                    = 0x0590, // 1 1 2
        DAILY_QUESTS_1               = 0x0591, // 10 1 2
        PADDING                      = 0x059B, // 1 1 0
        MAX = 0x59C,
/*
        RESILIENCE_RATING = 0x57c,
        SELECTION = 0x10,
*/
    }
}

