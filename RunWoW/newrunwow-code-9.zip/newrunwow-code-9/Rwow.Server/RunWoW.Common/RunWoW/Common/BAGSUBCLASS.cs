﻿namespace RunWoW.Common
{
    using System;

    public enum BAGSUBCLASS
    {
        ENCHANTING = 3,
        ENGINEERING = 8,
        GEMS = 10,
        HERBS = 2,
        KEYS = 9,
        NONE = 0,
        SOUL_SHARDS = 1
    }
}

