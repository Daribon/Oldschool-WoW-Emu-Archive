﻿namespace RunWoW.Common
{
    using System;

    public enum CORPSEFIELDS
    {
        BYTES_1 = 0x20,
        BYTES_2 = 0x21,
        DISPLAY_ID = 12,
        DYNAMIC_FLAGS = 0x24,
        FACING = 8,
        FLAGS = 0x23,
        GUILD = 0x22,
        ITEM = 13,
        MAX = 0x25,
        OWNER = 6,
        PADDING = 0x25,
        POS_X = 9,
        POS_Y = 10,
        POS_Z = 11,
        START = 6
    }
}

