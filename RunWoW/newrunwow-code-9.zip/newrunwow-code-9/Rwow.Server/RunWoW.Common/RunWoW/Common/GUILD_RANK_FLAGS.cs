﻿namespace RunWoW.Common
{
    using System;

    public enum GUILD_RANK_FLAGS
    {
        ALL = 0x1f1ff,
        CHANGEINFO = 0x10000,
        DEMOTE = 0x100,
        EMPTY = 0x40,
        EOFFNOTE = 0x8000,
        EPNOTE = 0x2000,
        GCHATLISTEN = 1,
        GCHATSPEAK = 2,
        INVITE = 0x10,
        OFFCHATLISTEN = 4,
        OFFCHATSPEAK = 8,
        PROMOTE = 0x80,
        REMOVE = 0x20,
        SETMOTD = 0x1000,
        VIEWOFFNOTE = 0x4000
    }
}

