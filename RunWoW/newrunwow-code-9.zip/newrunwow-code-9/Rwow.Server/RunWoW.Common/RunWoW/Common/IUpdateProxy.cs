//
namespace RunWoW.Common
{
    using RunServer.Common;
    using System;
    using System.Collections;

    public interface IUpdateProxy
    {
        void ClearPrivates(BitArray values);
        bool GetPrivate(int id);
        void WriteUpdates(BinWriter writer, BitArray values, object obj, bool isPrivate, bool clearValues);
    }
}

