﻿namespace RunWoW.Common
{
    using System;

    public enum CONTAINERFIELDS
    {
        ALIGN_PAD = 0x3d,
        MAX = 0x86,
        NUM_SLOTS = 60,
        SLOTS = 0x3e,
        START = 60
    }
}

