﻿namespace RunWoW.Common
{
    using System;

    public enum WEAPONSUBCLASS
    {
        ONEHANDAXE,
        TWOHANDAXE,
        BOW,
        GUN,
        ONEHANDBLUNT,
        TWOHANDBLUNT,
        POLEARM,
        ONEHANDSWORD,
        TWOHANDSWORD,
        NOTVALID9,
        STAFF,
        ONEHANDEXOTIC,
        TWOHANDEXOTIC,
        UNARMED,
        GENERIC,
        DAGGER,
        THROWN,
        SPEAR,
        CROSSBOW,
        WAND,
        FISHING
    }
}

