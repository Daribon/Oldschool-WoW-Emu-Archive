//
namespace RunWoW.Common
{
    using RunServer.Common;
    using System;
    using System.Threading;

    public class ShortPacket : BinWriter, IPacket
    {
        private int m_finishedFlag;
        private DateTime m_innerTime;
        private SMSG m_msgID;
        private DateTime m_processTime;
        private int m_users;

        public ShortPacket(SMSG msgID)
        {
            this.m_msgID = msgID;
            this.Write((short) 0);
            this.Write((ushort) msgID);
        }

        internal ShortPacket(SMSG msgID, int length) : base(length + 4)
        {
            this.m_msgID = msgID;
            this.Write((short) 0);
            this.Write((ushort) msgID);
        }

        public void Aquire()
        {
            Interlocked.Increment(ref this.m_users);
            if (base.Disposed)
            {
                throw new Exception("Aquiring exposed packet!");
            }
        }

        public ShortPacket Clone()
        {
            ShortPacket packet = new ShortPacket(this.m_msgID, base.Length);
            packet.Write((IntPtr) (base.GetHandle().ToInt32() + 4), base.Length - 4);
            packet.InnerTime = this.InnerTime;
            packet.ProcessTime = this.ProcessTime;
            return packet;
        }

        public void Finish()
        {
            if (Interlocked.CompareExchange(ref this.m_finishedFlag, 1, 0) == 0)
            {
                ushort num = (ushort) (base.Length - 2);
                num = (ushort) ((num >> 8) + ((num & 0xff) << 8));
                base.Set(0, num);
                base.Set(2, (ushort) this.m_msgID);
            }
        }

        public void Release()
        {
            Interlocked.Decrement(ref this.m_users);
            if (this.m_users == 0)
            {
                base.Dispose();
            }
        }

        /*
        int IPacket.get_Length()
        {
            return base.Length;
        }

        IntPtr IPacket.GetHandle()
        {
            return base.GetHandle();
        }*/
        
        public virtual bool Empty
        {
            get
            {
                return false;
            }
        }

        public DateTime InnerTime
        {
            get
            {
                return this.m_innerTime;
            }
            set
            {
                this.m_innerTime = value;
            }
        }

        public SMSG MsgID
        {
            get
            {
                return this.m_msgID;
            }
        }

        public DateTime ProcessTime
        {
            get
            {
                return this.m_processTime;
            }
            set
            {
                this.m_processTime = value;
            }
        }

        public int Users
        {
            get
            {
                return this.m_users;
            }
        }
    }
}

