//
namespace RunWoW.Common
{
    using System;

    public enum ITEMCLASS
    {
        CONSUMABLE,
        CONTAINER,
        WEAPON,
        GEM,
        ARMOUR,
        REAGENT,
        PROJECTILE,
        TRADEGOODS,
        GENERIC,
        BOOK,
        MONEY,
        QUIVER,
        QUEST,
        KEYLOCKPICK,
        PERMANENT,
        JUNK,
        MAX
    }
}

