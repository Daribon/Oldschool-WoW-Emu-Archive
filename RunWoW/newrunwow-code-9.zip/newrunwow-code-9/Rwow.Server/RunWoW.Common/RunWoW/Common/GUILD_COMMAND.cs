﻿namespace RunWoW.Common
{
    using System;

    public enum GUILD_COMMAND
    {
        CREATE = 0,
        FOUNDER = 12,
        INVITE = 1,
        QUIT = 2
    }
}

