﻿namespace RunWoW.Common
{
    using System;

    public enum SPELLMODIFIER
    {
        CAST_TIME = 1,
        COOLDOWN = 3,
        CRIT_CHANCE = 9,
        DAMAGE = 0,
        DURATION = 7,
        MAX = 0x11,
        PCT_CAST_TIME = 14,
        PCT_CRIT_DAMAGE = 0x11,
        PCT_DAMAGE = 11,
        PCT_INTERRUPT = 13,
        PCT_POWER_COST = 0x10,
        PCT_RANGE = 12,
        PCT_THREAT = 15,
        PERIOD = 10,
        POWER_COST = 4,
        RADIUS = 6,
        RANGE = 5,
        THREAT = 8
    }
}

