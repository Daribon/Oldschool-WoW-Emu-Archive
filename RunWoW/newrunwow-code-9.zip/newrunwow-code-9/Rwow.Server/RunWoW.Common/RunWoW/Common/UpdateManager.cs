//
namespace RunWoW.Common
{
    using Microsoft.CSharp;
    using RunServer.Common;
    using System;
    using System.CodeDom.Compiler;
    using System.Collections;
    using System.Collections.Generic;
    using System.IO;
    using System.Reflection;

    public class UpdateManager
    {
        public static readonly UpdateManager Instance = new UpdateManager();
        private ArrayList m_assemblies = new ArrayList();
        private TempFileCollection m_files = new TempFileCollection();
        private Dictionary<string, Type> m_names = new Dictionary<string, Type>();
        private Dictionary<Type, IUpdateProxy> m_proxies = new Dictionary<Type, IUpdateProxy>();
        private Dictionary<Type, UpdateObjectInfo> m_types = new Dictionary<Type, UpdateObjectInfo>();

        private UpdateManager()
        {
        }

        private void AddReference(ArrayList namespaces, Type type)
        {
            if (!namespaces.Contains(type.Namespace))
            {
                namespaces.Add(type.Namespace);
            }
            if (!this.m_assemblies.Contains(type.Assembly))
            {
                this.m_assemblies.Add(type.Assembly);
            }
        }

        public void ClearPrivateFields(Type type, BitArray array)
        {
            if (!this.m_types.ContainsKey(type))
            {
                throw new UpdateManagerException("UpdateObjectInfo is missing for type " + type);
            }
            if (!this.m_proxies.ContainsKey(type))
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.WARNING, "Proxy not found for type " + type);
            }
            else
            {
                this.m_proxies[type].ClearPrivates(array);
            }
        }

        private void Compile()
        {
            CompilerParameters options = new CompilerParameters();
            options.GenerateExecutable = false;
            options.WarningLevel = 4;
            foreach (Assembly assembly in this.m_assemblies)
            {
                options.ReferencedAssemblies.Add(assembly.CodeBase.Replace("file:///", ""));
            }
            options.ReferencedAssemblies.Add("RunServer.Database.dll");
            options.ReferencedAssemblies.Add("RunWoW.Database.dll");
            CodeDomProvider provider = new CSharpCodeProvider();
            string[] fileNames = new string[this.m_files.Count];
            this.m_files.CopyTo(fileNames, 0);
            CompilerResults results = provider.CompileAssemblyFromFile(options, fileNames);
            if (results.Errors.Count > 0)
            {
                string text = string.Empty;
                foreach (string text2 in results.Output)
                {
                    text = text + text2 + Environment.NewLine;
                }
                Console.WriteLine(text);
                throw new Exception("Cannot compile proxies: " + text);
            }
            this.m_files.Delete();
            foreach (Type type in results.CompiledAssembly.GetTypes())
            {
                if (this.m_names.ContainsKey(type.Name))
                {
                    this.m_proxies[this.m_names[type.Name]] = (IUpdateProxy) Activator.CreateInstance(type);
                }
            }
        }

        private static void GenerateClearPrivates(TextWriter writer, Type type, UpdateObjectInfo info)
        {
            writer.WriteLine("\t\tpublic void ClearPrivates(BitArray values)");
            writer.WriteLine("\t\t{");
            for (int i = 0; i < info.MaxFields; i++)
            {
                if ((info[i] != null) && info[i].Private)
                {
                    writer.WriteLine("\t\t\tvalues[{0}] = false;", i);
                }
            }
            writer.WriteLine("\t\t}\n");
        }

        private static void GenerateFooter(TextWriter writer)
        {
            writer.WriteLine("\t}\n");
            writer.WriteLine("}\n");
        }

        private void GenerateHeader(TextWriter writer, Type type, ArrayList namespaces)
        {
            foreach (string text in namespaces)
            {
                writer.WriteLine("using {0};", text);
            }
            writer.WriteLine("\nnamespace {0}.Proxies\n{{", base.GetType().Namespace);
            writer.WriteLine("\tpublic class {0}Proxy : IUpdateProxy", type.Name);
            writer.WriteLine("\t{\n");
        }

        private static void GenerateIsPrivate(TextWriter writer, Type type, UpdateObjectInfo info)
        {
            writer.WriteLine("\t\tpublic bool GetPrivate(int field)");
            writer.WriteLine("\t\t{");
            writer.WriteLine("\t\t\treturn isPrivate[field];");
            writer.WriteLine("\t\t}");
            writer.WriteLine("\t\tprivate bool [] isPrivate;");
            writer.WriteLine("");
            writer.WriteLine("\t\tpublic {0}Proxy()", type.Name);
            writer.WriteLine("\t\t{");
            writer.WriteLine("\t\t\tisPrivate = new bool[{0}];", info.MaxFields);
            for (int i = 0; i < info.MaxFields; i++)
            {
                if (info[i] != null)
                {
                    writer.WriteLine("\t\t\tisPrivate[{0}] = {1};", i, info[i].Private.ToString().ToLower());
                }
            }
            writer.WriteLine("\t\t}\n");
        }

        public void GenerateProxies()
        {
            foreach (Type type in this.m_types.Keys)
            {
                this.GenerateProxy(type);
            }
            this.Compile();
        }

        public void GenerateProxy(Type type)
        {
            if (!this.m_types.ContainsKey(type))
            {
                throw new UpdateManagerException("UpdateObjectInfo is missing for type " + type);
            }
            UpdateObjectInfo info = this.m_types[type];
            ArrayList namespaces = new ArrayList();
            this.AddReference(namespaces, base.GetType());
            this.AddReference(namespaces, type);
            this.AddReference(namespaces, typeof(BinWriter));
            this.AddReference(namespaces, typeof(BitArray));
            this.AddReference(namespaces, typeof(Console));
            this.AddReference(namespaces, typeof(Exception));
            this.m_names.Add(type.Name + "Proxy", type);
            string path = string.Format(@"{0}\{1}Proxy.cs", this.m_files.TempDir, type.Name);
            using (FileStream stream = new FileStream(path, FileMode.Create, FileAccess.Write))
            {
                using (TextWriter writer = new StreamWriter(stream))
                {
                    this.GenerateHeader(writer, type, namespaces);
                    GenerateWrite(writer, type, info);
                    GenerateIsPrivate(writer, type, info);
                    GenerateClearPrivates(writer, type, info);
                    GenerateFooter(writer);
                }
            }
            this.m_files.AddFile(path, false);
        }

        private static void GenerateWrite(TextWriter writer, Type type, UpdateObjectInfo info)
        {
            writer.WriteLine("\t\tpublic void WriteUpdates(BinWriter writer, BitArray values, object obj, bool isPrivate, bool clearValues)");
            writer.WriteLine("\t\t{");
            writer.WriteLine("\t\t\t{0} nobj = obj as {0};", type.Name);
            writer.WriteLine("\t\t\twriter.Write((byte){0});", info.BlockSize);
            writer.WriteLine("\t\t\tbyte[] mask = new byte[{0}];\n", info.BlockSize * 4);
            writer.WriteLine("\t\t\tint maskPos = writer.Position;");
            writer.WriteLine("\t\t\twriter.Position += {0};", info.BlockSize * 4);
            for (int i = 0; i < info.MaxFields; i++)
            {
                if (info[i] != null)
                {
                    try
                    {
                        if (!info[i].Private)
                        {
                            writer.WriteLine("\t\t\t\tif (values[{0}])", i);
                        }
                        else
                        {
                            writer.WriteLine("\t\t\t\tif (isPrivate && values[{0}])", i);
                        }
                        writer.WriteLine("\t\t\t\t{");
                        info[i].GenerateCode(writer, "\t\t\t\t\t", "writer", "nobj", "mask");
                        writer.WriteLine("\t\t\t\t\tif (clearValues)");
                        writer.WriteLine("\t\t\t\t\t\tvalues[{0}] = false;", i);
                        writer.WriteLine("\t\t\t\t}");
                    }
                    catch (Exception exception)
                    {
                        Console.WriteLine("Exception while generating proxy " + exception);
                    }
                }
            }
            writer.WriteLine("\t\t\tint pos = writer.Position;");
            writer.WriteLine("\t\t\twriter.Position = maskPos;");
            writer.WriteLine("\t\t\twriter.Write(mask, {0});", info.BlockSize * 4);
            writer.WriteLine("\t\t\twriter.Position = pos;");
            writer.WriteLine("\t\t}\n");
        }

        public bool IsPrivateField(Type type, int index)
        {
            if (!this.m_types.ContainsKey(type))
            {
                throw new UpdateManagerException("UpdateObjectInfo is missing for type " + type);
            }
            if (!this.m_proxies.ContainsKey(type))
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.WARNING, "Proxy not found for type " + type);
            }
            else
            {
                return this.m_proxies[type].GetPrivate(index);
            }
            UpdateObjectInfo.UpdateFieldInfo info = this.m_types[type][index];
            if (info == null)
            {
                Console.WriteLine("Asked for unknown field {0} for object type {1}", index, type.Name);
                return false;
            }
            return info.Private;
        }

        public int MaxLength(Type type)
        {
            if (!this.m_types.ContainsKey(type))
            {
                throw new UpdateManagerException("UpdateObjectInfo is missing for type " + type);
            }
            return this.m_types[type].MaxFields;
        }

        public void Register(Type type)
        {
            if (this.m_types.ContainsKey(type))
            {
                throw new UpdateManagerException("Type " + type + " already registered!");
            }
            this.m_types[type] = new UpdateObjectInfo(type);
        }

        public void WriteSingleUpdate(BinWriter writer, int fieldId, object obj)
        {
            Type key = obj.GetType();
            if (!this.m_proxies.ContainsKey(key))
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.WARNING, "Proxy not found for type " + key);
            }
            if (!this.m_types.ContainsKey(key))
            {
                throw new UpdateManagerException("UpdateObjectInfo is missing for type " + key);
            }
            UpdateObjectInfo info = this.m_types[key];
            byte blockSize = info.BlockSize;
            writer.Write(blockSize);
            byte[] mask = new byte[blockSize * 4];
            int position = writer.Position;
            writer.Position += mask.Length;
            info[fieldId].WriteValue(obj, writer, mask);
            int num3 = writer.Position;
            writer.Position = position;
            writer.Write(mask, mask.Length);
            writer.Position = num3;
        }

        public void WriteUpdates(BinWriter writer, BitArray values, object obj, bool isPrivate, bool clearValues)
        {
            Type key = obj.GetType();
            if (!this.m_proxies.ContainsKey(key))
            {
                LogConsole.WriteLine(RunServer.Common.LogLevel.WARNING, "Proxy not found for type " + key);
            }
            else
            {
                this.m_proxies[key].WriteUpdates(writer, values, obj, isPrivate, clearValues);
                return;
            }
            if (!this.m_types.ContainsKey(key))
            {
                throw new UpdateManagerException("UpdateObjectInfo is missing for type " + key);
            }
            UpdateObjectInfo info = this.m_types[key];
            byte blockSize = info.BlockSize;
            writer.Write(blockSize);
            byte[] mask = new byte[blockSize * 4];
            int position = writer.Position;
            writer.Position += mask.Length;
            int num3 = 0;
            LogConsole.WriteLine(RunServer.Common.LogLevel.ECHO, "Processing with mask length {0} object {1} private: {2}", new object[] { mask.Length, obj, isPrivate });
            for (int i = 0; i < values.Length; i++)
            {
                if (values[i] && (isPrivate || !info[i].Private))
                {
                    info[i].WriteValue(obj, writer, mask);
                    if (clearValues)
                    {
                        values[i] = false;
                    }
                    num3++;
                }
            }
            LogConsole.WriteLine(RunServer.Common.LogLevel.ECHO, "Processed {0} fields", new object[] { num3 });
            int num5 = writer.Position;
            writer.Position = position;
            writer.Write(mask, mask.Length);
            writer.Position = num5;
        }
    }
}

