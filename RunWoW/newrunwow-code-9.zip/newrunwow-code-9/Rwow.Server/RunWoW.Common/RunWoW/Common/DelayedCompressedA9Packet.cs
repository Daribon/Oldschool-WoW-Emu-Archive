﻿namespace RunWoW.Common
{
    using System;
    using System.Collections;

    public class DelayedCompressedA9Packet
    {
        private CompressedA9Packet m_innerPacket;
        private IList m_list;

        public DelayedCompressedA9Packet(A9Packet packet)
        {
            this.m_list = new A9Packet[] { packet };
        }

        public DelayedCompressedA9Packet(IList list)
        {
            this.m_list = list;
        }

        public void Release()
        {
            if (this.m_innerPacket != null)
            {
                this.m_innerPacket.Release();
            }
        }

        public CompressedA9Packet InnerPacket
        {
            get
            {
                if (this.m_innerPacket == null)
                {
                    this.m_innerPacket = new CompressedA9Packet(this.m_list);
                    this.m_innerPacket.Aquire();
                }
                return this.m_innerPacket;
            }
        }
    }
}

