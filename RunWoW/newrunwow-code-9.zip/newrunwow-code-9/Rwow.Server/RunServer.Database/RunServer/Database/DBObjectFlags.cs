//
namespace RunServer.Database
{
    using System;

    [Flags]
    public enum DBObjectFlags : byte
    {
        Deleted = 8,
        Dirty = 1,
        New = 2,
        None = 0,
        Resolved = 4
    }
}

