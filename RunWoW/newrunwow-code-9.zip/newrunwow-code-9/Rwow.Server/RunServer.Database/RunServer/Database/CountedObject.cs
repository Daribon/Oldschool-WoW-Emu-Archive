//
namespace RunServer.Database
{
    using RunServer.Common;
    using System;

    public class CountedObject
    {
        private static SynchronizedDictionary<Type, int> m_instances = new SynchronizedDictionary<Type, int>();

        protected CountedObject()
        {
            Type key = base.GetType();
            if (!m_instances.ContainsKey(key))
            {
                m_instances[key] = 1;
            }
            else
            {
                SynchronizedDictionary<Type, int> instances;
                Type type2;
                (instances = m_instances)[type2 = key] = instances[type2] + 1;
            }
        }

        ~CountedObject()
        {
            this.FreeInstance();
        }

        protected void FreeInstance()
        {
            Type key = base.GetType();
            if (m_instances.ContainsKey(key))
            {
                SynchronizedDictionary<Type, int> instances;
                Type type2;
                (instances = m_instances)[type2 = key] = instances[type2] - 1;
            }
        }

        public static SynchronizedDictionary<Type, int> Instances
        {
            get
            {
                return m_instances;
            }
            set
            {
                m_instances = value;
            }
        }
    }
}

