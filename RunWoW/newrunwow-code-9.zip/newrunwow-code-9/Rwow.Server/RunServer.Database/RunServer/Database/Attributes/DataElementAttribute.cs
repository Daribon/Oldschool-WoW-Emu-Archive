﻿namespace RunServer.Database.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class DataElementAttribute : MemberValueAttribute
    {
        private bool allowDbNull = true;
        private bool unique = false;

        public bool AllowDbNull
        {
            get
            {
                return this.allowDbNull;
            }
            set
            {
                this.allowDbNull = value;
            }
        }

        public bool Unique
        {
            get
            {
                return this.unique;
            }
            set
            {
                this.unique = value;
            }
        }
    }
}

