﻿namespace RunServer.Database.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class IndexAttribute : DataElementAttribute
    {
        private bool m_skipZero;

        public bool SkipZero
        {
            get
            {
                return this.m_skipZero;
            }
            set
            {
                this.m_skipZero = value;
            }
        }
    }
}

