﻿namespace RunServer.Database.Attributes
{
    using System;

    [AttributeUsage(AttributeTargets.Field | AttributeTargets.Property)]
    public class PrimaryKeyAttribute : DataElementAttribute
    {
    }
}

