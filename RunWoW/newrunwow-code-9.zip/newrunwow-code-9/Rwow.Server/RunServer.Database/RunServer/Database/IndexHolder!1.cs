//
namespace RunServer.Database
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunServer.Database.MemberValues;
    using System;
    using System.Collections.Generic;

    public class IndexHolder<T> where T: DataObject
    {
        private SynchronizedDictionary<string, SynchronizedDictionary<object, SynchronizedDictionary<uint, uint>>> m_indexes;
        private MemberValue[] m_indexMemberValues;

        public IndexHolder(MemberValue[] fields)
        {
            this.m_indexMemberValues = fields;
            this.m_indexes = new SynchronizedDictionary<string, SynchronizedDictionary<object, SynchronizedDictionary<uint, uint>>>();
            foreach (MemberValue value2 in this.m_indexMemberValues)
            {
                this.m_indexes[value2.GetName()] = new SynchronizedDictionary<object, SynchronizedDictionary<uint, uint>>();
            }
        }

        public void GetObjects(string field, object key, ref PooledList<T> result, ref uint[] toGet)
        {
            if (this.m_indexes.ContainsKey(field))
            {
                if (key is string)
                {
                    key = ((string) key).ToLower();
                }
                if (this.m_indexes[field].ContainsKey(key))
                {
                    List<uint> list = new List<uint>();
                    lock (this.m_indexes[field][key])
                    {
                        foreach (KeyValuePair<uint, uint> pair in this.m_indexes[field][key])
                        {
                            list.Add(pair.Key);
                        }
                    }
                    toGet = list.ToArray();
                }
            }
        }

        public void ReindexObject(string field, object oldkey, object key, uint id)
        {
            if (this.m_indexes.ContainsKey(field))
            {
                if (oldkey is string)
                {
                    oldkey = ((string) oldkey).ToLower();
                }
                if (key is string)
                {
                    key = ((string) key).ToLower();
                }
                else
                {
                    foreach (MemberValue value2 in this.m_indexMemberValues)
                    {
                        if (((value2.GetName() == field) && ((IndexAttribute) value2.Attribute).SkipZero) && (((int) DBConvert.ChangeType(key, typeof(int))) == 0))
                        {
                            return;
                        }
                    }
                }
                if (this.m_indexes[field].ContainsKey(oldkey))
                {
                    this.m_indexes[field][oldkey].Remove(id);
                }
                if (!this.m_indexes[field].ContainsKey(key))
                {
                    this.m_indexes[field][key] = new SynchronizedDictionary<uint, uint>();
                }
                if (!this.m_indexes[field][key].ContainsKey(id))
                {
                    this.m_indexes[field][key][id] = id;
                }
            }
        }

        public void RemoveObject(T dataObject)
        {
            for (int i = 0; i < this.m_indexMemberValues.Length; i++)
            {
                object key = this.m_indexMemberValues[i].GetValue(dataObject);
                if (key != null)
                {
                    key = (key is string) ? ((string) key).ToLower() : key;
                    string name = this.m_indexMemberValues[i].GetName();
                    if (this.m_indexes[name].ContainsKey(key) && this.m_indexes[name][key].ContainsKey(dataObject.ObjectId))
                    {
                        this.m_indexes[name][key].Remove(dataObject.ObjectId);
                        if (this.m_indexes[name][key].Count == 0)
                        {
                            this.m_indexes[name].Remove(key);
                        }
                    }
                }
            }
        }

        public void SetIndexValues(object[][] values)
        {
            foreach (object[] objArray in values)
            {
                uint num = (uint) DBConvert.ChangeType(objArray[0], typeof(uint));
                for (int i = 0; i < this.m_indexMemberValues.Length; i++)
                {
                    MemberValue value2 = this.m_indexMemberValues[i];
                    object obj2 = objArray[i + 1];
                    if (obj2 is string)
                    {
                        obj2 = ((string) obj2).ToLower();
                    }
                    else if (((IndexAttribute) value2.Attribute).SkipZero && (((int) Convert.ChangeType(obj2, typeof(int))) == 0))
                    {
                        continue;
                    }
                    if (obj2.GetType() != value2.GetValueType())
                    {
                        obj2 = DBConvert.ChangeType(obj2, value2.GetValueType());
                    }
                    if (!this.m_indexes[value2.GetName()].ContainsKey(obj2))
                    {
                        this.m_indexes[value2.GetName()][obj2] = new SynchronizedDictionary<uint, uint>();
                    }
                    this.m_indexes[value2.GetName()][obj2][num] = num;
                }
            }
        }

        public void SubmitObject(T dataObject)
        {
            for (int i = 0; i < this.m_indexMemberValues.Length; i++)
            {
                object obj2 = this.m_indexMemberValues[i].GetValue(dataObject);
                if (obj2 != null)
                {
                    string name = this.m_indexMemberValues[i].GetName();
                    obj2 = (obj2 is string) ? ((string) obj2).ToLower() : obj2;
                    if (!((IndexAttribute) this.m_indexMemberValues[i].Attribute).SkipZero || (((int) DBConvert.ChangeType(obj2, typeof(int))) != 0))
                    {
                        if (!this.m_indexes[name].ContainsKey(obj2))
                        {
                            this.m_indexes[name][obj2] = new SynchronizedDictionary<uint, uint>();
                        }
                        if (!this.m_indexes[name][obj2].ContainsKey(dataObject.ObjectId))
                        {
                            this.m_indexes[name][obj2][dataObject.ObjectId] = dataObject.ObjectId;
                        }
                    }
                }
            }
        }

        public ICollection<string> IndexFields
        {
            get
            {
                return this.m_indexes.Keys;
            }
        }

        public MemberValue[] IndexMemberValues
        {
            get
            {
                return this.m_indexMemberValues;
            }
        }
    }
}

