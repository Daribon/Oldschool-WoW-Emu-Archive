//
namespace RunWoW.DB
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct DBVector
    {
        [DataElement(Name="X")]
        public float X;
        [DataElement(Name="Y")]
        public float Y;
        [DataElement(Name="Z")]
        public float Z;
        public RunServer.Common.Vector Vector
        {
            get
            {
                return new RunServer.Common.Vector(this.X, this.Y, this.Z);
            }
            set
            {
                this.X = value.X;
                this.Y = value.Y;
                this.Z = value.Z;
            }
        }
    }
}

