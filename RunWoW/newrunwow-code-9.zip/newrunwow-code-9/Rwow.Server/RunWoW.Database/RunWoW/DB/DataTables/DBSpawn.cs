//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="Spawn")]
    public class DBSpawn : DBBase
    {
        [Relation(LocalField="CreatureID", RemoteField="Creature_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBCreature Creature;
        [Relation(LocalField="QuestID", RemoteField="EndGroup", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBQuest> EndQuests;
        [Relation(LocalField="LootGroupID", RemoteField="LootGroupID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBLoot> Loot;
        private bool m_active;
        [DataElement(Name="BehaivorID")]
        internal byte m_behaivorID;
        private static ulong m_count;
        [Index(Name="CreatureID", Unique=true)]
        internal uint m_creatureID;
        [DataElement(Name="Facing")]
        internal float m_facing;
        [DataElement(Name="Faction")]
        internal FACTION m_faction;
        [DataElement(Name="Flags")]
        internal int m_Flags;
        [DataElement(Name="Health")]
        internal int m_health;
        [DataElement(Name="Level")]
        internal short m_level;
        [DataElement(Name="LootGroupID")]
        internal uint m_lootid;
        [DataElement(Name="NpcFlags")]
        internal uint m_npcFlags;
        [DataElement(Name="Position")]
        internal DBVector m_position;
        [DataElement(Name="Power")]
        internal int m_power;
        [DataElement(Name="QuestGroupID")]
        internal uint m_questid;
        [DataElement(Name="SpellGroupID")]
        internal uint m_spellid;
        [DataElement(Name="TaxiID")]
        internal uint m_taxiid;
        [DataElement(Name="TextID")]
        internal uint m_textid;
        [DataElement(Name="TradeGroupID")]
        internal uint m_tradeid;
        [DataElement(Name="TrainGroupID")]
        internal uint m_trainid;
        [DataElement(Name="VItem0")]
        internal ulong m_vi0;
        [DataElement(Name="VItem0D")]
        internal int m_vi0d;
        [DataElement(Name="VItem1")]
        internal ulong m_vi1;
        [DataElement(Name="VItem1D")]
        internal int m_vi1d;
        [DataElement(Name="VItem2")]
        internal ulong m_vi2;
        [DataElement(Name="VItem2D")]
        internal int m_vi2d;
        [Index(Name="WorldMapID")]
        internal uint m_worldMapID;
        [Relation(LocalField="ObjectId", RemoteField="OwnerID", AutoLoad=false, AutoDelete=true, AutoSave=false)]
        public PooledList<DBMovepoint> Movepoints;
        [Relation(LocalField="TextID", RemoteField="Speech_ID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public DBSpeech Speech;
        [Relation(LocalField="SpellGroupID", RemoteField="SpellGroupID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBMonsterSpell> Spells;
        [Relation(LocalField="QuestID", RemoteField="StartGroup", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBQuest> StartQuests;
        [Relation(LocalField="TaxiID", RemoteField="TaxiNode_ID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public DBTaxiNode Taxi;
        [Relation(LocalField="TradeGroupID", RemoteField="TradeGroupID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBTrade> Trade;
        [Relation(LocalField="TrainGroupID", RemoteField="TrainGroupID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBTrain> Train;

        public DBSpawn()
        {
            this.m_position = new DBVector();
            this.m_health = -1;
            this.m_power = -1;
            m_count++;
        }

        public DBSpawn(DBCreature creature, uint map, float facing, Vector position)
        {
            this.m_position = new DBVector();
            this.m_health = -1;
            this.m_power = -1;
            this.Creature = creature;
            this.CreatureID = creature.ObjectId;
            this.TextID = creature.ObjectId;
            this.QuestID = creature.ObjectId;
            this.SpellGroupID = creature.SpellGroupId;
            this.BehaivorID = (byte) creature.BehaivorId;
            this.TradeGroupID = creature.TradeGroupId;
            this.TrainGroupID = creature.TrainGroupId;
            this.LootGroupID = creature.LootGroupId;
            this.Flags = creature.Flags;
            this.NpcFlags = creature.NpcFlags;
            this.Faction = creature.Faction;
            this.Level = creature.Level;
            this.VirtualItem0 = creature.VItemInfo[0];
            this.VirtualItem1 = creature.VItemInfo[1];
            this.VirtualItem2 = creature.VItemInfo[2];
            this.VirtualItem0D = creature.VItemDisplay[0];
            this.VirtualItem1D = creature.VItemDisplay[1];
            this.VirtualItem2D = creature.VItemDisplay[2];
            this.WorldMapID = map;
            this.Facing = facing;
            this.Position = position.Clone();
        }

        ~DBSpawn()
        {
            m_count--;
        }

        public bool Active
        {
            get
            {
                return this.m_active;
            }
            set
            {
                this.m_active = value;
            }
        }

        public byte BehaivorID
        {
            get
            {
                return this.m_behaivorID;
            }
            set
            {
                base.Assign<byte>(ref this.m_behaivorID, value);
            }
        }

        public static ulong Count
        {
            get
            {
                return m_count;
            }
        }

        public uint CreatureID
        {
            get
            {
                return this.m_creatureID;
            }
            set
            {
                base.Assign<uint>(ref this.m_creatureID, value);
            }
        }

        public float Facing
        {
            get
            {
                return this.m_facing;
            }
            set
            {
                base.Assign<float>(ref this.m_facing, value);
            }
        }

        public FACTION Faction
        {
            get
            {
                return this.m_faction;
            }
            set
            {
                base.Assign<FACTION>(ref this.m_faction, value);
            }
        }

        public int Flags
        {
            get
            {
                return this.m_Flags;
            }
            set
            {
                base.Assign<int>(ref this.m_Flags, value);
            }
        }

        public int Health
        {
            get
            {
                return this.m_health;
            }
            set
            {
                base.Assign<int>(ref this.m_health, value);
            }
        }

        public short Level
        {
            get
            {
                return this.m_level;
            }
            set
            {
                base.Assign<short>(ref this.m_level, value);
            }
        }

        public uint LootGroupID
        {
            get
            {
                return this.m_lootid;
            }
            set
            {
                base.Assign<uint>(ref this.m_lootid, value);
            }
        }

        public uint NpcFlags
        {
            get
            {
                return this.m_npcFlags;
            }
            set
            {
                base.Assign<uint>(ref this.m_npcFlags, value);
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_position.Vector;
            }
            set
            {
                this.m_position.Vector = value;
            }
        }

        public int Power
        {
            get
            {
                return this.m_power;
            }
            set
            {
                base.Assign<int>(ref this.m_power, value);
            }
        }

        public uint QuestID
        {
            get
            {
                return this.m_questid;
            }
            set
            {
                base.Assign<uint>(ref this.m_questid, value);
            }
        }

        public uint SpellGroupID
        {
            get
            {
                return this.m_spellid;
            }
            set
            {
                base.Assign<uint>(ref this.m_spellid, value);
            }
        }

        public uint TaxiID
        {
            get
            {
                return this.m_taxiid;
            }
            set
            {
                base.Assign<uint>(ref this.m_taxiid, value);
            }
        }

        public uint TextID
        {
            get
            {
                return this.m_textid;
            }
            set
            {
                base.Assign<uint>(ref this.m_textid, value);
            }
        }

        public uint TradeGroupID
        {
            get
            {
                return this.m_tradeid;
            }
            set
            {
                base.Assign<uint>(ref this.m_tradeid, value);
            }
        }

        public uint TrainGroupID
        {
            get
            {
                return this.m_trainid;
            }
            set
            {
                base.Assign<uint>(ref this.m_trainid, value);
            }
        }

        public ulong VirtualItem0
        {
            get
            {
                return this.m_vi0;
            }
            set
            {
                base.Assign<ulong>(ref this.m_vi0, value);
            }
        }

        public int VirtualItem0D
        {
            get
            {
                return this.m_vi0d;
            }
            set
            {
                base.Assign<int>(ref this.m_vi0d, value);
            }
        }

        public ulong VirtualItem1
        {
            get
            {
                return this.m_vi1;
            }
            set
            {
                base.Assign<ulong>(ref this.m_vi1, value);
            }
        }

        public int VirtualItem1D
        {
            get
            {
                return this.m_vi1d;
            }
            set
            {
                base.Assign<int>(ref this.m_vi1d, value);
            }
        }

        public ulong VirtualItem2
        {
            get
            {
                return this.m_vi2;
            }
            set
            {
                base.Assign<ulong>(ref this.m_vi2, value);
            }
        }

        public int VirtualItem2D
        {
            get
            {
                return this.m_vi2d;
            }
            set
            {
                base.Assign<int>(ref this.m_vi2d, value);
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldMapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldMapID, value);
            }
        }
    }
}

