﻿namespace RunWoW.DB.DataTables
{
    using System;

    public class CharacterHolder
    {
        public byte Class;
        public string GuildOfficerNote;
        public string GuildPublicNote;
        public uint GuildRank;
        public DateTime LastAccess;
        public byte Level;
        public string Name;
        public uint ObjectId;
        public uint Zone;

        public CharacterHolder(DBCharacter character)
        {
            this.Update(character);
        }

        public void Update(DBCharacter character)
        {
            this.ObjectId = character.ObjectId;
            this.Name = character.Name;
            this.Level = character.Level;
            this.Class = (byte) character.Class;
            this.Zone = character.Zone;
            this.GuildRank = character.GuildRank;
            this.LastAccess = character.LastAccess;
            this.GuildPublicNote = character.GuildPublicNote;
            this.GuildOfficerNote = character.GuildOfficerNote;
        }
    }
}

