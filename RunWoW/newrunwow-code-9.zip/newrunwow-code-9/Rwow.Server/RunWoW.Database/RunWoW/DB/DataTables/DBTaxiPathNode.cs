﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="TaxiPathNode")]
    public class DBTaxiPathNode : DBBase
    {
        [DataElement(Name="Num")]
        internal uint m_num;
        [Index(Name="PathID")]
        internal uint m_path;
        [DataElement(Name="Position")]
        internal DBVector m_position = new DBVector();
        [DataElement(Name="WorldMapID")]
        internal uint m_worldMapID;

        public uint Number
        {
            get
            {
                return this.m_num;
            }
            set
            {
                base.Assign<uint>(ref this.m_num, value);
            }
        }

        public uint PathID
        {
            get
            {
                return this.m_path;
            }
            set
            {
                base.Assign<uint>(ref this.m_path, value);
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_position.Vector;
            }
            set
            {
                this.m_position.Vector = value;
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldMapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldMapID, value);
            }
        }
    }
}

