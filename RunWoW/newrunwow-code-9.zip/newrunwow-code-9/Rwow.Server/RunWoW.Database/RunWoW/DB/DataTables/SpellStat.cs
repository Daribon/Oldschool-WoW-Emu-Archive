//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct SpellStat
    {
        [DataElement]
        public uint ID;
        [DataElement]
        public int Trigger;
        [DataElement]
        public int Charges;
        [DataElement]
        public int Cooldown;
        [DataElement]
        public int Category;
        [DataElement]
        public int CategoryCooldown;
        public DBSpell Spell;
    }
}

