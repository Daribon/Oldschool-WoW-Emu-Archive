//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="WorldMap")]
    public class DBWorldMap : DBBase
    {
        [Relation(LocalField="ObjectId", RemoteField="WorldMapID", AutoLoad=false, AutoDelete=false, AutoSave=false, UseZero=true)]
        public PooledList<DBGameObject> GameObjects;
        [DataElement(Name="BottomX")]
        internal int m_bottomX;
        [DataElement(Name="BottomY")]
        internal int m_bottomY;
        [DataElement(Name="EnterLevel")]
        internal int m_enterLevel;
        [DataElement(Name="RessurectPosition")]
        internal DBVector m_resPosition;
        [DataElement(Name="RessurectWorld")]
        internal int m_resWorld;
        [DataElement(Name="SpiritHealerID")]
        internal int m_shid;
        [DataElement(Name="TileSize")]
        internal int m_tileSize;
        [DataElement(Name="TopX")]
        internal int m_topX;
        [DataElement(Name="TopY")]
        internal int m_topY;
        [Relation(LocalField="ObjectId", RemoteField="WorldMapID", AutoLoad=false, AutoDelete=false, AutoSave=false, UseZero=true)]
        public PooledList<DBSpawn> Spawns;

        public DBWorldMap()
        {
            this.m_shid = 0x195b;
            this.m_resWorld = -1;
            this.m_resPosition = new DBVector();
        }

        public DBWorldMap(int bottomX, int bottomY, int topX, int topY, int tileSize)
        {
            this.m_shid = 0x195b;
            this.m_resWorld = -1;
            this.m_resPosition = new DBVector();
            this.m_bottomX = bottomX;
            this.m_bottomY = bottomY;
            this.m_topX = topX;
            this.m_topY = topY;
            this.m_tileSize = tileSize;
            base.Dirty = true;
        }

        public int BottomX
        {
            get
            {
                return this.m_bottomX;
            }
        }

        public int BottomY
        {
            get
            {
                return this.m_bottomY;
            }
        }

        public int EnterLevel
        {
            get
            {
                return this.m_enterLevel;
            }
        }

        public Vector RessurectPosition
        {
            get
            {
                return this.m_resPosition.Vector;
            }
        }

        public int RessurectWorld
        {
            get
            {
                return this.m_resWorld;
            }
        }

        public int SpiritHealerID
        {
            get
            {
                return this.m_shid;
            }
        }

        public int TileSize
        {
            get
            {
                return this.m_tileSize;
            }
        }

        public int TopX
        {
            get
            {
                return this.m_topX;
            }
        }

        public int TopY
        {
            get
            {
                return this.m_topY;
            }
        }
    }
}

