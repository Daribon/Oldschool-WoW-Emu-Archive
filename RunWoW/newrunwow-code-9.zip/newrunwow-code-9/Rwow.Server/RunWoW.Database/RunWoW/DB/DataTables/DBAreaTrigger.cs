//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="AreaTrigger")]
    public class DBAreaTrigger : DBBase
    {
        [DataElement(Name="Enabled")]
        internal bool m_enabled;
        [DataElement(Name="Facing")]
        internal float m_facing;
        [DataElement(Name="Position")]
        internal DBVector m_pos = new DBVector();
        [DataElement(Name="Dismount")]
        internal bool m_tavern;
        [DataElement(Name="WorldMapID")]
        internal uint m_worldMapID;

        public bool Enabled
        {
            get
            {
                return this.m_enabled;
            }
            set
            {
                base.Assign<bool>(ref this.m_enabled, value);
            }
        }

        public float Facing
        {
            get
            {
                return this.m_facing;
            }
            set
            {
                base.Assign<float>(ref this.m_facing, value);
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_pos.Vector;
            }
            set
            {
                this.m_pos.Vector = value;
            }
        }

        public bool Tavern
        {
            get
            {
                return this.m_tavern;
            }
            set
            {
                base.Assign<bool>(ref this.m_tavern, value);
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldMapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldMapID, value);
            }
        }
    }
}

