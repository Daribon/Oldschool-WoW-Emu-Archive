//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct SpawnTemplate
    {
        [DataElement(Name="Level")]
        public short Level;
        [DataElement(Name="Faction")]
        public FACTION Faction;
        [DataElement(Name="Flags")]
        public int Flags;
        [DataElement(Name="NpcFlags")]
        public uint NpcFlags;
        [DataElement(Name="BehaivorID")]
        public sbyte BehaivorId;
        [DataElement(Name="SpellGroupID")]
        public uint SpellGroupId;
        [DataElement(Name="TradeGroupID")]
        public uint TradeGroupId;
        [DataElement(Name="TrainGroupID")]
        public uint TrainGroupId;
        [DataElement(Name="LootGroupID")]
        public uint LootGroupId;
        [DataElement(Name="VItemDisplay", ArraySize=3)]
        public int[] VItemDisplay;
        [DataElement(Name="VItemInfo", ArraySize=3)]
        public ulong[] VItemInfo;
        public SpawnTemplate(bool init)
        {
            this.VItemDisplay = new int[3];
            this.VItemInfo = new ulong[3];
            this.Level = 1;
            this.Faction = FACTION.NONE;
            this.Flags = 0;
            this.NpcFlags = 0;
            this.BehaivorId = 0;
            this.SpellGroupId = 0;
            this.TradeGroupId = 0;
            this.TrainGroupId = 0;
            this.LootGroupId = 0;
        }
    }
}
