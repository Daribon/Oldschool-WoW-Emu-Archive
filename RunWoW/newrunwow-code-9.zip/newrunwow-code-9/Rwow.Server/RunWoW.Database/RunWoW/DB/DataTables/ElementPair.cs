﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct ElementPair
    {
        [DataElement]
        public uint ID;
        [DataElement]
        public uint Count;
    }
}

