//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="ItemTemplate")]
    public class DBItemTemplate : DBBase
    {
        [Relation(LocalField="ObjectId", RemoteField="LootGroupID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBItemLoot> Loot;
        [DataElement(Name="Allowable_Class")]
        internal int m_allowableClass;
        [DataElement(Name="Allowable_Races")]
        internal int m_allowableRace;
        [DataElement(Name="Ammunition_Type")]
        internal int m_ammoType;
        [DataElement(Name="BagType")]
        internal int m_bagType;
        [DataElement(Name="Block")]
        internal int m_block;
        [DataElement(Name="Bounding")]
        internal int m_bonding;
        [DataElement(Name="Buy_Price")]
        internal int m_buyPrice;
        [DataElement(Name="Class")]
        internal ITEMCLASS m_class;
        [DataElement(Name="Container_Slots")]
        internal int m_containerSlots;
        [DataElement(Name="Damage", ArraySize=5)]
        internal DamageStat[] m_damageStats = new DamageStat[5];
        [DataElement(Name="Description")]
        internal string m_description = string.Empty;
        [DataElement(Name="Icon_ID")]
        internal int m_displayID;
        [DataElement(Name="Flags")]
        internal int m_flags;
        [DataElement(Name="Inventory_Type")]
        internal INVTYPE m_invType;
        [DataElement(Name="Bonus", ArraySize=10)]
        internal ItemBonus[] m_itemBonus = new ItemBonus[10];
        [DataElement(Name="Item_Level")]
        internal int m_itemlevel;
        [DataElement(Name="Language_ID")]
        internal int m_languageID;
        [DataElement(Name="Lock_ID")]
        internal int m_lock;
        [DataElement(Name="Material")]
        internal int m_material;
        [DataElement(Name="Max_Count")]
        internal int m_maxCount;
        [DataElement(Name="Max_Durability")]
        internal int m_maxDurability;
        [DataElement(Name="Stackable")]
        internal int m_maxStack = 1;
        [DataElement(Name="Required_Skill_Rank")]
        internal int m_minReqSkill;
        [DataElement(Name="InventoryName")]
        internal string m_name = "ITEM NAME UNSET!";
        [DataElement(Name="QuestName")]
        internal string m_name1 = string.Empty;
        [DataElement(Name="Name3")]
        internal string m_name2 = string.Empty;
        [DataElement(Name="Name4")]
        internal string m_name3 = string.Empty;
        [DataElement(Name="Overall_Quality")]
        internal int m_overallQuality;
        [DataElement(Name="Page_Material")]
        internal int m_pageMaterial;
        [DataElement(Name="Page_Text")]
        internal int m_pageText;
        [DataElement(Name="RandomProperties")]
        internal int m_rand;
        [DataElement(Name="Range")]
        internal float m_range;
        [DataElement(Name="Rank")]
        internal int m_rank;
        [DataElement(Name="Required_Level")]
        internal int m_reqLevel;
        [DataElement(Name="Required_Skill")]
        internal int m_reqSkill;
        [DataElement(Name="ReqSpell")]
        internal int m_reqSpell;
        [DataElement(Name="Resistance")]
        internal Resistance m_resists = new Resistance(false);
        [DataElement(Name="Sell_Price")]
        internal int m_sellPrice;
        [DataElement(Name="SetID")]
        internal int m_set;
        [DataElement(Name="Sheath")]
        internal int m_sheatheType;
        [DataElement(Name="SocketBonus")]
        internal int m_socketBonus;
        [DataElement(Name="Socket", ArraySize=3)]
        internal SocketStat[] m_socketStats = new SocketStat[3];
        [DataElement(Name="Spell", ArraySize=5)]
        internal RunWoW.DB.DataTables.SpellStat[] m_spellStats = new RunWoW.DB.DataTables.SpellStat[5];
        [DataElement(Name="Start_Quest_ID")]
        internal int m_startQuestId;
        [DataElement(Name="SubClass")]
        internal int m_subClass;
        internal int m_tmpcount;
        [DataElement(Name="ToolID")]
        internal int m_toolId;
        [DataElement(Name="unk3")]
        internal int m_unk3;
        [DataElement(Name="unk4")]
        internal int m_unk4;
        [DataElement(Name="unk5")]
        internal int m_unk5;
        [DataElement(Name="unk6")]
        internal int m_unk6;
        [DataElement(Name="unk8")]
        internal int m_unk8;
        [DataElement(Name="Unknown9")]
        internal int m_unk9;
        [DataElement(Name="Delay")]
        internal int m_weaponSpeed;
        [DataElement(Name="World")]
        internal int m_world;
        [Relation(LocalField="StartQuestID", RemoteField="Quest_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBQuest StartQuest;

        public int getItemBonusByStat(int stat)
        {
            int num = 0;
            foreach (ItemBonus bonus in this.m_itemBonus)
            {
                if (bonus.Stat == stat)
                {
                    num += bonus.Bonus;
                }
            }
            return num;
        }

        public RunWoW.DB.DataTables.SpellStat getSpellStat(int ndx)
        {
            return this.m_spellStats[ndx];
        }

        public void setSpellStat(int ndx, RunWoW.DB.DataTables.SpellStat stat)
        {
            base.Dirty = true;
            this.m_spellStats[ndx] = stat;
        }

        public int AllowableClass
        {
            get
            {
                return this.m_allowableClass;
            }
            set
            {
                base.Assign<int>(ref this.m_allowableClass, value);
            }
        }

        public int AllowableRace
        {
            get
            {
                return this.m_allowableRace;
            }
            set
            {
                base.Assign<int>(ref this.m_allowableRace, value);
            }
        }

        public int AmmoType
        {
            get
            {
                return this.m_ammoType;
            }
            set
            {
                base.Assign<int>(ref this.m_ammoType, value);
            }
        }

        public int Area
        {
            get
            {
                return this.m_unk8;
            }
            set
            {
                base.Assign<int>(ref this.m_unk8, value);
            }
        }

        public ARMOURSUBCLASS ArmourSubClass
        {
            get
            {
                return (ARMOURSUBCLASS) this.m_subClass;
            }
            set
            {
                base.Dirty = true;
                this.m_subClass = (int) value;
            }
        }

        public BAGSUBCLASS BagSubClass
        {
            get
            {
                return (BAGSUBCLASS) this.m_subClass;
            }
            set
            {
                base.Dirty = true;
                this.m_subClass = (int) value;
            }
        }

        public int BagType
        {
            get
            {
                return this.m_bagType;
            }
            set
            {
                base.Assign<int>(ref this.m_bagType, value);
            }
        }

        public int BindType
        {
            get
            {
                return this.m_bonding;
            }
            set
            {
                base.Assign<int>(ref this.m_bonding, value);
            }
        }

        public int Block
        {
            get
            {
                return this.m_block;
            }
            set
            {
                base.Assign<int>(ref this.m_block, value);
            }
        }

        public int BuyPrice
        {
            get
            {
                return this.m_buyPrice;
            }
            set
            {
                base.Assign<int>(ref this.m_buyPrice, value);
            }
        }

        public int CityRank
        {
            get
            {
                return this.m_unk3;
            }
            set
            {
                base.Assign<int>(ref this.m_unk3, value);
            }
        }

        public ITEMCLASS Class
        {
            get
            {
                return this.m_class;
            }
            set
            {
                base.Dirty = true;
                this.m_class = value;
            }
        }

        public bool Conjured
        {
            get
            {
                return ((this.Flags & 2) == 2);
            }
        }

        public int ContainerSlots
        {
            get
            {
                return this.m_containerSlots;
            }
            set
            {
                base.Assign<int>(ref this.m_containerSlots, value);
            }
        }

        public DamageStat[] DamageStats
        {
            get
            {
                return this.m_damageStats;
            }
        }

        public string Description
        {
            get
            {
                return this.m_description;
            }
            set
            {
                base.Assign(ref this.m_description, value);
            }
        }

        public int DisplayID
        {
            get
            {
                return this.m_displayID;
            }
            set
            {
                base.Assign<int>(ref this.m_displayID, value);
            }
        }

        public int Flags
        {
            get
            {
                return this.m_flags;
            }
            set
            {
                base.Assign<int>(ref this.m_flags, value);
            }
        }

        public bool Honour
        {
            get
            {
                return ((this.Flags & 0x9194) == 0x9194);
            }
        }

        public INVTYPE InvType
        {
            get
            {
                return this.m_invType;
            }
            set
            {
                base.Assign<INVTYPE>(ref this.m_invType, value);
            }
        }

        public ItemBonus[] ItemBonuses
        {
            get
            {
                return this.m_itemBonus;
            }
        }

        public int Itemlevel
        {
            get
            {
                return this.m_itemlevel;
            }
            set
            {
                base.Assign<int>(ref this.m_itemlevel, value);
            }
        }

        public int LanguageID
        {
            get
            {
                return this.m_languageID;
            }
            set
            {
                base.Assign<int>(ref this.m_languageID, value);
            }
        }

        public int Lock
        {
            get
            {
                return this.m_lock;
            }
            set
            {
                base.Assign<int>(ref this.m_lock, value);
            }
        }

        public bool LockBox
        {
            get
            {
                return ((this.Flags & 4) == 4);
            }
        }

        public int Material
        {
            get
            {
                return this.m_material;
            }
            set
            {
                base.Assign<int>(ref this.m_material, value);
            }
        }

        public int MaxCount
        {
            get
            {
                return this.m_maxCount;
            }
            set
            {
                base.Assign<int>(ref this.m_maxCount, value);
            }
        }

        public int MaxDurability
        {
            get
            {
                return this.m_maxDurability;
            }
            set
            {
                base.Assign<int>(ref this.m_maxDurability, value);
            }
        }

        public int MaxStack
        {
            get
            {
                return this.m_maxStack;
            }
            set
            {
                base.Assign<int>(ref this.m_maxStack, value);
            }
        }

        public int MinReqSkill
        {
            get
            {
                return this.m_minReqSkill;
            }
            set
            {
                base.Assign<int>(ref this.m_minReqSkill, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public string Name1
        {
            get
            {
                return this.m_name1;
            }
            set
            {
                base.Assign(ref this.m_name1, value);
            }
        }

        public string Name2
        {
            get
            {
                return this.m_name2;
            }
            set
            {
                base.Assign(ref this.m_name2, value);
            }
        }

        public string Name3
        {
            get
            {
                return this.m_name3;
            }
            set
            {
                base.Assign(ref this.m_name3, value);
            }
        }

        public int OverallQuality
        {
            get
            {
                return this.m_overallQuality;
            }
            set
            {
                base.Assign<int>(ref this.m_overallQuality, value);
            }
        }

        public int PageMaterial
        {
            get
            {
                return this.m_pageMaterial;
            }
            set
            {
                base.Assign<int>(ref this.m_pageMaterial, value);
            }
        }

        public int PageText
        {
            get
            {
                return this.m_pageText;
            }
            set
            {
                base.Assign<int>(ref this.m_pageText, value);
            }
        }

        public PROJECTILESUBCLASS ProjectileSubClass
        {
            get
            {
                return (PROJECTILESUBCLASS) this.m_subClass;
            }
            set
            {
                base.Dirty = true;
                this.m_subClass = (int) value;
            }
        }

        public bool Quest
        {
            get
            {
                return ((this.Flags & 0x800) == 0x800);
            }
        }

        public QUIVERSUBCLASS QuiverSubClass
        {
            get
            {
                return (QUIVERSUBCLASS) this.m_subClass;
            }
            set
            {
                base.Dirty = true;
                this.m_subClass = (int) value;
            }
        }

        public int RandomProperties
        {
            get
            {
                return this.m_rand;
            }
            set
            {
                base.Assign<int>(ref this.m_rand, value);
            }
        }

        public float Range
        {
            get
            {
                return this.m_range;
            }
            set
            {
                base.Assign<float>(ref this.m_range, value);
            }
        }

        public bool Ranged
        {
            get
            {
                if (this.Class == ITEMCLASS.WEAPON)
                {
                    switch (this.WeaponSubClass)
                    {
                        case WEAPONSUBCLASS.BOW:
                        case WEAPONSUBCLASS.GUN:
                        case WEAPONSUBCLASS.THROWN:
                        case WEAPONSUBCLASS.CROSSBOW:
                        case WEAPONSUBCLASS.WAND:
                            return true;
                    }
                }
                return false;
            }
        }

        public int Rank
        {
            get
            {
                return this.m_rank;
            }
            set
            {
                base.Assign<int>(ref this.m_rank, value);
            }
        }

        public int Reputation
        {
            get
            {
                return this.m_unk4;
            }
            set
            {
                base.Assign<int>(ref this.m_unk4, value);
            }
        }

        public int ReputationRank
        {
            get
            {
                return this.m_unk5;
            }
            set
            {
                base.Assign<int>(ref this.m_unk5, value);
            }
        }

        public int ReqLevel
        {
            get
            {
                return this.m_reqLevel;
            }
            set
            {
                base.Assign<int>(ref this.m_reqLevel, value);
            }
        }

        public int ReqSkill
        {
            get
            {
                return this.m_reqSkill;
            }
            set
            {
                base.Assign<int>(ref this.m_reqSkill, value);
            }
        }

        public int ReqSpell
        {
            get
            {
                return this.m_reqSpell;
            }
            set
            {
                base.Assign<int>(ref this.m_reqSpell, value);
            }
        }

        public Resistance Resists
        {
            get
            {
                return this.m_resists;
            }
            set
            {
                base.Dirty = true;
                this.m_resists = value;
            }
        }

        public int SellPrice
        {
            get
            {
                return this.m_sellPrice;
            }
            set
            {
                base.Assign<int>(ref this.m_sellPrice, value);
            }
        }

        public int SetID
        {
            get
            {
                return this.m_set;
            }
            set
            {
                base.Assign<int>(ref this.m_set, value);
            }
        }

        public int SheathType
        {
            get
            {
                return this.m_sheatheType;
            }
            set
            {
                base.Assign<int>(ref this.m_sheatheType, value);
            }
        }

        public int SocketBonus
        {
            get
            {
                return this.m_socketBonus;
            }
            set
            {
                base.Assign<int>(ref this.m_socketBonus, value);
            }
        }

        public SocketStat[] SocketStats
        {
            get
            {
                return this.m_socketStats;
            }
        }

        public RunWoW.DB.DataTables.SpellStat[] SpellStat
        {
            get
            {
                return this.m_spellStats;
            }
        }

        public int StartQuestID
        {
            get
            {
                return this.m_startQuestId;
            }
            set
            {
                base.Assign<int>(ref this.m_startQuestId, value);
            }
        }

        public int SubClass
        {
            get
            {
                return this.m_subClass;
            }
            set
            {
                base.Assign<int>(ref this.m_subClass, value);
            }
        }

        public int TempCount
        {
            get
            {
                return this.m_tmpcount;
            }
            set
            {
                this.m_tmpcount = value;
            }
        }

        public int ToolID
        {
            get
            {
                if (this.m_toolId != 0)
                {
                    return this.m_toolId;
                }
                switch (base.ObjectId)
                {
                    case 0x184a:
                        return 6;

                    case 0x184b:
                        return 14;

                    case 0x18c3:
                        return 7;

                    case 0x1744:
                        return 13;

                    case 0x1437:
                        return 2;

                    case 0x1438:
                        return 4;

                    case 0x1439:
                        return 5;

                    case 0x143a:
                        return 3;

                    case 0xb55:
                        return 11;

                    case 0x1b5d:
                        return 1;

                    case 0x23bd:
                        return 12;

                    case 0x2902:
                        return 15;

                    case 0x2b7a:
                        return 8;

                    case 0x2b89:
                        return 9;

                    case 0x3f4f:
                        return 10;
                }
                return 0;
            }
            set
            {
                base.Assign<int>(ref this.m_toolId, value);
            }
        }

        public int Unknown6
        {
            get
            {
                return this.m_unk6;
            }
            set
            {
                base.Assign<int>(ref this.m_unk6, value);
            }
        }

        public int Unknown9
        {
            get
            {
                return this.m_unk9;
            }
            set
            {
                base.Assign<int>(ref this.m_unk9, value);
            }
        }

        public int WeaponSpeed
        {
            get
            {
                return this.m_weaponSpeed;
            }
            set
            {
                base.Assign<int>(ref this.m_weaponSpeed, value);
            }
        }

        public WEAPONSUBCLASS WeaponSubClass
        {
            get
            {
                return (WEAPONSUBCLASS) this.m_subClass;
            }
            set
            {
                base.Dirty = true;
                this.m_subClass = (int) value;
            }
        }

        public bool Widget
        {
            get
            {
                return ((this.Flags & 0x200) == 0x200);
            }
        }

        public int World
        {
            get
            {
                return this.m_world;
            }
            set
            {
                base.Assign<int>(ref this.m_world, value);
            }
        }
    }
}

