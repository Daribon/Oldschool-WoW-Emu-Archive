//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="Item")]
    public class DBItem : DBBase
    {
        [Relation(LocalField="RandomPropertyID", RemoteField="ItemRandomProperties_ID", AutoLoad=true)]
        public DBItemRandomProperties ItemRandomProperties;
        [DataElement(Name="ContainerID")]
        internal long m_containerID;
        [DataElement(Name="Cooldown")]
        internal DateTime m_cooldown;
        [DataElement(Name="Creator")]
        internal uint m_creator;
        [DataElement(Name="Durability")]
        internal int m_durability;
        [DataElement(Name="DynamicFlags")]
        internal ushort m_dynamicFlags;
        [DataElement(Name="Enchantment", ArraySize=7)]
        internal ItemEnchantment[] m_enchantments;
        [DataElement(Name="Expiration")]
        internal DateTime m_expiration;
        [Index(Name="OwnerID")]
        internal uint m_ownerID;
        [DataElement(Name="OwnerSlot")]
        internal byte m_ownerSlot;
        [DataElement(Name="PropertyID")]
        internal int m_randomPropertyID;
        [DataElement(Name="PropertySeed")]
        internal int m_randomPropertySeed;
        [DataElement(Name="SpellCharge", ArraySize=5)]
        internal int[] m_spellCharges;
        [DataElement(Name="StackCount")]
        internal int m_stackcount;
        [DataElement(Name="StaticFlags")]
        internal ushort m_staticFlags;
        [DataElement(Name="TemplateID", AllowDbNull=false)]
        internal uint m_templateID;
        [DataElement(Name="ItemTextID")]
        internal int m_textID;
        public const int MaxUserEnchants = 2;
        [Relation(LocalField="TemplateID", RemoteField="ItemTemplate_ID", AutoLoad=true, AutoSave=false, AutoDelete=false)]
        public DBItemTemplate Template;

        public DBItem()
        {
            this.m_stackcount = 1;
            this.m_expiration = CustomDateTime.Now;
            this.m_cooldown = CustomDateTime.Now;
            this.m_spellCharges = new int[5];
            this.m_enchantments = new ItemEnchantment[7];
        }

        public DBItem(DBItemTemplate template)
        {
            this.m_stackcount = 1;
            this.m_expiration = CustomDateTime.Now;
            this.m_cooldown = CustomDateTime.Now;
            this.m_spellCharges = new int[5];
            this.m_enchantments = new ItemEnchantment[7];
            this.m_templateID = template.ObjectId;
            this.Template = template;
            this.Durability = template.MaxDurability;
            for (int i = 0; i < 5; i++)
            {
                SpellStat stat = template.getSpellStat(i);
                if (stat.ID != 0)
                {
                    this.m_spellCharges[i] = stat.Charges;
                }
            }
            base.Dirty = true;
        }

        public long ContainerID
        {
            get
            {
                return this.m_containerID;
            }
            set
            {
                base.Assign<long>(ref this.m_containerID, value);
            }
        }

        public DateTime Cooldown
        {
            get
            {
                return this.m_cooldown;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_cooldown, value);
            }
        }

        [UpdateValue(10)]
        public uint Creator
        {
            get
            {
                return this.m_creator;
            }
            set
            {
                base.Assign<uint>(ref this.m_creator, value);
            }
        }

        [UpdateValue(0x3a, Private=true)]
        public int Durability
        {
            get
            {
                return this.m_durability;
            }
            set
            {
                base.Assign<int>(ref this.m_durability, value);
            }
        }

        [UpdateValue(0x15, ShortsIndex=1, Private=true)]
        public ushort DynamicFlags
        {
            get
            {
                return this.m_dynamicFlags;
            }
            set
            {
                base.Assign<ushort>(ref this.m_dynamicFlags, value);
            }
        }

        [UpdateValue(0x16, ArraySize=7, NumSubFields=3, Private=false)]
        public ItemEnchantment[] Enchantments
        {
            get
            {
                return this.m_enchantments;
            }
        }

        public DateTime Expiration
        {
            get
            {
                return this.m_expiration;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_expiration, value);
            }
        }

        public int LastEnchant
        {
            get
            {
                for (int i = 0; i < this.m_enchantments.Length; i++)
                {
                    if (this.m_enchantments[i].ID != 0)
                    {
                        return i;
                    }
                }
                return -1;
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }

        public byte OwnerSlot
        {
            get
            {
                return this.m_ownerSlot;
            }
            set
            {
                base.Assign<byte>(ref this.m_ownerSlot, value);
            }
        }

        [UpdateValue(0x37, Private=true)]
        public int PropertySeed
        {
            get
            {
                return this.m_randomPropertySeed;
            }
            set
            {
                base.Assign<int>(ref this.m_randomPropertySeed, value);
            }
        }

        [UpdateValue(0x38)]
        public int RandomPropertyID
        {
            get
            {
                return this.m_randomPropertyID;
            }
            set
            {
                base.Assign<int>(ref this.m_randomPropertyID, value);
            }
        }

        public bool Soulbound
        {
            get
            {
                return ((this.m_staticFlags & 1) == 1);
            }
            set
            {
                if (value)
                {
                    this.m_staticFlags = (ushort) (this.m_staticFlags | 1);
                }
                else
                {
                    this.m_staticFlags = (ushort) (this.m_staticFlags & -2);
                }
            }
        }

        [UpdateValue(0x10, ArraySize=5, Private=true)]
        public int[] SpellCharges
        {
            get
            {
                return this.m_spellCharges;
            }
        }

        [UpdateValue(14, Private=true)]
        public int StackCount
        {
            get
            {
                return this.m_stackcount;
            }
            set
            {
                base.Assign<int>(ref this.m_stackcount, value);
            }
        }

        [UpdateValue(0x15, ShortsIndex=0, Private=true)]
        public ushort StaticFlags
        {
            get
            {
                return this.m_staticFlags;
            }
            set
            {
                base.Assign<ushort>(ref this.m_staticFlags, value);
            }
        }

        public uint TemplateID
        {
            get
            {
                return this.m_templateID;
            }
            set
            {
                base.Assign<uint>(ref this.m_templateID, value);
            }
        }

        [UpdateValue(0x39)]
        public int TextID
        {
            get
            {
                return this.m_textID;
            }
            set
            {
                base.Assign<int>(ref this.m_textID, value);
            }
        }
    }
}

