﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="ItemRandomProperties")]
    public class DBItemRandomProperties : DBBase
    {
        [DataElement(Name="Enchantment", ArraySize=3)]
        internal int[] m_effects = new int[3];
        [DataElement(Name="Flags")]
        internal int m_flags;
        [DataElement(Name="Suffix")]
        internal string m_suffix;

        public int[] EnchantEffect
        {
            get
            {
                return this.m_effects;
            }
        }

        public int Flags
        {
            get
            {
                return this.m_flags;
            }
        }

        public string Suffix
        {
            get
            {
                return this.m_suffix;
            }
        }
    }
}

