﻿namespace RunWoW.DB.DataTables
{
    using System;

    public enum FRIENDTYPE : byte
    {
        FRIEND = 0,
        IGNORE = 1
    }
}

