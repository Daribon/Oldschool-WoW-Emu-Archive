//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Text")]
    public class DBText : DBBase
    {
        [DataElement(Name="Text")]
        internal string m_text;

        public string Text
        {
            get
            {
                return this.m_text;
            }
            set
            {
                base.Assign(ref this.m_text, value);
            }
        }
    }
}

