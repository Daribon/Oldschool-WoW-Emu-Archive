//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Abilities")]
    public class DBAbility : DBBase
    {
        [DataElement(Name="Cooldown")]
        internal DateTime m_cooldown;
        [DataElement(Name="Unknown")]
        internal ushort m_craft;
        [DataElement(Name="Level")]
        internal ushort m_level;
        [DataElement(Name="MaxLevel")]
        internal ushort m_maxlevel;
        [Index(Name="Owner_ID")]
        internal uint m_ownerID;
        [DataElement(Name="SkillID")]
        internal ushort m_skillid;
        internal ushort m_slot;
        [DataElement(Name="SpellID", AllowDbNull=false)]
        internal ushort m_spellID;
        [DataElement(Name="TalentID")]
        internal ushort m_talentid;
        [DataElement(Name="Type")]
        internal ABILITYTYPE m_type;
        [Relation(LocalField="SpellID", RemoteField="Spell_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBSpell Spell;

        public DateTime Cooldown
        {
            get
            {
                return this.m_cooldown;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_cooldown, value);
            }
        }

        public ushort Craft
        {
            get
            {
                return this.m_craft;
            }
            set
            {
                base.Assign<ushort>(ref this.m_craft, value);
            }
        }

        public ushort Level
        {
            get
            {
                return this.m_level;
            }
            set
            {
                base.Assign<ushort>(ref this.m_level, value);
            }
        }

        public ushort MaxLevel
        {
            get
            {
                return this.m_maxlevel;
            }
            set
            {
                base.Assign<ushort>(ref this.m_maxlevel, value);
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }

        public ushort SkillID
        {
            get
            {
                return this.m_skillid;
            }
            set
            {
                base.Assign<ushort>(ref this.m_skillid, value);
            }
        }

        public ushort Slot
        {
            get
            {
                return this.m_slot;
            }
            set
            {
                base.Assign<ushort>(ref this.m_slot, value);
            }
        }

        public ushort SpellID
        {
            get
            {
                return this.m_spellID;
            }
            set
            {
                base.Assign<ushort>(ref this.m_spellID, value);
            }
        }

        public ushort TalentID
        {
            get
            {
                return this.m_talentid;
            }
            set
            {
                base.Assign<ushort>(ref this.m_talentid, value);
            }
        }

        public ABILITYTYPE Type
        {
            get
            {
                return this.m_type;
            }
            set
            {
                base.Assign<ABILITYTYPE>(ref this.m_type, value);
            }
        }
    }
}

