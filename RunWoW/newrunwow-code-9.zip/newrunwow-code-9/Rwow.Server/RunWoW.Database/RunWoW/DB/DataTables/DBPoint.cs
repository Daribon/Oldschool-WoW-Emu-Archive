﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="Point")]
    public class DBPoint : DBBase
    {
        [DataElement(Name="Description")]
        internal string m_desc;
        [DataElement(Name="Position")]
        internal DBVector m_pos = new DBVector();
        [DataElement(Name="Type")]
        internal int m_type;
        [DataElement(Name="WorldMapID")]
        internal uint m_worldMapID;

        public string Description
        {
            get
            {
                return this.m_desc;
            }
            set
            {
                base.Assign(ref this.m_desc, value);
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_pos.Vector;
            }
            set
            {
                this.m_pos.Vector = value;
            }
        }

        public int Type
        {
            get
            {
                return this.m_type;
            }
            set
            {
                base.Assign<int>(ref this.m_type, value);
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldMapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldMapID, value);
            }
        }
    }
}

