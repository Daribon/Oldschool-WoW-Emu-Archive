﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="PetSpell")]
    public class DBPetSpell : DBBase
    {
        [DataElement(Name="Cooldown")]
        internal DateTime m_cooldown;
        [Index(Name="Owner_ID")]
        internal uint m_ownerID;
        [DataElement(Name="SpellID", AllowDbNull=false)]
        internal ushort m_spellID;
        [Relation(LocalField="SpellID", RemoteField="Spell_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBSpell Spell;

        public DateTime Cooldown
        {
            get
            {
                return this.m_cooldown;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_cooldown, value);
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }

        public ushort SpellID
        {
            get
            {
                return this.m_spellID;
            }
            set
            {
                base.Assign<ushort>(ref this.m_spellID, value);
            }
        }
    }
}

