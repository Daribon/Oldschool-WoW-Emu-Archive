﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Auction")]
    public class DBAuction : DBBase
    {
        [Relation(LocalField="ItemID", RemoteField="Item_ID", AutoLoad=false, AutoSave=false, AutoDelete=false)]
        public DBItem Item;
        [DataElement(Name="BuyOutPrice")]
        public uint m_buyPrice;
        [DataElement(Name="CreateTime")]
        public DateTime m_createTime;
        [DataElement(Name = "ExpirationTime")]
        public DateTime m_expirationTime;
        [DataElement(Name="House")]
        public uint m_house;
        [DataElement(Name="ItemClass")]
        public uint m_itemClass;
        [DataElement(Name="ItemEnchantments")]
        public uint m_itemEnchantments;
        [DataElement(Name="ItemID")]
        public uint m_itemID;
        [DataElement(Name="ItemInventoryType")]
        public uint m_itemInventoryType;
        [DataElement(Name="ItemLevel")]
        public uint m_itemLevel;
        [DataElement(Name="ItemName")]
        public string m_itemName;
        [DataElement(Name="ItemQuality")]
        public uint m_itemQuality;
        [DataElement(Name="ItemRandomProperties")]
        public uint m_itemRandomProperties;
        [DataElement(Name="ItemStackCount")]
        public uint m_itemStackCount;
        [DataElement(Name="ItemSubClass")]
        public uint m_itemSubClass;
        [DataElement(Name="ItemTemplateID")]
        public uint m_itemTemplateID;
        [DataElement(Name="LastBid")]
        public uint m_lastBid;
        [Index(Name="OwnerID")]
        public uint m_ownerID;
        [DataElement(Name="AuctionPoolID")]
        public uint m_poolID;
        [DataElement(Name="StartPrice")]
        public uint m_startPrice;
        [DataElement(Name="TradeTime")]
        public uint m_tradeTime;

        public uint BuyOutPrice
        {
            get
            {
                return this.m_buyPrice;
            }
            set
            {
                base.Assign<uint>(ref this.m_buyPrice, value);
            }
        }

        public DateTime CreateTime
        {
            get
            {
                return this.m_createTime;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_createTime, value);
            }
        }

        public DateTime ExpirationTime
        {
            get
            {
                return this.m_expirationTime;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_expirationTime, value);
            }
        }

        public uint House
        {
            get
            {
                return this.m_house;
            }
            set
            {
                base.Assign<uint>(ref this.m_house, value);
            }
        }

        public uint ItemClass
        {
            get
            {
                return this.m_itemClass;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemClass, value);
            }
        }

        public uint ItemEnchantments
        {
            get
            {
                return this.m_itemEnchantments;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemEnchantments, value);
            }
        }

        public uint ItemID
        {
            get
            {
                return this.m_itemID;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemID, value);
            }
        }

        public uint ItemInventoryType
        {
            get
            {
                return this.m_itemInventoryType;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemInventoryType, value);
            }
        }

        public uint ItemLevel
        {
            get
            {
                return this.m_itemLevel;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemLevel, value);
            }
        }

        public string ItemName
        {
            get
            {
                return this.m_itemName;
            }
            set
            {
                base.Assign(ref this.m_itemName, value);
            }
        }

        public uint ItemQuality
        {
            get
            {
                return this.m_itemQuality;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemQuality, value);
            }
        }

        public uint ItemRandomProperties
        {
            get
            {
                return this.m_itemRandomProperties;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemRandomProperties, value);
            }
        }

        public uint ItemStackCount
        {
            get
            {
                return this.m_itemStackCount;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemStackCount, value);
            }
        }

        public uint ItemSubClass
        {
            get
            {
                return this.m_itemSubClass;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemSubClass, value);
            }
        }

        public uint ItemTemplateID
        {
            get
            {
                return this.m_itemTemplateID;
            }
            set
            {
                base.Assign<uint>(ref this.m_itemTemplateID, value);
            }
        }

        public uint LastBid
        {
            get
            {
                return this.m_lastBid;
            }
            set
            {
                base.Assign<uint>(ref this.m_lastBid, value);
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }

        public uint PoolID
        {
            get
            {
                return this.m_poolID;
            }
            set
            {
                base.Assign<uint>(ref this.m_poolID, value);
            }
        }

        public uint StartPrice
        {
            get
            {
                return this.m_startPrice;
            }
            set
            {
                base.Assign<uint>(ref this.m_startPrice, value);
            }
        }

        public uint TradeTime
        {
            get
            {
                return this.m_tradeTime;
            }
            set
            {
                base.Assign<uint>(ref this.m_tradeTime, value);
            }
        }
    }
}

