//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct DamageStat
    {
        [DataElement]
        public float Min;
        [DataElement]
        public float Max;
        [DataElement]
        public int Type;
    }
}

