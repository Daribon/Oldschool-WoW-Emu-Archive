﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="QuestLog")]
    public class DBQuestLog : DBBase
    {
        [Index(Name="Owner_ID")]
        internal uint m_ownerid;
        [DataElement(Name="Quest_ID")]
        internal uint m_questid;
        [DataElement(Name="Status")]
        internal QUESTSTATUS m_status;
        [DataElement(Name="Target", ArraySize=5)]
        internal uint[] m_targets = new uint[5];
        [Relation(LocalField="QuestID", RemoteField="Quest_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBQuest Quest;

        public uint OwnerID
        {
            get
            {
                return this.m_ownerid;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerid, value);
            }
        }

        public uint QuestID
        {
            get
            {
                return this.m_questid;
            }
            set
            {
                base.Assign<uint>(ref this.m_questid, value);
            }
        }

        public QUESTSTATUS Status
        {
            get
            {
                return this.m_status;
            }
            set
            {
                base.Assign<QUESTSTATUS>(ref this.m_status, value);
            }
        }

        public uint[] Target
        {
            get
            {
                return this.m_targets;
            }
            set
            {
                base.Dirty = true;
                this.m_targets = value;
            }
        }
    }
}

