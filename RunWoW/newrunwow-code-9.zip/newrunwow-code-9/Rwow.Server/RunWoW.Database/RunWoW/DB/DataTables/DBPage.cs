﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Page")]
    public class DBPage : DBBase
    {
        [DataElement(Name="NextPageID")]
        internal uint m_next;
        [DataElement(Name="Text")]
        internal string m_text;

        public uint Next
        {
            get
            {
                return this.m_next;
            }
            set
            {
                base.Assign<uint>(ref this.m_next, value);
            }
        }

        public string Text
        {
            get
            {
                return this.m_text;
            }
            set
            {
                base.Assign(ref this.m_text, value);
            }
        }
    }
}

