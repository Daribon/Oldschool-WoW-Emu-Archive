//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="NSkill")]
    public class DBNSkill : DBBase
    {
        [DataElement(Name="Craft")]
        internal byte m_craft;
        [DataElement(Name="MaxLevel")]
        internal int m_maxlevel;
        [DataElement(Name="MinLevel")]
        internal int m_minlevel;
        [DataElement(Name="SpellRank")]
        internal string m_rank = string.Empty;
        [DataElement(Name="Skill_ID")]
        internal int m_skill;
        [DataElement(Name="SkillName")]
        internal string m_skillname = string.Empty;
        [Index(Name="Spell_ID")]
        internal uint m_spell;
        [DataElement(Name="SpellName")]
        internal string m_spellname = string.Empty;

        public byte Craft
        {
            get
            {
                return this.m_craft;
            }
        }

        public int Level
        {
            get
            {
                return this.m_minlevel;
            }
        }

        public int MaxLevel
        {
            get
            {
                return this.m_maxlevel;
            }
        }

        public string Rank
        {
            get
            {
                return this.m_rank;
            }
        }

        public int SkillID
        {
            get
            {
                return this.m_skill;
            }
        }

        public string SkillName
        {
            get
            {
                return this.m_skillname;
            }
        }

        public uint SpellID
        {
            get
            {
                return this.m_spell;
            }
        }

        public string SpellName
        {
            get
            {
                return this.m_spellname;
            }
        }
    }
}

