﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct Resistance
    {
        [DataElement(Name="Physical")]
        public int Physical;
        [DataElement]
        public int Holy;
        [DataElement]
        public int Fire;
        [DataElement]
        public int Nature;
        [DataElement]
        public int Frost;
        [DataElement]
        public int Shadow;
        [DataElement]
        public int Arcane;
        public Resistance(bool neg)
        {
            int num = neg ? -2 : 0;
            this.Physical = num;
            this.Holy = num;
            this.Fire = num;
            this.Nature = num;
            this.Frost = num;
            this.Shadow = num;
            this.Arcane = num;
        }
    }
}

