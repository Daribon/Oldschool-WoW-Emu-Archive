﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="TaxiNode")]
    public class DBTaxiNode : DBBase
    {
        [DataElement(Name="LocationName")]
        internal string m_name = string.Empty;
        [DataElement(Name="Position")]
        internal DBVector m_position = new DBVector();
        [Index(Name="WorldMapID")]
        internal uint m_worldMapID;
        [Relation(LocalField="ObjectId", RemoteField="StartPoint", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public PooledList<DBTaxiPath> Paths;

        public string LocationName
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_position.Vector;
            }
            set
            {
                this.m_position.Vector = value;
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldMapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldMapID, value);
            }
        }
    }
}

