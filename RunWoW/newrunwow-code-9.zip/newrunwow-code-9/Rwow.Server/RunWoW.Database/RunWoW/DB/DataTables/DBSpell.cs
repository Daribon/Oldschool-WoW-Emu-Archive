//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="Spell_BK", ID="Spell_ID")]
    public class DBSpell : DBBase
    {
        internal SPELLEFFECT[] DeadEffects = new SPELLEFFECT[] { SPELLEFFECT.SKINNING, SPELLEFFECT.RESURRECT, SPELLEFFECT.RESURRECT_NEW, SPELLEFFECT.SELF_RESURRECT };
        private sbyte m_aspect = -1;
        private sbyte m_blessing = -1;
        [DataElement(Name="CastTime")]
        internal int m_casttime;
        [DataElement(Name="Category")]
        internal uint m_category;
        [DataElement(Name="CoolDown")]
        internal int m_cooldown;
        [DataElement(Name="CraftReqs", ArraySize=7)]
        internal CraftReq[] m_craft_req = new CraftReq[7];
        [DataElement(Name="CreatureType")]
        internal int m_creatureType;
        [DataElement(Name="DispelType")]
        internal SpellDispelType m_dispelType;
        [DataElement(Name="Duration")]
        internal int m_duration;
        [DataElement(Name="Effect", ArraySize=3)]
        internal SpellEffect[] m_effects = new SpellEffect[3];
        [DataElement(Name="Flags", ArraySize=4)]
        internal int[] m_flags = new int[4];
        [DataElement(Name="InventoryTypeTarget")]
        internal int m_inventoryTypeTarget;
        [DataElement(Name="MaxLevel")]
        internal int m_maxlevel;
        [DataElement(Name="MaxRange")]
        internal int m_maxrange;
        [DataElement(Name="DispelMechanicType")]
        internal RunWoW.Common.MechanicDispelType m_mechanicDispelType;
        [DataElement(Name="MinRange")]
        internal int m_minrange;
        private sbyte m_paladinAura = -1;
        private bool m_petCast;
        [DataElement(Name="PlayerLevel")]
        internal int m_plevel = 1;
        [DataElement(Name="PowerCost")]
        internal int m_powerCost;
        [DataElement(Name="PowerCostPercent")]
        internal int m_powerCostPercent;
        [DataElement(Name="ManaCostPerLevel")]
        internal int m_powerCostPerLevel;
        [DataElement(Name="PowerType")]
        internal POWERTYPE m_powertype;
        [DataElement(Name="ProcChance")]
        internal int m_procchance;
        [DataElement(Name="ProcCharges")]
        internal int m_proccharges;
        [DataElement(Name="ProcFlag")]
        internal int m_procflags;
        [DataElement(Name="Rank")]
        internal sbyte m_rank;
        [DataElement(Name="ReqSpell")]
        internal ushort m_req_spell;
        [DataElement(Name="RequiredItemClass")]
        internal int m_requiredItemClass;
        [DataElement(Name="RequiredItemSubclass")]
        internal int m_requiredItemSubclass;
        [DataElement(Name="School")]
        internal DAMAGETYPE m_school;
        private sbyte m_seal = -1;
        [DataElement(Name="SpellFocus")]
        internal int m_spellFocus;
        [DataElement(Name="SpellGroupID")]
        internal int m_spellGroup;
        [DataElement(Name="SpellLevel")]
        internal int m_spelllevel;
        [DataElement(Name="SpellName")]
        internal string m_spellname = string.Empty;
        private sbyte m_sting = -1;
        private DBSpell m_targetSpell;
        private int m_tempDuration;
        [DataElement(Name="Tool", ArraySize=2)]
        internal int[] m_tools = new int[2];
        [DataElement(Name="ToolType", ArraySize=2)]
        internal int[] m_toolsType = new int[2];
        [Relation(LocalField="ObjectId", RemoteField="Spell_ID", AutoLoad=true, AutoDelete=true, AutoSave=true)]
        public DBSpellCost SpellCost;
        [Relation(LocalField="ObjectId", RemoteField="Spell_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBNSkill TempSkill;

        public bool AcceptItem(DBItemTemplate item)
        {
            if (item != null)
            {
                int num = ((int) 1) << item.SubClass;
                if (this.RequiredItemClass == (int)item.Class)
                {
                    return ((this.RequiredItemSubclass & num) == num);
                }
            }
            return false;
        }

        public bool HasAura(AURAEFFECT effect)
        {
            if ((this.m_effects[0].Aura != effect) && (this.m_effects[1].Aura != effect))
            {
                return (this.m_effects[2].Aura == effect);
            }
            return true;
        }

        public bool HasEffect(SPELLEFFECT effect)
        {
            if ((this.m_effects[0].Type != effect) && (this.m_effects[1].Type != effect))
            {
                return (this.m_effects[2].Type == effect);
            }
            return true;
        }

        public bool AreaCast
        {
            get
            {
                for (int i = 0; i < this.Effect.Length; i++)
                {
                    if (this.Effect[i].Radius > 0f)
                    {
                        return true;
                    }
                }
                return false;
            }
        }

        public bool CastOnDead
        {
            get
            {
                for (int i = 0; i < this.Effect.Length; i++)
                {
                    for (int j = 0; j < this.DeadEffects.Length; j++)
                    {
                        if (this.Effect[i].Type == this.DeadEffects[j])
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
        }

        public int CastTime
        {
            get
            {
                return this.m_casttime;
            }
        }

        public uint Category
        {
            get
            {
                return this.m_category;
            }
        }

        public bool ChangeEyes
        {
            get
            {
                return ((this.m_flags[1] & 0x2000) == 0x2000);
            }
        }

        public bool Channeled
        {
            get
            {
                return ((this.m_flags[1] & 4) == 4);
            }
        }

        public bool ChannelObject
        {
            get
            {
                return this.Fishing;
            }
        }

        public bool Combo
        {
            get
            {
                return ((this.m_flags[1] & 0x100000) == 0x100000);
            }
        }

        public int CoolDown
        {
            get
            {
                return this.m_cooldown;
            }
        }

        public int Cost
        {
            get
            {
                if (this.SpellCost != null)
                {
                    return this.SpellCost.Cost;
                }
                return 0;
            }
            set
            {
                if (this.SpellCost == null)
                {
                    this.SpellCost = new DBSpellCost();
                    this.SpellCost.SpellID = this.SpellID;
                }
                this.SpellCost.Cost = value;
            }
        }

        public bool Craft
        {
            get
            {
                return ((this.m_flags[0] & 0x20) == 0x20);
            }
        }

        public CraftReq[] CraftReqs
        {
            get
            {
                return this.m_craft_req;
            }
        }

        public int CreatureType
        {
            get
            {
                return this.m_creatureType;
            }
        }

        public SpellDispelType DispelType
        {
            get
            {
                return this.m_dispelType;
            }
        }

        public int Duration
        {
            get
            {
                if (this.m_tempDuration != 0)
                {
                    return this.m_tempDuration;
                }
                return this.m_duration;
            }
            set
            {
                this.m_tempDuration = value;
            }
        }

        public SpellEffect[] Effect
        {
            get
            {
                return this.m_effects;
            }
        }

        public bool FirstAid
        {
            get
            {
                return ((this.m_flags[1] & 0x4044) == 0x4044);
            }
        }

        public bool Fishing
        {
            get
            {
                return ((this.m_flags[1] & 0x1000000) == 0x1000000);
            }
        }

        public int[] Flags
        {
            get
            {
                return this.m_flags;
            }
        }

        public bool Food
        {
            get
            {
                if ((this.m_flags[0] & 0x18000100) == 0x18000100)
                {
                    return (this.m_flags[1] == 0);
                }
                return false;
            }
        }

        public bool HealPet
        {
            get
            {
                return ((this.m_flags[2] & 0x800) == 0x800);
            }
        }

        public bool HuntShot
        {
            get
            {
                return ((this.m_flags[2] & 0x20000) == 0x20000);
            }
        }

        public bool Interrupts
        {
            get
            {
                if ((this.m_flags[0] & 0x40000000) != 0x40000000)
                {
                    return ((this.m_flags[1] & 0x40000) == 0x40000);
                }
                return true;
            }
        }

        public int InventoryTypeTarget
        {
            get
            {
                return this.m_inventoryTypeTarget;
            }
        }

        public bool IsAspect
        {
            get
            {
                if (this.m_aspect == -1)
                {
                    this.m_aspect = this.Name.StartsWith("Aspect ") ? ((sbyte) 1) : ((sbyte) 0);
                }
                return (this.m_aspect == 1);
            }
        }

        public bool IsBinary
        {
            get
            {
                for (int i = 0; i < this.m_effects.Length; i++)
                {
                    if (this.m_effects[i].Type != SPELLEFFECT.NONE)
                    {
                        if ((this.m_effects[i].Type != SPELLEFFECT.SCHOOL_DAMAGE) && (this.m_effects[i].Type != SPELLEFFECT.AURA))
                        {
                            return true;
                        }
                        if ((this.m_effects[i].Type == SPELLEFFECT.AURA) && (this.m_effects[i].Aura != AURAEFFECT.PERIODIC_DAMAGE))
                        {
                            return true;
                        }
                    }
                }
                return false;
            }
        }

        public bool IsBlessing
        {
            get
            {
                if (this.m_blessing == -1)
                {
                    this.m_blessing = this.Name.StartsWith("Blessing ") ? ((sbyte) 1) : ((sbyte) 0);
                }
                return (this.m_blessing == 1);
            }
        }

        public bool IsCurse
        {
            get
            {
                return (this.m_dispelType == SpellDispelType.CURSE);
            }
        }

        public bool IsDisease
        {
            get
            {
                return (this.m_dispelType == SpellDispelType.DISEASE);
            }
        }

        public bool IsPaladinAura
        {
            get
            {
                if (this.m_paladinAura == -1)
                {
                    this.m_paladinAura = this.Name.EndsWith(" Aura") ? ((sbyte) 1) : ((sbyte) 0);
                }
                return (this.m_paladinAura == 1);
            }
        }

        public bool IsPoison
        {
            get
            {
                return (this.m_dispelType == SpellDispelType.POISON);
            }
        }

        public bool IsSeal
        {
            get
            {
                if (this.m_seal == -1)
                {
                    this.m_seal = this.Name.StartsWith("Seal ") ? ((sbyte) 1) : ((sbyte) 0);
                }
                return (this.m_seal == 1);
            }
        }

        public bool IsShapeshift
        {
            get
            {
                return this.HasAura(AURAEFFECT.MOD_SHAPESHIFT);
            }
        }

        public bool IsSting
        {
            get
            {
                if (this.m_sting == -1)
                {
                    this.m_sting = this.Name.EndsWith(" Sting") ? ((sbyte) 1) : ((sbyte) 0);
                }
                return (this.m_sting == 1);
            }
        }

        public bool IsTrack
        {
            get
            {
                if (!this.HasAura(AURAEFFECT.TRACK_CREATURES) && !this.HasAura(AURAEFFECT.TRACK_RESOURCES))
                {
                    return this.HasAura(AURAEFFECT.TRACK_STEALTHED);
                }
                return true;
            }
        }

        public int MaxLevel
        {
            get
            {
                return this.m_maxlevel;
            }
        }

        public uint MaxRange
        {
            get
            {
                return (uint) this.m_maxrange;
            }
        }

        public RunWoW.Common.MechanicDispelType MechanicDispelType
        {
            get
            {
                return this.m_mechanicDispelType;
            }
        }

        public uint MinRange
        {
            get
            {
                return (uint) this.m_minrange;
            }
        }

        public string Name
        {
            get
            {
                return this.m_spellname;
            }
        }

        public bool NextAttackSpell
        {
            get
            {
                if ((this.m_duration <= 0) && ((this.Flags[2] & 0x20) == 0))
                {
                    return this.HasEffect(SPELLEFFECT.WEAPON_DAMAGEP1);
                }
                return false;
            }
        }

        public bool NPCCast
        {
            get
            {
                return ((this.m_flags[1] & 0x80) == 0x80);
            }
        }

        public bool PalAura
        {
            get
            {
                return ((this.m_flags[2] & 0x10) == 0x10);
            }
        }

        public bool Passive
        {
            get
            {
                if ((this.m_flags[0] & 0x40) == 0x40)
                {
                    return (this.m_duration <= 0);
                }
                return false;
            }
        }

        public bool PetCast
        {
            get
            {
                if (!this.HealPet)
                {
                    return this.m_petCast;
                }
                return true;
            }
            set
            {
                this.m_petCast = value;
            }
        }

        public int PlayerLevel
        {
            get
            {
                return this.m_plevel;
            }
            set
            {
                this.m_plevel = value;
                base.Dirty = true;
            }
        }

        public int PowerCost
        {
            get
            {
                return this.m_powerCost;
            }
        }

        public int PowerCostPercent
        {
            get
            {
                return this.m_powerCostPercent;
            }
        }

        public int PowerCostPerLevel
        {
            get
            {
                return this.m_powerCostPerLevel;
            }
        }

        public POWERTYPE PowerType
        {
            get
            {
                return this.m_powertype;
            }
        }

        public int ProcChance
        {
            get
            {
                return this.m_procchance;
            }
        }

        public int ProcCharges
        {
            get
            {
                return this.m_proccharges;
            }
        }

        public int ProcFlags
        {
            get
            {
                return this.m_procflags;
            }
        }

        public bool Ranged
        {
            get
            {
                return ((this.m_flags[0] & 2) == 2);
            }
        }

        public int Rank
        {
            get
            {
                return this.m_rank;
            }
        }

        public bool ReqItem
        {
            get
            {
                if ((this.RequiredItemClass == 2) && !this.HasAura(AURAEFFECT.MOD_SKILL))
                {
                    return !this.HasAura(AURAEFFECT.MOD_SKILL_TALENT);
                }
                return false;
            }
        }

        public ushort ReqSpellID
        {
            get
            {
                return this.m_req_spell;
            }
            set
            {
                this.m_req_spell = value;
                base.Dirty = true;
            }
        }

        public int RequiredItemClass
        {
            get
            {
                return this.m_requiredItemClass;
            }
        }

        public int RequiredItemSubclass
        {
            get
            {
                return this.m_requiredItemSubclass;
            }
        }

        public DAMAGETYPE School
        {
            get
            {
                return this.m_school;
            }
        }

        public bool Slowdown
        {
            get
            {
                return ((this.m_flags[0] & 0x40000000) == 0x40000000);
            }
        }

        public int SpellFocus
        {
            get
            {
                return this.m_spellFocus;
            }
        }

        public int SpellGroup
        {
            get
            {
                return this.m_spellGroup;
            }
        }

        public ushort SpellID
        {
            get
            {
                return (ushort) base.ObjectId;
            }
        }

        public int SpellLevel
        {
            get
            {
                return this.m_spelllevel;
            }
        }

        public bool Stealth
        {
            get
            {
                return ((this.m_flags[1] & 0x10) == 0x10);
            }
        }

        public bool SummonDemon
        {
            get
            {
                return ((this.m_flags[1] & 1) == 1);
            }
        }

        public bool TamedSummon
        {
            get
            {
                return ((this.m_flags[0] & 0x10000000) == 0x10000000);
            }
        }

        public bool Taming
        {
            get
            {
                return ((this.m_flags[2] & 0x400) == 0x400);
            }
        }

        public DBSpell TargetSpell
        {
            get
            {
                return this.m_targetSpell;
            }
            set
            {
                this.m_targetSpell = value;
            }
        }

        public int[] Tools
        {
            get
            {
                return this.m_tools;
            }
        }

        public int[] ToolsType
        {
            get
            {
                return this.m_toolsType;
            }
        }
    }
}

