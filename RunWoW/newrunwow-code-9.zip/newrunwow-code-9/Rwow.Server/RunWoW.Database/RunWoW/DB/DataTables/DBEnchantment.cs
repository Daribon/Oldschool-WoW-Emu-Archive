//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Enchantment")]
    public class DBEnchantment : DBBase
    {
        [DataElement(Name="Effect", ArraySize=3)]
        internal ENCHANTEFFECT[] m_effects = new ENCHANTEFFECT[3];
        [DataElement(Name="Flags")]
        internal int m_flags;
        [DataElement(Name="MaxLevel")]
        internal int m_maxlevel;
        [DataElement(Name="MinLevel")]
        internal int m_minlevel;
        [DataElement(Name="Name")]
        internal string m_name = string.Empty;

        public ENCHANTEFFECT[] Effect
        {
            get
            {
                return this.m_effects;
            }
        }

        public int Flags
        {
            get
            {
                return this.m_flags;
            }
        }

        public int MaxLevel
        {
            get
            {
                return this.m_maxlevel;
            }
        }

        public int MinLevel
        {
            get
            {
                return this.m_minlevel;
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
        }
    }
}

