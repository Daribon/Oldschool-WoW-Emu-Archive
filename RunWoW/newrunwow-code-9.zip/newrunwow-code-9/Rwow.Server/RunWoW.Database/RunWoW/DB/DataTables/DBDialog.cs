﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Dialog")]
    public class DBDialog : DBBase
    {
        [DataElement(Name="Count")]
        internal uint m_count;
        [DataElement(Name="Entry", ArraySize=12)]
        internal DialogEntry[] m_entries = new DialogEntry[12];
        [DataElement(Name="Text_ID")]
        internal uint m_text;
        [Relation(LocalField="TextID", RemoteField="Text_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBText Text;

        public uint Count
        {
            get
            {
                return this.m_count;
            }
            set
            {
                base.Assign<uint>(ref this.m_count, value);
            }
        }

        public DialogEntry[] Entries
        {
            get
            {
                return this.m_entries;
            }
            set
            {
                base.Dirty = true;
                this.m_entries = value;
            }
        }

        public uint TextID
        {
            get
            {
                return this.m_text;
            }
            set
            {
                base.Assign<uint>(ref this.m_text, value);
            }
        }
    }
}

