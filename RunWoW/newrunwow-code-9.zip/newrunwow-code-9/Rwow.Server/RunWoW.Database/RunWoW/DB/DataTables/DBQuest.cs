﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Quest")]
    public class DBQuest : DBBase
    {
        [DataElement(Name="ClassFlag")]
        internal int m_classflag;
        [DataElement(Name="Complete")]
        internal string m_complete;
        [DataElement(Name="Description")]
        internal string m_desc;
        [Index(Name="EndGroup")]
        internal uint m_end;
        [DataElement(Name="RewardExp")]
        internal uint m_exp;
        [DataElement(Name="Faction", ArraySize=2)]
        internal uint[] m_faction = new uint[2];
        [DataElement(Name="Flags")]
        internal int m_flags;
        [DataElement(Name="Incomplete")]
        internal string m_incomplete;
        [DataElement(Name="MaxLevel")]
        internal uint m_maxlevel;
        [DataElement(Name="MinLevel")]
        internal uint m_minlevel;
        [DataElement(Name="Required_Skill_Level")]
        internal int m_minReqSkill;
        [DataElement(Name="RewardMoney")]
        internal uint m_money;
        [DataElement(Name="Name")]
        internal string m_name;
        [DataElement(Name="Next")]
        internal uint m_next;
        [DataElement(Name="PointFlags")]
        internal uint m_pointFlags;
        [DataElement(Name="PointID")]
        internal uint m_pointID;
        [DataElement(Name="Position_X")]
        internal float m_positionX;
        [DataElement(Name="Position_Y")]
        internal float m_positionY;
        [DataElement(Name="RaceFlag")]
        internal int m_raceflag;
        [DataElement(Name="Reputation", ArraySize=2)]
        internal uint[] m_reputation = new uint[2];
        [DataElement(Name="Required_Skill")]
        internal int m_reqSkill;
        [DataElement(Name="Requires", ArraySize=2)]
        internal uint[] m_require = new uint[2];
        [DataElement(Name="RewardReputation")]
        internal uint m_rewardReputation;
        [DataElement(Name="RewardItem", ArraySize=6)]
        internal TypedElementPair[] m_rewards = new TypedElementPair[6];
        [Index(Name="StartGroup")]
        internal uint m_start;
        [DataElement(Name="Target", ArraySize=6)]
        internal TypedElementPair[] m_targets = new TypedElementPair[7];
        [DataElement(Name="Text")]
        internal string m_text;
        [DataElement(Name="Time")]
        internal uint m_time;
        [DataElement(Name="Type")]
        internal uint m_type;
        [DataElement(Name="WorldMap_ID")]
        internal uint m_world;
        [DataElement(Name="Zone")]
        internal int m_zone;

        public int ClassFlag
        {
            get
            {
                return this.m_classflag;
            }
            set
            {
                base.Assign<int>(ref this.m_classflag, value);
            }
        }

        public string Complete
        {
            get
            {
                return this.m_complete;
            }
            set
            {
                base.Assign(ref this.m_complete, value);
            }
        }

        public string Description
        {
            get
            {
                return this.m_desc;
            }
            set
            {
                base.Assign(ref this.m_desc, value);
            }
        }

        public uint EndGroup
        {
            get
            {
                return this.m_end;
            }
            set
            {
                base.Assign<uint>(ref this.m_end, value);
            }
        }

        public uint[] Faction
        {
            get
            {
                return this.m_faction;
            }
        }

        public uint Faction1
        {
            set
            {
                base.Assign<uint>(ref this.m_faction[0], value);
            }
        }

        public uint Faction2
        {
            set
            {
                base.Assign<uint>(ref this.m_faction[1], value);
            }
        }

        public int Flags
        {
            get
            {
                return this.m_flags;
            }
            set
            {
                base.Assign<int>(ref this.m_flags, value);
            }
        }

        public string Incomplete
        {
            get
            {
                return this.m_incomplete;
            }
            set
            {
                base.Assign(ref this.m_incomplete, value);
            }
        }

        public uint MaxLevel
        {
            get
            {
                return this.m_maxlevel;
            }
            set
            {
                base.Assign<uint>(ref this.m_maxlevel, value);
            }
        }

        public uint MinLevel
        {
            get
            {
                return this.m_minlevel;
            }
            set
            {
                base.Assign<uint>(ref this.m_minlevel, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public uint Next
        {
            get
            {
                return this.m_next;
            }
            set
            {
                base.Assign<uint>(ref this.m_next, value);
            }
        }

        public uint PointFlags
        {
            get
            {
                return this.m_pointFlags;
            }
            set
            {
                base.Assign<uint>(ref this.m_pointFlags, value);
            }
        }

        public uint PointID
        {
            get
            {
                return this.m_pointID;
            }
            set
            {
                base.Assign<uint>(ref this.m_pointID, value);
            }
        }

        public float PositionX
        {
            get
            {
                return this.m_positionX;
            }
            set
            {
                base.Assign<float>(ref this.m_positionX, value);
            }
        }

        public float PositionY
        {
            get
            {
                return this.m_positionY;
            }
            set
            {
                base.Assign<float>(ref this.m_positionY, value);
            }
        }

        public int RaceFlag
        {
            get
            {
                return this.m_raceflag;
            }
            set
            {
                base.Assign<int>(ref this.m_raceflag, value);
            }
        }

        public bool Repeatable
        {
            get
            {
                if (!this.Name.StartsWith("A Donation"))
                {
                    return this.Name.StartsWith("Additional");
                }
                return true;
            }
        }

        public uint[] Reputation
        {
            get
            {
                return this.m_reputation;
            }
        }

        public uint Reputation1
        {
            set
            {
                base.Assign<uint>(ref this.m_reputation[0], value);
            }
        }

        public uint Reputation2
        {
            set
            {
                base.Assign<uint>(ref this.m_reputation[1], value);
            }
        }

        public uint Require1
        {
            set
            {
                base.Assign<uint>(ref this.m_require[0], value);
            }
        }

        public uint Require2
        {
            set
            {
                base.Assign<uint>(ref this.m_require[1], value);
            }
        }

        public int RequiredSkill
        {
            get
            {
                return this.m_reqSkill;
            }
            set
            {
                base.Assign<int>(ref this.m_reqSkill, value);
            }
        }

        public int RequiredSkillLevel
        {
            get
            {
                return this.m_minReqSkill;
            }
            set
            {
                base.Assign<int>(ref this.m_minReqSkill, value);
            }
        }

        public uint[] Requires
        {
            get
            {
                return this.m_require;
            }
            set
            {
                this.m_require = value;
                base.Dirty = true;
            }
        }

        public uint RewardExp
        {
            get
            {
                return this.m_exp;
            }
            set
            {
                base.Assign<uint>(ref this.m_exp, value);
            }
        }

        public TypedElementPair[] RewardItem
        {
            get
            {
                return this.m_rewards;
            }
        }

        public uint RewardMoney
        {
            get
            {
                return this.m_money;
            }
            set
            {
                base.Assign<uint>(ref this.m_money, value);
            }
        }

        public uint RewardReputation
        {
            get
            {
                return this.m_rewardReputation;
            }
            set
            {
                base.Assign<uint>(ref this.m_rewardReputation, value);
            }
        }

        public uint StartGroup
        {
            get
            {
                return this.m_start;
            }
            set
            {
                base.Assign<uint>(ref this.m_start, value);
            }
        }

        public TypedElementPair[] Target
        {
            get
            {
                return this.m_targets;
            }
        }

        public string Text
        {
            get
            {
                return this.m_text;
            }
            set
            {
                base.Assign(ref this.m_text, value);
            }
        }

        public uint Time
        {
            get
            {
                return this.m_time;
            }
            set
            {
                base.Assign<uint>(ref this.m_time, value);
            }
        }

        public uint Type
        {
            get
            {
                return this.m_type;
            }
            set
            {
                base.Assign<uint>(ref this.m_type, value);
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_world;
            }
            set
            {
                base.Assign<uint>(ref this.m_world, value);
            }
        }

        public int Zone
        {
            get
            {
                return this.m_zone;
            }
            set
            {
                base.Assign<int>(ref this.m_zone, value);
            }
        }
    }
}

