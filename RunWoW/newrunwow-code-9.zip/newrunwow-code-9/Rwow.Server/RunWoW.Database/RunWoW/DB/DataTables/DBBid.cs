namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="AuctionBids")]
    public class DBBid : DBBase
    {
        [Index(Name="AuctionID")]
        public uint m_auctionID;
        [DataElement(Name="BidAmount")]
        public uint m_bidAmount;
        [Index(Name="BidOwnerID")]
        public uint m_bidOwnerID;

        public uint AuctionID
        {
            get
            {
                return this.m_auctionID;
            }
            set
            {
                base.Assign<uint>(ref this.m_auctionID, value);
            }
        }

        public uint BidAmount
        {
            get
            {
                return this.m_bidAmount;
            }
            set
            {
                base.Assign<uint>(ref this.m_bidAmount, value);
            }
        }

        public uint BidderID
        {
            get
            {
                return this.m_bidOwnerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_bidOwnerID, value);
            }
        }
    }
}

