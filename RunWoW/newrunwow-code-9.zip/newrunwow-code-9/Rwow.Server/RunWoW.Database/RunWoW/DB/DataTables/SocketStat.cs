﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct SocketStat
    {
        [DataElement]
        public int Type;
        [DataElement]
        public int Bonus;
    }
}

