﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="RandomPropertiesGroups")]
    public class DBRandomGroup : DBBase
    {
        [Relation(LocalField="RandomProperiesID", RemoteField="ItemRandomProperties_ID", AutoLoad=true)]
        public DBItemRandomProperties ItemRandomProperties;
        [Index(Name="GroupID")]
        internal int m_groupID;
        [DataElement(Name="Percent")]
        internal float m_percent;
        [DataElement(Name="ItemRandomPropertiesID")]
        internal int m_propID;

        public int GroupID
        {
            get
            {
                return this.m_groupID;
            }
        }

        public float Percent
        {
            get
            {
                return this.m_percent;
            }
        }

        public int RandomProperiesID
        {
            get
            {
                return this.m_propID;
            }
        }
    }
}

