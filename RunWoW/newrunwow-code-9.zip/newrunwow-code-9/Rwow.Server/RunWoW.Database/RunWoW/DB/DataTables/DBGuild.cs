﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Collections.Generic;

    [DataTable(TableName="Guild")]
    public class DBGuild : DBBase
    {
        [DataElement(Name="Border")]
        internal uint m_border;
        [DataElement(Name="BorderColor")]
        internal uint m_bordercolor;
        private Dictionary<string, CharacterHolder> m_characters;
        [DataElement(Name="Color")]
        internal uint m_color;
        [DataElement(Name="CreationDate")]
        internal DateTime m_creationDate;
        [DataElement(Name="GuildInfo")]
        internal string m_guildinfo;
        [DataElement(Name="Icon")]
        internal uint m_icon;
        [DataElement(Name="IconColor")]
        internal uint m_iconcolor;
        private CharacterHolder m_leader;
        [DataElement(Name="Leader")]
        internal uint m_leaderId;
        [DataElement(Name="MaxRank")]
        internal uint m_maxrank;
        [DataElement(Name="MOTD")]
        internal string m_motd;
        [Index(Name="Name")]
        internal string m_name;
        [DataElement(Name="RankFlags", ArraySize=10)]
        internal uint[] m_rankflags = new uint[10];
        [DataElement(Name="RankName", ArraySize=10)]
        internal string[] m_rankname = new string[10];

        public uint Border
        {
            get
            {
                return this.m_border;
            }
            set
            {
                base.Assign<uint>(ref this.m_border, value);
            }
        }

        public uint BorderColor
        {
            get
            {
                return this.m_bordercolor;
            }
            set
            {
                base.Assign<uint>(ref this.m_bordercolor, value);
            }
        }

        public Dictionary<string, CharacterHolder> Characters
        {
            get
            {
                return this.m_characters;
            }
            set
            {
                this.m_characters = value;
            }
        }

        public uint Color
        {
            get
            {
                return this.m_color;
            }
            set
            {
                base.Assign<uint>(ref this.m_color, value);
            }
        }

        public DateTime CreationDate
        {
            get
            {
                return this.m_creationDate;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_creationDate, value);
            }
        }

        public string GuildInfo
        {
            get
            {
                return this.m_guildinfo;
            }
            set
            {
                base.Assign(ref this.m_guildinfo, value);
            }
        }

        public uint Icon
        {
            get
            {
                return this.m_icon;
            }
            set
            {
                base.Assign<uint>(ref this.m_icon, value);
            }
        }

        public uint IconColor
        {
            get
            {
                return this.m_iconcolor;
            }
            set
            {
                base.Assign<uint>(ref this.m_iconcolor, value);
            }
        }

        public CharacterHolder Leader
        {
            get
            {
                return this.m_leader;
            }
            set
            {
                this.m_leader = value;
            }
        }

        public uint LeaderID
        {
            get
            {
                return this.m_leaderId;
            }
            set
            {
                base.Assign<uint>(ref this.m_leaderId, value);
            }
        }

        public uint MaxRank
        {
            get
            {
                return this.m_maxrank;
            }
            set
            {
                base.Assign<uint>(ref this.m_maxrank, value);
            }
        }

        public string MOTD
        {
            get
            {
                return this.m_motd;
            }
            set
            {
                base.Assign(ref this.m_motd, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public uint[] RankFlags
        {
            get
            {
                return this.m_rankflags;
            }
            set
            {
                this.m_rankflags = value;
                base.Dirty = true;
            }
        }

        public string[] RankName
        {
            get
            {
                return this.m_rankname;
            }
            set
            {
                this.m_rankname = value;
                base.Dirty = true;
            }
        }
    }
}

