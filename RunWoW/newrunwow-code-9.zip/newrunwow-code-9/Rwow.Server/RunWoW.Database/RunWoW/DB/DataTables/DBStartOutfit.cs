﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="StartOutfit")]
    public class DBStartOutfit : DBBase
    {
        [DataElement(Name="Class")]
        internal CLASS m_class;
        [DataElement(Name="Gender")]
        internal byte m_gender;
        [DataElement(Name="Item", ArraySize=12)]
        internal uint[] m_item = new uint[12];
        [DataElement(Name="Race")]
        internal RACE m_race;

        public CLASS Class
        {
            get
            {
                return this.m_class;
            }
        }

        public byte Gender
        {
            get
            {
                return this.m_gender;
            }
        }

        public uint[] Item
        {
            get
            {
                return this.m_item;
            }
        }

        public RACE Race
        {
            get
            {
                return this.m_race;
            }
        }
    }
}

