//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="MonsterSpell")]
    public class DBMonsterSpell : DBBase
    {
        [DataElement(Name="AutoCast")]
        internal bool m_auto;
        private DateTime m_cooldown;
        [Index(Name="SpellGroupID")]
        internal uint m_group;
        [DataElement(Name="Offensive")]
        internal bool m_off;
        [DataElement(Name="SpellID", AllowDbNull=false)]
        internal ushort m_spellID;
        [Relation(LocalField="SpellID", RemoteField="Spell_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBSpell Spell;

        public DBMonsterSpell()
        {
            this.m_cooldown = CustomDateTime.Now;
        }

        public DBMonsterSpell(ushort spellID, bool off)
        {
            this.m_cooldown = CustomDateTime.Now;
            this.m_off = off;
            this.m_spellID = spellID;
            this.m_auto = true;
        }

        public bool AutoCast
        {
            get
            {
                return this.m_auto;
            }
            set
            {
                base.Assign<bool>(ref this.m_auto, value);
            }
        }

        public DateTime Cooldown
        {
            get
            {
                return this.m_cooldown;
            }
            set
            {
                this.m_cooldown = value;
            }
        }

        public uint GroupID
        {
            get
            {
                return this.m_group;
            }
            set
            {
                base.Assign<uint>(ref this.m_group, value);
            }
        }

        public bool Offensive
        {
            get
            {
                return this.m_off;
            }
            set
            {
                base.Assign<bool>(ref this.m_off, value);
            }
        }

        public ushort SpellID
        {
            get
            {
                return this.m_spellID;
            }
            set
            {
                base.Assign<ushort>(ref this.m_spellID, value);
            }
        }
    }
}

