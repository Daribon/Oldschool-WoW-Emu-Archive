//
namespace RunWoW.DB.DataTables
{
    using System;

    public class DBConstants
    {
        public const int TargetMaximumAbilities = 0x3a980;
        public const int TargetMaximumAccounts = 800;
        public const int TargetMaximumCharacters = 0x42a;
        public const int TargetMaximumItems = 0x3a980;
    }
}

