﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Repair")]
    public class DBRepair : DBBase
    {
        [DataElement(Name="Armor", ArraySize=7)]
        internal int[] m_armor = new int[7];
        [DataElement(Name="Weapon", ArraySize=0x15)]
        internal int[] m_weapon = new int[0x15];

        public int[] Armor
        {
            get
            {
                return this.m_armor;
            }
        }

        public int[] Weapon
        {
            get
            {
                return this.m_weapon;
            }
        }
    }
}

