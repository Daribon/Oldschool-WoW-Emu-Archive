//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Disenchant")]
    public class DBDisenchant : DBBase
    {
        [Index(Name="ItemTemplate_ID")]
        internal uint m_itemid;
        [DataElement(Name="Name")]
        internal string m_name = string.Empty;
        [DataElement(Name="Reagent", ArraySize=3)]
        internal ElementPair[] m_reagents = new ElementPair[3];

        public uint ItemTemplate_ID
        {
            get
            {
                return this.m_itemid;
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
        }

        public ElementPair[] Reagents
        {
            get
            {
                return this.m_reagents;
            }
        }
    }
}

