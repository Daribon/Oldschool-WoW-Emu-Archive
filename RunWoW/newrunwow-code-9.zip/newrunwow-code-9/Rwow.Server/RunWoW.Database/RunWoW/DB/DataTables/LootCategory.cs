﻿namespace RunWoW.DB.DataTables
{
    using System;

    public enum LootCategory : byte
    {
        ITEM = 3,
        LOOT = 0,
        QUEST = 8,
        RANDOM_ITEM = 5,
        RANDOM_LOOT = 4,
        SKILL = 2,
        SKINNING = 7,
        SPELL = 1
    }
}

