﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="TaxiPath")]
    public class DBTaxiPath : DBBase
    {
        [DataElement(Name="Cost")]
        internal int m_cost;
        [DataElement(Name="EndPoint")]
        internal uint m_end;
        [Index(Name="StartPoint")]
        internal uint m_start;
        [Relation(LocalField="ObjectId", RemoteField="PathID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public PooledList<DBTaxiPathNode> PathNodes;

        public int Cost
        {
            get
            {
                return this.m_cost;
            }
            set
            {
                base.Assign<int>(ref this.m_cost, value);
            }
        }

        public uint End
        {
            get
            {
                return this.m_end;
            }
            set
            {
                base.Assign<uint>(ref this.m_end, value);
            }
        }

        public uint Start
        {
            get
            {
                return this.m_start;
            }
            set
            {
                base.Assign<uint>(ref this.m_start, value);
            }
        }
    }
}

