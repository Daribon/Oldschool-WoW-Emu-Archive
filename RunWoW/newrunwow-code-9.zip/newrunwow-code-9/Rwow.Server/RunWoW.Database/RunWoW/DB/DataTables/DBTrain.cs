//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Train")]
    public class DBTrain : DBBase
    {
        [Index(Name="TrainGroupID")]
        internal uint m_group;
        [DataElement(Name="TrainTargetID")]
        internal uint m_target;
        [Relation(LocalField="TargetID", RemoteField="Spell_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBSpell Target;

        public uint GroupID
        {
            get
            {
                return this.m_group;
            }
            set
            {
                base.Assign<uint>(ref this.m_group, value);
            }
        }

        public DBSpell Spell
        {
            get
            {
                return this.Target;
            }
        }

        public uint TargetID
        {
            get
            {
                return this.m_target;
            }
            set
            {
                base.Assign<uint>(ref this.m_target, value);
            }
        }
    }
}

