﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct CraftReq
    {
        [DataElement]
        public int ItemTemplateID;
        [DataElement]
        public sbyte Quantity;
    }
}

