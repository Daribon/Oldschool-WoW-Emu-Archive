﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="ActionButton")]
    public class DBActionButton : DBBase
    {
        [DataElement(Name="Action")]
        internal ushort m_action;
        [DataElement(Name="Misc")]
        internal ushort m_misc;
        [Index(Name="Owner_ID")]
        internal uint m_ownerID;
        [DataElement(Name="Slot")]
        internal ushort m_slot;
        [DataElement(Name="Type")]
        internal ushort m_type;

        public ushort Action
        {
            get
            {
                return this.m_action;
            }
            set
            {
                base.Assign<ushort>(ref this.m_action, value);
            }
        }

        public ushort Misc
        {
            get
            {
                return this.m_misc;
            }
            set
            {
                base.Assign<ushort>(ref this.m_misc, value);
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }

        public ushort Slot
        {
            get
            {
                return this.m_slot;
            }
            set
            {
                base.Assign<ushort>(ref this.m_slot, value);
            }
        }

        public ushort Type
        {
            get
            {
                return this.m_type;
            }
            set
            {
                base.Assign<ushort>(ref this.m_type, value);
            }
        }
    }
}

