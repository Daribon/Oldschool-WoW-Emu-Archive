﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct TypedElementPair
    {
        [DataElement]
        public uint ID;
        [DataElement]
        public uint Count;
        [DataElement]
        public byte Type;
        public int DisplayID;
    }
}

