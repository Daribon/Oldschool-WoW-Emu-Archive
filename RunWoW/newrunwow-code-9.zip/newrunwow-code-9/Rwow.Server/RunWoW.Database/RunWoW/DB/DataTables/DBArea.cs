//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="Area")]
    public class DBArea : DBBase
    {
        [DataElement(Name="AreaFlag")]
        internal int m_areaFlag;
        [DataElement(Name="FishGroupID")]
        internal uint m_fishgroup;
        [DataElement(Name="Level")]
        internal int m_level;
        [DataElement(Name="Name")]
        internal string m_name;
        [DataElement(Name="Type")]
        internal byte m_type;
        [DataElement(Name="Weather")]
        internal WeatherType m_weather;
        [Index(Name="WorldMapID")]
        internal uint m_worldmapID;

        public int AreaFlag
        {
            get
            {
                return this.m_areaFlag;
            }
            set
            {
                base.Assign<int>(ref this.m_areaFlag, value);
            }
        }

        public uint FishGroupID
        {
            get
            {
                return this.m_fishgroup;
            }
            set
            {
                base.Assign<uint>(ref this.m_fishgroup, value);
            }
        }

        public int Level
        {
            get
            {
                return this.m_level;
            }
            set
            {
                base.Assign<int>(ref this.m_level, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public byte Type
        {
            get
            {
                return this.m_type;
            }
            set
            {
                base.Assign<byte>(ref this.m_type, value);
            }
        }

        public WeatherType Weather
        {
            get
            {
                return this.m_weather;
            }
            set
            {
                this.m_weather = value;
                base.Dirty = true;
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldmapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldmapID, value);
            }
        }
    }
}

