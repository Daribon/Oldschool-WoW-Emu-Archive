//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="FactionTemplate")]
    public class DBFaction : DBBase
    {
        [DataElement(Name="Description")]
        internal string m_descr = string.Empty;
        [DataElement(Name="Enemies")]
        internal byte m_enemies;
        [DataElement(Name="Faction_ID")]
        internal uint m_factionid;
        [DataElement(Name="Friends")]
        internal byte m_friends;
        [DataElement(Name="Hostiles")]
        internal byte m_hostiles;
        [DataElement(Name="Reputation")]
        internal int m_reputation;

        public string Description
        {
            get
            {
                return this.m_descr;
            }
            set
            {
                base.Assign(ref this.m_descr, value);
            }
        }

        public byte Enemies
        {
            get
            {
                return this.m_enemies;
            }
            set
            {
                base.Assign<byte>(ref this.m_enemies, value);
            }
        }

        public uint Faction
        {
            get
            {
                return this.m_factionid;
            }
            set
            {
                base.Assign<uint>(ref this.m_factionid, value);
            }
        }

        public byte Friends
        {
            get
            {
                return this.m_friends;
            }
            set
            {
                base.Assign<byte>(ref this.m_friends, value);
            }
        }

        public byte Hostiles
        {
            get
            {
                return this.m_hostiles;
            }
            set
            {
                base.Assign<byte>(ref this.m_hostiles, value);
            }
        }

        public int Reputation
        {
            get
            {
                return this.m_reputation;
            }
            set
            {
                base.Assign<int>(ref this.m_reputation, value);
            }
        }
    }
}

