//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Lock")]
    public class DBLock : DBBase
    {
        [DataElement(Name="Level", ArraySize=5)]
        internal int[] m_level = new int[5];
        [DataElement(Name="Target", ArraySize=5)]
        internal int[] m_target = new int[5];
        [DataElement(Name="Type")]
        internal int m_type;

        public int[] Level
        {
            get
            {
                return this.m_level;
            }
        }

        public int[] Target
        {
            get
            {
                return this.m_target;
            }
        }

        public int Type
        {
            get
            {
                return this.m_type;
            }
        }
    }
}

