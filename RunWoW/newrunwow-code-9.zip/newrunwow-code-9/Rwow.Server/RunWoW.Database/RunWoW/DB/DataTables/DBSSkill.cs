﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="SSkill")]
    public class DBSSkill : DBBase
    {
        [DataElement(Name="ClassFlag")]
        internal int m_class;
        [DataElement(Name="RaceFlag")]
        internal int m_race;
        [Index(Name="Skill_ID")]
        internal int m_skill;
        [DataElement(Name="SkillName")]
        internal string m_skillname = string.Empty;
        [DataElement(Name="Spell_ID")]
        internal int m_spell;
        [DataElement(Name="SpellName")]
        internal string m_spellname = string.Empty;
        [Index(Name="StartSkill")]
        internal int m_start;

        public int ClassFlag
        {
            get
            {
                return this.m_class;
            }
        }

        public int RaceFlag
        {
            get
            {
                return this.m_race;
            }
        }

        public int SkillID
        {
            get
            {
                return this.m_skill;
            }
        }

        public string SkillName
        {
            get
            {
                return this.m_skillname;
            }
        }

        public int SpellID
        {
            get
            {
                return this.m_spell;
            }
        }

        public string SpellName
        {
            get
            {
                return this.m_spellname;
            }
        }

        public int StartSkill
        {
            get
            {
                return this.m_start;
            }
        }
    }
}

