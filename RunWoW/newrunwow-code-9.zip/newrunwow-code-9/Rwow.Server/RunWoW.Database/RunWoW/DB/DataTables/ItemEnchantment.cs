﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct ItemEnchantment
    {
        [DataElement(Name="id"), UpdateValue(Field=0)]
        public int ID;
        [DataElement(Name="expiration"), UpdateValue(Field=1)]
        public int Expires;
        [DataElement(Name="chargesRemaining"), UpdateValue(Field=2)]
        public int Charges;
        public DBEnchantment Enchantment;
    }
}

