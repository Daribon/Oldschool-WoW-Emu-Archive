﻿namespace RunWoW.DB.DataTables
{
    using System;

    public enum ABILITYTYPE : byte
    {
        PET_SPELL = 3,
        SKILL = 1,
        SPELL = 0,
        TALENT = 2
    }
}

