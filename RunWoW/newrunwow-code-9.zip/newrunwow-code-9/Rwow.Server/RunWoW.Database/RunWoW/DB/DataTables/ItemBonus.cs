﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct ItemBonus
    {
        [DataElement]
        public int Stat;
        [DataElement(Name="Amount")]
        public int Bonus;
    }
}

