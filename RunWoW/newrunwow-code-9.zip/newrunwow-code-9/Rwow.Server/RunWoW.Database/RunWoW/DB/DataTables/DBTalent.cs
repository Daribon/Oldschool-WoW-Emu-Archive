﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Talent")]
    public class DBTalent : DBBase
    {
        [DataElement(Name="Level")]
        internal byte m_level;
        [DataElement(Name="TalentIDNeeded")]
        internal int m_needed;
        [DataElement(Name="SpellID", ArraySize=5)]
        internal int[] m_spells = new int[5];
        [DataElement(Name="TabNum")]
        internal byte m_tab;

        public byte Level
        {
            get
            {
                return this.m_level;
            }
        }

        public int ReqTalent
        {
            get
            {
                return this.m_needed;
            }
        }

        public int[] SpellID
        {
            get
            {
                return this.m_spells;
            }
        }

        public byte Tab
        {
            get
            {
                return this.m_tab;
            }
        }
    }
}

