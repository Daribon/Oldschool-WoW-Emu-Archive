﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="GOTemplate")]
    public class DBGOTemplate : DBBase
    {
        [DataElement(Name="DisplayID")]
        internal int m_displayid;
        [DataElement(Name="LootGroupID")]
        internal uint m_lootid;
        [DataElement(Name="Name")]
        internal string m_name = string.Empty;
        [DataElement(Name="Name1")]
        internal string m_name1 = string.Empty;
        [DataElement(Name="Name2")]
        internal string m_name2 = string.Empty;
        [DataElement(Name="Name3")]
        internal string m_name3 = string.Empty;
        [DataElement(Name="Scale")]
        internal float m_scale = 1f;
        [DataElement(Name="Sound", ArraySize=10)]
        internal int[] m_sound = new int[10];
        [DataElement(Name="Transport")]
        internal byte m_transport;
        [DataElement(Name="TypeID")]
        internal int m_typeid;

        public int DisplayID
        {
            get
            {
                return this.m_displayid;
            }
            set
            {
                base.Assign<int>(ref this.m_displayid, value);
            }
        }

        public uint LootGroupId
        {
            get
            {
                return this.m_lootid;
            }
            set
            {
                base.Assign<uint>(ref this.m_lootid, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public string Name1
        {
            get
            {
                return this.m_name1;
            }
            set
            {
                base.Assign(ref this.m_name1, value);
            }
        }

        public string Name2
        {
            get
            {
                return this.m_name2;
            }
            set
            {
                base.Assign(ref this.m_name2, value);
            }
        }

        public string Name3
        {
            get
            {
                return this.m_name3;
            }
            set
            {
                base.Assign(ref this.m_name3, value);
            }
        }

        public float Scale
        {
            get
            {
                return this.m_scale;
            }
            set
            {
                base.Assign<float>(ref this.m_scale, value);
            }
        }

        public int[] Sound
        {
            get
            {
                return this.m_sound;
            }
            set
            {
                base.Dirty = true;
                this.m_sound = value;
            }
        }

        public bool Transport
        {
            get
            {
                return (this.m_transport == 1);
            }
            set
            {
                this.m_transport = value ? ((byte) 1) : ((byte) 0);
                base.Dirty = true;
            }
        }

        public int TypeID
        {
            get
            {
                return this.m_typeid;
            }
            set
            {
                base.Assign<int>(ref this.m_typeid, value);
            }
        }
    }
}

