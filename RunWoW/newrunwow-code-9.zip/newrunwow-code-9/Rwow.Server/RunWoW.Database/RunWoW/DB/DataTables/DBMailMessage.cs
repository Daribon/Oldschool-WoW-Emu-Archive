﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="MailMessage")]
    public class DBMailMessage : DBBase
    {
        [DataElement(Name="BodyText")]
        internal string m_body;

        public string Body
        {
            get
            {
                return this.m_body;
            }
            set
            {
                base.Assign(ref this.m_body, value);
            }
        }
    }
}

