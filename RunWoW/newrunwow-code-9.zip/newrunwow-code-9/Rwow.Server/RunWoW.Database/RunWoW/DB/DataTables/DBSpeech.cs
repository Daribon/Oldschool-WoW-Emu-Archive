//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="Speech")]
    public class DBSpeech : DBBase
    {
        [Relation(LocalField="AttackedTextID", RemoteField="Text_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBText AttackedText;
        [Relation(LocalField="FleeTextID", RemoteField="Text_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBText FleeText;
        [DataElement(Name="Class", ArraySize=11)]
        internal uint[] m_dialogs = new uint[11];

        public uint Dialog(CLASS cl)
        {
            int index = this.getClassNum(cl);
            if ((index >= 0) && (index <= 8))
            {
                return this.m_dialogs[index];
            }
            return 0;
        }

        private int getClassNum(CLASS cl)
        {
            if (cl < (CLASS.ANY | CLASS.ROGUE | CLASS.PALADIN))
            {
                return (((int) cl) - 1);
            }
            if (cl < CLASS.DRUID)
            {
                return (((int) cl) - 2);
            }
            return (((int) cl) - 3);
        }

        public void SetDialog(CLASS cl, uint w)
        {
            int index = this.getClassNum(cl);
            if ((index >= 0) && (index <= 8))
            {
                this.m_dialogs[index] = w;
                base.Dirty = true;
            }
        }

        public uint AttackedTextID
        {
            get
            {
                return this.m_dialogs[9];
            }
            set
            {
                this.m_dialogs[9] = value;
            }
        }

        public uint FleeTextID
        {
            get
            {
                return this.m_dialogs[10];
            }
            set
            {
                this.m_dialogs[10] = value;
            }
        }
    }
}

