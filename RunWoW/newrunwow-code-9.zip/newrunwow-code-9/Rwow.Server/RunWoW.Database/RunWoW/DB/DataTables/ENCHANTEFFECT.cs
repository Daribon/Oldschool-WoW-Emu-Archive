//
namespace RunWoW.DB.DataTables
{
    using System;

    public enum ENCHANTEFFECT : byte
    {
        ARMOR = 4,
        DAMAGE = 2,
        NONE = 0,
        PROC_SPELL = 1,
        SPELL = 3
    }
}

