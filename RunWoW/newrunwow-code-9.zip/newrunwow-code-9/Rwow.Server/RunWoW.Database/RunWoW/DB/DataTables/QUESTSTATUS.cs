﻿namespace RunWoW.DB.DataTables
{
    using System;

    public enum QUESTSTATUS : byte
    {
        COMPLETED = 2,
        FAILED = 1,
        FINISHED = 3,
        STARTED = 0
    }
}

