//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database;
    using RunWoW.DB;
    using System;

    public class DBBase : DataObject
    {
        protected void Assign(ref DBVector var, Vector value)
        {
            if ((base.Dirty || (var.X != value.X)) || ((var.Y != value.Y) || (var.Z != value.Z)))
            {
                var.Vector = value;
                base.Dirty = true;
            }
        }

        protected void Assign<T>(ref T var, T value)
        {
            if (base.Dirty || !var.Equals(value))
            {
                var = value;
                base.Dirty = true;
            }
        }

        protected void Assign(ref string var, string value)
        {
            if ((base.Dirty || ((var == null) && (value != null))) || !var.Equals(value))
            {
                var = value;
                base.Dirty = true;
            }
        }
    }
}

