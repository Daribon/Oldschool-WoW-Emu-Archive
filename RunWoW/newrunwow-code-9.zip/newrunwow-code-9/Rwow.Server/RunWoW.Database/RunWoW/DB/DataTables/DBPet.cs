//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Pet")]
    public class DBPet : DBBase
    {
        [Relation(LocalField="TrueCreatureID", RemoteField="Creature_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBCreature Creature;
        [DataElement(Name="CreatureID")]
        internal uint m_creatureId;
        [DataElement(Name="Exp")]
        internal uint m_exp;
        [DataElement(Name="Grows")]
        internal byte m_grows;
        [DataElement(Name="Happyness")]
        internal int m_happy;
        [DataElement(Name="Level")]
        internal uint m_level;
        [DataElement(Name="Name")]
        internal string m_name;
        [Index(Name="Owner_ID")]
        internal uint m_ownerID;
        [DataElement(Name="TrueCreatureID")]
        internal uint m_trueCreatureId;
        [Relation(LocalField="ObjectId", RemoteField="Owner_ID", AutoLoad=false, AutoSave=true, AutoDelete=true)]
        public PooledList<DBPetSpell> Spells;

        public uint CreatureID
        {
            get
            {
                return this.m_creatureId;
            }
            set
            {
                base.Assign<uint>(ref this.m_creatureId, value);
            }
        }

        public uint Exp
        {
            get
            {
                return this.m_exp;
            }
            set
            {
                base.Assign<uint>(ref this.m_exp, value);
            }
        }

        public bool Grows
        {
            get
            {
                return (this.m_grows > 0);
            }
            set
            {
                this.m_grows = value ? ((byte) 1) : ((byte) 0);
                base.Dirty = true;
            }
        }

        public int Happyness
        {
            get
            {
                return this.m_happy;
            }
            set
            {
                base.Assign<int>(ref this.m_happy, value);
            }
        }

        public uint Level
        {
            get
            {
                return this.m_level;
            }
            set
            {
                base.Assign<uint>(ref this.m_level, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }

        public uint TrueCreatureID
        {
            get
            {
                return this.m_trueCreatureId;
            }
            set
            {
                base.Assign<uint>(ref this.m_trueCreatureId, value);
            }
        }
    }
}

