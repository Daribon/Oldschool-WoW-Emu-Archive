//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using RunWoW.DB;
    using System;
    using System.Collections;

    [DataTable(TableName="Characters", ResolveTypes=new Type[] { typeof(DBItem), typeof(DBAbility), typeof(DBQuestLog), typeof(DBActionButton) }/*, ResolveProcedure="getCharacterData"*/)]
    public class DBCharacter : DBBase
    {
        [Relation(LocalField="ObjectId", RemoteField="Owner_ID", AutoLoad=false, AutoSave=true, AutoDelete=true)]
        public PooledList<DBAbility> Abilities;
        [Relation(LocalField="ObjectId", RemoteField="Owner_ID", AutoLoad=false, AutoSave=true, AutoDelete=true)]
        public PooledList<DBActionButton> Actions;
        [Relation(LocalField="ObjectId", RemoteField="Owner_ID", AutoLoad=false, AutoSave=false, AutoDelete=false)]
        public PooledList<DBFriendList> Friends;
        [Relation(LocalField="GuildID", RemoteField="Guild_ID", AutoLoad=false, AutoSave=true, AutoDelete=true)]
        public DBGuild Guild;
        [Relation(LocalField="ObjectId", RemoteField="OwnerID", AutoLoad=false, AutoSave=true, AutoDelete=true)]
        public PooledList<DBItem> Items;
        [Index(Name="AccountID", AllowDbNull=false)]
        internal uint m_accountID;
        [DataElement(Name="ActionBars")]
        internal byte m_actionBars;
        [DataElement(Name="IsActive")]
        internal byte m_active = 1;
        [DataElement(Name="Agility")]
        internal short m_agility;
        [DataElement(Name="Ammo")]
        internal uint m_ammo;
        [DataElement(Name="BankSlots")]
        internal byte m_bankSlots;
        [DataElement(Name="BindPoint")]
        internal DBVector m_bind = new DBVector();
        [DataElement(Name="BindWorld")]
        internal uint m_bind_world;
        [DataElement(Name="BindZone")]
        internal uint m_bind_zone;
        [DataElement(Name="Class")]
        internal CLASS m_class;
        [DataElement(Name="CreationDate")]
        internal DateTime m_creationDate = CustomDateTime.Now;
        [DataElement(Name="DeathPoint")]
        internal DBVector m_deathPoint = new DBVector();
        [DataElement(Name="DeathWorld")]
        internal int m_deathWorld = -1;
        [DataElement(Name="DisplayID")]
        internal short m_displayID;
        [DataElement(Name="Exp")]
        internal int m_exp;
        internal byte[][] m_exploredZones = new byte[1][];
        [DataElement(Name="Face")]
        internal byte m_face;
        [DataElement(Name="FacialHairStyle")]
        internal byte m_facialHairStyle;
        [DataElement(Name="Facing")]
        internal float m_facing;
        [DataElement(Name="Faction")]
        internal FACTION m_faction;
        [DataElement(Name="Gender")]
        internal byte m_gender;
        [DataElement(Name="GroupID")]
        internal uint m_GroupID;
        [Index(Name="GuildID", SkipZero=true)]
        internal uint m_GuildID;
        [DataElement(Name="GuildRank")]
        internal uint m_GuildRank;
        [DataElement(Name="HairColor")]
        internal byte m_hairColor;
        [DataElement(Name="HairStyle")]
        internal byte m_hairStyle;
        [DataElement(Name="Health")]
        internal short m_health;
        [DataElement(Name="HKills")]
        internal int m_hkills;
        [DataElement(Name="Honor")]
        internal int m_honor;
        [DataElement(Name="Intellect")]
        internal short m_intellect;
        [DataElement(Name="LastAccess")]
        internal DateTime m_lastaccess = CustomDateTime.Now;
        [DataElement(Name="LastPetID")]
        internal uint m_lastPetID;
        [DataElement(Name="Level")]
        internal byte m_level;
        [DataElement(Name="MaxHealth")]
        internal short m_maxHealth;
        [DataElement(Name="MaxPower")]
        internal short m_maxPower;
        private string m_message = string.Empty;
        [DataElement(Name="Money")]
        internal int m_money;
        [Index(Name="Name", Unique=true)]
        internal string m_name;
        [DataElement(Name="GuildOfficerNote")]
        internal string m_officerNote = string.Empty;
        [DataElement(Name="OriginalClass")]
        internal CLASS m_originalClass;
        [DataElement(Name="Outfit", ArraySize=0x13)]
        internal int[] m_outfit = new int[0x13];
        [DataElement(Name="Position")]
        internal DBVector m_position = new DBVector();
        [DataElement(Name="Power")]
        internal short m_power;
        [DataElement(Name="PowerType")]
        internal POWERTYPE m_powerType;
        [DataElement(Name="ProfPoints")]
        internal byte m_profPoints;
        [DataElement(Name="ProfsWiped")]
        internal ushort m_profsWiped;
        [DataElement(Name="GuildPublicNote")]
        internal string m_publicNote = string.Empty;
        [DataElement(Name="PVPRank")]
        internal byte m_pvprank;
        [DataElement(Name="Race")]
        internal RACE m_race;
        [DataElement(Name="RankPoints")]
        internal int m_rankPoints;
        [DataElement(Name="RestedState")]
        internal int m_restedPoints;
        [DataElement(Name="RPAll")]
        internal int m_rpAll;
        [DataElement(Name="Scale")]
        internal float m_scale = 1f;
        [DataElement(Name="Skin")]
        internal byte m_skin;
        [DataElement(Name="Spirit")]
        internal short m_spirit;
        [DataElement(Name="Stamina")]
        internal short m_stamina;
        [DataElement(Name="Strength")]
        internal short m_strength;
        [DataElement(Name="TalentPoints")]
        internal byte m_talentPoints;
        [DataElement(Name="TalentsWiped")]
        internal ushort m_talentsWiped;
        [DataElement(Name="Taxi", ArraySize=8)]
        internal int[] m_taxi = new int[8];
        private BitArray m_taxiArray;
        [DataElement(Name="TutorialFlags", ArraySize=8)]
        internal int[] m_tutorialFlags = new int[8];
        [DataElement(Name="UHKills")]
        internal int m_uhkills;
        internal byte[][] m_uiconfig = new byte[8][];
        [DataElement(Name="WeeklyStanding")]
        internal int m_weeklyStanding;
        [DataElement(Name="WorldMapID")]
        internal uint m_worldmapID;
        [DataElement(Name="Zone")]
        internal uint m_zone;
        [Relation(LocalField="ObjectId", RemoteField="Friend_ID", AutoLoad=false, AutoSave=false, AutoDelete=false)]
        public PooledList<DBFriendList> OnFriends;
        [Relation(LocalField="ObjectId", RemoteField="Owner_ID", AutoLoad=false, AutoSave=true, AutoDelete=true)]
        public PooledList<DBPet> PetList;
        [Relation(LocalField="ObjectId", RemoteField="Owner_ID", AutoLoad=false, AutoSave=true, AutoDelete=true)]
        public PooledList<DBQuestLog> QuestLog;

        public uint AccountID
        {
            get
            {
                return this.m_accountID;
            }
            set
            {
                base.Assign<uint>(ref this.m_accountID, value);
            }
        }

        public byte ActionBars
        {
            get
            {
                return this.m_actionBars;
            }
            set
            {
                base.Assign<byte>(ref this.m_actionBars, value);
            }
        }

        public byte Active
        {
            get
            {
                return this.m_active;
            }
            set
            {
                base.Assign<byte>(ref this.m_active, value);
            }
        }

        public short Agility
        {
            get
            {
                return this.m_agility;
            }
            set
            {
                base.Assign<short>(ref this.m_agility, value);
            }
        }

        public uint Ammo
        {
            get
            {
                return this.m_ammo;
            }
            set
            {
                base.Assign<uint>(ref this.m_ammo, value);
            }
        }

        public byte BankSlots
        {
            get
            {
                return this.m_bankSlots;
            }
            set
            {
                base.Assign<byte>(ref this.m_bankSlots, value);
            }
        }

        public Vector BindPoint
        {
            get
            {
                return this.m_bind.Vector;
            }
            set
            {
                base.Assign(ref this.m_bind, value);
            }
        }

        public uint BindWorld
        {
            get
            {
                return this.m_bind_world;
            }
            set
            {
                base.Assign<uint>(ref this.m_bind_world, value);
            }
        }

        public uint BindZone
        {
            get
            {
                return this.m_bind_zone;
            }
            set
            {
                base.Assign<uint>(ref this.m_bind_zone, value);
            }
        }

        public CLASS Class
        {
            get
            {
                return this.m_class;
            }
            set
            {
                base.Assign<CLASS>(ref this.m_class, value);
            }
        }

        public DateTime CreationDate
        {
            get
            {
                return this.m_creationDate;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_creationDate, value);
            }
        }

        public Vector DeathPoint
        {
            get
            {
                return this.m_deathPoint.Vector;
            }
            set
            {
                base.Assign(ref this.m_deathPoint, value);
            }
        }

        public int DeathWorld
        {
            get
            {
                return this.m_deathWorld;
            }
            set
            {
                base.Assign<int>(ref this.m_deathWorld, value);
            }
        }

        public int DHKills
        {
            get
            {
                return this.m_uhkills;
            }
            set
            {
                base.Assign<int>(ref this.m_uhkills, value);
            }
        }

        public short DisplayID
        {
            get
            {
                return this.m_displayID;
            }
            set
            {
                base.Assign<short>(ref this.m_displayID, value);
            }
        }

        public int Exp
        {
            get
            {
                return this.m_exp;
            }
            set
            {
                base.Assign<int>(ref this.m_exp, value);
            }
        }

        public byte[][] ExploredZones
        {
            get
            {
                return this.m_exploredZones;
            }
        }

        public byte Face
        {
            get
            {
                return this.m_face;
            }
            set
            {
                base.Assign<byte>(ref this.m_face, value);
            }
        }

        public byte FacialHairStyle
        {
            get
            {
                return this.m_facialHairStyle;
            }
            set
            {
                base.Assign<byte>(ref this.m_facialHairStyle, value);
            }
        }

        public float Facing
        {
            get
            {
                return this.m_facing;
            }
            set
            {
                base.Assign<float>(ref this.m_facing, value);
            }
        }

        public FACTION Faction
        {
            get
            {
                return this.m_faction;
            }
            set
            {
                base.Assign<FACTION>(ref this.m_faction, value);
            }
        }

        public byte Gender
        {
            get
            {
                return this.m_gender;
            }
            set
            {
                base.Assign<byte>(ref this.m_gender, value);
            }
        }

        public uint GroupID
        {
            get
            {
                return this.m_GroupID;
            }
            set
            {
                base.Assign<uint>(ref this.m_GroupID, value);
            }
        }

        public uint GuildID
        {
            get
            {
                return this.m_GuildID;
            }
            set
            {
                base.Assign<uint>(ref this.m_GuildID, value);
            }
        }

        public string GuildOfficerNote
        {
            get
            {
                return this.m_officerNote;
            }
            set
            {
                base.Assign(ref this.m_officerNote, value);
            }
        }

        public string GuildPublicNote
        {
            get
            {
                return this.m_publicNote;
            }
            set
            {
                base.Assign(ref this.m_publicNote, value);
            }
        }

        public uint GuildRank
        {
            get
            {
                return this.m_GuildRank;
            }
            set
            {
                base.Assign<uint>(ref this.m_GuildRank, value);
            }
        }

        public byte HairColor
        {
            get
            {
                return this.m_hairColor;
            }
            set
            {
                base.Assign<byte>(ref this.m_hairColor, value);
            }
        }

        public byte HairStyle
        {
            get
            {
                return this.m_hairStyle;
            }
            set
            {
                base.Assign<byte>(ref this.m_hairStyle, value);
            }
        }

        public short Health
        {
            get
            {
                return this.m_health;
            }
            set
            {
                base.Assign<short>(ref this.m_health, value);
            }
        }

        public int HKills
        {
            get
            {
                return this.m_hkills;
            }
            set
            {
                base.Assign<int>(ref this.m_hkills, value);
            }
        }

        public int Honor
        {
            get
            {
                return this.m_honor;
            }
            set
            {
                base.Assign<int>(ref this.m_honor, value);
            }
        }

        public short Intellect
        {
            get
            {
                return this.m_intellect;
            }
            set
            {
                base.Assign<short>(ref this.m_intellect, value);
            }
        }

        public DateTime LastAccess
        {
            get
            {
                return this.m_lastaccess;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_lastaccess, value);
            }
        }

        public uint LastPetID
        {
            get
            {
                return this.m_lastPetID;
            }
            set
            {
                base.Assign<uint>(ref this.m_lastPetID, value);
            }
        }

        public byte Level
        {
            get
            {
                return this.m_level;
            }
            set
            {
                base.Assign<byte>(ref this.m_level, value);
            }
        }

        public short MaxHealth
        {
            get
            {
                return this.m_maxHealth;
            }
            set
            {
                base.Assign<short>(ref this.m_maxHealth, value);
            }
        }

        public short MaxPower
        {
            get
            {
                return this.m_maxPower;
            }
            set
            {
                base.Assign<short>(ref this.m_maxPower, value);
            }
        }

        public string Message
        {
            get
            {
                return this.m_message;
            }
            set
            {
                this.m_message = value;
            }
        }

        public int Money
        {
            get
            {
                return this.m_money;
            }
            set
            {
                base.Assign<int>(ref this.m_money, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public CLASS OriginalClass
        {
            get
            {
                return this.m_originalClass;
            }
            set
            {
                base.Assign<CLASS>(ref this.m_originalClass, value);
            }
        }

        public int[] Outfit
        {
            get
            {
                return this.m_outfit;
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_position.Vector;
            }
            set
            {
                base.Assign(ref this.m_position, value);
            }
        }

        public short Power
        {
            get
            {
                return this.m_power;
            }
            set
            {
                base.Assign<short>(ref this.m_power, value);
            }
        }

        public POWERTYPE PowerType
        {
            get
            {
                return this.m_powerType;
            }
            set
            {
                base.Assign<POWERTYPE>(ref this.m_powerType, value);
            }
        }

        public byte ProfPoints
        {
            get
            {
                return this.m_profPoints;
            }
            set
            {
                base.Assign<byte>(ref this.m_profPoints, value);
            }
        }

        public ushort ProfWiped
        {
            get
            {
                return this.m_profsWiped;
            }
            set
            {
                base.Assign<ushort>(ref this.m_profsWiped, value);
            }
        }

        public byte PVPRank
        {
            get
            {
                return this.m_pvprank;
            }
            set
            {
                base.Assign<byte>(ref this.m_pvprank, value);
            }
        }

        public RACE Race
        {
            get
            {
                return this.m_race;
            }
            set
            {
                base.Assign<RACE>(ref this.m_race, value);
            }
        }

        public int RankPoints
        {
            get
            {
                return this.m_rankPoints;
            }
            set
            {
                base.Assign<int>(ref this.m_rankPoints, value);
            }
        }

        public int RestedPoints
        {
            get
            {
                return this.m_restedPoints;
            }
            set
            {
                base.Assign<int>(ref this.m_restedPoints, value);
            }
        }

        public int RPAll
        {
            get
            {
                return this.m_rpAll;
            }
            set
            {
                base.Assign<int>(ref this.m_rpAll, value);
            }
        }

        public float Scale
        {
            get
            {
                return this.m_scale;
            }
            set
            {
                base.Assign<float>(ref this.m_scale, value);
            }
        }

        public byte Skin
        {
            get
            {
                return this.m_skin;
            }
            set
            {
                base.Assign<byte>(ref this.m_skin, value);
            }
        }

        public short Spirit
        {
            get
            {
                return this.m_spirit;
            }
            set
            {
                base.Assign<short>(ref this.m_spirit, value);
            }
        }

        public short Stamina
        {
            get
            {
                return this.m_stamina;
            }
            set
            {
                base.Assign<short>(ref this.m_stamina, value);
            }
        }

        public short Strength
        {
            get
            {
                return this.m_strength;
            }
            set
            {
                base.Assign<short>(ref this.m_strength, value);
            }
        }

        public byte TalentPoints
        {
            get
            {
                return this.m_talentPoints;
            }
            set
            {
                base.Assign<byte>(ref this.m_talentPoints, value);
            }
        }

        public ushort TalentsWiped
        {
            get
            {
                return this.m_talentsWiped;
            }
            set
            {
                base.Assign<ushort>(ref this.m_talentsWiped, value);
            }
        }

        public int[] Taxi
        {
            get
            {
                return this.m_taxi;
            }
        }

        public BitArray TaxiArray
        {
            get
            {
                if (this.m_taxiArray == null)
                {
                    this.m_taxiArray = new BitArray(this.m_taxi);
                }
                return this.m_taxiArray;
            }
        }

        public int[] TutorialFlags
        {
            get
            {
                return this.m_tutorialFlags;
            }
        }

        public byte[][] UIConfig
        {
            get
            {
                return this.m_uiconfig;
            }
            set
            {
                this.m_uiconfig = value;
            }
        }

        public int WeeklyStanding
        {
            get
            {
                return this.m_weeklyStanding;
            }
            set
            {
                base.Assign<int>(ref this.m_weeklyStanding, value);
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldmapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldmapID, value);
            }
        }

        public uint Zone
        {
            get
            {
                return this.m_zone;
            }
            set
            {
                base.Assign<uint>(ref this.m_zone, value);
            }
        }
    }
}

