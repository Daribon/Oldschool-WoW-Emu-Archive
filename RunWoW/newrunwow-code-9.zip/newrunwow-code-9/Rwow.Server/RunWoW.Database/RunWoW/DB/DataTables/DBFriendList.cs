﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="FriendList")]
    public class DBFriendList : DBBase
    {
        [Index(Name="Friend_ID")]
        internal uint m_friendID;
        [Index(Name="Owner_ID")]
        internal uint m_ownerID;
        [DataElement(Name="Type")]
        internal FRIENDTYPE m_type;

        public uint Friend_ID
        {
            get
            {
                return this.m_friendID;
            }
            set
            {
                base.Assign<uint>(ref this.m_friendID, value);
            }
        }

        public FRIENDTYPE FriendType
        {
            get
            {
                return this.m_type;
            }
            set
            {
                base.Dirty = true;
                this.m_type = value;
            }
        }

        public uint Owner_ID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }
    }
}

