//
namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="Creature")]
    public class DBCreature : DBBase
    {
        [DataElement(Name="AttackTime")]
        internal int m_attacktime = 2000;
        [DataElement(Name="AttackTime1")]
        internal int m_attacktime1 = 2000;
        [DataElement(Name="CreatureFamily")]
        internal sbyte m_creatureFamily;
        [DataElement(Name="CreatureType")]
        internal sbyte m_creatureType;
//        [DataElement(Name="Default")]
//        internal SpawnTemplate m_defaults = new SpawnTemplate(true);
        [DataElement(Name="MinLevel")]
        internal short m_minlevel;
        [DataElement(Name="MaxLevel")]
        internal short m_maxlevel;
        [DataElement(Name="Faction")]
        internal FACTION m_faction;
        [DataElement(Name="Flags")]
        internal int m_flags;
        [DataElement(Name="NpcFlags")]
        internal uint m_npcflags;
        [DataElement(Name="BehaivorID")]
        internal sbyte m_behaivorId;
        [DataElement(Name="SpellGroupID")]
        internal uint m_spellgroupId;
        [DataElement(Name="TradeGroupID")]
        internal uint m_tradegroupId;
        [DataElement(Name="TrainGroupID")]
        internal uint m_traingroupId;
        [DataElement(Name="LootGroupID")]
        internal uint m_lootgroupId;
        [DataElement(Name="VItemDisplay", ArraySize=3)]
        internal int[] m_vitemdisplay;
        [DataElement(Name="VItemInfo", ArraySize=3)]
        internal ulong[] m_viteminfo;
        [DataElement(Name="DisplayID")]
        internal int m_displayID;
        [DataElement(Name="Elite")]
        internal sbyte m_elite;
//        [DataElement(Name="HealthPerLevel")]
//        internal float m_hpl = 1.7f;
        [DataElement(Name="MinHealth")]
        internal int m_minhealth;
        [DataElement(Name="MaxHealth")]
        internal int m_maxhealth;
        [DataElement(Name="CombatReach")]
        internal float m_maxRange = 3f;
        [DataElement(Name="Bounding")]
        internal float m_minRange = 1f;
        [DataElement(Name="MountDisplayID")]
        internal int m_mountdisplayID;
        [DataElement(Name="Name")]
        internal string m_name = "Monster";
        [DataElement(Name="Name1")]
        internal string m_name1 = string.Empty;
        [DataElement(Name="Name2")]
        internal string m_name2 = string.Empty;
        [DataElement(Name="Name3")]
        internal string m_name3 = string.Empty;
        [DataElement(Name="Named")]
        internal bool m_named;
//        [DataElement(Name="PowerPerLevel")]
//        internal float m_ppl = 1.7f;
        [DataElement(Name="MinPower")]
        internal int m_minpower;
        [DataElement(Name="MaxPower")]
        internal int m_maxpower;
        [DataElement(Name="Resistance")]
        internal RunWoW.DB.DataTables.Resistance m_resist = new RunWoW.DB.DataTables.Resistance(true);
        [DataElement(Name="RunningSpeed")]
        internal float m_runSpeed = 5f;
        [DataElement(Name="Scale")]
        internal float m_scale = 1f;
        private int m_spawns;
        [DataElement(Name="Title")]
        internal string m_title = string.Empty;
        [DataElement(Name="WalkSpeed")]
        internal float m_walkSpeed = 2.5f;

        public int AttackTime
        {
            get
            {
                return this.m_attacktime;
            }
            set
            {
                base.Assign<int>(ref this.m_attacktime, value);
            }
        }

        public int AttackTime1
        {
            get
            {
                return this.m_attacktime1;
            }
            set
            {
                base.Assign<int>(ref this.m_attacktime1, value);
            }
        }

        public sbyte CreatureFamily
        {
            get
            {
                return this.m_creatureFamily;
            }
            set
            {
                base.Assign<sbyte>(ref this.m_creatureFamily, value);
            }
        }

        public sbyte CreatureType
        {
            get
            {
                return this.m_creatureType;
            }
            set
            {
                base.Assign<sbyte>(ref this.m_creatureType, value);
            }
        }
/*
        public SpawnTemplate Defaults
        {
            get
            {
                return this.m_defaults;
            }
            set
            {
                this.m_defaults = value;
                base.Dirty = true;
            }
        }
*/

        public short MinLevel
        {
            get
            {
                return this.m_minlevel;
            }
            set
            {
                base.Assign<short>(ref this.m_minlevel, value);
                Dirty = true;
            }
        }

        public short MaxLevel
        {
            get
            {
                return this.m_maxlevel;
            }
            set
            {
                base.Assign<short>(ref this.m_maxlevel, value);
                Dirty = true;
            }
        }

        public FACTION Faction
        {
            get
            {
                return this.m_faction;
            }
            set
            {
                base.Assign<FACTION>(ref this.m_faction, value);
                Dirty = true;
            }
        }

        public int Flags
        {
            get
            {
                return this.m_flags;
            }
            set
            {
                base.Assign<int>(ref this.m_flags, value);
                Dirty = true;
            }
        }

        public uint NpcFlags
        {
            get
            {
                return this.m_npcflags;
            }
            set
            {
                base.Assign<uint>(ref this.m_npcflags, value);
                Dirty = true;
            }
        }

        public sbyte BehaivorId
        {
            get
            {
                return this.m_behaivorId;
            }
            set
            {
                base.Assign<sbyte>(ref this.m_behaivorId, value);
                Dirty = true;
            }
        }

        public uint SpellGroupId
        {
            get
            {
                return this.m_spellgroupId;
            }
            set
            {
                base.Assign<uint>(ref this.m_spellgroupId, value);
                Dirty = true;
            }
        }

        public uint TradeGroupId
        {
            get
            {
                return this.m_tradegroupId;
            }
            set
            {
                base.Assign<uint>(ref this.m_tradegroupId, value);
                Dirty = true;
            }
        }

        public uint TrainGroupId
        {
            get
            {
                return this.m_traingroupId;
            }
            set
            {
                base.Assign<uint>(ref this.m_traingroupId, value);
                Dirty = true;
            }
        }

        public uint LootGroupId
        {
            get
            {
                return this.m_lootgroupId;
            }
            set
            {
                base.Assign<uint>(ref this.m_lootgroupId, value);
                Dirty = true;
            }
        }

        public int[] VItemDisplay
        {
            get
            {
                return this.m_vitemdisplay;
            }
        }

        public ulong[] VItemInfo
        {
            get
            {
                return this.m_viteminfo;
            }
        }

        public int DisplayID
        {
            get
            {
                return this.m_displayID;
            }
            set
            {
                base.Assign<int>(ref this.m_displayID, value);
            }
        }

        public sbyte Elite
        {
            get
            {
                return this.m_elite;
            }
            set
            {
                base.Assign<sbyte>(ref this.m_elite, value);
            }
        }

        public uint Entry
        {
            get
            {
                return base.ObjectId;
            }
        }
/*
        public float HealthPerLevel
        {
            get
            {
                return this.m_hpl;
            }
            set
            {
                base.Assign<float>(ref this.m_hpl, value);
            }
        }
*/

        public int MinHealth
        {
            get
            {
                return this.m_minhealth;
            }
            set
            {
                base.Assign<int>(ref this.m_minhealth, value);
            }
        }

        public int MaxHealth
        {
            get
            {
                return this.m_maxhealth;
            }
            set
            {
                base.Assign<int>(ref this.m_maxhealth, value);
            }
        }

        public float MaxRange
        {
            get
            {
                return this.m_maxRange;
            }
            set
            {
                base.Assign<float>(ref this.m_maxRange, value);
            }
        }

        public float MinRange
        {
            get
            {
                return this.m_minRange;
            }
            set
            {
                base.Assign<float>(ref this.m_minRange, value);
            }
        }

        public int MountDisplayID
        {
            get
            {
                return this.m_mountdisplayID;
            }
            set
            {
                base.Assign<int>(ref this.m_mountdisplayID, value);
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Assign(ref this.m_name, value);
            }
        }

        public string Name1
        {
            get
            {
                return this.m_name1;
            }
            set
            {
                base.Assign(ref this.m_name1, value);
            }
        }

        public string Name2
        {
            get
            {
                return this.m_name2;
            }
            set
            {
                base.Assign(ref this.m_name2, value);
            }
        }

        public string Name3
        {
            get
            {
                return this.m_name3;
            }
            set
            {
                base.Assign(ref this.m_name3, value);
            }
        }

        public bool Named
        {
            get
            {
                return this.m_named;
            }
            set
            {
                base.Assign<bool>(ref this.m_named, value);
            }
        }
/*
        public float PowerPerLevel
        {
            get
            {
                return this.m_ppl;
            }
            set
            {
                base.Assign<float>(ref this.m_ppl, value);
            }
        }
*/

        public int MinPower
        {
            get
            {
                return this.m_minpower;
            }
            set
            {
                base.Assign<int>(ref this.m_minpower, value);
            }
        }

        public int MaxPower
        {
            get
            {
                return this.m_maxpower;
            }
            set
            {
                base.Assign<int>(ref this.m_maxpower, value);
            }
        }

        public RunWoW.DB.DataTables.Resistance Resistance
        {
            get
            {
                return this.m_resist;
            }
        }

        public float RunningSpeed
        {
            get
            {
                return this.m_runSpeed;
            }
            set
            {
                base.Assign<float>(ref this.m_runSpeed, value);
            }
        }

        public float Scale
        {
            get
            {
                return this.m_scale;
            }
            set
            {
                base.Assign<float>(ref this.m_scale, value);
            }
        }

        public int Spawns
        {
            get
            {
                return this.m_spawns;
            }
            set
            {
                this.m_spawns = value;
            }
        }

        public string Title
        {
            get
            {
                return this.m_title;
            }
            set
            {
                base.Assign(ref this.m_title, value);
            }
        }

        public float WalkSpeed
        {
            get
            {
                return this.m_walkSpeed;
            }
            set
            {
                base.Assign<float>(ref this.m_walkSpeed, value);
            }
        }
    }
}

