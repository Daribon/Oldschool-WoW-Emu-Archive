﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Mail")]
    public class DBMail : DBBase
    {
        [DataElement(Name="COD")]
        public int m_cod;
        [DataElement(Name="ExpirationTime")]
        public DateTime m_expirationTime;
        [DataElement(Name="ItemID")]
        public int m_item;
        [DataElement(Name="MailType")]
        public int m_mailType;
        [DataElement(Name="MessageID")]
        public uint m_messageID;
        [DataElement(Name="Money")]
        public int m_money;
        [Index(Name="OwnerID")]
        public uint m_ownerID;
        [DataElement(Name="HasRead")]
        public int m_read;
        [DataElement(Name="SenderID")]
        public uint m_senderID;
        [DataElement(Name="Subject")]
        public string m_subject = string.Empty;
        [DataElement(Name="DispatchTime")]
        public DateTime m_time;

        public int COD
        {
            get
            {
                return this.m_cod;
            }
            set
            {
                base.Assign<int>(ref this.m_cod, value);
            }
        }

        public DateTime ExpirationTime
        {
            get
            {
                return this.m_expirationTime;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_expirationTime, value);
            }
        }

        public bool HasRead
        {
            get
            {
                return (this.m_read > 0);
            }
            set
            {
                base.Assign<int>(ref this.m_read, value ? 1 : 0);
            }
        }

        public int Item
        {
            get
            {
                return this.m_item;
            }
            set
            {
                base.Assign<int>(ref this.m_item, value);
            }
        }

        public int MailType
        {
            get
            {
                return this.m_mailType;
            }
            set
            {
                base.Assign<int>(ref this.m_mailType, value);
            }
        }

        public uint MessageID
        {
            get
            {
                return this.m_messageID;
            }
            set
            {
                base.Assign<uint>(ref this.m_messageID, value);
            }
        }

        public int Money
        {
            get
            {
                return this.m_money;
            }
            set
            {
                base.Assign<int>(ref this.m_money, value);
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerID;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerID, value);
            }
        }

        public int ReadStatus
        {
            get
            {
                return this.m_read;
            }
            set
            {
                base.Assign<int>(ref this.m_read, value);
            }
        }

        public uint SenderID
        {
            get
            {
                return this.m_senderID;
            }
            set
            {
                base.Assign<uint>(ref this.m_senderID, value);
            }
        }

        public string Subject
        {
            get
            {
                return this.m_subject;
            }
            set
            {
                base.Assign(ref this.m_subject, value);
            }
        }

        public DateTime Time
        {
            get
            {
                return this.m_time;
            }
            set
            {
                base.Assign<DateTime>(ref this.m_time, value);
            }
        }
    }
}

