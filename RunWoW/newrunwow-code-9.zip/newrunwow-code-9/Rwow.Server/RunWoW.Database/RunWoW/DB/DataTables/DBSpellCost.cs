﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="SpellCost")]
    public class DBSpellCost : DBBase
    {
        [DataElement(Name="Cost")]
        internal int m_cost;
        [Index(Name="Spell_ID", AllowDbNull=false)]
        internal uint m_spellID;

        public int Cost
        {
            get
            {
                return this.m_cost;
            }
            set
            {
                base.Assign<int>(ref this.m_cost, value);
            }
        }

        public uint SpellID
        {
            get
            {
                return this.m_spellID;
            }
            set
            {
                base.Assign<uint>(ref this.m_spellID, value);
            }
        }
    }
}

