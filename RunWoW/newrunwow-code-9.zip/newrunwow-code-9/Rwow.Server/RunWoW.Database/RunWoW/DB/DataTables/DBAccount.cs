//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;

    [DataTable(TableName="Account")]
    public class DBAccount : DBBase
    {
        [Relation(LocalField="ObjectId", RemoteField="AccountID", AutoLoad=false, AutoSave=false, AutoDelete=true)]
        public PooledList<DBCharacter> Characters;
        [DataElement(Name="AccessLvl")]
        internal ACCESSLEVEL m_accesslvl = ACCESSLEVEL.NORMAL;
        [DataElement(Name="CreationDate")]
        internal DateTime m_creationDate = CustomDateTime.Now;
        [DataElement(Name="LastAccess")]
        internal DateTime m_lastacess = CustomDateTime.Now;
        [DataElement(Name="LastIP")]
        internal string m_lastip = "0.0.0.0";
        [Index(Name="Name", Unique=true)]
        internal string m_name;
        [DataElement(Name="Password")]
        internal string m_password;
        [DataElement(Name="SessionKey", ArraySize=0)]
        internal byte[] m_skey;

        public ACCESSLEVEL AccessLvl
        {
            get
            {
                return this.m_accesslvl;
            }
            set
            {
                base.Dirty = true;
                this.m_accesslvl = value;
            }
        }

        public DateTime CreationDate
        {
            get
            {
                return this.m_creationDate;
            }
            set
            {
                base.Dirty = true;
                this.m_creationDate = value;
            }
        }

        public DateTime LastAcess
        {
            get
            {
                return this.m_lastacess;
            }
            set
            {
                base.Dirty = true;
                this.m_creationDate = value;
            }
        }

        public string LastIP
        {
            get
            {
                return this.m_lastip;
            }
            set
            {
                base.Dirty = true;
                this.m_lastip = value;
            }
        }

        public string Name
        {
            get
            {
                return this.m_name;
            }
            set
            {
                base.Dirty = true;
                this.m_name = value;
            }
        }

        public string Password
        {
            get
            {
                return this.m_password;
            }
            set
            {
                base.Dirty = true;
                this.m_password = value;
            }
        }

        public byte[] SessionKey
        {
            get
            {
                return this.m_skey;
            }
            set
            {
                base.Dirty = true;
                this.m_skey = value;
            }
        }
    }
}

