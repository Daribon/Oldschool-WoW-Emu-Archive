﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="GameObject")]
    public class DBGameObject : DBBase
    {
        [Relation(LocalField="GOQuestID", RemoteField="EndGroup", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBQuest> EndQuests;
        public static uint GOQuestShift = 0xc350;
        [Relation(LocalField="LootGroupID", RemoteField="LootGroupID", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBGOLoot> Loot;
        private bool m_active;
        [DataElement(Name="Facing")]
        internal float m_facing;
        [DataElement(Name="Faction")]
        internal FACTION m_faction;
        [DataElement(Name="Flags")]
        internal uint m_flags;
        [DataElement(Name="Level")]
        internal int m_level;
        [DataElement(Name="LootGroupID")]
        internal uint m_lootid;
        [DataElement(Name="Position")]
        internal DBVector m_pos = new DBVector();
        [DataElement(Name="QuestGroupID")]
        internal uint m_questId;
        [DataElement(Name="Rotation", ArraySize=4)]
        internal float[] m_rotation = new float[4];
        [DataElement(Name="State")]
        internal int m_state;
        [DataElement(Name="TemplateID")]
        internal uint m_templateid;
        [Index(Name="WorldMapID")]
        internal uint m_worldMapID;
        [Relation(LocalField="GOQuestID", RemoteField="StartGroup", AutoLoad=false, AutoDelete=false, AutoSave=false)]
        public PooledList<DBQuest> StartQuests;
        [Relation(LocalField="TemplateID", RemoteField="GOTemplate_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBGOTemplate Template;

        public bool Active
        {
            get
            {
                return this.m_active;
            }
            set
            {
                this.m_active = value;
            }
        }

        public float Facing
        {
            get
            {
                return this.m_facing;
            }
            set
            {
                base.Assign<float>(ref this.m_facing, value);
            }
        }

        public FACTION Faction
        {
            get
            {
                return this.m_faction;
            }
            set
            {
                base.Assign<FACTION>(ref this.m_faction, value);
            }
        }

        public uint Flags
        {
            get
            {
                return this.m_flags;
            }
            set
            {
                base.Assign<uint>(ref this.m_flags, value);
            }
        }

        public uint GOQuestID
        {
            get
            {
                if (this.m_questId != 0)
                {
                    return (this.m_questId + GOQuestShift);
                }
                return 0;
            }
        }

        public int Level
        {
            get
            {
                return this.m_level;
            }
            set
            {
                base.Assign<int>(ref this.m_level, value);
            }
        }

        public uint LootGroupID
        {
            get
            {
                return this.m_lootid;
            }
            set
            {
                base.Assign<uint>(ref this.m_lootid, value);
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_pos.Vector;
            }
            set
            {
                this.m_pos.Vector = value;
            }
        }

        public uint QuestID
        {
            get
            {
                return this.m_questId;
            }
            set
            {
                base.Assign<uint>(ref this.m_questId, value);
            }
        }

        public float[] Rotation
        {
            get
            {
                return this.m_rotation;
            }
            set
            {
                base.Dirty = true;
                this.m_rotation = value;
            }
        }

        public int State
        {
            get
            {
                return this.m_state;
            }
            set
            {
                base.Assign<int>(ref this.m_state, value);
            }
        }

        public uint TemplateID
        {
            get
            {
                return this.m_templateid;
            }
            set
            {
                base.Assign<uint>(ref this.m_templateid, value);
            }
        }

        public uint WorldMapID
        {
            get
            {
                return this.m_worldMapID;
            }
            set
            {
                base.Assign<uint>(ref this.m_worldMapID, value);
            }
        }
    }
}

