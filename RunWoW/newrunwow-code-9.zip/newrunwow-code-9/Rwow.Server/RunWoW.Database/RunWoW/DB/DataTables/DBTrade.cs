﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="Trade")]
    public class DBTrade : DBBase
    {
        [DataElement(Name="Count")]
        internal short m_count;
        [Index(Name="TradeGroupID")]
        internal uint m_group;
        [DataElement(Name="Quantity")]
        internal short m_quantity;
        [DataElement(Name="RandomID")]
        internal int m_randomId;
        [DataElement(Name="TradeTargetID")]
        internal ushort m_target;
        [Relation(LocalField="TargetID", RemoteField="ItemTemplate_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBItemTemplate Target;

        public short Count
        {
            get
            {
                return this.m_count;
            }
            set
            {
                base.Assign<short>(ref this.m_count, value);
            }
        }

        public uint GroupID
        {
            get
            {
                return this.m_group;
            }
            set
            {
                base.Assign<uint>(ref this.m_group, value);
            }
        }

        public short Quantity
        {
            get
            {
                return this.m_quantity;
            }
            set
            {
                base.Assign<short>(ref this.m_quantity, value);
            }
        }

        public int RandomID
        {
            get
            {
                return this.m_randomId;
            }
            set
            {
                base.Assign<int>(ref this.m_randomId, value);
            }
        }

        public ushort TargetID
        {
            get
            {
                return this.m_target;
            }
            set
            {
                base.Assign<ushort>(ref this.m_target, value);
            }
        }
    }
}

