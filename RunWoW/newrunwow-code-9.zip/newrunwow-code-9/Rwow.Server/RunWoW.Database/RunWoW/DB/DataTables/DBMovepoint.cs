//
namespace RunWoW.DB.DataTables
{
    using RunServer.Common;
    using RunServer.Database.Attributes;
    using RunWoW.DB;
    using System;

    [DataTable(TableName="Movepoint")]
    public class DBMovepoint : DBBase
    {
        [DataElement(Name="Number")]
        internal byte m_num;
        [Index(Name="OwnerID")]
        internal uint m_ownerid;
        [DataElement(Name="Position")]
        internal DBVector m_pos = new DBVector();

        public byte Number
        {
            get
            {
                return this.m_num;
            }
            set
            {
                base.Assign<byte>(ref this.m_num, value);
            }
        }

        public uint OwnerID
        {
            get
            {
                return this.m_ownerid;
            }
            set
            {
                base.Assign<uint>(ref this.m_ownerid, value);
            }
        }

        public Vector Position
        {
            get
            {
                return this.m_pos.Vector;
            }
            set
            {
                this.m_pos.Vector = value;
            }
        }
    }
}

