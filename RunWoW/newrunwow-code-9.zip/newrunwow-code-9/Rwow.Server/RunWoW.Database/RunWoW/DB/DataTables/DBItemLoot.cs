﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using System;

    [DataTable(TableName="ItemLoot")]
    public class DBItemLoot : DBBase
    {
        [DataElement(Name="Category")]
        internal LootCategory m_cat;
        [Index(Name="LootGroupID")]
        internal uint m_group;
        [DataElement(Name="Percentage")]
        internal float m_percent;
        [DataElement(Name="LootTargetID")]
        internal ushort m_target;
        [Relation(LocalField="TargetID", RemoteField="ItemTemplate_ID", AutoLoad=true, AutoDelete=false, AutoSave=false)]
        public DBItemTemplate Target;

        public LootCategory Category
        {
            get
            {
                return this.m_cat;
            }
            set
            {
                base.Dirty = true;
                this.m_cat = value;
            }
        }

        public uint GroupID
        {
            get
            {
                return this.m_group;
            }
            set
            {
                base.Assign<uint>(ref this.m_group, value);
            }
        }

        public float Percentage
        {
            get
            {
                return this.m_percent;
            }
            set
            {
                base.Assign<float>(ref this.m_percent, value);
            }
        }

        public ushort TargetID
        {
            get
            {
                return this.m_target;
            }
            set
            {
                base.Assign<ushort>(ref this.m_target, value);
            }
        }
    }
}

