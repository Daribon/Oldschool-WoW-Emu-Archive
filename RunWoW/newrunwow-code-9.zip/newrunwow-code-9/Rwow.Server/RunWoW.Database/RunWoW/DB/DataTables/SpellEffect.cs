﻿namespace RunWoW.DB.DataTables
{
    using RunServer.Database.Attributes;
    using RunWoW.Common;
    using System;
    using System.Runtime.InteropServices;

    [StructLayout(LayoutKind.Sequential)]
    public struct SpellEffect
    {
        [DataElement]
        public SPELLEFFECT Type;
        [DataElement]
        public int RandomDamage;
        [DataElement]
        public int Speed;
        [DataElement]
        public int Damage;
        [DataElement]
        public float Radius;
        [DataElement]
        public AURAEFFECT Aura;
        [DataElement]
        public int AuraPeriod;
        [DataElement]
        public uint Category;
        [DataElement]
        public int AuraParam;
        [DataElement]
        public float Percent;
        [DataElement]
        public int NumTargets;
        [DataElement]
        public int Spell;
        [DataElement]
        public float Combo;
        [DataElement(Name="ImplicitTargetA")]
        public byte TargetA;
        [DataElement(Name="ImplicitTargetB")]
        public byte TargetB;
        public int Value
        {
            get
            {
                return (this.Damage + this.RandomDamage);
            }
        }
    }
}

