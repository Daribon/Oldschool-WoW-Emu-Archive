// Assembly RunUO, Version 1.0.0.0

[assembly: System.Reflection.AssemblyKeyFile("")]
[assembly: System.Reflection.AssemblyKeyName("")]
[assembly: System.Reflection.AssemblyDelaySign(false)]
[assembly: System.Reflection.AssemblyCompany("RunUO Software Team")]
[assembly: System.Reflection.AssemblyTitle("RunUO Server")]
[assembly: System.Reflection.AssemblyProduct("RunUO")]
[assembly: System.Reflection.AssemblyCopyright("RunUO Software Team")]
[assembly: System.Reflection.AssemblyConfiguration("")]
[assembly: System.Reflection.AssemblyDescription("Ultima Online Server Software")]
[assembly: System.Reflection.AssemblyTrademark("RunUO Software Team")]
[assembly: System.Security.Permissions.SecurityPermission(SecurityAction.RequestMinimum, SkipVerification=true)]
// Module RunUO.exe

[module: System.Security.UnverifiableCode]
// Assembly Reference mscorlib
// Assembly Reference System
// Assembly Reference System.Xml
// Module Reference Kernel32

