namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void VirtueGumpRequestEventHandler(VirtueGumpRequestEventArgs e);

}

