namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool AllowBeneficialHandler(Mobile from, Mobile target);

}

