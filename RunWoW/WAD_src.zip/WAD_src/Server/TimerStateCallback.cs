namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void TimerStateCallback(object state);

}

