namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void CrashedEventHandler(CrashedEventArgs e);

}

