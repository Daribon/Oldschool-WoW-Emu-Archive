namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void CastSpellRequestEventHandler(CastSpellRequestEventArgs e);

}

