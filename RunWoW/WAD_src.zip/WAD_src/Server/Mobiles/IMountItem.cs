namespace Server.Mobiles
{
    public interface IMountItem
    {
        // Properties
        IMount Mount { get; }

    }
}

