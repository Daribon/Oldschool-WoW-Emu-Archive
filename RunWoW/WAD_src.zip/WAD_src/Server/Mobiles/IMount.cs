namespace Server.Mobiles
{
    using Server;
    using System;

    public interface IMount
    {
        // Properties
        Mobile Rider { get; set; }

    }
}

