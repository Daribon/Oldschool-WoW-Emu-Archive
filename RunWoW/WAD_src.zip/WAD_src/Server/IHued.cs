namespace Server
{
    using System;

    public interface IHued
    {
        // Properties
        int HuedItemID { get; }

    }
}

