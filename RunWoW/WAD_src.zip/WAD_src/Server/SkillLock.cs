namespace Server
{
    using System;

    public enum SkillLock
    {
        // Fields
        Down = 1,
        Locked = 2,
        Up = 0
    }
}

