namespace Server
{
    using System;

    public enum BodyType
    {
        // Fields
        Animal = 3,
        Empty = 0,
        Equipment = 5,
        Human = 4,
        Monster = 1,
        Sea = 2
    }
}

