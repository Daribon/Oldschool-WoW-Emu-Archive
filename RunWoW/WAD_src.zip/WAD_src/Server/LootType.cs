namespace Server
{
    using System;

    public enum LootType
    {
        // Fields
        Blessed = 2,
        Cursed = 3,
        Newbied = 1,
        Regular = 0
    }
}

