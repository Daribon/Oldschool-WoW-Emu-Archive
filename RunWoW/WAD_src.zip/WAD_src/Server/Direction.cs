System.NullReferenceException: Object reference not set to an instance of an object.
   at _129._1(String , String )
   at _129.VisitArrayCreateExpression(IArrayCreateExpression expression)
   at _119.VisitExpression(IExpression expression)
   at _129._1(IExpression , IType )
   at _129.VisitCustomAttribute(ICustomAttribute customAttribute)
   at _128.VisitCustomAttributeCollection(ICustomAttributeCollection attributes)
   at _128.VisitTypeDeclaration(ITypeDeclaration typeDeclaration)
   at _133.VisitTypeDeclaration(ITypeDeclaration typeDeclaration)
   at _131.VisitTypeDeclaration(ITypeDeclaration typeDeclaration)
   at Reflector.FileDisassembler.FileDisassemblerWindow.WriteTypeDeclaration(ITypeDeclaration typeDeclaration, ILanguageConfiguration configuration)
namespace Server
{
}

