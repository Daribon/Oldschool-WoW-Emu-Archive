namespace Server
{
    using System;

    public enum ParticleSupportType
    {
        // Fields
        Detect = 1,
        Full = 0,
        None = 2
    }
}

