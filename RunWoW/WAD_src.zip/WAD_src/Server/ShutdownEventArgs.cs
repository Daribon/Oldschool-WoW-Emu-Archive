namespace Server
{
    using System;

    public class ShutdownEventArgs : EventArgs
    {
        // Methods
        public ShutdownEventArgs()
        {
        }

    }
}

