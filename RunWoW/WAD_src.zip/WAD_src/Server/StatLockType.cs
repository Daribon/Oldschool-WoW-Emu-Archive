namespace Server
{
    using System;

    public enum StatLockType
    {
        // Fields
        Down = 1,
        Locked = 2,
        Up = 0
    }
}

