namespace Server
{
    using System;

    public interface IArmor
    {
        // Properties
        double ArmorRating { get; }

    }
}

