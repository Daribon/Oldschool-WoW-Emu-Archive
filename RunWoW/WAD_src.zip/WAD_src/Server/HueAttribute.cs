namespace Server
{
    using System;

    [AttributeUsage(AttributeTargets.Property)]
    public class HueAttribute : Attribute
    {
        // Methods
        public HueAttribute()
        {
        }

    }
}

