namespace Server
{
    using System;

    public enum ResistanceType
    {
        // Fields
        Cold = 2,
        Energy = 4,
        Fire = 1,
        Physical = 0,
        Poison = 3
    }
}

