namespace Server
{
    using System;

    public enum DeathMoveResult
    {
        // Fields
        MoveToBackpack = 2,
        MoveToCorpse = 0,
        RemainEquiped = 1
    }
}

