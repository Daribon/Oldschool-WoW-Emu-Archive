namespace Server
{
    using Server.Guilds;
    using System;
    using System.Runtime.CompilerServices;

    public delegate BaseGuild CreateGuildHandler(CreateGuildEventArgs e);

}

