namespace Server.Guilds
{
    using System;

    public enum GuildType
    {
        // Fields
        Chaos = 1,
        Order = 2,
        Regular = 0
    }
}

