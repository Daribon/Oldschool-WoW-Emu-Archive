namespace Server.Gumps
{
    using System;

    public enum GumpButtonType
    {
        // Fields
        Page = 0,
        Reply = 1
    }
}

