namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void ChangeProfileRequestEventHandler(ChangeProfileRequestEventArgs e);

}

