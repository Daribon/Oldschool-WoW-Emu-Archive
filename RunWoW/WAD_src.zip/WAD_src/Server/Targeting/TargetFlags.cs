namespace Server.Targeting
{
    using System;

    public enum TargetFlags
    {
        // Fields
        Beneficial = 2,
        Harmful = 1,
        None = 0
    }
}

