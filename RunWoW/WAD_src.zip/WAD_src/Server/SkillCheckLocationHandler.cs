namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool SkillCheckLocationHandler(Mobile from, SkillName skill, double minSkill, double maxSkill);

}

