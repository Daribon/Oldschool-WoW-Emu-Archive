namespace Server.Items
{
    using Server;
    using System;
    using System.Runtime.CompilerServices;

    public delegate int CheckItemGroup(Item a, Item b);

}

