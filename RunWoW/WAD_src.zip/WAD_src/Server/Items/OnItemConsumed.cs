namespace Server.Items
{
    using Server;
    using System;
    using System.Runtime.CompilerServices;

    public delegate void OnItemConsumed(Item item, int amount);

}

