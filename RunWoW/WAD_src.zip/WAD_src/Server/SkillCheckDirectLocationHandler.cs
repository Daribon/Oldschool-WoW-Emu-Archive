namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool SkillCheckDirectLocationHandler(Mobile from, SkillName skill, double chance);

}

