namespace Server
{
    using System;

    public interface IPoint2D
    {
        // Properties
        int X { get; }

        int Y { get; }

    }
}

