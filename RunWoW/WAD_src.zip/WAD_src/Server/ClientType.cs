namespace Server
{
    using System;

    public enum ClientType
    {
        // Fields
        God = 2,
        Regular = 0,
        UOTD = 1
    }
}

