namespace Server
{
    using System;

    public interface ICarvable
    {
        // Methods
        void Carve(Mobile from, Item item);

    }
}

