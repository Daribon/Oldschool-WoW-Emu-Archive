namespace Server
{
    using System;

    public enum VisibleDamageType
    {
        // Fields
        Everyone = 2,
        None = 0,
        Related = 1
    }
}

