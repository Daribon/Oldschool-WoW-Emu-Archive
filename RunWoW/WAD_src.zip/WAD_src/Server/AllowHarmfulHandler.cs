namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool AllowHarmfulHandler(Mobile from, Mobile target);

}

