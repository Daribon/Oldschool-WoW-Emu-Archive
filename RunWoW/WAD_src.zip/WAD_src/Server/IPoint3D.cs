namespace Server
{
    using System;

    public interface IPoint3D : IPoint2D
    {
        // Properties
        int Z { get; }

    }
}

