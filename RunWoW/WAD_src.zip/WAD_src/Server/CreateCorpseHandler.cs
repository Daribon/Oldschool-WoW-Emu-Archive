namespace Server
{
    using Server.Items;
    using System;
    using System.Collections;
    using System.Runtime.CompilerServices;

    public delegate Container CreateCorpseHandler(Mobile from, ArrayList initialContent, ArrayList equipedItems);

}

