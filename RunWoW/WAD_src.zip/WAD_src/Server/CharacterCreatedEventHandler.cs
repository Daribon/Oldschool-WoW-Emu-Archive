namespace Server
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate void CharacterCreatedEventHandler(CharacterCreatedEventArgs e);

}

