namespace Server
{
    using System;

    public enum AccessLevel
    {
        // Fields
        Administrator = 4,
        Counselor = 1,
        GameMaster = 2,
        Player = 0,
        Seer = 3
    }
}

