namespace Server.Network
{
    using System;

    public enum EffectType
    {
        // Fields
        FixedFrom = 3,
        FixedXYZ = 2,
        Lightning = 1,
        Moving = 0
    }
}

