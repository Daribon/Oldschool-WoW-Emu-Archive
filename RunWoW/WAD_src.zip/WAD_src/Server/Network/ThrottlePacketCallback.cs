namespace Server.Network
{
    using System;
    using System.Runtime.CompilerServices;

    public delegate bool ThrottlePacketCallback(NetState state);

}

