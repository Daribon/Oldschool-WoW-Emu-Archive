namespace Server.Network
{
    using System;

    public enum CMEFlags
    {
        // Fields
        Colored = 32,
        Disabled = 1,
        None = 0
    }
}

