namespace Server.Network
{
    using System;

    public enum AffixType
    {
        // Fields
        Append = 0,
        Prepend = 1,
        System = 2
    }
}

