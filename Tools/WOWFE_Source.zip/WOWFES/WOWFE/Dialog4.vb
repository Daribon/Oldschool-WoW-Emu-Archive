Imports System.Windows.Forms
Imports System.IO
Public Class Dialog4

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Dim ping1checked As String
        Dim ping2checked As String
        Dim combine As String = "0"
        Dim closeaction As String = "2"
        Dim checkver As String

        If (CheckBox1.Checked = False) Then
            ping1checked = "0"
        Else
            ping1checked = "1"
        End If
        If (CheckBox2.Checked = False) Then
            ping2checked = "0"
        Else
            ping2checked = "1"
        End If

        If (RadioButton4.Checked = True) Then
            combine = "0"
        End If
        If (RadioButton5.Checked = True) Then
            combine = "1"
        End If
        If (RadioButton6.Checked = True) Then
            combine = "2"
        End If

        If (RadioButton1.Checked = True) Then
            closeaction = "1"
        End If
        If (RadioButton2.Checked = True) Then
            closeaction = "2"
        End If
        If (RadioButton3.Checked = True) Then
            closeaction = "3"
        End If


        If (CheckBox3.Checked = False) Then
            checkver = "0"
        Else
            checkver = "1"
        End If

        File.WriteAllText(Application.StartupPath + "\settings.cfg", ComboBox1.Text + "|" + ping1checked + "|" + ping2checked + "|" + combine + "|" + closeaction + "|" + TextBox1.Text + "|" + checkver)
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub ComboBox1_TextChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.TextChanged
        If (ComboBox1.Text.LastIndexOf("\") < ComboBox1.Text.Length - 1) Then
            ComboBox1.Text = ComboBox1.Text + "\"
        Else
        End If

        Try
            If (System.IO.File.Exists(ComboBox1.Text + "WoW.exe") = True) Then
                TextBox1.Text = System.Diagnostics.FileVersionInfo.GetVersionInfo(ComboBox1.Text + "WoW.exe").FileVersion.Replace(", ", ".")
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Form1.FolderBrowserDialog1.SelectedPath = ComboBox1.Text
        Form1.FolderBrowserDialog1.ShowDialog()
        ComboBox1.Text = Form1.FolderBrowserDialog1.SelectedPath

        Try
            If (System.IO.File.Exists(ComboBox1.Text + "WoW.exe") = True) Then
                TextBox1.Text = System.Diagnostics.FileVersionInfo.GetVersionInfo(ComboBox1.Text + "WoW.exe").FileVersion.Replace(", ", ".")
            End If

        Catch ex As Exception
        End Try
    End Sub

    Private Sub Dialog4_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Try
            If (System.IO.File.Exists(ComboBox1.Text + "WoW.exe") = True) Then
                TextBox1.Text = System.Diagnostics.FileVersionInfo.GetVersionInfo(ComboBox1.Text + "WoW.exe").FileVersion.Replace(", ", ".")
            End If

        Catch ex As Exception
        End Try
    End Sub
End Class
