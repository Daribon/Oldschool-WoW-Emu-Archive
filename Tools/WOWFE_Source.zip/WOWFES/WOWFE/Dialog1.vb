Imports System.Windows.Forms
Imports System.IO
Imports System.Net.NetworkInformation

Public Class Dialog1

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Form1.servername.Items.Add(TextBox1.Text)
        Form1.ListBox1.Items.Add(TextBox3.Text)
        Form1.ListBox2.Items.Add(TextBox2.Text)
        Form1.regurl.Items.Add(TextBox4.Text)
        Form1.homeurl.Items.Add(TextBox5.Text)
        If (Dialog4.CheckBox2.Checked = True) Then
            Try
                Form1.ListBox3.Items.Add(Form1.ping(TextBox3.Text))
            Catch ex As Exception
                Form1.ListBox3.Items.Add("0")
            End Try
        Else
            Form1.ListBox3.Items.Add("0")
        End If
        If (File.Exists(Application.StartupPath + "\servers.txt") = False) Then
            File.WriteAllText(Application.StartupPath + "\servers.txt", TextBox1.Text + "|" + TextBox2.Text + "|" + TextBox3.Text + "|" + TextBox4.Text + "|" + TextBox5.Text)
        Else
            File.AppendAllText(Application.StartupPath + "\servers.txt", vbCrLf + TextBox1.Text + "|" + TextBox2.Text + "|" + TextBox3.Text + "|" + TextBox4.Text + "|" + TextBox5.Text)
        End If
        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

End Class
