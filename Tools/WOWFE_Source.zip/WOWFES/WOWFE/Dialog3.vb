Imports System.Windows.Forms
Imports System.IO
Imports System.Net.NetworkInformation

Public Class Dialog3
    Dim current As Integer = -1
    Dim href0 As String

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        WebBrowser1.Navigate(ComboBox1.Text)
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Public Function doping(ByVal ip As String)
        Try
            Form1.ListBox3.Items.Add(Form1.ping(ip))
        Catch ex As Exception
            Form1.ListBox3.Items.Add("0")
        End Try
    End Function

    Public Function importurl()
        Dim HtmlElement As HtmlElement

        For Each HtmlElement In WebBrowser1.Document.GetElementsByTagName("A")
            Dim href As String = Unescape(HtmlElement.GetAttribute("href").ToString)
            Dim href2 As String


            If (href.StartsWith("wow:") = True) Then
                href2 = HtmlElement.GetAttribute("href").ToString.Replace("wow:", "").Replace("/", "")
                If (Dialog4.RadioButton6.Checked = True) Then
                    If (WebBrowser1.DocumentText.Contains("wowadd:") = True) Then
                        href = ""
                        href2 = ""
                    End If
                End If
            ElseIf (href.StartsWith("wowadd:") = True) Then
                href2 = HtmlElement.GetAttribute("href").ToString.Replace("wowadd://", "").Replace("wowadd:/", "").Replace("wowadd:", "")
                If (Dialog4.RadioButton5.Checked = True) Then
                    If (WebBrowser1.DocumentText.Contains("wow:") = True) Then
                        href = ""
                        href2 = ""
                    End If
                End If
            End If
            If (href.ToString.Contains("wow:") = True) Then
                Form1.servername.Items.Add("0")
                Form1.ListBox1.Items.Add(href2)
                Form1.ListBox2.Items.Add("0")
                Form1.regurl.Items.Add("0")
                Form1.homeurl.Items.Add("0")
                If (CheckBox1.Checked = True) Then
                    doping(href2)
                Else
                    Form1.ListBox3.Items.Add("0")
                End If
            ElseIf (href.ToString.Contains("wowadd:") = True) Then
                Dim wowadd As Array
                If (href2.ToString.Contains("|") = True) Then
                    wowadd = href2.Split("|")
                Else
                    wowadd = href2.Split("%7C")
                End If
                Form1.servername.Items.Add(wowadd(0))
                Form1.ListBox1.Items.Add(wowadd(2))
                Form1.ListBox2.Items.Add(wowadd(1))
                Form1.regurl.Items.Add(wowadd(3))
                Form1.homeurl.Items.Add(wowadd(4))
                If (CheckBox1.Checked = True) Then
                    doping(wowadd(2))
                Else
                    Form1.ListBox3.Items.Add("0")
                End If
            End If
        Next

        Dim ii As Integer
        If (File.Exists(Application.StartupPath + "\servers.txt") = False) Then
        Else
            File.Delete(Application.StartupPath + "\servers.txt")
        End If
        For ii = 0 To Form1.ListBox1.Items.Count - 1
            If (File.Exists(Application.StartupPath + "\servers.txt") = False) Then
                File.WriteAllText(Application.StartupPath + "\servers.txt", Form1.servername.Items.Item(ii) + "|" + Form1.ListBox2.Items.Item(ii) + "|" + Form1.ListBox1.Items.Item(ii) + "|" + Form1.regurl.Items.Item(ii) + "|" + Form1.homeurl.Items.Item(ii))
            Else
                File.AppendAllText(Application.StartupPath + "\servers.txt", vbCrLf + Form1.servername.Items.Item(ii) + "|" + Form1.ListBox2.Items.Item(ii) + "|" + Form1.ListBox1.Items.Item(ii) + "|" + Form1.regurl.Items.Item(ii) + "|" + Form1.homeurl.Items.Item(ii))
            End If
        Next
    End Function

    Private Sub WebBrowser1_DocumentCompleted(ByVal sender As System.Object, ByVal e As System.Windows.Forms.WebBrowserDocumentCompletedEventArgs) Handles WebBrowser1.DocumentCompleted
        If (CheckBox2.Checked = True) Then
            Dim linksplit() As String = {}

            If (href0 <> "") Then
                linksplit = href0.Split(",")
            End If

            If (current <> -1) Then
                If (current >= linksplit.Length) Then
                    current = -1
                    href0 = ""
                    Me.DialogResult = System.Windows.Forms.DialogResult.OK
                    Me.Close()
                Else
                    importurl()
                    current += 1
                    ToolStripProgressBar1.Increment(1)
                    Dim percent As Integer = ((current / ToolStripStatusLabel1.Tag) * 100)
                    ToolStripStatusLabel1.Text = "Status:  " & current & "/" & ToolStripStatusLabel1.Tag & " (" & percent & "%)"
                    WebBrowser1.Navigate(linksplit(current))
                End If
            Else
                Dim HtmlElement0 As HtmlElement
                For Each HtmlElement0 In WebBrowser1.Document.GetElementsByTagName("A")
                    Dim link As String = Unescape(HtmlElement0.GetAttribute("href").ToString)
                    If (link.StartsWith("http://") = True Or link.StartsWith("https://") = True) Then
                        If (href0 = "") Then
                            href0 = link
                        Else
                            href0 &= "," & link
                        End If
                    ElseIf (New Uri(link).IsFile = True) Then
                        If (href0 = "") Then
                            href0 = WebBrowser1.Url.ToString.TrimEnd(WebBrowser1.Url.LocalPath.TrimStart("/").ToCharArray) & link
                        Else
                            href0 &= "," & WebBrowser1.Url.ToString.TrimEnd(WebBrowser1.Url.LocalPath.TrimStart("/").ToCharArray) & link
                        End If
                    End If
                Next
                Dim href0split() As String = href0.Split(",")
                If (href0 <> "") Then
                    current = 0
                    ToolStripProgressBar1.Visible = True
                    ToolStripProgressBar1.Maximum = href0split.Length
                    ToolStripProgressBar1.Increment(1)
                    ToolStripStatusLabel1.Visible = True
                    ToolStripStatusLabel1.Tag = href0split.Length
                    Dim percent As Integer = ((current / ToolStripStatusLabel1.Tag) * 100)
                    ToolStripStatusLabel1.Text = "Status:  " & current & "/" & ToolStripStatusLabel1.Tag & " (" & percent & "%)"
                    WebBrowser1.Navigate(href0split(current))
                Else
                    Me.DialogResult = System.Windows.Forms.DialogResult.OK
                    Me.Close()
                End If
            End If
        Else
            importurl()
            Me.DialogResult = System.Windows.Forms.DialogResult.OK
            Me.Close()
        End If
    End Sub

    Public Function Unescape(ByVal Enc As String) As String
        Dim i As Long
        For i = 1 To Len(Enc)
            If Mid(Enc, i, 1) = "%" Then Enc = Replace(Enc, Mid(Enc, i, 3), Chr(Asc(Chr("&H" & Mid(Enc, i + 1, 2)))))
        Next i
        Return Enc
    End Function
End Class
