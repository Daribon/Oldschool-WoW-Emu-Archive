Imports System.Windows.Forms
Imports System.IO
Imports System.Net.NetworkInformation

Public Class Dialog2

    Private Sub OK_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OK_Button.Click
        Dim prevsel0 As Integer = Form1.servername.SelectedIndex
        Dim prevsel1 As Integer = Form1.ListBox1.SelectedIndex
        Dim prevsel2 As Integer = Form1.ListBox2.SelectedIndex
        Dim prevsel3 As Integer = Form1.ListBox3.SelectedIndex
        Dim prevsel4 As Integer = Form1.regurl.SelectedIndex
        Dim prevsel5 As Integer = Form1.homeurl.SelectedIndex
        Form1.servername.Items.RemoveAt(prevsel0)
        Form1.servername.Items.Insert(prevsel0, TextBox1.Text)
        Form1.ListBox1.Items.RemoveAt(prevsel1)
        Form1.ListBox1.Items.Insert(prevsel1, TextBox3.Text)
        Form1.ListBox2.Items.RemoveAt(prevsel2)
        Form1.ListBox2.Items.Insert(prevsel2, TextBox2.Text)
        Form1.regurl.Items.RemoveAt(prevsel4)
        Form1.regurl.Items.Insert(prevsel4, TextBox4.Text)
        Form1.homeurl.Items.RemoveAt(prevsel5)
        Form1.homeurl.Items.Insert(prevsel5, TextBox5.Text)

        If (Dialog4.CheckBox2.Checked = True) Then
            Dim sping As Integer = 0
            Try
                sping = Form1.ping(TextBox3.Text)
            Catch ex As Exception
                sping = 0
            End Try
            Dim insindex As Integer = Form1.ListBox3.SelectedIndex
            Form1.ListBox3.Items.RemoveAt(Form1.ListBox3.SelectedIndex)
            Form1.ListBox3.Items.Insert(insindex, sping)
            Form1.ListBox3.SelectedIndex = insindex
        End If
        Dim ei As Integer
        If (File.Exists(Application.StartupPath + "\servers.txt") = False) Then
        Else
            File.Delete(Application.StartupPath + "\servers.txt")
        End If
        For ei = 0 To Form1.ListBox1.Items.Count - 1
            If (File.Exists(Application.StartupPath + "\servers.txt") = False) Then
                File.WriteAllText(Application.StartupPath + "\servers.txt", Form1.servername.Items.Item(ei) + "|" + Form1.ListBox2.Items.Item(ei) + "|" + Form1.ListBox1.Items.Item(ei) + "|" + Form1.regurl.Items.Item(ei) + "|" + Form1.homeurl.Items.Item(ei))
            Else
                File.AppendAllText(Application.StartupPath + "\servers.txt", vbCrLf + Form1.servername.Items.Item(ei) + "|" + Form1.ListBox2.Items.Item(ei) + "|" + Form1.ListBox1.Items.Item(ei) + "|" + Form1.regurl.Items.Item(ei) + "|" + Form1.homeurl.Items.Item(ei))
            End If
        Next

        Me.DialogResult = System.Windows.Forms.DialogResult.OK
        Me.Close()
        Form1.servername.SelectedIndex = prevsel0
        Form1.ListBox1.SelectedIndex = prevsel1
        Form1.ListBox2.SelectedIndex = prevsel2
        Form1.ListBox3.SelectedIndex = prevsel3
        Form1.regurl.SelectedIndex = prevsel4
        Form1.homeurl.SelectedIndex = prevsel5
    End Sub

    Private Sub Cancel_Button_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Cancel_Button.Click
        Me.DialogResult = System.Windows.Forms.DialogResult.Cancel
        Me.Close()
    End Sub

    Private Sub Dialog2_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        TextBox1.Text = Form1.servername.SelectedItem
        TextBox2.Text = Form1.ListBox2.SelectedItem
        TextBox3.Text = Form1.ListBox1.SelectedItem
        TextBox4.Text = Form1.regurl.SelectedItem
        TextBox5.Text = Form1.homeurl.SelectedItem
    End Sub
End Class
