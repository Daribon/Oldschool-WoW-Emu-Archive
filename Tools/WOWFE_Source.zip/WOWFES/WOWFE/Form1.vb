Imports System.IO
Imports Microsoft.Win32
Imports SHDocVw
Imports System.Net.NetworkInformation

Public Class Form1
    Dim settingsarray As String()
    Dim settingsarray2 As String()
    Dim settingsarray3 As String()
    Dim settingsarray4 As String()
    Dim settingsarray5 As String()
    Dim settingsarray6 As String()
    Dim settingsarray7 As String()
    Dim settingsarray8 As String()
    Dim fieldsarray() As String
    Dim fieldsarray2() As String
    Dim fieldsarray3() As String
    Dim fieldsarray4() As String
    Dim fieldsarray5() As String
    Dim fieldsarray6() As String
    Dim versorted As Boolean = False

    Public Function ping(ByVal hostname As String) As Integer
        Dim ping1 As New Ping
        Dim pingr As PingReply = ping1.Send(hostname)
        Dim pingi As Integer = pingr.RoundtripTime
        ping1 = Nothing
        Return pingi
    End Function

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As System.EventArgs) Handles Me.Load
        Dim appProc() As Process
        Dim strModName, strProcName As String
        strModName = Process.GetCurrentProcess.MainModule.ModuleName
        strProcName = System.IO.Path.GetFileNameWithoutExtension(strModName)
        appProc = Process.GetProcessesByName(strProcName)
        If (appProc.Length > 1) Then
            appProc(0).Kill()
        End If

        Dim regwow As RegistryKey
        Registry.ClassesRoot.CreateSubKey("wow")
        Registry.ClassesRoot.OpenSubKey("wow", True).CreateSubKey("shell")
        Registry.ClassesRoot.OpenSubKey("wow", True).OpenSubKey("shell", True).CreateSubKey("open")
        Registry.ClassesRoot.OpenSubKey("wow", True).OpenSubKey("shell", True).OpenSubKey("open", True).CreateSubKey("command")
        Dim regwowadd As RegistryKey
        Registry.ClassesRoot.CreateSubKey("wowadd")
        Registry.ClassesRoot.OpenSubKey("wowadd", True).CreateSubKey("shell")
        Registry.ClassesRoot.OpenSubKey("wowadd", True).OpenSubKey("shell", True).CreateSubKey("open")
        Registry.ClassesRoot.OpenSubKey("wowadd", True).OpenSubKey("shell", True).OpenSubKey("open", True).CreateSubKey("command")
        Dim regwowimport As RegistryKey
        Registry.ClassesRoot.CreateSubKey("wowimport")
        Registry.ClassesRoot.OpenSubKey("wowimport", True).CreateSubKey("shell")
        Registry.ClassesRoot.OpenSubKey("wowimport", True).OpenSubKey("shell", True).CreateSubKey("open")
        Registry.ClassesRoot.OpenSubKey("wowimport", True).OpenSubKey("shell", True).OpenSubKey("open", True).CreateSubKey("command")
        Dim regwowsearch As RegistryKey
        Registry.ClassesRoot.CreateSubKey("wowsearch")
        Registry.ClassesRoot.OpenSubKey("wowsearch", True).CreateSubKey("shell")
        Registry.ClassesRoot.OpenSubKey("wowsearch", True).OpenSubKey("shell", True).CreateSubKey("open")
        Registry.ClassesRoot.OpenSubKey("wowsearch", True).OpenSubKey("shell", True).OpenSubKey("open", True).CreateSubKey("command")

        regwow = Registry.ClassesRoot.OpenSubKey("wow", True)
        regwowadd = Registry.ClassesRoot.OpenSubKey("wowadd", True)
        regwowimport = Registry.ClassesRoot.OpenSubKey("wowimport", True)
        regwowsearch = Registry.ClassesRoot.OpenSubKey("wowsearch", True)
        regwow.SetValue("URL Protocol", "")
        regwowadd.SetValue("URL Protocol", "")
        regwowimport.SetValue("URL Protocol", "")
        regwowsearch.SetValue("URL Protocol", "")

        regwow = Registry.ClassesRoot.OpenSubKey("wow", True).OpenSubKey("shell", True).OpenSubKey("open", True).OpenSubKey("command", True)
        regwowadd = Registry.ClassesRoot.OpenSubKey("wowadd", True).OpenSubKey("shell", True).OpenSubKey("open", True).OpenSubKey("command", True)
        regwowimport = Registry.ClassesRoot.OpenSubKey("wowimport", True).OpenSubKey("shell", True).OpenSubKey("open", True).OpenSubKey("command", True)
        regwowsearch = Registry.ClassesRoot.OpenSubKey("wowsearch", True).OpenSubKey("shell", True).OpenSubKey("open", True).OpenSubKey("command", True)
        regwow.SetValue("", Chr(34) & System.Reflection.Assembly.GetEntryAssembly.Location & Chr(34) & " %1")
        regwowadd.SetValue("", Chr(34) & System.Reflection.Assembly.GetEntryAssembly.Location & Chr(34) & " %1")
        regwowimport.SetValue("", Chr(34) & System.Reflection.Assembly.GetEntryAssembly.Location & Chr(34) & " %1")
        regwowsearch.SetValue("", Chr(34) & System.Reflection.Assembly.GetEntryAssembly.Location & Chr(34) & " %1")

        loadsettings()
        loadservers()


        If (Command() = "") Then
        ElseIf (Command().StartsWith("wowadd:")) Then
            Dim wowadd As Array = Unescape(Command()).Replace("wowadd://", "").Replace("wowadd:/", "").Replace("wowadd:", "").Split("|")
            servername.Items.Add(wowadd(0))
            ListBox1.Items.Add(wowadd(2))
            ListBox2.Items.Add(wowadd(1))
            regurl.Items.Add(wowadd(3))
            homeurl.Items.Add(wowadd(4))
            If (Dialog4.CheckBox2.Checked = True) Then
                Try
                    ListBox3.Items.Add(ping(wowadd(1)))
                Catch ex As Exception
                    ListBox3.Items.Add("0")
                End Try
            Else
                ListBox3.Items.Add("0")
            End If
            If (File.Exists(Application.StartupPath + "\servers.txt") = False) Then
                File.WriteAllText(Application.StartupPath + "\servers.txt", wowadd(0) + "|" + wowadd(1) + "|" + wowadd(2) + "|" + wowadd(3) + "|" + wowadd(4))
            Else
                File.AppendAllText(Application.StartupPath + "\servers.txt", vbCrLf + wowadd(0) + "|" + wowadd(1) + "|" + wowadd(2) + "|" + wowadd(3) + "|" + wowadd(4))
            End If
        ElseIf (Command().StartsWith("wow:")) Then
            servername.Items.Add("0")
            ListBox1.Items.Add(Unescape(Command()).Replace("wow:", "").Replace("/", ""))
            ListBox2.Items.Add("0")
            regurl.Items.Add("0")
            homeurl.Items.Add("0")
            If (Dialog4.CheckBox2.Checked = True) Then
                Try
                    ListBox3.Items.Add(ping(Unescape(Command()).Replace("wow:", "").Replace("/", "")))
                Catch ex As Exception
                    ListBox3.Items.Add("0")
                End Try
            Else
                ListBox3.Items.Add("0")
            End If
            If (File.Exists(Application.StartupPath + "\servers.txt") = False) Then
                File.WriteAllText(Application.StartupPath + "\servers.txt", Unescape(Command()).Replace("wow:", "").Replace("/", ""))
                Play(Unescape(Command()).Replace("wow:", "").Replace("/", ""))
            Else
                File.AppendAllText(Application.StartupPath + "\servers.txt", vbCrLf + Unescape(Command()).Replace("wow:", "").Replace("/", ""))
                Play(Unescape(Command()).Replace("wow:", "").Replace("/", ""))
            End If
        ElseIf (Command().StartsWith("wowimport:")) Then
            Dialog3.WebBrowser1.Navigate(Unescape(Command()).Replace("wowimport://", "").Replace("wowimport:/", "").Replace("wowimport:", ""))
        ElseIf (Command().StartsWith("wowsearch:")) Then
            Dialog3.CheckBox2.Checked = True
            Dialog3.WebBrowser1.Navigate(Unescape(Command()).Replace("wowsearch://", "").Replace("wowsearch:/", "").Replace("wowsearch:", ""))
        End If
    End Sub

    Public Function Unescape(ByVal Enc As String) As String
        Dim i As Long
        For i = 1 To Len(Enc)
            If Mid(Enc, i, 1) = "%" Then Enc = Replace(Enc, Mid(Enc, i, 3), Chr(Asc(Chr("&H" & Mid(Enc, i + 1, 2)))))
        Next i
        Return Enc
    End Function

    Public Function Play(ByVal server As String, Optional ByVal ver As String = "0")
        If (Dialog4.TextBox1.Text.StartsWith(3) = True) Then
            If (Directory.Exists(Dialog4.ComboBox1.Text + "Data\enUS") = True) Then
                File.WriteAllText(Dialog4.ComboBox1.Text + "Data\enUS\realmlist.WTF", "set realmlist " + server)
            ElseIf (Directory.Exists(Dialog4.ComboBox1.Text + "Data\enGB") = True) Then
                File.WriteAllText(Dialog4.ComboBox1.Text + "Data\enGB\realmlist.WTF", "set realmlist " + server)
            End If
        Else
            File.WriteAllText(Dialog4.ComboBox1.Text + "realmlist.WTF", "set realmlist " + server)
        End If
        If (Dialog4.CheckBox3.Checked = True) Then
            If (Dialog4.TextBox1.Text <> ver) Then
                Dim result As MsgBoxResult
                Dim lessmore As String = "different"
                If (Dialog4.TextBox1.Text > ver) Then
                    lessmore = "higher"
                ElseIf (Dialog4.TextBox1.Text < ver) Then
                    lessmore = "lower"
                End If
                result = MsgBox("Your WoW version (" & Dialog4.TextBox1.Text & ") is " & lessmore & " than the selected server (" & ver & ")." & vbCrLf & "Launch anyway?" & vbCrLf & vbCrLf & vbCrLf & "Note: you can hide this option under 'Settings'.", MsgBoxStyle.YesNo)
                If (result = MsgBoxResult.Yes) Then
                    Process.Start(Dialog4.ComboBox1.Text + "WoW.exe")
                    afterlaunch()
                End If
            Else
                Process.Start(Dialog4.ComboBox1.Text + "WoW.exe")
                afterlaunch()
            End If

        Else
            Process.Start(Dialog4.ComboBox1.Text + "WoW.exe")
            afterlaunch()
        End If
    End Function

    Public Function loadsettings(Optional ByVal fromfile As String = "")
        If (fromfile = "") Then
            fromfile = Application.StartupPath + "\settings.cfg"
        End If

        If (File.Exists(fromfile) = True) Then
            If (File.Exists(fromfile) = True) Then
                settingsarray = File.ReadAllText(fromfile).Split(vbCrLf)
                Dim i As Integer = 0

                ReDim settingsarray2(settingsarray.Length)
                ReDim settingsarray3(settingsarray.Length)
                ReDim settingsarray4(settingsarray.Length)
                ReDim settingsarray5(settingsarray.Length)
                ReDim settingsarray6(settingsarray.Length)
                ReDim settingsarray7(settingsarray.Length)
                ReDim settingsarray8(settingsarray.Length)

                While (i < settingsarray.Length)
                    Dim tmp() As String = settingsarray(i).Split("|")
                    settingsarray2(i) = tmp(0).Replace(Chr(10), "").Replace(Chr(13), "")
                    settingsarray3(i) = tmp(1).Replace(Chr(10), "").Replace(Chr(13), "")
                    settingsarray4(i) = tmp(2).Replace(Chr(10), "").Replace(Chr(13), "")
                    settingsarray5(i) = tmp(3).Replace(Chr(10), "").Replace(Chr(13), "")
                    settingsarray6(i) = tmp(4).Replace(Chr(10), "").Replace(Chr(13), "")
                    settingsarray7(i) = tmp(5).Replace(Chr(10), "").Replace(Chr(13), "")
                    settingsarray8(i) = tmp(6).Replace(Chr(10), "").Replace(Chr(13), "")
                    i += 1
                End While
            Else
            End If
            If (settingsarray2(0) = "0" Or settingsarray2(0) = "") Then
            Else
                Dialog4.ComboBox1.Text = settingsarray2(0).ToString
            End If
            If (settingsarray3(0) = "") Then
            ElseIf (settingsarray3(0) = "0") Then
                Dialog4.CheckBox1.Checked = False
            ElseIf (settingsarray3(0) = "1") Then
                Dialog4.CheckBox1.Checked = True
            Else
                Dialog4.CheckBox1.Checked = settingsarray3(0).ToString
            End If

            If (settingsarray4(0) = "") Then
            ElseIf (settingsarray4(0) = "0") Then
                Dialog4.CheckBox2.Checked = False
                Dialog3.CheckBox1.Checked = False
            ElseIf (settingsarray4(0) = "1") Then
                Dialog4.CheckBox2.Checked = True
                Dialog3.CheckBox1.Checked = True
            Else
                Dialog4.CheckBox2.Checked = settingsarray4(0).ToString
                Dialog3.CheckBox1.Checked = settingsarray4(0).ToString
            End If

            If (settingsarray5(0) = "") Then
            ElseIf (settingsarray5(0) = "0") Then
                Dialog4.RadioButton4.Checked = True
            ElseIf (settingsarray5(0) = "1") Then
                Dialog4.RadioButton5.Checked = True
            ElseIf (settingsarray5(0) = "2") Then
                Dialog4.RadioButton6.Checked = True
            End If

            If (settingsarray6(0) = "" Or settingsarray6(0) = "0") Then
            ElseIf (settingsarray6(0) = "1") Then
                Dialog4.RadioButton1.Checked = True
            ElseIf (settingsarray6(0) = "2") Then
                Dialog4.RadioButton2.Checked = True
            ElseIf (settingsarray6(0) = "3") Then
                Dialog4.RadioButton3.Checked = True
            End If

            If (settingsarray8(0) = "") Then
            ElseIf (settingsarray8(0) = "0") Then
                Dialog4.CheckBox3.Checked = False
            ElseIf (settingsarray8(0) = "1") Then
                Dialog4.CheckBox3.Checked = True
            Else
                Dialog4.CheckBox3.Checked = settingsarray3(0).ToString
            End If

            If (settingsarray7(0) = "" Or settingsarray7(0) = "0") Then
            Else
                Dialog4.TextBox1.Text = settingsarray7(0)
            End If
        Else
            Try
                Dim regwowpath As String = Registry.LocalMachine.OpenSubKey("SOFTWARE", True).OpenSubKey("Blizzard Entertainment").OpenSubKey("World of Warcraft").GetValue("InstallPath")
                If regwowpath = "" Then
                    MsgBox("No config file not found." & vbCrLf & "Please set your WoW directory now.")
                    Dialog4.ShowDialog()
                Else
                    Dim result As MsgBoxResult = MsgBox("No config file not found." & vbCrLf & "Set WoW directory to " & Chr(34) & regwowpath & Chr(34) & "?", MsgBoxStyle.YesNo)
                    If (result = MsgBoxResult.Yes) Then
                        Dialog4.ComboBox1.Text = regwowpath
                        Try
                            If (System.IO.File.Exists(Dialog4.ComboBox1.Text + "WoW.exe") = True) Then
                                Dialog4.TextBox1.Text = System.Diagnostics.FileVersionInfo.GetVersionInfo(Dialog4.ComboBox1.Text + "WoW.exe").FileVersion.Replace(", ", ".")
                            End If

                        Catch ex As Exception
                        End Try
                        savesettings()
                    End If
                End If
            Catch ex As Exception
                MsgBox("No config file not found." & vbCrLf & "Please set your WoW directory now.")
                Dialog4.ShowDialog()
            End Try
        End If
    End Function

    Public Function savesettings(Optional ByVal tofile As String = "")
        If (tofile = "") Then
            tofile = Application.StartupPath + "\settings.cfg"
        End If

        Dim ping1checked As String
        Dim ping2checked As String
        Dim combine As String = "0"
        Dim closeaction As String = "2"
        Dim checkver As String

        If (Dialog4.CheckBox1.Checked = False) Then
            ping1checked = "0"
        Else
            ping1checked = "1"
        End If
        If (Dialog4.CheckBox2.Checked = False) Then
            ping2checked = "0"
        Else
            ping2checked = "1"
        End If

        If (Dialog4.RadioButton4.Checked = True) Then
            combine = "0"
        End If
        If (Dialog4.RadioButton5.Checked = True) Then
            combine = "1"
        End If
        If (Dialog4.RadioButton6.Checked = True) Then
            combine = "2"
        End If

        If (Dialog4.RadioButton1.Checked = True) Then
            closeaction = "1"
        End If
        If (Dialog4.RadioButton2.Checked = True) Then
            closeaction = "2"
        End If
        If (Dialog4.RadioButton3.Checked = True) Then
            closeaction = "3"
        End If


        If (Dialog4.CheckBox3.Checked = False) Then
            checkver = "0"
        Else
            checkver = "1"
        End If

        File.WriteAllText(tofile, Dialog4.ComboBox1.Text + "|" + ping1checked + "|" + ping2checked + "|" + combine + "|" + closeaction + "|" + Dialog4.TextBox1.Text + "|" + checkver)
    End Function

    Public Function loadservers(Optional ByVal fromfile As String = "")
        If (fromfile = "") Then
            fromfile = Application.StartupPath + "\servers.txt"
        End If

        If (File.Exists(fromfile) = True) Then
            fieldsarray = File.ReadAllText(fromfile).Split(vbCrLf)
            Dim i1 As Integer = 0

            ReDim fieldsarray2(fieldsarray.Length)
            ReDim fieldsarray3(fieldsarray.Length)
            ReDim fieldsarray4(fieldsarray.Length)
            ReDim fieldsarray5(fieldsarray.Length)
            ReDim fieldsarray6(fieldsarray.Length)

            While (i1 < fieldsarray.Length)
                Dim tmp() As String = fieldsarray(i1).Split("|")
                fieldsarray2(i1) = tmp(0).Replace(Chr(10), "").Replace(Chr(13), "")
                If (fieldsarray(i1).ToString.Contains("|") = True) Then
                    fieldsarray3(i1) = tmp(1).Replace(Chr(10), "").Replace(Chr(13), "")
                    fieldsarray4(i1) = tmp(2).Replace(Chr(10), "").Replace(Chr(13), "")
                    fieldsarray5(i1) = tmp(3).Replace(Chr(10), "").Replace(Chr(13), "")
                    fieldsarray6(i1) = tmp(4).Replace(Chr(10), "").Replace(Chr(13), "")
                Else
                    fieldsarray3(i1) = "0"
                    fieldsarray4(i1) = "0"
                    fieldsarray5(i1) = "0"
                    fieldsarray6(i1) = "0"
                End If
                i1 += 1
            End While
        Else
        End If

        If (File.Exists(fromfile) = True) Then
            Dim i As Integer
            While (i < fieldsarray.Length)
                If (fieldsarray(i).ToString.Contains("|") = False) Then
                    fieldsarray3(i) = "0"
                    fieldsarray4(i) = "0"
                    fieldsarray5(i) = "0"
                    fieldsarray6(i) = "0"
                End If
                If (fieldsarray.Length > 1) Then
                    If (fieldsarray4(i).ToString <> "") Then
                        servername.Items.Add(fieldsarray2(i).Replace("|", ""))
                        ListBox1.Items.Add(fieldsarray4(i).Replace("|", ""))
                        ListBox2.Items.Add(fieldsarray3(i).Replace("|", ""))
                        regurl.Items.Add(fieldsarray5(i).Replace("|", ""))
                        homeurl.Items.Add(fieldsarray6(i).Replace("|", ""))
                        If (Dialog4.CheckBox1.Checked = True) Then
                            Try
                                ListBox3.Items.Add(ping(fieldsarray4(i).Replace("|", "")))
                            Catch ex As Exception
                                ListBox3.Items.Add("0")
                            End Try
                        Else
                            ListBox3.Items.Add("0")
                        End If
                    Else
                        servername.Items.Add("0")
                        ListBox1.Items.Add(fieldsarray4(i).ToString)
                        ListBox2.Items.Add("0")
                        regurl.Items.Add("0")
                        homeurl.Items.Add("0")
                        If (Dialog4.CheckBox1.Checked = True) Then
                            Try
                                ListBox3.Items.Add(ping(fieldsarray(i).Replace("|", "")))
                            Catch ex As Exception
                                ListBox3.Items.Add("0")
                            End Try
                        Else
                            ListBox3.Items.Add("0")
                        End If
                    End If
                Else
                    If (fieldsarray4(i).ToString <> "") Then
                        servername.Items.Add(fieldsarray2(i).Replace("|", ""))
                        ListBox1.Items.Add(fieldsarray4(i).Replace("|", ""))
                        ListBox2.Items.Add(fieldsarray3(i).Replace("|", ""))
                        regurl.Items.Add(fieldsarray5(i).Replace("|", ""))
                        homeurl.Items.Add(fieldsarray6(i).Replace("|", ""))
                        If (Dialog4.CheckBox1.Checked = True) Then
                            Try
                                ListBox3.Items.Add(ping(fieldsarray4(i).Replace("|", "")))
                            Catch ex As Exception
                                ListBox3.Items.Add("0")
                            End Try
                        Else
                            ListBox3.Items.Add("0")
                        End If
                    Else
                        servername.Items.Add("0")
                        ListBox1.Items.Add(fieldsarray(i).ToString.Substring(1))
                        ListBox2.Items.Add("0")
                        regurl.Items.Add("0")
                        homeurl.Items.Add("0")
                        If (Dialog4.CheckBox1.Checked = True) Then
                            Try
                                ListBox3.Items.Add(ping(fieldsarray(i).Replace("|", "")))
                            Catch ex As Exception
                                ListBox3.Items.Add("0")
                            End Try
                        Else
                            ListBox3.Items.Add("0")
                        End If
                    End If
                End If
                i += 1
            End While
        Else
        End If
    End Function

    Public Function openserverlist()
        OpenFileDialog1.InitialDirectory = Application.StartupPath
        OpenFileDialog1.ShowDialog()

        If (File.Exists(OpenFileDialog1.FileName) = True) Then
            servername.Items.Clear()
            ListBox1.Items.Clear()
            ListBox2.Items.Clear()
            ListBox3.Items.Clear()
            regurl.Items.Clear()
            homeurl.Items.Clear()
            loadservers(OpenFileDialog1.FileName)
        Else
            Exit Function
        End If
    End Function

    Public Function saveserverlist()
        SaveFileDialog1.InitialDirectory = Application.StartupPath
        SaveFileDialog1.ShowDialog()

        Dim id As Integer
        If (File.Exists(SaveFileDialog1.FileName) = False) Then
        Else
            File.Delete(SaveFileDialog1.FileName)
        End If
        For id = 0 To ListBox1.Items.Count - 1
            If (File.Exists(SaveFileDialog1.FileName) = False) Then
                File.WriteAllText(SaveFileDialog1.FileName, servername.Items.Item(id) + "|" + ListBox2.Items.Item(id) + "|" + ListBox1.Items.Item(id) + "|" + regurl.Items.Item(id) + "|" + homeurl.Items.Item(id))
            Else
                File.AppendAllText(SaveFileDialog1.FileName, vbCrLf + servername.Items.Item(id) + "|" + ListBox2.Items.Item(id) + "|" + ListBox1.Items.Item(id) + "|" + regurl.Items.Item(id) + "|" + homeurl.Items.Item(id))
            End If
        Next
    End Function

    Public Function appendserverlist()
        SaveFileDialog2.InitialDirectory = Application.StartupPath
        SaveFileDialog2.ShowDialog()

        Dim ig As Integer
        For ig = 0 To ListBox1.Items.Count - 1
            If (File.Exists(SaveFileDialog2.FileName) = False) Then
                File.WriteAllText(SaveFileDialog2.FileName, servername.Items.Item(ig) + "|" + ListBox2.Items.Item(ig) + "|" + ListBox1.Items.Item(ig) + "|" + regurl.Items.Item(ig) + "|" + homeurl.Items.Item(ig))
            Else
                File.AppendAllText(SaveFileDialog2.FileName, vbCrLf + servername.Items.Item(ig) + "|" + ListBox2.Items.Item(ig) + "|" + ListBox1.Items.Item(ig) + "|" + regurl.Items.Item(ig) + "|" + homeurl.Items.Item(ig))
            End If
        Next
    End Function

    Public Function sendtotaskbar()
        Me.Hide()
        MinimizeToTaskbarToolStripMenuItem.Checked = True
    End Function

    Public Function afterlaunch()
        If (Dialog4.RadioButton1.Checked = True) Then
            Close()
        ElseIf (Dialog4.RadioButton2.Checked = True) Then
            sendtotaskbar()
        End If
    End Function

    Public Function delsel()
        Dim prevsel0 As Integer = servername.SelectedIndex
        Dim prevsel1 As Integer = ListBox1.SelectedIndex
        Dim prevsel2 As Integer = ListBox2.SelectedIndex
        Dim prevsel3 As Integer = ListBox3.SelectedIndex
        Dim prevsel4 As Integer = regurl.SelectedIndex
        Dim prevsel5 As Integer = homeurl.SelectedIndex
        servername.Items.Remove(servername.SelectedItem)
        ListBox1.Items.Remove(ListBox1.SelectedItem)
        ListBox2.Items.Remove(ListBox2.SelectedItem)
        ListBox3.Items.Remove(ListBox3.SelectedItem)
        regurl.Items.Remove(regurl.SelectedItem)
        homeurl.Items.Remove(homeurl.SelectedItem)
        servername.SelectedIndex = prevsel0 - 1
        ListBox1.SelectedIndex = prevsel1 - 1
        ListBox2.SelectedIndex = prevsel2 - 1
        ListBox3.SelectedIndex = prevsel3 - 1
        regurl.SelectedIndex = prevsel4 - 1
        homeurl.SelectedIndex = prevsel5 - 1
    End Function

    Public Function delall()
        servername.Items.Clear()
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        regurl.Items.Clear()
        homeurl.Items.Clear()
    End Function

    Public Function pingsel()
        Dim sping As Integer = 0
        Try
            sping = ping(ListBox1.Items.Item(ListBox1.SelectedIndex))
        Catch ex As Exception
            sping = 0
        End Try
        Dim insindex As Integer = ListBox3.SelectedIndex
        ListBox3.Items.RemoveAt(ListBox3.SelectedIndex)
        ListBox3.Items.Insert(insindex, sping)
        ListBox3.SelectedIndex = insindex
    End Function

    Public Function pingall()
        Dim prevsel0 As Integer = servername.SelectedIndex
        Dim prevsel1 As Integer = ListBox1.SelectedIndex
        Dim prevsel2 As Integer = ListBox2.SelectedIndex
        Dim prevsel3 As Integer = ListBox3.SelectedIndex
        Dim prevsel4 As Integer = regurl.SelectedIndex
        Dim prevsel5 As Integer = homeurl.SelectedIndex

        ListBox3.Items.Clear()
        Dim i As Integer = 0
        While (i < ListBox1.Items.Count)
            Try
                ListBox3.Items.Add(ping(ListBox1.Items.Item(i)))
            Catch ex As Exception
                ListBox3.Items.Add("0")
            End Try
            i += 1
        End While

        servername.SelectedIndex = prevsel0
        ListBox1.SelectedIndex = prevsel1
        ListBox2.SelectedIndex = prevsel2
        ListBox3.SelectedIndex = prevsel3
        regurl.SelectedIndex = prevsel4
        homeurl.SelectedIndex = prevsel5
    End Function

    Public Function openurl(ByVal url As String)
        Dim ie As New SHDocVw.InternetExplorerClass
        Dim wb As IWebBrowserApp = CType(ie, IWebBrowserApp)
        wb.Visible = True
        wb.Navigate(url)
    End Function

    Public Function homesel()
        openurl(homeurl.SelectedItem)
    End Function

    Public Function regsel()
        openurl(regurl.SelectedItem)
    End Function






    Private Sub QuitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles QuitToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub ListBox1_DoubleClick(ByVal sender As Object, ByVal e As System.EventArgs) Handles ListBox1.DoubleClick
        Play(ListBox1.SelectedItem.ToString, ListBox2.SelectedItem.ToString)
    End Sub

    Private Sub Button1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button1.Click
        Play(ListBox1.SelectedItem.ToString, ListBox2.SelectedItem.ToString)
    End Sub

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        delsel()
    End Sub

    Private Sub Button3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button3.Click
        Dialog1.ShowDialog()
    End Sub

    Private Sub Button4_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button4.Click
        delall()
    End Sub

    Private Sub OpenServerListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles OpenServerListToolStripMenuItem.Click
        openserverlist()
    End Sub

    Private Sub SaveListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveListToolStripMenuItem.Click
        saveserverlist()
    End Sub

    Private Sub AppendToServerListToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AppendToServerListToolStripMenuItem.Click
        appendserverlist()
    End Sub

    Private Sub SaveToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles SaveToolStripMenuItem.Click
        SaveFileDialog3.InitialDirectory = Application.StartupPath
        SaveFileDialog3.ShowDialog()
        savesettings(SaveFileDialog3.FileName)
    End Sub

    Private Sub LoadToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles LoadToolStripMenuItem.Click
        OpenFileDialog2.InitialDirectory = Application.StartupPath
        OpenFileDialog2.ShowDialog()
        loadsettings(OpenFileDialog2.FileName)
    End Sub

    Private Sub AboutToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AboutToolStripMenuItem.Click
        MsgBox("World Of Warcraft Front End v" & Application.ProductVersion & " by Toph" & vbCrLf & vbCrLf & "Email: chrismrulz@hotmail.com" & vbCrLf, MsgBoxStyle.Information, "About World Of Warcraft Front End")
    End Sub

    Private Sub Button6_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button6.Click
        Dialog2.ShowDialog()
    End Sub

    Private Sub EditServerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles EditServerToolStripMenuItem.Click
        Dialog2.ShowDialog()
    End Sub

    Private Sub DeleteSelectedServerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteSelectedServerToolStripMenuItem.Click
        delsel()
    End Sub

    Private Sub DeleteAllServersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles DeleteAllServersToolStripMenuItem.Click
        delall()
    End Sub

    Private Sub ImportServersFromURLToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ImportServersFromURLToolStripMenuItem.Click
        Dialog3.ShowDialog()
    End Sub

    Private Sub Button7_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button7.Click
        pingall()
    End Sub

    Private Sub Button8_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button8.Click
        pingsel()
    End Sub

    Private Sub PingSelectedServerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PingSelectedServerToolStripMenuItem.Click
        pingsel()
    End Sub

    Private Sub PingAllServersToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PingAllServersToolStripMenuItem.Click
        pingall()
    End Sub

    Private Sub PreferencesToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PreferencesToolStripMenuItem.Click
        Dialog4.ShowDialog()
    End Sub

    Private Sub MinimizeToTaskbarToolStripMenuItem1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MinimizeToTaskbarToolStripMenuItem1.Click
        sendtotaskbar()
    End Sub

    Private Sub MinimizeToTaskbarToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MinimizeToTaskbarToolStripMenuItem.Click
        If (MinimizeToTaskbarToolStripMenuItem.Checked = True) Then
            MinimizeToTaskbarToolStripMenuItem.Checked = False
            Me.Show()
        Else
            MinimizeToTaskbarToolStripMenuItem.Checked = True
            Me.Hide()
        End If
    End Sub

    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub AddServerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles AddServerToolStripMenuItem.Click
        Dialog1.ShowDialog()
    End Sub

    Private Sub PlayOnOfficialEUServerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlayOnOfficialEUServerToolStripMenuItem.Click
        Play("eu.logon.worldofwarcraft.com")
    End Sub

    Private Sub PlayOnOfficialUSServerToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles PlayOnOfficialUSServerToolStripMenuItem.Click
        Play("us.logon.worldofwarcraft.com")
    End Sub

    Private Sub GoToHomepageToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles GoToHomepageToolStripMenuItem.Click
        homesel()
    End Sub

    Private Sub RegisterToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RegisterToolStripMenuItem.Click
        regsel()
    End Sub

    Private Sub Button5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button5.Click
        homesel()
    End Sub

    Private Sub Button9_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button9.Click
        regsel()
    End Sub





    Private Sub servername_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles servername.SelectedIndexChanged
        If (servername.SelectedIndex <> -1) Then
            ListBox1.SelectedIndex = servername.SelectedIndex
            ListBox2.SelectedIndex = servername.SelectedIndex
            ListBox3.SelectedIndex = servername.SelectedIndex
            regurl.SelectedIndex = servername.SelectedIndex
            homeurl.SelectedIndex = servername.SelectedIndex
        End If
    End Sub

    Private Sub ListBox1_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox1.SelectedIndexChanged
        If (ListBox1.SelectedIndex <> -1) Then
            ListBox2.SelectedIndex = ListBox1.SelectedIndex
            ListBox3.SelectedIndex = ListBox1.SelectedIndex
            servername.SelectedIndex = ListBox1.SelectedIndex
            regurl.SelectedIndex = ListBox1.SelectedIndex
            homeurl.SelectedIndex = ListBox1.SelectedIndex
        End If
    End Sub

    Private Sub ListBox2_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox2.SelectedIndexChanged
        If (ListBox2.SelectedIndex <> -1) Then
            ListBox1.SelectedIndex = ListBox2.SelectedIndex
            ListBox3.SelectedIndex = ListBox2.SelectedIndex
            servername.SelectedIndex = ListBox2.SelectedIndex
            regurl.SelectedIndex = ListBox2.SelectedIndex
            homeurl.SelectedIndex = ListBox2.SelectedIndex
        End If
    End Sub

    Private Sub ListBox3_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ListBox3.SelectedIndexChanged
        If (ListBox3.SelectedIndex <> -1) Then
            ListBox2.SelectedIndex = ListBox3.SelectedIndex
            ListBox1.SelectedIndex = ListBox3.SelectedIndex
            servername.SelectedIndex = ListBox3.SelectedIndex
            regurl.SelectedIndex = ListBox3.SelectedIndex
            homeurl.SelectedIndex = ListBox3.SelectedIndex
        End If
    End Sub

    Private Sub regurl_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles regurl.SelectedIndexChanged
        If (regurl.SelectedIndex <> -1) Then
            ListBox2.SelectedIndex = regurl.SelectedIndex
            ListBox1.SelectedIndex = regurl.SelectedIndex
            servername.SelectedIndex = regurl.SelectedIndex
            regurl.SelectedIndex = regurl.SelectedIndex
            homeurl.SelectedIndex = regurl.SelectedIndex
        End If
    End Sub

    Private Sub homeurl_SelectedIndexChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles homeurl.SelectedIndexChanged
        If (homeurl.SelectedIndex <> -1) Then
            ListBox2.SelectedIndex = homeurl.SelectedIndex
            ListBox1.SelectedIndex = homeurl.SelectedIndex
            servername.SelectedIndex = homeurl.SelectedIndex
            regurl.SelectedIndex = homeurl.SelectedIndex
            homeurl.SelectedIndex = homeurl.SelectedIndex
        End If
    End Sub

    Private Sub TextBox1_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox1.TextChanged
        If (TextBox1.Text <> "") Then
            ListBox1.SelectedIndex = ListBox1.FindString(TextBox1.Text)
        End If
    End Sub

    Private Sub TextBox2_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox2.TextChanged
        If (TextBox2.Text <> "") Then
            servername.SelectedIndex = servername.FindString(TextBox2.Text)
        End If
    End Sub

    Private Sub TextBox3_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox3.TextChanged
        If (TextBox3.Text <> "") Then
            ListBox2.SelectedIndex = ListBox2.FindString(TextBox3.Text)
        End If
    End Sub

    Private Sub TextBox4_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles TextBox4.TextChanged
        If (TextBox4.Text <> "") Then
            ListBox3.SelectedIndex = ListBox3.FindString(TextBox4.Text)
        End If
    End Sub







    Private Sub Label1_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label1.Click
        If (versorted = False) Then
            versorted = True
            Dim l0p As Integer = servername.SelectedIndex
            Dim l1p As Integer = ListBox1.SelectedIndex
            Dim l2p As Integer = ListBox2.SelectedIndex
            Dim l3p As Integer = ListBox3.SelectedIndex
            Dim l4p As Integer = regurl.SelectedIndex
            Dim l5p As Integer = homeurl.SelectedIndex
            Dim list0() As String = {}
            Dim list1() As String = {}
            Dim list2() As String = {}
            Dim list3() As String = {}
            Dim list4() As String = {}
            Dim list5() As String = {}
            ReDim list0(servername.Items.Count - 1)
            ReDim list1(ListBox1.Items.Count - 1)
            ReDim list2(ListBox2.Items.Count - 1)
            ReDim list3(ListBox3.Items.Count - 1)
            ReDim list4(regurl.Items.Count - 1)
            ReDim list5(homeurl.Items.Count - 1)

            Dim i0 As Integer = 0
            For Each item As Object In servername.Items
                list0(i0) = item.ToString
                i0 += 1
            Next

            Dim i As Integer = 0
            For Each item As Object In ListBox1.Items
                list1(i) = item.ToString
                i += 1
            Next

            Dim i2 As Integer = 0
            For Each item As Object In ListBox2.Items
                list2(i2) = item.ToString
                i2 += 1
            Next

            Dim i3 As Integer = 0
            For Each item As Object In ListBox3.Items
                list3(i3) = item.ToString
                i3 += 1
            Next

            Dim i4 As Integer = 0
            For Each item As Object In regurl.Items
                list4(i4) = item.ToString
                i4 += 1
            Next

            Dim i5 As Integer = 0
            For Each item As Object In homeurl.Items
                list5(i5) = item.ToString
                i5 += 1
            Next

            servername.Items.Clear()
            ListBox1.Items.Clear()
            ListBox2.Items.Clear()
            ListBox3.Items.Clear()
            regurl.Items.Clear()
            homeurl.Items.Clear()

            Array.Sort(list2, list0)
            Array.Sort(list2, list1)
            Array.Sort(list2, list3)
            Array.Sort(list2, list4)
            Array.Sort(list2, list5)

            For Each item As String In list0
                servername.Items.Add(item)
            Next
            For Each item As String In list1
                ListBox1.Items.Add(item)
            Next
            For Each item As String In list2
                ListBox2.Items.Add(item)
            Next
            For Each item As String In list3
                ListBox3.Items.Add(item)
            Next
            For Each item As String In list4
                regurl.Items.Add(item)
            Next
            For Each item As String In list5
                homeurl.Items.Add(item)
            Next
            servername.SelectedIndex = l0p
            ListBox1.SelectedIndex = l1p
            ListBox2.SelectedIndex = l2p
            ListBox3.SelectedIndex = l3p
            regurl.SelectedIndex = l4p
            homeurl.SelectedIndex = l5p
        End If
    End Sub

    Private Sub Label2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label2.Click
        versorted = False
        Dim l0p As Integer = servername.SelectedIndex
        Dim l1p As Integer = ListBox1.SelectedIndex
        Dim l2p As Integer = ListBox2.SelectedIndex
        Dim l3p As Integer = ListBox3.SelectedIndex
        Dim l4p As Integer = regurl.SelectedIndex
        Dim l5p As Integer = homeurl.SelectedIndex
        Dim list0() As String = {}
        Dim list1() As String = {}
        Dim list2() As String = {}
        Dim list3() As String = {}
        Dim list4() As String = {}
        Dim list5() As String = {}
        ReDim list0(servername.Items.Count - 1)
        ReDim list1(ListBox1.Items.Count - 1)
        ReDim list2(ListBox2.Items.Count - 1)
        ReDim list3(ListBox3.Items.Count - 1)
        ReDim list4(regurl.Items.Count - 1)
        ReDim list5(homeurl.Items.Count - 1)

        Dim i0 As Integer = 0
        For Each item As Object In servername.Items
            list0(i0) = item.ToString
            i0 += 1
        Next

        Dim i As Integer = 0
        For Each item As Object In ListBox1.Items
            list1(i) = item.ToString
            i += 1
        Next

        Dim i2 As Integer = 0
        For Each item As Object In ListBox2.Items
            list2(i2) = item.ToString
            i2 += 1
        Next

        Dim i3 As Integer = 0
        For Each item As Object In ListBox3.Items
            list3(i3) = item.ToString
            i3 += 1
        Next

        Dim i4 As Integer = 0
        For Each item As Object In regurl.Items
            list4(i4) = item.ToString
            i4 += 1
        Next

        Dim i5 As Integer = 0
        For Each item As Object In homeurl.Items
            list5(i5) = item.ToString
            i5 += 1
        Next

        servername.Items.Clear()
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        regurl.Items.Clear()
        homeurl.Items.Clear()

        Array.Sort(list1, list0)
        Array.Sort(list1, list2)
        Array.Sort(list1, list3)
        Array.Sort(list1, list4)
        Array.Sort(list1, list5)

        For Each item As String In list0
            servername.Items.Add(item)
        Next
        For Each item As String In list1
            ListBox1.Items.Add(item)
        Next
        For Each item As String In list2
            ListBox2.Items.Add(item)
        Next
        For Each item As String In list3
            ListBox3.Items.Add(item)
        Next
        For Each item As String In list4
            regurl.Items.Add(item)
        Next
        For Each item As String In list5
            homeurl.Items.Add(item)
        Next
        servername.SelectedIndex = l0p
        ListBox1.SelectedIndex = l1p
        ListBox2.SelectedIndex = l2p
        ListBox3.SelectedIndex = l3p
        regurl.SelectedIndex = l4p
        homeurl.SelectedIndex = l5p
    End Sub

    Private Sub Label3_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label3.Click
        versorted = False
        Dim l0p As Integer = servername.SelectedIndex
        Dim l1p As Integer = ListBox1.SelectedIndex
        Dim l2p As Integer = ListBox2.SelectedIndex
        Dim l3p As Integer = ListBox3.SelectedIndex
        Dim l4p As Integer = regurl.SelectedIndex
        Dim l5p As Integer = homeurl.SelectedIndex
        Dim list0() As String = {}
        Dim list1() As String = {}
        Dim list2() As String = {}
        Dim list3() As String = {}
        Dim list4() As String = {}
        Dim list5() As String = {}
        ReDim list0(servername.Items.Count - 1)
        ReDim list1(ListBox1.Items.Count - 1)
        ReDim list2(ListBox2.Items.Count - 1)
        ReDim list3(ListBox3.Items.Count - 1)
        ReDim list4(regurl.Items.Count - 1)
        ReDim list5(homeurl.Items.Count - 1)

        Dim i0 As Integer = 0
        For Each item As Object In servername.Items
            list0(i0) = item.ToString
            i0 += 1
        Next

        Dim i As Integer = 0
        For Each item As Object In ListBox1.Items
            list1(i) = item.ToString
            i += 1
        Next

        Dim i2 As Integer = 0
        For Each item As Object In ListBox2.Items
            list2(i2) = item.ToString
            i2 += 1
        Next

        Dim i3 As Integer = 0
        For Each item As Object In ListBox3.Items
            list3(i3) = item.ToString
            i3 += 1
        Next

        Dim i4 As Integer = 0
        For Each item As Object In regurl.Items
            list4(i4) = item.ToString
            i4 += 1
        Next

        Dim i5 As Integer = 0
        For Each item As Object In homeurl.Items
            list5(i5) = item.ToString
            i5 += 1
        Next

        servername.Items.Clear()
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        regurl.Items.Clear()
        homeurl.Items.Clear()

        Array.Sort(list3, list0)
        Array.Sort(list3, list1)
        Array.Sort(list3, list2)
        Array.Sort(list3, list4)
        Array.Sort(list3, list5)

        For Each item As String In list0
            servername.Items.Add(item)
        Next
        For Each item As String In list1
            ListBox1.Items.Add(item)
        Next
        For Each item As String In list2
            ListBox2.Items.Add(item)
        Next
        For Each item As String In list3
            ListBox3.Items.Add(item)
        Next
        For Each item As String In list4
            regurl.Items.Add(item)
        Next
        For Each item As String In list5
            homeurl.Items.Add(item)
        Next
        servername.SelectedIndex = l0p
        ListBox1.SelectedIndex = l1p
        ListBox2.SelectedIndex = l2p
        ListBox3.SelectedIndex = l3p
        regurl.SelectedIndex = l4p
        homeurl.SelectedIndex = l5p
    End Sub

    Private Sub Label5_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label5.Click
        versorted = False
        Dim l0p As Integer = servername.SelectedIndex
        Dim l1p As Integer = ListBox1.SelectedIndex
        Dim l2p As Integer = ListBox2.SelectedIndex
        Dim l3p As Integer = ListBox3.SelectedIndex
        Dim l4p As Integer = regurl.SelectedIndex
        Dim l5p As Integer = homeurl.SelectedIndex
        Dim list0() As String = {}
        Dim list1() As String = {}
        Dim list2() As String = {}
        Dim list3() As String = {}
        Dim list4() As String = {}
        Dim list5() As String = {}
        ReDim list0(servername.Items.Count - 1)
        ReDim list1(ListBox1.Items.Count - 1)
        ReDim list2(ListBox2.Items.Count - 1)
        ReDim list3(ListBox3.Items.Count - 1)
        ReDim list4(regurl.Items.Count - 1)
        ReDim list5(homeurl.Items.Count - 1)

        Dim i0 As Integer = 0
        For Each item As Object In servername.Items
            list0(i0) = item.ToString
            i0 += 1
        Next

        Dim i As Integer = 0
        For Each item As Object In ListBox1.Items
            list1(i) = item.ToString
            i += 1
        Next

        Dim i2 As Integer = 0
        For Each item As Object In ListBox2.Items
            list2(i2) = item.ToString
            i2 += 1
        Next

        Dim i3 As Integer = 0
        For Each item As Object In ListBox3.Items
            list3(i3) = item.ToString
            i3 += 1
        Next

        Dim i4 As Integer = 0
        For Each item As Object In regurl.Items
            list4(i4) = item.ToString
            i4 += 1
        Next

        Dim i5 As Integer = 0
        For Each item As Object In homeurl.Items
            list5(i5) = item.ToString
            i5 += 1
        Next

        servername.Items.Clear()
        ListBox1.Items.Clear()
        ListBox2.Items.Clear()
        ListBox3.Items.Clear()
        regurl.Items.Clear()
        homeurl.Items.Clear()

        Array.Sort(list0, list1)
        Array.Sort(list0, list2)
        Array.Sort(list0, list3)
        Array.Sort(list0, list4)
        Array.Sort(list0, list5)

        For Each item As String In list0
            servername.Items.Add(item)
        Next
        For Each item As String In list1
            ListBox1.Items.Add(item)
        Next
        For Each item As String In list2
            ListBox2.Items.Add(item)
        Next
        For Each item As String In list3
            ListBox3.Items.Add(item)
        Next
        For Each item As String In list4
            regurl.Items.Add(item)
        Next
        For Each item As String In list5
            homeurl.Items.Add(item)
        Next
        servername.SelectedIndex = l0p
        ListBox1.SelectedIndex = l1p
        ListBox2.SelectedIndex = l2p
        ListBox3.SelectedIndex = l3p
        regurl.SelectedIndex = l4p
        homeurl.SelectedIndex = l5p
    End Sub

    Private Sub Button11_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button11.Click
        If (ListBox1.Items.Count > 0) Then
            ListBox1.SelectedIndex = 0
        End If
    End Sub

    Private Sub Button12_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button12.Click
        If (ListBox1.Items.Count > 0) Then
            ListBox1.SelectedIndex = ListBox1.Items.Count - 1
        End If
    End Sub

    Private Sub Button13_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button13.Click
        If (ListBox1.Items.Count > 0 And ListBox1.SelectedIndex < ListBox1.Items.Count - 1) Then
            ListBox1.SelectedIndex += 1
        End If
    End Sub

    Private Sub Button14_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button14.Click
        If (ListBox1.Items.Count > 0 And ListBox1.SelectedIndex > 0) Then
            ListBox1.SelectedIndex -= 1
        End If
    End Sub

    Public Sub filter()
        Try
            Dim toremove As New ArrayList
            Dim sni As Integer = 0
            For Each item As Object In servername.Items
                If (toremove.Contains(item)) Then
                    sni += 1
                ElseIf (ComboBox1.Text = "Contains:" And item.ToString.ToLower.Contains(Filter1.Text.ToLower) = False) Then
                    toremove.Add(sni)
                ElseIf (ComboBox1.Text = "Doesn't Contain:" And item.ToString.ToLower.Contains(Filter1.Text.ToLower) = True) Then
                    toremove.Add(sni)
                ElseIf (ComboBox1.Text = "Equals:" And item.ToString.ToLower <> Filter1.Text.ToLower) Then
                    toremove.Add(sni)
                ElseIf (ComboBox1.Text = "Doesn't Equal:" And item.ToString.ToLower = Filter1.Text.ToLower) Then
                    toremove.Add(sni)
                ElseIf (ComboBox1.Text = "Less Than:" And item.ToString >= Filter1.Text) Then
                    toremove.Add(sni)
                ElseIf (ComboBox1.Text = "Greater Than:" And item.ToString <= Filter1.Text) Then
                    toremove.Add(sni)
                Else
                    sni += 1
                End If
            Next

            Dim lb1 As Integer = 0
            For Each item As Object In ListBox1.Items
                If (toremove.Contains(item)) Then
                    lb1 += 1
                ElseIf (ComboBox3.Text = "Contains:" And item.ToString.ToLower.Contains(Filter3.Text.ToLower) = False) Then
                    toremove.Add(lb1)
                ElseIf (ComboBox3.Text = "Doesn't Contain:" And item.ToString.Contains(Filter3.Text.ToLower) = True) Then
                    toremove.Add(lb1)
                ElseIf (ComboBox3.Text = "Equals:" And item.ToString.ToLower <> Filter3.Text.ToLower) Then
                    toremove.Add(lb1)
                ElseIf (ComboBox3.Text = "Doesn't Equal:" And item.ToString.ToLower = Filter3.Text.ToLower) Then
                    toremove.Add(lb1)
                ElseIf (ComboBox3.Text = "Less Than:" And item.ToString >= Filter3.Text) Then
                    toremove.Add(lb1)
                ElseIf (ComboBox3.Text = "Greater Than:" And item.ToString <= Filter3.Text) Then
                    toremove.Add(lb1)
                Else
                    lb1 += 1
                End If
            Next

            Dim lb2 As Integer = 0
            For Each item As Object In ListBox2.Items
                If (toremove.Contains(item)) Then
                    lb2 += 1
                ElseIf (ComboBox2.Text = "Contains:" And item.ToString.ToLower.Contains(Filter2.Text.ToLower) = False) Then
                    toremove.Add(lb2)
                ElseIf (ComboBox2.Text = "Doesn't Contain:" And item.ToString.ToLower.Contains(Filter2.Text.ToLower) = True) Then
                    toremove.Add(lb2)
                ElseIf (ComboBox2.Text = "Equals:" And item.ToString.ToLower <> Filter2.Text.ToLower) Then
                    toremove.Add(lb2)
                ElseIf (ComboBox2.Text = "Doesn't Equal:" And item.ToString.ToLower = Filter2.Text.ToLower) Then
                    toremove.Add(lb2)
                ElseIf (ComboBox2.Text = "Less Than:" And item.ToString >= Filter2.Text) Then
                    toremove.Add(lb2)
                ElseIf (ComboBox2.Text = "Greater Than:" And item.ToString <= Filter2.Text) Then
                    toremove.Add(lb2)
                Else
                    lb2 += 1
                End If
            Next

            Dim lb3 As Integer = 0
            For Each item As Object In ListBox3.Items
                If (toremove.Contains(item)) Then
                    lb3 += 1
                ElseIf (ComboBox4.Text = "Contains:" And item.ToString.ToLower.Contains(Filter4.Text.ToLower) = False) Then
                    toremove.Add(lb3)
                ElseIf (ComboBox4.Text = "Doesn't Contain:" And item.ToString.ToLower.Contains(Filter4.Text.ToLower) = True) Then
                    toremove.Add(lb3)
                ElseIf (ComboBox4.Text = "Equals:" And item.ToString.ToLower <> Filter4.Text.ToLower) Then
                    toremove.Add(lb3)
                ElseIf (ComboBox4.Text = "Doesn't Equal:" And item.ToString.ToLower = Filter4.Text.ToLower) Then
                    toremove.Add(lb3)
                ElseIf (ComboBox4.Text = "Less Than:" And item.ToString >= Filter4.Text) Then
                    toremove.Add(lb3)
                ElseIf (ComboBox4.Text = "Greater Than:" And item.ToString <= Filter4.Text) Then
                    toremove.Add(lb3)
                Else
                    lb3 += 1
                End If
            Next

            For Each item As Integer In toremove
                servername.Items.RemoveAt(item)
                ListBox1.Items.RemoveAt(item)
                ListBox2.Items.RemoveAt(item)
                ListBox3.Items.RemoveAt(item)
                regurl.Items.RemoveAt(item)
                homeurl.Items.RemoveAt(item)
            Next

            servername.SelectedIndex = 0
            ListBox1.SelectedIndex = 0
            ListBox2.SelectedIndex = 0
            ListBox3.SelectedIndex = 0
            regurl.SelectedIndex = 0
            homeurl.SelectedIndex = 0
        Catch ex As Exception

        End Try
    End Sub

    Private Sub Button10_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button10.Click
        filter()
    End Sub

    Private Sub ComboBox1_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.DropDown
        ComboBox1.Width = 100
    End Sub

    Private Sub ComboBox1_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox1.DropDownClosed
        ComboBox1.Width = 41
    End Sub

    Private Sub ComboBox2_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox2.DropDown
        ComboBox2.Width = 100
    End Sub

    Private Sub ComboBox2_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox2.DropDownClosed
        ComboBox2.Width = 41
    End Sub

    Private Sub ComboBox3_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox3.DropDown
        ComboBox3.Width = 100
    End Sub

    Private Sub ComboBox3_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox3.DropDownClosed
        ComboBox3.Width = 41
    End Sub

    Private Sub ComboBox4_DropDown(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox4.DropDown
        ComboBox4.Width = 100
    End Sub

    Private Sub ComboBox4_DropDownClosed(ByVal sender As Object, ByVal e As System.EventArgs) Handles ComboBox4.DropDownClosed
        ComboBox4.Width = 41
    End Sub
End Class
