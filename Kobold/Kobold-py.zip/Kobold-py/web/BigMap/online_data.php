<?php
/* 
	POMK  v1.0
	Player Online Map for Kobold

	Show online players position on map. Update without refresh.
	Show tooltip with location, race, class and level of player.
	
  16.12.2006 Rewritten for kobold by AceIndy

	Originaly 
	Created by mirage666 (c) (mailto:mirage666@pisem.net icq# 152263154)
	who wrote it under POMM v1.3 for Mangos
	
	
	Please edit incl/config.php to suit your own needs
*/

require('incl/config.php');
require_once "JsHttpRequest/Php.php";

$mysql = mysql_connect($mysql_host, $mysql_user, $mysql_pw);
$db = mysql_select_db($mysql_db);

if(!$mysql) die("Can�t connect to MySql!<br>".mysql_error()." ".mysql_errno());
if(!$db) die("Can�t connect to MySql Database!<br>".mysql_error()." ".mysql_errno());


$JsHttpRequest = new Subsys_JsHttpRequest_Php("windows-1251");
$i=0;
$query = mysql_query("SELECT
`characters`.`data`,
`characters`.`positionX`,
`characters`.`positionY`,
`characters`.`mapId`,
`characters`.`name`,
`characters`.`class`,
`characters`.`race`,
`characters`.`zoneId`,
`www_zones`.`ZoneName`
FROM
`characters`
Inner Join `char_state` ON `characters`.`guid` = `char_state`.`player_guid`
Inner Join `www_zones` ON `characters`.`zoneId` = `www_zones`.`ZoneID`
WHERE `characters`.`guid`=`char_state`.`player_guid` and `char_state`.`online_state` = 1 and `characters`.`mapID`<>530
ORDER BY `characters`.`name`
;");
while($ress = mysql_fetch_array($query))
	{
	$zone = str_replace("'","`",$ress['ZoneName']);
	$char_data = explode(' ',$ress['data']);
	$char_gender = dechex($char_data[36]);
	$char_gender = str_pad($char_gender,8, 0, STR_PAD_LEFT);
	$pos = get_player_position($ress['positionX'],$ress['positionY'],$ress['mapId']);
	$arr[$i]['x'] = $pos['x'];
	$arr[$i]['y'] = $pos['y'];
	$arr[$i]['name']=$ress['name'];
	$arr[$i]['zone']=$zone;
	$arr[$i]['cl'] = $ress['class'];
	$arr[$i]['race'] = $ress['race'];
	$arr[$i]['level'] = $char_data[34];
	$arr[$i]['gender'] = $char_gender{3};
	$i++;
	}
$_RESULT =$arr;

function get_player_position($x,$y,$m) {
 $xpos = round((20000-($x)*1.05) * (1280/40000));
 $ypos = round((20000-($y)*1.5) * (870/40000));
 switch ($m)
 {
   case 530:
     if ($ypos > 640 and $xpos > 435 ){
          $pos['x'] = $ypos - 755  ;
          $pos['y'] = $xpos - 515 ;
     } elseif ($ypos < 755 and $xpos < 480 ){
          $pos['x'] = $ypos + 520 ;
          $pos['y'] = $xpos - 258 ;
     } else {
     	    $pos['x'] = -100 ;
          $pos['y'] = -100 ;
     }
     break;
     
   case 509:
   case 531:
   case 249:
   case 1:
    $pos['x'] = $ypos - 170 ;
    $pos['y'] = $xpos - 190 ;
    break;
    
   default:
    $pos['x'] = $ypos + 610 ;
    $pos['y'] = $xpos - 350 ;
 }
 return $pos;
}

?>