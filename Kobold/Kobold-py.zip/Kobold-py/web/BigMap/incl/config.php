<?php

$time= "60";                                           // Update time (seconds), 0 - not update.
$show_time="1";                                        // Show update timer 1 - on, 0 - off
$img_base = "http://www.aceindy.tournan.com/img/";     // Image dir
$SQL_ZoneIDs = "1";                                    //Lookup Zones in MySQL

$mysql_host = 'mysql_1.aceindy.nl';                    //hostname/address of your mysql server; default 'localhost'
$mysql_user = 'root';                                  //username to login into your database; default 'root'
$mysql_pw = '7747K0dak';                               //password to login into your database
$mysql_db = 'wow_server';                              //db to connect to; default 'wow_server' or 'kobold'  

?>