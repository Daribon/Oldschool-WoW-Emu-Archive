<?php
/* 
	POMK  v1.0
	Player Online Map for Kobold

	Show online players position on map. Update without refresh.
	Show tooltip with location, race, class and level of player.
	
  16.12.2006 Rewritten for kobold by AceIndy

	Originaly 
	Created by mirage666 (c) (mailto:mirage666@pisem.net icq# 152263154)
	who wrote it under POMM v1.3 for Mangos
	
	
	Please edit incl/config.php to suit your own needs
*/

require('incl/config.php');
$point="http://www.aceindy.tournan.com/img/realm_on.gif";
$link = "index.php"
?>
<HTML><HEAD><title>AceIndy's DutchW*W map</title>
<style type="text/css">
<!--
body {
	margin-left: 0px;
	margin-top: 0px;
	margin-right: 0px;
	margin-bottom: 0px;
	color: #EABA28;
	background-color: #000000;
}
#world {
	position: absolute;
	height: 1150px;
	width: 1150px;
	left: 50%;
	margin-left: -575px;
	background-image: url(http://www.aceindy.tournan.com/img/map_outland.jpg);
	z-index: 10;
}
#points {
	position: absolute;
	height: 1150px;
	width: 1150px;
	left: 50%;
	margin-left: -575px;
	z-index: 100;
}
#wow {
	position: absolute;
	height: 1150px;
	width: 1150px;
	left: 50%;
	margin-left: -575px;
	z-index: 20;
	text-align: center;
	clear: none;
	float: none;
}
#info {
	position: absolute;
	height: 1150px;
	width: 1150px;
	left: 50%;
	margin-left: -575px;
	z-index: 30;
	text-align: center;
}
#timer {
	font-family: arial;
	font-size: 12px;
	font-style: normal;
	text-align: center;
	font-weight: bold;
	color: #FF3333;
	z-index: 40;
	filter: Glow(Color=#000099, Strength=3);
}
#server_info {
	font-family: Georgia, "Times New Roman", Times, serif;
	font-size: 12px;
	font-style: italic;
	text-align: center;
	font-weight: bold;
	color: #FFFF99;
	filter: Glow(Color=0, Strength=3);
}
#tip {
	background: #000000;
	border: 1px solid #aaaaaa;
	left: -1000px;
	padding: 0px;
	position: absolute;
	top: -1000px;
	z-index: 110;
} 
.tip_header {
	background: #bb0000;
	FONT-WEIGHT: bold;
	color: #FFFFFF;
	font-family: arial, helvetica, sans-serif;
	font-size: 12px;
	font-style: normal;
	text-align: center;
	padding: 0px;
} 
.tip_text {
	background: #000000;
	FONT-WEIGHT: normal;
	color: #ffffff;
	font-family: arial, helvetica, sans-serif;
	font-size: 12px;
	font-style: normal;
	text-align: center;
	padding: 3px;
} 
-->
</style>
</HEAD>
<script language="JavaScript" src="JsHttpRequest/Js.js"></script>
<SCRIPT LANGUAGE="javascript" TYPE="text/javascript">

var time = <?php echo $time ?>;
var show_time=<?php echo $show_time ?>;
var race_name = {
		1: 'Human',
		2: 'Orc',
		3: 'Dwarf',
		4: 'Night Elf',
		5: 'Undead',
		6: 'Tauren',
		7: 'Gnome',
		8: 'Troll',
		9: 'Goblin',
	 10: 'Blood Elf',
	 11: 'Draenei'
}

var class_name = {
		1: 'Warrior',
		2: 'Paladin',
		3: 'Hunter',
		4: 'Rogue',
		5: 'Priest',
		7: 'Shaman',
		8: 'Mage',
		9: 'Warlock',
		11: 'Druid'
}

function tip(header,text) { 
var t; 
t=document.getElementById("tip"); 

if (window.opera) { 
x=window.event.clientX+15; 
y=window.event.clientY-10; 
} else if (navigator.appName=="Netscape") {
document.onmousemove=function(e) { x = e.pageX+15; y = e.pageY-10; return true}
} else { 
x=window.event.clientX + document.documentElement.scrollLeft + document.body.scrollLeft + 15; 
y=window.event.clientY + document.documentElement.scrollTop + document.body.scrollTop - 10; 
} 

t.innerHTML='<table width="80" border="0" cellspacing="0" cellpadding="0"\><tr class=\'tip_header\'\><td\>'+header+'</td\></tr\><tr class=\'tip_text\'\><td\>'+text+'</td\></tr\><\/table\>';
if (screen.width-x<150) x-=150; 
t.style.left=x + "px"; 
t.style.top=y + "px"; 
} 

function h_tip() { 
var t; 
t=document.getElementById("tip"); 
t.innerHTML=""; 
t.style.left="-1000px"; 
t.style.top="-1000px"; 
} 

function show(data) {
i=0;
text='';
if (data) {
while (i<data.length) {
	if (data[i].race==2 || data[i].race==5 || data[i].race==6 || data[i].race==8 || data[i].race==10 ) 
											{point="<?php echo $img_base ?>horde.gif";} else {point="<?php echo $img_base ?>allia.gif";}
	text=text+'<img src="'+point+'" style="position: absolute; border: 0px; left: '+data[i].x+'px; top: '+data[i].y+'px;" onMouseMove="tip(\''+data[i].name+'\',\''+data[i].zone+'<br\><img src=\\\'<?php echo $img_base ?>'+data[i].race+'-'+data[i].gender+'.gif\\\' style=\\\'float:center\\\' border=0 width=18 height=18\> <img src=\\\'<?php echo $img_base ?>'+data[i].cl+'.gif\\\' style=\\\'float:center\\\' border=0 width=18 height=18\><br\>'+race_name[data[i].race]+'<br/>'+class_name[data[i].cl]+'<br/>lvl '+data[i].level+'\');" onMouseOut="h_tip();"\>';
i++;
}
}
document.getElementById("points").innerHTML=text;
}

function load_data() {
var req = new Subsys_JsHttpRequest_Js();
req.onreadystatechange = function() {
	if (req.readyState == 4) {show(req.responseJS);}
    }
    req.open('GET', 'outline_data.php', true);
    req.send({ });
}

function reset() {
var ms = 0;
then = new Date();
then.setTime(then.getTime()-ms);
load_data();
}

function display() {
now = new Date();
ms = now.getTime() - then.getTime();
ms = time*1000-ms;
if ((show_time==1) && (time!=0)) {document.getElementById("timer").innerHTML=(Math.round(ms/1000));}
if (ms<=0) {
	reset();
	}
if (time!=0) {setTimeout("display();", 500);}
}

function start() {
reset();
display();
if (navigator.appName=="Netscape") {
document.onmousemove=function(e) { x = e.pageX+15; y = e.pageY-10; return true}
}
}
</SCRIPT>
<BODY onload=start()>
<div id="tip"></div><div ID="points"></div><div ID="world"></div><div ID="info"><center><table border="0" cellspacing="0" cellpadding="0" height="20"><tr><td valign="top" id="timer"></td></tr></table>
<table border="0" cellspacing="0" cellpadding="0" height="470" width="1">
<tr><td>
<div id="switch" style="position:absolute; width:200px; height:115px; z-index:200; left: 22px; top: 22px;"><a href="index.php">
<img src="http://www.aceindy.tournan.com/img/b_azeroth.gif" width="100" height="100" border="0"
onMouseOver="tip('<b>Azeroth</b>', 'Click here to switch map');" onMouseOut="h_tip();"></a>
</div>
</td></tr></table>
<table border="0" cellspacing="0" cellpadding="0" height="370" width="100%">
<tr><td align="center" valign="bottom" id="server_info"></td></tr></table></center>
</BODY></HTML>