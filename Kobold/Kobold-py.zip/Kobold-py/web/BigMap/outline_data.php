<?php
/* 
	POMK  v1.0
	Player Online Map for Kobold

	Show online players position on map. Update without refresh.
	Show tooltip with location, race, class and level of player.
	
  16.12.2006 Rewritten for kobold by AceIndy

	Originaly 
	Created by mirage666 (c) (mailto:mirage666@pisem.net icq# 152263154)
	who wrote it under POMM v1.3 for Mangos
	
	
	Please edit incl/config.php to suit your own needs
*/

require('incl/config.php');
require_once "JsHttpRequest/Php.php";

$mysql = mysql_connect($mysql_host, $mysql_user, $mysql_pw);
$db = mysql_select_db($mysql_db);

if(!$mysql) die("Can�t connect to MySql!<br>".mysql_error()." ".mysql_errno());
if(!$db) die("Can�t connect to MySql Database!<br>".mysql_error()." ".mysql_errno());


$JsHttpRequest = new Subsys_JsHttpRequest_Php("windows-1251");
$i=0;
$query = mysql_query("SELECT
`characters`.`data`,
`characters`.`positionX`,
`characters`.`positionY`,
`characters`.`mapId`,
`characters`.`name`,
`characters`.`class`,
`characters`.`race`,
`characters`.`zoneId`,
`www_zones`.`ZoneName`
FROM
`characters`
Inner Join `char_state` ON `characters`.`guid` = `char_state`.`player_guid`
Inner Join `www_zones` ON `characters`.`zoneId` = `www_zones`.`ZoneID`
WHERE `characters`.`guid`=`char_state`.`player_guid` and `char_state`.`online_state` = 1 and `characters`.`mapID`>1
ORDER BY `characters`.`name`
;");
while($ress = mysql_fetch_array($query))
	{
	$zone = str_replace("'","`",$ress['ZoneName']);
	$char_data = explode(' ',$ress['data']);
	$char_gender = dechex($char_data[36]);
	$char_gender = str_pad($char_gender,8, 0, STR_PAD_LEFT);
	$pos = get_player_position($ress['positionY'],$ress['positionX'],$ress['mapId']);
	$arr[$i]['x'] = $pos['x'];
	$arr[$i]['y'] = $pos['y'];
	$arr[$i]['name']=$ress['name'];
	$arr[$i]['zone']=$zone;
	$arr[$i]['cl'] = $ress['class'];
	$arr[$i]['race'] = $ress['race'];
	$arr[$i]['level'] = $char_data[34];
	$arr[$i]['gender'] = $char_gender{3};
	$i++;
	}
$_RESULT =$arr;

function get_player_position($x,$y,$m) {
	if ($x >= -1100 and $x <= 10500 and $y <= 5500 and $y >= -5500 ) {
	  $pos['x'] = (-$x + 10500) * (1130/12000);
	  $pos['y'] = (-$y + 5500) * (1150/11110);
 // $pos['x'] = 1130 ; == -1000
 // $pos['y'] = 1100 ; == -5500
 // $pos['x'] = 0 ; == 10500
 // $pos['y'] = 0 ; == 5500
} else {
	  $pos['x'] = -100;
	  $pos['y'] = -100;	  
}
 return $pos;
}

?>