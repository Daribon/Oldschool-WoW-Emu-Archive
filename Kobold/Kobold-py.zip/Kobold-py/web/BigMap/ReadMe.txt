	POMK  v1.0
	Player Online Map for Kobold

	Show online players position on map. Update without refresh.
	Show tooltip with location, race, class and level of player.
	
  16.12.2006 Rewritten for kobold by AceIndy

	Originaly 
	Created by mirage666 (c) (mailto:mirage666@pisem.net icq# 152263154)
	who wrote it under POMM v1.3 for Mangos
	
	
	Please edit incl/config.php to suit your own needs
