<?
// ERROR REPORTING STUFF LEAVE IT ALONE
error_reporting(E_ERROR | E_CORE_ERROR | E_COMPILE_ERROR | E_USER_ERROR);

// SITE CUSTOMIZATION; PS if your going to have a 's you must have a \ before it, ex: $title = 'b3ck\'s WoW test server';
$title           = 'Dutch W*W Anduril V3';                                 // title of your site; default 'WoW Test Server' this will display in the titlebar and at the top of the page
$acct_closed     = '';                                                     // Entering a text in here will close account creation page, showing the text you entered
$ver_accepted    = '2.0.1 build [6180]';                                   // Shows accepted client version
$ver_alternative = 'BC 2.0.0 build [6080]';                                // Shows alternative client version

$forums          = 'http://dutchwow.jaccobird.com/';                       // link to your forums, default 'http://www.laughingkobold.com'
$web_account     = 'http://realm1.aceindy.nl/wow/';                            // link to Account Creation server (normaly LS), must be known due to multiple realms
$web_port        = '80';																									 // Base port for Account Creation server (in case of multirealms, additional realms will have web_port +1)

// Images locations
$image_base      = 'http://www.aceindy.tournan.com/images/';               // Image dir (can be internal or external)
$background      = $image_base.'nightelf.jpg';                             // the background image for the main DIV's, you can change it to a color, just put '#XXXXXX'
$banner          = $image_base.'dutchwgz.png';                             // The Banner image in top of site

// MYSQL: EDIT TO MATCH YOUR DB INFO OTHERWISE YOU CAN'T CREATE ACCOUNTS
$mysql_host      = 'mysql_1.aceindy.nl';                                   // host of your mysql server; default 'localhost'
$mysql_user      = 'root';                                                 // username to login into your database; default 'root'
$mysql_pw        = '7747K0dak';                                            // password to login into your database
$mysql_db        = 'wow_server';                                           // db to connect to; default 'wow_server' or 'kobold'  

//Config for stats-pages Classes & Races 
$show_online          = true;																							 // Show stats for classes/races currently online
$show_total           = true;                                              // Show stats for all classes/races registered
$show_Width           = 25;                                                // Bar width to be used in table
$show_HeightTotal     = 66;                                                // Highest bar will be this height in table 
$show_HeightNone      = 0;                                                 // Offset to bars 

// US MIRRORS; THESE ARE JUST SOME MIRRORS I FOUND FROM WOWWIKI.COM YOU MAY CHANGE THEM TO WHATEVER YOU WANT
$us_mirror_1_title = '2.0.1 incremental'; //title of the patch file this will show up on the outside of the link box
$us_mirror_1_link = 'http://a.wirebrain.de/wow/patches/2.0.1/enUS/WoW-1.12.x-to-2.0.1-enUS-patch.zip'; //actual link to the patch file
$us_mirror_1_desc = '1.12.x > 2.0.1 [PC] (483.30 MB)'; //description of the patch file which will be used as the link text

$us_mirror_2_title = '2.0.1 incremental';
$us_mirror_2_link = 'http://a.wirebrain.de/wow/patches/2.0.1/enUS/WoW-1.12.x-to-2.0.1-enUS-patch.zip';
$us_mirror_2_desc = '1.12.x > 2.0.1 [Mac] (483.30 MB)';

$us_mirror_3_title = '1.12.1 incremental';
$us_mirror_3_link = 'http://a.wirebrain.de/wow/patches/1.12.1/enUS/WoW-1.12.0.5595-to-1.12.1.5875-enUS-patch.exe';
$us_mirror_3_desc = '1.12.0 > 1.12.1 [PC] (3.12 MB)';

$us_mirror_4_title = '1.12.1 incremental';
$us_mirror_4_link = 'http://a.wirebrain.de/wow/patches/1.12.1/enUS/WoW-1.12.0.5595-to-1.12.1.5875-enUS-patch.zip';
$us_mirror_4_desc = '1.12.0 > 1.12.1 [Mac] (3.72 MB)';

$us_mirror_5_title = '1.12.0 Full';
$us_mirror_5_link = 'http://a.wirebrain.de/wow/patches/1.12/private/WoW-1.12.0-enUS-patch.exe';
$us_mirror_5_desc = '1.12.0 Full [PC] (465.25 MB)';

$us_mirror_6_title = '1.12.0 Full';
$us_mirror_6_link = 'http://a.wirebrain.de/wow/patches/1.12/private/WoW-1.12.0-enUS-patch.zip';
$us_mirror_6_desc = '1.12.0 Full [MAC] (466.03 MB)';
//I figured 6 mirrors should be enough for each patch section, you may add more if you want, you'll have to add code in the us_patches.php as well






// EU MIRRORS; THESE ARE JUST SOME MIRRORS I FOUND FROM WOWWIKI.COM YOU MAY CHANGE THEM TO WHATEVER YOU WANT
$eu_mirror_1_title = '2.0.1 incremental'; //title of the patch file this will show up on the outside of the link box
$eu_mirror_1_link = 'http://a.wirebrain.de/wow/patches/2.0.1/enGB/WoW-1.12.x-to-2.0.1-enGB-patch.zip'; //actual link to the patch file
$eu_mirror_1_desc = '1.12.x > 2.0.1 [PC] (672.15 MB)'; //description of the patch file which will be used as the link text

$eu_mirror_2_title = '2.0.1 incremental';
$eu_mirror_2_link = 'http://a.wirebrain.de/wow/patches/2.0.1/enGB/WoW-1.12.x-to-2.0.1-enGB-patch.zip';
$eu_mirror_2_desc = '1.12.x > 2.0.1 [Mac] (672.15 MB)';

$eu_mirror_3_title = '1.12.0 incremental';
$eu_mirror_3_link = 'http://a.wirebrain.de/wow/patches/1.12/enGB/WoW-1.11.2.5464-to-1.12.0.5595-enGB-patch.exe';
$eu_mirror_3_desc = '1.11.2 > 1.12.0 [PC] (16.33 MB)';

$eu_mirror_4_title = '1.12.0 incremental';
$eu_mirror_4_link = 'http://a.wirebrain.de/wow/patches/1.12/enGB/WoW-1.11.2.5464-to-1.12.0.5595-enGB-patch.zip';
$eu_mirror_4_desc = '1.11.2 > 1.12.0 [MAC] (18.00 MB)';

$eu_mirror_5_title = '1.12.0 Full';
$eu_mirror_5_link = 'http://a.wirebrain.de/wow/patches/1.12/private/WoW-1.12.0-enGB-patch.exe';
$eu_mirror_5_desc = '1.12.0 Full [PC] (456.24 MB)';

$eu_mirror_6_title = '1.12.0 Full';
$eu_mirror_6_link = 'http://a.wirebrain.de/wow/patches/1.12/private/WoW-1.12.0-enGB-patch.zip';
$eu_mirror_6_desc = '1.12.0 Full [MAC] (457.32 MB)';
//I figured 6 mirrors should be enough for each patch section, you may add more if you want, you'll have to add code in the eu_patches.php as well
?>


