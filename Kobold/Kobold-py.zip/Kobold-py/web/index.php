<?
require('incl/_config.php');

$mysql           = mysql_connect($mysql_host, $mysql_user, $mysql_pw);
$db              = mysql_select_db($mysql_db);

if(!$mysql) die("Can�t connect to MySql!<br>".mysql_error()." ".mysql_errno());
if(!$db) die("Can�t connect to MySql Database!<br>".mysql_error()." ".mysql_errno());

?>
<html>
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/styles.css" rel="stylesheet">
<title>:: <?=$title ?> ::</title></head>
<body>
<div align="center" id="container">
<div id="title"><font class="style1"><a><img src="<?=$banner?>" border="0" alt="<?=$title?>" title="<?=$title?>" height="60" width="468" ></a></font></div>
<br />
<div id="nav">
<a class="navlink" target="_blank" href="<?=$forums ?>">Forum</a> |
<a class="navlink" href="<? echo $web_account;?>index.php?action=server">Online</a> |
<a class="navlink" href="<? echo $_SERVER["PHP_SELF"];?>?action=races">Races</a> | 
<a class="navlink" href="<? echo $_SERVER["PHP_SELF"];?>?action=classes">Classes</a> | 
<a class="navlink" href="<? echo $web_account;?>index.php?action=account">New Account</a> | 
<a class="navlink" href="<? echo $_SERVER["PHP_SELF"];?>?action=gmtickets"">GM Tickets</a>
</div>

<?
$action=isset($_GET['action'])?$_GET['action']:'DEFAULT_ACTION';
switch($action) {
case "server":
include("pages/server.php");
break;
case "status":
include("pages/status.php");
break;
case "users":
include("pages/users.php");
break;
case "races":
include("pages/races.php");
break;
case "classes":
include("pages/Classes.php");
break;
case "uspatches":
include("pages/patches_us.php");
break;
case "eupatches":
include("pages/patches_eu.php");
break;
case "credits":
include("pages/credits.php");
break;
case "gmtickets":
include("pages/gmtickets.php");
break;
case "account":
include("account.php");
break;
case "gmportal":
include("gmportal.php");
break;
default:
include("pages/users.php");
break;
}
?>
<br />
<div id="nav2">
<span class="navlink2">
<a class="navlink2" href="#1" onClick="window.open ('bigmap/index.php', 'OnlinePlayerMap', 'Toolbar=0, Location=0, Directories=0, Status=0, Menubar=0, Scrollbar=0, Resizable=1, Copyhistory=1, Width=1280, Height=870') ">Online map</a> - 
<a class="navlink2" href="http://wow.gamona.de/worldmap2/" title="Online player map" target="_blank">Atlas</a> - 
<a class="navlink2" href="<? echo $_SERVER["PHP_SELF"]; ?>?action=uspatches">enUS Patches</a> - 
<a class="navlink2" href="<? echo $_SERVER["PHP_SELF"]; ?>?action=eupatches">enGB Patches</a> - 
<a class="navlink2" href="http://www.wowwiki.com/Patch_mirrors" title="Can't find your Patch on my site?, go here I guarantee you'll find it at wowwiki.com" target="_blank">More Patches</a> - 
<a class="navlink2" href="https://login.blizzard.fileplanet.com/login.aspx?o=login&d=fileplanet&r=http://www.fileplanet.com/blizzard_promotion/wow_raf.htm" title="Get WoW For Free 2.8GB Download tho, but you can play it on this server" target="_blank">Download WoW</a>
</span><?PHP include("incl/footer.php")?>
</div></body></html>