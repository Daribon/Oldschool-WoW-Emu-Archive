<?
@session_start();
require('incl/_config.php');
@$link = mysql_connect("$mysql_host", "$mysql_user", "$mysql_pw");
mysql_select_db("$mysql_db");

echo '<br /><div style="background-image: url('.$background.')" id=account><br /><li>GM Portal</li><br /><div id="hr"></div><div align=center>';
if (isset($_POST["username"])) {
  $u = $_POST["username"];
  $p = ($_POST["password"]);
  $query = mysql_query("SELECT `password`,`GM`,`acct`,`sessionkey` FROM `accounts` WHERE `login` = '$u'");
  $cp = mysql_fetch_array($query);

  if (empty($p) || empty($u )) {
    echo "<div class=\"error\">A field was left blank</div><br />";
  }elseif ($p!=$cp[0]) {
    echo "<div class=\"error\">Wrong passwords, please try again</div>";
  }elseif ($cp[1]== 0) {
    echo "<div class=\"error\">You are not a GM</div><br />";
  } else {
    echo "<div class=\"style4\">The user \"$u\" has successfully loged on.</div><br />";
    $_SESSION['enumkey']=$cp[3];
    include("pages/BindPoint.php");
    include("pages/inventory.php");
    include("pages/lockchar.php");
    include("pages/unlockchar.php");
    include("pages/BannIP.php");
    include("pages/UnBannIP.php");
    include("pages/KillServ.php");
  }
} elseif (isset($_POST["charname"])) {
    $c = $_POST["charname"];
    mysql_query("UPDATE `characters` RIGHT JOIN `bindpoint` ON `characters`.`guid` = `bindpoint`.`playerId` AND `characters`.`name` =  '$c' SET `characters`.`positionX`= `bindpoint`.`positionX`,`characters`.`positionY`= `bindpoint`.`positionY`,`characters`.`positionZ`= `bindpoint`.`positionZ`,`characters`.`mapId`= `bindpoint`.`mapId`,`characters`.`zoneId`= `bindpoint`.`zoneId`;");
    if (mysql_affected_rows()>0) {
       echo "<div class=\"style4\">The position of \"$c\" has been restored to bindpoint.</div><br />";
    } else {
       echo "<div class=\"style4\">The position of \"$c\" could not be updated.</div><br />";
    }
} elseif (isset($_POST["invname"])) {
    $c = $_POST["invname"];

    $query = mysql_query("SELECT `characters`.`level` from `characters` WHERE `characters`.`name` = '$c';");
    while($ress = mysql_fetch_array($query)) {
        $gold = 15000000;
        if ($ress[0] < 9) { $gold = 100000 ;} 
        elseif  ($ress[0] < 19) { $gold = 500000 ;}
        elseif  ($ress[0] < 29) { $gold = 1000000 ;}
        elseif  ($ress[0] < 39) { $gold = 3000000 ;}
        elseif  ($ress[0] < 49) { $gold = 5000000 ;}
        elseif  ($ress[0] < 59) { $gold = 10000000 ;};
        echo '<div class=\"style4\">Inventory of '.$c.':</div><br /><table>
                <tr>
                   <td align=left><b>.mod level '.$ress[0].'</b></td>
                </tr>
                <tr>
                   <td align=left><b>.mod gold '.$gold.'</b></td>
                </tr>';
    }
    $query = mysql_query("SELECT `characters`.`name`,`characters`.`level`,`items`.`item_id`,`items`.`name` as `item`,`characters`.`level`,`items`.`requiredlevel`,`characters`.`class`,`items`.`allowableclass`,`characters`.`race`,`items`.`allowablerace`,`items`.`buyprice`,`items`.`sellprice` FROM `characters` Left Join `inventory` ON `characters`.`guid` = `inventory`.`player_guid` Left Join `item_instances` ON `inventory`.`item_guid` = `item_instances`.`guid` Left Join `items` ON  `items`.`item_id` =  SUBSTRING_INDEX(SUBSTRING_INDEX(`item_instances`.`data`,' ',4), ' ', -1) Where `characters`.`name` = '$c' Order By `items`.`item_id`  > 0 ;");
    while($ress = mysql_fetch_array($query)) {
      echo '<tr>
                  <td><b>.add '.$ress[2].'</b></td>
            </tr>';
    }
    echo '</table>';
} elseif (isset($_POST["lockname"])) {
    $ln = $_POST["lockname"];
    mysql_query("UPDATE `characters` SET `characters`.`enumFlag`= 65535 where `characters`.`name` =  '$ln';");
    if (mysql_affected_rows()>0) {
       echo "<div class=\"style4\">The character \"$ln\" has been locked.</div><br />";
    } else {
       echo "<div class=\"style4\">The character \"$ln\" could not be locked.</div><br />";
    }
    echo "<div class=\"style4\">Current lock list:</div><br />";
    $query = mysql_query("SELECT `characters`.`guid`,`characters`.`name` FROM `characters` WHERE `characters`.`enumFlag` > 0 ;");
    while($ress = mysql_fetch_array($query)) {
      echo '<tr>
               <div align="left">
                  <td align=center><b><span style="color:'.$color.'">'.$ress[0].'</span></b></td>
                  <td align=left><b><span style="color:'.$color.'">'.$ress[1].'</span></b></td>
               </div>
            </tr>
     <br \>';
    }
} elseif (isset($_POST["unlockname"])) {
    $ul = $_POST["unlockname"];
    mysql_query("UPDATE `characters` SET `characters`.`enumFlag`= 0 where `characters`.`name` =  '$ul';");
    if (mysql_affected_rows()>0) {
       echo "<div class=\"style4\">The character \"$ul\" has been unlocked.</div><br />";
    } else {
       echo "<div class=\"style4\">The character \"$ul\" could not be unlocked.</div><br />";
    }
    echo "<div class=\"style4\">Current lock list:</div><br />";
    $query = mysql_query("SELECT `characters`.`guid`,`characters`.`name` FROM `character` WHERE `characters`.`enumFlag`= 65535;");
    while($ress = mysql_fetch_array($query)) {
      echo '<tr>
               <div align="left">
                  <td align=left><b><span style="color:'.$color.'">'.$ress[1].'</span></b></td>
               </div>
            </tr>
            <tr>
               <div align="left">
                   <td align=left><b><span style="color:'.$color.'">'.$ress[2].'</span></b></td>
               </div>
            </tr>
     <br \>';
    }
} elseif (isset($_POST["BannIP"])) {
    $bi = $_POST["BannIP"];
    $br = $_POST["Breason"];
    if ($bi!='') { 
       mysql_query("INSERT INTO `black_list` SET `black_list`.`baned_ip`= '$bi', `black_list`.`reason` =  '$br';");
       if (mysql_affected_rows()>0) {
          echo "<div class=\"style4\">The IP \"$bi\" has put on bannlist, reason was \"$br\"</div><br />";
       } else {
          echo "<div class=\"style4\">The IP \"$bi\" could not be added.</div><br />";
       }
    }
    echo "<div class=\"style4\">Current banlist:</div><br />";
    $query = mysql_query("SELECT * FROM `black_list`;");
    while($ress = mysql_fetch_array($query)) {
      echo '<tr>
               <div align="left">
                  <td align=left><b><span style="color:'.$color.'">'.$ress[1].'</span></b></td>
               </div>
            </tr>
            <tr>
               <div align="left">
                   <td align=left><b><span style="color:'.$color.'">'.$ress[2].'</span></b></td>
               </div>
            </tr>
    <br \>';
    }
} elseif (isset($_POST["UnBannIP"])) {
    $ub = $_POST["UnBannIP"];
    if ($ub!='') {
        mysql_query("DELETE FROM `black_list` WHERE `black_list`.`baned_ip` =  '$ub';");
        if (mysql_affected_rows()>0) {
           echo "<div class=\"style4\">The IP \"$ub\" has been removed.</div><br />";
        } else {
           echo "<div class=\"style4\">The IP \"$ul\" could not be removed.</div><br />";
        }
    } 
    echo "<div class=\"style4\">Current banlist:</div><br />";
    $query = mysql_query("SELECT * FROM `black_list`;");
    while($ress = mysql_fetch_array($query)) {
      echo '<tr>
               <div align="left">
                  <td align=left><b><span style="color:'.$color.'">'.$ress[1].'</span></b></td>
               </div>
            </tr>
            <tr>
               <div align="left">
                   <td align=left><b><span style="color:'.$color.'">'.$ress[2].'</span></b></td>
               </div>
            </tr>
    <br \>';
    }
} elseif (isset($_POST["killserv"])) {
    $kl = $_POST["killserv"];
    if ($kl == "LS" ) {
       echo exec('taskkill.exe /F /IM _LogonServer.exe');
    } elseif ($kl == "RS") {
      echo exec('taskkill.exe /F /IM _RealmServer.exe');
    } else {
       echo "<div class=\"style4\">You did not specify LS or RS.</div><br />";
    }
} else {
  include("pages/logon.php");
}?></div></div>

