<?
require('incl/_config.php');
@$link = mysql_connect("$mysql_host", "$mysql_user", "$mysql_pw");
mysql_select_db("$mysql_db");
$counted = mysql_query("SELECT COUNT(acct) FROM accounts;");
$Tacct = mysql_fetch_array($counted);
$counted = mysql_query("SELECT COUNT(id) FROM realm_list where status = 0;");
$Trealms = mysql_fetch_array($counted);

if (empty($acct_closed)) {
  echo '<br /><div style="background-image: url('.$background.')" id=account><br /><li><font color=#00FF00>'.$Tacct[0].'</font> - accounts on <font color=#00FF00>'.$Trealms[0].'</font> realm(s).</li><br /><div id="hr"></div><div align=center>';

  if (isset($_POST["username"])) {
   $u = $_POST["username"];
   $p = ($_POST["password"]);
   $cp = ($_POST["cpassword"]);
   $ctype = ($_POST["c_type"]);
   $e = $_POST["email"];
   $t = date("Y-m-d");
   $ip = $_SERVER['REMOTE_ADDR'];
   if (strlen($p) < 4 || strlen($cp) < 4 || strlen($u) < 4 ) {
    echo "<div class=\"regfail\">Error ! (Minimum field lenght is 4 chars)</div><br />";
  }else{
    if($p!=$cp) {
      echo "<div class=\"regfail\">Error ! (The passwords do not match)</div>";
    } else {
				$checkuser = mysql_query("SELECT `login`, `email` FROM `accounts` WHERE `login` = '$u' OR `email` = '$e'") or die('SQL error: ' . mysql_error());
	  	  $user_exists = mysql_num_rows($checkuser);
	    	if ($user_exists > 0) {
	    		echo "<div class=\"regfail\">Error ! (Username or Email already exists)</div><br />";
	    	} else {
         if ($ctype == "Normal") { $flags = 0; } else { $flags = 1; }
 			 		$query = "insert into `accounts` (login,password,s,v,gm,sessionkey,email,joindate,regip,expansion_allowed) values ('$u','$p','NULL','NULL','0','NULL','$e','$t','$ip','$flags')";
					mysql_query($query) or die(mysql_error());
					echo "<div class=\"regok\">The user \"$u\" has been successfully registered. You may now login.</div><br />";
        }
      }
    }
  }
} else { 
  echo '<br /><div style="background-image: '.$background.'" id=account><br /><li><font color=#00FF00>'.$Tacct[0].'</font> - accounts with <font color=#00FF00>'.$Tchar[0].'</font> characters so far.</li><br /><div id="hr"></div><div align=center>
  '.$acct_closed.'<br /><br />';
}
echo 'Kobold accepts clients of version:<br /><br />
<font color="Yellow"><b>'.$ver_accepted.'<br />'
.$ver_alternative.'</b></FONT><br />'; 
?>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1">
<link href="css/styles.css" rel="stylesheet">
<title>:: <?=$title ?> ::</title></head>
     <form action="<?=$web_account;?>index.php?action=account" method="post">
         <table>
           <tr>
             <td align="right">
               Username:
             </td>
             <td align="left">
               <input id="textarea" type="text" maxlength="10" name="username">
             </td>
            </tr>
           <tr>
             <td align="right">
               Password:
                 </td>
                     <td align="left">
                       <input id="textarea" type="password" maxlength="10" name="password">
             </td>
           </tr>
           <tr>
             <td align="right">
               Confirm Password:
                 </td>
                     <td align="left">
                       <input id="textarea" type="password" maxlength="10" name="cpassword">
             </td>
           </tr>
		       <tr>
		         <td align="right">
		           Email:
                 </td>
                     <td align="left">
                       <input id="textarea" type="text" maxlength="40" name="email">
		         </td>
           <tr>
             <td align="right">
               Client type:
                 </td>
                     <td align="left">
                       <select name="c_type" type="select" size = 1 >
                          <option>Burning Crusade
                          <option selected="true">Burning Crusade
                      </select>
             </td>
           </tr>
           <tr>
             <td colspan="2" align="center">
               <div align="right">
                 <input id="buttons" type="submit" value="Register">
                 <input type="reset" id="buttons" name="Clear" value="Clear">
               </div></td>
           </tr>
           <tr>
             <td colspan="2" align="center">
             <div align="right">
                <span class="credits3"><b>Remember: A Game worth playing, is a Game worth buying</span></b>
             </div></td>
            </tr>
         </table></form></div></div>