<br />
<div style="background-image: <?=$background ?>" id="credits">
<br><br><li><font color="LightBlue">Credits</li></font>
<br /><div id="hr"></div>
<br />
<span class="credits3">Main developer & Admin:<br /><div id="creditline">AceIndy</div></span><br /><br />
<span class="credits2">DB developer:<br /><div id="creditline">Iceman</div></span><br /><br />
<span class="credits4">Additonal Modifications:<br /><div id="creditline">Gorm</div></span><br /><br />
<span class="credits1">Webpage design original by:<br /><div id="creditline">b3ck</div></span><br /><br />
</div>