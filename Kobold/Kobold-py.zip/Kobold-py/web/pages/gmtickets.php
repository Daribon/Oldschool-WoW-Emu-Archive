
<?
@$link = mysql_connect("$mysql_host", "$mysql_user", "$mysql_pw");
if (!$link) {
  die('Could not connect: ' . mysql_error());
}
mysql_select_db("$mysql_db");
$q = mysql_query("SELECT gmsystem.ticket_id,gmsystem.text,gmsystem.category,characters.name FROM gmsystem,characters WHERE gmsystem.guid=characters.guid ORDER BY gmsystem.ticket_id");

echo '<br />
<div style="background-image: '.$background.'" id="credits"><br /><li>GM Ticket System</font></li>
<br /><div id="hr"></div>
<div style="overflow:auto; margin-left:5; height:auto">
<table width="99%" height="33" background="'.$background.'">';

while ($r = mysql_fetch_assoc($q))	{
	echo '<tr><th align="left"><font color=#00FF00>'.$r['ticket_id'].'</font> - <font color="LightBlue">'.$r['name'].'</font><br /></th></tr>
	<tr><td id="TICKET'.$r['ticket_id'].'"><font color="yellow">'.$r['text'].'</font></td></tr>';
}
echo '</table></tr></div></div>';
?>
