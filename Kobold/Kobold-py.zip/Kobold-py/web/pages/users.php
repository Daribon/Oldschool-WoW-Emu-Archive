<?

if (!$sort = &$_GET['s']) $sort="level";
if (!$flag = &$_GET['f']) $flag=0;
if ($flag==1)	{	$flag=0; $sort_type='ASC'; } 
		else	{	$flag=1; $sort_type='DESC'; }
$link=$_SERVER['PHP_SELF']."?f=".$flag."&s=";

$counted = mysql_query("SELECT COUNT(player_guid) FROM char_state WHERE online_state=1;");
$res = mysql_fetch_array($counted);
echo '<br /><div style="background-image: '.$background.'" id="users"><br /><li><font color=#00FF00>'.$res[0].'</font> - <font color="Orange"> Online Characters '.date("H:i:s").' on '.$title.'</li>
<br /><div id="hr"></div>
<div style="overflow:auto; margin-left:5; height:auto">

<table width="99%" height="33" background="'.$background.'">
<tr><tr><tr><tr><tr>
    <td align=left><b><a href="'.$link.'name" class="navlink1">Name</a></font></b></td>
    <td align=center><b><a href="'.$link.'level" class="navlink1">Level</a></font></b></td>
    <td align=center><b><a href="'.$link.'race" class="navlink1">Race</a></font></b></td>
    <td align=center><b><a href="'.$link.'class" class="navlink1">Class</a></font></b></td>
    <td align=left><b><a href="'.$link.'ZoneName" class="navlink1">Zone</a></font></b></td>
</tr>';
?>
<?
$horde = 0;
$alliance = 0;
$races = array(1 => 'Human','Orc','Dwarf','Night Elf','Undead','Tauren','Gnome','Troll','Unknown','Blood Elf','Draenei');
$classes = array(1 => 'Warrior','Paladin','Hunter','Rogue','Priest','Unknown','Shaman','Mage','Warlock','Unknown','Druid');
$query = mysql_query("SELECT `characters`.`name`,`characters`.`level`,`characters`.`race`,`characters`.`class`,`characters`.`zoneId`,`www_zones`.`ZoneName` FROM `characters` Inner Join `char_state` ON `characters`.`guid` = `char_state`.`player_guid` Inner Join `www_zones` ON `characters`.`zoneId` = `www_zones`.`ZoneID` WHERE `char_state`.`online_state` =  1 ORDER BY $sort $sort_type;");
while($ress = mysql_fetch_array($query)) {
	if($ress['race']==1 or $ress['race']==3 or $ress['race']==4 or $ress['race']==7 or $ress['race']==11){
		$race="race1";
		$alliance = $alliance + 1;
	} else {
		$race="race2";
		$horde = $horde + 1;
	}
	if ($ress['level'] >= 60) {
    $border = 1 ;
  } else {
  	$border = 0 ;
  }
	echo '<tr>
    		<td align=left><b><span class="'.$race.'" >'.$ress['name'].'</span></b></td>
    		<td align=center><b><span class="'.$race.'">'.$ress['level'].'</span></b></td>
    		<td align=center><img title="'.$races[$ress['race']].'" border='.$border.' src="'.$image_base.'/Census_'.$races[$ress['race']].'.jpg" alt="'.$races[$ress['race']].'" WIDTH=20 HEIGHT=20></td>
    		<td align=center><img title="'.$classes[$ress['class']].'" border='.$border.' src="'.$image_base.'/Census_'.$classes[$ress['class']].'.jpg" alt="'.$classes[$ress['class']].'" WIDTH=20 HEIGHT=20></td>
    		<td align=left><b><font class="zoneid" >  '.$ress['ZoneName'].'</font></b></td>
  	</tr>
  	';
}
echo '<tr><td align=left><font size = 3 color=#0088EE>'.$alliance.'</font><font size = 2 color="Orange"> Alliance - </font>
<font size = 3 color=#EE0000>'.$horde.'</font><font size = 2 color="Orange"> Horde</td></tr>';

?></table></div></div>
