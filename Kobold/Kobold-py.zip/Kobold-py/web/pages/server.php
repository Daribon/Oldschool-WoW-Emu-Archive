<?

$rtypes = array('Normal','PvP','','','','','RP','','RPPVP');
$rstatus = array('Online','Online','Online','Offline');

if (!$flag = &$_GET['r']) $flag=1;

echo '<br /><div style="background-image: '.$background.'" id="users"><br /><li> Please click  Realm below to see online players</li><br />
<div id="hr"></div>
<div style="overflow:auto; margin-left:5; height:auto">
<table width="99%" height="33" background="'.$background.'">
<tr>
	<td align=left><span class="style4"><b>ID</span></b></td>
	<td align=left><span class="style4"><b>Realm Server</span></b></td>
	<td align=center><span class="style4"><b>Type</span></b></td>
	<td align=center><span class="style4"><b>State</span></b></td>
</tr>';

$query = mysql_query("SELECT realm_list.id, realm_list.name, realm_list.status, realm_list.type, realm_list.address FROM realm_list ORDER BY realm_list.id ASC;");
while($row = mysql_fetch_array($query)) {
	  
  $webport = $web_port + $row['id']  - 1;
  $link="http://".$row['address'].":".$webport."/wow/index.php?action=users";

	if($row['status'] > 2 ) {
		$pcolor="#777777";
		$link=$_SERVER['PHP_SELF']."?action=server"; 
	}
	elseif ($row['status'] == 0)
	  if ($row['type'] == 1 | $row['type'] == 8)
		   $pcolor="#CC1111";
    else 
		   $pcolor="#11BB11";

	echo '
	<tr>
	<td align=left><a href="'.$link.'" class="navlink1"><b><span style="color:'.$pcolor.'">'.$row['id'].'</span></b></a></td>
	<td align=left><a href="'.$link.'" class="navlink1"><b><span style="color:'.$pcolor.'">'.trim($row['name']).'</span></b></a></td>
	<td align=center><a href="'.$link.'" class="navlink1"><b><span style="color:'.$pcolor.'">'.$rtypes[$row['type']].'</span></b></a></td>
	<td align=center><a href="'.$link.'" class="navlink1"><b><span style="color:'.$pcolor.'">'.$rstatus[$row['status']].'</span></b></a></td>
 	</tr>';
}
?></table></div></div>