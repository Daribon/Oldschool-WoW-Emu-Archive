<br />
<div style="background-image: <?=$background ?>" id="patches">
<br /><br /><li>Latest enGB Patches</li>
<br /><div id="hr"></div><br />
<span class="patches2"><? echo $eu_mirror_1_title; ?><br /><div id="patchline"><a class="navlink" href="<? echo $eu_mirror_1_link; ?>"><? echo $eu_mirror_1_desc; ?></a></div></span><br /><br />
<span class="patches2"><? echo $eu_mirror_2_title; ?><br /><div id="patchline"><a class="navlink" href="<? echo $eu_mirror_2_link; ?>"><? echo $eu_mirror_2_desc; ?></a></div></span><br /><br />
<span class="patches2"><? echo $eu_mirror_3_title; ?><br /><div id="patchline"><a class="navlink" href="<? echo $eu_mirror_3_link; ?>"><? echo $eu_mirror_3_desc; ?></a></div></span><br /><br />
<span class="patches2"><? echo $eu_mirror_4_title; ?><br /><div id="patchline"><a class="navlink" href="<? echo $eu_mirror_4_link; ?>"><? echo $eu_mirror_4_desc; ?></a></div></span><br /><br />
<span class="patches2"><? echo $eu_mirror_5_title; ?><br /><div id="patchline"><a class="navlink" href="<? echo $eu_mirror_5_link; ?>"><? echo $eu_mirror_5_desc; ?></a></div></span><br /><br />
<span class="patches2"><? echo $eu_mirror_6_title; ?><br /><div id="patchline"><a class="navlink" href="<? echo $eu_mirror_6_link; ?>"><? echo $eu_mirror_6_desc; ?></a></div></span><br /><br />
</div>