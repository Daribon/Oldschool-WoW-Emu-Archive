<?
echo '<br /><div style="background-image: '.$background.'" id="stats"><br /><li>Statistics on Classes</li>
				<br /><div id="hr"></div>
				<div style="overflow:auto; margin-left:5; height:auto">
				<center><table width="90%" height="33" background="'.$background.'"><br />';
if($show_online)	a(true,$image_base,$show_Width,$show_HeightTotal,$show_HeightNone);
if($show_total)	a(false,$image_base,$show_Width,$show_HeightTotal,$show_HeightNone);

echo '</table></div></div>';

function query($str) {
	global $sql_queries;
	if($sql_queries++ > 10) { echo 'querylimit reached<br>'; return NULL; }

	$r = mysql_query($str) or die("<font color=red><b>Error occured</b>:<br><i>$str</i><br>".mysql_error()."</font>");
	return $r;
}

function a($online,$image_base,$show_Width,$show_HeightTotal,$show_HeightNone) {

	global $cfg;

	$classCount = array(0,0,0,0,0,0,0,0,0,0,0,0);
	$classid = array(1 => 'Warrior', 'Paladin', 'Hunter', 'Rogue', 'Priest', 'Shaman', 'Mage', 'Warlock', 'Druid');

	if($online)
		{
			$users = mysql_result(query("SELECT count(player_guid) AS count FROM `char_state` WHERE online_state = 1"), 0);
			$sql = "SELECT `characters`.`class`, count(`char_state`.`player_guid`) AS count FROM `characters` Inner Join `char_state` ON `characters`.`guid` = `char_state`.`player_guid` WHERE `char_state`.`online_state` = 1 GROUP BY `characters`.`class` ORDER BY `characters`.`class`;";
		}
	else
		{
			$users = mysql_result(query("SELECT count(guid) AS count FROM `characters`"), 0);
			$sql = "SELECT `characters`.`class`, count(`char_state`.`player_guid`) AS count FROM `characters` Inner Join `char_state` ON `characters`.`guid` = `char_state`.`player_guid` GROUP BY `characters`.`class` ORDER BY `characters`.`class`;";
		}

	$q = query($sql);

	echo '<table class=count cellpadding=0 cellspacing=2><tr><th class=big colspan=8><font size = 3 color="Yellow">';
	if($online) echo ' Online'; else echo ' Registered';
	echo '</font></th></tr>';

	while(($row = mysql_fetch_array($q)))
		$classCount[$row['class']] = $row['count'];
		
	foreach ($classid as $tid => $className) {
		if($tid == 9) $id = 11; elseif ($tid > 5) $id = $tid + 1; else $id = $tid;
		echo '<td valign=bottom align=center>';
		echo '<img src="'.$image_base.'/classCount.gif" width='.$show_Width.' height='.(empty($classCount[$id]) ? ($show_HeightNone) : (($show_HeightTotal)  / $users * $classCount[$id])).' alt='.$classCount[$id].'>';
	}	
	echo '<tr>';
	
	foreach ($classid as $className) {
		echo '<td align=center><img title="'.$className.'" border=0 src="'.$image_base.'/Census_'.$className.'.jpg" alt="'.$className.'" WIDTH=30 HEIGHT=30>';
	}	

	echo '<tr>';

	foreach ($classid as $tid => $className) {
  if($tid == 9) $id = 11; elseif ($tid > 5) $id = $tid + 1; else $id = $tid;
	echo '<td align=center>'.$classCount[$id];
	}	

	echo '</table>';
}
?>