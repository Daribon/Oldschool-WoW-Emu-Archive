<?
$sessionkey = mysql_query("SELECT 1 FROM `accounts` WHERE `sessionkey` = '$cp[3]'") or die('SQL error: ' . mysql_error());
$validkey = mysql_num_rows($sessionkey);

if ($validkey > 0) {
	    echo '<br />
       <form action="index.php?action=gmportal" method="post">
        <table>
           <tr>
               <td colspan="2" align="center">
                   <div align="center" >Restart Service (Login or Realm):</div>
               </td>
           </tr>
           <tr>
               <td align="right">
                   LS or RS:
               </td>
               <td align="left">
                   <input id="textarea" type="text" maxlength="16" name="killserv"><input id="buttons" type="submit" value="Kill">
               </td>
               <td align="left">
                   <input type="reset" id="buttons" name="Clear" value="Clear">          </tr>
              </td>
          </table>
       </form>';
} else {
     echo '<div class=\"error\">sessionkey don\'t match</div><br />';
}
?>