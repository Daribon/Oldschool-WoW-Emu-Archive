<?
$sessionkey = mysql_query("SELECT 1 FROM `accounts` WHERE `sessionkey` = '$cp[3]'") or die('SQL error: ' . mysql_error());
$validkey = mysql_num_rows($sessionkey);

if ($validkey > 0) {
	    echo '<br />
       <form action="index.php?action=gmportal" method="post">
        <table>
          <tr>
              <td colspan="2" align="center">
                  <div align="center" >(Un)lock character:</div>
                  <div align="center" >Leave empty to view bannlist:</div>
              </td>
          </tr>
          <tr>
              <td align="right">
                   LockName:
              </td>
              <td align="left">
                   <input id="textarea" type="text" maxlength="16" name="lockname"><input id="buttons" type="submit" value="Lock">
              <td align="center">
                   <input type="reset" id="buttons" name="Clear" value="Clear">
              </td>
           </tr>
       </form>';
} else {
     echo '<div class=\"error\">sessionkey don\'t match</div><br />';
}
?>