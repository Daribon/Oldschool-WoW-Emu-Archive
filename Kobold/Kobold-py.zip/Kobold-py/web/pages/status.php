<br /><div style="background-image: '.$background.'" id="users"><br /><li> Server status</li><br />
<div id="hr"></div>
<div style="overflow:auto; margin-left:5; height:auto">
<table width="99%" height="33" background="'.$background.'">
<tr>
	<td align=left><span class="style4"><b>StartDate,Time        TaskName  Elapsed Mem</b></span></td>
</tr>
<?
echo '<tr><td>'.exec('pv -o"%d\t%n\t%e\t%m[Kb]" _logonserver.exe').'</td></tr>';
echo '<tr><td>'.exec('pv -o"%d\t%n\t%e\t%m[Kb]" _realmserver.exe').'</td></tr>';
echo '<tr><td>'.exec('pv -o"%d\t%n\t%e\t%m[Kb]" _worldserver.exe').'</td></tr>';
?>
</table></div></div>