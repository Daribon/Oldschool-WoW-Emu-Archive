<?
$sessionkey = mysql_query("SELECT 1 FROM `accounts` WHERE `sessionkey` = '$cp[3]'") or die('SQL error: ' . mysql_error());
$validkey = mysql_num_rows($sessionkey);

if ($validkey > 0) {
      echo '<br />
       <form action="index.php?action=gmportal" method="post">
        <table>
          <tr>
               <td colspan="2" align="center">
                   <div align="center" >Reset bindpoint for:</div>
               </td>
         </tr>
         <tr>
               <td align="right">
                   Character Name:
               </td>
               <td align="left">
                   <input id="textarea" type="text" maxlength="10" name="charname">
               </td>
          <tr>
               <td colspan="2" align="center">
                   <div align="right">
                       <input id="buttons" type="submit" value="reset bindpoint">
                       <input type="reset" id="buttons" name="Clear" value="Clear">
                   </div>
               </td>
          </tr>
          <tr>
              <td colspan="2" align="center">
                  <div align="center" >(Un)lock character:</div>
              </td>
          </tr>
          <tr>
              <td align="right">
                   LockName:
              </td>
              <td align="left">
                   <input id="textarea" type="text" maxlength="10" name="lockname">
              </td>
          </tr>
          <tr>
              <td align="right">
                   UnlockName:
              </td>
              <td align="left">
                   <input id="textarea" type="text" maxlength="10" name="unlockname">
               </td>
          <tr>
               <td colspan="2" align="center">
                   <div align="right">
                       <input id="buttons" type="submit" value="Lock Char">
                       <input id="buttons" type="submit" value="Unlock Char">
                       <input type="reset" id="buttons" name="Clear" value="Clear">
                   </div>
               </td>
          </tr>
          <tr>
               <td colspan="2" align="center">
                   <div align="center" >(Un)Ban IP:</div>
               </td>
          </tr>
          <tr>
               <td align="right">
                   UnBan IP:
               </td>
               <td align="left">
                   <input id="textarea" type="text" maxlength="16" name="UnBannIP">
               </td>
           <tr>
               <td align="right">
                   Ban IP:
               </td>
               <td align="left">
                   <input id="textarea" type="text" maxlength="16" name="BannIP">
               </td>
           <tr>
               <td align="right">
                   Reason:
               </td>
               <td align="left">
                   <input id="textarea" type="text" maxlength="80" name="Breason">
               </td>
           </tr>
           <tr>
               <td colspan="2" align="center">
                  <div align="center">Leave empty to view bannlist:</div>
                  <div align="right">
                      <input id="buttons" type="submit" value="Unbann IP">
                      <input id="buttons" type="submit" value="Bann IP">
                      <input type="reset" id="buttons" name="Clear" value="Clear">
                  </div>
               </td>
           </tr>
           <tr>
               <td colspan="2" align="center">
                   <div align="center" >Restart Service (Login or Realm):</div>
               </td>
           </tr>
           <tr>
               <td align="right">
                   LS or RS:
               </td>
               <td align="left">
                   <input id="textarea" type="text" maxlength="16" name="kill_service">
               </td>
             <tr>
               <td colspan="2" align="center">
                   <div align="right">
                   <input id="buttons" type="submit" value="kill_service">
                   <input type="reset" id="buttons" name="Clear" value="Clear">
                   </div>
               </td>
            </tr>
         </table>
       </form>';
} else {
     echo '<div class=\"error\">sessionkey don\'t match</div><br />';
}
?>