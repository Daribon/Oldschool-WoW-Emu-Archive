<?
$sessionkey = mysql_query("SELECT 1 FROM `accounts` WHERE `sessionkey` = '$cp[3]'") or die('SQL error: ' . mysql_error());
$validkey = mysql_num_rows($sessionkey);

if ($validkey > 0) {
	    echo '<br />
       <form action="index.php?action=gmportal" method="post">
          <tr>
               <td align="right">
                   UnBan IP:
               </td>
               <td align="left">
                   <input id="textarea" type="text" maxlength="16" name="UnBannIP"><input id="buttons" type="submit" value="Unban">
               </td>
               <td align="center">
                   <input type="reset" id="buttons" name="Clear" value="Clear">
               </td>
           </tr>
        </table>
       </form>';
} else {
     echo '<div class=\"error\">sessionkey don\'t match</div><br />';
}
?>