<?
echo '<br /><div style="background-image: '.$background.'" id="stats"><br /><li>Statistics on Races</li>
				<br /><div id="hr"></div>
				<div style="overflow:auto; margin-left:5; height:auto">
				<center><table width="90%" height="33" background="'.$background.'"><br />';
if($show_online)	a(true,$image_base,$show_Width,$show_HeightTotal,$show_HeightNone);
if($show_total)	a(false,$image_base,$show_Width,$show_HeightTotal,$show_HeightNone);
echo '</table></div></div>';

function query($str) {
	global $sql_queries;
	if($sql_queries++ > 10) { echo 'querylimit reached<br>'; return NULL; }

	$r = mysql_query($str) or die("<font color=red><b>Error occured</b>:<br><i>$str</i><br>".mysql_error()."</font>");
	return $r;
}

function a($online,$image_base,$show_Width,$show_HeightTotal,$show_HeightNone) {

	$raceCount = array(0,0,0,0,0,0,0,0,0,0,0);
  $raceid = array(1 => 'Human', 'Orc', 'Dwarf', 'Night Elf', 'Undead', 'Tauren', 'Gnome', 'Troll', 'Blood Elf', 'Draenei');

	if($online)
		{
			$users = mysql_result(query("SELECT count(player_guid) AS count FROM `char_state` WHERE online_state = 1"), 0);
			$sql = "SELECT `characters`.`race`, count(`char_state`.`player_guid`) AS count FROM `characters` Inner Join `char_state` ON `characters`.`guid` = `char_state`.`player_guid` WHERE `char_state`.`online_state` = 1 GROUP BY `characters`.`race` ORDER BY `characters`.`race`;";
		}
	else
		{
			$users = mysql_result(query("SELECT count(guid) AS count FROM `characters`"), 0);
			$sql = "SELECT `characters`.`race`, count(`char_state`.`player_guid`) AS count FROM `characters` Inner Join `char_state` ON `characters`.`guid` = `char_state`.`player_guid` GROUP BY `characters`.`race` ORDER BY `characters`.`race`;";
		}

	$q = query($sql);
  $Tot = 0;
  $Alliance = 0;

	echo '<table class=count cellpadding=0 cellspacing=2><tr><th class=big colspan=8><font size = 3 color="Yellow">';
	if($online) echo ' Online'; else echo ' Registered';
	echo '</font></th></tr>';
	
	while(($row = mysql_fetch_array($q)))
		$raceCount[$row['race']] = $row['count'];
	
	foreach ($raceid as $tid => $raceName) {
 		if($tid > 8) $id = $tid + 1; else $id = $tid;
		echo '<td valign=bottom align=center>';
		echo '<img src="'.$image_base.'/raceCount.gif" width='.$show_Width.' height=' . (empty($raceCount[$id]) ? ($show_HeightNone) : ($show_HeightTotal  / $users * $raceCount[$id])).' alt='.$raceCount[$id].'>';
		$Tot = $Tot + $raceCount[$id];
		if($id ==  1 || $id ==  3 || $id ==  4 || $id ==  7 || $id == 11 ) $Alliance = $Alliance + $raceCount[$id];
	}	
	echo '<tr>';
	
	foreach ($raceid as $raceName) {
		echo '<td align=center><img title="'.$raceName.'" border=0 src="'.$image_base.'/Census_'.$raceName.'.jpg" alt="'.$raceName.'" WIDTH=30 HEIGHT=30>';
	}	

	echo '<tr>';

	foreach ($raceid as $tid => $raceName) {
		if($tid > 8) $id = $tid + 1; else $id = $tid;
 		echo '<td align=center>'.max(0, $raceCount[$id]);
	}	
	$Horde = $Tot - $Alliance;
  echo '</table>
  <font size = 3 color=#0088EE>'.$Alliance.'</font><font size = 2 color="Orange"> Alliance - </font><font size = 3 color=#EE0000>'.$Horde.'</font><font size = 2 color="Orange"> Horde <br /><br />';
}

?>