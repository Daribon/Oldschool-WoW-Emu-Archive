<?
echo '<br />
<div class=\"style4\">Please Login below</div>
<form action="index.php?action=gmportal" method="post">
    <table>
         <tr>
             <td align="right">
                 Username:
             </td>
             <td align="left">
                 <input id="textarea" type="text" maxlength="10" name="username">
             </td>
         </tr>
         <tr>
             <td align="right">
                 Password:
             </td>
             <td align="left">
                 <input id="textarea" type="password" maxlength="10" name="password">
             </td>
         </tr>
         <tr>
             <td colspan="2" align="center">
                 <div align="right">
                     <input id="buttons" type="submit" value="Login">
                     <input type="reset" id="buttons" name="Clear" value="Clear">
                 </div>
             </td>
         </tr>
    </table>
</form>';
?>