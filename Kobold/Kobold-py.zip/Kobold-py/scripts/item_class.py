# This file contains functions for GameObject class

from Ludmilla import *   # Import Ludmilla namespace
import consts as co    # Import of constants
reload(co)             
from random import *     # Import random generator module
import const_skills as co_skill    # Import of constants
reload(co_skill)         

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

printLog( "  o Registerring Item Class" )

# ####################################################################################
# used to help Core to select right loot for Disenchanting 
#     
def GenerateLoot_DisEnchanting(item, player):
    
    # Get Player & Disenchanted Item attributes
    p_level = player.GetLevel()
    
    i_model = item.GetModel()
    i_entry = item.GetEntry()
    i_class = item.GetItemClass()
    i_subclass = item.GetItemSubClass()
    i_quality = item.GetItemQuality()
    i_level = item.GetItemLevel()
    i_inv_type = item.GetInventoryType()
    i_reqlvl = item.GetRequiredLevel()
    print "Item: E[%s] L[%s] T[%s] M[%s] C[%s] SC[%s] Q[%s]" % (i_entry, i_level, i_inv_type, i_model, i_class, i_subclass, i_quality)
    
    printLog( "disenchanting loot: for player: level[%s]" % (p_level) )
    
    
    # check if item can be disenchanted
    '''
    patch: 2.0.1
    - Skill level now determines what items you can disenchant.
      - Skill 1= Level 1-20
      - Skill 25= Level 20-25
      - Skill 50= Level 25-30
      - Skill 75= Level 30-35
      - Skill 100= Level 35-40
      - Skill 125= Level 40-45
      - Skill 150= Level 45-50
      - Skill 175= Level 50-55
      - Skill 200= Level 55-60
      - Skill 225= Level 60-65
      
    '''
    skill = player.GetSkill(co_skill.SKILL_ENCHANTING)
    can_disenchant = FALSE

    if   skill > 225 and i_level >= 55 and i_level <= 65: can_disenchant = TRUE
    elif skill > 200 and i_level >= 55 and i_level <= 60: can_disenchant = TRUE
    elif skill > 175 and i_level >= 50 and i_level <= 55: can_disenchant = TRUE
    elif skill > 150 and i_level >= 45 and i_level <= 50: can_disenchant = TRUE
    elif skill > 125 and i_level >= 40 and i_level <= 45: can_disenchant = TRUE
    elif skill > 100 and i_level >= 35 and i_level <= 40: can_disenchant = TRUE
    elif skill > 75  and i_level >= 30 and i_level <= 35: can_disenchant = TRUE
    elif skill > 50  and i_level >= 25 and i_level <= 30: can_disenchant = TRUE    
    elif skill > 25  and i_level >= 20 and i_level <= 25: can_disenchant = TRUE
    elif skill > 1   and i_level >= 1  and i_level <= 20: can_disenchant = TRUE
    
    # this will send error to player saying that item can't be disenchanted
    if can_disenchant == FALSE: 
        item.ClearLootTable()
        return
    
    # REAGENTS ###########################
    #------------------------------
    # Dust
    #------------------------------
    STRANGE_DUST            = 10940
    SOUL_DUST               = 11083
    VISION_DUST             = 11137
    DREAM_DUST              = 11176
    ILLUSION_DUST           = 16204

    #------------------------------
    # Essence
    #------------------------------
    LESSER_MAGIC_ESSENCE    = 10938
    GREATER_MAGIC_ESSENCE   = 10939
    LESSER_ASTRAL_ESSENCE   = 10998
    GREATER_ASTRAL_ESSENCE  = 11082
    LESSER_MYSTIC_ESSENCE   = 11134
    GREATER_MYSTIC_ESSENCE  = 11135
    LESSER_NETHER_ESSENCE   = 11174
    GREATER_NETHER_ESSENCE  = 11175
    LESSER_ETERNAL_ESSENCE  = 16202
    GREATER_ETERNAL_ESSENCE = 16203

    
    #------------------------------
    # Shards
    #------------------------------
    SMALL_GLIMMERING_SHARD  = 10978
    LARGE_GLIMMERING_SHARD  = 11084
    SMALL_GLOWING_SHARD     = 11138
    LARGE_GLOWING_SHARD     = 11139
    SMALL_RADIANT_SHARD     = 11177
    LARGE_RADIANT_SHARD     = 11178
    SMALL_BRILLIANT_SHARD   = 14343
    LARGE_BRILLIANT_SHARD   = 14344

    #------------------------------
    # Epixxx! :)
    #------------------------------
    NEXUS_CRYSTAL           = 20725

    # ##################################
    
    # Adding Item To Loot (DEFAULT AS AN EXAMPLE!)
    #item.AddItemToLoot( REAGENT_SMALL_GLIMMERING_SHARD, 1 )
    
    reagent = None

    # Chance % to get alternate class of reagents on disenchant
    ALTERNATE_CHANCE        = 5

    alt         = (randrange(100) < ALTERNATE_CHANCE)   # chance to get alternate itemclass dis loot
    altquality  = (randrange(100) < ALTERNATE_CHANCE)   # chance to get alternate quality dis loot

    #---------------------------------
    # GREEN ITEMS GO HERE
    #---------------------------------
    if i_quality == co.ITEM_QUALITY_UNCOMMON and not altquality:
        # Dusts usually are extracted from armors, but also occasionally found from weapons.
        #
        if (i_class in [co.ITEM_CLASS_ARMOR, co.ITEM_CLASS_JEWELRY] and not alt) or \
            (i_class == co.ITEM_CLASS_WEAPON and alt):

            if i_reqlvl <= 20:   reagent = STRANGE_DUST, randrange(2,5)
            elif i_reqlvl <= 30: reagent = SOUL_DUST, randrange(2,5)
            elif i_reqlvl <= 40: reagent = VISION_DUST, randrange(2,5)            
            elif i_reqlvl <= 50: reagent = DREAM_DUST, randrange(2,5)
            else:               reagent = ILLUSION_DUST, randrange(2,5)

        # Essences usually are extracted from weapons, but also occasionally found from armors.
        #
        if (i_class in [co.ITEM_CLASS_ARMOR, co.ITEM_CLASS_JEWELRY] and alt) or \
            (i_class == co.ITEM_CLASS_WEAPON and not alt):

            if i_reqlvl <= 10: reagent = LESSER_MAGIC_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 15: reagent = GREATER_MAGIC_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 20: reagent = LESSER_ASTRAL_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 25: reagent = GREATER_ASTRAL_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 30: reagent = LESSER_MYSTIC_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 35: reagent = GREATER_MYSTIC_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 40: reagent = LESSER_NETHER_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 45: reagent = GREATER_NETHER_ESSENCE, randrange(1,3)
            elif i_reqlvl <= 50: reagent = LESSER_ETERNAL_ESSENCE, randrange(1,3)
            else: reagent = GREATER_ETERNAL_ESSENCE, randrange(1,3)

    # Blue loots and alternate quality (chance on disenchant) green loots give shards
    #
    if i_quality >= co.ITEM_QUALITY_RARE or altquality:
        if i_reqlvl <= 20: reagent = SMALL_GLIMMERING_SHARD, 1
        elif i_reqlvl <= 25: reagent = LARGE_GLIMMERING_SHARD, 1
        elif i_reqlvl <= 30: reagent = SMALL_GLOWING_SHARD, 1
        elif i_reqlvl <= 35: reagent = LARGE_GLOWING_SHARD, 1
        elif i_reqlvl <= 40: reagent = SMALL_RADIANT_SHARD, 1
        elif i_reqlvl <= 45: reagent = LARGE_RADIANT_SHARD, 1
        elif i_reqlvl <= 50: reagent = SMALL_BRILLIANT_SHARD, 1
        else:
            if i_quality == co.ITEM_QUALITY_LEGENDARY:
                reagent = NEXUS_CRYSTAL, randrange(2,3)
            elif i_quality == co.ITEM_QUALITY_EPIC or randrange(100) < 2:
                reagent = NEXUS_CRYSTAL, 1
            else:
                reagent = LARGE_BRILLIANT_SHARD, 1

    item.ClearLootTable()
    if reagent is not None:
        item.AddItemToLoot (reagent[0], reagent[1])
    #else:
        # BUGFIX: Change this fix to no-disenchant on wrong items
        # If item is wrong for disenchanting, we loot item itself :)
        #item.AddItemToLoot (i_entry, 1)
    # now server (on empty Loot) will throw Red message that Item can't be Disenchanted and Item will stay in place not touched

# -- EOF --
