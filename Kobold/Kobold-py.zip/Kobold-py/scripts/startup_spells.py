#
# This module is executed on Ludmilla startup
#

from Ludmilla import *
from const_spells import *
from spell_class import *
import spell_class as spell_c    # Import of Spell Class Module
reload(spell_c)  
import const_spells as spell_co     # Import of constants (skills)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name) 

# ####################################################################################
# Initialise Spell Effect Registration
spell_c.RegisterSpellEffectsOnStartup()


# ####################################################################################
# Disable malfunctioning spells

print "  o Disabling bugged spells :"

import spells.Disabled
DisabledSpell = spells.Disabled
reload (DisabledSpell)
# RegisterSpellClass ( XXXXX , DisabledSpell.Spell_disabled())

RegisterSpellClass (15007, DisabledSpell.Spell_disabled()) #Resurrection Sickness
#RegisterSpellClass (1515, DisabledSpell.Spell_disabled())
#RegisterSpellClass (688, DisabledSpell.Spell_disabled())
RegisterSpellClass (20912, DisabledSpell.Spell_disabled()) #Resurrection Sickness
RegisterSpellClass (20913, DisabledSpell.Spell_disabled())
RegisterSpellClass (20914, DisabledSpell.Spell_disabled())
RegisterSpellClass (27168, DisabledSpell.Spell_disabled()) #Resurrection Sickness
RegisterSpellClass (20911, DisabledSpell.Spell_disabled())
RegisterSpellClass (25899, DisabledSpell.Spell_disabled())
RegisterSpellClass (27169, DisabledSpell.Spell_disabled())
RegisterSpellClass (31252, DisabledSpell.Spell_disabled())
RegisterSpellClass (31032, DisabledSpell.Spell_disabled())
RegisterSpellClass (32177, DisabledSpell.Spell_disabled())
31252
#Initialise Spell Overwriting Modules Registration
print " o Setting up Spell handlers :"

import spells.HammerOfWrath
HammerOfWrath = spells.HammerOfWrath
reload (HammerOfWrath)
# Hammer of Wrath
RegisterSpellClass (24275, HammerOfWrath.Spell_HammerOfWrath())
RegisterSpellClass (24274, HammerOfWrath.Spell_HammerOfWrath())
RegisterSpellClass (24239, HammerOfWrath.Spell_HammerOfWrath())

#----------------------------------------------------------

printLog("*** LastStand...")

import spells.LastStand
LastStand = spells.LastStand
reload (LastStand)

RegisterSpellClass (12975, LastStand.Spell_Last_Stand())
RegisterSpellClass (12976, LastStand.Spell_Last_Stand_1()) 

#----------------------------------------------------------
#printLog("*** Rockbiter...") 
 
#import spells.rockbiter 
#rockbiter = spells.rockbiter 
#reload (rockbiter) 
 
#RegisterSpellClass (8017, rockbiter.Spell_ROCKBITER_WEAPON_RANK_1()) # Rank 1 
#RegisterSpellClass (8018, rockbiter.Spell_ROCKBITER_WEAPON_RANK_2()) # Rank 2 
#RegisterSpellClass (8019, rockbiter.Spell_ROCKBITER_WEAPON_RANK_3()) # Rank 3 
#RegisterSpellClass (10399, rockbiter.Spell_ROCKBITER_WEAPON_RANK_4()) # Rank 4 
#RegisterSpellClass (10402, rockbiter.Spell_ROCKBITER_WEAPON_RANK_5()) # Rank 5 
#RegisterSpellClass (16315, rockbiter.Spell_ROCKBITER_WEAPON_RANK_6()) # Rank 6 
#RegisterSpellClass (16316, rockbiter.Spell_ROCKBITER_WEAPON_RANK_7()) # Rank 7 
  
#----------------------------------------------------------
print "*** Wisp Form..."

import spells.WispSpirit
WispSpirit = spells.WispSpirit
reload (WispSpirit)

RegisterSpellClass (20585, WispSpirit.Spell_WISP_SPIRIT_RACIAL_PASSIVE())

#----------------------------------------------------------
printLog("*** GM helper Auto UnStuck...")

import spells.UnStuck
UnStuck = spells.UnStuck
reload (UnStuck)

RegisterSpellClass (7355, UnStuck.Spell_UnStuck())

#----------------------------------------------------------
printLog("*** PolymorphChicken...")

import spells.PolymorfChicken
PolymorfChicken = spells.PolymorfChicken
reload (PolymorfChicken)

RegisterSpellClass (228, PolymorfChicken.Spell_PolymorphChicken())

# ####################################################################################
#----------------------------------------------------------
printLog("*** Skills...")
import spells.TrainSkill
TrainSkill = spells.TrainSkill
reload (TrainSkill)
RegisterSpellClass (11612, TrainSkill.Spell_ArtisanAlchemy()) # Rank 4
RegisterSpellClass (9786, TrainSkill.Spell_ArtisanBlacksmithing()) # Rank 4
RegisterSpellClass (18261, TrainSkill.Spell_ArtisanCooking()) # Rank 4
RegisterSpellClass (13921, TrainSkill.Spell_ArtisanEnchanting()) # Rank 4
RegisterSpellClass (12657, TrainSkill.Spell_ArtisanEngineering()) # Rank 4
RegisterSpellClass (10847, TrainSkill.Spell_ArtisanFirstaid()) # Rank 4
RegisterSpellClass (18249, TrainSkill.Spell_ArtisanFishing()) # Rank 4
RegisterSpellClass (11994, TrainSkill.Spell_ArtisanHerbalism()) # Rank 4
RegisterSpellClass (10663, TrainSkill.Spell_ArtisanLeatherworking()) # Rank 4
RegisterSpellClass (10249, TrainSkill.Spell_ArtisanMining()) # Rank 4
RegisterSpellClass (10769, TrainSkill.Spell_ArtisanSkinning()) # Rank 4
RegisterSpellClass (12181, TrainSkill.Spell_ArtisanTailoring()) # Rank 4
#RegisterSpellClass (12691, TrainSkill.Spell_ArtisanGEMOLOGY()) # Rank 4    (need to be added)
RegisterSpellClass (28597, TrainSkill.Spell_MasterAlchemy()) # Rank 5
RegisterSpellClass (29845, TrainSkill.Spell_MasterBlacksmithing()) # Rank 5
RegisterSpellClass (33360, TrainSkill.Spell_MasterCooking()) # Rank 5
RegisterSpellClass (28030, TrainSkill.Spell_MasterEnchanting()) # Rank 5
RegisterSpellClass (30351, TrainSkill.Spell_MasterEngineering()) # Rank 5
RegisterSpellClass (27029, TrainSkill.Spell_MasterFirstaid()) # Rank 5
RegisterSpellClass (33098, TrainSkill.Spell_MasterFishing()) # Rank 5
RegisterSpellClass (28696, TrainSkill.Spell_MasterHerbalism()) # Rank 5
RegisterSpellClass (32550, TrainSkill.Spell_MasterLeatherworking()) # Rank 5
RegisterSpellClass (29355, TrainSkill.Spell_MasterMining()) # Rank 5
RegisterSpellClass (32679, TrainSkill.Spell_MasterSkinning()) # Rank 5
RegisterSpellClass (26791, TrainSkill.Spell_MasterTailoring()) # Rank 5


# ###############################################################################

printLog("*** Initializing the spell handlers for Proffesion Skills...")



print " o Aura Handlers:" 

import spells.auras.SpellAuraDummy
AuraDummy = spells.auras.SpellAuraDummy
reload (AuraDummy)
RegisterAuraHandler( spell_co.SPELL_AURA_DUMMY, AuraDummy.AuraHandler() )

import spells.auras.SpellAuraAddFlatModifier
AURAFLAT = spells.auras.SpellAuraAddFlatModifier
reload (AURAFLAT)
RegisterAuraHandler( spell_co.SPELL_AURA_ADD_FLAT_MODIFIER, AURAFLAT.AuraHandler() )

import spells.auras.SpellAuraModDamagePercentTaken
AURATAKEN = spells.auras.SpellAuraModDamagePercentTaken
reload (AURATAKEN)
RegisterAuraHandler( spell_co.SPELL_AURA_MOD_DAMAGE_PERCENT_TAKEN, AURATAKEN.AuraHandler() )

import spells.auras.SpellAuraTrackCreatures
AURATRACK = spells.auras.SpellAuraTrackCreatures
reload (AURATRACK)
RegisterAuraHandler( spell_co.SPELL_AURA_TRACK_CREATURES, AURATRACK.AuraHandler() )

#
#
#





 ####################################################################################
print " o Spell scripting system ready to be used" 
print " " 

# We do not play with Spell Scripts before Core gets fixed with Spell Effects and Auras

#--- END ---
