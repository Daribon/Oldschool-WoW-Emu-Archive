# COPYRIGHT (C) 2006 LUDMILLA TEAM
from Ludmilla import *          # Import server environment
from random import *            # Randomiser Import
import consts as co             # Import of constants
reload(co)   
import const_skills as skill_co # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co # Import of constants (skills)
reload(spell_co)  
import opcodes as opcode
reload(opcode)

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

# EXAMPLE
#packet = InitialisePacket(707)
#packet.uint8(1)
#packet.uint16(0)
#packet.uint32(2)
#packet.uint64(0x0xf000100000000011)
#packet.string("Hello World!)
#packet.Send(unit)

# SMSG_AREA_TRIGGER_MESSAGE
def make_SMSG_AREA_TRIGGER_MESSAGE (unk_1, text):
    print "SMSG_AREA_TRIGGER_MESSAGE"
    packet = InitialisePacket(opcode.SMSG_AREA_TRIGGER_MESSAGE)
    packet.uint32(unk_1)
    packet.string(text)
    return packet

def make_SMSG_PLAY_SOUND (sound_effect_id):
    print "SMSG_PLAY_SOUND"
    packet = InitialisePacket(opcode.SMSG_PLAY_SOUND)
    packet.uint32(sound_effect_id)
    return packet

def make_SMSG_SET_FACTION_STANDING (flags,reputationID,standing):
    print "SMSG_SET_FACTION_STANDING"
    packet = InitialisePacket(opcode.SMSG_SET_FACTION_STANDING) 
    packet.uint32(flags)
    packet.uint32(reputationID)  
    packet.uint32(standing)
    return packet
# -- EOF --
    
    
