# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *
from random import *
from consts import *
from player_class import *
import packet_class as packet_builder         # Import of supporting functions
reload(packet_builder)  
import consts as co                           # Import of constants
reload(co)   
import config as cfg                          # Import of configuration constants
reload(cfg)  
import support as support                     # Import supporting scripts
reload(support)  

import MySQLdb
conn = MySQLdb.connect (host = cfg.MYSQL_HOST, user = cfg.MYSQL_USER, passwd = cfg.MYSQL_PASSWD, db = cfg.MYSQL_DB)

printLog("  o Setting up EXE modules :")
printLog("   -> Registering Elite Reputatation")
printLog("   -> Registering Quest Reputatation")

# ###########################################################################################
# Calc Elite Reputation, used to help core calculate reputation for killing elites
def CalcReputation(self, victim):
    if cfg.PLAYER_REP_FIX:
        if victim.GetElite() > 0:
    
             ELITE = victim.GetElite()
             RepGained = 5  # Reputation base
    
             # Multiply based on elite_type
             if      ELITE == co.CREATURE_ELITE_ELITE:      RepGained *= 5
             elif    ELITE == co.CREATURE_ELITE_RAREELITE:  RepGained *= 10
             elif    ELITE == co.CREATURE_ELITE_WORLDBOSS:  RepGained *= 20
             elif    ELITE == co.CREATURE_ELITE_RARE:       RepGained *= 40
         
             # Reduce reputation if friendly
             if victim.GetReputationStandingByFactionTemplateId(self.GetFaction()) >= co.FACTION_STANDING_FRIENDLY:
                 RepGained = 0 - RepGained
             
             # Update reputation & notify client
             RepID = GetPlayerDefaultReputationID(self)
             UpdateReputation(self, RepID , RepGained )
             
             print "Reputation Elite:player [%s] gained [%d] on [%s] for ID [%d]" % (self.GetName(),RepGained,victim.GetName(), RepID)
    
# ###########################################################################################
# Calc Quest Reputation, used to help core calculate reputation for quests
def CalcQuestReputation(giver, player, questid ):

    # Collect variables
    quest_behavior = GetQuestSQL_questBehavior(questid)
    quest_level = GetQuestSQL_questLevel(questid)
    quest_faction = giver.GetFaction()
    quest_reputationID = Reputation_ID(quest_faction) #Quest givers reputationID

    # Reputation base
    quest_reputation_reward = 25  
    if      support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_REPUTATION):       quest_reputation_reward *= 10
    elif    support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_REPEATABLE):       quest_reputation_reward *= 10          
    elif    support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_TIMED):            quest_reputation_reward *= 10
    elif    support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_KILL):             quest_reputation_reward *= 10
    elif    support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_SPEAKTO):          quest_reputation_reward *= 2
    elif    support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_EXPLORE):          quest_reputation_reward *= 2
    elif    support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_DELIVER):          quest_reputation_reward *= 3
    elif    support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_UNDEFINED):        quest_reputation_reward *= 2
    quest_reputation_reward -= 25 #substract 25 from result, as client already got some basic reputation from core

    # Replace default faction/reward by custom values, if found ( see def GetCustomQuest() below)
    quest_cust = GetCustomQuest(questid)
    if quest_cust:
        y = 0
        for x in quest_cust:
            quest_faction = quest_cust[y][0]
            quest_reputation_reward = quest_cust[y][1]
            quest_reputationID = Reputation_ID(quest_faction) #Quest givers reputationID
            quest_reputation_reward *= ReputationModifier(player, quest_level )
            UpdateReputation(player, quest_reputationID, quest_reputation_reward )       
            quest_reputation_reward -= 25 #substract 25 from result, as client already got some basic reputation from core
            y += 1
            print "Reputation QuestID:[%d] Behaviour [%d] gained [%d] on player:[%s]" % (questid, quest_behavior, quest_reputation_reward, player.GetName())
        return

    # Reduce according difference between questlevel & playerlevel
    quest_reputation_reward *= ReputationModifier(player, quest_level )

    # Update reputation & notify client
    UpdateReputation(player, quest_reputationID, quest_reputation_reward )       

    # Add additional reputation for affiliate factions
    if support.HasFlags(quest_behavior, co.QUEST_BEHAVIOR_REPEATABLE):
        reputationgroups = [[1,7,9,28],[18,19,20,21,49],[14,15,16,17,55],
                           [40,45,53],[41,46,52],[39,58,62],[37,38,60,61,64,65,66]] #default reputation groups for all sides
        for x in reputationgroups:
            if quest_reputationID in x:
                for repids in x:                    
                    if repids <> quest_reputationID:
                        UpdateReputation(player, repids , (quest_reputation_reward * 0.25))

    print "Reputation QuestID:[%d] Behaviour [%d] gained [%d] on player:[%s]" % (questid, quest_behavior, quest_reputation_reward, player.GetName())

# ###########################################################################################
# Reduce modifier according difference between questlevel & playerlevel
# 
def ReputationModifier(player, quest_level ):
    lvldiff = player.GetLevel() - quest_level
    modifier = 1
    if lvldiff   >=9 : modifier = 0.20
    elif lvldiff >=8 : modifier = 0.40
    elif lvldiff >=7 : modifier = 0.60
    elif lvldiff >=6 : modifier = 0.80
    return modifier

# ###########################################################################################
# Update reputation , send updated value to client
def UpdateReputation(player, reputationID, reputation_reward ):

     # Add gained reputation to reputationID of given faction
     player.SetReputationValue(reputationID, player.GetReputationValue(reputationID) + reputation_reward )

     # Update new Reputation on client side
     packet = packet_builder.make_SMSG_SET_FACTION_STANDING(GetRepFlagSQL(player), reputationID, player.GetReputationValue(reputationID))
     packet.Send(player)
 
# ###########################################################################################
# Get reputation Flags for players faction
def GetRepFlagSQL(player):
    cursor = conn.cursor ()
    cursor.execute ("SELECT flags FROM char_reputation WHERE PlayerId = " + str(player.GetGUIDUInt64()) + " AND ReputationId = " + str(GetPlayerDefaultReputationID(player)))
    row = cursor.fetchone ()
    cursor.close ()
    if row:
      return row[0]

# ###########################################################################################
# Get required faction values from sql for given quest
def GetRepFactVals(questid):
    cursor = conn.cursor ()
    cursor.execute ("SELECT repFaction1,repvalue1,repFaction2,repvalue2 FROM quests WHERE questId = " + str(questid))
    row = cursor.fetchone ()
    cursor.close ()
    if row:
        return row

# ###########################################################################################
# Get required faction values from sql for given quest
def PlayerReputationValueByFactionId(player,faction):
    cursor = conn.cursor ()
    cursor.execute ("SELECT standing FROM char_reputation WHERE PlayerId = " + str(player.GetGUIDUInt64()) + " AND factionID = " + str(faction))
    row = cursor.fetchone ()
    cursor.close ()
    if row:
        return row[0]
    
# ###########################################################################################
# Extracts QuestLevel from sql
def GetQuestSQL_questLevel(quest_id):

    cursor = conn.cursor ()
    cursor.execute ("SELECT `quests`.`questLevel` FROM `quests` WHERE `quests`.`questId` = " + str(quest_id))
    row = cursor.fetchone ()
    cursor.close ()
    if row:
      return row[0]

# ###########################################################################################
# Extracts QuestBehavior from sql
def GetQuestSQL_questBehavior(quest_id):

    cursor = conn.cursor ()
    cursor.execute ("SELECT `quests`.`questBehavior` FROM `quests` WHERE `quests`.`questId` = " + str(quest_id))
    row = cursor.fetchone ()
    cursor.close ()
    if row:
      return row[0]

# ###########################################################################################
# Extracts QuestLevel & QuestBehavior some QuestData from sql
def GetQuestSQL(quest_id):

    cursor = conn.cursor ()
    cursor.execute ("SELECT `quests`.`questLevel`, `quests`.`questBehavior` FROM `quests` WHERE `quests`.`questId` = " + str(quest_id))
    row = cursor.fetchone ()
    cursor.close ()
    if row:
      return row
      
# ###########################################################################################
# Get ReputationID for players based on their race
def GetPlayerDefaultReputationID(player):
    ReputationID_by_FactionID = { co.RACE_HUMAN:19
                              , co.RACE_ORC:14
                              , co.RACE_DWARF:20 
                              , co.RACE_NIGHT_ELF:21 
                              , co.RACE_TAUREN:16 
                              , co.RACE_GNOME:18 
                              , co.RACE_TROLL:15 
                              , co.RACE_BLOOD_ELF:55 
                              , co.RACE_DRAENEI:49 }

    return ReputationID_by_FactionID.get(player.GetRace(),0)

# ###########################################################################################
# Returns ReputationID for given faction
def Reputation_ID(fact_id):
    Default_Reputation = {11:19,12:19,21:1,23:18,29:14,47:20,54:18,55:20,57:20,59:4,64:18,65:14,67:12,68:17,69:9,70:6,71:17,
                          72:19,76:14,79:21,80:21,81:16,85:14,87:6,92:2,93:3,97:6,98:17,104:16,105:16,108:6,118:17,120:1,121:1,
                          122:20,123:19,124:21,125:14,126:15,132:2,133:3,169:10,270:51,349:5,369:7,390:1,412:52,414:35,469:11,
                          470:9,471:5,472:6,473:5,474:7,475:7,509:53,510:52,529:13,530:15,576:35,577:28,589:27,609:36,629:37,
                          635:36,636:35,637:9,694:8,695:42,709:39,729:41,730:40,749:42,776:54,794:13,809:44,814:13,854:28,
                          855:28,874:27,875:18,876:15,877:15,889:46,890:45,909:50,910:54,911:55,922:56,930:49,932:58,933:60,
                          934:62,941:61,942:64,946:38,967:63,970:65,978:66,989:67,990:57,994:36,995:16,996:36,1054:8,1055:8,
                          1074:14,1076:21,1078:19,1097:21,1134:17,1154:17,1174:14,1214:41,1215:41,1216:40,1217:40,1254:36,
                          1334:40,1335:41,1354:44,1355:44,1474:4,1475:4,1514:45,1515:46,1534:40,1554:41,1555:50,1574:51,
                          1575:19,1577:53,1594:21,1595:14,1596:40,1597:41,1598:52,1599:53,1600:21,1601:54,1602:55,1603:55,
                          1604:55,1608:36,1611:20,1612:14,1615:10,1618:20,1619:14,1623:56,1624:13,1625:13,1628:56,1635:10,
                          1638:49,1639:49,1640:49,1641:46,1642:45,1646:49,1647:49,1650:61,1651:61,1652:61,1653:61,1654:49,
                          1655:49,1656:55,1657:55,1658:55,1659:64,1660:64,1661:64,1666:38,1667:38,1668:37,1669:37,1670:37,
                          1671:38,1694:49,1695:55,1696:63,1698:49,1699:49,1700:49,1707:65,1708:65,1709:65,1710:64,1721:66,
                          1722:66,1723:66,1724:66,1728:64,1729:37,1730:60,1731:60,1737:38,1741:39,1743:58,1744:62,1745:55,
                          1746:62,1766:13,1767:13,1775:39,1776:58,1777:58,1778:57,1779:67,1788:60,1801:12,1802:11,1805:58,
                          1818:69,1820:70,1824:71,1836:60,1837:65,1838:62,1844:58,1845:62,1850:71,1851:69}
    return Default_Reputation.get(fact_id,0)


# ###########################################################################################
# Returns Custom faction/reward for given quest
def GetCustomQuest(questid):
    result=[]
    cursor = conn.cursor ()
    cursor.execute ("SELECT FactionID,ReputationAward FROM questsreputation WHERE questId = " + str(questid))
    rows = cursor.fetchall ()
    for row in rows:
           result.append([int(row[0]),int(row[1])])
    cursor.close ()
    return result

# EOF #