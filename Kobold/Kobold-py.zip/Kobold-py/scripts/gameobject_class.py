# COPYRIGHT (C) 2006 LUDMILLA TEAM
# This file contains functions for GameObject class
from Ludmilla import *              # Import server environment
from random import *
from consts import *                # Import of constants
import consts as co                 # Import of constants
reload(co)   
import config as cfg                # Import of configuration constants
reload(cfg)

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

printLog( "  o Registerring Gameobject Class" )

# ####################################################################################
# use to modify some specific settings for GO on its creation
#     
def OnCreated(go):
    pass

# ####################################################################################
# used to help Core to select right loot for Fishing 
#     
def GenerateLoot_Fishing(go, player):

    # Get Player attributes
    zone_id = player.GetZoneId()
    map_id  = player.GetMapId()
    zone_lvl = GetZoneLevel(zone_id)
    
    print GetZoneLevel(player.GetZoneId())
    print "fishing loot: for player in zone[%s]-lvl[%d] map[%s]" % (zone_id,zone_lvl,map_id)

    fish_loot = []
    
    #Azeroth
    if map_id == 0:

        #Alterac Mountains
        if zone_id == 36:
            fish_loot = [6292, 6294, 6295, 6310, 6311, 6364, 6643, 8366, 6359, 6307, 6291, 6308, 6289, 8365,
             6361, 6299, 5524]

        #Wetlands
        if zone_id == 11:
            fish_loot = [6309, 6310, 6647, 6359, 6307, 6358, 6308, 6289, 6361, 6354, 6360, 5524, 6352]

        #Silverpine Forest
        if zone_id == 130:
            fish_loot = [6309, 6310, 6311, 6645, 6351, 6307, 6358, 6291, 6308, 6289, 6361, 6303, 6299, 5523,
             6353]
    
        #Arathi Highlands
        if zone_id == 45:
            fish_loot = [6309, 6308, 8365, 6362, 4603, 6355, 5524]
     
        #Deadwind Pass
        if zone_id == 41:
            fish_loot = [13902, 13891]
     
        #Dun Morogh
        if zone_id == 1:
            fish_loot = [6292, 6294, 6295, 6643, 6291, 6308, 6289]

        #Duskwood
        if zone_id == 10:
            fish_loot = [6309, 6310, 6311, 6364, 6647, 6291, 6308, 6289]
  
        #Eastern Plaguelands
        if zone_id == 139:
            fish_loot = [13901]
     
        #Elwynn Forest
        if zone_id == 12:
            fish_loot = [6292, 6294, 6295, 6309, 6643, 6291, 6308, 6289]
     
        #Hillsbrad Foothills
        if zone_id == 267:
            fish_loot = [6309, 6310, 6311, 6363, 6364, 6647, 6359, 6307, 6358, 6308, 6289, 6361, 6354, 6360, 
             5524, 6352]
     
        #Loch Modan
        if zone_id == 38:
            fish_loot = [6309, 6310, 6311, 6645, 6291, 6308, 6317, 6289]
     
        #Redridge Mountains
        if zone_id == 44:
            fish_loot = [6309, 6310, 6311, 6363, 6364, 6647, 6291, 6308, 6289]
     
        #Stormwind City
        if zone_id == 1519:
            fish_loot = [6309, 6310, 6311, 6645, 6291, 6308, 6289, 6361]
        
        #Stranglethorn Vale
        if zone_id == 33:
            fish_loot = [6309, 6310, 6311, 6363, 13876, 13877, 13879, 6359, 6358, 6308, 8365, 6362, 4603, 6357,
             6355, 5524]
            
        #Swamp of Sorrows
        if zone_id == 8:
            fish_loot = [6309, 6310, 6311, 13885, 13886, 6308, 8365, 13758, 6362, 4603, 6355, 5524]
            
        #The Deadmines
        if zone_id == 1581:
            fish_loot = [6310, 6291, 6308, 6289, 6303]
            
        #The Hinterlands
        if zone_id == 47:
            fish_loot = [13885, 13886, 13876, 13882, 13877, 13884, 13878, 13881, 8365, 13759, 13758, 13760]
            
        #The Temple of Atal'Hakkar
        if zone_id == 1477:
            fish_loot = [13885, 13886, 13881]
            
        #Tirisfal Glades
        if zone_id == 85:
            fish_loot = [6292, 6294, 6295, 6643, 6291, 6289, 6303, 6299]
            
        #Western Plaguelands
        if zone_id == 28:
            fish_loot = [13885, 13886, 13882, 13883, 13884, 13881, 13757, 6358, 6308, 8365, 13759, 13758, 13760]
            
        #Westfall
        if zone_id == (40 or 206):
            fish_loot = [6309, 6310, 6311, 6645, 6351, 6307, 6358, 6291, 6308, 6289, 6361, 6303, 5523, 6353]
    
    #Kalimdor
            
    if map_id == 1:
            
        #Silithus
        if zone_id == 1377:
            fish_loot = [13901, 13757, 13890, 13759, 13758, 13760, 13889]
            
        #Stonetalon Mountains
        if zone_id == 406:
            fish_loot = [6309, 6310, 6311, 6363, 6364, 6647, 6458, 6308, 6303]
            
        #Tanaris
        if zone_id == 440:
            fish_loot = [6292, 13876, 13877, 1387, 13879, 13880, 6359, 13874, 13875, 13754, 6362, 4603, 13422,
             13755]
            
        #Teldrassil
        if zone_id == 141:
            fish_loot = [6292, 6294, 6295, 6643, 6291, 6289, 6303]
            
        #The Barrens
        if zone_id == 17:
            fish_loot = [6292, 6294, 6309, 6310, 6311, 6645, 6643, 6351, 6522, 6470, 6307, 6458, 6358, 6291, 
             6308, 6289, 6361, 6303, 5523, 6353]
            
        #Thousand Needles
        if zone_id == 400:
            fish_loot = [6309, 6310, 6311, 6363, 6308, 8365]
            
        #Un'Goro Crater
        if zone_id == 490:
            fish_loot = [13885, 13886, 13883, 13881, 8365, 13759, 13758, 13760]
            
        #Wailing Caverns
        if zone_id == 718:
            fish_loot = [6309, 6310, 6311, 6645, 6522, 6470, 6291, 6308, 6289]
            
        #Winterspring
        if zone_id == 618:
            fish_loot = [13901, 13903, 13891, 13759, 13760, 13889]
            
        #Ashenvale
        if zone_id == 331:
            fish_loot = [6309, 6310, 6311, 6363, 6364, 13886, 13882, 6647, 6359, 6307, 6358, 6291, 6308, 6289,
             6361, 6299, 6354, 5524, 6352]
            
        #Azshara
        if zone_id == 16:
            fish_loot = [13909, 13910, 13885, 13886, 13876, 13882, 13877, 13878, 13879, 13888, 6359, 13874, 
             13875, 13893, 6358, 6308, 13754, 6289, 8365, 13758, 6362, 4603, 13760, 13918, 13422, 6355, 13755]
            
        #Darkshore
        if zone_id == 148:
            fish_loot = [6309, 6310, 6311, 6645, 12238, 6351, 6359, 6307, 6358, 6291, 6308, 6289, 6361, 6362,
             6303, 6357, 6299, 5523, 6353, 6355, 5524]
            
        #Blackfathom Deeps
        if zone_id == 719:
            fish_loot = [6309, 6645, 6291, 6308, 6289, 6299]
            
        #Durotar
        if zone_id == 14:
            fish_loot = [6292, 6294, 6295, 6643, 6291, 6308, 6289, 6303]
            
        #Dustwallow Marsh
        if zone_id == 15:
            fish_loot = [6309, 6310, 6311, 8366, 6351, 6359, 6358, 6308, 8365, 6361, 6362, 6303, 4603, 6357,
             5523, 6355, 5524]
            
        #Felwood
        if zone_id == 361:
            fish_loot = [13885, 13886, 13882, 13884, 13881, 8365, 13759, 13758, 13760]
            
        #Feralas
        if zone_id == 357:
            fish_loot = [13901, 13885, 13886, 13876, 13882, 13883, 13877, 13884, 13878, 13879, 13880, 13881, 
             6359, 13874, 13875, 13754, 8365, 13759, 13758, 6362, 4603, 13760, 13422, 13755]
            
        #Frostfire Hot Springs
        if zone_id == 2246:
            fish_loot = [13891]
            
        #Maraudon
        if zone_id == 2100:
            fish_loot = [13885, 13886]
            
        #Moonglade
        if zone_id == 493:
            fish_loot = [13885, 13886, 13882, 13883, 13884, 13881, 6359, 13757, 6358, 8365, 13759, 13758, 6362,
             13760, 6355, 5524]
            
        #Mulgore
        if zone_id == 215:
            fish_loot = [6292, 6294, 6295, 6643, 6291, 6289]
            
        #Orgrimmar
        if zone_id == 1637:
            fish_loot = [6292, 6309, 6310, 6311, 6645, 6351, 6358, 6291, 6308, 6289, 6361, 6303, 5523, 6353]
    
    # Empty Loot Table
    go.ClearLootTable()
    max_el = fish_loot.__len__()
    
    # check on 0 sized list
    if max_el == 0: return 
    
    #Add fish to loot
    v = randrange(0,max_el)    
    go.AddItemToLoot(fish_loot[v], 1)

# -- EOF --
