# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *              # Import server environment
from random import *                # Randomiser Import
import config as cfg                # Import of configuration constants
reload(cfg)  
import consts as co                 # Import of constants
reload(co)   
import const_skills as skill_co     # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co     # Import of constants (spells)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  
import player_class as player_cls
reload(player_cls) 
import packet_class as packet_builder         # Import of supporting functions
reload(packet_builder)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

# ####################################################################################
# Register Spell Effects for Scripting
def RegisterSpellEffectsOnStartup():
    print "  o -- Registering Spell Effects"
    
    RegisterSpellEffects(spell_co.EFFECT_SEND_EVENT)
#    print "     -> EFFECT_SEND_EVENT"
    RegisterSpellEffects(spell_co.EFFECT_DUMMY)
#    print "     -> EFFECT_DUMMY (partially)"
    RegisterSpellEffects(spell_co.EFFECT_ACTIVATE_OBJECT)
#    print "     -> EFFECT_ACTIVATE_OBJECT"

# ####################################################################################
# Called every time on Spell Effect Activation if returned FALSE then Effect will be used from Core
def OnSpellEffect(spell, slot):

    result       = FALSE
    spell_id     = spell.GetSpellId()
    spell_effect = spell.GetEffectId(slot)
    caster       = spell.GetCaster()
    if caster == NULL: return

    print "OnSpellEffect: spell_id[%d] slot[%d] effect[%d] caster[%s]" % (spell_id, slot, spell_effect, caster.GetName())

    if   spell_effect == spell_co.EFFECT_SEND_EVENT:      result = Handler_EFFECT_SEND_EVENT     (spell, caster, slot)
    elif spell_effect == spell_co.EFFECT_DUMMY:           result = Handler_EFFECT_DUMMY          (spell, caster, slot)
    elif spell_effect == spell_co.EFFECT_ACTIVATE_OBJECT: result = Handler_EFFECT_ACTIVATE_OBJECT(spell, caster, slot)
    
    return result

# ####################################################################################
# EFFECT_SEND_EVENT handler
def Handler_EFFECT_SEND_EVENT(spell, caster, slot):
    
    spell_id = spell.GetSpellId()
    target = spell.GetUnitTarget()
    
#    print "EFFECT_SEND_EVENT: %d" % (spell_id)
   
    #-----------------------------------------------------------------------------
    if spell_id == spell_co.SPELL_ID_HORDE_FLAG:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            text =  "|cdf20af20%s picked up the flag!" % (caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            
            # Send Sound
            packet = packet_builder.make_SMSG_PLAY_SOUND( co.SOUND__PVP_FLAG_TAKEN_HORDE )
            caster.SendBattleGroundPacket(packet, co.SIDE_ALLIANCE_MASK | co.SIDE_HORDE_MASK)
        
            return TRUE
    
    #-----------------------------------------------------------------------------    
    elif spell_id == spell_co.SPELL_ID_ALLIANCE_FLAG:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            text =  "|cffff6060%s picked up the flag!" % (caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            
            # Send Sound
            packet = packet_builder.make_SMSG_PLAY_SOUND( co.SOUND__PVP_FLAG_TAKEN_ALLIANCE )
            caster.SendBattleGroundPacket(packet, co.SIDE_ALLIANCE_MASK | co.SIDE_HORDE_MASK)
            
            return TRUE
    
    #-----------------------------------------------------------------------------
    if spell_id == spell_co.SPELL_ID_HORDE_FLAG_DROP:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            text =  "|cdf20af20%s dropped the flag!" % (caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            
            # Send Sound
            packet = packet_builder.make_SMSG_PLAY_SOUND( co.SOUND__PVP_WARNING_HORDE )
            caster.SendBattleGroundPacket(packet, co.SIDE_ALLIANCE_MASK | co.SIDE_HORDE_MASK)
            
            return TRUE
    
    #-----------------------------------------------------------------------------    
    elif spell_id == spell_co.SPELL_ID_ALLIANCE_FLAG_DROP:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            text =  "|cffff6060%s dropped the flag!" % (caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            
            # Send Sound
            packet = packet_builder.make_SMSG_PLAY_SOUND( co.SOUND__PVP_WARNING_ALLIANCE )
            caster.SendBattleGroundPacket(packet, co.SIDE_ALLIANCE_MASK | co.SIDE_HORDE_MASK)
            
            return TRUE
    
    #-----------------------------------------------------------------------------
    elif spell_id == spell_co.SPELL_ID_ALLIANCE_FLAG_RETURNS_EVENT:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            text =  "|cdf20af20%s returned the flag!" % (caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            
            # Send Sound
            packet = packet_builder.make_SMSG_PLAY_SOUND( co.SOUND__PVP_FLAG_RETURNED_ALLIANCE )
            caster.SendBattleGroundPacket(packet, co.SIDE_ALLIANCE_MASK | co.SIDE_HORDE_MASK)
            
            return TRUE
    
    #-----------------------------------------------------------------------------    
    elif spell_id == spell_co.SPELL_ID_HORDE_FLAG_RETURNS_EVENT:
       
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            text =  "|cffff6060%s returned the flag!" % (caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            
            # Send Sound
            packet = packet_builder.make_SMSG_PLAY_SOUND( co.SOUND__PVP_FLAG_RETURNED_HORDE )
            caster.SendBattleGroundPacket(packet, co.SIDE_ALLIANCE_MASK | co.SIDE_HORDE_MASK)
            
            return TRUE 
        
    return FALSE
    
# ####################################################################################
# EFFECT_DUMMY handler
def Handler_EFFECT_DUMMY(spell, caster, slot):

    spell_id = spell.GetSpellId()
    target = spell.GetUnitTarget()
    
#    print "EFFECT_DUMMY: %d" % (spell_id)
    
    #-----------------------------------------------------------------------------
    if spell_id == spell_co.SPELL_ID_HORDE_FLAG_CLICK or spell_id == spell_co.SPELL_ID_ALLIANCE_FLAG_CLICK:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            spell_to_cast = 0
            #go = spell.GetGOCaster()
            #spell_to_cast = go.GetDataField(3) # mixed in templates
            if spell_id == spell_co.SPELL_ID_HORDE_FLAG_CLICK:    spell_to_cast = spell_co.SPELL_ID_HORDE_FLAG
            if spell_id == spell_co.SPELL_ID_ALLIANCE_FLAG_CLICK: spell_to_cast = spell_co.SPELL_ID_ALLIANCE_FLAG
            #go.CreateDelayedSpellCast(caster, caster, spell_to_cast)
            caster.CastSpell(caster, spell_to_cast, TRUE)
            #go.Despawn(0)
            #go.BindRespawnToSpell(caster, spell_to_cast)
            #caster.SetFlagTakenEvent(2)
        return TRUE
    
    #-----------------------------------------------------------------------------
    elif spell_id == spell_co.SPELL_ID_HORDE_FLAG_CAPTURE:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            print "flag capture[warsong]"
            text =  "|cdf20af20%s yells: %s captured the Horde flag!" % (caster.GetName(), caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            #caster.RemoveAffect(caster, spell_co.SPELL_ID_HORDE_FLAG)
            #caster.ModifyFlagCaptureCount(1)
            #caster.RemoveFlagTakenEvent()
            player_cls.CalculateBattleGroundBonusHonor(caster)
            
            # Respawn Flag
            print "searching for BG Flag with id: %d" % ( co.BATTLEGROUND_HORDE_FLAG )
            #go = GetGameObjectById( co.BATTLEGROUND_HORDE_FLAG, caster.GetInstanceId() )
            #if go: 
            #    print "respawning GO: %x" % ( go.GetGUIDUInt64() )
            #    go.Respawn(1000) # make flag respawn in 1000ms
        
        return TRUE  
    
    #-----------------------------------------------------------------------------
    elif spell_id == spell_co.SPELL_ID_ALLIANCE_FLAG_CAPTURE:
        
        if caster.GetGUIDUInt64() == target.GetGUIDUInt64():
            print "flag capture[silverwing]"
            text =  "|cffff6060%s yells: %s captured the Alliance flag!" % (caster.GetName(), caster.GetName())
            caster.SendBattleGroundMessage(text, co.SIDE_ALL_MASK)
            #caster.RemoveFlagTakenEvent()
            #caster.ModifyFlagCaptureCount(1)
            #caster.RemoveAffect(caster, spell_co.SPELL_ID_ALLIANCE_FLAG)
            player_cls.CalculateBattleGroundBonusHonor(caster)
            
            # Respawn Flag
            print "searching for BG Flag with id: %d" % ( co.BATTLEGROUND_ALLIANCE_FLAG )
            #go = GetGameObjectById( co.BATTLEGROUND_ALLIANCE_FLAG, caster.GetInstanceId()  )
            #if go: 
            #    print "respawning GO: %x" % ( go.GetGUIDUInt64() )
            #    go.Respawn(1000) # make flag respawn in 1000ms
                
        return TRUE      
    
    #-----------------------------------------------------------------------------
    elif spell_id == spell_name.SPELL_ID_SPIRIT_HEALER_RES:
        
        # Scan Nearby Area
        units_around = caster.MapRangeUnitList()
        for _unit in units_around:
            if _unit == NULL: continue
            if _unit.IsNPC(): continue
            if _unit.isDead() == FALSE: continue
            
            print "found Dead Player nearby: %s" % (_unit.GetName())
                
            # Resurrect found Player ( nor by player, nor by standard spirit healer)
            _unit.ResurrectPlayer(FALSE, FALSE)
            
        return TRUE 
    #-----------------------------------------------------------------------------
    elif spell_id == spell_name.SPELL_ID_TAMING_LESSON:
        
        target = spell.GetUnitTarget()
        if target == NULL: return FALSE
        
        print "Learning spells: %s" % (target.GetName())
        
        target.AddSpell( spell_name.SPELL_ID_TAME_BEAST, TRUE )
        target.AddSpell( spell_name.SPELL_ID_CALL_PET, TRUE )
        target.AddSpell( spell_name.SPELL_ID_DISMISS_PET, TRUE )
            
        return TRUE 
        
    #-----------------------------------------------------------------------------
    elif  spell_id == spell_name.SPELL_ID_LIFE_TAP_RANK_1 or \
          spell_id == spell_name.SPELL_ID_LIFE_TAP_RANK_2 or \
          spell_id == spell_name.SPELL_ID_LIFE_TAP_RANK_3 or \
          spell_id == spell_name.SPELL_ID_LIFE_TAP_RANK_4 or \
          spell_id == spell_name.SPELL_ID_LIFE_TAP_RANK_5 or \
          spell_id == spell_name.SPELL_ID_LIFE_TAP_RANK_6 :
        
        target = spell.GetUnitTarget()
        if target == NULL: return FALSE
        
        health_to_convert = spell.GetPoints(slot)
        
        cur_health = target.GetHealth()
        max_mana = target.GetMaxMana()
        cur_mana = target.GetMana()
        
        # check if Full mana already
        if cur_mana == max_mana: return TRUE
        if health_to_convert >= cur_health: return TRUE
        
        # check for value correction in case we have to convert less than specified value to get Max
        if cur_mana + health_to_convert > max_mana: health_to_convert = max_mana - cur_mana
        
        target.SetHealth( cur_health - health_to_convert )
        target.ModifyMana( health_to_convert )
            
        return TRUE 
    #-----------------------------------------------------------------------------
    elif  spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_1 or \
          spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_2 or \
          spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_3 or \
          spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_4 or \
          spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_5 :
        
        arrayOfRank = 0
        
        if spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_2:
            arrayOfRank = 1
        elif spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_3:
            arrayOfRank = 2
        elif spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_4:
            arrayOfRank = 3
        elif spell_id == spell_name.SPELL_ID_HOLY_SHOCK_RANK_5:
            arrayOfRank = 4
        
        
        spellToCast = 0
        
        if caster.CanAttackUnit(target):
            damageSpells = [spell_name.SPELL_ID_HOLY_SHOCK_RANK_1_1, spell_name.SPELL_ID_HOLY_SHOCK_RANK_2_2, spell_name.SPELL_ID_HOLY_SHOCK_RANK_3_2, spell_name.SPELL_ID_HOLY_SHOCK_RANK_4_2, spell_name.SPELL_ID_HOLY_SHOCK_RANK_5_1]
            spellToCast = damageSpells[arrayOfRank]
        else:
            healSpells = [spell_name.SPELL_ID_HOLY_SHOCK_RANK_1_2, spell_name.SPELL_ID_HOLY_SHOCK_RANK_2_3, spell_name.SPELL_ID_HOLY_SHOCK_RANK_3_3, spell_name.SPELL_ID_HOLY_SHOCK_RANK_4_1, spell_name.SPELL_ID_HOLY_SHOCK_RANK_5_2]
            spellToCast = healSpells[arrayOfRank]
        
        caster.CastSpell(target, spellToCast, 1)
        
        return TRUE
    #-----------------------------------------------------------------------------
    elif  spell_id == spell_name.SPELL_ID_EXECUTE_RANK_1_1 or \
          spell_id == spell_name.SPELL_ID_EXECUTE_RANK_2_1 or \
          spell_id == spell_name.SPELL_ID_EXECUTE_RANK_3_1 or \
          spell_id == spell_name.SPELL_ID_EXECUTE_RANK_4 or \
          spell_id == spell_name.SPELL_ID_EXECUTE_RANK_5 or \
          spell_id == spell_name.SPELL_ID_EXECUTE_RANK_6 or \
          spell_id == spell_name.SPELL_ID_EXECUTE_RANK_7 :
        
        damageToDeal = spell.GetPoints(slot)
        
        spellRank = 1
        
        if spell_id == spell_name.SPELL_ID_EXECUTE_RANK_2_1:
            spellRank = 2
        elif spell_id == spell_name.SPELL_ID_EXECUTE_RANK_3_1:
            spellRank = 3
        elif spell_id == spell_name.SPELL_ID_EXECUTE_RANK_4:
            spellRank = 4
        elif spell_id == spell_name.SPELL_ID_EXECUTE_RANK_5:
            spellRank = 5
        elif spell_id == spell_name.SPELL_ID_EXECUTE_RANK_6:
            spellRank = 6
        elif spell_id == spell_name.SPELL_ID_EXECUTE_RANK_7:
            spellRank = 7
        
        rageForDamage = caster.GetRage()
        
        damageToDeal = damageToDeal + (rageForDamage * 0.3 * spellRank)
        
        caster.ModifyRage(-rageForDamage)
        
        caster.DealDamage(target, spell.GetSpellId(), damageToDeal)
        
        return TRUE
    
    return FALSE
    
# ####################################################################################
# EFFECT_ACTIVATE_OBJECT handler
def Handler_EFFECT_ACTIVATE_OBJECT(spell, caster, slot):
    
    spell_id = spell.GetSpellId()
#    print "EFFECT_ACTIVATE_OBJECT: %d" % (spell_id)
    
    #-----------------------------------------------------------------------------
    if spell_id == spell_co.SPELL_ID_ALLIANCE_FLAG_RETURNS_EVENT:
        print "searching for BG Flag with id: %d" % ( co.BATTLEGROUND_ALLIANCE_FLAG )
        go = GetGameObjectById( co.BATTLEGROUND_ALLIANCE_FLAG, caster.GetInstanceId()  )
        if go: 
            print "respawning GO: %x" % ( go.GetGUIDUInt64() )
            go.Respawn(1000) # make flag respawn in 1000ms
        return TRUE
        
    #-----------------------------------------------------------------------------
    elif spell_id == spell_co.SPELL_ID_HORDE_FLAG_RETURNS_EVENT:
        print "searching for BG Flag with id: %d" % ( co.BATTLEGROUND_HORDE_FLAG )
        go = GetGameObjectById( co.BATTLEGROUND_HORDE_FLAG, caster.GetInstanceId() )
        if go: 
            print "respawning GO: %x" % ( go.GetGUIDUInt64() )
            go.Respawn(1000) # make flag respawn in 1000ms
        return TRUE
    
    return FALSE
# -- EOF ---
