# COPYRIGHT (C) 2006 LUDMILLA TEAM
from Ludmilla import *              # Import server environment
from random import *
from consts import *                # Import of constants
import consts as co                 # Import of constants
reload(co)   
import config as cfg                # Import of configuration constants
reload(cfg)  
import const_skills as skill_co     # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co     # Import of constants (spells)
reload(spell_co)
import const_spellname as spellname_co #Import of constant (spell name)
reload(spellname_co)  
import support as supporter         # Import of supporting functions
reload(supporter)  
import packet_class as packet_builder         # Import of supporting functions
reload(packet_builder)  
import player.stats_loader as StatsLoader         # Import of supporting functions
reload(StatsLoader)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

#  This file contains predefined race and class initialisations,
#  LudMilla calls race and class init functions on creating character
#  and on loading character (when recalculating base stats)
#
#
# v.0310 (Date: 03.10.2005) 
#modify by zhenya (Date: 21.01.2007)

# #####  SETTINGS #######
MAX_COUNT_SUPPLY =  cfg.PLAYER_MAX_COUNT_SUPPLY     # Max Supplies #1 in bagpack       (usually Water)
MAX_COUNT_SUPPLY2 = cfg.PLAYER_MAX_COUNT_SUPPLY2    # Max Supplies #2 in bagpack       (usually Bread, Apple, Musroom, Jerky)
MAX_COUNT_AMMO =    cfg.PLAYER_MAX_COUNT_AMMO       # Max Ammo in bagpack                 (usually Bullets, Arrows)
MAX_COUNT_WPN =     cfg.PLAYER_MAX_COUNT_WPN        # Max Weapon                               (usually Throwing Knifes, Axes)
GIFT =              cfg.PLAYER_GIFT                 # To Disable function - 0, Enable - 1 (Default) (puts nice flower to female chars to bagpack)
SRV_CUSTOM =        cfg.PLAYER_SRV_CUSTOM           # To Disable function - 0 (Default), Enable - 1 (for adding custom Items to bagpack or char)
# ###################


# ############### !!! DO NOT MODIFY ANY SETTING BELOW THIS LINE, IT MAY LEAD TO SERVER INSTABILLITY !!!  ################


# RACE-COMMON ################################################################################
#---------------------------------------ALLIANCE-----------------------------------------------------#

def CommonOneTimeRacialAlliance (p):
    """ One Time Racial additions common to all races of Alliance
    """

    p.AddSpell (668)            # Language: Common
    p.SetSkill (98, 300, 300)   # Language: Common
    p.AddSpell (203)            # Unarmed
    p.SetSkill (162, 1, 5)      # Unarmed
    p.AddSpell (81)             # Dodge
    p.AddSpell (0x19CB)         # Attack Melee
    p.AddSpell (3365)           # Opening
    p.AddSpell (6478)           # Opening
    p.AddSpell (9078)           # Cloth
    p.SetSkill (415, 1, 1)      # Cloth
    p.AddSpell (7266)           # Duel
    p.AddSpell (7355)           # Stuck
    #--- Initial Items GLOBAL ---
    p.AddItemToSlot (23, 6948, 1)                   # Hearthstone

# RACE-COMMON ################################################################################
#--------------------------------------HORDE------------------------------------------------------#

def CommonOneTimeRacialHorde (p):
    """ One Time Racial additions common to all races of Horde
    """

    p.AddSpell (669)            # Language: Orcish
    p.SetSkill (109, 300, 300)  # Language: Orcish
    p.AddSpell (203)            # Unarmed
    p.SetSkill (162, 1, 5)      # Unarmed
    p.AddSpell (81)             # Dodge
    p.AddSpell (0x19CB)         # Attack Melee
    p.AddSpell (3365)           # Opening
    p.AddSpell (6478)           # Opening
    p.AddSpell (9078)           # Cloth
    p.SetSkill (415, 1, 1)      # Cloth
    p.AddSpell (7266)           # Duel
    p.AddSpell (7355)           # Stuck
    #--- Initial Items GLOBAL ---
    p.AddItemToSlot (23, 6948, 1)                   # Hearthstone

# #############################################################################################
# ##
# ##  RACE INIT FUNCTIONS
# ##
# #############################################################################################

# ##############################  ALLIANCE ####################################################
#--------------------------------------------------------------------------------------------#

def Dwarf (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
    
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  22)
    p.SetBaseStats(STAT_TYPE_AGILITY,   16)
    p.SetBaseStats(STAT_TYPE_STAMINA,   23)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 19)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    19)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
  
    # Sturtup Location is set always
    p.StartupLocation (0, -6240.32, 331.033, 382.758, 1.0)  # Coldridge Valley
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 32)
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit:
        p.PlayerModel (53, 54)      # Male / Female
        p.SetFaction (3)            # PLAYER, Dwarf

        p.AddSpell (672)            # Language: Dwarven
        p.SetSkill (111, 300, 300)  # Language: Dwarven

        CommonOneTimeRacialAlliance (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage
        
        #--- Racial ---
        p.AddSpell (2481)       # Find Treasure
        p.AddSpell (20594)      # Stoneform
        p.AddSpell (20595)      # Gun Specialization
        p.AddSpell (20596)      # Frost Resistance
        
#--------------------------------------------------------------------------------------------#
def Gnome (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
   
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  16)
    p.SetBaseStats(STAT_TYPE_AGILITY,   23)
    p.SetBaseStats(STAT_TYPE_STAMINA,   19)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 23)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    20)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
    
    # Sturtup Location is set always
    p.StartupLocation (0, -6240.32, 331.033, 382.758, 1.0)  # Coldridge Valley
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 32)
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit:
        p.PlayerModel (1563, 1564)  # Male / Female
        p.SetFaction (115)            # PLAYER, Gnome

        p.AddSpell (7340)           # Language: Gnomish
        p.SetSkill (313, 300, 300)  # Language: Gnomish

        CommonOneTimeRacialAlliance (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (20589)      # Escape Artist
        p.AddSpell (20591)      # Expansive Mind
        p.AddSpell (20592)      # Arcane Resistance
        p.AddSpell (20593)      # Engineering Specialization
        
#--------------------------------------------------------------------------------------------#
def Human (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """    
    
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  20)
    p.SetBaseStats(STAT_TYPE_AGILITY,   20)
    p.SetBaseStats(STAT_TYPE_STAMINA,   20)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 20)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    20)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
    
    # Sturtup Location is set always
    p.StartupLocation (0, -8949.95, -132.493, 83.5312, 1.0)  # Northshire Valley
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 2)
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit:
        p.PlayerModel (49, 50)      # Male / Female
        p.SetFaction (1)            # PLAYER, Human

        CommonOneTimeRacialAlliance (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage
        
        #--- Racial ---
        p.AddSpell (20597)      # Sword Specialization
        p.AddSpell (20598)      # The Human Spirit
        p.AddSpell (20599)      # Diplomacy
        p.AddSpell (20600)      # Perception
        p.AddSpell (20864)      # Mace Specialization

#--------------------------------------------------------------------------------------------#
def NightElf (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
   
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  17)
    p.SetBaseStats(STAT_TYPE_AGILITY,   25)
    p.SetBaseStats(STAT_TYPE_STAMINA,   19)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 20)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    20)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
   
    # Sturtup Location is set always
    p.StartupLocation (1, 10311.3, 832.463, 1326.41, 1.0)  # Shadowglen
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 100663296)
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit: 
        p.PlayerModel (55, 56)      # Male / Female
        p.SetFaction (4)            # PLAYER, Night Elf

        p.AddSpell (671)            # Language: Darnassian
        p.SetSkill (113, 300, 300)  # Language: Darnassian

        CommonOneTimeRacialAlliance (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (20580)      # Shadowmeld
        p.AddSpell (20582)      # Quickness
        p.AddSpell (20583)      # Nature Resistance
        p.AddSpell (20585)      # Wisp Spirit

#--------------------------------------------------------------------------------------------#
def Draenei (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
   
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  21)
    p.SetBaseStats(STAT_TYPE_AGILITY,   17)
    p.SetBaseStats(STAT_TYPE_STAMINA,   19)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 21)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    22)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
   
    # Sturtup Location is set always
    p.StartupLocation (530, -3961.86, -13931.27, 100.58, 1.0)  # Ammen Vale
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit: 
        p.PlayerModel (16125, 16126)      # Male / Female
        p.SetFaction (1629)            # PLAYER, Draenei

        p.AddSpell (29932)            # Language Draenei
        p.SetSkill (759, 300, 300)  # Language Draenei

        CommonOneTimeRacialAlliance (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (28875)      # Gem cutting
        p.AddSpell (28880)      # Gift of the Naaru
        p.AddSpell (6562)       # Heroic Presence
        p.AddSpell (20579)      # Shadow Resistance
        
# ##############################  HORDE #######################################################
#--------------------------------------------------------------------------------------------#

def Orc (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """

    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  23)
    p.SetBaseStats(STAT_TYPE_AGILITY,   17)
    p.SetBaseStats(STAT_TYPE_STAMINA,   22)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 17)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    23)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
    
    # Sturtup Location is set always
    p.StartupLocation (1, -618.518, -4251.67, 38.718, 1.0)  # Valley of Trials
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 4194304)
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit:
        p.PlayerModel (51, 52)  # Male / Female
        p.SetFaction (2)        # PLAYER, Orc

        CommonOneTimeRacialHorde (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (20572)      # Blood Fury
        p.AddSpell (20573)      # Hardness
        p.AddSpell (20574)      # Axe Specialization
        p.AddSpell (20575)      # Command

#--------------------------------------------------------------------------------------------#
def Tauren (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
    
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  25)
    p.SetBaseStats(STAT_TYPE_AGILITY,   15)
    p.SetBaseStats(STAT_TYPE_STAMINA,   22)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 15)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    22)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
    
    # Sturtup Location is set always
    p.StartupLocation (1, -2917.58, -257.98, 52.9968, 1.0)  # Camp Narache
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 2097152)
    
    # Set player size
    p.SetScale(1.35)
    
    if oneTimeInit:
        p.PlayerModel (59, 60)      # Male / Female
        p.SetFaction (6)            # PLAYER, Tauren

        p.AddSpell (670)            # Language: Taurane
        p.SetSkill (115, 300, 300)  # Language: Taurane

        CommonOneTimeRacialHorde (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (20549)      # War Stomp
        p.AddSpell (20550)      # Endurance
        p.AddSpell (20551)      # Nature Resistance
        p.AddSpell (20552)      # Cultivation

#--------------------------------------------------------------------------------------------#
def Troll (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
    
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  21)
    p.SetBaseStats(STAT_TYPE_AGILITY,   22)
    p.SetBaseStats(STAT_TYPE_STAMINA,   21)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 16)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    21)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
    
    # Sturtup Location is set always
    p.StartupLocation (1, -618.518, -4251.67, 38.718, 1.0)  # Valley of Trials
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 4194304)
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit:
        p.PlayerModel (1478, 1479)  # Male / Female
        p.SetFaction (116)          # PLAYER, Troll

        p.AddSpell (7341)           # Language: Trollish
        p.SetSkill (315, 300, 300)  # Language: Trollish

        CommonOneTimeRacialHorde (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (20554)      # Berserking
        p.AddSpell (20555)      # Regeneration
        p.AddSpell (20557)      # Beast Slaying
        p.AddSpell (20558)      # Throwing Specialization

#--------------------------------------------------------------------------------------------#
def Undead (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
        
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  19)
    p.SetBaseStats(STAT_TYPE_AGILITY,   18)
    p.SetBaseStats(STAT_TYPE_STAMINA,   21)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 18)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    25)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
    
    # Sturtup Location is set always
    p.StartupLocation (0, 1676.35, 1677.45, 121.67, 3.14)  # Deathknell
    
    # Taxi mask ( base knowledge for race )
    p.AddTaxiMask(0, 1024)
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit:
        p.PlayerModel (57, 58)      # Male / Female
        p.SetFaction (5)            # PLAYER, Undead

        p.AddSpell (17737)          # Language: Gutterspeak
        p.SetSkill (673, 300, 300)  # Language: Gutterspeak

        CommonOneTimeRacialHorde (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (5227)       # Underwater Breathing
        p.AddSpell (7744)       # Will of The Forsaken
        p.AddSpell (20577)      # Cannibalize
        p.AddSpell (20579)      # Shadow Resistance

#--------------------------------------------------------------------------------------------#
def BloodElf (p, oneTimeInit):
    """ Add Racial spells, skills and bonuses
    """
   
    # Player Initial Level 1 stats ---------START----------------
    
    # Base Stats for L1
    p.SetBaseStats(STAT_TYPE_STRENGTH,  19)
    p.SetBaseStats(STAT_TYPE_AGILITY,   22)
    p.SetBaseStats(STAT_TYPE_STAMINA,   20)
    p.SetBaseStats(STAT_TYPE_INTELLECT, 24)
    p.SetBaseStats(STAT_TYPE_SPIRIT,    20)
    
    # Stats increase per level
    p.SetStatsPerLevel(STAT_TYPE_STRENGTH, 2)
    p.SetStatsPerLevel(STAT_TYPE_AGILITY, 2)
    p.SetStatsPerLevel(STAT_TYPE_STAMINA, 2)
    p.SetStatsPerLevel(STAT_TYPE_INTELLECT, 2)
    p.SetStatsPerLevel(STAT_TYPE_SPIRIT, 2)

    # Base HP and HP/level, Base Mana and Mana/level
    p.SetBaseHealth         (0)
    p.SetBaseStartHealth    (40)
    p.SetHealthPerLevel     (GetBaseHealthPerLevel(p))
    p.SetHealthLevelUpScale (1.0)
    
    p.SetBaseMana           (0)
    p.SetBaseStartMana      (40)
    p.SetManaPerLevel       (GetBaseManaPerLevel(p))
    p.SetManaLevelUpScale   (1.0)
    
    # Player Initial Level 1 stats ---------END----------------
   
    # Sturtup Location is set always
    p.StartupLocation (530, 10349.85, -6357.63, 33.48, 1.0)  # Sunstrider Isle
    
    # Set player size
    p.SetScale(1.0)
    
    if oneTimeInit: 
        p.PlayerModel (15476, 15475)      # Male / Female
        p.SetFaction (1610)            # PLAYER, Blood Elf

        p.AddSpell (813)            # Language Thalassian
        p.SetSkill (137, 300, 300)  # Language Thalassian

        CommonOneTimeRacialHorde (p)
        # Reputation (p) # OBSOLETE, initial Reputation is set via core from DBC storage

        #--- Racial ---
        p.AddSpell (28877)      # Arcane Affinity
        p.AddSpell (822)        # Magic Resistance
        p.AddSpell (28730)      # Arcane Torrent
        p.AddSpell (28734)      # Mana Tap
        
#--------------------------------------------------------------------------------------------#
# ##############################  END RACES  ##################################################

# #############################################################################################
# ##
# ##  CLASS INIT FUNCTIONS
# ##
# #############################################################################################

    # ############################### START DRUID ############################# #

def Druid (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Druid"
    
    p.ModifyBaseStats (STAT_TYPE_STRENGTH,  1)
    p.ModifyBaseStats (STAT_TYPE_INTELLECT, 2)
    p.ModifyBaseStats (STAT_TYPE_SPIRIT,    2)
    
    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)
    
    if oneTimeInit:
        p.AddSpell (9077)           # Leather
        p.SetSkill (414, 1, 1)      # Leather

        #--- Class Skills ---
        p.SetSkill (574, 1, 1)      # Balance
        p.SetSkill (573, 1, 1)      # Restoration

        #--- Other ---
        p.AddSpell (227)            # Staves
        p.SetSkill (136, 1, 5)      # Staves
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (5176)           # Wrath Rank 1
        p.AddSpell (5185)           # Healing Touch Rank 1

        # ##### CUSTOM MODULES ###########   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ################################

        #--- Bag pack UNIFIED ---        
         
        p.AddItemToSlot (24, 159, MAX_COUNT_SUPPLY)     # Refreshing Spring Water
        p.AddItemToSlot (25, 4536, MAX_COUNT_SUPPLY2)   # Shiny Red Apple
        
    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
        # ############################################################################

        if p.GetRace() == RACE_NIGHT_ELF:        # Night-Elf Race
        
            p.AddSpell (1180)           # Daggers
            p.SetSkill (173, 1, 5)      # Daggers
            
        #--- Initial Items ---        
            p.AddItemToSlot (3, 127, 1)     # Novice's  Shirt
            p.AddItemToSlot (4, 6123, 1)    # Novice's  Robe
            p.AddItemToSlot (6, 44, 1)      # Novice's pants
            p.AddItemToSlot (15, 3661, 1)   # Hand crafted staff

    # ############################################################################

        if p.GetRace() == RACE_TAUREN:        # Tauren Race
        
            p.AddSpell (198)           # Maces
            p.SetSkill (54, 1, 5)      # Maces
        
        #--- Initial Items ---
            p.AddItemToSlot (3, 127, 1)     # Novice's Shirt
            p.AddItemToSlot (4, 6139, 1)    # Novice's Robe
            p.AddItemToSlot (6, 6124, 1)    # Novice's Pants
            p.AddItemToSlot (7, 51, 1)      # Novice's Boots
            p.AddItemToSlot (15, 35, 1)     # Bent Staff
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
        
    # ############################### END DRUID #################################

#--------------------------------------------------------------------------------------------#

    # ############################### START HUNTER ##############################

def Hunter (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Hunter"

    p.ModifyBaseStats (STAT_TYPE_AGILITY, 3)
    p.ModifyBaseStats (STAT_TYPE_STAMINA, 1)
    p.ModifyBaseStats (STAT_TYPE_SPIRIT,  1)

    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)
    
    if oneTimeInit:
        p.AddSpell (9077)           # Leather
        p.SetSkill (414, 1, 1)      # Leather

        #--- Class Skills ---
        p.SetSkill (163, 1, 1)      # Marksmanship - Ranged Combat
        p.SetSkill (51, 1, 1)       # Survival - Outdoorsmanship

        #--- Other ---
        p.AddSpell (75)             # Auto Shot
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (2973)           # Raptor Strike Rank 1

        # ##### CUSTOM MODULES ###########   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ############################
        
        #--- Initial Items UNIFIED ---
        p.AddItemToSlot (24, 159, MAX_COUNT_SUPPLY)     # Refreshing Spring Water

    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_NIGHT_ELF:            # Night Elf Race

            p.AddSpell (264)             # Bows
            p.SetSkill (45, 1, 5)        # Bows
            p.AddSpell (1180)            # Daggers
            p.SetSkill (173, 1, 5)       # Daggers

        #--- Initial Items ---
            p.AddItemToSlot (3, 148, 1)      # Rugged Trapper's Shirt
            p.AddItemToSlot (6, 147, 1)      # Rugged Trapper's Pants
            p.AddItemToSlot (7, 129, 1)      # Rugged Trapper's Boots
            p.AddItemToSlot (15, 2092, 1)    # Worn dagger
            p.AddItemToSlot (17, 2504, 1)    # Worn Shortbow

            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            p.AddItemToSlot (19, 2101, 1)                   # Light Quiver
            
            p.AddItemToBag  (19, 0, 2512, MAX_COUNT_AMMO)   # Rough Arrow
            p.SetAmmoSlot   (2512)                          # Loads Ammo to AMMO Slot on Character

    # ############################################################################

        if p.GetRace() == RACE_DWARF:        # Dwarf Race

            p.AddSpell (196)             # Axes
            p.SetSkill (44, 1, 5)        # Axes
            p.AddSpell (266)             # Guns
            p.SetSkill (46, 1, 5)       # Guns

        #--- Initial Items ---
            p.AddItemToSlot (3, 148, 1)      # Rugged Trapper's Shirt
            p.AddItemToSlot (6, 147, 1)      # Rugged Trapper's Pants
            p.AddItemToSlot (7, 129, 1)      # Rugged Trapper's Boots
            p.AddItemToSlot (15, 37, 1)      # Worn Short Axe
            p.AddItemToSlot (17, 2508, 1)    # Old Blunderbuss

            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            p.AddItemToSlot (19, 2102, 1)                   # Small Ammo Pouch
            
            p.AddItemToBag  (19, 0, 2516, MAX_COUNT_AMMO)   # Light Shot
            p.SetAmmoSlot   (2516)                          # Loads Ammo to AMMO Slot on Character

    # ############################################################################

        if p.GetRace() == RACE_ORC:        # Orc Race

            p.AddSpell (196)             # Axes
            p.SetSkill (44, 1, 5)       # Axes
            p.AddSpell (264)             # Bows
            p.SetSkill (45, 1, 5)        # Bows

        #--- Initial Items ---
            p.AddItemToSlot (3, 127, 1)      # Trapper's Shirt
            p.AddItemToSlot (6, 6126, 1)     # Trapper's Pants
            p.AddItemToSlot (7, 6127, 1)     # Trapper's Boots
            p.AddItemToSlot (15, 37, 1)      # Worn Short Axe
            p.AddItemToSlot (17, 2504, 1)    # Worn Shortbow
            
            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            p.AddItemToSlot (19, 2101, 1)                   # Light Quiver
            
            p.AddItemToBag  (19, 0, 2512, MAX_COUNT_AMMO)   # Rough Arrow
            p.SetAmmoSlot   (2512)                          # Loads Ammo to AMMO Slot on Character

    # ############################################################################

        if p.GetRace() == RACE_TROLL:        # Troll Race

            p.AddSpell (196)             # Axes
            p.SetSkill (44, 1, 5)        # Axes
            p.AddSpell (264)             # Bows
            p.SetSkill (45, 1, 5)        # Bows

        #--- Initial Items ---
            p.AddItemToSlot (3, 127, 1)      # Trapper's Shirt
            p.AddItemToSlot (6, 6126, 1)     # Trapper's Pants
            p.AddItemToSlot (7, 6127, 1)     # Trapper's Boots
            p.AddItemToSlot (15, 37, 1)      # Worn Short Axe
            p.AddItemToSlot (17, 2504, 1)    # Worn Shortbow

            p.AddItemToSlot (25, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap
            p.AddItemToSlot (19, 2101, 1)                   # Light Quiver
            
            p.AddItemToBag  (19, 0, 2512, MAX_COUNT_AMMO)   # Rough Arrow
            p.SetAmmoSlot   (2512)                          # Loads Ammo to AMMO Slot on Character

    # ############################################################################

        if p.GetRace() == RACE_TAUREN:        # Tauren Race

            p.AddSpell (196)             # Axes
            p.SetSkill (44, 1, 5)        # Axes
            p.AddSpell (266)             # Guns
            p.SetSkill (46, 1, 5)        # Guns

        #--- Initial Items ---
            p.AddItemToSlot (3, 127, 1)      # Trapper's Shirt
            p.AddItemToSlot (6, 6126, 1)     # Trapper's Pants
            p.AddItemToSlot (7, 6127, 1)     # Trapper's Boots
            p.AddItemToSlot (15, 37, 1)      # Worn Short Axe
            p.AddItemToSlot (17, 2508, 1)    # Old Blunderbuss
            
            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            p.AddItemToSlot (19, 2102, 1)                   # Small Ammo Pouch
            
            p.AddItemToBag  (19, 0, 2516, MAX_COUNT_AMMO)   # Light Shot
            p.SetAmmoSlot   (2516)                          # Loads Ammo to AMMO Slot on Character

    # ############################################################################

        if p.GetRace() == RACE_BLOOD_ELF:            # Blood Elf Race

            p.AddSpell (264)             # Bows
            p.SetSkill (45, 1, 5)        # Bows
            p.AddSpell (1180)            # Daggers
            p.SetSkill (173, 1, 5)       # Daggers

        #--- Initial Items ---
            p.AddItemToSlot (3, 20901, 1)      # Warder's Shirt
            p.AddItemToSlot (6, 20899, 1)      # Warder's Pants
            p.AddItemToSlot (7, 20900, 1)      # Warder's Boots
            p.AddItemToSlot (15, 20982, 1)    # Sharp Dagger
            p.AddItemToSlot (17, 20980, 1)    # Warder's Shortbow

            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)    #  Tough Hunk of Bread
            p.AddItemToSlot (19, 2101, 1)                   # Light Quiver
            
            p.AddItemToBag  (19, 0, 2512, MAX_COUNT_AMMO)   # Rough Arrow
            p.SetAmmoSlot   (2512)                          # Loads Ammo to AMMO Slot on Character
            
    # ############################################################################

        if p.GetRace() == RACE_DRAENEI:  # Dreaenei Race

            p.AddSpell (6562)            # Heoric Presence
            p.AddSpell (7919)             # Crossbow
            p.SetSkill (226, 1, 5)        # Crossbow
            p.AddSpell (1180)            # Daggers
            p.SetSkill (173, 1, 5)       # Daggers

        #--- Initial Items ---
            p.AddItemToSlot (3, 23345, 1)      # Scout's Shirt
            p.AddItemToSlot (6, 23344, 1)      # Scout's Pants
            p.AddItemToSlot (7, 23348, 1)      # Scout's Boots
            p.AddItemToSlot (15, 25, 1)    # Worn Shortsword
            p.AddItemToSlot (17, 23347, 1)    # Weathered Crossbow

            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            p.AddItemToSlot (19, 2101, 1)                   # Light Quiver
            
            p.AddItemToBag  (19, 0, 2512, MAX_COUNT_AMMO)   # Rough Arrow
            p.SetAmmoSlot   (2512)                          # Loads Ammo to AMMO Slot on Character
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
        
    # ############################### END HUNTER #################################

#--------------------------------------------------------------------------------------------#

    # ############################### START MAGE ################################

def Mage (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Mage"
    
    p.ModifyBaseStats (STAT_TYPE_INTELLECT, 3)
    p.ModifyBaseStats (STAT_TYPE_SPIRIT,    2)
    
    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)
    
    if oneTimeInit:
        #--- Class Skills ---
        p.SetSkill (6, 1, 1)        # Frost
        p.SetSkill (8, 1, 1)        # Fire

        #--- Other ---
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (5009)           # Wands
        p.SetSkill (228, 1, 5)      # Wands
        p.AddSpell (5019)           # Shoot
        p.AddSpell (227)            # Staves
        p.SetSkill (136, 1, 5)      # Staves
        p.AddSpell (133)            # Fireball Rank 1
        p.AddSpell (168)            # Frost Armor Rank 1

        # ##### CUSTOM MODULES ########## #   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ########################### #
        
        #--- Initial Items UNIFIED ---
        p.AddItemToSlot (24, 159, MAX_COUNT_SUPPLY)     # Refreshing Spring Water
        
    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_HUMAN:        # Human Race

            p.AddItemToSlot (3, 6096, 1)    # Apprentice's Shirt
            p.AddItemToSlot (4, 56, 1)      # Apprentice's Robe
            p.AddItemToSlot (6, 1395, 1)    # Apprentice's Pants
            p.AddItemToSlot (7, 55, 1)      # Apprentice's Boots
            p.AddItemToSlot (15, 35, 1)     # Bent Staff

        #--- Initial Items ---
            p.AddItemToSlot (25, 2070, MAX_COUNT_SUPPLY2)   # Darnassian Bleu

    # ############################################################################

        if p.GetRace() == RACE_GNOME:        # Gnome Race

            p.AddItemToSlot (3, 6096, 1)    # Apprentice's Shirt
            p.AddItemToSlot (4, 56, 1)      # Apprentice's Robe
            p.AddItemToSlot (6, 1395, 1)    # Apprentice's Pants
            p.AddItemToSlot (7, 55, 1)      # Apprentice's Boots
            p.AddItemToSlot (15, 35, 1)     # Bent Staff

        #--- Initial Items ---
            p.AddItemToSlot (25, 4536, MAX_COUNT_SUPPLY2)   # Shiny Red Apple

    # ############################################################################

        if p.GetRace() == RACE_UNDEAD:        # Undead Race

            p.AddItemToSlot (3, 6096, 1)    # Apprentice's Shirt
            p.AddItemToSlot (4, 56, 1)      # Apprentice's Robe
            p.AddItemToSlot (6, 1395, 1)    # Apprentice's Pants
            p.AddItemToSlot (7, 55, 1)      # Apprentice's Boots
            p.AddItemToSlot (15, 35, 1)     # Bent Staff

        #--- Initial Items ---
            p.AddItemToSlot (25, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_TROLL:        # Troll Race

            p.AddItemToSlot (3, 6096, 1)    # Apprentice's Shirt
            p.AddItemToSlot (4, 56, 1)      # Apprentice's Robe
            p.AddItemToSlot (6, 1395, 1)    # Apprentice's Pants
            p.AddItemToSlot (7, 55, 1)      # Apprentice's Boots
            p.AddItemToSlot (15, 35, 1)     # Bent Staff

        #--- Initial Items ---
            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)     # Tough Jerky
    
    # ############################################################################

        if p.GetRace() == RACE_BLOOD_ELF:   # Blood Elf Race

            p.AddItemToSlot (3, 6096, 1)    # Apprentice's Shirt
            p.AddItemToSlot (4, 20893, 1)      # Apprentice's Robe
            p.AddItemToSlot (6, 20894, 1)    # Apprentice's Pants
            p.AddItemToSlot (7, 20895, 1)      # Apprentice's Boots
            p.AddItemToSlot (15, 35, 1)     # Bent Staff

        #--- Initial Items ---
            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread  
            
    # ############################################################################

        if p.GetRace() == RACE_DRAENEI:     # Draenei Race

            p.AddSpell (28878)              # Inspiring Presence
            p.AddItemToSlot (3, 23473, 1)    # Apprentice's Shirt
            p.AddItemToSlot (4, 23479, 1)      # Apprentice's Robe
            p.AddItemToSlot (6, 23474, 1)    # Apprentice's Pants
            p.AddItemToSlot (7, 23475, 1)      # Apprentice's Boots
            p.AddItemToSlot (15, 35, 1)     # Bent Staff

        #--- Initial Items ---
            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread  
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
        
    # ############################### END MAGE ###################################

#--------------------------------------------------------------------------------------------#

    # ############################### START PALADIN ############################

def Paladin (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Paladin"

    p.ModifyBaseStats (STAT_TYPE_STRENGTH, 2)
    p.ModifyBaseStats (STAT_TYPE_STAMINA,  2)
    p.ModifyBaseStats (STAT_TYPE_SPIRIT,   1)
    
    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)

    if oneTimeInit:
        p.AddSpell (9077)           # Leather
        p.SetSkill (414, 1, 1)      # Leather
        p.AddSpell (8737)           # Mail
        p.SetSkill (413, 1, 1)      # Mail
        p.AddSpell (9116)           # Shield
        p.SetSkill (433, 1, 1)      # Shield

        #--- Class Skills ---
        p.SetSkill (594, 1, 1)      # Holy

        #--- Other ---
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (107)            # Block
        p.AddSpell (635)            # Holy Light Rank 1
        p.AddSpell (20154)          # Seal of Righteousness Rank 1

        # ##### CUSTOM MODULES ########## #   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ########################### #

        #--- Initial Items UNIFIED ---
        p.AddItemToSlot (24, 159, MAX_COUNT_SUPPLY)     # Refreshing Spring Water

    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_HUMAN:        # Human Race

            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)      # Maces 
            p.AddSpell (199)            # 2 Handed Maces
            p.SetSkill (160, 1, 5)     # 2 Handed Maces

        #--- Initial Items ---
            p.AddItemToSlot (3, 45, 1)      # Squire's shirt
            p.AddItemToSlot (6, 44, 1)      # Squire's pants
            p.AddItemToSlot (7, 43, 1)      # Squire's boots
            p.AddItemToSlot (15, 2361, 1)   # battleworn hammer

            p.AddItemToSlot (25, 2070, MAX_COUNT_SUPPLY2)   # Darnassian Bleu

    # ############################################################################

        if p.GetRace() == RACE_DWARF:        # Dwarf Race

            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)       # Maces 
            p.AddSpell (199)            # 2 Handed Maces
            p.SetSkill (160, 1, 5)      # 2 Handed Maces

        #--- Initial Items ---
            p.AddItemToSlot (3, 6117, 1)    # Squire's shirt
            p.AddItemToSlot (6, 6118, 1)    # Squire's pants
            p.AddItemToSlot (7, 43, 1)      # Squire's boots
            p.AddItemToSlot (15, 2361, 1)   # battleworn hammer

            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread

    # ############################################################################

        if p.GetRace() == RACE_BLOOD_ELF:   # Blood elf Race

            p.AddSpell (201)                # Swords 
            p.SetSkill (43, 1, 5)           # Swords 
            p.AddSpell (202)                # 2 Handed Swords 
            p.SetSkill (55, 1, 5)          # 2 Handed Swords

        #--- Initial Items ---
            p.AddItemToSlot (3, 24143, 1)      # Initiate's Shirt
            p.AddItemToSlot (6, 24145, 1)      # Initiate's Pants
            p.AddItemToSlot (7, 24146, 1)      # Initiate's Boots
            p.AddItemToSlot (15, 23346, 1)   # Battleworn Sword

            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            
    # ############################################################################
                
        if p.GetRace() == RACE_DRAENEI:   # Draenei Race

            p.AddSpell (198)                # Maces
            p.SetSkill (54, 1, 5)           # Maces 
            p.AddSpell (199)                # 2 Handed Maces
            p.SetSkill (160, 1, 5)          # 2 Handed Maces

        #--- Initial Items ---
            p.AddItemToSlot (3, 23476, 1)      # Initiate's Shirt
            p.AddItemToSlot (6, 23477, 1)      # Initiate's Pants
            p.AddItemToSlot (15, 2361, 1)   # Battleworn hammer

            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
        
    # ############################### END PALADIN ##############################

#--------------------------------------------------------------------------------------------#

    # ############################### START PRIEST #############################

def Priest (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """ 
    print "Init class: Priest"

    p.ModifyBaseStats (STAT_TYPE_INTELLECT,  2)
    p.ModifyBaseStats (STAT_TYPE_SPIRIT,     3)
        
    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)

    if oneTimeInit:
        #--- Class Skills ---
        p.SetSkill (56, 1, 1)       # Holy

        #--- Other ---
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (5009)           # Wands
        p.SetSkill (228, 1, 5)      # Wands
        p.AddSpell (5019)           # Shoot
        p.AddSpell (2050)           # Lesser Heal Rank 1
        p.AddSpell (585)            # Smite Rank 1

        # ##### CUSTOM MODULES ########## #   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ########################### # 

        #--- Start Items UNIFIED ---        
        p.AddItemToSlot (24, 159, MAX_COUNT_SUPPLY)     # Refreshing Spring Water
        
    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_HUMAN:        # Human Race

            p.AddSpell (198)             # Maces
            p.SetSkill (54, 6, 10)       # Maces 

            p.AddItemToSlot (3, 53, 1)      # neophyte's shirt
            p.AddItemToSlot (4, 6098, 1)    # neophyte's robe
            p.AddItemToSlot (6, 52, 1)      # neophytes's pants
            p.AddItemToSlot (7, 51, 1)      # neophytes's boots
            p.AddItemToSlot (15, 36, 1)     # worn mace

        #--- Initial Items ---
            p.AddItemToSlot (25, 2070, MAX_COUNT_SUPPLY2)   # Darnassian Bleu

    # ############################################################################

        if p.GetRace() == RACE_NIGHT_ELF:        # Night Elf Race

            p.AddSpell (198)             # Maces
            p.SetSkill (54, 1, 5)        # Maces 

            p.AddItemToSlot (3, 53, 1)      # neophyte's shirt
            p.AddItemToSlot (4, 6119, 1)    # neophyte's robe
            p.AddItemToSlot (6, 52, 1)      # neophytes's pants
            p.AddItemToSlot (7, 51, 1)      # neophytes's boots
            p.AddItemToSlot (15, 36, 1)     # worn mace

        #--- Initial Items ---
             
            p.AddItemToSlot (25, 2070, MAX_COUNT_SUPPLY2)   # Darnassian Bleu

    # ############################################################################

        if p.GetRace() == RACE_DWARF:        # Dwarf Race

            p.AddSpell (198)             # Maces
            p.SetSkill (54, 1, 5)        # Maces 

            p.AddItemToSlot (3, 53, 1)      # neophyte's shirt
            p.AddItemToSlot (4, 6098, 1)    # neophyte's robe
            p.AddItemToSlot (6, 52, 1)      # neophytes's pants
            p.AddItemToSlot (7, 51, 1)      # neophytes's boots
            p.AddItemToSlot (15, 36, 1)     # worn mace

        #--- Initial Items ---
            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread

    # ############################################################################

        if p.GetRace() == RACE_UNDEAD:      # Undead Race

            p.AddSpell (198)                # Maces
            p.SetSkill (54, 1, 5)           # Maces 

            p.AddItemToSlot (3, 53, 1)      # neophyte's shirt
            p.AddItemToSlot (4, 6144, 1)    # neophyte's robe
            p.AddItemToSlot (6, 52, 1)      # neophytes's pants
            p.AddItemToSlot (7, 51, 1)      # neophytes's boots
            p.AddItemToSlot (15, 36, 1)     # worn mace

        #--- Initial Items ---
            p.AddItemToSlot (25, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_TROLL:       # Troll Race

            p.AddSpell (198)                # Maces
            p.SetSkill (54, 1, 5)           # Maces 

            p.AddItemToSlot (3, 53, 1)      # neophyte's shirt
            p.AddItemToSlot (4, 6144, 1)    # neophyte's robe
            p.AddItemToSlot (6, 52, 1)      # neophytes's pants
            p.AddItemToSlot (7, 51, 1)      # neophytes's boots
            p.AddItemToSlot (15, 36, 1)     # worn mace

        #--- Initial Items ---
            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread

    # ############################################################################

        if p.GetRace() == RACE_BLOOD_ELF:   # Blood Elf Race

            p.AddSpell (198)                # Maces
            p.SetSkill (54, 1, 5)           # Maces 

            p.AddItemToSlot (3, 53, 1)      # Neophyte's shirt
            p.AddItemToSlot (4, 20891, 1)    # Neophyte's robe
            p.AddItemToSlot (6, 52, 1)      # Neophyte's pants
            p.AddItemToSlot (7, 51, 1)      # Neophyte's boots
            p.AddItemToSlot (15, 20981, 1)     # Neophyte's Mace

        #--- Initial Items ---
             
            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            
    # ############################################################################

        if p.GetRace() == RACE_DRAENEI:     # Draenei Race

            p.AddSpell (28878)              # Inspiring Presence
            p.AddSpell (198)                # Maces
            p.SetSkill (54, 1, 5)           # Maces 

            p.AddItemToSlot (3, 6097, 1)      # Acolyte's Shirt
            p.AddItemToSlot (4, 23322, 1)    # Acolyte's Robe
            p.AddItemToSlot (6, 1396, 1)      # Acolyte's Pants
            p.AddItemToSlot (7, 59, 1)      # Acolyte's Shoes
            p.AddItemToSlot (15, 36, 1)     # Worn Mace

        #--- Initial Items ---
             
            p.AddItemToSlot (25, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
            
    # ############################### END PRIEST ##############################

#--------------------------------------------------------------------------------------------#

    # ############################### START ROGUE #############################

def Rogue (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Rogue"

    p.ModifyBaseStats (STAT_TYPE_STRENGTH, 1)
    p.ModifyBaseStats (STAT_TYPE_AGILITY,  3)
    p.ModifyBaseStats (STAT_TYPE_STAMINA,  1)

    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)
    
    if oneTimeInit:
        p.AddSpell (9077)           # Leather
        p.SetSkill (414, 1, 1)      # Leather

        #--- Class Skills ---
        p.SetSkill (38, 1, 1)       # Combat
        p.SetSkill (253, 1, 1)      # Assasination

        #--- Other ---
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (1180)           # Daggers
        p.SetSkill (173, 1, 5)      # Daggers
        p.AddSpell (2567)           # Thrown
        p.SetSkill (176, 1, 5)      # Thrown  
        p.AddSpell (2764)           # Throw
        p.AddSpell (1752)           # Sinister Strike Rank 1
        p.AddSpell (2098)           # Eviscerate Rank 1

        # ##### CUSTOM MODULES ########## #   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ########################### #

    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_HUMAN:        # Human Race

            p.AddItemToSlot (3, 49, 1)      # Footpad's shirt
            p.AddItemToSlot (6, 48, 1)      # Footpad's Pants
            p.AddItemToSlot (7, 47, 1)      # Footpad's shoes
            p.AddItemToSlot (15, 2092, 1)   # Worn dagger
            p.AddItemToSlot (17, 2947, MAX_COUNT_WPN)  # Small Throwing Knife
            
        #--- Initial Items ---
            p.AddItemToSlot (24, 2070, MAX_COUNT_SUPPLY2)   # Darnassian Bleu

    # ############################################################################

        if p.GetRace() == RACE_NIGHT_ELF:        # Night Elf Race

            p.AddItemToSlot (3, 49, 1)      # Footpad's shirt
            p.AddItemToSlot (6, 48, 1)      # Footpad's Pants
            p.AddItemToSlot (7, 47, 1)      # Footpad's shoes
            p.AddItemToSlot (15, 2092, 1)   # Worn dagger
            p.AddItemToSlot (17, 2947, MAX_COUNT_WPN)  # Small Throwing Knife

        #--- Initial Items ---
            p.AddItemToSlot (24, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread

    # ############################################################################

        if p.GetRace() == RACE_DWARF:        # Dwarf Race

            p.AddItemToSlot (3, 49, 1)      # Footpad's shirt
            p.AddItemToSlot (6, 48, 1)      # Footpad's Pants
            p.AddItemToSlot (7, 47, 1)      # Footpad's shoes
            p.AddItemToSlot (15, 2092, 1)   # Worn dagger
            p.AddItemToSlot (17, 3111, MAX_COUNT_WPN)  # Crude Throwing Axe

        #--- Initial Items ---
            p.AddItemToSlot (24, 4540, MAX_COUNT_SUPPLY2)    # Tough Hunk of Bread

    # ############################################################################

        if p.GetRace() == RACE_GNOME:        # Gnome Race

            p.AddItemToSlot (3, 49, 1)      # Footpad's shirt
            p.AddItemToSlot (6, 48, 1)      # Footpad's Pants
            p.AddItemToSlot (7, 47, 1)      # Footpad's shoes
            p.AddItemToSlot (15, 2092, 1)   # Worn dagger
            p.AddItemToSlot (17, 2947, MAX_COUNT_WPN)  # Small Throwing Knife

        #--- Initial Items ---
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky

    # ############################################################################

        if p.GetRace() == RACE_UNDEAD:        # Undead Race

            p.AddItemToSlot (3, 2105, 1)    # Thug shirt
            p.AddItemToSlot (6, 120, 1)     # Thug Pants
            p.AddItemToSlot (7, 121, 1)     # Thug shoes
            p.AddItemToSlot (15, 2092, 1)   # Worn dagger
            p.AddItemToSlot (17, 2947, MAX_COUNT_WPN)  # Small Throwing Knife
            
        #--- Initial Items ---
            p.AddItemToSlot (24, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_ORC:        # Orc Race

            p.AddItemToSlot (3, 2105, 1)    # Thug shirt
            p.AddItemToSlot (6, 120, 1)     # Thug Pants
            p.AddItemToSlot (7, 121, 1)     # Thug shoes
            p.AddItemToSlot (15, 2092, 1)   # Worn dagger
            p.AddItemToSlot (17, 3111, MAX_COUNT_WPN)  # Crude Throwing Axe
            
        #--- Initial Items ---
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky

    # ############################################################################

        if p.GetRace() == RACE_TROLL:        # Troll Race

            p.AddItemToSlot (3, 2105, 1)    # Thug shirt
            p.AddItemToSlot (6, 120, 1)     # Thug Pants
            p.AddItemToSlot (7, 121, 1)     # Thug shoes
            p.AddItemToSlot (15, 2092, 1)   # Worn dagger
            p.AddItemToSlot (17, 3111, MAX_COUNT_WPN)  # Crude Throwing Axe

        #--- Initial Items ---
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky

    # ############################################################################

        if p.GetRace() == RACE_BLOOD_ELF:   # Blood Elf Race

            p.AddItemToSlot (3, 20897, 1)      # lookout's shirt
            p.AddItemToSlot (6, 20896, 1)      # lookout's Pants
            p.AddItemToSlot (7, 20898, 1)      # lookout's shoes
            p.AddItemToSlot (15, 20982, 1)   # Sharp Dagger
            p.AddItemToSlot (17, 3111, MAX_COUNT_WPN)  # Crude Throwing Axe

        #--- Initial Items ---
            p.AddItemToSlot (24, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
        
    # ############################### END ROGUE #############################

#--------------------------------------------------------------------------------------------#

    # ############################### START SHAMAN ##########################

def Shaman (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Shaman"
   
    p.ModifyBaseStats (STAT_TYPE_STRENGTH,  1)
    p.ModifyBaseStats (STAT_TYPE_STAMINA,   1)    
    p.ModifyBaseStats (STAT_TYPE_INTELLECT, 3)
    p.ModifyBaseStats (STAT_TYPE_SPIRIT,    3)
    
    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)

    if oneTimeInit:
        p.AddSpell (9077)           # Leather
        p.SetSkill (414, 1, 1)      # Leather
        p.AddSpell (9116)           # Shield
        p.SetSkill (433, 1, 1)      # Shield

        #--- Class Skills ---
        p.SetSkill (375, 1, 1)      # Elemental Combat
        p.SetSkill (374, 1, 1)      # Restoration

        #--- Other ---
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (107)            # Block
        p.AddSpell (227)            # Staves
        p.SetSkill (136, 1, 5)      # Staves
        p.AddSpell (198)            # Maces
        p.SetSkill (54, 1, 5)       # Maces 
        p.AddSpell (403)            # Lightning Bolt Rank 1
        p.AddSpell (331)            # Healing Wave Rank 1

        # ##### CUSTOM MODULES ########## #   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM) 
        # ########################### #
       
        #--- Start Outfit UNIFIED --- 

      
        #--- Start Items UNIFIED ---        
        p.AddItemToSlot (24, 159, MAX_COUNT_SUPPLY)     # Refreshing Spring Water
        
    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_ORC:        # Orc Race
            p.AddItemToSlot (3, 154, 1)     # Primitive Mantle
            p.AddItemToSlot (6, 153, 1)     # Primitive Kilt
            p.AddItemToSlot (7, 51, 1)      # Novice's Boots
            p.AddItemToSlot (15, 36, 1)     # Worn Mace

        #--- Initial Items ---
            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky

    # ############################################################################

        if p.GetRace() == RACE_TROLL:        # Troll Race
        
            p.AddItemToSlot (3, 154, 1)     # Primitive Mantle
            p.AddItemToSlot (6, 153, 1)     # Primitive Kilt
            p.AddItemToSlot (7, 51, 1)      # Novice's Boots
            p.AddItemToSlot (15, 36, 1)     # Worn Mace
            
        #--- Initial Items ---
            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky

    # ############################################################################

        if p.GetRace() == RACE_TAUREN:        # Tauren Race
        
            p.AddItemToSlot (3, 154, 1)     # Primitive Mantle
            p.AddItemToSlot (6, 153, 1)     # Primitive Kilt
            p.AddItemToSlot (7, 51, 1)      # Novice's Boots
            p.AddItemToSlot (15, 36, 1)     # Worn Mace

        #--- Initial Items ---
            p.AddItemToSlot (26, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_DRAENEI:       # Draenei Race

            p.AddSpell (28878)                # Inspiring Presence
            p.AddItemToSlot (3, 23345, 1)     # Scout's Shirt
            p.AddItemToSlot (6, 23344, 1)     # Scout's Pants
            p.AddItemToSlot (7, 23348, 1)      # Scout's Boots
            p.AddItemToSlot (15, 36, 1)     # Worn Mace
            
        #--- Initial Items ---
            p.AddItemToSlot (24, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
        
    # ############################### END SHAMAN ############################

#--------------------------------------------------------------------------------------------#

    # ############################### START WARLOCK #########################

def Warlock (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Warlock"
    
    p.ModifyBaseStats (STAT_TYPE_STAMINA,   1)    
    p.ModifyBaseStats (STAT_TYPE_INTELLECT, 2)
    p.ModifyBaseStats (STAT_TYPE_SPIRIT,    2)
    
    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)
    
    if oneTimeInit:
        #--- Class Skills ---
        p.SetSkill (354, 1, 1)      # Demonology
        p.SetSkill (593, 1, 1)      # Destruction

        #--- Other ---
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (5009)           # Wands
        p.SetSkill (228, 1, 5)      # Wands
        p.AddSpell (1180)           # Daggers
        p.SetSkill (173, 1, 5)      # Daggers
        p.AddSpell (5019)           # Shoot
        p.AddSpell (686)            # Shadow Bolt Rank 1
        p.AddSpell (687)            # Demon Skin Rank 1

        # ##### CUSTOM MODULES ########## #   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ########################### #

        #--- Start Items UNIFIED ---        
        p.AddItemToSlot (24, 159, MAX_COUNT_SUPPLY)     # Refreshing Spring Water

    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_HUMAN:        # Human Race

        #--- Initial Items ---
            p.AddItemToSlot (3, 964, 1)     # acolyte's Shirt
            p.AddItemToSlot (4, 57, 1)      # acolyte's robe
            p.AddItemToSlot (6, 1396, 1)    # acolyte's pants
            p.AddItemToSlot (7, 59, 1)      # acolyte's shoes
            p.AddItemToSlot (15, 2092, 1)   # worn dagger

        #--- Initial Items ---
            p.AddItemToSlot (25, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_GNOME:        # Gnome Race

        #--- Initial Items ---
            p.AddItemToSlot (3, 964, 1)     # acolyte's Shirt
            p.AddItemToSlot (4, 57, 1)      # acolyte's robe
            p.AddItemToSlot (6, 1396, 1)    # acolyte's pants
            p.AddItemToSlot (7, 59, 1)      # acolyte's shoes
            p.AddItemToSlot (15, 2092, 1)   # worn dagger

        #--- Initial Items ---
            p.AddItemToSlot (25, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_UNDEAD:        # Undead Race

        #--- Initial Items ---
            p.AddItemToSlot (3, 964, 1)     # acolyte's Shirt
            p.AddItemToSlot (4, 6129, 1)    # acolyte's robe
            p.AddItemToSlot (6, 1396, 1)    # acolyte's pants
            p.AddItemToSlot (7, 59, 1)      # acolyte's shoes
            p.AddItemToSlot (15, 2092, 1)   # worn dagger

        #--- Initial Items ---
            p.AddItemToSlot (25, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_ORC:        # Orc Race

        #--- Initial Items ---
            p.AddItemToSlot (3, 964, 1)     # acolyte's Shirt
            p.AddItemToSlot (4, 6129, 1)    # acolyte's robe
            p.AddItemToSlot (6, 1396, 1)    # acolyte's pants
            p.AddItemToSlot (7, 59, 1)      # acolyte's shoes
            p.AddItemToSlot (15, 2092, 1)   # worn dagger

            p.AddItemToSlot (25, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
          
    # ############################################################################

        if p.GetRace() == RACE_BLOOD_ELF:   # Blood Elf Race

        #--- Initial Items ---
            p.AddItemToSlot (3, 6097, 1)     # Acolyte's Shirt
            p.AddItemToSlot (4, 20892, 1)      # Acolyte's Robe
            p.AddItemToSlot (6, 1396, 1)    # Acolyte's Pants
            p.AddItemToSlot (7, 59, 1)      # Acolyte's Shoes
            p.AddItemToSlot (15, 20983, 1)   # Worn Dagger

        #--- Initial Items ---
            p.AddItemToSlot (25, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap
          
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p) 
        
    # ############################### END WARLOCK ###########################
#--------------------------------------------------------------------------------------------#

    # ############################### START WARRIOR #########################

def Warrior (p, oneTimeInit):
    """ Add class-specific spells, skills and bonuses
    """
    print "Init class: Warrior"
    
    p.ModifyBaseStats (STAT_TYPE_STRENGTH,  3)
    p.ModifyBaseStats (STAT_TYPE_STAMINA,   2)    
    
    # Recalculates Health & Mana on Player Login/Creation
    Recalculate(p)
    
    if oneTimeInit:
        p.AddSpell (9077)           # Leather
        p.SetSkill (414, 1, 1)      # Leather
        p.AddSpell (8737)           # Mail
        p.SetSkill (413, 1, 1)      # Mail
        p.AddSpell (9116)           # Shield
        p.SetSkill (433, 1, 1)      # Shield

        #--- Class Skills ---
        p.SetSkill (26, 1, 1)       # Arms

        #--- Other ---
        p.SetSkill (95, 1, 5)       # Defense
        p.AddSpell (107)            # Block
        p.AddSpell (78)             # Heroic Strike
        p.AddSpell (2457)           # Battle stance
        
        # ##### CUSTOM MODULES ###########   
        CommonGift (p, GIFT)
        CommonWDDGCustomisation (p, SRV_CUSTOM)
        # ################################
    
    # Definition of Race Specific Spells, Skills, Start Items for Specified Class
    # ############################################################################

        if p.GetRace() == RACE_HUMAN:        # Human Race

            p.AddSpell (201)            # Swords
            p.SetSkill (43, 1, 5)      # Swords
            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)      # Maces 
            p.AddSpell (196)            # Axes
            p.SetSkill (44, 1, 5)       # Axes

        #--- Initial Items ---
            p.AddItemToSlot (3, 38, 1)      # recruit's shirt
            p.AddItemToSlot (6, 39, 1)      # recruit's pants
            p.AddItemToSlot (7, 40, 1)      # recruit's boots
            p.AddItemToSlot (15, 25, 1)     # worn short sword
            p.AddItemToSlot (16, 2362, 1)   # worn wooden shield
            
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            
    # ############################################################################

        if p.GetRace() == RACE_NIGHT_ELF:        # Night Elf Race

            p.AddSpell (201)            # Swords
            p.SetSkill (43, 1, 5)       # Swords
            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)       # Maces 
            p.AddSpell (1180)           # Daggers
            p.SetSkill (173, 1, 5)      # Daggers

        #--- Initial Items ---
            p.AddItemToSlot (3, 6120, 1)      # recruit's shirt
            p.AddItemToSlot (6, 6121, 1)      # recruit's pants
            p.AddItemToSlot (7, 6122, 1)      # recruit's boots
            p.AddItemToSlot (15, 25, 1)       # worn short sword
            p.AddItemToSlot (16, 2362, 1)     # worn wooden shield
            
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            
    # ############################################################################

        if p.GetRace() == RACE_DWARF:        # Dwarf Race

            p.AddSpell (197)            # Two-Handed Axes
            p.SetSkill (172, 1, 5)      # Two-Handed Axes
            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)       # Maces 
            p.AddSpell (196)            # Axes
            p.SetSkill (44, 1, 5)       # Axes

        #--- Initial Items ---
            p.AddItemToSlot (3, 38, 1)      # recruit's shirt
            p.AddItemToSlot (6, 39, 1)      # recruit's pants
            p.AddItemToSlot (7, 40, 1)      # recruit's boots
            p.AddItemToSlot (15, 12282, 1)  # Worn Battleaxe
            
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            
    # ############################################################################

        if p.GetRace() == RACE_GNOME:        # Gnome Race

            p.AddSpell (201)            # Swords
            p.SetSkill (43, 1, 5)       # Swords
            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)       # Maces 
            p.AddSpell (1180)           # Daggers
            p.SetSkill (173, 1, 5)      # Daggers

        #--- Initial Items ---
            p.AddItemToSlot (3, 38, 1)      # recruit's shirt
            p.AddItemToSlot (6, 39, 1)      # recruit's pants
            p.AddItemToSlot (7, 40, 1)      # recruit's boots
            p.AddItemToSlot (15, 25, 1)     # worn short sword
            p.AddItemToSlot (16, 2362, 1)   # worn wooden shield
            
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky
            
    # ############################################################################

        if p.GetRace() == RACE_UNDEAD:        # Undead Race

            p.AddSpell (201)            # Swords
            p.SetSkill (43, 1, 5)       # Swords
            p.AddSpell (202)            # Two-Handed Swords
            p.SetSkill (55, 1, 5)       # Two-Handed Swords
            p.AddSpell (1180)           # Daggers
            p.SetSkill (173, 1, 5)      # Daggers

        #--- Initial Items ---
            p.AddItemToSlot (3, 6125, 1)    # Brawler's Harness
            p.AddItemToSlot (6, 139, 1)     # Brawler's pants
            p.AddItemToSlot (7, 140, 1)     # Brawler's boots
            p.AddItemToSlot (15, 25, 1)     # worn short sword
            p.AddItemToSlot (16, 2362, 1)   # worn wooden shield
            
            p.AddItemToSlot (24, 4604, MAX_COUNT_SUPPLY2)   # Forest Mushroom Cap

    # ############################################################################

        if p.GetRace() == RACE_ORC:        # Orc Race

            p.AddSpell (197)            # Two-Handed Axes
            p.SetSkill (172, 1, 5)      # Two-Handed Axes
            p.AddSpell (196)            # Axes
            p.SetSkill (44, 1, 5)       # Axes
            p.AddSpell (201)            # Swords
            p.SetSkill (43, 1, 5)       # Swords

        #--- Initial Items ---
            p.AddItemToSlot (3, 6125, 1)    # Brawler's Harness
            p.AddItemToSlot (6, 139, 1)     # Brawler's pants
            p.AddItemToSlot (7, 140, 1)     # Brawler's boots
            p.AddItemToSlot (15, 12282, 1)  # Worn Battleaxe
            
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky

    # ############################################################################

        if p.GetRace() == RACE_TROLL:        # Troll Race

            p.AddSpell (196)            # Axes
            p.SetSkill (44, 1, 5)       # Axes
            p.AddSpell (1180)           # Daggers
            p.SetSkill (173, 1, 5)      # Daggers
            p.AddSpell (2567)           # Thrown
            p.SetSkill (176, 1, 5)      # Thrown
            p.AddSpell (2764)           # Throw

        #--- Initial Items ---
            p.AddItemToSlot (3, 6125, 1)    # Brawler's Harness
            p.AddItemToSlot (6, 139, 1)     # Brawler's pants
            p.AddItemToSlot (7, 140, 1)     # Brawler's boots
            p.AddItemToSlot (15, 37, 1)     # Worn Short Axe
            p.AddItemToSlot (16, 2362, 1)   # worn wooden shield
            p.AddItemToSlot (17, 3111, MAX_COUNT_AMMO)  # Crude Throwing Axe
            
            p.AddItemToSlot (24, 117, MAX_COUNT_SUPPLY2)    # Tough Jerky

    # ############################################################################

        if p.GetRace() == RACE_TAUREN:        # Tauren Race

            p.AddSpell (199)            # Two-Handed Maces
            p.SetSkill (160, 1, 5)      # Two-Handed Maces
            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)       # Maces 
            p.AddSpell (196)            # Axes
            p.SetSkill (44, 1, 5)       # Axes

        #--- Initial Items ---
            p.AddItemToSlot (3, 6125, 1)    # Brawler's Harness
            p.AddItemToSlot (6, 139, 1)     # Brawler's pants
            p.AddItemToSlot (7, 140, 1)     # Brawler's boots
            p.AddItemToSlot (15, 2361, 1)   # Battleworn Hammer
            
            p.AddItemToSlot (24, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread

    # ############################################################################

        if p.GetRace() == RACE_DRAENEI: # Draenei Race

            p.AddSpell (6562)           # Heoric Presence
            p.AddSpell (201)            # Swords
            p.SetSkill (43, 1, 5)       # Swords
            p.AddSpell (198)            # Maces
            p.SetSkill (54, 1, 5)       # Maces 
            p.AddSpell (1180)           # Daggers
            p.SetSkill (173, 1, 5)      # Daggers

        #--- Initial Items ---
            p.AddItemToSlot (3, 23473, 1)      # Recruit's shirt
            p.AddItemToSlot (6, 23474, 1)      # Recruit's pants
            p.AddItemToSlot (7, 23475, 1)      # Recruit's boots
            p.AddItemToSlot (15, 23346, 1)       # Battleworn Claymore

            
            p.AddItemToSlot (24, 4540, MAX_COUNT_SUPPLY2)   # Tough Hunk of Bread
            
#--------------------------------------------------------------------------------------------#
        # Setting Action Buttons
        ActionButtons(p)
            
    # ############################### END WARRIOR ################################
        
# REPUTATION SETTINGS  ################################################################################
#--------------------------------------------------------------------------------------------#

# !!! OBSOLETE, initial Reputation is set via core from DBC storage:

# Note: All start values for Reputation are 0. Client has got defaults so we do not worry what initiall value shall be.
#          If Value for command SetReputation(Index,Value) is 17, then Reputation for the specified Area is activated for player. Like for 
#          Alliance all Cities got 17, and the same for Horde.

# OBSOLETE, initial Reputation is set via core from DBC storage:
def Reputation (p):
    """ Initial settings for Reputation Values for every Race
    """
   # print "Init Reputation"
    
    # ALLIANCE REPUTATION ################################################
    if  p.GetRace() == RACE_HUMAN or \
        p.GetRace() == RACE_DWARF or \
        p.GetRace() == RACE_NIGHT_ELF or \
        p.GetRace() == RACE_DRAENEI or \
        p.GetRace() == RACE_GNOME:
        # 1
        p.SetReputation(0, 2)
        p.SetReputationValue(0, 0)
        # 2
        p.SetReputation(1, 0)
        p.SetReputationValue(1, 0)
        # 3
        p.SetReputation(2, 2)
        p.SetReputationValue(2, 0)
        # 4
        p.SetReputation(3, 2)
        p.SetReputationValue(3, 0)    
        # 5
        p.SetReputation(4, 16)
        p.SetReputationValue(4, 0)    
        # 6
        p.SetReputation(5, 0)
        p.SetReputationValue(5, 0)
        # 7
        p.SetReputation(6, 2)
        p.SetReputationValue(6, 0)
        # 8
        p.SetReputation(7, 0)
        p.SetReputationValue(7, 0)
        # 9
        p.SetReputation(8, 16)
        p.SetReputationValue(8, 0)    
        # 10
        p.SetReputation(9, 0)
        p.SetReputationValue(9, 0)  
        # 11
        p.SetReputation(10, 8)
        p.SetReputationValue(10, 0)
        # 12
        p.SetReputation(11, 9)
        p.SetReputationValue(11, 0)
        # 13
        p.SetReputation(12, 14)
        p.SetReputationValue(12, 0)
        # 14
        p.SetReputation(13, 0)
        p.SetReputationValue(13, 0)    
        # Orgrimmar
        p.SetReputation(14, 6)
        p.SetReputationValue(14, 0)    
        # Darkspear Trolls
        p.SetReputation(15, 6)
        p.SetReputationValue(15, 0)
        # Thunder Bluff
        p.SetReputation(16, 6)
        p.SetReputationValue(16, 0)
        # Undercity
        p.SetReputation(17, 6)
        p.SetReputationValue(17, 0)
        # Gnomeregan Exiles
        p.SetReputation(18, 17)
        p.SetReputationValue(18, 0)
        # Stormwind
        p.SetReputation(19, 17)
        p.SetReputationValue(19, 0) 
        # Ironforge
        p.SetReputation(20, 17)
        p.SetReputationValue(20, 0)
        # Darnassus
        p.SetReputation (21, 17)
        p.SetReputationValue (21, 0)
        # 23
        p.SetReputation(22, 4)
        p.SetReputationValue(22, 0)
        # 24
        p.SetReputation(23, 4)
        p.SetReputationValue(23, 0)    
        # 25
        p.SetReputation(24, 4)
        p.SetReputationValue(24, 0)    
        # 26
        p.SetReputation(25, 4)
        p.SetReputationValue(25, 0)
        # 27
        p.SetReputation(26, 4)
        p.SetReputationValue(26, 0)
        # 28
        p.SetReputation(27, 0)
        p.SetReputationValue(27, 0)
        # 29
        p.SetReputation(28, 0)
        p.SetReputationValue(28, 0)    
        # 30
        p.SetReputation(29, 4)
        p.SetReputationValue(29, 0) 
        # 31
        p.SetReputation(30, 4)
        p.SetReputationValue(30, 0)
        # 32
        p.SetReputation(31, 4)
        p.SetReputationValue(31, 0)
        # 33
        p.SetReputation(32, 4)
        p.SetReputationValue(32, 0)
        # 34
        p.SetReputation(33, 4)
        p.SetReputationValue(33, 0)    
        # 35
        p.SetReputation(34, 4)
        p.SetReputationValue(34, 0)    
        # 36
        p.SetReputation(35, 2)
        p.SetReputationValue(35, 0)
        # 37
        p.SetReputation(36, 0)
        p.SetReputationValue(36, 0)
        # 38
        p.SetReputation(37, 0)
        p.SetReputationValue(37, 0)
        # 39
        p.SetReputation(38, 2)
        p.SetReputationValue(38, 0)    
        # 40
        p.SetReputation(39, 20)
        p.SetReputationValue(39, 0)   
        # 41
        p.SetReputation(40, 16)
        p.SetReputationValue(40, 0)
        # 42
        p.SetReputation(41, 2)
        p.SetReputationValue(41, 0)
        # 43
        p.SetReputation(42, 0)
        p.SetReputationValue(42, 0)
        # 44
        p.SetReputation(43, 16)
        p.SetReputationValue(43, 0)    
        # 45
        p.SetReputation(44, 16)
        p.SetReputationValue(44, 0)    
        # 46
        p.SetReputation(45, 16)
        p.SetReputationValue(45, 0)
        # 47
        p.SetReputation(46, 6)
        p.SetReputationValue(46, 0)
        # 48
        p.SetReputation(47, 24)
        p.SetReputationValue(47, 0)
        # 49
        p.SetReputation(48, 14)
        p.SetReputationValue(48, 0)    
        # 50
        p.SetReputation(49, 6)
        p.SetReputationValue(49, 0)  
        # 51
        p.SetReputation(50, 0)
        p.SetReputationValue(50, 0)
        # 52
        p.SetReputation(51, 0)
        p.SetReputationValue(51, 0)
        # 53
        p.SetReputation(52, 0)
        p.SetReputationValue(52, 0)
        # 54
        p.SetReputation(53, 0)
        p.SetReputationValue(53, 0)    
        # 55
        p.SetReputation(54, 0)
        p.SetReputationValue(54, 0)    
        # 56
        p.SetReputation(55, 0)
        p.SetReputationValue(55, 0)
        # 57
        p.SetReputation(56, 0)
        p.SetReputationValue(56, 0)
        # 58
        p.SetReputation(57, 0)
        p.SetReputationValue(57, 0)
        # 59
        p.SetReputation(58, 0)
        p.SetReputationValue(58, 0)    
        # 60
        p.SetReputation(59, 0)
        p.SetReputationValue(59, 0)  
        # 61
        p.SetReputation(60, 0)
        p.SetReputationValue(60, 0)
        # 62
        p.SetReputation(61, 0)
        p.SetReputationValue(61, 0)
        # 63
        p.SetReputation(62, 0)
        p.SetReputationValue(62, 0)
        # 64
        p.SetReputation(63, 0)
        p.SetReputationValue(63, 0)    

    # HORDE REPUTATION ################################################    
    if  p.GetRace() == RACE_ORC or \
        p.GetRace() == RACE_UNDEAD or \
        p.GetRace() == RACE_TAUREN or \
        p.GetRace() == RACE_BLOOD_ELF or \
        p.GetRace() == RACE_TROLL:
        # 1
        p.SetReputation(0, 2)
        p.SetReputationValue(0, 0)
        # 2
        p.SetReputation(1, 0)
        p.SetReputationValue(1, 0)
        # 3
        p.SetReputation(2, 2)
        p.SetReputationValue(2, 0)
        # 4
        p.SetReputation(3, 2)
        p.SetReputationValue(3, 0)    
        # 5
        p.SetReputation(4, 16)
        p.SetReputationValue(4, 0)    
        # 6
        p.SetReputation(5, 0)
        p.SetReputationValue(5, 0)
        # 7
        p.SetReputation(6, 2)
        p.SetReputationValue(6, 0)
        # 8
        p.SetReputation(7, 0)
        p.SetReputationValue(7, 0)
        # 9
        p.SetReputation(8, 22)
        p.SetReputationValue(8, 0)    
        # 10
        p.SetReputation(9, 0)
        p.SetReputationValue(9, 0)  
        # 11
        p.SetReputation(10, 8)
        p.SetReputationValue(10, 0)
        # 12
        p.SetReputation(11, 14)
        p.SetReputationValue(11, 0)
        # 13
        p.SetReputation(12, 9)
        p.SetReputationValue(12, 0)
        # 14
        p.SetReputation(13, 0)
        p.SetReputationValue(13, 0)    
        # Orgrimmar
        p.SetReputation(14, 17)
        p.SetReputationValue(14, 0)    
        # Darkspear Trolls
        p.SetReputation(15, 17)
        p.SetReputationValue(15, 0)
        # Thunder Bluff
        p.SetReputation(16, 17)
        p.SetReputationValue(16, 0)
        # Undercity
        p.SetReputation(17, 17)
        p.SetReputationValue(17, 0)
        # Gnomeregan Exiles
        p.SetReputation(18, 6)
        p.SetReputationValue(18, 0)
        # Stormwind
        p.SetReputation(19, 6)
        p.SetReputationValue(19, 0) 
        # Ironforge
        p.SetReputation(20, 6)
        p.SetReputationValue(20, 0)
        # Darnassus
        p.SetReputation (21, 6)
        p.SetReputationValue (21, 0)
        # 23
        p.SetReputation(22, 4)
        p.SetReputationValue(22, 0)
        # 24
        p.SetReputation(23, 4)
        p.SetReputationValue(23, 0)    
        # 25
        p.SetReputation(24, 4)
        p.SetReputationValue(24, 0)    
        # 26
        p.SetReputation(25, 4)
        p.SetReputationValue(25, 0)
        # 27
        p.SetReputation(26, 4)
        p.SetReputationValue(26, 0)
        # 28
        p.SetReputation(27, 6)
        p.SetReputationValue(27, 0)
        # 29
        p.SetReputation(28, 0)
        p.SetReputationValue(28, 0)    
        # 30
        p.SetReputation(29, 4)
        p.SetReputationValue(29, 0) 
        # 31
        p.SetReputation(30, 4)
        p.SetReputationValue(30, 0)
        # 32
        p.SetReputation(31, 4)
        p.SetReputationValue(31, 0)
        # 33
        p.SetReputation(32, 4)
        p.SetReputationValue(32, 0)
        # 34
        p.SetReputation(33, 4)
        p.SetReputationValue(33, 0)    
        # 35
        p.SetReputation(34, 4)
        p.SetReputationValue(34, 0)    
        # 36
        p.SetReputation(35, 2)
        p.SetReputationValue(35, 0)
        # 37
        p.SetReputation(36, 0)
        p.SetReputationValue(36, 0)
        # 38
        p.SetReputation(37, 0)
        p.SetReputationValue(37, 0)
        # 39
        p.SetReputation(38, 0)
        p.SetReputationValue(38, 0)    
        # 40
        p.SetReputation(39, 20)
        p.SetReputationValue(39, 0)   
        # 41
        p.SetReputation(40, 2)
        p.SetReputationValue(40, 0)
        # 42
        p.SetReputation(41, 2)
        p.SetReputationValue(41, 0)
        # 43
        p.SetReputation(42, 0)
        p.SetReputationValue(42, 0)
        # 44
        p.SetReputation(43, 16)
        p.SetReputationValue(43, 0)    
        # 45
        p.SetReputation(44, 16)
        p.SetReputationValue(44, 0)    
        # 46
        p.SetReputation(45, 06)
        p.SetReputationValue(45, 0)
        # 47
        p.SetReputation(46, 16)
        p.SetReputationValue(46, 0)
        # 48
        p.SetReputation(47, 14)
        p.SetReputationValue(47, 0)
        # 49
        p.SetReputation(48, 24)
        p.SetReputationValue(48, 0)    
        # 50
        p.SetReputation(49, 16)
        p.SetReputationValue(49, 0)  
        # 51
        p.SetReputation(50, 16)
        p.SetReputationValue(50, 0)
        # 52
        p.SetReputation(51, 16)
        p.SetReputationValue(51, 0)
        # 53
        p.SetReputation(52, 16)
        p.SetReputationValue(52, 0)
        # 54
        p.SetReputation(53, 2)
        p.SetReputationValue(53, 0)    
        # 55
        p.SetReputation(54, 0)
        p.SetReputationValue(54, 0)    
        # 56
        p.SetReputation(55, 0)
        p.SetReputationValue(55, 0)
        # 57
        p.SetReputation(56, 0)
        p.SetReputationValue(56, 0)
        # 58
        p.SetReputation(57, 0)
        p.SetReputationValue(57, 0)
        # 59
        p.SetReputation(58, 0)
        p.SetReputationValue(58, 0)    
        # 60
        p.SetReputation(59, 0)
        p.SetReputationValue(59, 0)  
        # 61
        p.SetReputation(60, 0)
        p.SetReputationValue(60, 0)
        # 62
        p.SetReputation(61, 0)
        p.SetReputationValue(61, 0)
        # 63
        p.SetReputation(62, 0)
        p.SetReputationValue(62, 0)
        # 64
        p.SetReputation(63, 0)
        p.SetReputationValue(63, 0)  

#--------------------------------------------------------------------------------------------#

# #############################################################################################
# ##
# ##  HEALTH & MANA RECALCULATION
# ##  This module sets Initial Health/Mana values to Start Chars and also Recalculates Health/Mana/Rage/Energy on Player Login
# #############################################################################################

# Stats recalculations
def cubicPolynome (level, a3, a2, a1, a0):
    v = float(a3) * float(level*level*level) + float(a2) * float(level*level) + float(a1) * float(level) + float(a0)
    return float(v)
    
# Get Level-Up Stats values
def GetStatsPerLevel(u, stat_type):

    level           = u.GetLevel()
    
    # We recalculate only > 1 level
    if level == 1: return 0.0
    
    cls             = u.GetClass()
    str_on_level    = 0.0
    agi_on_level    = 0.0
    sta_on_level    = 0.0
    int_on_level    = 0.0
    spi_on_level    = 0.0

    if cls == CLASS_DRUID:
        str_on_level = cubicPolynome (level, 0.000021, 0.003009, 0.486493, -0.400003)
        agi_on_level = cubicPolynome (level, 0.000041, 0.000440, 0.512076, -1.000317)
        sta_on_level = cubicPolynome (level, 0.000023, 0.003345, 0.560050, -0.562058)
        int_on_level = cubicPolynome (level, 0.000038, 0.005145, 0.871006, -0.832029)
        spi_on_level = cubicPolynome (level, 0.000059, 0.004044, 1.040000, -1.488504)

    if cls == CLASS_HUNTER:
        str_on_level = cubicPolynome (level, 0.000022, 0.001800, 0.407867, -0.550889)
        agi_on_level = cubicPolynome (level, 0.000040, 0.007416, 1.125108, -1.003045)
        sta_on_level = cubicPolynome (level, 0.000031, 0.004480, 0.780040, -0.800471)
        int_on_level = cubicPolynome (level, 0.000020, 0.003007, 0.505215, -0.500642)
        spi_on_level = cubicPolynome (level, 0.000017, 0.003803, 0.536846, -0.490026)

    if cls == CLASS_MAGE:
        str_on_level = cubicPolynome (level, 0.000002, 0.001003, 0.100890, -0.076055)
        agi_on_level = cubicPolynome (level, 0.000008, 0.001001, 0.163190, -0.064280)
        sta_on_level = cubicPolynome (level, 0.000006, 0.002031, 0.278360, -0.340077)
        int_on_level = cubicPolynome (level, 0.000040, 0.007416, 1.125108, -1.003045)
        spi_on_level = cubicPolynome (level, 0.000039, 0.006981, 1.090090, -1.006070)

    if cls == CLASS_PALADIN:
        str_on_level = cubicPolynome (level, 0.000037, 0.005455, 0.940039, -1.000090)
        agi_on_level = cubicPolynome (level, 0.000020, 0.003007, 0.505215, -0.500642)
        sta_on_level = cubicPolynome (level, 0.000038, 0.005145, 0.871006, -0.832029)
        int_on_level = cubicPolynome (level, 0.000023, 0.003345, 0.560050, -0.562058)
        spi_on_level = cubicPolynome (level, 0.000032, 0.003025, 0.615890, -0.640307)

    if cls == CLASS_PRIEST:
        str_on_level = cubicPolynome (level, 0.000008, 0.001001, 0.163190, -0.064280)
        agi_on_level = cubicPolynome (level, 0.000022, 0.000022, 0.260756, -0.494000)
        sta_on_level = cubicPolynome (level, 0.000024, 0.000981, 0.364935, -0.570900)
        int_on_level = cubicPolynome (level, 0.000039, 0.006981, 1.090090, -1.006070)
        spi_on_level = cubicPolynome (level, 0.000040, 0.007416, 1.125108, -1.003045)

    if cls == CLASS_ROGUE:
        str_on_level = cubicPolynome (level, 0.000025, 0.004170, 0.654096, -0.601491)
        agi_on_level = cubicPolynome (level, 0.000038, 0.007834, 1.191028, -1.203940)
        sta_on_level = cubicPolynome (level, 0.000032, 0.003025, 0.615890, -0.640307)
        int_on_level = cubicPolynome (level, 0.000008, 0.001001, 0.163190, -0.064280)
        spi_on_level = cubicPolynome (level, 0.000024, 0.000981, 0.364935, -0.570900)

    if cls == CLASS_SHAMAN:
        str_on_level = cubicPolynome (level, 0.000035, 0.003641, 0.734310, -0.800626)
        agi_on_level = cubicPolynome (level, 0.000022, 0.001800, 0.407867, -0.550889)
        sta_on_level = cubicPolynome (level, 0.000020, 0.006030, 0.809570, -0.809220)
        int_on_level = cubicPolynome (level, 0.000031, 0.004480, 0.780040, -0.800471)
        spi_on_level = cubicPolynome (level, 0.000038, 0.005145, 0.871006, -0.832029)

    if cls == CLASS_WARLOCK:
        str_on_level = cubicPolynome (level, 0.000006, 0.002031, 0.278360, -0.340077)
        agi_on_level = cubicPolynome (level, 0.000024, 0.000981, 0.364935, -0.570900)
        sta_on_level = cubicPolynome (level, 0.000021, 0.003009, 0.486493, -0.400003)
        int_on_level = cubicPolynome (level, 0.000059, 0.004044, 1.040000, -1.488504)
        spi_on_level = cubicPolynome (level, 0.000040, 0.006404, 1.038791, -1.039076)

    if cls == CLASS_WARRIOR:
        str_on_level = cubicPolynome (level, 0.000039, 0.006902, 1.080040, -1.051701)
        agi_on_level = cubicPolynome (level, 0.000022, 0.004600, 0.655333, -0.600356)
        sta_on_level = cubicPolynome (level, 0.000059, 0.004044, 1.040000, -1.488504)
        int_on_level = cubicPolynome (level, 0.000002, 0.001003, 0.100890, -0.076055)
        spi_on_level = cubicPolynome (level, 0.000006, 0.002031, 0.278360, -0.340077)

    return_value = 0.0
        
    if   stat_type == STAT_TYPE_STRENGTH:     return_value = float(str_on_level) / float(level - 1)
    elif stat_type == STAT_TYPE_AGILITY:      return_value = float(agi_on_level) / float(level - 1)
    elif stat_type == STAT_TYPE_STAMINA:      return_value = float(sta_on_level) / float(level - 1)
    elif stat_type == STAT_TYPE_INTELLECT:    return_value = float(int_on_level) / float(level - 1)  
    elif stat_type == STAT_TYPE_SPIRIT:       return_value = float(spi_on_level) / float(level - 1)

    return return_value

# Get Base Mana recalculated for level
def GetBaseManaPerLevel(u):
    
    TYPE_ID__MANA = 1
    
    level           = u.GetLevel()
    cls             = u.GetClass()
    race            = u.GetRace()
    
    mana_per_level   = 0.0

    # use external file for per  level stats pickup if enabled
    if cfg.PLAYER_USE_FILE_FOR_STATS == TRUE: 
        mana_per_level = StatsLoader.GetValuePerLevel(TYPE_ID__MANA, race, cls, level)
        if mana_per_level > 0: return mana_per_level
    
    #to-do: get dependecies class/race
    if   cls == CLASS_DRUID:    mana_per_level = 23.0
    elif cls == CLASS_HUNTER:   mana_per_level = 18.0
    elif cls == CLASS_MAGE:     mana_per_level = 25.0
    elif cls == CLASS_PALADIN:  mana_per_level = 19.0
    elif cls == CLASS_PRIEST:   mana_per_level = 24.0
    elif cls == CLASS_SHAMAN:   mana_per_level = 20.0
    elif cls == CLASS_WARLOCK:  mana_per_level = 23.0

    return mana_per_level

# Get Base Health recalculated for level
def GetBaseHealthPerLevel(u):

    TYPE_ID__HEALTH = 0

    level           = u.GetLevel()
    cls             = u.GetClass()
    race            = u.GetRace()
    
    health_per_level = 0.0

    # use external file for per  level stats pickup if enabled
    if cfg.PLAYER_USE_FILE_FOR_STATS == TRUE: 
        health_per_level = StatsLoader.GetValuePerLevel(TYPE_ID__HEALTH, race, cls, level)
        if health_per_level > 0: return health_per_level
    
    #to-do: get dependecies class/race
    if   cls == CLASS_DRUID:    health_per_level = 8.0
    elif cls == CLASS_HUNTER:   health_per_level = 17.0
    elif cls == CLASS_MAGE:     health_per_level = 15.0
    elif cls == CLASS_PALADIN:  health_per_level = 18.0
    elif cls == CLASS_PRIEST:   health_per_level = 15.0
    elif cls == CLASS_ROGUE:    health_per_level = 19.0
    elif cls == CLASS_SHAMAN:   health_per_level = 17.0
    elif cls == CLASS_WARLOCK:  health_per_level = 15.0
    elif cls == CLASS_WARRIOR:  health_per_level = 19.0
    
    return health_per_level
    
# Note! All Max mana and health are set on recalculation of stats, this affect its level through setting of base mana/health and bound stats like spirit, intellect and etc...
def Recalculate(p):

   # print "Setting Initial Values for Health/Mana/RAGE/ENERGY (1st Level) ..."

    # ############################### START DRUID  ##############################
    if p.GetClass() == CLASS_DRUID:
        if p.GetRace() == RACE_TAUREN:
            p.SetBaseStartHealth     (38)
            p.SetBaseStartMana       (50)
        else:
            p.SetBaseStartHealth     (34)
            p.SetBaseStartMana       (50)
    # ############################### START HUNTER ##############################
    if p.GetClass() == CLASS_HUNTER:
        p.SetBaseStartHealth     (26)
        p.SetBaseStartMana       (65)
    # ############################### START MAGE ################################
    if p.GetClass() == CLASS_MAGE:
        p.SetBaseStartHealth     (32)
        p.SetBaseStartMana       (100)
    # ############################### START PALADIN ############################
    if p.GetClass() == CLASS_PALADIN:
        p.SetBaseStartHealth     (18)
        p.SetBaseStartMana       (60)
    # ############################### START PRIEST #############################
    if p.GetClass() == CLASS_PRIEST:
        p.SetBaseStartHealth     (32)
        p.SetBaseStartMana       (110)
    # ############################### START ROGUE #############################
    if p.GetClass() == CLASS_ROGUE:
        p.SetMaxEnergy  (100)
        p.SetEnergy     (100)
        p.SetBaseStartHealth     (25)
    # ############################### START SHAMAN ##########################
    if p.GetClass() == CLASS_SHAMAN:
        if p.GetRace() == RACE_TAUREN:
            p.SetBaseStartHealth     (31)
            p.SetBaseStartMana       (55)
        else:
            p.SetBaseStartHealth     (27)
            p.SetBaseStartMana       (55)
    # ############################### START WARLOCK #########################
    if p.GetClass() == CLASS_WARLOCK:
        if p.GetRace() == RACE_HUMAN:
            p.SetBaseStartHealth     (23)
            p.SetBaseStartMana       (100)
        else:
            p.SetBaseStartHealth     (23)
            p.SetBaseStartMana       (90)
    # ############################### START WARRIOR #########################
    if p.GetClass() == CLASS_WARRIOR:
        p.SetRage (0)
        p.SetMaxRage (1000)
        p.SetBaseStartHealth     (20)
# #############################################################################################
# ##
# ##  SETTING ACTION BUTTONS
# ##  
# #############################################################################################

def ioctlValue(i): 
    if i & 0x80000000: 
        i = -((i^0xffffffff)+1) 
    return i 

def ActionButtons(p):

    print "Setting Action Buttons ..."
    
    # ## Common to all ACTION BUTTONS TEMPLATE

    data =[ 0x000019CB  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ,   0x00000000  ,   0x00000000  ,   0x00000000  ,
            0x00000000  ]                       

    """
    Panel#1 72 - 83
    Panel#2 12 - 23
    
    Drink:
    Refreshing spring water (159)
    
    Food:
    Tough Jerky             (117)
    Darnassian Blue         (2070)
    Forest Mushroom Cap     (4604)
    Tough Hunk of Bread     (4540)
    Shiny Red Apple         (4536)
    """
    
    #p.SetActionButton(72, 6603) # Attack
    
    # SETTING FOOD
    if p.GetSlotByItemID(117)   != 0xFF: data [11] =  0x75   + 0x80000000
    if p.GetSlotByItemID(2070)  != 0xFF: data [11] =  0x816  + 0x80000000
    if p.GetSlotByItemID(4604)  != 0xFF: data [11] =  0x11FC + 0x80000000
    if p.GetSlotByItemID(4540)  != 0xFF: data [11] =  0x11BC + 0x80000000
    if p.GetSlotByItemID(4536)  != 0xFF: data [11] =  0x11B8 + 0x80000000
    # SETTING DRINK
    if p.GetSlotByItemID(159)   != 0xFF: data [10] =  0x9F   + 0x80000000
    
    # ############################### START DRUID  ##############################
    
    if p.GetClass() == CLASS_DRUID:
        data [1] = 0x00001438
        data [2] = 0x00001441

    # ############################### START HUNTER ##############################

    if p.GetClass() == CLASS_HUNTER:
        data [1] = 0x00000B9D
        data [2] = 0x0000004B

    # ############################### START MAGE ################################

    if p.GetClass() == CLASS_MAGE:
        data [1] = 0x00000085
        data [2] = 0x000000A8

    # ############################### START PALADIN ############################

    if p.GetClass() == CLASS_PALADIN:
        data [1] = 0x00004EBA
        data [2] = 0x0000027B

    # ############################### START PRIEST #############################
    
    if p.GetClass() == CLASS_PRIEST:
        data [1] = 0x00000249
        data [2] = 0x00000802
  
    # ############################### START ROGUE #############################

    if p.GetClass() == CLASS_ROGUE:
        data [1] = 0x000006D8
        data [2] = 0x00000832
        data [3] = 0x00000ACC

    # ############################### START SHAMAN ##########################

    if p.GetClass() == CLASS_SHAMAN:
        data [1] = 0x00000193
        data [2] = 0x0000014B

    # ############################### START WARLOCK #########################

    if p.GetClass() == CLASS_WARLOCK:
        data [1] = 0x000002AE
        data [2] = 0x000002AF

    # ############################### START WARRIOR #########################

    if p.GetClass() == CLASS_WARRIOR:
        data [1] = 0x0000004E
        data [72] = 0x000019CB
        data [73] = 0x0000004E
    
    # Passing Data to Client
    for step in range(0,120):
        p.SetActionButton(step, ioctlValue(data[step]))
            
# #############################################################################################
# ##
# ##  RACE-COMMON & COMMON-CUSTOMISING FUNCTIONS
# ##
# #############################################################################################

# COMMON-CUSTOMISING #########################################################################
#--CommonGift------------------------------------------------------------------------------------------#

def CommonGift (p, GIFT):
    """ Gift to our Dearest Ladies
    """
    print "Init custom module COMMON GIFT"
    
    if GIFT:
        if p.GetGender() == GENDER_FEMALE:
            p.AddItemToSlot (38, 3421, 1)   # Simple Wildflowers

# COMMON-CUSTOMISING #########################################################################
#--Common Customisation-----------------------------------------------------------------------#

def CommonWDDGCustomisation (p, SRV_CUSTOM):
    """ Customised start items (Welcome Letter & Gift Voucher)
    """
    """ Attention !:
    Customised items shall be added starting from the end of bagpack (38 slot),
    currently items put starting from slot 37 with enabled CommonGift function,
    which puts Gift to slot 38. 
    All Races for different Classes have different number of start items.
    """ 
 #   print "Init custom module COMMON WDDG"

    if SRV_CUSTOM:

        if p.GetRace() == RACE_HUMAN:        # Human Race
            #p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14646, 1) # Northshire Gift Voucher - Human

        if p.GetRace() == RACE_ORC:        # Orc Race
            #p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14649, 1) # Valley of Trials Gift Voucher - Orc Troll

        if p.GetRace() == RACE_DWARF:        # Dwarf Race
            #p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14647, 1) # Coldridge Valley Gift Voucher - Dwarf Gnome

        if p.GetRace() == RACE_NIGHT_ELF:        # Night Elf Race
            # p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14648, 1) # Shadowglen Gift Voucher - Night Elf

        if p.GetRace() == RACE_UNDEAD:        # Undead Race
            #p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14651, 1) # Deathknell Gift Voucher - Undead

        if p.GetRace() == RACE_TAUREN:        # Tauren Race
            #p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14650, 1) # Camp Narache Gift Voucher - Tauren

        if p.GetRace() == RACE_GNOME:        # Gnome Race
            #p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14647, 1) # Coldridge Valley Gift Voucher - Dwarf Gnome

        if p.GetRace() == RACE_TROLL:        # Troll Race
            #p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 14649, 1) # Valley of Trials Gift Voucher - Orc Troll
            
        if p.GetRace() == RACE_DRAENEI:        # Draenei Race
            # p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 22888, 1) # Ammen Vale Gift Voucher - Draenei

        if p.GetRace() == RACE_BLOOD_ELF:        # Blood Elf Race
            # p.AddItemToSlot (36, 56004, 1) #  Welcome Letter
            p.AddItemToSlot (37, 20938, 1) # Sunstrider Isle Gift Voucher - Blood Elf


# ONLEARNSPELL #########################################################################
#--Called on every Learn Spell Event add here additional spells to be learnt                        -----------------------------------------------------------------------#
def OnLearnSpell (u, spell_id, skill_id):

    # u -        Unit* class pointer
    # spell_id - Id of Learnt Spell
    # skill_id - Id of Learnt Skill
    
  #  print "OnLearnSpell[%s]: Spell[%d] Skill[%d]" % (u.GetName(), spell_id, skill_id)
    
    spell_to_learn = []
    send_packet_update = co.TRUE
    isPlayer = u.IsPlayer()

    if spell_id == spellname_co.SPELL_ID_RIDING_APPRENTICE:
        u.SetSkill(skill_co.SKILL_RIDING, 75, 75)  
    elif spell_id == spellname_co.SPELL_ID_RIDING_JOURNEYMAN:
        u.SetSkill(skill_co.SKILL_RIDING, 150, 150)
    elif spell_id == spellname_co.SPELL_ID_RIDING_EXPERT:
        u.SetSkill(skill_co.SKILL_RIDING, 225, 225)
    elif spell_id == spellname_co.SPELL_ID_RIDING_ARTISAN:
        u.SetSkill(skill_co.SKILL_RIDING, 300, 300)  

    if skill_id == skill_co.SKILL_BLACKSMITHING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_COPPER_BRACERS )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_COPPER_VEST )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_SHARPENING_STONE )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_WEIGHTSTONE )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_COPPER_BRACERS )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_COPPER_VEST )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_SHARPENING_STONE )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_WEIGHTSTONE )

    elif skill_id == skill_co.SKILL_JEWELCRAFTING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_DELICATE_COPPER_WIRE )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_COPPER_VEST )
            spell_to_learn.append( spellname_co.SPELL_ID_BRAIDED_COPPER_RING )
            spell_to_learn.append( spellname_co.SPELL_ID_HEAVY_COPPER_RING )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_STONE_STATUE )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_DELICATE_COPPER_WIRE )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_COPPER_VEST )
            spell_to_learn.append( spellname_co.SPELL_ID_BRAIDED_COPPER_RING )
            spell_to_learn.append( spellname_co.SPELL_ID_HEAVY_COPPER_RING )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_STONE_STATUE )

    elif skill_id == skill_co.SKILL_TAILORING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_SIMPLE_LINEN_PANTS )
            spell_to_learn.append( spellname_co.SPELL_ID_LINEN_CLOAK )
            spell_to_learn.append( spellname_co.SPELL_ID_BROWN_LINEN_SHIRT )
            spell_to_learn.append( spellname_co.SPELL_ID_WHITE_LINEN_SHIRT )
            spell_to_learn.append( spellname_co.SPELL_ID_BOLT_OF_LINEN_CLOTH )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_SIMPLE_LINEN_PANTS )
            spell_to_learn.append( spellname_co.SPELL_ID_LINEN_CLOAK )
            spell_to_learn.append( spellname_co.SPELL_ID_BROWN_LINEN_SHIRT )
            spell_to_learn.append( spellname_co.SPELL_ID_WHITE_LINEN_SHIRT )
            spell_to_learn.append( spellname_co.SPELL_ID_BOLT_OF_LINEN_CLOTH )

    elif skill_id == skill_co.SKILL_LEATHERWORKING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_LIGHT_ARMOR_KIT )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_CLOAK )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_BRACERS )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_BOOTS )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_VEST )
            spell_to_learn.append( spellname_co.SPELL_ID_LIGHT_LEATHER )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_LIGHT_ARMOR_KIT )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_CLOAK )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_BRACERS )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_BOOTS )
            spell_to_learn.append( spellname_co.SPELL_ID_HANDSTITCHED_LEATHER_VEST )
            spell_to_learn.append( spellname_co.SPELL_ID_LIGHT_LEATHER )

    elif skill_id == skill_co.SKILL_ALCHEMY:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_ELIXIR_OF_LIONS_STRENGTH )
            spell_to_learn.append( spellname_co.SPELL_ID_ELIXIR_OF_MINOR_DEFENSE )
            spell_to_learn.append( spellname_co.SPELL_ID_MINOR_HEALING_POTION )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_LIGHT_ARMOR_KIT )
            spell_to_learn.append( spellname_co.SPELL_ID_ELIXIR_OF_MINOR_DEFENSE )
            spell_to_learn.append( spellname_co.SPELL_ID_MINOR_HEALING_POTION )

    elif skill_id == skill_co.SKILL_ENCHANTING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_ENCHANT_BRACER__MINUS__MINOR_DEFLECTION )
            spell_to_learn.append( spellname_co.SPELL_ID_ENCHANT_BRACER__MINUS__MINOR_HEALTH )
            spell_to_learn.append( spellname_co.SPELL_ID_RUNED_COPPER_ROD )
            spell_to_learn.append( spellname_co.SPELL_ID_DISENCHANT )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_ENCHANT_BRACER__MINUS__MINOR_DEFLECTION )
            spell_to_learn.append( spellname_co.SPELL_ID_ENCHANT_BRACER__MINUS__MINOR_HEALTH )
            spell_to_learn.append( spellname_co.SPELL_ID_RUNED_COPPER_ROD )
            spell_to_learn.append( spellname_co.SPELL_ID_DISENCHANT )

    elif skill_id == skill_co.SKILL_FIRST_AID:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_LINEN_BANDAGE )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_LINEN_BANDAGE )

    elif skill_id == skill_co.SKILL_ENGINEERING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_CRAFTED_LIGHT_SHOT )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_DYNAMITE )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_BLASTING_POWDER )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_CRAFTED_LIGHT_SHOT )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_DYNAMITE )
            spell_to_learn.append( spellname_co.SPELL_ID_ROUGH_BLASTING_POWDER )
            
    elif skill_id == skill_co.SKILL_COOKING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_HERB_BAKED_EGG )
            spell_to_learn.append( spellname_co.SPELL_ID_ROASTED_BOAR_MEAT )
            spell_to_learn.append( spellname_co.SPELL_ID_CHARRED_WOLF_MEAT )
            spell_to_learn.append( spellname_co.SPELL_ID_BASIC_CAMPFIRE )
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_HERB_BAKED_EGG )
            spell_to_learn.append( spellname_co.SPELL_ID_ROASTED_BOAR_MEAT )
            spell_to_learn.append( spellname_co.SPELL_ID_CHARRED_WOLF_MEAT )
            spell_to_learn.append( spellname_co.SPELL_ID_BASIC_CAMPFIRE )
            
    elif skill_id == skill_co.SKILL_MINING:
        if CheckSide(u) == SIDE_ALLIANCE:
            spell_to_learn.append( spellname_co.SPELL_ID_SMELTING )
            spell_to_learn.append( spellname_co.SPELL_ID_FIND_MINERALS )
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_COPPER )
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_THORIUM )      # 16153
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_ELEMENTIUM )   # 22967
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_FEL_IRON )     # 29356            
        else:
            spell_to_learn.append( spellname_co.SPELL_ID_SMELTING )
            spell_to_learn.append( spellname_co.SPELL_ID_FIND_MINERALS )
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_COPPER )
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_THORIUM )      # 16153
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_ELEMENTIUM )   # 22967
            spell_to_learn.append( spellname_co.SPELL_ID_SMELT_FEL_IRON )     # 29356             

    elif skill_id == skill_co.SKILL_HERBALISM:
        spell_to_learn.append( spellname_co.SPELL_ID_FIND_HERBS )
     
    elif skill_id == skill_co.SKILL_BOWS:
        spell_to_learn.append( spellname_co.SPELL_ID_SHOOT_BOW )
     
    elif skill_id == skill_co.SKILL_CROSSBOWS:
        spell_to_learn.append( spellname_co.SPELL_ID_CROSSBOWS )
     
    elif skill_id == skill_co.SKILL_THROWN: 
        spell_to_learn.append( spellname_co.SPELL_ID_THROWN )
     
    elif skill_id == skill_co.SKILL_GUNS:
        spell_to_learn.append( spellname_co.SPELL_ID_GUNS )
     
    elif skill_id == skill_co.SKILL_WANDS:
        spell_to_learn.append( spellname_co.SPELL_ID_SHOOT )# 5019
    
    elif skill_id == skill_co.SKILL_POISONS:
        spell_to_learn.append( spellname_co.SPELL_ID_INSTANT_POISON_RANK_1_2 )   #8681

    # learn spell (add it to Player or Creature)
    if spell_to_learn is not None:
        for itr in spell_to_learn:
            if u.HasSpell(itr) == co.FALSE:
                u.AddSpell(itr, send_packet_update)
           #     print "OnLearnSpell: + additional spell[%s]" % (itr)


# ONSKILLLEVELUP ########################################################################
#--Called on every Event when Skill was used (except skills leveling in combat)                    -----------------------------------------------------------------------#
def OnSkillUse (u, skillline_id, reqskill_max, reqskill_min, reqskill_level, used_go):

    current_skill = u.GetSkill(skillline_id, 1)
    max_skill     = u.GetMaxSkill(skillline_id, 1)

    # make some checks
    if max_skill == 0 or current_skill >= max_skill or u.IsPlayer() == co.FALSE or u.HasSkill(skillline_id) == co.FALSE:
      #  print "OnSkillUse:Did not pass requirements, skill not leveled up"
        return
    
    FIXED_PCT  = 75
    SKILL_STEP = 1
    SKILL_WITH_MODS = co.TRUE
    new_skill     = 0
    skill_lvlup   = 0
    yel_green     = ((reqskill_max - reqskill_min)/2 + reqskill_min)
    
    profession_skill = co.FALSE
    action_skill     = co.FALSE
    fishing          = co.FALSE
    
    quality_red      = co.FALSE
    quality_orange   = co.FALSE
    quality_yellow   = co.FALSE
    quality_green    = co.FALSE
    quality_grey     = co.FALSE
    
    profession_skills_list = [ skill_co.SKILL_BLACKSMITHING, skill_co.SKILL_LEATHERWORKING, 
     skill_co.SKILL_ALCHEMY, skill_co.SKILL_COOKING, skill_co.SKILL_TAILORING, skill_co.SKILL_ENGINEERING,    
     skill_co.SKILL_ENCHANTING, skill_co.SKILL_FIRST_AID, skill_co.SKILL_POISONS, skill_co.SKILL_JEWELCRAFTING ]
                               
    action_skills_list = [ skill_co.SKILL_HERBALISM, skill_co.SKILL_MINING,skill_co.SKILL_SKINNING,
     skill_co.SKILL_LOCKPICKING ]                              

    # Determine what type of skill do we have
    if   skillline_id in profession_skills_list: profession_skill = co.TRUE
    elif skillline_id in action_skills_list:     action_skill = co.TRUE
    elif skillline_id == skill_co.SKILL_FISHING:  fishing = co.TRUE
    
    chance = randrange(100)

    if profession_skill == co.TRUE:
     #   print "OnSkillUse: main profession skill"        
        
        if current_skill <= reqskill_min: 
            quality_orange = co.TRUE
        elif current_skill > reqskill_min and current_skill <= yel_green: 
            quality_yellow = co.TRUE
        elif current_skill > yel_green and current_skill <= reqskill_max: 
            quality_green = co.TRUE
        elif current_skill > reqskill_max: 
            quality_grey = co.TRUE
   
        if quality_orange: 
       #     print "OnSkillUse: orange"
            skill_lvlup += SKILL_STEP
        elif quality_yellow:
          #  print "OnSkillUse: yellow"
            if chance <= 75: skill_lvlup += SKILL_STEP
        elif quality_green: 
           # print "OnSkillUse: green"
            if chance <= 50: skill_lvlup += SKILL_STEP
        elif quality_grey:    
         #   print "OnSkillUse: low recipe quality: grey, will not level up"
            return # no skill level up
   
    elif action_skill == co.TRUE:
     #   print "OnSkillUse: secondary profession(action) skill"
        if chance < FIXED_PCT: skill_lvlup += SKILL_STEP

    elif fishing == co.TRUE:
     #   print "OnSkillUse: Fishing skill"
        if current_skill > (supporter.GetZoneMaxSkill(u) - 50):        
         if current_skill <= supporter.GetZoneMaxSkill(u): skill_lvlup += SKILL_STEP
    
    new_skill = current_skill + skill_lvlup
    if new_skill > max_skill: new_skill = max_skill
    
    # Update Skills
   # print "OnSkillUse: player[%s] skill_id[%d] new_level[%d]" % (u.GetName(),skillline_id,new_skill)
    u.UpdateSkill(skillline_id, new_skill, max_skill)

# ON FIRST TIME CHAR IN WORLD #########################################################################
# Is Called only once for Player which is newly created and Put Into World
#
def OnFirstTimeInWorld (p):
   # print "OnFirstTimeInWorld: called for player[%s]" % (p.GetName())
    
    # Cast one Time Spells on Players like Stances
    if p.GetClass() == co.CLASS_WARRIOR:
        p.CastSpell( p, spellname_co.SPELL_ID_BATTLE_STANCE, TRUE ) #Add 2457   Battle stance  # TRUE - trigger immediately
#    if p.GetClass() == co.CLASS_PALADIN:
#        p.CastSpell( p, spellname_co.SPELL_ID_PURGE_RANK_2, TRUE ) #Add 8012   PURGE  # TRUE - trigger immediately
# ####################################################################################
#  returns Side to which Player belongs  
def CheckSide(p):
    if  p.GetRace() == RACE_HUMAN or \
        p.GetRace() == RACE_DWARF or \
        p.GetRace() == RACE_NIGHT_ELF or \
        p.GetRace() == RACE_DRAENEI or \
        p.GetRace() == RACE_GNOME:
        return SIDE_ALLIANCE
        
    if  p.GetRace() == RACE_ORC or \
        p.GetRace() == RACE_UNDEAD or \
        p.GetRace() == RACE_TAUREN or \
        p.GetRace() == RACE_BLOOD_ELF or \
        p.GetRace() == RACE_TROLL:
        return SIDE_HORDE

def GetPlayerSide(p):
    return CheckSide(p)
        
# ####################################################################################
# called by core when flag drop event happens         
def OnBattleGroundFlagDrop(player):
    
    '''
    if player.HasAffect( spell_co.SPELL_ID_HORDE_FLAG ) or player.HasAffect( spell_co.SPELL_ID_ALLIANCE_FLAG ):
            
        flag_id = 0
        
        if player.HasAffect( spell_co.SPELL_ID_ALLIANCE_FLAG ): 
            flag_id = co.BATTLEGROUND_ALLIANCE_FLAG_DROP
            #player.RemoveAffect(player, spell_co.SPELL_ID_ALLIANCE_FLAG)
            player.CastSpell( player, spell_co.SPELL_ID_ALLIANCE_FLAG_DROP, TRUE )
        
        if player.HasAffect( spell_co.SPELL_ID_HORDE_FLAG ):    
            flag_id = co.BATTLEGROUND_HORDE_FLAG_DROP
            #player.RemoveAffect(player, spell_co.SPELL_ID_HORDE_FLAG)
            player.CastSpell( player, spell_co.SPELL_ID_HORDE_FLAG_DROP, TRUE )
        
        # Now spawned by spell
        #        
        #loc = player.GetXYZ()
        #rot = (0,0,0,0)
        #flag = player.CreateGameObject(flag_id, loc, rot, FALSE)
        #flag.SetFlags(0)  # activate it
        #flag.AddToWorld() # place on map
    '''

# ####################################################################################
# called by spell_class when flag capture event happens 
def CalculateBattleGroundBonusHonor(capturer):

    team_side = GetPlayerSide(capturer)
    myBG_id = capturer.GetInstanceId()
    
    capt_honor_bonus = 35
    team_honor_bonus = 10
    
    # Add Honor to capturer now
    capturer.SetBGBonusHonor( capt_honor_bonus )
    print "CalculateBattleGroundBonusHonor: player[%s] old_honor[%d] honor+[%d]" % (capturer.GetName(), capturer.GetBGBonusHonor(), capt_honor_bonus)

    player_list = GetPlayerList()
    
    for player in player_list:
        if player == NULL: continue
        if player.GetGUIDUInt64() == capturer.GetGUIDUInt64(): continue # skip self
        if GetPlayerSide(player) != team_side: continue
        if player.GetInstanceId() != myBG_id: continue

        # sample Honor just for test now
        print "CalculateBattleGroundBonusHonor: player[%s] old_honor[%d] honor+[%d]" % (player.GetName(), player.GetBGBonusHonor(), team_honor_bonus)
        player.SetBGBonusHonor( team_honor_bonus )
        
# ON CHAR LOGIN ###################################################################################
#
def OnPlayerLogin (p):
    print "OnPlayerLogin: %s" % (p.GetName())
    # Send Welcome message
    packet = packet_builder.make_SMSG_AREA_TRIGGER_MESSAGE(0, "Server depreciated, %s ! Use new realmlist logon.aceindy.nl client 2.1.1 build(6739)" % p.GetName())
    packet.Send(p)

# ON CHAR WORLD ENTER  ##############################################################################
#
# ON CHAR WORLD ENTER  ##############################################################################
#
def OnPlayerEnterWorld (p):    
   # print "OnPlayerEnterWorld: %s" % (p.GetName())
    nmbr = 0
    for i in (465,10290,7294,643,19746,10298,19876,20218,10291,19888,10299,1032,19897,10300,19899,10292,19896,\
              10301,19898,10293,19900,32223,27151,27150,27152,27149,27153):
        if p.HasAffect( i ):
           p.RemoveAffect( p, i )
           nmbr +=1
    print "ONLOGIN - removing %s auras for player %s " % (nmbr,p.GetName())    
    #cast on Player honor spell 
    if p.isDead() == FALSE:
        if p.GetMapId() in [0,1,530]:
            if p.GetLevel() > 10: 
                p.CastSpell(p, spellname_co.SPELL_ID_HONORLESS_TARGET, TRUE)
#    if p.GetClass() != 3:
#        if p.HasSpell(1515) == TRUE: p.RemoveSpell(1515)
#    if p.GetClass() != 9:
#        if p.HasSpell(688) == TRUE: p.RemoveSpell(688)
        
    
# Called on every Chat message  ##############################################################################
# if returned TRUE - command executed, if FALSE - not executed or found
#
def OnGMCommand(self, target, message):
   # print "OnChatMessage: Self[%s] Message[%s]" % (self.GetName(), message)  
    return FALSE
    
#--- EOF ---#
