# COPYRIGHT (C) 2006 LUDMILLA TEAM
from Ludmilla import *          # Import server environment
from random import *            # Randomiser Import
from math import *              # Math lib Import
import consts as co             # Import of constants
reload(co)   


ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

MarkSpot = {0:[[0,0,0],[0,0,0]]}
#------------------------------This functions use KremLiN in his AI Molten_Core--------------------------------------------------------
class CUnitPAPData:
    m_count=0
    m_unit=0
    def ___cmp___(x,y):
        if x.m_count>y.m_count:
            return 1
        if x.m_count==y.m_count:
            return 0
        if x.m_count<y.m_count:
            return -1

def GetCountPlayersAroundPlayer(unit):
    count=0
    list_players=unit.MapRangeUnitList()
    for _unit in list_players:
        if _unit.IsPlayer():
            if _unit.isDead()==FALSE:
                if supporter.CalcDist(_unit,unit)<=40:
                    if supporter.CalcDist(unit,_unit)<=20:
                        count+=1
    return count


def GetMoreAroundUnit(mob):
    _units = mob.MapRangeUnitList()
    if len(_units)==0:
        return -1 #or mob:)))
    players = []
    pap_players=[]
    for _unit in _units:
        if _unit.IsPlayer():
            players.append(_unit)
    for _player in players:
        unit_pap=CUnitPAPData()
        unit_pap.m_unit=_player
        unit_pap.m_count=GetCountPlayersAroundPlayer(_player)
        pap_players.append(unit_pap)
    pap_players.sort()
    pap_players.reverse()
    return pap_players[0].m_unit

class CUnitAgroData:
    m_float=0.0
    m_unit=0
    def ___cmp___(x,y):
        if x.m_float>y.m_float:
            return 1
        if x.m_float==y.m_float:
            return 0
        if x.m_float<y.m_float:
            return -1

def GetHateListLen(mob):
    list=mob.GetHateList()
    return len(list)

def GetRandomUnit(mob):
    list_units=mob.GetHateList()
    list_units_len=len(list_units)
    if list_units_len==1:
        return mob.GetMostHated()
    else:
        return GetUnitByHatePosition(mob,randrange(1,list_units_len))

def GetUnitByHatePosition(mob,pos):
    list=mob.GetHateList()
    list_unit=[]
    for _unit in list:
        temp_class=CUnitAgroData()
        temp_class.m_unit=_unit
        temp_class.m_float=mob.GetHate(_unit)
        list_unit.append(temp_class)
    list_unit.sort()
    list_unit.reverse()
    for _unit in list_unit:
        print "Unit have hate=%f" % (_unit.m_float)
    unit=list_unit[pos-1].m_unit
    return unit

#--------------------------------------------------------------------------------------------------------
def CalcDist(obj1,obj2):
    arr1=obj1.GetXYZ()
    arr2=obj2.GetXYZ()
    return sqrt( ( arr2[0] - arr1[0] ) * ( arr2[0] - arr1[0] ) + ( arr2[1] - arr1[1] ) * ( arr2[1] - arr1[1] ) )

#--------------------------------------------------------------------------------------------------------
def HasFlags(value, flags):
    if value & flags < flags: return FALSE
    return TRUE

#--------------------------------------------------------------------------------------------------------
def GetZoneMaxSkill(player):
    ZoneMaxSkill = {1:50   , 
                 2   :100  ,
                 8   :225  ,
                 9   :50   ,
                 10  :50   ,
                 11  :150  ,
                 12  :50   ,
                 14  :50   ,
                 15  :225  ,
                 16  :275  ,
                 17  :275  ,
                 18  :50   ,
                 28  :290  ,
                 33  :225  ,
                 35  :225  ,
                 36  :150  ,
                 37  :225  ,
                 38  :100  ,
                 40  :100  ,
                 41  :225  ,
                 43  :225  ,
                 44  :125  ,
                 45  :200  ,
                 47  :250  ,
                 57  :50   ,
                 60  :50   ,
                 61  :50   ,
                 62  :50   ,
                 63  :50   ,
                 64  :50   ,
                 68  :150  ,
                 69  :125  ,
                 71  :225  ,
                 74  :225  ,
                 75  :225  ,
                 76  :225  ,
                 85  :50   ,
                 86  :50   ,
                 87  :50   ,
                 88  :50   ,
                 89  :50   ,
                 92  :50   ,
                 100 :225  ,
                 102 :225  ,
                 104 :225  ,
                 115 :100  ,
                 116 :225  ,
                 117 :225  ,
                 122 :225  ,
                 129 :225  ,
                 130 :100  ,
                 139 :300  ,
                 141 :50   ,
                 146 :50   ,
                 148 :100  ,
                 150 :150  ,
                 162 :50   ,
                 163 :50   ,
                 168 :50   ,
                 169 :50   ,
                 172 :100  ,
                 187 :50   ,
                 188 :50   ,
                 193 :290  ,
                 202 :290  ,
                 211 :50   ,
                 215 :50   ,
                 221 :50   ,
                 223 :50   ,
                 226 :100  ,
                 227 :100  ,
                 237 :100  ,
                 249 :280  ,
                 256 :50   ,
                 258 :50   ,
                 259 :50   ,
                 265 :50   ,
                 266 :50   ,
                 267 :150  ,
                 271 :150  ,
                 272 :150  ,
                 279 :200  ,
                 284 :200  ,
                 295 :150  ,
                 297 :225  ,
                 298 :150  ,
                 299 :150  ,
                 300 :225  ,
                 301 :225  ,
                 302 :225  ,
                 305 :100  ,
                 306 :100  ,
                 307 :250  ,
                 309 :100  ,
                 310 :225  ,
                 311 :225  ,
                 312 :225  ,
                 314 :200  ,
                 317 :200  ,
                 323 :100  ,
                 324 :200  ,
                 327 :200  ,
                 328 :200  ,
                 331 :150  ,
                 350 :250  ,
                 351 :250  ,
                 353 :250  ,
                 356 :250  ,
                 357 :250  ,
                 361 :250  ,
                 363 :50   ,
                 367 :50   ,
                 368 :50   ,
                 373 :50   ,
                 374 :50   ,
                 375 :300  ,
                 382 :125  ,
                 384 :125  ,
                 385 :125  ,
                 386 :125  ,
                 387 :125  ,
                 388 :125  ,
                 391 :125  ,
                 392 :125  ,
                 393 :50   ,
                 400 :125  ,
                 401 :125  ,
                 405 :200  ,
                 406 :135  ,
                 414 :150  ,
                 415 :150  ,
                 416 :150  ,
                 418 :150  ,
                 420 :150  ,
                 421 :150  ,
                 422 :150  ,
                 424 :150  ,
                 429 :150  ,
                 433 :150  ,
                 434 :150  ,
                 437 :150  ,
                 440 :175  ,
                 441 :150  ,
                 443 :100  ,
                 445 :100  ,
                 448 :100  ,
                 449 :100  ,
                 452 :100  ,
                 453 :100  ,
                 454 :100  ,
                 456 :100  ,
                 460 :135  ,
                 463 :275  ,
                 464 :135  ,
                 478 :50   ,
                 490 :275  ,
                 493 :300  ,
                 496 :225  ,
                 497 :225  ,
                 501 :225  ,
                 502 :225  ,
                 504 :225  ,
                 508 :225  ,
                 509 :225  ,
                 510 :225  ,
                 511 :225  ,
                 513 :225  ,
                 516 :225  ,
                 517 :225  ,
                 518 :200  ,
                 537 :250  ,
                 538 :250  ,
                 542 :250  ,
                 543 :250  ,
                 556 :50   ,
                 576 :150  ,
                 598 :200  ,
                 602 :200  ,
                 604 :200  ,
                 618 :300  ,
                 636 :135  ,
                 656 :300  ,
                 657 :225  ,
                 702 :50   ,
                 718 :135  ,
                 719 :135  ,
                 720 :135  ,
                 797 :225  ,
                 799 :150  ,
                 810 :50   ,
                 814 :50   ,
                 815 :125  ,
                 818 :50   ,
                 878 :275  ,
                 879 :150  ,
                 896 :150  ,
                 917 :100  ,
                 919 :100  ,
                 922 :100  ,
                 923 :50   ,
                 927 :50   ,
                 968 :250  ,
                 977 :250  ,
                 978 :250  ,
                 979 :250  ,
                 983 :250  ,
                 988 :250  ,
                 997 :125  ,
                 998 :125  ,
                 1001:125  ,
                 1002:125  ,
                 1008:250  ,
                 1017:150  ,
                 1018:150  ,
                 1020:150  ,
                 1021:150  ,
                 1022:150  ,
                 1023:150  ,
                 1024:150  ,
                 1025:150  ,
                 1039:150  ,
                 1056:290  ,
                 1097:150  ,
                 1099:300  ,
                 1101:250  ,
                 1102:250  ,
                 1106:250  ,
                 1112:250  ,
                 1116:250  ,
                 1117:250  ,
                 1119:250  ,
                 1120:250  ,
                 1121:250  ,
                 1126:225  ,
                 1136:250  ,
                 1156:225  ,
                 1176:250  ,
                 1222:275  ,
                 1227:275  ,
                 1228:275  ,
                 1229:275  ,
                 1230:275  ,
                 1231:275  ,
                 1234:275  ,
                 1256:275  ,
                 1296:50   ,
                 1297:50   ,
                 1336:250  ,
                 1337:250  ,
                 1338:100  ,
                 1339:200  ,
                 1477:275  ,
                 1519:50   ,
                 1557:175  ,
                 1577:225  ,
                 1578:225  ,
                 1581:100  ,
                 1617:50   ,
                 1637:50   ,
                 1638:50   ,
                 1662:50   ,
                 1681:200  ,
                 1682:200  ,
                 1684:200  ,
                 1701:125  ,
                 1738:225  ,
                 1739:225  ,
                 1740:225  ,
                 1760:225  ,
                 1762:250  ,
                 1764:225  ,
                 1765:225  ,
                 1767:275  ,
                 1770:275  ,
                 1777:225  ,
                 1778:225  ,
                 1780:225  ,
                 1797:225  ,
                 1798:225  ,
                 1883:250  ,
                 1884:250  ,
                 1939:250  ,
                 1940:250  ,
                 1942:250  ,
                 1977:225  ,
                 1997:275  ,
                 1998:275  ,
                 2017:300  ,
                 2077:100  ,
                 2078:100  ,
                 2079:225  ,
                 2097:175  ,
                 2100:245  ,
                 2158:250  ,
                 2246:300  ,
                 2256:300  ,
                 2270:300  ,
                 2272:300  ,
                 2277:300  ,
                 2279:300  ,
                 2298:300  ,
                 2302:225  ,
                 2317:250  ,
                 2318:225  ,
                 2321:275  ,
                 2322:50   ,
                 2323:250  ,
                 2324:200  ,
                 2325:150  ,
                 2326:100  ,
                 2364:100  ,
                 2365:150  ,
                 2398:100  ,
                 2399:50   ,
                 2400:250  ,
                 2401:200  ,
                 2402:100  ,
                 2403:225  ,
                 2405:200  ,
                 2408:200  ,
                 2457:150  ,
                 2477:300  ,
                 2481:275  ,
                 2521:250  ,
                 2522:250  ,
                 2558:300  ,
                 2562:300  ,
                 2597:300  ,
                 2618:275  ,
                 2619:300  ,
                 2620:290  ,
                 2624:300  ,
                 2631:300  ,
                 2797:150  ,
                 2837:300  ,
                 2897:150  }
    return ZoneMaxSkill.get(player.GetZoneId(),50)
    
# -- EOF --