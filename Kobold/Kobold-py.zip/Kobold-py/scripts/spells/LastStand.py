from Ludmilla import *

import const_spells
co = const_spells
reload (co)
#by dissaster - LastStand
#SPELL_ID_LAST_STAND = 12975
#SPELL_ID_LAST_STAND_1 = 12976
#When activated, this ability temporarily grants you 30% of your maximum hit points for 20 seconds. After the effect expires, the hit points are lost.

#------------------------------------------------------------------------------

class Spell_Last_Stand:
    """ LAst stand
    """
    def CanCast (self, caster, target_dummy):
        print "last stand: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "last stand: SpellEffect called!"
        
        caster.ModifyHealth((caster.GetMaxHealth() / 100) * 30)
                               
#------------------------------------------------------------------------------

class Spell_Last_Stand_1:
    """ LAst stand
    """
    def CanCast (self, caster, target_dummy):
        print "last stand: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "last stand: SpellEffect called!"
        
        caster.ModifyHealth((caster.GetMaxHealth() / 100) * 30)
                               
#----------------------------------------------------------------------------

#--- END ---
