from Ludmilla import *

import const_spells as co
reload (co)
from random import *

#------------------------------------------------------------------------------
class Spell_HammerOfWrath:
    """ Hammer of Wrath (may only be casted of enemy health <= 20% of max)	
    """
    def CanCast (self, caster, target):
        print "Spell_HammerOfWrath: CanCast called!"
        targetHealth = target.GetHealth()
        targetMaxHealth = target.GetMaxHealth()
        if targetHealth > (targetMaxHealth * 0.2):
            return 10
        else:
            return 0
