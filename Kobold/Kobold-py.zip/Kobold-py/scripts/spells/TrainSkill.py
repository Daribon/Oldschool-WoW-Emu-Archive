from Ludmilla import *

import const_spells
co = const_spells
reload (co)
import const_skills
co_skill = const_skills
reload (co_skill)

#------------------------------------------------------------------------------
class Spell_ArtisanAlchemy:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 171 , target.GetSkill(171) , 300 )

class Spell_ArtisanBlacksmithing:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 164 , target.GetSkill(164) , 300 )

class Spell_ArtisanCooking:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 185 , target.GetSkill(185) , 300 )

class Spell_ArtisanEnchanting:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 333 , target.GetSkill(333) , 300 )

class Spell_ArtisanEngineering:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 202 , target.GetSkill(202) , 300 )

class Spell_ArtisanFirstaid:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 129 , target.GetSkill(129) , 300 )

class Spell_ArtisanFishing:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 356 , target.GetSkill(356) , 300 )

class Spell_ArtisanHerbalism:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 182 , target.GetSkill(182) , 300 )

class Spell_ArtisanLeatherworking:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 165 , target.GetSkill(165) , 300 )

class Spell_ArtisanMining:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 186 , target.GetSkill(186) , 300 )

class Spell_ArtisanSkinning:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 393 , target.GetSkill(393) , 300 )

class Spell_ArtisanTailoring:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 197 , target.GetSkill(197) , 300 )

#--------------------------------------------------
class Spell_MasterAlchemy:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 171 , target.GetSkill(171) , 375 )

class Spell_MasterBlacksmithing:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 164 , target.GetSkill(164) , 375 )

class Spell_MasterCooking:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 185 , target.GetSkill(185) , 375 )

class Spell_MasterEnchanting:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 333 , target.GetSkill(333) , 375 )

class Spell_MasterEngineering:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 202 , target.GetSkill(202) , 375 )

class Spell_MasterFirstaid:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 129 , target.GetSkill(129) , 375 )

class Spell_MasterFishing:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 356 , target.GetSkill(356) , 375 )

class Spell_MasterHerbalism:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 182 , target.GetSkill(182) , 375 )

class Spell_MasterLeatherworking:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 165 , target.GetSkill(165) , 375 )

class Spell_MasterMining:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 186 , target.GetSkill(186) , 375 )

class Spell_MasterSkinning:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 393 , target.GetSkill(393) , 375 )

class Spell_MasterTailoring:
    """ TrainSkill
    """
    def SpellEffect (self, caster, target):
        print "Spell_TrainSkill: SpellEffect called!"
                
        target.SetSkill( 197 , target.GetSkill(197) , 375 )
#------------------------------------------------------------------------------

#--- END ---