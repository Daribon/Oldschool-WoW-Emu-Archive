from Ludmilla import *
from random import *

import const_spells
co = const_spells
reload (co)

#------------------------------------------------------------------------------
class Spell_UnStuck:

    def CanCast (self, caster, target_dummy):
        caster.Teleport(self.GetBindPoint())
        return 0


#------------------------------------------------------------------------------

#--- END ---