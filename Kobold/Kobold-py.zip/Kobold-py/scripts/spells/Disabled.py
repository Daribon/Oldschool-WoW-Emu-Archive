
from Ludmilla import *

import const_spells
co = const_spells
reload (co)
#------------------------------------------------------------------------------

class Spell_disabled:
    def CanCast (self, caster, target_dummy):
        return co.CAST_FAIL_CANT_DO_THAT_YET

#--- END ---
