from Ludmilla import *

import const_spells
co = const_spells
reload (co)

#------------------------------------------------------------------------------
class Spell_WISP_SPIRIT_RACIAL_PASSIVE:
    """ Wisp Form
    """
    def CanCast (self, caster, target_dummy):
        print "Spell_WispSpirit: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_WispSpirit: SpellEffect called!"
        
        target.ModSpeed(15)
#------------------------------------------------------------------------------

#--- END ---
