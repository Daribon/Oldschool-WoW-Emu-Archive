# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *              # Import server environment
from random import *                # Randomiser Import
import consts as co                 # Import of constants
reload(co)   
import const_skills as skill_co     # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co     # Import of constants (skills)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

#------------------------------------------------------------------------------
class AuraHandler:

    def ApplyModifier ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
#        print "ApplyModifier: %d %d %d %d %d %d" % ( apply, amount, value1, value2, spell_id, spell_effect_slot )
        result = FALSE
        column=0
        
        # register Spells for these Aura Type
        Vector = [5217,6793,9845,9846]
        for column in range(0,4):
            if spell_id == Vector[column]:
                result = ptrAuraHandler.TIGERS_FURY( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        return result    

    def TIGERS_FURY ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):

        column=0
        rank=0
        Vector = [5217,6793,9845,9846]
        for column in range(0,4):
            if spell_id == Vector[column]:
                rank=column+1
        
        if spell_effect_slot == 0:
            if apply == 1:
                attackplus = 10*rank*14
                attacknormal = caster.GetAttackPower()
                caster.SetAttackPower(attacknormal + attackplus)
                return FALSE
            if apply == 0:
                attackplus = 10*rank*14
                attacknormal = caster.GetAttackPower()
                caster.SetAttackPower(attacknormal - attackplus)
                return FALSE
        if spell_effect_slot == 1:
            if apply == 1:
                return FALSE
            if apply == 0:
                return FALSE
            
#--- END ---
