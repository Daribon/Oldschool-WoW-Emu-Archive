# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *              # Import server environment
from random import *                # Randomiser Import
import consts as co                 # Import of constants
reload(co)   
import const_skills as skill_co     # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co     # Import of constants (skills)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

#------------------------------------------------------------------------------
class AuraHandler:

    def ApplyModifier ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
#        print "ApplyModifier: %d %d %d %d %d %d" % ( apply, amount, value1, value2, spell_id, spell_effect_slot )

        result = FALSE
        
        # register Spells for these Aura Type       
        if spell_id == spell_name.SPELL_ID_CAT_FORM_SHAPESHIFT_1:
            result = ptrAuraHandler.CAT_FORM_SHAPESHIFT( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )

        if spell_id == spell_name.SPELL_ID_CAT_FORM_SHAPESHIFT_2:
            result = ptrAuraHandler.CAT_FORM_SHAPESHIFT( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )

        if spell_id == spell_name.SPELL_ID_DIRE_BEAR_FORM_SHAPESHIFT:
            result = ptrAuraHandler.DIRE_BEAR_FORM_SHAPESHIFT( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )

        if spell_id == spell_name.SPELL_ID_DIRE_BEAR_FORM_SHAPESHIFT_1:
            result = ptrAuraHandler.DIRE_BEAR_FORM_SHAPESHIFT( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )

        return result    

    def CAT_FORM_SHAPESHIFT ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):

        if spell_effect_slot == 0:

            if apply == 1:
                caster_str = caster.GetStrength()
                caster_agi = caster.GetAgility()
                caster_level = caster.GetLevel()
                attackplus = ((caster_str + caster_agi) * caster_level/10)
                attacknormal = caster.GetAttackPower()
                HOTW = 0
                PS = 0
                
                #Heart of the Wild Plus
                column = 0
                HOTW_X = [24894,17006,17005,17004,17003]
                HOTW_Y = [0.2,0.16,0.12,0.08,0.04]
                for column in range(0,5):
                    if caster.HasSpell(HOTW_X[column]):
                        caster_str = caster.GetStrength()
                        caster_hotw = caster_str * HOTW_Y[column]
                        HOTW = (caster_hotw * 2) - 20
                        break

                #Predatory Strike Plus
                column = 0 
                PS_X = [16975,16974,16972]
                PS_Y = [1.5,1,0.5]
                for column in range(0,3):
                    if caster.HasSpell(PS_X[column]):
                        caster_level = caster.GetLevel()
                        PS = caster_level * PS_Y[column]
                        break
                        
                caster.SetAttackPower(attacknormal + attackplus + HOTW + PS)
                
            if apply == 0:
                caster_str = caster.GetStrength()
                level = caster.GetLevel()
                str_on_level = 16 + level * 2
                weirdx = caster_str - str_on_level
                recover_atk = (caster_str * 4) - 29 - weirdx *2     #Weird Formula
                caster.SetAttackPower(recover_atk)
                
            return FALSE

    def DIRE_BEAR_FORM_SHAPESHIFT ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
        
        if spell_effect_slot == 0:

            if apply == 1:
                caster_str = caster.GetStrength()
                caster_agi = caster.GetAgility()
                caster_level = caster.GetLevel()
                attackplus = (caster_str * caster_level/15)
                attacknormal = caster.GetAttackPower()                
                caster.SetAttackPower(attacknormal + attackplus)
                

                #Heart of the Wild Plus
                column = 0
                HOTW_X = [24894,17006,17005,17004,17003]
                HOTW_Y = [0.2,0.16,0.12,0.08,0.04]
                caster_sta = caster.GetStamina()
                caster_hp = (caster_sta + 70) * 10
                fix = 1210
                level = caster.GetLevel()
                sta_on_level = 17 + level * 2
                weirdx = (caster_sta - sta_on_level) * 10
                for column in range(0,5):
                    if caster.HasSpell(HOTW_X[column]):
                        caster_hpplus = caster_sta * HOTW_Y[column] * 10
                        caster.SetMaxHealth(caster_hp + caster_hpplus - fix - weirdx)
                        break                      
                             
            if apply == 0:
                caster_str = caster.GetStrength()
                caster.SetAttackPower((caster_str * 2) - 20)
                fix = 1210
                caster_sta = caster.GetStamina()
                level = caster.GetLevel()
                sta_on_level = 17 + level * 2
                weirdx = (caster_sta - sta_on_level) * 10 
                caster_hp = (caster_sta + 70) * 10
                caster.SetMaxHealth(caster_hp - fix - weirdx)
                
            return FALSE

    

            
#--- END ---
