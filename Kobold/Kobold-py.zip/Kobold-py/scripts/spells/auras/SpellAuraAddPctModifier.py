# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *              # Import server environment
from random import *                # Randomiser Import
import consts as co                 # Import of constants
reload(co)   
import const_skills as skill_co     # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co     # Import of constants (skills)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

#------------------------------------------------------------------------------
class AuraHandler:

    def ApplyModifier ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
        print "ApplyModifier: %d %d %d %d %d %d" % ( apply, amount, value1, value2, spell_id, spell_effect_slot )

        result = FALSE
        column=0
        
        # register Spells for these Aura Type
        #Ice Shards
        Disabled = [11207,12672,15047,15052,15053,31934,31829,31828,31827]
        for column in range(0,5):
            if spell_id == Disabled[column]:
                result = ptrAuraHandler.DISABLED( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        return result

    def DISABLED ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
        if spell_effect_slot == 0:
            if apply == 1:
                caster.RemoveSpell(spell_id)
                return TRUE
            if apply == 0:
                return TRUE
        if spell_effect_slot == 1:
            if apply == 1:
                return TRUE
            if apply == 0:
                return TRUE
            
#--- END ---
