# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *              # Import server environment
from random import *                # Randomiser Import
import consts as co                 # Import of constants
reload(co)   
import const_skills as skill_co     # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co     # Import of constants (skills)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

#------------------------------------------------------------------------------
class AuraHandler:

    def ApplyModifier ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
#        print "ApplyModifier: %d %d %d %d %d %d" % ( apply, amount, value1, value2, spell_id, spell_effect_slot )

        result = FALSE
        column=0
        
        # register Spells for these Aura Type
        #Fix Starfire Stun Talent
        if spell_id == spell_co.:
                result = ptrAuraHandler.ICE_BARRIER( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        return result

    def ICE_BARRIER( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
        if spell_effect_slot == 0:
            if apply == 1:
                caster.CastSpell(caster, 34709)
                return FALSE
            if apply == 0:
                return FALSE
        if spell_effect_slot == 1:
            if apply == 1:
                return FALSE
            if apply == 0:
                return FALSE
            
#--- END ---
