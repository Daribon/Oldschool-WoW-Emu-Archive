# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *              # Import server environment
from random import *                # Randomiser Import
import consts as co                 # Import of constants
reload(co)   
import const_skills as skill_co     # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co     # Import of constants (skills)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

#------------------------------------------------------------------------------
class AuraHandler:

    def ApplyModifier ( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
#        print "ApplyModifier: %d %d %d %d %d %d" % ( apply, amount, value1, value2, spell_id, spell_effect_slot )

        result = FALSE
        
        # spell_effect_slot  can be:  0 - 1 - 2 
        
        # register Spells for these Aura Type       
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_1_2:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_2_1:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_3_1:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_4:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_5:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_6:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_7:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )
        if spell_id == spell_name.SPELL_ID_SEAL_OF_RIGHTEOUSNESS_RANK_8:
            result = ptrAuraHandler.SEAL_OF_RIGHTEOUSNESS( caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot )

        
        return result    
    
    
    def SEAL_OF_RIGHTEOUSNESS( ptrAuraHandler, caster, target, apply, amount, value1, value2, spell_id, spell_effect_slot ):
        
        if spell_effect_slot == 0:
            
            statsMod = caster.GetStatsModifier()
            
            min_dmg = amount/87 * apply
            max_dmg = amount/25 * apply
            spell_id= spell_id  * apply
            
            statsMod.SetAdditionalSpellDamage(spell_id, min_dmg, max_dmg)
            
            return TRUE
        
        if spell_effect_slot == 2:
            return FALSE
            
#--- END ---
