from Ludmilla import *
from random import *

import const_spells
co = const_spells
reload (co)

#------------------------------------------------------------------------------
class Spell_ROCKBITER_WEAPON_RANK_1:
    """ rockbiter weapon Rank 1
    """
    def CanCast (self, caster, target_dummy):
        print "ROCKBITER_WEAPON_RANK_1: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_ROCKBITER_WEAPON_RANK_1: SpellEffect called!"

        caster.SetMaxDamage(caster.GetMaxDamage() + 2)

#------------------------------------------------------------------------------
class Spell_ROCKBITER_WEAPON_RANK_2:
    """ rockbiter weapon Rank 2
    """
    def CanCast (self, caster, target_dummy):
        print "ROCKBITER_WEAPON_RANK_2: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_ROCKBITER_WEAPON_RANK_2: SpellEffect called!"

        caster.SetMaxDamage(caster.GetMaxDamage() + 4)
#------------------------------------------------------------------------------
class Spell_ROCKBITER_WEAPON_RANK_3:
    """ rockbiter weapon Rank 3
    """
    def CanCast (self, caster, target_dummy):
        print "ROCKBITER_WEAPON_RANK_3: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_ROCKBITER_WEAPON_RANK_3: SpellEffect called!"

        caster.SetMaxDamage(caster.GetMaxDamage() + 6)
#------------------------------------------------------------------------------
class Spell_ROCKBITER_WEAPON_RANK_4:
    """ rockbiter weapon Rank 4
    """
    def CanCast (self, caster, target_dummy):
        print "ROCKBITER_WEAPON_RANK_4: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_ROCKBITER_WEAPON_RANK_4: SpellEffect called!"

        caster.SetMaxDamage(caster.GetMaxDamage() + 15)
#------------------------------------------------------------------------------
class Spell_ROCKBITER_WEAPON_RANK_5:
    """ rockbiter weapon Rank 5
    """
    def CanCast (self, caster, target_dummy):
        print "ROCKBITER_WEAPON_RANK_5: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_ROCKBITER_WEAPON_RANK_5: SpellEffect called!"

        caster.SetMaxDamage(caster.GetMaxDamage() + 15)
#------------------------------------------------------------------------------
class Spell_ROCKBITER_WEAPON_RANK_6:
    """ rockbiter weapon Rank 6
    """
    def CanCast (self, caster, target_dummy):
        print "ROCKBITER_WEAPON_RANK_6: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_ROCKBITER_WEAPON_RANK_6: SpellEffect called!"

        caster.SetMaxDamage(caster.GetMaxDamage() + 28)
#------------------------------------------------------------------------------
class Spell_ROCKBITER_WEAPON_RANK_7:
    """ rockbiter weapon Rank 7
    """
    def CanCast (self, caster, target_dummy):
        print "ROCKBITER_WEAPON_RANK_7: CanCast called!"
        return 0

    def SpellEffect (self, caster, target):
        print "Spell_ROCKBITER_WEAPON_RANK_7: SpellEffect called!"

        caster.SetMaxDamage(caster.GetMaxDamage() + 40)
#------------------------------------------------------------------------------


#--- END ---