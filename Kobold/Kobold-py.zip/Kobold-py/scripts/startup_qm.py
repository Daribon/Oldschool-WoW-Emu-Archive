# This module is dedicated for Quest, Gossip, Item, GO, AreaTriggers processing and
# initialization.
#
# Author: <PavkaM>

from Ludmilla import *
from executables import *
import qm.def_text as dnpct
reload(dnpct)
import consts as co             # Import of constants
reload(co)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

printLog( " " )

def SelectModule(self, player):
    # init default_py for all creatures
    RegisterGossipModule ( self.GetEntry() , "qm.default_proc", FALSE )

##################################################################
    
def StartupQMSystem():
    printLog( " " )
    printLog( "------------========================------------" ) 
    printLog( "|ooooooooo SETTING UP <Quest> SYSTEM oooooooooo|" )
    printLog( "------------========================------------" ) 

##################################################################
    
    printLog( "------------========================------------" ) 
    printLog( "|ooo Registering handlers AI for GO and Area's |" )
    printLog( "------------========================------------" )

    RegiterGOHandlers()
    RegiterAreaTriggerHandlers()
    
    printLog( "|>----------------Successfully----------------<|" )

##################################################################
    
    printLog( " " )
    printLog( "|>---Registering public services (Guards)-----<|" )

    import qm.guardians.Ogrimmar_Grunt
    reload (qm.guardians.Ogrimmar_Grunt)
    RegisterGossipModule      (3296, "qm.guardians.Ogrimmar_Grunt", FALSE)

    import qm.guardians.Stormwind_Guard
    reload (qm.guardians.Stormwind_Guard)
    RegisterGossipModule      (1423, "qm.guardians.Stormwind_Guard", FALSE)
    
    import qm.guardians.Stormwind_City_Guard
    reload (qm.guardians.Stormwind_City_Guard)
    RegisterGossipModule      (68, "qm.guardians.Stormwind_City_Guard", FALSE)

    import qm.guardians.Darnassus_Sentinel
    reload (qm.guardians.Darnassus_Sentinel)
    RegisterGossipModule      (4262, "qm.guardians.Darnassus_Sentinel", FALSE)

    import qm.guardians.Teldrassil_Sentinel
    reload (qm.guardians.Teldrassil_Sentinel)
    RegisterGossipModule      (3571, "qm.guardians.Teldrassil_Sentinel", FALSE)

    import qm.guardians.Ironforge_Guard
    reload (qm.guardians.Ironforge_Guard)
    RegisterGossipModule      (5595, "qm.guardians.Ironforge_Guard", FALSE)


    import qm.guardians.Undercity_Guardian
    reload (qm.guardians.Undercity_Guardian)
    RegisterGossipModule      (5624, "qm.guardians.Undercity_Guardian", FALSE)

    import qm.guardians.Bluffwatcher
    reload (qm.guardians.Bluffwatcher)
    RegisterGossipModule      (3084, "qm.guardians.Bluffwatcher", FALSE)

    import qm.other.guildmaster
    reload (qm.other.guildmaster)

    import qm.guardians.Mulgore_Guardians
    reload (qm.guardians.Mulgore_Guardians)
    for i in (3209, 3210, 3211, 3212, 3213, 3214, 3215, 3217, 3218, 3219, 3220 ,3221, 3222, 3223 ,3224):
        RegisterGossipModule      (i, "qm.guardians.Mulgore_Guardians", FALSE)

    printLog( "|>----------------Successfully----------------<|" )

##################################################################
    # --------------------------------------------------> Specific NPC Scripts
    printLog( " " )
    printLog( "|>---------Registering Custom Modules---------<|" )

    import qm.custom.Marshal_McBride
    reload (qm.custom.Marshal_McBride)
    RegisterGossipModule (197, "qm.custom.Marshal_McBride", FALSE)

    import qm.custom.Skorn_Whitecloud
    reload (qm.custom.Skorn_Whitecloud)
    RegisterGossipModule (3052, "qm.custom.Skorn_Whitecloud", FALSE)

    import qm.TeleTubby
    reload (qm.TeleTubby)
    RegisterGossipModule (40001, "qm.TeleTubby", FALSE)

    printLog( "|>----------------Successfully----------------<|" )

##################################################################

    printLog( " " )
    printLog( "------------========================------------" ) 
    printLog( "|ooo SETTING UP <Default Texts/Menu Items> oooo|" )
    printLog( "------------========================------------" )

    dnpct.InitializeGreetNPCTextTable()
    dnpct.InitializeRefuseNPCTextTable()
    dnpct.InitializeTextTable()
    dnpct.InitializeInfoNPCTextTable()
    
    printLog( "|>----------------Successfully----------------<|" )

##################################################################

    printLog( "------------========================------------" ) 
    printLog( "|ooo registering remaining defailt AI      oooo|" )
    printLog( "------------========================------------" )

    import qm.default_proc
    reload (qm.default_proc)

    RegisterGossipModule      (0, "qm.default_proc", FALSE)
    RegisterItemHandlerModule (0, "qm.default_proc", FALSE)
    RegisterGOHandlerModule   (0, "qm.default_proc", FALSE)
    RegisterAreaTriggerModule (0, "qm.default_proc", FALSE)
    
    printLog( "|>----------------Successfully----------------<|" )

    printLog( " " )
    printLog( "------------========================------------" ) 
    printLog( "|oooo  Quest system ready to be used oooooooooo|" )
    printLog( "------------========================------------" ) 

def RegiterGOHandlers():
##################################################################
    printLog( " " )
    printLog( "|>---------Registering GO Script Modules------<|" )
   
    import qm.gameobjects.battlegroundflag
    reload (qm.gameobjects.battlegroundflag)
    RegisterGOHandlerModuleByName("Silverwing Flag", "qm.gameobjects.battlegroundflag", FALSE)
    RegisterGOHandlerModuleByName("Warsong Flag", "qm.gameobjects.battlegroundflag", FALSE)
    
    import ai.inst.Dead_Mines.Defiascannon
    reload (ai.inst.Dead_Mines.Defiascannon)
    RegisterGOHandlerModuleByName("Defias Cannon", "ai.inst.Dead_Mines.Defiascannon", FALSE)
    
    printLog( "|>----------------Successfully----------------<|" )

##################################################################

def RegiterAreaTriggerHandlers():

    printLog( " " )
    printLog( "|>-----Registering AreaTrigger Script Modules-<|" )
    
    import qm.areatriggers.battlegroundwarsong
    reload (qm.areatriggers.battlegroundwarsong)
    RegisterAreaTriggerModule(3646, "qm.areatriggers.battlegroundwarsong", FALSE)
    RegisterAreaTriggerModule(3647, "qm.areatriggers.battlegroundwarsong", FALSE)
    
    printLog( "|>----------------Successfully----------------<|" )
##################################################################


# Start QM System
StartupQMSystem()

#--- END ---

