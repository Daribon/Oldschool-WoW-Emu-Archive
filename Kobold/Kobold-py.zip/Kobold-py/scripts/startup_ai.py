# This module is dedicated for AI initialization.
#
from Ludmilla import *
from executables import *
from config import *
import ai.default
reload (ai.default)


# Used for Dinamical Calls of core, it will NOT override all registered Creatures in def StartupAISystem():
def SelectAIModule(self):
    #RegisterAIModule(self.GetEntry(), "ai.default", 0)
    pass
    
def StartupAISystem():
    printLog(" " )
    printLog("------------========================------------" ) 
    printLog("|ooooooooooo SETTING UP <AI> SYSTEM ooooooooooo|" )
    printLog("------------========================------------" ) 

##################################################################
    printLog(" " )
    printLog("|  -> Registering default AI NPC having spells |" )

    # Creature Type (AI selector)
    printLog( "|        -> by Type" )
    
    # Creature Family (AI Selector) 
    printLog( "|        -> by Family" )
    

    printLog( "|>----------------Successfully----------------<|" )

##################################################################
    printLog( " " )
    printLog("|>---------Registering BG AI Modules----------<|" )

    import ai.bg.bghealer
    Bghealer = ai.bg.bghealer
    reload(ai.bg.bghealer)
    RegisterAIClass (13116, Bghealer.AI_BGHealer(), 0)

    printLog("|>----------------Successfully----------------<|" )

##################################################################
    printLog( " " )
    printLog("|>------Registering Locations AI Modules------<|" )
    printLog("|   -> Registering <Westfall>                  |" )

    printLog("|   -> Registering <Elwynn Forrest>            |" )

    printLog("|   -> Registering <Durotar>                   |" )

    import ai.loc.durotar.lasypeon
    reload (ai.loc.durotar.lasypeon)
    RegisterAIModule (10556, "ai.loc.durotar.lasypeon", 0)

    printLog("|   -> Registering <Teldrassil>                |" )

    printLog("|>----------------Successfully----------------<|" )

##################################################################

    printLog("|>------Registering City's AI Modules---------<|" )
  
    printLog( "|>----------------Successfully----------------<|" )

##################################################################

    printLog( " " )
    printLog("|   -> Registering <BOSSES> AI Modules         |" )   
    import ai.bosses.edwinvancleef
    EdwinVanCleef = ai.bosses.edwinvancleef
    reload(ai.bg.bghealer)
    RegisterAIClass (639, EdwinVanCleef.AI_Vancleef(), 0)

    printLog("|>----------------Successfully----------------<|" )

##################################################################
    printLog(" " )

    printLog("|   -> Registering <Quest> AI Modules         |" )
    import ai.quest.quest_invisible
    reload (ai.quest.quest_invisible)
    for i in (5891,18826):
        RegisterAIModule (i, "ai.quest.quest_invisible", 0)

    printLog("|>----------------Successfully----------------<|" )

    printLog("|   -> Registering <Totems> AI Modules         |" )

    import ai.totems.alltotems
    reload (ai.totems.alltotems)
    for i in (5879,6110,6111,7844,7845,15482,15483,5873,5919,5920,7366,7367,7368,15470,15474,2630,\
              3579,3911,3912,3913,7398,7399,15478,5874,5921,5922,7403,15464,15479,2523,3902,3903,3904,15480,\
              7400,7402,5913,5923,3527,3906,3907,3908,3909,15488,5926,7412,7413,15486,5929,7464,\
              7465,7466,15484,3573,7414,7415,7416,15489,5950,6012,7423,10557,15485,5925,7467,7468,7469,6112,15490,\
              7483,7484,15496,15497,3968,9687,9688,9689,15492,5924,7486,7487,5927,7424,7425,10467,11100,11101,15463,15487):
        RegisterAIModule (i, "ai.totems.alltotems", 0)

##################################################################
    printLog("|   -> Registering <StandState> AI Modules     |" )

    import ai.type.humanoid.kneeling
    reload (ai.type.humanoid.kneeling)
    for i in (3140, 3644, 3650, 5042, 8396, 12427, 12429, 12430, 16546, 16723, 16807, 17073, 17515, 17519, 18813):
        RegisterAIModule (i, "ai.type.humanoid.kneeling", 0)

    import ai.type.humanoid.sitting
    reload (ai.type.humanoid.sitting)
    for i in (1413, 1414, 1415, 1457, 4451, 5738, 8403, 10599, 10600, 10721, 15171, 15367, 16554, 17520,\
              20407):
        RegisterAIModule (i, "ai.type.humanoid.sitting", 0)

    import ai.type.humanoid.sleeping
    reload (ai.type.humanoid.sleeping)
    for i in (2107, 2486, 2852, 3888, 4052, 4996, 5736, 5915, 7903, 7904, 9999, 10556, 15190, 16971, 17117,\
              17508, 17849, 18812):
        RegisterAIModule (i, "ai.type.humanoid.sleeping", 0)

    import ai.type.humanoid.working
    reload (ai.type.humanoid.working)
    for i in (16591, 17244, 18800, 18892 ):
        RegisterAIModule (i, "ai.type.humanoid.working", 0)

    import ai.type.humanoid.wounded
    reload (ai.type.humanoid.wounded)
    RegisterAIModule (16483, "ai.type.humanoid.wounded", 0)
    printLog("|>----------------Successfully----------------<|" )


##################################################################
#  Registering default AI NPC having spells, 
#  Must run as last, since already registered ai is skipped by core automaticaly.
    printLog(" " )
    printLog("|  -> Registering default AI NPC having spells |" )
    cursor = conn.cursor ()
    cursor.execute ("SELECT DISTINCT `creature_id` FROM `creatures_spell`")
    rows = cursor.fetchall ()
    for row in rows: RegisterAIModule(row[0], "ai.default", 0)
    cursor.close ()
    printLog("|>----------------Successfully----------------<|" )

##################################################################    
   
    printLog("------------========================------------" ) 
    printLog("|oooo  SETTING UP <AI> SYSTEM Successfully oooo|" )
    printLog("------------========================------------" ) 

StartupAISystem()

#--- END ---
