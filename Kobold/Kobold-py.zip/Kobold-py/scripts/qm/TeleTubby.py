#
# Default handler for all Innkeepers in the world. If you need special 
# treatments please use another script file for them.
#
# Author: <PavkaM>
# edited by <Jester>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    txtid = self.GetStoredNPCText(co.BANK_GREET, 820)

    if GetPlayerSide(player) == co.SIDE_ALLIANCE:
        txt1 = self.GetStoredText(co.BANK_GREET, "Stormwind - Alliance.")
        txt2 = self.GetStoredText(co.BANK_GREET, "Ironforge - Allianc.")
        txt3 = self.GetStoredText(co.BANK_GREET, "Darnassus - Alliance.")
        txt4 = self.GetStoredText(co.BANK_GREET, "Exodar - Alliance.")
        txt5 = self.GetStoredText(co.BANK_GREET, "Theramore - Alliance")
    else :
        txt1 = self.GetStoredText(co.BANK_GREET, "Undercity - Horde")
        txt2 = self.GetStoredText(co.BANK_GREET, "Ogrimmar - Horde")
        txt3 = self.GetStoredText(co.BANK_GREET, "Thunder Bluff - Horde")
        txt4 = self.GetStoredText(co.BANK_GREET, "Silvermoon City - Horde")
        txt5 = self.GetStoredText(co.BANK_GREET, "Grom`Gol - Horde")

    #txt6 = self.GetStoredText(co.BANK_GREET, "Ratchet - Neutral")
    #txt7 = self.GetStoredText(co.BANK_GREET, "Gadgetzan - Neutral")

    # Innkeeper related menus
    player.AddGossipItem( 0, txt1, co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO + 1)
    player.AddGossipItem( 0, txt2, co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO + 2)
    player.AddGossipItem( 0, txt3, co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO + 3)
    player.AddGossipItem( 0, txt4, co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO + 4) 
    player.AddGossipItem( 0, txt5, co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO + 5) 
    #player.AddGossipItem( 0, txt6, co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO + 6) 
    #player.AddGossipItem( 0, txt7, co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO + 7) 
    
    player.SendGossipMenu(self, txtid) # Inn Greet Message

    
# -------------------------------------------

def OnGossipSelect (self, player, sender, action):
    # Serving default menus
    
    if GetPlayerSide(player)== co.SIDE_ALLIANCE:
        if action == co.GOSSIP_SENDER_INFO + 1 :
            player.Teleport(0, -8975.57, 503.94, 96.39, 0) 
        elif action == co.GOSSIP_SENDER_INFO + 2 :
            player.Teleport(0, -5038.69, -808.57, 495.13, 0)
        elif action == co.GOSSIP_SENDER_INFO + 3 :
            player.Teleport(1, 9953.73, 2160.58, 1327.49, 0) 
        elif action == co.GOSSIP_SENDER_INFO + 4 :
            player.Teleport(530, -4006.42, -11878.67, 0.47, 0)
        elif action == co.GOSSIP_SENDER_INFO + 5 :
            player.Teleport(1, -3677.17, -4387.56, 10.75, 0)
        elif action == co.GOSSIP_SENDER_INFO + 6 :
            player.Teleport(1, -989.90, -3691.29, 9.10, 0)
        elif action == co.GOSSIP_SENDER_INFO + 7 :
            player.Teleport(1, -7120.97, -3768.82, 9.23, 0)
    else :
        if action == co.GOSSIP_SENDER_INFO + 1 :
            player.Teleport(0, 1790.03, 239.11, 60.55, 0) 
        elif action == co.GOSSIP_SENDER_INFO + 2 :
            player.Teleport(1, 1526.06, -4410.98, 13.87, 0)
        elif action == co.GOSSIP_SENDER_INFO + 3 :
            player.Teleport(1, -1405.51, 109.68, 16.37, 0) 
        elif action == co.GOSSIP_SENDER_INFO + 4 :
            player.Teleport(530, 9416.72, -7281.41, 14.18, 0)
        elif action == co.GOSSIP_SENDER_INFO + 5 :
            player.Teleport(0, -12352.80, 211.45, 4.85, 0)
        elif action == co.GOSSIP_SENDER_INFO + 6 :
            player.Teleport(1, -989.90, -3691.29, 9.10, 0)
        elif action == co.GOSSIP_SENDER_INFO + 7 :
            player.Teleport(1, -7120.97, -3768.82, 9.23, 0)
    
def OnDialogStatus (self, player):
    return player.NPCQuestDialogStatus( self, co.DIALOG_STATUS_CHAT )

def GetPlayerSide(p):
    if  p.GetRace() == co.RACE_HUMAN or \
        p.GetRace() == co.RACE_DWARF or \
        p.GetRace() == co.RACE_NIGHT_ELF or \
        p.GetRace() == co.RACE_DRAENEI or \
        p.GetRace() == co.RACE_GNOME:
        return co.SIDE_ALLIANCE
        
    if  p.GetRace() == co.RACE_ORC or \
        p.GetRace() == co.RACE_UNDEAD or \
        p.GetRace() == co.RACE_TAUREN or \
        p.GetRace() == co.RACE_BLOOD_ELF or \
        p.GetRace() == co.RACE_TROLL:
        return co.SIDE_HORDE