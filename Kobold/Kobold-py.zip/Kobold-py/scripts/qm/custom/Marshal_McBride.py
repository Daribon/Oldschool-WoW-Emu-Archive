#
# Marshal McBride Specific script
#
# Author: <PavkaM>

from Ludmilla import *
from random import *
import consts as co
reload(co)


def OnChooseReward (self, player, questid, rewardid):
    if questid == 21: # Skirmish at Echo Ridge
        self.Emote   (co.EMOTE_ONESHOT_SALUTE) 
        player.Emote (co.EMOTE_ONESHOT_SALUTE)
        self.Say     (player, "You are dismissed.", co.LANG_UNIVERSAL, co.MONSTER_SAY)
        
    FollowUpQuest = player.GetFollowingQuest(self, questid)
    if FollowUpQuest != 0 :
        player.SendQuestDetails(self, FollowUpQuest)
    else :
        player.CloseGossipWindow()


