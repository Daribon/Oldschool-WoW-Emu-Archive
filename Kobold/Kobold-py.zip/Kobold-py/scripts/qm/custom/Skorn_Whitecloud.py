#
# Skorn Whitecloud handler
#
# Author: <PavkaM>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):
    player.AddGossipItem( 0, "Tell me a story, Skorn.", co.GOSSIP_SENDER_MAIN, co.GOSSIP_SENDER_INFO )
    player.SendGossipMenu( self, 522 ) # Skorn Whitecloud message

    
# -------------------------------------------

def OnGossipSelect (self, player, sender, action):
    # Serving default menus
    
    if action == co.GOSSIP_SENDER_INFO :
        player.SendGossipMenu(self, 523 )

