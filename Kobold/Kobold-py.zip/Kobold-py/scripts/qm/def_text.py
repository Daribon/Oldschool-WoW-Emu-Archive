#
# This module initializes the default NPCTexts for all NPCs.
# If a NPC has a default text please add it here
#
# Author: <PavkaM>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def InitializeGreetNPCTextTable():
    # ==> Added on 21.10.2005 by <PavkaM>. Exported from WADEmu creatures.scp.
    # Note: Should be removed by sniffing. 20% are incorrect.
    
    RegisterStoredNPCText( co.BANK_GREET,  223, 5294)  # Dan Golthas
    RegisterStoredNPCText( co.BANK_GREET,  233, 2414)  # Farmer Saldean
    RegisterStoredNPCText( co.BANK_GREET,  332, 5994)  # Master Mathias Shaw
    RegisterStoredNPCText( co.BANK_GREET,  352, 1256)  # Dungar Longdrink
    RegisterStoredNPCText( co.BANK_GREET,  440,  878)  # Blackrock Grunt
    RegisterStoredNPCText( co.BANK_GREET,  460, 5693)  # Alamar Grimm
    RegisterStoredNPCText( co.BANK_GREET,  491, 5010)  # Quartermaster Lewis
    RegisterStoredNPCText( co.BANK_GREET,  523, 5009)  # Thor
    RegisterStoredNPCText( co.BANK_GREET,  658, 4937)  # Sten Stoutarm
    RegisterStoredNPCText( co.BANK_GREET,  716, 6535)  # Barnil Stonepot
    RegisterStoredNPCText( co.BANK_GREET,  836, 1914)  # Durnan Furcutter
    RegisterStoredNPCText( co.BANK_GREET,  837, 4436)  # Branstock Khalder
    RegisterStoredNPCText( co.BANK_GREET,  895, 5000)  # Thorgas Grimson
    RegisterStoredNPCText( co.BANK_GREET,  906, 2193)  # Maximillian Crowe
    RegisterStoredNPCText( co.BANK_GREET,  912, 1215)  # Thran Khorman
    RegisterStoredNPCText( co.BANK_GREET,  916, 4834)  # Solm Hargrin
    RegisterStoredNPCText( co.BANK_GREET,  925, 3976)  # Brother Sammuel
    RegisterStoredNPCText( co.BANK_GREET,  926, 3975)  # Bromos Grummner
    RegisterStoredNPCText( co.BANK_GREET,  928, 3976)  # Lord Grayson Shadowbreaker
    RegisterStoredNPCText( co.BANK_GREET,  944,  561)  # Marryk Nurribit
    RegisterStoredNPCText( co.BANK_GREET,  963, 2287)  # Deputy Rainer
    RegisterStoredNPCText( co.BANK_GREET, 1019,  923)  # Elder Razormaw
    RegisterStoredNPCText( co.BANK_GREET, 1243, 4990)  # Hegnar Rumbleshot
    RegisterStoredNPCText( co.BANK_GREET, 1284,  580)  # Archbishop Benedictus
    RegisterStoredNPCText( co.BANK_GREET, 1300, 5416)  # Lawrence Schneider
    RegisterStoredNPCText( co.BANK_GREET, 1309, 1231)  # Wynne Larson
    RegisterStoredNPCText( co.BANK_GREET, 1310, 1231)  # Evan Larson
    RegisterStoredNPCText( co.BANK_GREET, 1315, 1231)  # Allan Hafgan
    RegisterStoredNPCText( co.BANK_GREET, 1317, 5207)  # Lucan Cordell
    RegisterStoredNPCText( co.BANK_GREET, 1318, 1231)  # Jessara Cordell
    RegisterStoredNPCText( co.BANK_GREET, 1319, 1238)  # Bryan Cross
    RegisterStoredNPCText( co.BANK_GREET, 1325, 1258)  # Jasper Fel
    RegisterStoredNPCText( co.BANK_GREET, 1340, 2289)  # Mountaineer Kadrell
    RegisterStoredNPCText( co.BANK_GREET, 1346, 5561)  # Georgio Bolero
    RegisterStoredNPCText( co.BANK_GREET, 1347, 1234)  # Alexandra Bolero
    RegisterStoredNPCText( co.BANK_GREET, 1351, 1242)  # Brother Cassius
    RegisterStoredNPCText( co.BANK_GREET, 1368, 1231)  # Justin
    RegisterStoredNPCText( co.BANK_GREET, 1382, 7017)  # Mudduk
    RegisterStoredNPCText( co.BANK_GREET, 1387, 5561)  # Thysta
    RegisterStoredNPCText( co.BANK_GREET, 1416, 7055)  # Grimand Elmore
    RegisterStoredNPCText( co.BANK_GREET, 1445, 1250)  # Jesse Halloran
    RegisterStoredNPCText( co.BANK_GREET, 1465, 1231)  # Drac Roughcut
    RegisterStoredNPCText( co.BANK_GREET, 1470, 5693)  # Ghak Healtouch
    RegisterStoredNPCText( co.BANK_GREET, 1496, 4093)  # Deathguard Dillinger
    RegisterStoredNPCText( co.BANK_GREET, 1569, 4934)  # Shadow Priest Sarvis
    RegisterStoredNPCText( co.BANK_GREET, 1572, 5580)  # Thorgrum Borrelson
    RegisterStoredNPCText( co.BANK_GREET, 1573, 5582)  # Gryth Thurden
    RegisterStoredNPCText( co.BANK_GREET, 1632, 5258)  # Adele Fielder
    RegisterStoredNPCText( co.BANK_GREET, 1652, 4097)  # Deathguard Burgess
    RegisterStoredNPCText( co.BANK_GREET, 1694, 4253)  # Loslor Rudge
    RegisterStoredNPCText( co.BANK_GREET, 1699, 7021)  # Gremlock Pilsnor
    RegisterStoredNPCText( co.BANK_GREET, 1703, 4999)  # Uthrar Threx
    RegisterStoredNPCText( co.BANK_GREET, 1738, 4097)  # Deathguard Terrence
    RegisterStoredNPCText( co.BANK_GREET, 1742, 4096)  # Deathguard Bartholomew
    RegisterStoredNPCText( co.BANK_GREET, 1743, 4074)  # Deathguard Lawrence
    RegisterStoredNPCText( co.BANK_GREET, 1744, 4097)  # Deathguard Mort
    RegisterStoredNPCText( co.BANK_GREET, 1746, 4097)  # Deathguard Cyrus
    RegisterStoredNPCText( co.BANK_GREET, 2079, 4936)  # Conservator Ilthalaine
    RegisterStoredNPCText( co.BANK_GREET, 2119, 1219)  # Dannal Stern
    RegisterStoredNPCText( co.BANK_GREET, 2122,  581)  # David Trias
    RegisterStoredNPCText( co.BANK_GREET, 2123, 4442)  # Dark Cleric Duesten
    RegisterStoredNPCText( co.BANK_GREET, 2124,  562)  # Isabella
    RegisterStoredNPCText( co.BANK_GREET, 2126, 5720)  # Maximillion
    RegisterStoredNPCText( co.BANK_GREET, 2127, 5719)  # Rupert Boch
    RegisterStoredNPCText( co.BANK_GREET, 2128,  563)  # Cain Firesong
    RegisterStoredNPCText( co.BANK_GREET, 2129, 4439)  # Dark Cleric Beryl
    RegisterStoredNPCText( co.BANK_GREET, 2130, 4796)  # Marion Call
    RegisterStoredNPCText( co.BANK_GREET, 2132, 5043)  # Carolai Anise
    RegisterStoredNPCText( co.BANK_GREET, 2169, 6957)  # Blackwood Totemic
    RegisterStoredNPCText( co.BANK_GREET, 2209, 4074)  # Deathguard Gavin
    RegisterStoredNPCText( co.BANK_GREET, 2210, 4097)  # Deathguard Royann
    RegisterStoredNPCText( co.BANK_GREET, 2226, 5453)  # Karos Razok
    RegisterStoredNPCText( co.BANK_GREET, 2327, 1221)  # Shaina Fuller
    RegisterStoredNPCText( co.BANK_GREET, 2393, 6595)  # Christoph Jeffcoat
    RegisterStoredNPCText( co.BANK_GREET, 2425, 4476)  # Varimathras
    RegisterStoredNPCText( co.BANK_GREET, 2489, 5168)  # Milstaff Stormeye
    RegisterStoredNPCText( co.BANK_GREET, 2492, 5885)  # Lexington Mortaim
    RegisterStoredNPCText( co.BANK_GREET, 2704, 6275)  # Hanashi
    RegisterStoredNPCText( co.BANK_GREET, 2788, 3293)  # Apprentice Kryten
    RegisterStoredNPCText( co.BANK_GREET, 2798, 7028)  # Pand Stonebinder
    RegisterStoredNPCText( co.BANK_GREET, 2834, 6793)  # Myizz Luckycatch
    RegisterStoredNPCText( co.BANK_GREET, 2858, 5454)  # Gringer
    RegisterStoredNPCText( co.BANK_GREET, 2859, 5479)  # Gyll
    RegisterStoredNPCText( co.BANK_GREET, 2916, 6383)  # Historian Karnik
    RegisterStoredNPCText( co.BANK_GREET, 2941, 7122)  # Lanie Reed
    RegisterStoredNPCText( co.BANK_GREET, 2980, 4935)  # Grull Hawkwind
    RegisterStoredNPCText( co.BANK_GREET, 2995, 5500)  # Tal
    RegisterStoredNPCText( co.BANK_GREET, 3009, 5079)  # Bena Winterhoof
    RegisterStoredNPCText( co.BANK_GREET, 3022, 4056)  # Sunn Ragetotem
    RegisterStoredNPCText( co.BANK_GREET, 3031, 5005)  # Tigor Skychaser
    RegisterStoredNPCText( co.BANK_GREET, 3041, 1218)  # Torm Ragetotem
    RegisterStoredNPCText( co.BANK_GREET, 3043, 1218)  # Ker Ragetotem
    RegisterStoredNPCText( co.BANK_GREET, 3045, 4439)  # Malakai Cross
    RegisterStoredNPCText( co.BANK_GREET, 3052,  522)  # Skorn Whitecloud
    RegisterStoredNPCText( co.BANK_GREET, 3057, 7013)  # Cairne Bloodhoof
    RegisterStoredNPCText( co.BANK_GREET, 3059, 4973)  # Harutt Thunderhorn
    RegisterStoredNPCText( co.BANK_GREET, 3060, 5717)  # Gart Mistrunner
    RegisterStoredNPCText( co.BANK_GREET, 3061, 4997)  # Lanka Farshot
    RegisterStoredNPCText( co.BANK_GREET, 3062, 5006)  # Meela Dawnstrider
    RegisterStoredNPCText( co.BANK_GREET, 3063, 1218)  # Krang Stonehoof
    RegisterStoredNPCText( co.BANK_GREET, 3064, 4785)  # Gennia Runetotem
    RegisterStoredNPCText( co.BANK_GREET, 3065, 4998)  # Yaw Sharpmane
    RegisterStoredNPCText( co.BANK_GREET, 3144, 3573)  # Eitrigg
    RegisterStoredNPCText( co.BANK_GREET, 3149, 3133)  # Nez'raz
    RegisterStoredNPCText( co.BANK_GREET, 3150, 2753)  # Hin Denburg
    RegisterStoredNPCText( co.BANK_GREET, 3153, 1040)  # Frang
    RegisterStoredNPCText( co.BANK_GREET, 3156, 5715)  # Nartok
    RegisterStoredNPCText( co.BANK_GREET, 3171, 4888)  # Thotar
    RegisterStoredNPCText( co.BANK_GREET, 3174, 3409)  # Dwukk
    RegisterStoredNPCText( co.BANK_GREET, 3184, 5034)  # Miao'zan
    RegisterStoredNPCText( co.BANK_GREET, 3212, 4072)  # Brave Ironhorn
    RegisterStoredNPCText( co.BANK_GREET, 3216, 4513)  # Neeru Fireblade
    RegisterStoredNPCText( co.BANK_GREET, 3274, 5495)  # Kolkar Pack Runner
    RegisterStoredNPCText( co.BANK_GREET, 3305, 7123)  # Grisha
    RegisterStoredNPCText( co.BANK_GREET, 3306, 5838)  # Keldas
    RegisterStoredNPCText( co.BANK_GREET, 3309, 2275)  # Karus
    RegisterStoredNPCText( co.BANK_GREET, 3310, 5516)  # Doras
    RegisterStoredNPCText( co.BANK_GREET, 3314, 5516)  # Urtharo
    RegisterStoredNPCText( co.BANK_GREET, 3315, 5005)  # Tor'phan
    RegisterStoredNPCText( co.BANK_GREET, 3318, 2275)  # Koma
    RegisterStoredNPCText( co.BANK_GREET, 3320, 2275)  # Soran
    RegisterStoredNPCText( co.BANK_GREET, 3322, 2275)  # Kaja
    RegisterStoredNPCText( co.BANK_GREET, 3332, 5793)  # Lumak
    RegisterStoredNPCText( co.BANK_GREET, 3333, 4879)  # Shankys
    RegisterStoredNPCText( co.BANK_GREET, 3341,  942)  # Gann Stonespire
    RegisterStoredNPCText( co.BANK_GREET, 3342, 2275)  # Shan'ti
    RegisterStoredNPCText( co.BANK_GREET, 3344, 5005)  # Kardris Dreamseeker
    RegisterStoredNPCText( co.BANK_GREET, 3345, 2280)  # Godan
    RegisterStoredNPCText( co.BANK_GREET, 3352, 4866)  # Ormak Grimshot
    RegisterStoredNPCText( co.BANK_GREET, 3355, 1606)  # Saru Steelfury
    RegisterStoredNPCText( co.BANK_GREET, 3362, 3893)  # Ogunaro Wolfrunner
    RegisterStoredNPCText( co.BANK_GREET, 3365, 5354)  # Karolek
    RegisterStoredNPCText( co.BANK_GREET, 3368, 5005)  # Borstan
    RegisterStoredNPCText( co.BANK_GREET, 3387, 2275)  # Jorn Skyseer
    RegisterStoredNPCText( co.BANK_GREET, 3412, 5158)  # Nogg
    RegisterStoredNPCText( co.BANK_GREET, 3413, 1571)  # Sovik
    RegisterStoredNPCText( co.BANK_GREET, 3428,  519)  # Korran
    RegisterStoredNPCText( co.BANK_GREET, 3429, 3559)  # Thork
    RegisterStoredNPCText( co.BANK_GREET, 3430, 3658)  # Mangletooth
    RegisterStoredNPCText( co.BANK_GREET, 3431, 3334)  # Grenthar
    RegisterStoredNPCText( co.BANK_GREET, 3432, 3553)  # Mankrik
    RegisterStoredNPCText( co.BANK_GREET, 3448, 4933)  # Tonga Runetotem
    RegisterStoredNPCText( co.BANK_GREET, 3457, 5516)  # Razormane Stalker
    RegisterStoredNPCText( co.BANK_GREET, 3478, 3471)  # Traugh
    RegisterStoredNPCText( co.BANK_GREET, 3483, 5496)  # Jahan Hawkwing
    RegisterStoredNPCText( co.BANK_GREET, 3484, 5440)  # Kil'hala
    RegisterStoredNPCText( co.BANK_GREET, 3489, 5515)  # Zargh
    RegisterStoredNPCText( co.BANK_GREET, 3494, 5696)  # Tinkerwiz
    RegisterStoredNPCText( co.BANK_GREET, 3516, 2285)  # Arch Druid Fandral Staghelm
    RegisterStoredNPCText( co.BANK_GREET, 3520, 1258)  # Ol' Emma
    RegisterStoredNPCText( co.BANK_GREET, 3523, 5431)  # Bowen Brisboise
    RegisterStoredNPCText( co.BANK_GREET, 3549, 5283)  # Shelene Rhobart
    RegisterStoredNPCText( co.BANK_GREET, 3557, 3418)  # Guillaume Sorouy
    RegisterStoredNPCText( co.BANK_GREET, 3593, 5725)  # Alyissia
    RegisterStoredNPCText( co.BANK_GREET, 3594, 4795)  # Frahun Shadewhisper
    RegisterStoredNPCText( co.BANK_GREET, 3595, 4438)  # Shanda
    RegisterStoredNPCText( co.BANK_GREET, 3596, 4863)  # Ayanna Everstride
    RegisterStoredNPCText( co.BANK_GREET, 3597, 4783)  # Mardant Strongoak
    RegisterStoredNPCText( co.BANK_GREET, 3598, 5725)  # Kyra Windblade
    RegisterStoredNPCText( co.BANK_GREET, 3599,  934)  # Jannok Breezesong
    RegisterStoredNPCText( co.BANK_GREET, 3605, 5264)  # Nadyia Maneweaver
    RegisterStoredNPCText( co.BANK_GREET, 3606, 5190)  # Alanna Raveneye
    RegisterStoredNPCText( co.BANK_GREET, 3615, 5495)  # Devrak
    RegisterStoredNPCText( co.BANK_GREET, 3620, 5838)  # Harruk
    RegisterStoredNPCText( co.BANK_GREET, 3622, 5839)  # Grokor
    RegisterStoredNPCText( co.BANK_GREET, 3624, 5839)  # Zudd
    RegisterStoredNPCText( co.BANK_GREET, 3685, 4862)  # Harb Clawhoof
    RegisterStoredNPCText( co.BANK_GREET, 3688, 5839)  # Reban Freerunner
    RegisterStoredNPCText( co.BANK_GREET, 3690, 4874)  # Kar Stormsinger
    RegisterStoredNPCText( co.BANK_GREET, 3691, 6553)  # Raene Wolfrunner
    RegisterStoredNPCText( co.BANK_GREET, 3838, 5474)  # Vesprystus
    RegisterStoredNPCText( co.BANK_GREET, 3841, 5473)  # Caylais Moonfeather
    RegisterStoredNPCText( co.BANK_GREET, 3850,  798)  # Sorcerer Ashcrombe
    RegisterStoredNPCText( co.BANK_GREET, 3967, 5364)  # Aayndia Floralwind
    RegisterStoredNPCText( co.BANK_GREET, 4143, 4795)  # Sparkleshell Snapper
    RegisterStoredNPCText( co.BANK_GREET, 4146, 4863)  # Jocaste
    RegisterStoredNPCText( co.BANK_GREET, 4151, 4795)  # Saltstone Crystalhide
    RegisterStoredNPCText( co.BANK_GREET, 4159, 5541)  # Me'lynn
    RegisterStoredNPCText( co.BANK_GREET, 4160, 5098)  # Ainethil
    RegisterStoredNPCText( co.BANK_GREET, 4200, 5476)  # Laird
    RegisterStoredNPCText( co.BANK_GREET, 4202, 5473)  # Gerenzo Wrenchwhistle
    RegisterStoredNPCText( co.BANK_GREET, 4211, 7028)  # Dannelor
    RegisterStoredNPCText( co.BANK_GREET, 4256, 5581)  # Golnir Bouldertoe
    RegisterStoredNPCText( co.BANK_GREET, 4314, 7175)  # Gorkas
    RegisterStoredNPCText( co.BANK_GREET, 4374, 5474)  # Strashaz Hydra
    RegisterStoredNPCText( co.BANK_GREET, 4419,  932)  # Race Master Kronkrider
    RegisterStoredNPCText( co.BANK_GREET, 4429,  778)  # Goblin Pit Crewman
    RegisterStoredNPCText( co.BANK_GREET, 4430,  780)  # Gnome Pit Crewman
    RegisterStoredNPCText( co.BANK_GREET, 4488, 5821)  # Parqual Fintallas
    RegisterStoredNPCText( co.BANK_GREET, 4489, 5820)  # Braug Dimspirit
    RegisterStoredNPCText( co.BANK_GREET, 4551, 5454)  # Michael Garrett
    RegisterStoredNPCText( co.BANK_GREET, 4552, 7021)  # Eunice Burch
    RegisterStoredNPCText( co.BANK_GREET, 4556, 5455)  # Gordon Wendham
    RegisterStoredNPCText( co.BANK_GREET, 4559, 5582)  # Timothy Weldon
    RegisterStoredNPCText( co.BANK_GREET, 4563, 5674)  # Kaal Soulreaper
    RegisterStoredNPCText( co.BANK_GREET, 4564, 5719)  # Luther Pickman
    RegisterStoredNPCText( co.BANK_GREET, 4565, 5674)  # Richard Kerwin
    RegisterStoredNPCText( co.BANK_GREET, 4566,  563)  # Kaelystia Hatebringer
    RegisterStoredNPCText( co.BANK_GREET, 4567,  563)  # Pierce Shackleton
    RegisterStoredNPCText( co.BANK_GREET, 4568,  563)  # Anastasia Hartwell
    RegisterStoredNPCText( co.BANK_GREET, 4573, 6961)  # Armand Cromwell
    RegisterStoredNPCText( co.BANK_GREET, 4576, 5566)  # Josef Gregorian
    RegisterStoredNPCText( co.BANK_GREET, 4578, 5918)  # Josephine Lister
    RegisterStoredNPCText( co.BANK_GREET, 4582, 4796)  # Carolyn Ward
    RegisterStoredNPCText( co.BANK_GREET, 4583, 4796)  # Miles Dexter
    RegisterStoredNPCText( co.BANK_GREET, 4584, 4796)  # Gregory Charles
    RegisterStoredNPCText( co.BANK_GREET, 4586, 5139)  # Graham Van Talen
    RegisterStoredNPCText( co.BANK_GREET, 4591, 7028)  # Mary Edras
    RegisterStoredNPCText( co.BANK_GREET, 4593, 1219)  # Christoph Walker
    RegisterStoredNPCText( co.BANK_GREET, 4594, 1219)  # Angela Curthas
    RegisterStoredNPCText( co.BANK_GREET, 4595, 1219)  # Baltus Fowler
    RegisterStoredNPCText( co.BANK_GREET, 4599, 4476)  # Sarah Killian
    RegisterStoredNPCText( co.BANK_GREET, 4606, 4439)  # Aelthalyste
    RegisterStoredNPCText( co.BANK_GREET, 4607, 4439)  # Father Lankester
    RegisterStoredNPCText( co.BANK_GREET, 4608, 4439)  # Father Lazarus
    RegisterStoredNPCText( co.BANK_GREET, 4609, 5089)  # Doctor Marsh
    RegisterStoredNPCText( co.BANK_GREET, 4611, 5099)  # Doctor Herbert Halsey
    RegisterStoredNPCText( co.BANK_GREET, 4613, 6159)  # Christopher Drakul
    RegisterStoredNPCText( co.BANK_GREET, 4616, 5228)  # Lavinia Crowe
    RegisterStoredNPCText( co.BANK_GREET, 4631, 5753)  # Wharfmaster Lozgil
    RegisterStoredNPCText( co.BANK_GREET, 4702, 4449)  # Ancient Kodo
    RegisterStoredNPCText( co.BANK_GREET, 4731, 4869)  # Zachariah Post
    RegisterStoredNPCText( co.BANK_GREET, 4752, 2275)  # Kildar
    RegisterStoredNPCText( co.BANK_GREET, 4772, 5858)  # Ultham Ironhorn
    RegisterStoredNPCText( co.BANK_GREET, 4773, 4873)  # Velma Warnam
    RegisterStoredNPCText( co.BANK_GREET, 4792,  580)  # "Swamp Eye" Jarl
    RegisterStoredNPCText( co.BANK_GREET, 4900, 5050)  # Alchemist Narett
    RegisterStoredNPCText( co.BANK_GREET, 4926, 1819)  # Krog
    RegisterStoredNPCText( co.BANK_GREET, 4945, 2138)  # Goblin Drag Car
    RegisterStoredNPCText( co.BANK_GREET, 4946,  778)  # Gnome Drag Car
    RegisterStoredNPCText( co.BANK_GREET, 4949, 4522)  # Thrall
    RegisterStoredNPCText( co.BANK_GREET, 4981, 1235)  # Ben Trias
    RegisterStoredNPCText( co.BANK_GREET, 4984, 5276)  # Argos Nightwhisper
    RegisterStoredNPCText( co.BANK_GREET, 5082, 3666)  # Vincent Hyal
    RegisterStoredNPCText( co.BANK_GREET, 5099, 6286)  # Soleil Stonemantle
    RegisterStoredNPCText( co.BANK_GREET, 5113, 5724)  # Kelv Sternhammer
    RegisterStoredNPCText( co.BANK_GREET, 5115, 5000)  # Daera Brightspear
    RegisterStoredNPCText( co.BANK_GREET, 5138, 5838)  # Gwina Stonebranch
    RegisterStoredNPCText( co.BANK_GREET, 5144,  823)  # Bink
    RegisterStoredNPCText( co.BANK_GREET, 5150, 7026)  # Nissa Firestone
    RegisterStoredNPCText( co.BANK_GREET, 5153, 5119)  # Jormund Stonebrow
    RegisterStoredNPCText( co.BANK_GREET, 5353, 1996)  # Itharius
    RegisterStoredNPCText( co.BANK_GREET, 5411, 2954)  # Krinkle Goodsteel
    RegisterStoredNPCText( co.BANK_GREET, 5484, 4434)  # Brother Benjamin
    RegisterStoredNPCText( co.BANK_GREET, 5491, 3976)  # Arthur the Faithful
    RegisterStoredNPCText( co.BANK_GREET, 5492, 3976)  # Katherine the Pure
    RegisterStoredNPCText( co.BANK_GREET, 5495, 5693)  # Ursula Deline
    RegisterStoredNPCText( co.BANK_GREET, 5498,  539)  # Elsharin
    RegisterStoredNPCText( co.BANK_GREET, 5500, 5019)  # Tel'Athir
    RegisterStoredNPCText( co.BANK_GREET, 5501, 3546)  # Kaerbrus
    RegisterStoredNPCText( co.BANK_GREET, 5503, 1233)  # Eldraeith
    RegisterStoredNPCText( co.BANK_GREET, 5505, 4784)  # Theridran
    RegisterStoredNPCText( co.BANK_GREET, 5515, 5000)  # Einris Brightspear
    RegisterStoredNPCText( co.BANK_GREET, 5516, 5000)  # Ulfir Ironbeard
    RegisterStoredNPCText( co.BANK_GREET, 5519, 1249)  # Billibub Cogspinner
    RegisterStoredNPCText( co.BANK_GREET, 5564, 5324)  # Simon Tanner
    RegisterStoredNPCText( co.BANK_GREET, 5565, 1238)  # Jillian Tanner
    RegisterStoredNPCText( co.BANK_GREET, 5594, 1471)  # Alchemist Pestlezugg
    RegisterStoredNPCText( co.BANK_GREET, 5695, 5233)  # Vance Undergloom
    RegisterStoredNPCText( co.BANK_GREET, 5725, 4097)  # Deathguard Lundmark
    RegisterStoredNPCText( co.BANK_GREET, 5749, 5836)  # Kayla Smithe
    RegisterStoredNPCText( co.BANK_GREET, 5750, 5835)  # Gina Lang
    RegisterStoredNPCText( co.BANK_GREET, 5753, 5835)  # Martha Strain
    RegisterStoredNPCText( co.BANK_GREET, 5759, 7028)  # Nurse Neela
    RegisterStoredNPCText( co.BANK_GREET, 5769, 2284)  # Arch Druid Hamuul Runetotem
    RegisterStoredNPCText( co.BANK_GREET, 5811, 2275)  # Kamari
    RegisterStoredNPCText( co.BANK_GREET, 5817, 5005)  # Shimra
    RegisterStoredNPCText( co.BANK_GREET, 5901, 1916)  # Islen Waterseer
    RegisterStoredNPCText( co.BANK_GREET, 5939, 7028)  # Vira Younghoof
    RegisterStoredNPCText( co.BANK_GREET, 5941, 6961)  # Lau'Tiki
    RegisterStoredNPCText( co.BANK_GREET, 5994, 3793)  # Zayus
    RegisterStoredNPCText( co.BANK_GREET, 6020, 3793)  # Slimeshell Makrura
    RegisterStoredNPCText( co.BANK_GREET, 6119,  766)  # Tog Rustsprocket
    RegisterStoredNPCText( co.BANK_GREET, 6252, 3586)  # Acolyte Magaz
    RegisterStoredNPCText( co.BANK_GREET, 6254, 3587)  # Acolyte Wytula
    RegisterStoredNPCText( co.BANK_GREET, 6289, 5433)  # Rand Rhobart
    RegisterStoredNPCText( co.BANK_GREET, 6301, 5121)  # Gorbold Steelhand
    RegisterStoredNPCText( co.BANK_GREET, 6376, 5835)  # Wren Darkspring
    RegisterStoredNPCText( co.BANK_GREET, 6491,  580)  # Spirit Healer
    RegisterStoredNPCText( co.BANK_GREET, 6546, 3590)  # Tabetha
    RegisterStoredNPCText( co.BANK_GREET, 6548, 2354)  # Magus Tirth
    RegisterStoredNPCText( co.BANK_GREET, 6566,  581)  # Estelle Gendry
    RegisterStoredNPCText( co.BANK_GREET, 6568, 1933)  # Vizzklick
    RegisterStoredNPCText( co.BANK_GREET, 6826, 2253)  # Talvash del Kissel
    RegisterStoredNPCText( co.BANK_GREET, 7166, 1041)  # Wrenix's Gizmotronic Apparatus
    RegisterStoredNPCText( co.BANK_GREET, 7172, 1094)  # Lore Keeper of Norgannon
    RegisterStoredNPCText( co.BANK_GREET, 7230, 1640)  # Shayis Steelfury
    RegisterStoredNPCText( co.BANK_GREET, 7231, 1635)  # Kelgruk Bloodaxe
    RegisterStoredNPCText( co.BANK_GREET, 7298, 5046)  # Demnul Farmountain
    RegisterStoredNPCText( co.BANK_GREET, 7363, 1303)  # Kum'isha the Collector
    RegisterStoredNPCText( co.BANK_GREET, 7406, 2136)  # Oglethorpe Obnoticus
    RegisterStoredNPCText( co.BANK_GREET, 7564, 2055)  # Marin Noggenfogger
    RegisterStoredNPCText( co.BANK_GREET, 7572, 1391)  # Fallen Hero of the Horde
    RegisterStoredNPCText( co.BANK_GREET, 7604, 1516)  # Sergeant Bly
    RegisterStoredNPCText( co.BANK_GREET, 7683, 1734)  # Alessandro Luca
    RegisterStoredNPCText( co.BANK_GREET, 7771, 2038)  # Marvon Rivetseeker
    RegisterStoredNPCText( co.BANK_GREET, 7772, 2054)  # Kalin Windflight
    RegisterStoredNPCText( co.BANK_GREET, 7773, 2053)  # Marli Wishrunner
    RegisterStoredNPCText( co.BANK_GREET, 7775, 2433)  # Gregan Brewspewer
    RegisterStoredNPCText( co.BANK_GREET, 7776, 3545)  # Talo Thornhoof
    RegisterStoredNPCText( co.BANK_GREET, 7783, 1796)  # Loramus Thalipedes
    RegisterStoredNPCText( co.BANK_GREET, 7804, 1759)  # Trenton Lighthammer
    RegisterStoredNPCText( co.BANK_GREET, 7825, 6979)  # Oran Snakewrithe
    RegisterStoredNPCText( co.BANK_GREET, 7852, 2639)  # Pratt McGrubben
    RegisterStoredNPCText( co.BANK_GREET, 7853, 2282)  # Scooty
    RegisterStoredNPCText( co.BANK_GREET, 7854, 2638)  # Jangdor Swiftstrider
    RegisterStoredNPCText( co.BANK_GREET, 7868, 3804)  # Sarah Tanner
    RegisterStoredNPCText( co.BANK_GREET, 7871, 3806)  # Se'Jib
    RegisterStoredNPCText( co.BANK_GREET, 7875, 7402)  # Hadoken Swiftstrider
    RegisterStoredNPCText( co.BANK_GREET, 7944, 2137)  # Tinkmaster Overspark
    RegisterStoredNPCText( co.BANK_GREET, 7949, 1759)  # Xylinnia Starshine
    RegisterStoredNPCText( co.BANK_GREET, 7954, 4878)  # Binjy Featherwhistle
    RegisterStoredNPCText( co.BANK_GREET, 7955, 3945)  # Milli Featherwhistle
    RegisterStoredNPCText( co.BANK_GREET, 8115, 1924)  # Witch Doctor Uzer'i
    RegisterStoredNPCText( co.BANK_GREET, 8125, 5798)  # Dirge Quikcleave
    RegisterStoredNPCText( co.BANK_GREET, 8126, 2138)  # Nixx Sprocketspring
    RegisterStoredNPCText( co.BANK_GREET, 8142, 5717)  # Jannos Lighthoof
    RegisterStoredNPCText( co.BANK_GREET, 8153, 5335)  # Narv Hidecrafter
    RegisterStoredNPCText( co.BANK_GREET, 8356, 3415)  # Chesmu
    RegisterStoredNPCText( co.BANK_GREET, 8380, 2293)  # Captain Vanessa Beltis
    RegisterStoredNPCText( co.BANK_GREET, 8399, 1994)  # Nyrill
    RegisterStoredNPCText( co.BANK_GREET, 8479, 1955)  # Kalaran Windblade
    RegisterStoredNPCText( co.BANK_GREET, 8509, 2279)  # Squire Maltrake
    RegisterStoredNPCText( co.BANK_GREET, 8576, 2033)  # Ag'tor Bloodfist
    RegisterStoredNPCText( co.BANK_GREET, 8579, 2140)  # Yeh'kinya
    RegisterStoredNPCText( co.BANK_GREET, 8587, 2036)  # Jediga
    RegisterStoredNPCText( co.BANK_GREET, 8673, 5516)  # Auctioneer Thathung
    RegisterStoredNPCText( co.BANK_GREET, 8736, 5177)  # Buzzek Bracketswing
    RegisterStoredNPCText( co.BANK_GREET, 8738, 2133)  # Vazario Linkgrease
    RegisterStoredNPCText( co.BANK_GREET, 8962, 2273)  # Hilary
    RegisterStoredNPCText( co.BANK_GREET, 9021, 2482)  # Kharan Mighthammer
    RegisterStoredNPCText( co.BANK_GREET, 9047, 2314)  # Jenal
    RegisterStoredNPCText( co.BANK_GREET, 9076, 2333)  # Ghede
    RegisterStoredNPCText( co.BANK_GREET, 9087, 2353)  # Bashana Runetotem
    RegisterStoredNPCText( co.BANK_GREET, 9117, 2817)  # J.D. Collie
    RegisterStoredNPCText( co.BANK_GREET, 9270, 3096)  # Williden Marshal
    RegisterStoredNPCText( co.BANK_GREET, 9271, 3095)  # Hol'anyee Marshal
    RegisterStoredNPCText( co.BANK_GREET, 9272, 3380)  # Spark Nilminer
    RegisterStoredNPCText( co.BANK_GREET, 9273, 3793)  # Petra Grossen
    RegisterStoredNPCText( co.BANK_GREET, 9298, 4634)  # Donova Snowden
    RegisterStoredNPCText( co.BANK_GREET, 9459, 2494)  # Cyrus Therepentous
    RegisterStoredNPCText( co.BANK_GREET, 9467, 2496)  # Miblon Snarltooth
    RegisterStoredNPCText( co.BANK_GREET, 9528, 3046)  # Arathandris Silversky
    RegisterStoredNPCText( co.BANK_GREET, 9544, 6594)  # Yuka Screwspigot
    RegisterStoredNPCText( co.BANK_GREET, 9558, 2640)  # Grimble
    RegisterStoredNPCText( co.BANK_GREET, 9559, 2641)  # Grizzlowe
    RegisterStoredNPCText( co.BANK_GREET, 9561,  580)  # Jalinda Sprig
    RegisterStoredNPCText( co.BANK_GREET, 9563, 2713)  # Ragged John
    RegisterStoredNPCText( co.BANK_GREET, 9564, 2642)  # Frezza
    RegisterStoredNPCText( co.BANK_GREET, 9566, 2644)  # Zapetta
    RegisterStoredNPCText( co.BANK_GREET, 9598, 2726)  # Arei
    RegisterStoredNPCText( co.BANK_GREET, 9618, 2734)  # Karna Remtravel
    RegisterStoredNPCText( co.BANK_GREET, 9619, 2816)  # Torwa Pathfinder
    RegisterStoredNPCText( co.BANK_GREET, 9620, 4960)  # Dreka'Sur
    RegisterStoredNPCText( co.BANK_GREET, 9836, 2993)  # Mathredis Firestar
    RegisterStoredNPCText( co.BANK_GREET, 9997, 3546)  # Spraggle Frock
    RegisterStoredNPCText( co.BANK_GREET, 10058,  938)  # Greth
    RegisterStoredNPCText( co.BANK_GREET, 10088, 5838)  # Xao'tsu
    RegisterStoredNPCText( co.BANK_GREET, 10136, 3193)  # Chemist Fuely
    RegisterStoredNPCText( co.BANK_GREET, 10182, 6533)  # Rexxar
    RegisterStoredNPCText( co.BANK_GREET, 10219, 5943)  # Gwennyth Bly'Leggonde
    RegisterStoredNPCText( co.BANK_GREET, 10266, 3412)  # Ug'thok
    RegisterStoredNPCText( co.BANK_GREET, 10267, 3296)  # Tinkee Steamboil
    RegisterStoredNPCText( co.BANK_GREET, 10306, 6957)  # Trull Failbane
    RegisterStoredNPCText( co.BANK_GREET, 10307, 3375)  # Witch Doctor Mau'ari
    RegisterStoredNPCText( co.BANK_GREET, 10378, 7315)  # Omusa Thunderhorn
    RegisterStoredNPCText( co.BANK_GREET, 10431, 4841)  # Gregor Greystone
    RegisterStoredNPCText( co.BANK_GREET, 10578, 3795)  # Bom'bay
    RegisterStoredNPCText( co.BANK_GREET, 10637, 3673)  # Malyfous Darkhammer
    RegisterStoredNPCText( co.BANK_GREET, 10667, 3585)  # Chromie
    RegisterStoredNPCText( co.BANK_GREET, 10668, 3558)  # Beaten Corpse
    RegisterStoredNPCText( co.BANK_GREET, 10778, 3668)  # Janice Felstone
    RegisterStoredNPCText( co.BANK_GREET, 10781, 3653)  # Royal Overseer Bauhaus
    RegisterStoredNPCText( co.BANK_GREET, 10782, 3657)  # Royal Factor Bathrilor
    RegisterStoredNPCText( co.BANK_GREET, 10837, 3753)  # High Executor Derrington
    RegisterStoredNPCText( co.BANK_GREET, 10838, 3754)  # Commander Ashlam Valorfist
    RegisterStoredNPCText( co.BANK_GREET, 10839, 4134)  # Argent Officer Garush
    RegisterStoredNPCText( co.BANK_GREET, 10840, 4135)  # Argent Officer Pureheart
    RegisterStoredNPCText( co.BANK_GREET, 10856, 4174)  # Argent Quartermaster Hasana
    RegisterStoredNPCText( co.BANK_GREET, 10857, 4193)  # Argent Quartermaster Lightspark
    RegisterStoredNPCText( co.BANK_GREET, 10879, 6957)  # Harbinger Balthazad
    RegisterStoredNPCText( co.BANK_GREET, 10880, 6957)  # Warcaller Gorlach
    RegisterStoredNPCText( co.BANK_GREET, 10922, 3807)  # Greta Mosshoof
    RegisterStoredNPCText( co.BANK_GREET, 10976,  580)  # Jeziba
    RegisterStoredNPCText( co.BANK_GREET, 10993, 5130)  # Twizwick Sprocketgrind
    RegisterStoredNPCText( co.BANK_GREET, 11016, 3865)  # Captured Arko'narin
    RegisterStoredNPCText( co.BANK_GREET, 11017, 5173)  # Roxxik
    RegisterStoredNPCText( co.BANK_GREET, 11019, 3864)  # Jessir Moonbow
    RegisterStoredNPCText( co.BANK_GREET, 11025, 5133)  # Mukdrak
    RegisterStoredNPCText( co.BANK_GREET, 11029, 5152)  # Trixie Quikswitch
    RegisterStoredNPCText( co.BANK_GREET, 11031, 5162)  # Franklin Lloyd
    RegisterStoredNPCText( co.BANK_GREET, 11035, 4450)  # Betina Bigglezink
    RegisterStoredNPCText( co.BANK_GREET, 11037, 5121)  # Jenna Lemkenilli
    RegisterStoredNPCText( co.BANK_GREET, 11038, 3935)  # Caretaker Alen
    RegisterStoredNPCText( co.BANK_GREET, 11041, 5027)  # Milla Fairancora
    RegisterStoredNPCText( co.BANK_GREET, 11044, 5046)  # Doctor Martin Felben
    RegisterStoredNPCText( co.BANK_GREET, 11047, 5040)  # Kray
    RegisterStoredNPCText( co.BANK_GREET, 11048, 5434)  # Victor Ward
    RegisterStoredNPCText( co.BANK_GREET, 11049, 5556)  # Rhiannon Davis
    RegisterStoredNPCText( co.BANK_GREET, 11050, 5438)  # Trianna
    RegisterStoredNPCText( co.BANK_GREET, 11053, 3996)  # High Priestess MacDonnell
    RegisterStoredNPCText( co.BANK_GREET, 11055, 3939)  # Shadow Priestess Vandis
    RegisterStoredNPCText( co.BANK_GREET, 11056, 3981)  # Alchemist Arbington
    RegisterStoredNPCText( co.BANK_GREET, 11057, 3978)  # Apothecary Dithers
    RegisterStoredNPCText( co.BANK_GREET, 11063, 4716)  # Carlin Redpath
    RegisterStoredNPCText( co.BANK_GREET, 11064, 3873)  # Darrowshire Spirit
    RegisterStoredNPCText( co.BANK_GREET, 11065, 5674)  # Thonys Pillarstone
    RegisterStoredNPCText( co.BANK_GREET, 11067, 5193)  # Malcomb Wynn
    RegisterStoredNPCText( co.BANK_GREET, 11068, 5181)  # Betty Quin
    RegisterStoredNPCText( co.BANK_GREET, 11071, 5196)  # Mot Dawnstrider
    RegisterStoredNPCText( co.BANK_GREET, 11073, 5253)  # Annora
    RegisterStoredNPCText( co.BANK_GREET, 11083, 5274)  # Darianna
    RegisterStoredNPCText( co.BANK_GREET, 11097, 5403)  # Drakk Stonehand
    RegisterStoredNPCText( co.BANK_GREET, 11098, 5407)  # Hahrana Ironhide
    RegisterStoredNPCText( co.BANK_GREET, 11137,  820)  # Xai'ander
    RegisterStoredNPCText( co.BANK_GREET, 11191, 7245)  # Lilith the Lithe
    RegisterStoredNPCText( co.BANK_GREET, 11192, 7243)  # Kilram
    RegisterStoredNPCText( co.BANK_GREET, 11193, 7247)  # Seril Scourgebane
    RegisterStoredNPCText( co.BANK_GREET, 11216, 4041)  # Eva Sarkhoff
    RegisterStoredNPCText( co.BANK_GREET, 11317, 4891)  # Jinar'Zillen
    RegisterStoredNPCText( co.BANK_GREET, 11407, 4443)  # Var'jun
    RegisterStoredNPCText( co.BANK_GREET, 11536, 4213)  # Quartermaster Miranda Breechlock
    RegisterStoredNPCText( co.BANK_GREET, 11554, 4394)  # Grazle
    RegisterStoredNPCText( co.BANK_GREET, 11556, 4396)  # Salfa
    RegisterStoredNPCText( co.BANK_GREET, 11625, 4813)  # Cork Gizelton
    RegisterStoredNPCText( co.BANK_GREET, 11626, 4815)  # Rigger Gizelton
    RegisterStoredNPCText( co.BANK_GREET, 11798, 4916)  # Bunthen Plainswind
    RegisterStoredNPCText( co.BANK_GREET, 11800, 4913)  # Silva Fil'naveth
    RegisterStoredNPCText( co.BANK_GREET, 11801, 6154)  # Rabine Saturna
    RegisterStoredNPCText( co.BANK_GREET, 11820, 6193)  # Locke Okarr
    RegisterStoredNPCText( co.BANK_GREET, 11835, 4474)  # Theodore Griffs
    RegisterStoredNPCText( co.BANK_GREET, 11860, 5443)  # Maggran Earthbinder
    RegisterStoredNPCText( co.BANK_GREET, 11868, 6233)  # Sayoc
    RegisterStoredNPCText( co.BANK_GREET, 11869, 6279)  # Ansekhwa
    RegisterStoredNPCText( co.BANK_GREET, 11872, 4633)  # Myranda the Hag
    RegisterStoredNPCText( co.BANK_GREET, 11939, 6153)  # Umber
    RegisterStoredNPCText( co.BANK_GREET, 11946, 7415)  # Drek'Thar
    RegisterStoredNPCText( co.BANK_GREET, 12031, 4959)  # Mai'Lahii
    RegisterStoredNPCText( co.BANK_GREET, 12032, 6961)  # Lui'Mala
    RegisterStoredNPCText( co.BANK_GREET, 12042, 4783)  # Loganaar
    RegisterStoredNPCText( co.BANK_GREET, 12097, 6257)  # Frostwolf Quartermaster
    RegisterStoredNPCText( co.BANK_GREET, 12136, 4693)  # Snurk Bucksquick
    RegisterStoredNPCText( co.BANK_GREET, 12137, 4694)  # Squibby Overspeck
    RegisterStoredNPCText( co.BANK_GREET, 12238, 6336)  # Zaetar's Spirit
    RegisterStoredNPCText( co.BANK_GREET, 12245, 4857)  # Vendor-Tron 1000
    RegisterStoredNPCText( co.BANK_GREET, 12246, 4856)  # Super-Seller 680
    RegisterStoredNPCText( co.BANK_GREET, 12340, 5212)  # Drulzegar Skraghook
    RegisterStoredNPCText( co.BANK_GREET, 12657, 5481)  # Don Pompa
    RegisterStoredNPCText( co.BANK_GREET, 12696, 5529)  # Senani Thunderheart
    RegisterStoredNPCText( co.BANK_GREET, 12716, 5579)  # Decedra Willham
    RegisterStoredNPCText( co.BANK_GREET, 12736, 5654)  # Je'neu Sancrea
    RegisterStoredNPCText( co.BANK_GREET, 12757, 5613)  # Karang Amakkar
    RegisterStoredNPCText( co.BANK_GREET, 12863, 6033)  # Warsong Runner
    RegisterStoredNPCText( co.BANK_GREET, 12866, 5713)  # Myriam Moonsinger
    RegisterStoredNPCText( co.BANK_GREET, 12867, 6574)  # Kuray'bin
    RegisterStoredNPCText( co.BANK_GREET, 12920, 6413)  # Doctor Gregory Victor
    RegisterStoredNPCText( co.BANK_GREET, 12944, 5834)  # Lokhtos Darkbargainer
    RegisterStoredNPCText( co.BANK_GREET, 12997, 5894)  # Monty
    RegisterStoredNPCText( co.BANK_GREET, 13176, 6066)  # Smith Regzar
    RegisterStoredNPCText( co.BANK_GREET, 13179, 6107)  # Wing Commander Guse
    RegisterStoredNPCText( co.BANK_GREET, 13220, 6155)  # Layo Starstrike
    RegisterStoredNPCText( co.BANK_GREET, 13236, 6093)  # Primalist Thurloga
    RegisterStoredNPCText( co.BANK_GREET, 13278, 6108)  # Duke Hydraxis
    RegisterStoredNPCText( co.BANK_GREET, 13283, 4835)  # Lord Tony Romano
    RegisterStoredNPCText( co.BANK_GREET, 13697, 6575)  # Cavindra
    RegisterStoredNPCText( co.BANK_GREET, 13698, 6334)  # Keeper Marandis
    RegisterStoredNPCText( co.BANK_GREET, 13699, 6335)  # Selendra
    RegisterStoredNPCText( co.BANK_GREET, 13716, 6373)  # Celebras the Redeemed
    RegisterStoredNPCText( co.BANK_GREET, 13717, 6353)  # Centaur Pariah
    RegisterStoredNPCText( co.BANK_GREET, 13776, 7434)  # Corporal Teeka Bloodsnarl
    RegisterStoredNPCText( co.BANK_GREET, 13840, 6475)  # Warmaster Laggrond
    RegisterStoredNPCText( co.BANK_GREET, 14374, 6917)  # Scholar Runethorn
    RegisterStoredNPCText( co.BANK_GREET, 14387, 6933)  # Lothos Riftwaker
    RegisterStoredNPCText( co.BANK_GREET, 14508, 7074)  # Short John Mithril
    RegisterStoredNPCText( co.BANK_GREET, 14527, 7041)  # Simone the Inconspicuous
    RegisterStoredNPCText( co.BANK_GREET, 14531, 7045)  # Artorius the Amiable
    RegisterStoredNPCText( co.BANK_GREET, 14624, 7115)  # Master Smith Burninate
    RegisterStoredNPCText( co.BANK_GREET, 14626, 7120)  # Taskmaster Scrange
    RegisterStoredNPCText( co.BANK_GREET, 14627, 7117)  # Hansel Heavyhands
    RegisterStoredNPCText( co.BANK_GREET, 14628, 7095)  # Evonice Sootsmoker
    RegisterStoredNPCText( co.BANK_GREET, 14634, 7094)  # Lookout Captain Lolo Longstriker
    RegisterStoredNPCText( co.BANK_GREET, 14729, 7189)  # Ralston Farnsley
    RegisterStoredNPCText( co.BANK_GREET, 14731, 7211)  # Lard
    RegisterStoredNPCText( co.BANK_GREET, 14736, 7238)  # Primal Torntusk
    RegisterStoredNPCText( co.BANK_GREET, 14737, 7239)  # Smith Slagtree
    RegisterStoredNPCText( co.BANK_GREET, 14738, 7237)  # Otho Moji'ko
    RegisterStoredNPCText( co.BANK_GREET, 14739, 7240)  # Mystic Yayo'jin
    RegisterStoredNPCText( co.BANK_GREET, 14740, 7241)  # Katoom the Angler
    RegisterStoredNPCText( co.BANK_GREET, 14741, 7242)  # Huntsman Markhor
    RegisterStoredNPCText( co.BANK_GREET, 14742, 7249)  # Zap Farflinger
    RegisterStoredNPCText( co.BANK_GREET, 14743, 7253)  # Jhordy Lapforge
    RegisterStoredNPCText( co.BANK_GREET, 14753, 7295)  # Illiyana Moonblaze
    RegisterStoredNPCText( co.BANK_GREET, 14754, 7294)  # Kelm Hargunth
    RegisterStoredNPCText( co.BANK_GREET, 14757, 7257)  # Elder Torntusk
    RegisterStoredNPCText( co.BANK_GREET,  7953, 4875)  # Xar'Ti/Raptor Riding Trainer
    RegisterStoredNPCText( co.BANK_GREET,  7952, 3896)  # Zjolnir/Raptor Handler

    # ==> Added on 25.10.2005 by <PavkaM>. Sniffed by <TheSelby>, <KrOnOsX>

    RegisterStoredNPCText( co.BANK_GREET, 7714,  825)  # Innkeeper Byula
    RegisterStoredNPCText( co.BANK_GREET, 7744,  823)  # Innkeeper Thulfram
    RegisterStoredNPCText( co.BANK_GREET, 7733, 3566)  # Innkeeper Fizzgrimble
    RegisterStoredNPCText( co.BANK_GREET, 7737, 7212)  # Innkeeper Greul
    RegisterStoredNPCText( co.BANK_GREET, 1464,  823)  # Innkeeper Helbrek
    RegisterStoredNPCText( co.BANK_GREET, 6928,  938)  # Innkeeper Grosk
    RegisterStoredNPCText( co.BANK_GREET, 6929,  938)  # Innkeeper Gryshka
    RegisterStoredNPCText( co.BANK_GREET, 6930, 7210)  # Innkeeper Karakul
    RegisterStoredNPCText( co.BANK_GREET, 6739,  821)  # Innkeeper Bates
    RegisterStoredNPCText( co.BANK_GREET, 6741,  821)  # Innkeeper Norman
    RegisterStoredNPCText( co.BANK_GREET, 6746,  822)  # Innkeeper Pala
    RegisterStoredNPCText( co.BANK_GREET, 6747,  822)  # Innkeeper Kauth
    RegisterStoredNPCText( co.BANK_GREET, 6790,  820)  # Innkeeper Trelayne
    RegisterStoredNPCText( co.BANK_GREET, 6791,  825)  # Innkeeper Wiley
    RegisterStoredNPCText( co.BANK_GREET, 6272,  820)  # Innkeeper Janene
    RegisterStoredNPCText( co.BANK_GREET, 5688,  821)  # Innkeeper Renee
    RegisterStoredNPCText( co.BANK_GREET, 1247, 1853)  # Innkeeper Belm
    RegisterStoredNPCText( co.BANK_GREET, 2352,  820)  # Innkeeper Anderson
    RegisterStoredNPCText( co.BANK_GREET, 2388,  821)  # Innkeeper Shay
    RegisterStoredNPCText( co.BANK_GREET, 3934, 7177)  # Innkeeper Boorand Plainswind
    RegisterStoredNPCText( co.BANK_GREET, 8931,  820)  # Innkeeper Heather
    RegisterStoredNPCText( co.BANK_GREET, 9501,  822)  # Innkeeper Adegwa
    RegisterStoredNPCText( co.BANK_GREET, 11103, 824)  # Innkeeper Lyshaerya
    RegisterStoredNPCText( co.BANK_GREET, 11118, 825)  # Innkeeper Vizzie
    RegisterStoredNPCText( co.BANK_GREET,   295, 820)  # Innkeeper Farley
    RegisterStoredNPCText( co.BANK_GREET,  6740, 820)  # Innkeeper Allison
    RegisterStoredNPCText( co.BANK_GREET, 5943,  7028)  # Rawrk/First Aid Trainer
    RegisterStoredNPCText( co.BANK_GREET, 3143,  3583)  # Gornek
    RegisterStoredNPCText( co.BANK_GREET, 3069,  5285)  # Chaw Stronghide/Journeyman Leatherworker
    RegisterStoredNPCText( co.BANK_GREET, 3067,  7021)  # Pyall Silentstride/Cook
    RegisterStoredNPCText( co.BANK_GREET, 8359,  5497)  # Ahanu/Leather Armor Merchant
    RegisterStoredNPCText( co.BANK_GREET, 2998,  1615)  # Karn Stonehoof/Expert Blacksmith
    RegisterStoredNPCText( co.BANK_GREET, 10278, 3415)  # Thrag Stonehoof/Journeyman Blacksmith
    RegisterStoredNPCText( co.BANK_GREET, 11051, 5428)  # Vhan/Journeyman Tailor
    RegisterStoredNPCText( co.BANK_GREET, 3004,  5551)  # Tepa/Expert Tailor
    RegisterStoredNPCText( co.BANK_GREET, 14728, 7190)  # Rumstag Proudstrider/Horde Cloth Quartermaster
    RegisterStoredNPCText( co.BANK_GREET, 11084, 5340)  # Tarn/Expert Leatherworker
    RegisterStoredNPCText( co.BANK_GREET, 3008,  5291)  # Mak/Journeyman Leatherworker
    RegisterStoredNPCText( co.BANK_GREET, 3026,  7021)  # Aska Mistrunner/Cooking Trainer
    RegisterStoredNPCText( co.BANK_GREET, 3028,  6961)  # Kah Mistrunner/Fishing Trainer
    RegisterStoredNPCText( co.BANK_GREET, 10086, 5838)  # Hesuwa Thunderhorn/Pet Trainer
    RegisterStoredNPCText( co.BANK_GREET, 3039,  4889)  # Holt Thunderhorn/Hunter Trainer
    RegisterStoredNPCText( co.BANK_GREET, 3038,  4867)  # Kary Thunderhorn/Hunter Trainer
    RegisterStoredNPCText( co.BANK_GREET, 3040,  4997)  # Urek Thunderhorn/Hunter Trainer
    RegisterStoredNPCText( co.BANK_GREET, 7427,  7616)  # Taim Ragetotem/Alterac Valley Battlemaster
    RegisterStoredNPCText( co.BANK_GREET, 12198, 7642)  # Martin Lindsey/Arathi Basin Battlemaster
    RegisterStoredNPCText( co.BANK_GREET, 5054,  6513)  # Krumn/Guild Master
    RegisterStoredNPCText( co.BANK_GREET, 11865, 6293)  # Buliwyf Stonehand/Weapon Master
    RegisterStoredNPCText( co.BANK_GREET, 13084, 6293)  # Bixi Wobblebonk/Weapon Master
    RegisterStoredNPCText( co.BANK_GREET, 11866, 6291)  # Ilyenia Moonfire/Weapon Master
    RegisterStoredNPCText( co.BANK_GREET, 11867, 6289)  # Woo Ping/Weapon Master
    RegisterStoredNPCText( co.BANK_GREET,  4588, 5355)  # Arthur Moore/Expert Leatherworker
    RegisterStoredNPCText( co.BANK_GREET,   384, 4859)  # Katie Hunter/Horse Breeder
    RegisterStoredNPCText( co.BANK_GREET,  4732, 4876)  # Randal Hunter/Horse Riding Instructor
    RegisterStoredNPCText( co.BANK_GREET,  1103, 5413)  # Eldrin/Journeyman Tailor
    RegisterStoredNPCText( co.BANK_GREET,  1430, 7021)  # Tomas/Cook
    RegisterStoredNPCText( co.BANK_GREET,  2329, 7028)  # Michelle Belle/Physician
    RegisterStoredNPCText( co.BANK_GREET,   917,  878)  # Keryn Sylvius/Rogue Trainer
    RegisterStoredNPCText( co.BANK_GREET,   514, 3405)  # Smith Argus/Journeyman Blacksmith
    RegisterStoredNPCText( co.BANK_GREET, 14721, 7179)  # Field Marshal Afrasiabi
    RegisterStoredNPCText( co.BANK_GREET, 14394, 6936)  # Major Mattingly
    RegisterStoredNPCText( co.BANK_GREET,  5193, 1259)  # Rebecca Laughlin/Tabard Vendor
    RegisterStoredNPCText( co.BANK_GREET,  4974, 1260)  # Aldwin Laughlin/Guild Master
    RegisterStoredNPCText( co.BANK_GREET,  3518, 1235)  # Thomas Miller/Baker
    RegisterStoredNPCText( co.BANK_GREET,   483, 1235)  # Elaine Trias/Mistress of Cheese
    RegisterStoredNPCText( co.BANK_GREET,  1275, 1236)  # Kyra Boucher/Reagent Vendor
    RegisterStoredNPCText( co.BANK_GREET,  1257, 1235)  # Keldric Boucher/Arcane Goods Vendor
    RegisterStoredNPCText( co.BANK_GREET,  2457, 1250)  # John Burnside/Banker
    RegisterStoredNPCText( co.BANK_GREET,  2456, 1250)  # Newton Burnside/Banker
    RegisterStoredNPCText( co.BANK_GREET,  2455, 1250)  # Olivia Burnside/Banker
    RegisterStoredNPCText( co.BANK_GREET,  1299, 1235)  # Lisbeth Schneider/Clothier
    RegisterStoredNPCText( co.BANK_GREET,  1304, 6936)  # Darian Singh/Fireworks Vendor
    RegisterStoredNPCText( co.BANK_GREET,  1305, 1253)  # Jarel Moor/Bartender
    RegisterStoredNPCText( co.BANK_GREET,  9584, 5919)  # Jalane Ayrole/Master Shadoweave Tailor
    RegisterStoredNPCText( co.BANK_GREET,  6122, 6755)  # Gakin the Darkbinder
    RegisterStoredNPCText( co.BANK_GREET,  1311, 1252)  # Joachim Brenlow/Bartender
    RegisterStoredNPCText( co.BANK_GREET,  5567, 5519)  # Sellandus/Expert Tailor
    RegisterStoredNPCText( co.BANK_GREET,  5566, 1202)  # Tannysa/Herbalism Trainer
    RegisterStoredNPCText( co.BANK_GREET,  1313, 1231)  # Maria Lumere/Alchemy Supplies
    RegisterStoredNPCText( co.BANK_GREET,  5499, 5016)  # Lilyssia Nightbreeze/Expert Alchemist
    RegisterStoredNPCText( co.BANK_GREET,  1350, 1241)  # Theresa Moulaine/Robe Vendor
    RegisterStoredNPCText( co.BANK_GREET,  1349, 1241)  # Agustus Moulaine/Mail Armor Merchant
    RegisterStoredNPCText( co.BANK_GREET,  5514, 1243)  # Brooke Stonebraid/Mining Supplier
    RegisterStoredNPCText( co.BANK_GREET,  5513, 1226)  # Gelman Stonehand/Mining Trainer
    RegisterStoredNPCText( co.BANK_GREET,  7232, 1133)  # Borgus Steelhand/Weapon Crafter
    RegisterStoredNPCText( co.BANK_GREET,  5509, 1243)  # Kathrum Axehand/Axe Merchant
    RegisterStoredNPCText( co.BANK_GREET,  5510, 1243)  # Thulman Flintcrag/Guns Vendor
    RegisterStoredNPCText( co.BANK_GREET, 11026, 5124)  # Sprite Jumpsprocket/Journeyman Engineer
    RegisterStoredNPCText( co.BANK_GREET,  5518, 5147)  # Lilliam Sparkspindle/Expert Engineer
    RegisterStoredNPCText( co.BANK_GREET,  5511, 1118)  # Therum Deepforge/Expert Blacksmith
    RegisterStoredNPCText( co.BANK_GREET,   957, 3406)  # Dane Lindgren/Journeyman Blacksmith
    RegisterStoredNPCText( co.BANK_GREET,  5512, 1243)  # Kaita Deepforge/Blacksmithing Supplies
    RegisterStoredNPCText( co.BANK_GREET,  5174, 5167)  # Springspindle Fizzlegear/Artisan Engineer
    RegisterStoredNPCText( co.BANK_GREET, 11028, 5118)  # Jemma Quikswitch/Journeyman Engineer
    RegisterStoredNPCText( co.BANK_GREET, 14724, 7194)  # Bubulo Acerbus/Alliance Cloth Quartermaster
    RegisterStoredNPCText( co.BANK_GREET,  5177, 5054)  # Tally Berryfizz/Expert Alchemist
    RegisterStoredNPCText( co.BANK_GREET,  1246, 5031)  # Vosur Brakthel/Journeyman Alchemist
    RegisterStoredNPCText( co.BANK_GREET, 14982, 7599)  # Lylandris/Warsong Gulch Battlemaster
    RegisterStoredNPCText( co.BANK_GREET,   857, 7642)  # Donal Osgood/Arathi Basin Battlemaster
    RegisterStoredNPCText( co.BANK_GREET, 15351, 7818)  # Alliance Brigadier General
    RegisterStoredNPCText( co.BANK_GREET, 12197, 7616)  # Glordrum Steelbeard/Alterac Valley Battlemaster
    RegisterStoredNPCText( co.BANK_GREET,  5164, 1135)  # Grumnus Steelshaper/Armor Crafter
    RegisterStoredNPCText( co.BANK_GREET, 11146, 3959)  # Ironus Coldsteel/Special Weapon Crafter
    RegisterStoredNPCText( co.BANK_GREET, 10276, 3456)  # Rotgath Stonebeard/Expert Blacksmith
    RegisterStoredNPCText( co.BANK_GREET, 10277, 3398)  # Groum Stonebeard/Journeyman Blacksmith
    RegisterStoredNPCText( co.BANK_GREET, 11145, 3937)  # Myolor Sunderfury
    RegisterStoredNPCText( co.BANK_GREET,  4258, 1261)  # Bengus Deepforge/Artisan Blacksmith
    RegisterStoredNPCText( co.BANK_GREET,  6286, 2676)  # Zarrin/Cook
    RegisterStoredNPCText( co.BANK_GREET,  3603, 5022)  # Cyndra Kindwhisper/Journeyman Alchemist
    RegisterStoredNPCText( co.BANK_GREET,  4241, 5477)  # Mydrannul/General Goods Vendor

    # ==> Added on 31.10.2005, 01:57 AM by <PavkaM>. Sniffed by <reSpawn>

    RegisterStoredNPCText( co.BANK_GREET,  4605, 3422)  # Basil Frye/Journeyman Blacksmith
    RegisterStoredNPCText( co.BANK_GREET,  2131, 1219)  # Austil de Mon/Warrior Trainer
    RegisterStoredNPCText( co.BANK_GREET, 15195, 7739)  # Wickerman Guardian/
    RegisterStoredNPCText( co.BANK_GREET, 15197, 7740)  # Darkcaller Yanka/
    RegisterStoredNPCText( co.BANK_GREET, 15106, 7683)  # Frostwolf Emissary/
    RegisterStoredNPCText( co.BANK_GREET,   347, 7616)  # Grizzle Halfmane/Alterac Valley Battlemaster
    RegisterStoredNPCText( co.BANK_GREET, 15007, 7642)  # Sir Malory Wheeler/Arathi Basin Battlemaster
    RegisterStoredNPCText( co.BANK_GREET, 11608, 4353)  # Bardu Sharpeye/
    RegisterStoredNPCText( co.BANK_GREET, 11615, 4356)  # Mickey Levine/
    RegisterStoredNPCText( co.BANK_GREET,  8403, 3666)  # Jeremiah Payson/Cockroach Vendor
    RegisterStoredNPCText( co.BANK_GREET, 11870, 6286)  # Archibald/Weapon Master
    RegisterStoredNPCText( co.BANK_GREET, 2804,  7655)  # Kurden Bloodclaw/Warsong Gulch Battlemaster

def InitializeRefuseNPCTextTable():
    # ==> Added on 25.10.2005 by <PavkaM>. Sniffed by <TheSelby>, <KrOnOsX>
    
    RegisterStoredNPCText( co.BANK_REFUSE,  3620,  5839)  # Harruk/Pet Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3170,  4793)  # Kaplak/Rogue Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3171,  4888)  # Thotar/Hunter Trainer
    RegisterStoredNPCText( co.BANK_REFUSE, 10578,  3794)  # Bom'bay/Witch Doctor in Training
    RegisterStoredNPCText( co.BANK_REFUSE,  5880,   565)  # Un'Thuwa/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3154,  5004)  # Jen'shan/Hunter Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5884,   565)  # Mai'ah/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3157,  5006)  # Shikrik/Shaman Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3707,  4440)  # Ken'jai/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3156,  5715)  # Nartok/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  12776, 5836)  # Hraug/Demon Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3062,  5006)  # Meela Dawnstrider/Shaman Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3060,  5717)  # Gart Mistrunner/Druid Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3059,  4973)  # Harutt Thunderhorn/Warrior Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3064,  4785)  # Gennia Runetotem/Druid Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3066,  5006)  # Narm Skychaser/Shaman Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3033,  3033)  # Turak Runetotem/Druid Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3034,  5717)  # Sheal Runetotem/Druid Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3036,  5717)  # Kym Wildmane/Druid Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3030,  5006)  # Siln Skychaser/Shaman Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3032,  5006)  # Beram Skychaser/Shaman Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3031,  5006)  # Tigor Skychaser/Shaman Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3045,  4439)  # Malakai Cross/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5957,  5882)  # Birgitte Cranston/Portal Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3049,   563)  # Thurston Xane/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3047,   563)  # Archmage Shymm/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3044,  4439)  # Miles Welsh/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3048,   563)  # Ursyn Ghull/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3706,  4440)  # Tai'jin/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3173,  5006)  # Swart/Shaman Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3155,  4793)  # Rwag/Rogue Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3042,  4973)  # Sark Ragetotem/Warrior Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  3041,  4973)  # Torm Ragetotem/Warrior Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2126,  5720)  # Maximillion/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5749,  5836)  # Kayla Smithe/Demon Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2124,   563)  # Isabella/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2123,  4439)  # Dark Cleric Duesten/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4582,  4796)  # Carolyn Ward/Rogue Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4583,  4796)  # Miles Dexter/Rogue Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4584,  4796)  # Gregory Charles/Rogue Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2492,  5885)  # Lexington Mortaim/Portal Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4607,  4439)  # Father Lankester/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  6374,  5836)  # Cylina Darkheart/Demon Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,   328,   539)  # Zaldimar Wefhellt/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,   377,  4434)  # Priestess Josetta/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5496,  5722)  # Sandahl/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,   461,  5722)  # Demisette Cloyce/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5520,  5836)  # Spackle Thornberry/Demon Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5495,  5722)  # Ursula Deline/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5489,  4434)  # Brother Joshua/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,   376,  4434)  # High Priestess Laurena/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5492,  3977)  # Katherine the Pure/Paladin Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,   928,  3977)  # Lord Grayson Shadowbreaker/Paladin Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5491,  3977)  # Arthur the Faithful/Paladin Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5484,  4434)  # Brother Benjamin/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5117,  5000)  # Regnus Thundergranite/Hunter Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5116,  5000)  # Olmin Burningbeard/Hunter Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  10090, 5839)  # Belia Thundergranite/Pet Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5113,  5724)  # Kelv Sternhammer/Warrior Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5114,  4988)  # Bilban Tosslespanner/Warrior Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  1901,  5724)  # Kelstrum Stonebreaker/Warrior Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,   906,  5722)  # Maximillian Crowe/Warlock Trainer

    # ==> Added on 31.10.2005, 01:57 AM by <PavkaM>. Sniffed by <reSpawn>

    RegisterStoredNPCText( co.BANK_REFUSE,  4616,  5228)  # Lavinia Crowe/Expert Enchanter
    RegisterStoredNPCText( co.BANK_REFUSE,  4596,  3479)  # James Van Brunt/Expert Blacksmith
#    RegisterStoredNPCText( co.BANK_REFUSE, 11031,  5162)  # Franklin Lloyd/Expert Engineer
    RegisterStoredNPCText( co.BANK_REFUSE,  4568,   563)  # Anastasia Hartwell/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4566,   563)  # Kaelystia Hatebringer/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4567,   563)  # Pierce Shackleton/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4564,  5720)  # Luther Pickman/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4563,  5715)  # Kaal Soulreaper/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5753,  5836)  # Martha Strain/Demon Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4606,  4439)  # Aelthalyste/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4608,  4439)  # Father Lazarus/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  4611,  5099)  # Doctor Herbert Halsey/Artisan Alchemist
    RegisterStoredNPCText( co.BANK_REFUSE,  2128,   563)  # Cain Firesong/Mage Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2127,  5720)  # Rupert Boch/Warlock Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  5750,  5836)  # Gina Lang/Demon Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2129,  4439)  # Dark Cleric Beryl/Priest Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2130,  4796)  # Marion Call/Rogue Trainer
    RegisterStoredNPCText( co.BANK_REFUSE,  2122,  4796)  # David Trias/Rogue Trainer

def InitializeTextTable():
    # ==> Added on 25.10.2005 by <PavkaM>. Sniffed by <TheSelby>, <KrOnOsX>

    RegisterStoredText( co.BANK_TEXT_TRADE,  6746,  "Let me browse your goods.")  # Innkeeper Pala/Innkeeper
    RegisterStoredText( co.BANK_TEXT_TRADE,  8359,  "Let me browse your goods.")  # Ahanu/Leather Armor Merchant
    RegisterStoredText( co.BANK_TEXT_TRADE,  4556,  "Let me browse your goods.")  # Gordon Wendham/Weapons Merchant
    RegisterStoredText( co.BANK_TEXT_TRADE,  4241,  "Let me browse your goods.")  # Mydrannul/General Goods Vendor
    RegisterStoredText( co.BANK_TEXT_TRAIN,  10086, "Train me in the ways of the beast.")  # Hesuwa Thunderhorn/Pet Trainer
    RegisterStoredText( co.BANK_TEXT_TRAIN,  3039,  "I wish to train.")  # Holt Thunderhorn/Hunter Trainer
    RegisterStoredText( co.BANK_TEXT_TRAIN,  3038,  "I am in need of training.")  # Kary Thunderhorn/Hunter Trainer
    RegisterStoredText( co.BANK_TEXT_TRAIN,   917,  "I am in need of training, Keryn.")  # Keryn Sylvius/Rogue Trainer
    RegisterStoredText( co.BANK_TEXT_TRAIN,  6286,  "I'd like to train in cooking.")  # Zarrin/Cook


def InitializeInfoNPCTextTable():
    # ==> Added on 25.10.2005 by <PavkaM>. Sniffed by <TheSelby>, <KrOnOsX>

    RegisterStoredNPCText( co.BANK_INFO, 11869,  6281)  # Ansekhwa/Weapon Master
    RegisterStoredNPCText( co.BANK_INFO, 13084,  6296)  # Bixi Wobblebonk/Weapon Master
    RegisterStoredNPCText( co.BANK_INFO, 11865,  6294)  # Buliwyf Stonehand/Weapon Master
    RegisterStoredNPCText( co.BANK_INFO,  2704,  6277)  # Hanashi/Weapon Master
    RegisterStoredNPCText( co.BANK_INFO, 11866,  6292)  # Ilyenia Moonfire/Weapon Master
    RegisterStoredNPCText( co.BANK_INFO, 11868,  6235)  # Sayoc/Weapon Master
    RegisterStoredNPCText( co.BANK_INFO, 11867,  6290)  # Woo Ping/Weapon Master

    # ==> Added on 31.10.2005, 01:57 AM by <PavkaM>. Sniffed by <reSpawn>

    RegisterStoredNPCText( co.BANK_INFO, 11870,  6287)  # Archibald/Weapon Master
