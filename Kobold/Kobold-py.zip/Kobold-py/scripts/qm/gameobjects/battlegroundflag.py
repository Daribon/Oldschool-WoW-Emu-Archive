from Ludmilla import *          # Import server environment
from random import *            # Randomiser Import
import config as cfg            # Import of configuration constants
reload(cfg)  
import consts as co             # Import of constants
reload(co)   
import const_skills as skill_co # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co # Import of constants (skills)
reload(spell_co)  
import player_class as player_cls
reload(player_cls) 

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

def OnGOSelect (gameobject, player):

    entry_id = gameobject.GetEntry()
    player_side = player_cls.GetPlayerSide(player)

    print "OnGOSelect: %s go_entry[%d]" % (player.GetName(), entry_id)
    
    if gameobject.GetName() != "Silverwing Flag" and gameobject.GetName() != "Warsong Flag": return
    
    #spell_to_cast = gameobject.GetDataField(1) 
    
    if   entry_id == co.BATTLEGROUND_ALLIANCE_FLAG: CLICK_ALLIANCE_FLAG (gameobject, player)
    elif entry_id == co.BATTLEGROUND_HORDE_FLAG:    CLICK_HORDE_FLAG    (gameobject, player)
    
    elif entry_id == co.BATTLEGROUND_ALLIANCE_FLAG_DROP: 
        
        if player_side == co.SIDE_ALLIANCE:
            player.CastSpell( player, spell_co.SPELL_ID_ALLIANCE_FLAG_RETURNS_EVENT )
            gameobject.Die() # delete this flag
            player.ModifyFlagReturnCount(1) # add flag returns count to player
            
        if player_side == co.SIDE_HORDE:
            CLICK_ALLIANCE_FLAG(gameobject, player)
        
    elif entry_id == co.BATTLEGROUND_HORDE_FLAG_DROP:    
        
        if player_side == co.SIDE_HORDE:
            player.CastSpell( player, spell_co.SPELL_ID_HORDE_FLAG_RETURNS_EVENT )
            gameobject.Die() # delete this flag
            player.ModifyFlagReturnCount(1) # add flag returns count to player
        
        if player_side == co.SIDE_ALLIANCE:
            CLICK_HORDE_FLAG(gameobject, player)

def CLICK_ALLIANCE_FLAG(gameobject, player):
    gameobject.CreateDelayedSpellCast(player, player, spell_co.SPELL_ID_ALLIANCE_FLAG_CLICK)
    
def CLICK_HORDE_FLAG(gameobject, player):
    gameobject.CreateDelayedSpellCast(player, player, spell_co.SPELL_ID_HORDE_FLAG_CLICK)
    
#-- EOF --