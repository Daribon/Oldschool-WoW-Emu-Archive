#
# Bluffwatcher Module
#
# Author: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "The bank"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "The wind rider master" , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "The guild master"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "The inn"               , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "The mailbox"           , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "The auction house"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "The weapon master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
    player.AddGossipItem( 0, "The stable master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
    player.AddGossipItem( 0, "The battlemaster"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
    player.AddGossipItem( 0, "A class trainer"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
    player.AddGossipItem( 0, "A profession trainer"  , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
    player.SendGossipMenu(self, 3543)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -1257.80004882812, 24.1431007385254, 6, 0, "Thunder Bluff Bank")
        player.SendGossipMenu(self, 1292)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -1196.43994140625, 28.2653999328613, 6, 0, "Wind Rider Roost")
        player.SendGossipMenu(self, 1293)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -1296.5, 127.579002380371, 6, 0, "Thunder Bluff Civic Information")
        player.SendGossipMenu(self, 1291)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -1296.06994628906, 39.7075004577637, 6, 0, "Thunder Bluff Inn")
        player.SendGossipMenu(self, 3153)

		
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -1263.59997558594, 44.3600997924805, 6, 0, "Thunder Bluff Mailbox")
        player.SendGossipMenu(self, 3154)


    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(29, 1381.77001953125, -4371.16015625, 5, 3, "Orgrimmar")
        player.SendGossipMenu(self, 3155)


    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -1282.31005859375, 89.5630035400391, 6, 0, "Ansekhwa")
        player.SendGossipMenu(self, 4520)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -1270.19995117188, 48.8459014892578, 6, 0, "Bulrug")
        player.SendGossipMenu(self, 5977)
        

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.AddGossipItem( 0, "Alterac Valley"       , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Arathi Basin"         , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Warsong Gulch"        , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 3)       
        player.SendGossipMenu(self, 7527)    


    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.AddGossipItem( 0, "Duid"                 , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Hunter"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Mage"                 , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Priest"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Shaman"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Warrior"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.SendGossipMenu(self, 3542)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Mining"               , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.SendGossipMenu(self, 3541)



def SendBattleMasterMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -1387.82995605469, -97.5561981201172, 6, 0, "Taim Ragetotem")
        player.SendGossipMenu(self, 7522)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -997.004028320312, 214.128997802734, 6, 0, "Martin Lindsey")
        player.SendGossipMenu(self, 7648)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -1384.94995117188, -75.9151000976563, 6, 0, "Kergul Bloodaxe")
        player.SendGossipMenu(self, 7523)



def SendClassTrainerMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -1054.47998046875, -285.075988769531, 6, 0, "Hall of Elders")
        player.SendGossipMenu(self, 1294)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -1416.32995605469, -114.285003662109, 6, 0, "Hunter's Hall")
        player.SendGossipMenu(self, 1295)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -1061.2099609375, 195.505004882813, 6, 0, "Pools of Vision")
        player.SendGossipMenu(self, 1296)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -1061.2099609375, 195.505004882813, 6, 0, "Pools of Vision")
        player.SendGossipMenu(self, 1297)

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -989.541015625, 278.252990722656, 6, 0, "Hall of Spirits")
        player.SendGossipMenu(self, 1298)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -1416.32995605469, -114.285003662109, 6, 0, "Hunter's Hall")
        player.SendGossipMenu(self, 1299)



    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -1085.56994628906, 27.2931003570557, 6, 0, "Bena's Alchemy")
        player.SendGossipMenu(self, 1332)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -1239.75, 104.888000488281, 6, 0, "Karn's Smithy")
        player.SendGossipMenu(self, 1333)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -1214.5, -21.2327003479004, 6, 0, "Aska's Kitchen")
        player.SendGossipMenu(self, 1334)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -1112.65002441406, 48.2608985900879, 6, 0, "Dawnstrider Enchanters")
        player.SendGossipMenu(self, 1335)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -996.585998535156, 200.503997802734, 6, 0, "Spiritual Healing")
        player.SendGossipMenu(self, 1336)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -1169.35998535156, -68.8779983520508, 6, 0, "Mountaintop Bait & Tackle")
        player.SendGossipMenu(self, 1337)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -1137.7099609375, -1.51698005199432, 6, 0, "Holistic Herbalism")
        player.SendGossipMenu(self, 1338)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -1156.22998046875, 66.8664016723633, 6, 0, "Thunder Bluff Armorers")
        player.SendGossipMenu(self, 1339)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, -1249.17004394531, 155.02799987793, 6, 0, "Stonehoof Geology")
        player.SendGossipMenu(self, 1340)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, -1148.56994628906, 51.1842002868652, 6, 0, "Mooranta")
        player.SendGossipMenu(self, 1343)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendPOI(63, -1156.22998046875, 66.8664016723633, 6, 0, "Thunder Bluff Armorers")
        player.SendGossipMenu(self, 1341)         
 


def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)        
        
    if sender == co.GOSSIP_SENDER_SEC_BATTLEINFO:
        SendBattleMasterMenu(self, player, action)
