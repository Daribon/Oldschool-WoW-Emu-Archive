#
# Stormwind City Guardian Module
#
# Author: <Thoz>
# Mod and repair : <Belfedia>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "Auction House"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "Bank"                 , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
    player.AddGossipItem( 0, "Gryphon master"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)    
    player.AddGossipItem( 0, "Guild master"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "Inn"                  , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "Stable master"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "Weapons Trainer"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
    player.AddGossipItem( 0, "Class trainer"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
    player.AddGossipItem( 0, "Profession trainer"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
    player.AddGossipItem( 0, "Battlemaster"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 10)

    player.SendGossipMenu(self, 2593)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
	player.SendPOI(63, -8818.65, 664.20, 6, 0, "Stormwind Auction House")
        player.SendGossipMenu(self, 3834)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -8916.87, 622.87, 6, 0, "Stormwind Counting House")
        player.SendGossipMenu(self, 764)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -8837.0, 493.5, 6, 0, "Dungar Longdrink")
        player.SendGossipMenu(self, 879)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -8894.0, 611.2, 6, 0, "Aldwin Laughlin")
        player.SendGossipMenu(self, 882)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -8869.0, 675.4, 6, 0, "The Gilded Rose")
        player.SendGossipMenu(self, 3860)

		
    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -8433.0, 554.7, 6, 0, "Jenova Stoneshield")
        player.SendGossipMenu(self, 5984)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -8797.0, 612.8, 6, 0, "Woo Ping")
        player.SendGossipMenu(self, 4516)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.AddGossipItem( 0, "Druid"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Hunter"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Mage"                 , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Paladin"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Priest"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Rogue"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Warlock"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Warrior"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)        
        
        player.SendGossipMenu(self, 4264)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Engineering"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Mining"               , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
        
        player.SendGossipMenu(self, 4273)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.AddGossipItem( 0, "Arathi Basin"     , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Warsong Gulch"    , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 2)       

        player.SendGossipMenu(self, 7529)  

def SendClassTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -8742.0, 1095.4, 6, 0, "Theridran")
        player.SendPOI(63, -8751.0, 1124.5, 6, 0, "Maldryn")
        player.SendGossipMenu(self, 902)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -8413.0, 541.5, 6, 0, "Thorfin Stoneshield")
        player.SendGossipMenu(self, 905)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -9012.0, 867.6, 6, 0, "Maginor Dumas")
        player.SendGossipMenu(self, 899)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -8577.0, 881.7, 6, 0, "Lord Grayson Shawdowbreaker")
        player.SendGossipMenu(self, 904)

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -8512.0, 862.4, 6, 0, "High Priestess Laurena")
        player.SendGossipMenu(self, 903)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -8753.0, 367.8, 6, 0, "Osborne the Night Man")
        player.SendGossipMenu(self, 900)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -8948.91, 998.35, 6, 0, "The Slaughtered Lamb")
        player.SendGossipMenu(self, 906)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -8624.54, 402.61, 6, 0, "Pig and Whistle")
        player.SendGossipMenu(self, 901)

    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -8988.0, 759.60, 6, 0, "Alchemy Needs")
        player.SendGossipMenu(self, 919)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -8424.0, 616.9, 6, 0, "Therum Deepforge")
        player.SendGossipMenu(self, 920)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -8611.0, 364.6, 6, 0, "Stephen Ryback")
        player.SendGossipMenu(self, 921)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -8858.0, 803.7, 6, 0, "Lucan Cordell")
        player.SendGossipMenu(self, 941)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -8347.0, 644.1, 6, 0, "Lilliam Sparkspindle")
        player.SendGossipMenu(self, 922)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -8513.0, 801.8, 6, 0, "Shaina Fuller")
        player.SendGossipMenu(self, 923)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -8803.0, 767.5, 6, 0, "Arnold Leland")
        player.SendGossipMenu(self, 940)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -8967.0, 779.5, 6, 0, "Tannysa")
        player.SendGossipMenu(self, 924)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, -8726.0, 477.4, 6, 0, "Simon Tanner")
        player.SendGossipMenu(self, 925)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, -8434.0, 692.8, 6, 0, "Gelman Stonehand")
        player.SendGossipMenu(self, 927)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendPOI(63, -8716.0, 469.4, 6, 0, "Maris Granger")
        player.SendGossipMenu(self, 928)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.SendPOI(63, -8938.0, 800.7, 6, 0, "Georgio Bolero")
        player.SendGossipMenu(self, 929)
    
def SendBattleMasterMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -8420.40, 328.70, 6, 0, "Dame Hotshem")
        player.SendGossipMenu(self, 7649)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -8454.00, 318.90, 6, 0, "Elfarran")
        player.SendGossipMenu(self, 7528)

def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_BATTLEINFO:
        SendBattleMasterMenu(self, player, action)
        
        
