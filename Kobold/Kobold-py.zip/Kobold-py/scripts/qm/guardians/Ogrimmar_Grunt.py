#
# Orgrimar Grunt Module
#
# Author: <PavkaM>
# Rewritten: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "The bank"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "The wind rider master" , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "The guild master"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "The inn"               , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "The mailbox"           , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "The auction house"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "The zeppelin master"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
    player.AddGossipItem( 0, "The weapon master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
    player.AddGossipItem( 0, "The stable master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
    player.AddGossipItem( 0, "The Officers Lounge"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
    player.AddGossipItem( 0, "The battlemaster"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
    player.AddGossipItem( 0, "A class trainer"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
    player.AddGossipItem( 0, "A profession trainer"  , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 13)
    player.SendGossipMenu(self, 2593)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 1631.51000976562, -4375.330078125, 6, 0, "Bank of Orgrimmar")
        player.SendGossipMenu(self, 2554)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 1676.60998535156, -4332.72021484375, 6, 0, "The Sky Tower")
        player.SendGossipMenu(self, 2555)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1576.93005371094, -4294.75, 6, 0, "Horde Embassy")
        player.SendGossipMenu(self, 2556)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 1644.51000976562, -4447.27978515625, 6, 0, "Orgrimmar Inn")
        player.SendGossipMenu(self, 2557)

		
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 1622.53002929687, -4388.7998046875, 6, 0, "Orgrimmar Mailbox")
        player.SendGossipMenu(self, 2558)


    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 1679.21997070313, -4450.10986328125, 6, 0, "Orgrimmar Auction House")
        player.SendGossipMenu(self, 3075)


    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 1337.36999511719, -4632.7001953125, 6, 0, "Orgrimmar Zeppelin Tower")
        player.SendGossipMenu(self, 3173)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, 2092.56005859375, -4823.9501953125, 6, 0, "Sayoc & Hanashi")
        player.SendGossipMenu(self, 4519)


    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, 2133.1201171875, -4663.93017578125, 6, 0, "Xon'cha")
        player.SendGossipMenu(self, 5974)


    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, 1633.56005859375, -4249.3701171875, 6, 0, "Hall of Legends")
        player.SendGossipMenu(self, 7046)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.AddGossipItem( 0, "Alterac Valley"       , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Arathi Basin"         , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Warsong Gulch"        , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 3)       
        player.SendGossipMenu(self, 7521)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.AddGossipItem( 0, "Hunter"     , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Mage"       , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Priest"     , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Shaman"     , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Rogue"      , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Warlock"    , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Warrior"    , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.SendGossipMenu(self, 2599)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 13 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Engineering"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Mining"               , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
        player.SendGossipMenu(self, 2594)



def SendBattleMasterMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 1983.92004394531, -4794.2099609375, 6, 0, "Hall of the Brave")
        player.SendGossipMenu(self, 7484)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 1983.92004394531, -4794.2099609375, 6, 0, "Hall of the Brave")
        player.SendGossipMenu(self, 7644)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1983.92004394531, -4794.2099609375, 6, 0, "Hall of the Brave")
        player.SendGossipMenu(self, 7520)

        
def SendClassTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 2114.84008789062, -4625.31982421875, 6, 0, "Orgrimmar Hunter's Hall")
        player.SendGossipMenu(self, 2559)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 1451.26000976562, -4223.330078125, 6, 0, "Darkbriar Lodge")
        player.SendGossipMenu(self, 2560)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1442.21997070313, -4183.240234375, 6, 0, "Spirit Lodge")
        player.SendGossipMenu(self, 2561)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 1925.34997558594, -4181.89013671875, 6, 0, "Thrall's Fortress")
        player.SendGossipMenu(self, 2562)

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 1773.39001464844, -4278.97021484375, 6, 0, "Shadowswift Brotherhood")
        player.SendGossipMenu(self, 2563)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 1849.57995605469, -4359.68994140625, 6, 0, "Darkfire Enclave")
        player.SendGossipMenu(self, 2564)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 1983.92004394531, -4794.2099609375, 6, 0, "Hall of the Brave")
        player.SendGossipMenu(self, 2565)

    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 1955.17004394531, -4475.7998046875, 6, 0, "Yelmak's Alchemy and Potions")
        player.SendGossipMenu(self, 2497)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 2054.34008789062, -4831.85009765625, 6, 0, "The Burning Anvil")
        player.SendGossipMenu(self, 2499)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1780.96997070313, -4481.31005859375, 6, 0, "Borstan's Firepit")
        player.SendGossipMenu(self, 2500)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 1917.5, -4434.9501953125, 6, 0, "Godan's Runeworks")
        player.SendGossipMenu(self, 2501)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 2038.4599609375, -4744.759765625, 6, 0, "Nogg's Machine Shop")
        player.SendGossipMenu(self, 2653)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 1485.21997070313, -4160.91015625, 6, 0, "Survival of the Fittest")
        player.SendGossipMenu(self, 2502)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 1994.15002441406, -4655.7001953125, 6, 0, "Lumak's Fishing")
        player.SendGossipMenu(self, 2503)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, 1898.61999511719, -4454.93994140625, 6, 0, "Jandi's Arboretum")
        player.SendGossipMenu(self, 2504)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, 1852.82995605469, -4562.31982421875, 6, 0, "Kodohide Leatherworkers")
        player.SendGossipMenu(self, 2513)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, 2029.7900390625, -4704.080078125, 6, 0, "Red Canyon Mining")
        player.SendGossipMenu(self, 2515)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendPOI(63, 1852.82995605469, -4562.31982421875, 6, 0, "Kodohide Leatherworkers")
        player.SendGossipMenu(self, 2516)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.SendPOI(63, 1802.66003417969, -4560.66015625, 6, 0, "Magar's Cloth Goods")
        player.SendGossipMenu(self, 2518)  

def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)

    if sender == co.GOSSIP_SENDER_SEC_BATTLEINFO:
        SendBattleMasterMenu(self, player, action)
