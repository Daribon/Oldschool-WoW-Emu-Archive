#
# Darnasus Sentinel Module
#
# Author: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "Auction House"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "The Bank"             , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "Hippogryph Master"    , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "Guild Master"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "The Inn"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "Mailbox"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "Stable Master"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
    player.AddGossipItem( 0, "Weapons Trainer"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
    player.AddGossipItem( 0, "Battlemaster"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
    player.AddGossipItem( 0, "Class Trainer"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
    player.AddGossipItem( 0, "Profession Trainer"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 11)    
    player.SendGossipMenu(self, 3016)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendGossipMenu(self, 3833)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 9938.45, 2512.35, 6, 0, "Darnassus Bank")
        player.SendGossipMenu(self, 3017)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 9945.65, 2618.94, 6, 0, "Rut'theran Village")
        player.SendGossipMenu(self, 3018)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 10076.40, 2199.59, 6, 0, "Darnassus Guild Master")
        player.SendGossipMenu(self, 3019)

		
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 10133.29, 2222.52, 6, 0, "Darnassus Inn")
        player.SendGossipMenu(self, 3020)


    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 9942.17, 2495.48, 6, 0, "Darnassus Mailbox")
        player.SendGossipMenu(self, 3021)


    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 10167.20, 2522.66, 6, 0, "Alassin")
        player.SendGossipMenu(self, 5980)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, 9907.11, 2329.70, 6, 0, "Ilyenia Moonfire")
        player.SendGossipMenu(self, 4517)


    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.AddGossipItem( 0, "Alterac Valley"   , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Arathi Basin"     , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Warsong Gulch"    , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 3)       
        
        player.SendGossipMenu(self, 7519)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.AddGossipItem( 0, "Druid"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Hunter"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Priest"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Rogue"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Warrior"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)        
        
        player.SendGossipMenu(self, 4264)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        
        player.SendGossipMenu(self, 4273)


def SendBattleMasterMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 9923.61, 2327.43, 6, 0, "Brogun Stoneshield")
        player.SendGossipMenu(self, 7518)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 9977.37, 2324.39, 6, 0, "Keras Wolfheart")
        player.SendGossipMenu(self, 7651)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 9979.84, 2315.79, 6, 0, "Aethalas")
        player.SendGossipMenu(self, 7482)


    
def SendClassTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 10186, 2570.46, 6, 0, "Darnassus Druid Trainer")
        player.SendGossipMenu(self, 3024)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 10177.29, 2511.10, 6, 0, "Darnassus Hunter Trainer")
        player.SendGossipMenu(self, 3023)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 9659.12, 2524.88, 6, 0, "Temple of the Moon")
        player.SendGossipMenu(self, 3025)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 10122, 2599.12, 6, 0, "Darnassus Rogue Trainer")
        player.SendGossipMenu(self, 3026)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 9951.91, 2280.38, 6, 0, "Warrior's Terrace")
        player.SendGossipMenu(self, 3033)



    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 10075.90, 2356.76, 6, 0, "Darnassus Alchemy Trainer")
        player.SendGossipMenu(self, 3035)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 10088.59, 2419.21, 6, 0, "Darnassus Cooking Trainer")
        player.SendGossipMenu(self, 3036)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 10146.09, 2313.42, 6, 0, "Darnassus Enchanting Trainer")
        player.SendGossipMenu(self, 3337)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 10150.09, 2390.43, 6, 0, "Darnassus First Aid Trainer")
        player.SendGossipMenu(self, 3037)     

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 9836.20, 2432.17, 6, 0, "Darnassus Fishing Trainer")
        player.SendGossipMenu(self, 3038)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 9757.17, 2430.16, 6, 0, "Darnassus Herbalism Trainer")
        player.SendGossipMenu(self, 3039)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 10086.59, 2255.77, 6, 0, "Darnassus Leatherworking Trainer")
        player.SendGossipMenu(self, 3040)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, 10081.40, 2257.18, 6, 0, "Darnassus Skinning Trainer")
        player.SendGossipMenu(self, 3042)

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, 10079.70, 2268.19, 6, 0, "Darnassus Tailor")
        player.SendGossipMenu(self, 3044)



def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)

    if sender == co.GOSSIP_SENDER_SEC_BATTLEINFO:
        SendBattleMasterMenu(self, player, action)
        
