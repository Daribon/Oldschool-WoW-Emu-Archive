#
# Undercity_Guardian Module
#
# Author: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "The bank"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "The bat handler"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "The guild master"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "The inn"               , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "The mailbox"           , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "The auction house"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "The zeppelin master"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
    player.AddGossipItem( 0, "The weapon master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
    player.AddGossipItem( 0, "The stable master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
    player.AddGossipItem( 0, "The battlemaster"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
    player.AddGossipItem( 0, "A class trainer"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
    player.AddGossipItem( 0, "A profession trainer"  , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
    player.SendGossipMenu(self, 3543)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 1595.64001464844, 232.455993652344, 6, 0, "Undercity Bank")
        player.SendGossipMenu(self, 3514)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 1565.90002441406, 271.434997558594, 6, 0, "Undercity Bat Handler")
        player.SendGossipMenu(self, 3515)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1594.17004394531, 205.572006225586, 6, 0, "Undercity Guild Master")
        player.SendGossipMenu(self, 3516)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 1639.43005371094, 220.998001098633, 6, 0, "Undercity Inn")
        player.SendGossipMenu(self, 3517)

		
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 1632.68994140625, 219.40299987793, 6, 0, "Undercity Mailbox")
        player.SendGossipMenu(self, 3518)


    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 2059.0400390625, 274.868988037109, 6, 0, "Undercity Zeppelin")
        player.SendGossipMenu(self, 3519)


    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendGossipMenu(self, 3520)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, 1670.31005859375, 324.665985107422, 6, 0, "Archibald")
        player.SendGossipMenu(self, 4521)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, 1634.18005371094, 226.768005371094, 6, 0, "Anya Maulray")
        player.SendGossipMenu(self, 5979)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.AddGossipItem( 0, "Alterac Valley"   , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Arathi Basin"     , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Warsong Gulch"    , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 3)       
        player.SendGossipMenu(self, 7527)    


    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.AddGossipItem( 0, "Mage"     , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Priest"       , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Rogue"     , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Warlock"     , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Warrior"      , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.SendGossipMenu(self, 3542)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Engineering"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Mining"               , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
        player.SendGossipMenu(self, 3541)


def SendBattleMasterMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 1329.05004882812, 333.920013427734, 6, 0, "Grizzle Halfmane")
        player.SendGossipMenu(self, 7525)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 1283.30004882812, 287.160003662109, 6, 0, "Sir Malory Wheeler")
        player.SendGossipMenu(self, 7646)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1265.09997558594, 351.182006835937, 6, 0, "Kurden Bloodclaw")
        player.SendGossipMenu(self, 7526)



def SendClassTrainerMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 1781.08996582031, 53.0096015930176, 6, 0, "Undercity Mage Trainers")
        player.SendGossipMenu(self, 3513)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 1758.33996582031, 401.506988525391, 6, 0, "Undercity Priest Trainers")
        player.SendGossipMenu(self, 3521)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1418.56005859375, 65.024299621582, 6, 0, "Undercity Rogue Trainers")
        player.SendGossipMenu(self, 3526)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 1780.92004394531, 53.1697006225586, 6, 0, "Undercity Warlock Trainers")
        player.SendGossipMenu(self, 3526)

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 1775.59997558594, 418.192993164063, 6, 0, "Undercity Warrior Trainers")
        player.SendGossipMenu(self, 3527)
    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 1419.82995605469, 417.196990966797, 6, 0, "The Apothecarium")
        player.SendGossipMenu(self, 3528)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 1696, 285.0419921875, 6, 0, "Undercity Blacksmithing Trainer")
        player.SendGossipMenu(self, 3529)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 1596.34997558594, 274.683990478516, 6, 0, "Undercity Cooking Trainer")
        player.SendGossipMenu(self, 3530)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 1488.5400390625, 280.194000244141, 6, 0, "Undercity Enchanting Trainer")
        player.SendGossipMenu(self, 3531)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 1408.58996582031, 143.430999755859, 6, 0, "Undercity Engineering Trainer")
        player.SendGossipMenu(self, 3532)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 1519.65002441406, 167.199005126953, 6, 0, "Undercity First Aid Trainer")
        player.SendGossipMenu(self, 3533)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 1679.90002441406, 89.0226974487305, 6, 0, "Undercity Fishing Trainer")
        player.SendGossipMenu(self, 3534)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, 1558.08996582031, 349.369995117188, 6, 0, "Undercity Herbalism Trainer")
        player.SendGossipMenu(self, 3535)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, 1498.76000976562, 196.432998657227, 6, 0, "Undercity Leatherworking Trainer")
        player.SendGossipMenu(self, 3536)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, 1642.88000488281, 335.588012695313, 6, 0, "Undercity Mining Trainer")
        player.SendGossipMenu(self, 3537)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendPOI(63, 1498.60998535156, 196.466003417969, 6, 0, "Undercity Skinning Trainer")
        player.SendGossipMenu(self, 3538)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.SendPOI(63, 1689.55004882813, 193.022994995117, 6, 0, "Undercity Tailoring Trainer")
        player.SendGossipMenu(self, 3539)  

def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)        
        
    if sender == co.GOSSIP_SENDER_SEC_BATTLEINFO:
        SendBattleMasterMenu(self, player, action)
