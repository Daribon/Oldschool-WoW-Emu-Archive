#
# Stormwind Guardian Module
#
# Author: <TheSelby>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "Bank"                 , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "Gryphon master"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "Guild master"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "Inn"                  , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "Stable master"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "Class trainer"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "Profession trainer"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
    
    player.SendGossipMenu(self, 2593)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendGossipMenu(self, 4260)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendGossipMenu(self, 4261)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendGossipMenu(self, 4262)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -9459.34, 42.08, 6, 0, "Lion's Pride Inn")
        player.SendGossipMenu(self, 4263)

		
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -9466.62, 45.87, 6, 0, "Erma")
        player.SendGossipMenu(self, 5983)


    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.AddGossipItem( 0, "Druid"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Hunter"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Mage"                 , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Paladin"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Priest"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Rogue"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Warlock"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Warrior"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)        
        
        player.SendGossipMenu(self, 4264)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Engineering"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Mining"               , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
        
        player.SendGossipMenu(self, 4273)


def SendClassTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendGossipMenu(self, 4265)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendGossipMenu(self, 4266)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -9471.12, 33.44, 6, 0, "Zaldimar Wefhellt")
        player.SendGossipMenu(self, 4268)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -9469, 108.05, 6, 0, "Brother Wilhelm")
        player.SendGossipMenu(self, 4269)

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -9461.07, 32.99, 6, 0, "Priestess Josetta")
        player.SendGossipMenu(self, 4267)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -9465.13, 13.29, 6, 0, "Keryn Sylvius")
        player.SendGossipMenu(self, 4270)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -9473.21, -4.08, 6, 0, "Maximillian Crowe")
        player.SendGossipMenu(self, 4272)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -9461.82, 109.50, 6, 0, "Lyria Du Lac")
        player.SendGossipMenu(self, 4271)

    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -9057.04, 153.63, 6, 0, "Alchemist Mallory")
        player.SendGossipMenu(self, 4274)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -9456.58, 87.90, 6, 0, "Smith Argus")
        player.SendGossipMenu(self, 4275)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -9467.54, -3.16, 6, 0, "Tomas")
        player.SendGossipMenu(self, 4276)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendGossipMenu(self, 4277)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendGossipMenu(self, 4278)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -9456.82, 30.49, 6, 0, "Michelle Belle")
        player.SendGossipMenu(self, 4279)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -9386.54, -118.73, 6, 0, "Lee Brown")
        player.SendGossipMenu(self, 4280)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -9060.70, 149.23, 6, 0, "Herbalist Pomeroy")
        player.SendGossipMenu(self, 4281)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, -9376.12, -75.23, 6, 0, "Adele Fielder")
        player.SendGossipMenu(self, 4282)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, -9381.12, -70.11, 6, 0, "Helene Peltskinner")
        player.SendGossipMenu(self, 4283)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendPOI(63, -9536.91, -1212.76, 6, 0, "Eldrin")
        player.SendGossipMenu(self, 4284)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.SendPOI(63, -9376.12, -75.23, 6, 0, "Adele Fielder")
        player.SendGossipMenu(self, 4285)  

def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)        
        
