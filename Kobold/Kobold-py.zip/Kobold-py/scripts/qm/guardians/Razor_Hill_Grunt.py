#
# Razor Hill Grunt Module
#
# Author: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "The bank"                 , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "The wind rider master"    , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "The inn"                  , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "The stable master"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "A class trainer"          , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "A profession trainer"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.SendGossipMenu(self, 4037)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendGossipMenu(self, 4032)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendGossipMenu(self, 4033)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 338.709014892578, -4688.8701171875, 6, 0, "Razor Hill Inn")
        player.SendGossipMenu(self, 4034)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 330.31298828125, -4710.669921875, 6, 0, "Shoja'my")
        player.SendGossipMenu(self, 5973)

       
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.AddGossipItem( 0, "Hunter"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Mage"                 , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Priest"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Rogue"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Shaman"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Warlock"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Warrior"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.SendGossipMenu(self, 4035)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Engineering"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Mining"               , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
        player.SendGossipMenu(self, 4036)



def SendClassTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 276.066986083984, -4706.72998046875, 6, 0, "Thotar")
        player.SendGossipMenu(self, 4013)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -839.330017089844, -4935.60986328125, 6, 0, "Un'Thuwa")
        player.SendGossipMenu(self, 4014)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 296.225006103516, -4828.10986328125, 6, 0, "Tai'jin")
        player.SendGossipMenu(self, 4015)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 265.765014648438, -4709.009765625, 6, 0, "Kaplak")
        player.SendGossipMenu(self, 4016)

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 307.796997070313, -4836.97021484375, 6, 0, "Swart")
        player.SendGossipMenu(self, 4017)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 355.880004882812, -4836.4599609375, 6, 0, "Dhugru Gorelust")
        player.SendGossipMenu(self, 4018)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 312.308013916016, -4824.66015625, 6, 0, "Tarshaw Jaggedscar")
        player.SendGossipMenu(self, 4019)

    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -800.252990722656, -4894.33984375, 6, 0, "Miao'zan")
        player.SendGossipMenu(self, 4020)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 373.247985839844, -4716.4501953125, 6, 0, "Dwukk")
        player.SendGossipMenu(self, 4021)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendGossipMenu(self, 4022)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendGossipMenu(self, 4023)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 368.959991455078, -4723.9599609375, 6, 0, "Mukdrak")
        player.SendGossipMenu(self, 4024)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 327.174987792969, -4825.6201171875, 6, 0, "Rawrk")
        player.SendGossipMenu(self, 4025)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -1065.48999023438, -4777.43017578125, 6, 0, "Lau'Tiki")
        player.SendGossipMenu(self, 4026)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -836.254028320312, -4896.89990234375, 6, 0, "Mishiki")
        player.SendGossipMenu(self, 4027)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendGossipMenu(self, 4028)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, 366.941009521484, -4705.08984375, 6, 0, "Krunn")
        player.SendGossipMenu(self, 4029)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendGossipMenu(self, 4030)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.SendGossipMenu(self, 4031)  

def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)
