#
# Teldrassil Sentinel Module
#
# Author: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "The Bank"             , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "Rut'theran Ferry"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "The Guild Master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "The Inn"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "Stable Master"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "Class Trainer"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "Profession Trainer"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)   
    player.SendGossipMenu(self, 4316)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendGossipMenu(self, 4317)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendGossipMenu(self, 4318)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendGossipMenu(self, 4319)

        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 9821.490234375, 960.138000488281, 6, 0, "Dolanaar Inn")
        player.SendGossipMenu(self, 4320)

		
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 9808.3701171875, 931.106018066406, 6, 0, "Seriadne")
        player.SendGossipMenu(self, 5982)


    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.AddGossipItem( 0, "Druid"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Hunter"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Priest"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Rogue"                , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Warrior"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)        
        
        player.SendGossipMenu(self, 4264)        


    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        
        player.SendGossipMenu(self, 4273)


def SendClassTrainerMenu (self, player, action):


    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 9741.580078125, 963.705017089844, 6, 0, "Kal")
        player.SendGossipMenu(self, 4323)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 9815.1201171875, 926.283020019531, 6, 0, "Dazalar")
        player.SendGossipMenu(self, 4324)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 9906.16015625, 986.635986328125, 6, 0, "Laurna Morninglight")
        player.SendGossipMenu(self, 4325)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 9789.01953125, 942.864990234375, 6, 0, "Jannok Breezesong")
        player.SendGossipMenu(self, 4326)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 9821.9697265625, 950.616027832031, 6, 0, "Kyra Windblade")
        player.SendGossipMenu(self, 4327)



    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, 9767.599609375, 878.817016601562, 6, 0, "Cyndra Kindwhisper")
        player.SendGossipMenu(self, 4329)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, 9751.1904296875, 906.132019042969, 6, 0, "Zarrin")
        player.SendGossipMenu(self, 4330)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, 10677.599609375, 1946.56005859375, 6, 0, "Alanna Raveneye")
        player.SendGossipMenu(self, 4331)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, 9903.1201171875, 999.094970703125, 6, 0, "Byancie")
        player.SendGossipMenu(self, 4332) 

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, 9821.9697265625, 950.616027832031, 6, 0, "Kyra Windblade")
        player.SendGossipMenu(self, 4333)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, 9773.7802734375, 875.883972167969, 6, 0, "Malorne Bladeleaf")
        player.SendGossipMenu(self, 4334)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, 10152.599609375, 1681.46997070313, 6, 0, "Nadyia Maneweaver")
        player.SendGossipMenu(self, 4335)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, 10135.599609375, 1673.18005371094, 6, 0, "Radnaal Maneweaver")
        player.SendGossipMenu(self, 4336)

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendGossipMenu(self, 4337)


def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)
        
