#
# Bluffwatcher Module
#
# Author: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "The bank"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "The wind rider master" , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "The inn"               , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "The stable master"     , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "A class trainer"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "A profession trainer"  , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.SendGossipMenu(self, 3543)

    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendGossipMenu(self, 4051)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendGossipMenu(self, 4052)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -2361.38989257813, -349.192993164063, 6, 0, "Bloodhoof Village Inn")
        player.SendGossipMenu(self, 4053)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -2338.86010742187, -357.563995361328, 6, 0, "Seikwa")
        player.SendGossipMenu(self, 5976)

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.AddGossipItem( 0, "Duid"                 , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Hunter"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Shaman"               , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Warrior"              , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.SendGossipMenu(self, 4069)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.AddGossipItem( 0, "Alchemy"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "First Aid"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Fishing"              , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Herbalism"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Leatherworking"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Mining"               , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Skinning"             , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Tailoring"            , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.SendGossipMenu(self, 3541)



def SendClassTrainerMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -2312.15991210938, -443.692993164063, 6, 0, "Gennia Runetotem")
        player.SendGossipMenu(self, 4054)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -2178.14990234375, -406.144012451172, 6, 0, "Yaw Sharpmane")
        player.SendGossipMenu(self, 4055)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -2301.5, -439.871002197266, 6, 0, "Narm Skychaser")
        player.SendGossipMenu(self, 4056)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -2345.43994140625, -494.114013671875, 6, 0, "Krang Stonehoof")
        player.SendGossipMenu(self, 4057)


    
def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendGossipMenu(self, 4058)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendGossipMenu(self, 4059)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -2263.34008789062, -287.910003662109, 6, 0, "Pyall Silentstride")
        player.SendGossipMenu(self, 4060)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendGossipMenu(self, 4061)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -2353.52001953125, -355.821014404297, 6, 0, "Vira Younghoof")
        player.SendGossipMenu(self, 4062)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -2349.21997070313, -241.376007080078, 6, 0, "Uthan Stillwater")
        player.SendGossipMenu(self, 4063)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendGossipMenu(self, 4064)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -2257.1201171875, -288.632995605469, 6, 0, "Chaw Stronghide")
        player.SendGossipMenu(self, 4065)         

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendGossipMenu(self, 4066)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, -2252.94995117187, -291.324005126953, 6, 0, "Yonn Deepcut")
        player.SendGossipMenu(self, 4067)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendGossipMenu(self, 4068)         
 


def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)        

