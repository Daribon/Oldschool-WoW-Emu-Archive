#
# Ironforge Guard Module
#
# Author: <KrOnOs>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):

    player.AddGossipItem( 0, "Auction House"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
    player.AddGossipItem( 0, "Bank of Ironforge"    , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 2)    
    player.AddGossipItem( 0, "Deeprun Tram"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
    player.AddGossipItem( 0, "Gryphon Master"       , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
    player.AddGossipItem( 0, "Guild Master"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
    player.AddGossipItem( 0, "The Inn"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
    player.AddGossipItem( 0, "Mailbox"              , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
    player.AddGossipItem( 0, "Stable Master"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
    player.AddGossipItem( 0, "Weapons Trainer"      , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
    player.AddGossipItem( 0, "Battlemaster"         , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
    player.AddGossipItem( 0, "Class Trainer"        , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
    player.AddGossipItem( 0, "Profession Trainer"   , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
    player.SendGossipMenu(self, 2760)
    
#######################################################################
#                         Menu Functions                              #
#######################################################################

def SendDefaultMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -4957.39013671875, -911.60400390625, 6, 0, "Ironforge Auction House")
        player.SendGossipMenu(self, 3014)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -4891.91015625, -991.47998046875, 6, 0, "The Vault")
        player.SendGossipMenu(self, 2761)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -4835.27978515625, -1294.69995117188, 6, 0, "Deeprun Tram")
        player.SendGossipMenu(self, 3814)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -4821.52001953125, -1152.30004882812, 6, 0, "Ironforge Gryphon Master")
        player.SendGossipMenu(self, 2762)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -5021.06005859375, -996.453002929688, 6, 0, "Ironforge Visitor's Center")
        player.SendGossipMenu(self, 2764)
		
    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -4850.47998046875, -872.570983886719, 6, 0, "Stonefire Tavern")
        player.SendGossipMenu(self, 2768)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -4845.7001953125, -880.552001953125, 6, 0, "Ironforge Mailbox")
        player.SendGossipMenu(self, 2769)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -5010.2099609375, -1262.03002929688, 6, 0, "Ulbrek Firehand")
        player.SendGossipMenu(self, 5986)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, -5040.009765625, -1201.88000488281, 6, 0, "Bixi and Buliwyf")
        player.SendGossipMenu(self, 4518)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.AddGossipItem( 0, "Alterac Valley"   , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Arathi Basin"     , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Warsong Gulch"    , co.GOSSIP_SENDER_SEC_BATTLEINFO, co.GOSSIP_ACTION_INFO_DEF + 3)       
        player.SendGossipMenu(self, 7529)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.AddGossipItem( 0, "Hunter"           , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Mage"             , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Paladin"          , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Rogue"            , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Warlock"          , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "Warrior"          , co.GOSSIP_SENDER_SEC_CLASSTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6) 
        player.SendGossipMenu(self, 2766)        

    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.AddGossipItem( 0, "Alchemy"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 1)
        player.AddGossipItem( 0, "Blacksmithing"    , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 2)
        player.AddGossipItem( 0, "Cooking"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 3)
        player.AddGossipItem( 0, "Enchanting"       , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 4)
        player.AddGossipItem( 0, "Engineering"      , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 5)
        player.AddGossipItem( 0, "First Aid"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 6)
        player.AddGossipItem( 0, "Fishing"          , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 7)
        player.AddGossipItem( 0, "Herbalism"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 8)
        player.AddGossipItem( 0, "Leatherworking"   , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 9)
        player.AddGossipItem( 0, "Mining"           , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 10)
        player.AddGossipItem( 0, "Skinning"         , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 11)
        player.AddGossipItem( 0, "Tailoring"        , co.GOSSIP_SENDER_SEC_PROFTRAIN, co.GOSSIP_ACTION_INFO_DEF + 12)
        player.SendGossipMenu(self, 2793)



def SendBattleMasterMenu (self, player, action):
    
    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -5047.8798828125, -1263.77001953125, 6, 0, "Glordrum Steelbeard")
        player.SendGossipMenu(self, 7483)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -5038.3701171875, -1266.39001464844, 6, 0, "Donal Osgood")
        player.SendGossipMenu(self, 7649)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -5037.240234375, -1274.82995605469, 6, 0, "Lylandris")
        player.SendGossipMenu(self, 7528)


    
def SendClassTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -5023.080078125, -1253.68005371094, 6, 0, "Hall of Arms")
        player.SendGossipMenu(self, 2770)

    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -4627.02001953125, -926.458984375, 6, 0, "Hall of Mysteries")
        player.SendGossipMenu(self, 2771)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -4627.02001953125, -926.458984375, 6, 0, "Hall of Mysteries")
        player.SendGossipMenu(self, 2773)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -4627.02001953125, -926.458984375, 6, 0, "Hall of Mysteries")
        player.SendGossipMenu(self, 2772)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -4647.830078125, -1124, 6, 0, "Ironforge Rogue Trainer")
        player.SendGossipMenu(self, 2774)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -4605.02978515625, -1110.4599609375, 6, 0, "Ironforge Warlock Trainer")
        player.SendGossipMenu(self, 2775)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -5023.080078125, -1253.68005371094, 6, 0, "Hall of Arms")
        player.SendGossipMenu(self, 2776)



def SendProfTrainerMenu (self, player, action):

    if action == co.GOSSIP_ACTION_INFO_DEF + 1 :
        player.SendPOI(63, -4858.5, -1241.83996582031, 6, 0, "Berryfizz's Potions and Mixed Drinks")
        player.SendGossipMenu(self, 2794)
        
    if action == co.GOSSIP_ACTION_INFO_DEF + 2 :
        player.SendPOI(63, -4796.97998046875, -1110.17004394531, 6, 0, "The Great Forge")
        player.SendGossipMenu(self, 2795)

    if action == co.GOSSIP_ACTION_INFO_DEF + 3 :
        player.SendPOI(63, -4767.830078125, -1184.59997558594, 6, 0, "The Bronze Kettle")
        player.SendGossipMenu(self, 2796)

    if action == co.GOSSIP_ACTION_INFO_DEF + 4 :
        player.SendPOI(63, -4803.72021484375, -1196.53002929688, 6, 0, "Thistlefuzz Arcanery")
        player.SendGossipMenu(self, 2797)     

    if action == co.GOSSIP_ACTION_INFO_DEF + 5 :
        player.SendPOI(63, -4799.56005859375, -1250.23999023438, 6, 0, "Springspindle's Gadgets")
        player.SendGossipMenu(self, 2798)

    if action == co.GOSSIP_ACTION_INFO_DEF + 6 :
        player.SendPOI(63, -4881.60009765625, -1153.13000488281, 6, 0, "Ironforge Physician")
        player.SendGossipMenu(self, 2799)

    if action == co.GOSSIP_ACTION_INFO_DEF + 7 :
        player.SendPOI(63, -4597.91015625, -1091.93005371094, 6, 0, "Traveling Fisherman")
        player.SendGossipMenu(self, 2800)

    if action == co.GOSSIP_ACTION_INFO_DEF + 8 :
        player.SendPOI(63, -4881.60009765625, -1153.13000488281, 6, 0, "Ironforge Physician")
        player.SendGossipMenu(self, 2801)

    if action == co.GOSSIP_ACTION_INFO_DEF + 9 :
        player.SendPOI(63, -4745.009765625, -1027.57995605469, 6, 0, "Finespindle's Leather Goods")
        player.SendGossipMenu(self, 2802)

    if action == co.GOSSIP_ACTION_INFO_DEF + 10 :
        player.SendPOI(63, -4705.06005859375, -1116.43005371094, 6, 0, "Deepmountain Mining Guild")
        player.SendGossipMenu(self, 2804)

    if action == co.GOSSIP_ACTION_INFO_DEF + 11 :
        player.SendPOI(63, -4745.009765625, -1027.57995605469, 6, 0, "Finespindle's Leather Goods")
        player.SendGossipMenu(self, 2805)

    if action == co.GOSSIP_ACTION_INFO_DEF + 12 :
        player.SendPOI(63, -4719.60986328125, -1056.96997070312, 6, 0, "Stonebrow's Clothier")
        player.SendGossipMenu(self, 2807)
        


def OnGossipSelect (self, player, sender, action):

    # Serving default/main menu
    if sender == co.GOSSIP_SENDER_MAIN:
        SendDefaultMenu(self, player, action)

    # Came from the second menu already    
    if sender == co.GOSSIP_SENDER_SEC_CLASSTRAIN:
        SendClassTrainerMenu(self, player, action)
        
    if sender == co.GOSSIP_SENDER_SEC_PROFTRAIN:
        SendProfTrainerMenu(self, player, action)

    if sender == co.GOSSIP_SENDER_SEC_BATTLEINFO:
        SendBattleMasterMenu(self, player, action)
        
