from Ludmilla import *          # Import server environment
from random import *            # Randomiser Import
import config as cfg            # Import of configuration constants
reload(cfg)  
import consts as co             # Import of constants
reload(co)   
import const_skills as skill_co # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co # Import of constants (skills)
reload(spell_co)  
import player_class as player_cls
reload(player_cls) 

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

# -----------------------------------------------------------------------------------------------------
def OnAreaTrigger (player, trigger_id, questid):

    print "OnAreaTrigger: player[%s] trigger[%d]" % (player.GetName(), trigger_id)

    ALLIANCE_FLAG_STAND_TRIGGER = 3646
    HORDE_FLAG_STAND_TRIGGER    = 3647

    if trigger_id == ALLIANCE_FLAG_STAND_TRIGGER and player.HasAffect( spell_co.SPELL_ID_HORDE_FLAG ): EVENT_ALLIANCE_CAPTURE_FLAG( player )
    if trigger_id == HORDE_FLAG_STAND_TRIGGER and player.HasAffect( spell_co.SPELL_ID_ALLIANCE_FLAG ): EVENT_HORDE_CAPTURE_FLAG( player )

# -----------------------------------------------------------------------------------------------------
def EVENT_ALLIANCE_CAPTURE_FLAG(player):
    if player.GetFlagTakenEvent(): return # we check if other tema has taken our flag too
    print "EVENT_ALLIANCE_CAPTURE_FLAG: player[%s]" % (player.GetName())
    player.CastSpell( player, spell_co.SPELL_ID_HORDE_FLAG_CAPTURE )
    
# -----------------------------------------------------------------------------------------------------
def EVENT_HORDE_CAPTURE_FLAG(player):
    if player.GetFlagTakenEvent(): return # we check if other tema has taken our flag too
    print "EVENT_HORDE_CAPTURE_FLAG: player[%s]" % (player.GetName())
    player.CastSpell( player, spell_co.SPELL_ID_ALLIANCE_FLAG_CAPTURE )
    
# -- EOF --