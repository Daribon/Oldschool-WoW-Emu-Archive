#
# Helper Functions to be generally used
#
# Author: <PavkaM>

from Ludmilla import *
from random import *
import consts as co
reload(co)

def HasTalents (player):
    # Will check if the player has some talents learned
    # Not yet implemented someone has to add all spells here
    #
    return 0

def UnlearnTalents (player):
    # Should unlearn all player's talents
    return

def GetTradeSkillLevel(player, trskill):
    # Returns the level of some tradeskill known by player
    # Need to add missing spells

    spell_apprentice = 0
    spell_journeyman = 0
    spell_expert     = 0
    spell_artisan    = 0

    if trskill == co.TRADESKILL_ALCHEMY:
        spell_apprentice = 2259
        spell_journeyman = 3101
        spell_expert     = 3464
        spell_artisan    = 11611

    elif trskill == co.TRADESKILL_BLACKSMITHING:
        spell_apprentice = 2018
        spell_journeyman = 3100
        spell_expert     = 3538
        spell_artisan    = 9785

    elif trskill == co.TRADESKILL_COOKING:
        spell_apprentice = 2550
        spell_journeyman = 3102
        spell_expert     = 3413
        spell_artisan    = 18260
       
    elif trskill == co.TRADESKILL_ENCHANTING:
        spell_apprentice = 7411
        spell_journeyman = 7412
        spell_expert     = 7413
        spell_artisan    = 13920

    elif trskill == co.TRADESKILL_ENGINEERING:
        spell_apprentice = 4036
        spell_journeyman = 4037
        spell_expert     = 4038
        spell_artisan    = 12656

    elif trskill == co.TRADESKILL_FIRSTAID:
        spell_apprentice = 3273
        spell_journeyman = 3274
        spell_expert     = 7924
        spell_artisan    = 10846
       
    elif trskill == co.TRADESKILL_HERBALISM:
        spell_apprentice = 2372
        spell_journeyman = 2373
        spell_expert     = 3571
        spell_artisan    = 11994
       
    elif trskill == co.TRADESKILL_LEATHERWORKING:
        spell_apprentice = 2108
        spell_journeyman = 3104
        spell_expert     = 20649
        spell_artisan    = 10662

    elif trskill == co.TRADESKILL_POISONS:
        spell_apprentice = 0
        spell_journeyman = 0
        spell_expert     = 0
        spell_artisan    = 0
       
    elif trskill == co.TRADESKILL_TAILORING:
        spell_apprentice = 3908
        spell_journeyman = 3909
        spell_expert     = 3910
        spell_artisan    = 12180

    elif trskill == co.TRADESKILL_MINING:
        spell_apprentice = 2575
        spell_journeyman = 2576
        spell_expert     = 3564
        spell_artisan    = 10248
       
    elif trskill == co.TRADESKILL_FISHING:
        spell_apprentice = 7620
        spell_journeyman = 7731
        spell_expert     = 7732
        spell_artisan    = 18248
       
    elif trskill == co.TRADESKILL_SKINNING:
        spell_apprentice = 8613
        spell_journeyman = 8617
        spell_expert     = 8618
        spell_artisan    = 10768
       
    if player.HasSpell(spell_artisan):
        return co.TRADESKILL_LEVEL_ARTISAN

    elif player.HasSpell(spell_expert):
        return co.TRADESKILL_LEVEL_EXPERT

    elif player.HasSpell(spell_journeyman):
        return co.TRADESKILL_LEVEL_JOURNEYMAN

    elif player.HasSpell(spell_apprentice):
        return co.TRADESKILL_LEVEL_APPRENTICE

    return co.TRADESKILL_LEVEL_NONE
