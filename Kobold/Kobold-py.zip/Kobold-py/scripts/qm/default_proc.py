#
# Default Gossip/Item/GO/AreTrigger Processor. This is the basic point
# of all QM System. We will edit and improve this file as 80% of all interaction
# in game is standartized.
#
# Author: <PavkaM>

from Ludmilla import *
from def_funcs import *
from random import *

import executables as _executables_
reload(_executables_)
import packet_class as packet_builder         # Import of supporting functions
reload(packet_builder)  

import consts as co             # Import of constants
reload(co)

import config as cfg            # Import of configuration constants
reload(cfg)  

#######################################################################################
#                  Default Processor for NPC(Gossip) Behaviour.                       #
#######################################################################################

def OnHello (self, player):
    guild = self.GetGuild()

    
    if self.IsQuestGiver() :
        player.AddNPCQuests( self ) # Adds quests to menu, if there are quests

    if self.HasSellTables() :
        player.AddGossipItem( 1, "You want to trade with me?", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_TRADE)
        
    if self.IsTrainer() :
        player.AddGossipItem( 1, "You need some training?", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_TRAIN)
        if self.GetClass() == player.GetClass() :
            player.AddGossipItem( 1, "You want to unlearn your talents?" , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INFO_DEF)
                
    if self.IsTaxi() :
        player.AddGossipItem( 2, "Do you need a ride?", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_TAXI)

    if guild == "Guild Master" :
        player.AddGossipItem( 7, "You want to form a guild?" , co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_GUILD)

    if guild.endswith ("Battlemaster") :
       player.AddGossipItem( 4, "So, you want to join a Battleground?", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_BATTLE)

    if guild == "Banker" :
       player.AddGossipItem( 5, "Do you want to transfer some goods?", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_BANK)

    if guild == "Innkeeper":
       player.AddGossipItem( 6, "Make this inn your home", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INN)
       player.AddGossipItem( 0, "What can you do at an inn ?", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_INN_INFO)

    if self.GetName() == "Spirit Healer" :
        player.AddGossipItem( 7, "Do you want me to bring you back to life?", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_HEAL)

    if guild.endswith ("Tabard Designer") or guild.endswith ("Tabard Vendor") :
        player.AddGossipItem( 8, "I'll show you some nice designs", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_TABARD)

    if guild == "Auctioneer" :
        player.AddGossipItem( 2, "Auction!", co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_AUCTION)

    player.SendGossipMenu(self, co.DEFAULT_GOSSIP_MESSAGE)
    
# -------------------------------------------

def OnGossipSelect (self, player, sender, action):

    # Serve default menus
    if action == co.GOSSIP_ACTION_TRADE :
        player.SendVendorList(self)
        
    if action == co.GOSSIP_ACTION_TRAIN :
        player.SendTrainerList(self)
         
    if action == co.GOSSIP_ACTION_TAXI :
        player.SendTaxiList(self)
        
    if action == co.GOSSIP_ACTION_GUILD :
        player.SendGuildManager(self)
        
    if action == co.GOSSIP_ACTION_BATTLE :
        player.SendBattleFieldsList(self)
        
    if action == co.GOSSIP_ACTION_BANK :
        player.SendBankManager(self)
        
    if action == co.GOSSIP_ACTION_INN :
        player.SetBindPoint(self)
        
    if action == co.GOSSIP_ACTION_HEAL :
        player.Resurrect(self)
        
    if action == co.GOSSIP_ACTION_TABARD :
        player.SendTabardList(self)
        
    if action == co.GOSSIP_ACTION_AUCTION :
        player.SendAuctionsList(self)
        
    if action == co.GOSSIP_ACTION_INFO_DEF :
        player.AddGossipItem( 0, "Yes. I do.", co.GOSSIP_SENDER_INFO, co.GOSSIP_ACTION_UNLEARN)
        player.SendGossipMenu(self, 5673)
        
    if action == co.GOSSIP_ACTION_UNLEARN :
        player.ResetPlTalents(self)
        
    if action == co.GOSSIP_ACTION_INN_INFO :
        player.AddGossipItem( 4, "Make this inn your home.", co.GOSSIP_SENDER_INN_INFO, co.GOSSIP_ACTION_INN)
        player.SendGossipMenu(self, 1853) # Default inn info

# ------------------------------------------

def OnGossipSelectCode (self, player, sender, action, code):
    # no default handler for this ...
    return

# -------------------------------------------
    
def OnQuestAccept (self, player, questid):
    # no default handler for this ...
    return
# ------------------------------------------

def OnQuestSelect (self, player, questid):
    # We will complete the quest, or send the details for this quest if incomplete
    if player.CanCompleteQuest( self, questid):
        player.SendQuestReward(self, questid)
    if CanStartRepCheck( player, questid):
        player.SendQuestDetails( self, questid )
    else:
        packet = packet_builder.make_SMSG_AREA_TRIGGER_MESSAGE(0, "You do not meet the reputation requirements %s" % player.GetName())
        packet.Send(player)
 # ------------------------------------------

def OnQuestComplete (self, player, questid):
    # We will complete the quest, or send the details for this quest if incomplete
    if player.CanCompleteQuest( self, questid):
        player.SendQuestReward(self, questid)
    else:
        player.SendQuestDetails( self, questid )
# ------------------------------------------

def OnChooseReward (self, player, questid, rewardid):
    if cfg.PLAYER_REP_FIX:
        # UPDATE REPUTATION ############################
        _executables_.CalcQuestReputation(self, player, questid )
    
    # will send following gossip, or close if no follow-up found
    FollowUpQuest = player.GetFollowingQuest(self, questid)
    if FollowUpQuest != 0 and CanStartRepCheck( player, questid):
        player.SendQuestDetails(self, FollowUpQuest)
    else :
        player.CloseGossipWindow()

# ------------------------------------------

def OnDialogStatus (self, player):
    # Let's see if this NPC has some "jobs" besides quest-giving

    DefStatus = co.DIALOG_STATUS_NONE

    if self.IsVendor() or \
       self.IsTrainer() or \
       self.IsTaxi() or \
       self.IsGuildMaster() or \
       self.IsBattleMaster() or \
       self.IsBanker() or \
       self.IsInnkeeper() or \
       self.IsSpiritHealer() or \
       self.IsTabardVendor() or \
       self.IsAuctioner() : DefStatus = co.DIALOG_STATUS_CHAT

    # Now, if NPC has some other "jobs" we will have a chat by default, if
    # the quests don't have something special to say.

    FinalStatus = player.NPCQuestDialogStatus( self, DefStatus )
        # Let's get the final Dialog status depending on "jobs" and quests.

    return FinalStatus

# --------------------------------------





#######################################################################################
#                  Default Processor for Item Behaviour.                              #
#######################################################################################


def OnItemQuestSelect (itemguid_lo, itemguid_hi, player, questid):
    # We will check if the user can take the following quest
    # checks include race/class/prereqs and etc.

    if player.CanTakeQuest(questid) :
        player.SendQuestDetails(itemguid_lo, itemguid_hi, questid)


# --------------------------------------


def OnItemQuestAccept (itemguid_lo, itemguid_hi, player, questid):
    # no default handler required ...
    return


# -------------------------------------------



#######################################################################################
#                  Default Processor for GO Behaviour.                                #
#######################################################################################


def OnGOSelect (gameobject, player):
    # Default internal hadler. You rarely will need to use
    # another handler.

    player.ManageGOQuests(gameobject);


# --------------------------------------

def OnGOQuestAccept (gameobject, player, questid):
    # no default handler required ...
    return

# -------------------------------------------

def OnGOChooseReward (gameobject, player, questid, rewardid):
    # no default handler required ...
    return

# -------------------------------------------


    
#######################################################################################
#                  Default Processor for AreaTrigger Behaviour.                       #
#######################################################################################


def OnAreaTrigger (player, triggerid, questid):
    #
    # Simply complete the exploration objective
    # if the trigger point is a Quest one.
    #
    
    if questid != 0 :
        if player.HasQuest(questid) :
            player.FinishExplorationObjective(questid)

        
# --------------------------------------

#######################################################################################
#                  Checks if Chararcter has enough reputation to complete quest.      #
#######################################################################################

def CanStartRepCheck (player,questid):
    GetRepFactVals = _executables_.GetRepFactVals(questid)
    if _executables_.PlayerReputationValueByFactionId(player,GetRepFactVals[0]) >= GetRepFactVals[1] and _executables_.PlayerReputationValueByFactionId(player,GetRepFactVals[2]) >= GetRepFactVals[3]:
         return co.TRUE
    return co.FALSE
# --------------------------------------
