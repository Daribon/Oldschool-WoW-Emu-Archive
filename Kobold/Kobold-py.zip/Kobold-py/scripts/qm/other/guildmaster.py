#
# GuildMaster default handler
#
# Author: <PavkaM>

from Ludmilla import *
import consts as co
reload(co)
from random import *


def OnHello (self, player):
    # Adding quests to menu, if there are quests
    if self.IsQuestGiver() :
        player.AddNPCQuests( self )

    # Get defaults
    txtid   = self.GetStoredNPCText( co.BANK_GREET, co.DEFAULT_GOSSIP_MESSAGE)
    txtfg   = self.GetStoredText( co.BANK_TEXT_GUILD, "How do I form a guild?")
    txtgc   = self.GetStoredText( co.BANK_TEXT_TABARD, "I want to create a guild crest.") 

    #player.AddGossipItem( 8, txtgc, co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_TABARD)
    player.AddGossipItem( 7, txtfg, co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_GUILD)
    player.AddGossipItem( 8, txtgc, co.GOSSIP_SENDER_MAIN, co.GOSSIP_ACTION_TABARD)
    player.SendGossipMenu(self, txtid) # Info message
    
# -------------------------------------------

def OnGossipSelect (self, player, sender, action):
    # Serving default menus
    
    if action == co.GOSSIP_ACTION_TABARD:
        player.SendTabardList(self)

    if action == co.GOSSIP_ACTION_GUILD:
        player.SendGuildManager(self)

# -------------------------------------------

def OnDialogStatus (self, player):
    return player.NPCQuestDialogStatus( self, co.DIALOG_STATUS_CHAT )