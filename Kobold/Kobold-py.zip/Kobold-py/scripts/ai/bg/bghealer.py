#
# by altxcom
#

from Ludmilla import *          # Import server environment
from random import *            # Randomiser Import
import config as cfg            # Import of configuration constants
reload(cfg)  
import consts as co             # Import of constants
reload(co)   
import const_skills as skill_co # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co # Import of constants (skills)
reload(spell_co)  
import player_class as player_cls
reload(player_cls) 
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

# ####################################################################################
class AI_BGHealer:

    #-----------------------------------------------------------------------------
    def OnEnemyDetected (Aclass, self, attacker):
        pass
        
    #-----------------------------------------------------------------------------
    def OnAttacked (Aclass, self, attacker):
        pass
        
    #-----------------------------------------------------------------------------
    def OnTakeDamage (Aclass, self, attacker):
        pass
        
    #-----------------------------------------------------------------------------
    def OnThink (Aclass, self, val):
        
        print "AI_BGHealer: OnThink: %d" % (val)
        
        self.MovementType(co.STAY_AT_CURRENT_PLACE)
        self.Emote(co.EMOTE_ONESHOT_SPELLCAST)
        
        spell_id = spell_name.SPELL_ID_SPIRIT_HEALER_RES
        
        print "AI_BGHealer: casting spell: %d" % (spell_id)
        
        self.CastSpell(self, spell_id)
        
        self.NextThink(32000, val)
    
    #-----------------------------------------------------------------------------
    def OnInitNpc (Aclass, self):
        print "AI_BGHealer: OnInitNpc: %s" % (self.GetName())
        self.NextThink(32000, 1)

#--- END ---