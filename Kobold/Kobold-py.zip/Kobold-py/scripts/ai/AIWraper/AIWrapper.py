class AiWrapper:
    CharName = ""
    TargetName = ""
    Health= 0
    MaxHealth = 0
    def __init__(self, AICharName, AITargetName, AICharHealth, AICharMaxHealth ):
        self.CharName=AICharName
        self.TargetName=AITargetName
        self.Health=AICharHealth
        self.MaxHealth=AICharMaxHealth
        
    def Emote(self,Emotion):
        print "WRAPPER>"+self.CharName+" make imotion # "+str(Emotion)
        
    def NextThink(self,Time, Value):
        print "WRAPPER>"+self.CharName+" go off to think "+str(Time)+" seconds "+"with value = "+str(Value)
        
    def Say(self,Target, Message, Lang):
        if Target==self:
            print "WRAPPER>"+self.CharName+" say words: "+Message+" on Language #"+str(Lang)
        else:
            print "WRAPPER>"+self.CharName+" say to target -="+Target.CharName+"=- words: "+Message+" on Language #"+str(Lang)

    def GetHealth(self):
        return self.Health

    def GetMaxHealth(self):
        return self.MaxHealth
        
    def Flee(self, Target, Time, Dist):
        print "WRAPPER>"+self.CharName+" begin to flee from target -="+Target.CharName+"=- for "+str(Time)+" seconds on dist = "+str(Dist)
        
        
        
        
