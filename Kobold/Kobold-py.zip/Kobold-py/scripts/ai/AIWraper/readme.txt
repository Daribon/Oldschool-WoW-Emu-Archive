AI Wrapper for Ludmila python AI scripts by SkyRanger 
=====================================================

Here you are some tool that can help debug AI scripts. It's only need
Python installed.

How to use:
===========

First:

Add to AI-script string:

from AIWraper.AIWrapper import *

Second:

Place text between #-- AI testing definition begin here and #TestAI() to bottom
of you script.

This is Example for peasant. You need to chenge only

AIWrpPlayer = AiWrapper("Peasant", "Player",20,100)

and

AIWrpEnemy  = AiWrapper("Wolf", "None",200,200)

string to test other AI

Example:
========

#-- AI testing definition begin here

def TestAI():
    AIWrpEnemy  = AiWrapper("Wolf", "None",200,200)
    AIWrpPlayer = AiWrapper("Peasant",AIWrpEnemy,20,100)
    print ">=>On AI Init:"
    OnInitNpc(AIWrpPlayer)
    print ">=>On AI Think:"
    OnThink (AIWrpPlayer,3)
    print ">=>On Attacked:"
    OnAttacked(AIWrpPlayer,AIWrpEnemy)
    print ">=>On Take Damage:"
    OnTakeDamage (AIWrpPlayer,AIWrpEnemy)
    print ">=>AI Test Done!"
    
#-- End of AI testing

# Uncomment following string to test AI
#TestAI()


Just uncomment #TestAI() and run script via Python GUI

Class description:
==================
Class constructor( __init__ ):

AiWrapper(AIMOBNAME, MOBTARGETNAME, CURRENTHEALTH, MAXHEALTH)

AIMOBNAME     - name of you AI class
MOBTARGETNAME - AIWrapper class of Enemy
CURRENTHEALTH - Current health of you AI mob
MAXHEALTH     - Maximum health of you AI mob

Class must have definition for ALL Ludmila function that used in AI scripts 
and also definiton of ALL attributes to store that data in class. So you may
be need to add some methond and attributes in this wrapper to make it work
with you scripts and also some more params into constructor...

You can see example in peasant.py for detailed info!