#by Aceindy

from Ludmilla import *
import consts as co
reload(co)
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name) 
from random import *

#------------------------------------------------------------------------------
def OnInitNpc (self):
 
    print "OnQuestInvisibility: %s %d" % (self.GetName(), self.GetEntry())
    self.CastSpell(self, spell_name.SPELL_ID_QUEST_INVISIBILITY )
#--- END ---#
