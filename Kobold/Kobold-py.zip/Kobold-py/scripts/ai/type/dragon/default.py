#
# AI Behavior Module
#
# To disable some handler, comment it out or rename, so loader doesn't find it by name
#
# Rewritten by Cain on 25-01-2006
#
from Ludmilla import *
import consts as co
reload(co)
from random import *

#------------------------------------------------------------------------------
def OnEnemyDetected (self, attacker):
    """ Function is called when NPC 'self' notifies (aggroes) player 'attacker'
        right before the moment when Hate is added.
        Param: (Unit attacker, Unit attacker)
    """
    pass
    
#------------------------------------------------------------------------------
#attack_emotes = [EMOTE_ONESHOT_RUDE, EMOTE_ONESHOT_ROAR, EMOTE_ONESHOT_POINT]
#attack_messages = ["The Brotherhood will not tolerate your actions!",  "Ah, chance to test this freshly sharpened blade!"]
def OnAttacked (self, attacker):
    """ Param: (Unit npc, Unit npc2)
        Function is called when npc is attacked by npc2, just before attack
        reaction game function called. If OnAttacked returns 0 or None, then
        normal reaction for current aiclass is called (attack back or flee).
    """
    # Initialise Variables
    spell_index = int(self.GetLevel())
    spell_list = [8873,8873,9573,16390,16396,17294,18435]
    if spell_index >= spell_list.__len__(): spell_index = spell_list.__len__() - 1

    # Randomly select casting Spell on Creature Level basis
    spell_id = spell_list[randint(0,spell_index)]
    
    #Init Spell Cast
#    printLog("Dragon casting spell: index[%s] spell[%s]" % (spell_index, spell_id))
    self.CastSpell(attacker, spell_id)
    
#------------------------------------------------------------------------------
#runaway_messages = ["Sorry, I got to go!", "Whoops, its dinner time!",
#    "See you later!", "Got to go!", "Have a nice day!"]


def OnTakeDamage (self, attacker):
    """ Function is called when NPC 'self' takes damage in combat from npc or
        player 'attacker'
        Param: (Unit attacker, Unit attacker)
    """
#    if 100.0 * self.GetHealth() / self.GetMaxHealth() <= 20:
#        if randrange (100) < 10:
#            self.Say (attacker, choice (runaway_messages), co.LANG_UNIVERSAL, co.MONSTER_SAY)
        # self.Emote is good to

        # Trigger 10 second flee mode when creature ignores damage with 15
        # meters help radius. If no help found, return back and attack.
        #
#        self.Flee (attacker, 10, 15)


#--- END ---
