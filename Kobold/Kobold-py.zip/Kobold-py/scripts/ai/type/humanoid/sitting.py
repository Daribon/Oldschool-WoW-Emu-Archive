#by Aceindy

from Ludmilla import *
import consts as co
reload(co)
from random import *

#------------------------------------------------------------------------------
def OnInitNpc (self):
   
    print "OnInitSit: %s %d" % (self.GetName(), self.GetEntry())
   
    self.MovementType (co.STAY_AT_CURRENT_PLACE)
    self.SetStandState (co.STANDSTATE_SIT)

#--- END ---