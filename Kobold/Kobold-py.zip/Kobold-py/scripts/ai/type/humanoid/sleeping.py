#by Aceindy

from Ludmilla import *
import consts as co
reload(co)
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name) 
from random import *

#------------------------------------------------------------------------------
def OnInitNpc (self):
   
    print "OnInitSleeping: %s %d" % (self.GetName(), self.GetEntry())
   
    self.MovementType (co.STAY_AT_CURRENT_PLACE)
    self.SetStandState (co.STANDSTATE_SLEEP)
#--- END ---