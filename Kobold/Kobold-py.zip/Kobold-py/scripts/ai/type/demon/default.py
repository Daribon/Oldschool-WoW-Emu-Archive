#
# AI Behavior Module
#
# To disable some handler, comment it out or rename, so loader doesn't find it by name
#
from Ludmilla import *
import consts as co
reload(co)
from random import *

#------------------------------------------------------------------------------
def OnEnemyDetected (self, attacker):
    """ Function is called when NPC 'self' notifies (aggroes) player 'attacker'
        right before the moment when Hate is added.
        Param: (Unit attacker, Unit attacker)
    """
    pass
    
    
#------------------------------------------------------------------------------
#attack_emotes = [EMOTE_ONESHOT_RUDE, EMOTE_ONESHOT_ROAR, EMOTE_ONESHOT_POINT]
#attack_messages = ["The Brotherhood will not tolerate your actions!",  "Ah, chance to test this freshly sharpened blade!"]

def OnAttacked (self, attacker):
    """ Param: (Unit npc, Unit npc2)
        Function is called when npc is attacked by npc2, just before attack
        reaction game function called.     elif OnAttacked returns 0 or None, then
        normal reaction for current aiclass is called (attack back or flee).
    """
    # Initialise Variables
    spell_id = 0
    spell_selector = round((self.GetLevel()) * 0.633333333) 
    
    # Select needed Spell on Creature Level basis
    if   spell_selector == 0: spell_id = 348
    elif spell_selector == 0: spell_id = 686
    elif spell_selector == 2: spell_id = 172
    elif spell_selector == 3: spell_id = 1454
    elif spell_selector == 4: spell_id = 695
    elif spell_selector == 5: spell_id = 172
    elif spell_selector == 6: spell_id = 707
    elif spell_selector == 7: spell_id = 1120
    elif spell_selector == 8: spell_id = 980
    elif spell_selector == 9: spell_id = 689
    elif spell_selector == 10: spell_id = 6222
    elif spell_selector == 11: spell_id = 705
    elif spell_selector == 12: spell_id = 5676
    elif spell_selector == 13: spell_id = 1094
    elif spell_selector == 14: spell_id = 1088
    elif spell_selector == 15: spell_id = 5740
    elif spell_selector == 16: spell_id = 699
    elif spell_selector == 17: spell_id = 6223
    elif spell_selector == 18: spell_id = 5138
    elif spell_selector == 19: spell_id = 8288
    elif spell_selector == 20: spell_id = 17919
    elif spell_selector == 21: spell_id = 1106
    elif spell_selector == 22: spell_id = 6217
    elif spell_selector == 23: spell_id = 2941
    elif spell_selector == 24: spell_id = 17920
    elif spell_selector == 25: spell_id = 6219
    elif spell_selector == 26: spell_id = 7648
    elif spell_selector == 27: spell_id = 6226
    elif spell_selector == 28: spell_id = 7641
    elif spell_selector == 29: spell_id = 7651
    elif spell_selector == 30: spell_id = 11711
    elif spell_selector == 31: spell_id = 9290
    elif spell_selector == 32: spell_id = 11665
    elif spell_selector == 33: spell_id = 6789
    elif spell_selector == 34: spell_id = 11672
    elif spell_selector == 35: spell_id = 11661
    elif spell_selector == 36: spell_id = 11668
    elif spell_selector == 37: spell_id = 17924
    elif spell_selector == 38: spell_id = 11678
    
    #Init Spell Cast
#    printLog("Demon casting spell: selector[%s] spell[%s]" % (spell_selector, spell_id))
    if spell_id != 0: self.CastSpell(attacker, spell_id)
    
#------------------------------------------------------------------------------
#runaway_messages = ["Sorry, I got to go!", "Whoops, its dinner time!",
#    "See you later!", "Got to go!", "Have a nice day!"]


def OnTakeDamage (self, attacker):
    """ Function is called when NPC 'self' takes damage in combat from npc or
        player 'attacker'
        Param: (Unit attacker, Unit attacker)
    """
#        elif 100.0 * self.GetHealth() / self.GetMaxHealth() <= 20:
#            elif randrange (100) < 10:
#            self.Say (attacker, choice (runaway_messages), co.LANG_UNIVERSAL, co.MONSTER_SAY)
        # self.Emote is good to

        # Trigger 10 second flee mode when creature ignores damage with 15
        # meters help radius.     elif no help found, return back and attack.
        #
#        self.Flee (attacker, 10, 15)


#--- END ---
