#
# AI Behavior Module
#
# From:	hylysi
# Posted:	Fri Jan 26, 2007 2:15 am
# Subject:	v3 working vancleef script
#

from Ludmilla import *
import consts as co
reload(co)
from random import *
#from AIWraper.AIWrapper import *
import packet_class as packet_builder
reload(packet_builder)

class AI_Vancleef:
   
    #------------------------------------------------------------------------------
    def OnUnitDeath (attacker, self):
        self.Say (attacker, "And stay down!", co.LANG_UNIVERSAL, co.MONSTER_YELL)
        printLog( "Vancleef - Slay" )
        packet = packet_builder.make_SMSG_PLAY_SOUND(5781)
        packet.SendToSetUnit(self, 1)

    #------------------------------------------------------------------------------
    #attack_emotes = [EMOTE_ONESHOT_RUDE, EMOTE_ONESHOT_ROAR, EMOTE_ONESHOT_POINT]
    def OnAttacked (Aclass,self, attacker):
         pass
         
    #-----------------------------------------------------------------------------
    def OnTakeDamage (aclass, self, attacker):
        while 100.0 * self.GetHealth() / self.GetMaxHealth() > 73 and 100.0 * self.GetHealth() / self.GetMaxHealth() < 77:
            self.Say (attacker, "Lapdogs, all of you!", co.LANG_UNIVERSAL, co.MONSTER_YELL)
            printLog( "Vancleef - Health 75%" )
            packet = packet_builder.make_SMSG_PLAY_SOUND(5782)
            packet.SendToSetUnit(attacker, 1)
            break
        while 100.0 * self.GetHealth() / self.GetMaxHealth() > 50 and 100.0 * self.GetHealth() / self.GetMaxHealth() <= 52:
            self.Say (attacker, "Fools! Our cause is righteous!", co.LANG_UNIVERSAL, co.MONSTER_YELL)
            printLog( "Vancleef - Health 50%" )
            packet = packet_builder.make_SMSG_PLAY_SOUND(5783)
            packet.SendToSetUnit(self, 1)
            break
        while 100.0 * self.GetHealth() / self.GetMaxHealth() > 18 and 100.0 * self.GetHealth() / self.GetMaxHealth() <= 20:
            self.Say (attacker, "The Brotherhood shall prevail!", co.LANG_UNIVERSAL, co.MONSTER_YELL)
            packet = packet_builder.make_SMSG_PLAY_SOUND(5784)
            packet.SendToSetUnit(self, 1)
            break
 #-----------------------------------------------------------------------------
    def OnEnemyDetected (ptrCls,self, attacker):
        self.Say (attacker, "None may challenge The Brotherhood!", co.LANG_UNIVERSAL, co.MONSTER_YELL)
        printLog( "Vancleef - Aggro" )
        packet = packet_builder.make_SMSG_PLAY_SOUND(5780)
        packet.SendToSetUnit(self, 1)
       
    #-----------------------------------------------------------------------------
    def OnThink (Aclass,self, val):
         pass
     
    #------------------------------------------------------------------------------
    def OnInitNpc (Aclass, self):
         self.NextThink (5000, 0)
 #--- END ---