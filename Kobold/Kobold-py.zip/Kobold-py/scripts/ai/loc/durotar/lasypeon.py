#

from Ludmilla import *
import consts as co
reload(co)
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  
from random import *

class AI_Peon:
    #------------------------------------------------------------------------------   
    def OnAttacked (Aclass,self, attacker):       
        pass

    #------------------------------------------------------------------------------
    def OnTakeDamage (Aclass,self, attacker):        
        pass
        
    #------------------------------------------------------------------------------
    def OnThink (Aclass,self, val):
     
        working_messages = ["It's hard work!", "I am tired!", "Working, Working...", "Slave driver!" ]

        if self.HasAffect( spell_name.SPELL_ID_PEON_SLEEPING ) == 0 and val > 30:
            self.CastSpell(self, spell_name.SPELL_ID_PEON_SLEEPING )
            print "Peon Sleep"
            return

        if self.HasAffect( spell_name.SPELL_ID_PEON_SLEEPING ) == 0 and randrange (100) < 1 :
            self.Say (self, choice (working_messages), co.LANG_UNIVERSAL, co.MONSTER_SAY)
 
        self.Emote (co.EMOTE_STATE_WORK_NOSHEATHE_CHOPWOOD)
        val += 1
        self.NextThink (1000, val)
     
    #------------------------------------------------------------------------------
    def OnInitNpc (Aclass,self):
        self.MovementType (co.STAY_AT_CURRENT_PLACE)
        self.Equip(1, 3, 0, 0)        
        self.Equip(0, 3, 7428, 218169346)    
        self.CastSpell(self, spell_name.SPELL_ID_PEON_SLEEPING )
        self.NextThink (100, 0)
#--- END ---



