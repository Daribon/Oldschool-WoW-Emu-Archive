#
# THIS MODULE MUST CONTAIN ONLY BASIC CREATURE BEHAVIOR (COMMON TO ALL LIVING)
# rebuild by altxcom 1.10.2006

from Ludmilla import *
import consts as co
reload(co)
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)
from random import *
from math import *              # Math lib Import
import support as _support_
reload(_support_)

#-----------------------------------------------------------------------------
def OnEnemyDetected (self, attacker):

    if self.GetClass() == co.CLASS_WARRIOR:
        self.CastSpell(self, spell_name.SPELL_ID_DEFENSIVE_STANCE)

    attack_messages = ["Die !","I will most certainly kill you !", "Better start calling your mummy", "I will get you !", "Ah, fresh meat", "Feel my wrath"]
    
    if self.GetType() != co.CREATURE_TYPE_BEAST:
        if attacker.IsPlayer(): 
            if randrange(100) < 5:
                self.Say(attacker, choice (attack_messages), co.LANG_UNIVERSAL, co.MONSTER_SAY)

#-----------------------------------------------------------------------------
def OnAttacked (self, attacker):

    if attacker.IsNPC() and attacker.GetReputationStandingByFactionTemplateId(self.GetFaction()) >= co.FACTION_STANDING_FRIENDLY:
        self.ClearHate()
        self.ShareHateWith(attacker)
        return

    RandomCast(self,attacker)
 

#-----------------------------------------------------------------------------
#to add self heal but should be in list of get self lvl and use spell in range for heal lvl also adding self flee on hp belove 10%
#on atacker hp < self get hp will mailfunction on npc and players in low lvl couse on low lvl player always have more hp then npc
#does "AbilityIsFriendly" give npc ability to resolve healing spell from dgm spell?


def OnTakeDamage (self, attacker):
    
    runaway_messages = ["Sorry, I got to go!", "Whoops, its dinner time!",
    "See you later!", "Got to go!", "Have a nice day!", "Ooops mummy calls me!"]

    guid64 = self.GetGUIDUInt64()
    
    # check Distance from moment of first damage, clearhate & go back when distance > 333
    if _support_.MarkSpot.has_key(guid64) == 0 :
        _support_.MarkSpot[guid64] = self.GetXYZ() #Mark spot if not already done so
        
    arr1 = _support_.MarkSpot[guid64] 
    arr2 = self.GetXYZ()
    if sqrt( ( arr2[0] - arr1[0] ) * ( arr2[0] - arr1[0] ) + ( arr2[1] - arr1[1] ) * ( arr2[1] - arr1[1] ) ) > 333:
        self.ClearHate()
        self.StartEvadeTo(_support_.MarkSpot[guid64])
        if self.GetFamily() == co.CREATURE_TYPE_HUMANOID:
            self.Say (attacker, choice (runaway_messages), co.LANG_UNIVERSAL, co.MONSTER_SAY)
        return
        
    RandomCast(self,attacker)
    
    if randrange(100) <= 25 and 100.0 * self.GetHealth() / self.GetMaxHealth() <= 5 :
        if self.GetFamily() == co.CREATURE_TYPE_HUMANOID:
            self.Say (attacker, choice (runaway_messages), co.LANG_UNIVERSAL, co.MONSTER_SAY)
        self.Flee (attacker, 8, 5)

def RandomCast (self,attacker):
    max_spell_count = self.GetDefaultSpellCount()
    current_health = 100.0 * self.GetHealth() / self.GetMaxHealth()
    
    if max_spell_count > 0 and randrange(100) < 25:
        spell_choice = randrange(0, max_spell_count)
        current_spell = self.GetDefaultSpell(spell_choice)
        
        current_dist = _support_.CalcDist(self, attacker)
    
        if AbilityIsFriendly(spell_choice) == co.TRUE and current_health <= 20:  
            self.CastSpell(self, current_spell)
        elif current_dist > 0.2 and current_dist < 20 :
            self.CastSpell(attacker, current_spell)
 
#-----------------------------------------------------------------------------
def OnThink (self, val):
    pass

#-----------------------------------------------------------------------------
#thinking of adding default handler for npc arround npc to be healed in fight also aded some bonus buff's
def OnInitNpc (self):
    NPC_Spells = { 474:spell_name.SPELL_ID_FROST_ARMOR_1,  #Defias Rogue Wizard
                   583:spell_name.SPELL_ID_STEALTH_RANK_1, #Defias Ambusher
                  6866:spell_name.SPELL_ID_STEALTH_RANK_1} #Defias Bodyguard
    c = self.GetEntry()
    if NPC_Spells.has_key(c):
        self.CastSpell(self, NPC_Spells.get(c))

#-----------------------------------------------------------------------------
#maybe to find way to return npc to its spawn point when too far from it? couse on normal map areas npc follow player till death
def OnWaypoint (self, Val):
    pass

#-----------------------------------------------------------------------------
def OnSleepNPC (self):
    self.CastSpell(self.spell_name.SPELL_ID_REMOVE_ALL_EFFECTS)
    pass
#added self clear loot on killer is npc    
def OnDeath (self, killer):
    if killer.IsNPC():
        self.ClearLootTable()
#-----------------------------------------------------------------------------
'''def OnUpdate (time_diff,self):
    """Function is called by core on every Creature Update
    """
    
    pass'''
#--- END ---