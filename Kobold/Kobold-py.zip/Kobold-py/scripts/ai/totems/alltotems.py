#by MasterM
from Ludmilla import *
import consts as co
reload(co)
from random import *
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name)  

#------------------------------------------------------------------------------
def OnInitNpc (self):
    
    entry_id = self.GetEntry()
    
    print "OnInitTotem: %s %d" % (self.GetName(), entry_id)
    
    # stop any movements
    self.MovementType (co.STAY_AT_CURRENT_PLACE)
    
    spell_id = 0
    
    if   entry_id == 5879: spell_id = 8443 #Fire Nova Totem 
    elif entry_id == 6110: spell_id = 8504 #Fire Nova Totem II
    elif entry_id == 6111: spell_id = 8509 #Fire Nova Totem III
    elif entry_id == 7844: spell_id = 11310 #Fire Nova Totem IV
    elif entry_id == 7845: spell_id = 11311 #Fire Nova Totem V
    elif entry_id == 15482: spell_id = 11312 #Fire Nova Totem VI
    elif entry_id == 15483: spell_id = 11313 #Fire Nova Totem VII        
    
    elif entry_id == 5873: spell_id = 8072	#Stoneskin Totem
    elif entry_id == 5919: spell_id = 8156  #Stoneskin Totem II
    elif entry_id == 5920: spell_id = 8157	#Stoneskin Totem III
    elif entry_id == 7366: spell_id = 10403	#Stoneskin Totem IV
    elif entry_id == 7367: spell_id = 10404	#Stoneskin Totem V
    elif entry_id == 7368: spell_id = 10405	#Stoneskin Totem VI
    elif entry_id == 15470: spell_id = 25506	#Stoneskin Totem VII
    elif entry_id == 15474: spell_id = 25507	#Stoneskin Totem VIII        

    elif entry_id == 2630: spell_id = 6474   #Earthbind Totem

    elif entry_id == 3579: spell_id = 5728	  #Stoneclaw Totem
    elif entry_id == 3911: spell_id = 6397	  #Stoneclaw Totem II
    elif entry_id == 3912: spell_id = 6398	  #Stoneclaw Totem III
    elif entry_id == 3913: spell_id = 6399	  #Stoneclaw Totem IV
    elif entry_id == 7398: spell_id = 10425   #Stoneclaw Totem V
    elif entry_id == 7399: spell_id = 10426	#Stoneclaw Totem VI
    elif entry_id == 15478: spell_id = 25513	#Stoneclaw Totem VII    


    elif entry_id == 5874: spell_id = 8076	#Strength of Earth Totem
    elif entry_id == 5921: spell_id = 8162	#Strength of Earth Totem II
    elif entry_id == 5922: spell_id = 8163	#Strength of Earth Totem III
    elif entry_id == 7403: spell_id = 10441	#Strength of Earth Totem IV
    elif entry_id == 15464: spell_id = 25362	#Strength of Earth Totem V
    elif entry_id == 15479: spell_id = 25527	#Strength of Earth Totem VI    
    
    elif entry_id == 2523: spell_id = 5676  #Searing Totem
    elif entry_id == 3902: spell_id = 17919 #6350	#Searing Totem II
    elif entry_id == 3903: spell_id = 17920 #6351	#Searing Totem III
    elif entry_id == 3904: spell_id = 17921 #6352	#Searing Totem IV
    elif entry_id == 7400: spell_id = 17922 #10435	#Searing Totem V
    elif entry_id == 7402: spell_id = 17923 #10436	#Searing Totem VI
    elif entry_id == 15480: spell_id = 27210 #10436	#Searing Totem VII
    
    elif entry_id == 5913: spell_id = 8145	#Tremor Totem

    elif entry_id == 5923: spell_id = 8167	#Poison Cleansing Totem

    elif entry_id == 3527: spell_id = 5672  #Healing Stream Totem
    elif entry_id == 3906: spell_id = 6371	#Healing Stream Totem II
    elif entry_id == 3907: spell_id = 6372	#Healing Stream Totem III
    elif entry_id == 3908: spell_id = 10460	#Healing Stream Totem IV
    elif entry_id == 3909: spell_id = 10465 #Healing Stream Totem V
    elif entry_id == 15488: spell_id = 25567 #Healing Stream Totem VI

    elif entry_id == 5926: spell_id = 8182	#Frost Resistance Totem
    elif entry_id == 7412: spell_id = 10476	#Frost Resistance Totem II
    elif entry_id == 7413: spell_id = 10477	#Frost Resistance Totem III
    elif entry_id == 15486: spell_id = 24449 	#Frost Resistance Totem IV    

    elif entry_id == 5929: spell_id = 8188	#Magma Totem
    elif entry_id == 7464: spell_id = 10582	#Magma Totem II
    elif entry_id == 7465: spell_id = 10583	#Magma Totem III
    elif entry_id == 7466: spell_id = 10584	#Magma Totem IV
    elif entry_id == 15484: spell_id = 25551	#Magma Totem V
    
    elif entry_id == 3573: spell_id = 5677	#Mana Spring Totem
    elif entry_id == 7414: spell_id = 10491	#Mana Spring Totem II
    elif entry_id == 7415: spell_id = 10493	#Mana Spring Totem III
    elif entry_id == 7416: spell_id = 10494	#Mana Spring Totem IV
    elif entry_id == 15489: spell_id = 24853	#Mana Spring Totem V

    elif entry_id == 5950: spell_id = 8229	    #Flametongue Totem
    elif entry_id == 6012: spell_id = 8251      #Flametongue Totem II
    elif entry_id == 7423: spell_id = 10524	    #Flametongue Totem III
    elif entry_id == 10557: spell_id = 16388	#Flametongue Totem IV
    elif entry_id == 15485: spell_id = 25556	#Flametongue Totem V    

    elif entry_id == 5925: spell_id = 8179	   #Grounding Totem

    elif entry_id == 7467: spell_id = 10596	   #Nature Resistance Totem
    elif entry_id == 7468: spell_id = 10598	   #Nature Resistance Totem II
    elif entry_id == 7469: spell_id = 10599	   #Nature Resistance Totem III
    elif entry_id == 15490: spell_id = 20551	   #Nature Resistance Totem IV

    elif entry_id == 6112: spell_id = 8515	   #Windfury Totem
    elif entry_id == 7483: spell_id = 10609	   #Windfury Totem II
    elif entry_id == 7484: spell_id = 10612	   #Windfury Totem III
    elif entry_id == 15496: spell_id = 25581	   #Windfury Totem IV
    elif entry_id == 15497: spell_id = 25582	   #Windfury Totem V    

    elif entry_id == 3968: spell_id = 16527	    #Sentry Totem

    elif entry_id == 9687: spell_id = 	15108   #Windwall Totem
    elif entry_id == 9688: spell_id = 	15109   #Windwall Totem II
    elif entry_id == 9689: spell_id = 	15110   #Windwall Totem III
    elif entry_id == 15492: spell_id = 	25576   #Windwall Totem IV

    elif entry_id == 5924: spell_id = 	8172    #Disease Cleansing Totem

    elif entry_id == 10467: spell_id = 	16191   #Mana Tide Totem
    elif entry_id == 11100: spell_id = 	17355   #Mana Tide Totem II
    elif entry_id == 11101: spell_id = 	17360   #Mana Tide Totem III

    elif entry_id == 7486: spell_id = 	8836    #Grace of Air Totem
    elif entry_id == 7487: spell_id = 	10626   #Grace of Air Totem II
    elif entry_id == 15463: spell_id = 	25360   #Grace of Air Totem III    

    elif entry_id ==  5927: spell_id =8185 		#Fire Resistance Totem
    elif entry_id == 7424: spell_id = 10534		#Fire Resistance Totem II
    elif entry_id == 7425: spell_id = 10535		#Fire Resistance Totem III
    elif entry_id == 15487: spell_id = 23992		#Fire Resistance Totem IV    

    self.CastSpell(self, spell_id)


#--- END ---


