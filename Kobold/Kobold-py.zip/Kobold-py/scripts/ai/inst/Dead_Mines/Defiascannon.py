
from Ludmilla import *
import consts as co
reload(co)
from random import *
import support as supporter
reload(supporter)

def OnGOSelect (gameobject, player):
 
 unit_list = self.MapRangeUnitList()
 agr_mob = []
 
 for enemy_ in unit_list:
  if enemy_.IsPlayer() == FALSE:
   agr_mob.append(enemy_)
   
 for agr_mobs in agr_mob:
  agr_mobs.AddHate(player,50) 
  
  go_list = GetInstanceGOList(self.GetInstanceId()) 
  for go in go_list:
    if go.GetName() == "Factory Door":
        # Open door (33 - open door, 34 - close door)
        go.SetFlags(33)
        go.SetState(0)
 