# COPYRIGHT (C) 2006 LUDMILLA TEAM
from Ludmilla import *          # Import server environment
from random import *            # Randomiser Import
import config as cfg            # Import of configuration constants
reload(cfg)  
import consts as co             # Import of constants
reload(co)   
import const_skills as skill_co # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co # Import of constants (skills)
reload(spell_co)  
import player_class as player_cls
reload(player_cls) 

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

# MoltenCore buffer_id declarations
INSTANCE_MC_ACH_SPAWN_BUFFER_INDEX          = 0
INSTANCE_MC_GOLEMAGG_BUFFER_INDEX           = 1
INSTANCE_MC_CR1_BUFFER_INDEX                = 2
INSTANCE_MC_CR2_BUFFER_INDEX                = 3
INSTANCE_MC_FIRESWORN1_STATUS_BUFFER_INDEX  = 4


#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Set's up Correct coordinate limits of known maps, also definitions to Instances (executed on server start only!)
def SetMapProperties(map_id):

    #SetMapSafeLoc(map_id, minX, maxX, minY, maxY, Instance, Instance Lifetime)
    
    d = None
    
    # *BG_Team_Size - normally if set to 0 then Battle Ground team size will be taken by server from DBC storage automatically
    #                                 only in case you experience that server has low population but you still are willing to offer BG to players
    #                                you shall change this value from 0 to desired player MAX count per 1 team, thus overwritting server defaults.
    #                                Example: setting for 2, will allow to enter from each side for 1 player min.

    #    map_id                       minX   maxX    minY   maxY   Lifetime     AreaTrig1 AreaTrig2    Team_Size*   Score_Max
#Normal maps (0)
    if   map_id == 0:   d = map_id, -15470, 15470, -15470, 15470,        0,           0,          0,            0,          0 #Azaroth
    elif map_id == 1:   d = map_id, -15470, 16470, -15470, 16470,        0,           0,          0,            0,          0 #Kalimdor
    elif map_id == 13:  d = map_id, -11870, 12470, -15470, 15470,        0,           0,          0,            0,          0 #Test
    elif map_id == 25:  d = map_id, -11870, 12470, -15470, 15470,        0,           0,          0,            0,          0 #ScottTest
    elif map_id == 35:  d = map_id, -15470, 12470, -15470, 15470,        0,           0,          0,            0,          0 #Stormwind Prison
    elif map_id == 37:  d = map_id, -15470, 12470, -15470, 15470,        0,           0,          0,            0,          0 #Azshara Crater
    elif map_id == 42:  d = map_id, -15470, 12470, -15470, 15470,        0,           0,          0,            0,          0 #Collin
    elif map_id == 369: d = map_id,  -8000,  8000,  -8000,  8000,        0,           0,          0,            0,          0 #Deeprun Tram
    elif map_id == 530: d = map_id, -20000, 20000, -20000, 20000,        0,           0,          0,            0,          0 #Expansion01

#Dungeons (1)

# Raids (2)
    elif map_id == 169: d = map_id,  -15470,  15470,  -15470,  15470,        1,           0,          0,            0,          0 #Emerald Dream
    elif map_id == 249: d = map_id,  -15470,  15470,  -15470,  15470,        1,           0,          0,            0,          0 #Onyxia's Lair
    elif map_id == 309: d = map_id,  -13000,  13000,  -13000,  13000,        1,           0,          0,            0,          0 #Zul'Gurub
    elif map_id == 409: d = map_id,  -15470,  15470,  -15470,  15470,        1,           0,          0,            0,          0 #Molten Core
    elif map_id == 469: d = map_id,  -15470,  15470,  -15470,  15470,        1,           0,          0,            0,          0 #Blackwing Lair
    elif map_id == 509: d = map_id,  -10000,  10000,  -10000,  10000,        1,           0,          0,            0,          0 #Ruins of Ahn'Qiraj
    elif map_id == 531: d = map_id,  -12000,   9500,   -9500,   9500,        1,           0,          0,            0,          0 #Ahn'Qiraj
    elif map_id == 532: d = map_id,  -12000,   9500,   -9500,   9500,        1,           0,          0,            0,          0 #Karazhan
    elif map_id == 533: d = map_id,  -12000,  12000,  -12000,  12000,        1,           0,          0,            0,          0 #Naxxramas
    elif map_id == 544: d = map_id,  -15470,  15470,  -15470,  15470,        1,           0,          0,            0,          0 #Magtheridon's Lair
    elif map_id == 548: d = map_id,  -15470,  15470,  -15470,  15470,        1,           0,          0,            0,          0 #Coilfang Raid
    elif map_id == 550: d = map_id,  -15470,  15470,  -15470,  15470,        1,           0,          0,            0,          0 #Tempest Keep Raid

# PvP_zone_I (3)
    elif map_id == 30:  d = map_id,  -8000,  8000,  -8000,  8000,        0,          95,       2606,            0,          0 #PVP Zone 1 Alterac Valley
    elif map_id == 489: d = map_id,  -8000,  8000,  -8000,  8000,        0,        3646,       3647,            0,          0 #PVP Zone 4 Warsong Gulch
    elif map_id == 529: d = map_id,  -8000,  8000,  -8000,  8000,        0,        3866,       3867,            0,          0 #PVP Zone 3 Arathi Basin
    elif map_id == 566: d = map_id,  -8000,  8000,  -8000,  8000,        0,           0,          0,            0,          0 #NetherstormArena

# PvP_zone_II (4)
    elif map_id == 559: d = map_id,  -8000,  8000,  -8000,  8000,        0,           0,          0,            0,          0 #PVPZone05
    elif map_id == 566: d = map_id,  -8000,  8000,  -8000,  8000,        0,           0,          0,            0,          0 #bladesedgearena

#undefined    
    else:               d = map_id,  -8000, 8000, -8000, 8000,       1,           0,          0,            0,          0 # Default Setting
    
#    print "mapdefenition [%d] -X[%d] +X[%d] -Y[%d] +Y[%d] L[%d]" % (d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7], d[8], d[9])
    SetMapDefinition( d[0], d[1], d[2], d[3], d[4], d[5], d[6], d[7], d[8], d[9] )
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Called by core on every Round Start
def OnBattleGroundRoundStart(instance_id, map_id):
    
    print "OnBattleGroundRoundStart: instance[%d] map[%d]" % (instance_id, map_id)
    
    text = "|cdf20af20The battle starts."
    SendBattleGroundMessage(text, co.SIDE_ALL_MASK, instance_id)
    
    # Warsong Gulch
    '''
    if map_id == 489:
        
        go_list = GetInstanceGOList(instance_id)
        
        for go in go_list:
            if go == NULL: continue
            else: entry_id = go.GetEntry()
            
            print "GetInstanceGOList: found GameObject[%d]" % ( entry_id )
            # Delete Flag Drops if any (due to dirty BD this is an easy way to make some cleanup on BG round start, shall be removed if DB is ok)
            #if entry_id == co.BATTLEGROUND_ALLIANCE_FLAG_DROP or entry_id == co.BATTLEGROUND_HORDE_FLAG_DROP or entry_id == co.BATTLEGROUND_HORDE_FLAG or entry_id == co.BATTLEGROUND_ALLIANCE_FLAG: go.Die()
            if entry_id == co.BATTLEGROUND_ALLIANCE_FLAG_DROP or entry_id == co.BATTLEGROUND_HORDE_FLAG_DROP: 
                go.Die()
                continue
                
            if go.GetType() == co.GO_TYPE_DOOR and ( go.GetFlags() == 32 or go.GetFlags() == 34 ):
                # Open door (33 - open door, 34 - close door)
                go.SetFlags(33)
                go.SetState(0)
    '''
            
            
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Called by core on every Round End
def OnBattleGroundRoundEnd(instance_id, map_id):

    print "OnBattleGroundRoundEnd: instance[%d] map[%d]" % (instance_id, map_id)

    '''
    text = "|cdf20af20Round has ended! You have 2 minutes to leave Battlefield..."
    SendBattleGroundMessage(text, co.SIDE_ALL_MASK, instance_id)
    
    # Warsong Gulch (close Doors)
    
    if map_id == 489:
        
        go_list = GetInstanceGOList(instance_id)
        
        for go in go_list:
            if go == NULL: continue
            
            entry_id = go.GetEntry()
            
            print "GetInstanceGOList: found GameObject[%d]" % ( entry_id ) 
            
            #if entry_id == 179918: 
            if go.GetType() == co.GO_TYPE_DOOR and go.GetFlags() == 33:
                # Open door (33 - open door, 34 - close door)
                go.SetFlags(34)
                go.SetState(1)
    '''
                
                
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Called by core on every instance init
def OnInstanceInit(instance, instance_id, map_id):

    print "OnInstanceInit: instance[%d] map[%d]" % (instance_id, map_id)
    
    
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Called by core when it ries to find correct Grave for MapId
def GetGraveIdByMapId(map_id):
     
     print "GetGraveIdByMapId: map[%d]" % (map_id)

     # to-do: add WorldSafeLoc.dbc Ids according MapIds
     # Graveyard ids for most instances (not new Outland) by TRat
     if map_id == 33: return 97
     elif map_id == 34: return 1
     elif map_id == 35: return 1
     elif map_id == 36: return 4
     elif map_id == 43: return 10
     elif map_id == 44: return 289
     elif map_id == 47: return 229
     elif map_id == 48: return 92
     elif map_id == 70: return 8
     elif map_id == 90: return 101
     elif map_id == 109: return 108
     elif map_id == 129: return 229
     elif map_id == 189: return 96
     elif map_id == 209: return 209
     elif map_id == 229: return 632
     elif map_id == 230: return 632
     elif map_id == 249: return 631
     elif map_id == 289: return 869
     elif map_id == 309: return 389
     elif map_id == 329: return 510
     elif map_id == 349: return 31
     elif map_id == 369: return 1
     elif map_id == 389: return 33
     elif map_id == 409: return 632
     elif map_id == 429: return 849
     elif map_id == 469: return 632
     elif map_id == 509: return 910
     elif map_id == 531: return 910
     elif map_id == 533: return 510
     
     return 0
    
#------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
# Called by core when it ries to find correct Grave for MapId
def GetInstanceRequirements(map_id):

    print "GetInstanceRequirements: map[%d]" % (map_id)    
    
    result = 1,70,1,40,0,0

    # if all set to 0 instance will get disabled for players entrance
    # info from LFGdungeons.dbc
    # 1 	 ID 	 Integer 	 	
    #2 	sRefName 	String 		Area/Instance (zone) name
    #3-10 	Localization 	String* 		
    #11 	level_min 	Integer 		Minimum level to participate.
    #12 	level_max 	Integer 		Maximum level when this dungeon becomes trivial.
    #13 	Unknown 	Integer 		Grouping of some type (5 = Battleground, 4 = Normal world zones? , 2 = Raid, 1 = 5 man)?
    #14 	faction 	Integer 		Faction type to participate. -1 all; 0 horde; 1 alliance;
    #15 	Unknown 	Integer 	5965 	
    #16 	Unknown 	Boolean* 	5965 	Does this just denote it's part of TBC or a toggle of some kind? 
    #ok this is info from dbc only still dont know whats last collumn?   
    
    if map_id == 389: result = 13, 70, 1, 40, 0, 0  #Ragefire Chasm 
    elif map_id == 43: result = 15, 70, 1, 40, 0, 0  #Wailing Caverns
    elif map_id == 36: result = 15, 70, 1 ,40, 0, 0  #The Deadmines
    elif map_id == 33: result = 18, 70, 1 ,40, 0, 0  #Shadowfang Keep
    elif map_id == 34: result = 22, 70, 1, 40, 0, 0  #The Stockade
    elif map_id == 90: result = 24, 70, 1, 40, 0, 0  #Gnomeregan
    elif map_id == 47: result = 24, 70, 1, 40, 0, 0  #Razorfen Kraul
    elif map_id == 189: result = 29, 70, 1, 40, 0, 0  #The Scarlet Monastery+
    elif map_id == 129: result = 33, 70, 1, 40, 0, 0  #Razorfen Downs
    elif map_id == 70: result = 35, 70, 1, 40, 0, 0  #Uldaman 
    elif map_id == 209: result = 43, 70, 1, 40, 0, 0  #Zul'Farrak
    elif map_id == 349: result = 40, 70, 1, 40, 0, 0  #Maraudon 
    elif map_id == 230: result = 48, 70, 1, 40, 0, 0  #Blackrock Depths+ 
    elif map_id == 229: result = 52, 70, 1, 40, 0, 0  #Blackrock Spire+
    elif map_id == 429: result = 56, 70, 1, 40, 0, 0  #Dire Maul+ 
    elif map_id == 329: result = 56, 70, 1, 40, 0, 0  #Stratholme+  
    elif map_id == 289: result = 56, 70, 1, 40, 0, 0  #Scholomance 
    elif map_id == 249: result = 60, 70, 1, 40, 0, 0  #Onyxia's Lair 
    elif map_id == 309: result = 56, 70, 1, 40, 0, 0  #Zul'Gurub 
    elif map_id == 409: result = 60, 70, 1, 40, 0, 0  #Molten Core
    elif map_id == 469: result = 60, 70, 1, 40, 0, 0  #Blackwing Lair 
    elif map_id == 509: result = 60, 70, 1, 40, 0, 0  #Ruins of Ahn'Qiraj  
    elif map_id == 531: result = 60, 70, 1, 40, 0, 0  #Temple of Ahn'Qiraj     
    elif map_id == 530: result = 70, 77, 1, 40, 0, 0  #Auchindoun      
    elif map_id == 532: result = 70, 77, 1, 40, 0, 0  #Karazhan  
    elif map_id == 48: result = 20, 70, 1, 40, 0, 0   #Blackfathom Deeps
    elif map_id == 109: result = 44, 70, 1, 40, 0, 0  #Sunken Temple
    elif map_id == 533: result = 60, 70, 1, 40, 0, 0  #Naxxramas
    elif map_id == 560: result = 70, 77, 1, 40, 0, 0  #Hyjal
    
    return result
    
# -- EOF --
 
