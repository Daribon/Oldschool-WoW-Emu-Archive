# COPYRIGHT (C) 2006 LUDMILLA TEAM
from Ludmilla import *          # Import server environment
from random import *            # Randomiser Import
import config as cfg            # Import of configuration constants
reload(cfg)  
import consts as co             # Import of constants reload(co)    
reload(co)               
import const_skills as skill_co # Import of constants (skills)
reload(skill_co)  
import const_spells as spell_co # Import of constants (skills)
reload(spell_co)  
import const_spellname as spell_name # Import of constants (spell_name)
reload(spell_name) 
import player_class as player_cls
reload(player_cls) 

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE

# ####################################################################################
# called by core before any Affects were removed
def OnUnitDeath(unit, killer):
    print "OnUnitDeath: unit[%s] killer[%s]" % (unit.GetName(), killer.GetName())
    
    if unit.IsPlayer():
        # BattleGround Support
        if unit.isInBG(): player_cls.OnBattleGroundFlagDrop(unit)

        #Fix for soulstone    
        if unit.HasAffect( spell_name.SPELL_ID_SOULSTONE_RESURRECTION ):
            unit.ResurrectPlayer(TRUE, TRUE)
            unit.SetHealth(400)
            unit.SetMana(700)
        elif unit.HasAffect( spell_name.SPELL_ID_SOULSTONE_RESURRECTION_1 ):
            unit.ResurrectPlayer(TRUE, TRUE)
            unit.SetHealth(750)
            unit.SetMana(1200)
        elif unit.HasAffect( spell_name.SPELL_ID_SOULSTONE_RESURRECTION_2 ):
            unit.ResurrectPlayer(TRUE, TRUE)
            unit.SetHealth(1100)
            unit.SetMana(1700)
        elif unit.HasAffect( spell_name.SPELL_ID_SOULSTONE_RESURRECTION_3 ):
            unit.ResurrectPlayer(TRUE, TRUE)
            unit.SetHealth(1600)
            unit.SetMana(2200)
            unit.RemoveSpell(20764)
        elif unit.HasAffect( spell_name.SPELL_ID_SOULSTONE_RESURRECTION_4 ):
            unit.ResurrectPlayer(TRUE, TRUE)
            unit.SetHealth(2100)
            unit.SetMana(2700)
    if killer.IsPlayer():
        # fix for SoulShard
        if killer.GetClass() == co.CLASS_WARLOCK and killer.GetLevel() >= 60 <= unit.GetLevel() + 5 :
            if unit.HasAffect( spell_name.SPELL_ID_DRAIN_SOUL_RANK_1 ) or \
               unit.HasAffect( spell_name.SPELL_ID_DRAIN_SOUL_RANK_2 ) or \
               unit.HasAffect( spell_name.SPELL_ID_DRAIN_SOUL_RANK_3 ) or \
               unit.HasAffect( spell_name.SPELL_ID_DRAIN_SOUL_RANK_4 ) or \
               unit.HasAffect( spell_name.SPELL_ID_DRAIN_SOUL_RANK_5 ): 
               killer.CastSpell(killer, spell_name.SPELL_ID_CREATE_SOUL_SHARD)

# ####################################################################################
# called by core 
def OnUnitStealth(unit):
    print "OnUnitStealth: unit[%s]" % (unit.GetName())
    if unit.IsPlayer():
#      unit.ModSpeed(10)
        # BattleGround Support
        if unit.isInBG(): player_cls.OnBattleGroundFlagDrop(unit)
    
    
# ####################################################################################

# called by core 
def OnUnitMount(unit):
    print "OnUnitMount: unit[%s]" % (unit.GetName())
    
    if unit.IsPlayer():
        # BattleGround Support
        if unit.isInBG(): player_cls.OnBattleGroundFlagDrop(unit)

            
# ####################################################################################
# called by core 
def OnUnitImmunity(unit):
    print "OnUnitImmunity: unit[%s]" % (unit.GetName())
    
    if unit.IsPlayer():
        # BattleGround Support
        if unit.isInBG(): player_cls.OnBattleGroundFlagDrop(unit)
        
# -- EOF --
