﻿from consts import *                            # Import of constants
# Define weather for different zones here, available types are
#
zones = {
             1    : WEATHER_TYPE_SNOW,       #Dun Morogh
             12   : WEATHER_TYPE_RAIN,       #Elwynn Forest
             33   : WEATHER_TYPE_RAIN,       #Stranglethorn Vale
             36   : WEATHER_TYPE_SNOW,       #Alterac Mountains
             85   : WEATHER_TYPE_RAIN,       #Tirisfal Glades
             148  : WEATHER_TYPE_RAIN,       #Darkshore
             357  : WEATHER_TYPE_RAIN,       #Feralas
             440  : WEATHER_TYPE_SANDSTORM,  #Tanaris
             490  : WEATHER_TYPE_RAIN,       #Un'Goro Crater
             618  : WEATHER_TYPE_SNOW,       #Winterspring
             1377 : WEATHER_TYPE_SANDSTORM } #Silithus

# Seasonal changes (WEATHER_TYPE_RAIN, WEATHER_TYPE_SNOW, WEATHER_TYPE_SANDSTORM)
spring = {   
             1    : [  0, 45,  2 ],      #Dun Morogh
             12   : [ 30,  0,  0 ],      #Elwynn Forest
             33   : [ 30,  0,  0 ],      #Stranglethorn Vale
             36   : [  2, 45,  2 ],      #Alterac Mountains
             85   : [ 50,  0,  0 ],      #Tirisfal Glades
             148  : [  5,  0,  1 ],      #Darkshore
             357  : [ 30,  0,  0 ],      #Feralas
             440  : [  0,  0, 20 ],      #Tanaris
             490  : [ 40,  0,  0 ],      #Un'Goro Crater
             618  : [  0, 40,  0 ],      #Winterspring
            1377  : [  0,  0, 20 ] }     #Silithus
summer = {                       
             1    : [  0, 30,  1 ],      #Dun Morogh
             12   : [ 30,  0,  0 ],      #Elwynn Forest
             33   : [ 40,  0,  0 ],      #Stranglethorn Vale
             36   : [ 12, 30,  1 ],      #Alterac Mountains
             85   : [ 67,  0,  0 ],      #Tirisfal Glades
             148  : [ 20,  0,  1 ],      #Darkshore
             357  : [ 50,  0,  0 ],      #Feralas
             440  : [  0,  0, 30 ],      #Tanaris
             490  : [ 40,  0,  0 ],      #Un'Goro Crater
             618  : [  0, 25,  0 ],      #Winterspring
            1377  : [  0,  0, 30 ] }     #Silithus
fall = {                         
             1    : [  0, 53,  0 ],      #Dun Morogh
             12   : [ 50,  0,  2 ],      #Elwynn Forest
             33   : [ 60,  0,  0 ],      #Stranglethorn Vale
             36   : [ 13, 53,  0 ],      #Alterac Mountains
             85   : [ 71,  0,  0 ],      #Tirisfal Glades
             148  : [ 12,  0,  1 ],      #Darkshore
             357  : [ 60,  0,  0 ],      #Feralas
             440  : [  0,  0, 50 ],      #Tanaris
             490  : [ 50,  0,  0 ],      #Un'Goro Crater
             618  : [  0, 35,  0 ],      #Winterspring
            1377  : [  0,  0, 50 ] }     #Silithus
winter = {                       
             1    : [  0, 90,  0 ],      #Dun Morogh
             12   : [  4,  0,  0 ],      #Elwynn Forest
             33   : [ 70,  0,  0 ],      #Stranglethorn Vale
             36   : [  0, 90,  0 ],      #Alterac Mountains
             85   : [ 50, 30,  0 ],      #Tirisfal Glades
             148  : [ 24,  0,  1 ],      #Darkshore
             357  : [ 50,  1,  0 ],      #Feralas
             440  : [  0,  0, 30 ],      #Tanaris
             490  : [ 50,  0,  0 ],      #Un'Goro Crater
             618  : [  0, 65,  0 ],      #Winterspring
            1377  : [  0,  0, 30 ] }     #Silithus

def_sound = { 
             WEATHER_TYPE_RAIN : [WEATHER_SOUND_RAIN_LIGHT, WEATHER_SOUND_RAIN_MEDIUM, WEATHER_SOUND_RAIN_HEAVY],
             WEATHER_TYPE_SNOW : [WEATHER_SOUND_SNOW_LIGHT, WEATHER_SOUND_SNOW_MEDIUM, WEATHER_SOUND_SNOW_HEAVY],
             WEATHER_TYPE_SANDSTORM : [WEATHER_SOUND_SANDSTORM_LIGHT, WEATHER_SOUND_SANDSTORM_MEDIUM, WEATHER_SOUND_SANDSTORM_HEAVY]}

wtypes = { 
             WEATHER_TYPE_NORMAL    :"NORMAL",
             WEATHER_TYPE_RAIN      :"RAIN",
             WEATHER_TYPE_SNOW      :"SNOW",
             WEATHER_TYPE_SANDSTORM :"SANDSTORM" }

wlist = {0:[0,0,0]} # Had to assign weather to variable, since core doesn't respond to GetWeather() correctly
