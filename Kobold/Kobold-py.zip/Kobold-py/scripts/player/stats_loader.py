#!/usr/bin/python

import sys
import consts as co     # Import of constants
reload(co)   

ENABLE = TRUE = 1
DISABLE = FALSE = NULL = 0

TYPE_ID__HEALTH = 0
TYPE_ID__MANA = 1

print "  o -- o Health Level Up Reader"

# -------------------------------------------------------------------------------------------------------------------------------------------------------------------
def IsRequestedRaceHeader(race_text, race_id):

    print "[%s][%d]" % (race_text, race_id)
    
    if race_text == "RACE_HUMAN"       and race_id == co.RACE_HUMAN:       return TRUE
    if race_text == "RACE_ORC"         and race_id == co.RACE_ORC:         return TRUE
    if race_text == "RACE_DWARF"       and race_id == co.RACE_DWARF:       return TRUE
    if race_text == "RACE_NIGHT_ELF"   and race_id == co.RACE_NIGHT_ELF:   return TRUE
    if race_text == "RACE_UNDEAD"      and race_id == co.RACE_UNDEAD:      return TRUE
    if race_text == "RACE_TAUREN"      and race_id == co.RACE_TAUREN:      return TRUE
    if race_text == "RACE_GNOME"       and race_id == co.RACE_GNOME:       return TRUE
    if race_text == "RACE_TROLL"       and race_id == co.RACE_TROLL:       return TRUE
    if race_text == "RACE_BLOOD_ELF"   and race_id == co.RACE_BLOOD_ELF:   return TRUE
    if race_text == "RACE_DRAENEI"     and race_id == co.RACE_DRAENEI:     return TRUE
    
    return FALSE
    
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------
def ConvertClass(class_id):

    if class_id == co.CLASS_WARRIOR:    return 0
    if class_id == co.CLASS_PALADIN:    return 1
    if class_id == co.CLASS_HUNTER:     return 2
    if class_id == co.CLASS_ROGUE:      return 3
    if class_id == co.CLASS_PRIEST:     return 4
    if class_id == co.CLASS_SHAMAN:     return 5
    if class_id == co.CLASS_MAGE:       return 6
    if class_id == co.CLASS_WARLOCK:    return 7
    if class_id == co.CLASS_DRUID:      return 8


# -------------------------------------------------------------------------------------------------------------------------------------------------------------------
def GetValueFromBlock(f, size, level, class_id):
    
    value = 0.0

    #normalize index for level
    level -= 1
    class_find_pos = ConvertClass(class_id)
    
    if level >= size:
        print "GetValueFromBlock: index is out of array"
        return 0
    
    for i in range(size):

        line = f.readline()
        line = line.strip()
       
        if i == level:

            #convert
            array = line.split(';')

            class_pos = 0
            for str_itr in array:

                if class_find_pos == class_pos:
                    value = eval(str_itr)
                    return value
            
                class_pos += 1
                                   
    return value
    
# -------------------------------------------------------------------------------------------------------------------------------------------------------------------
def GetValuePerLevel(type_id, race_id, class_id, level):
    
    filename = ""
    
    if type_id == TYPE_ID__HEALTH:  filename = ".\scripts\player\health_per_level.csv"
    if type_id == TYPE_ID__MANA:    filename = ".\scripts\player\mana_per_level.csv"
    
    try:
        f = open(filename,"rb")
    except:
        print "GetValuePerLevel: file[%s] is not found" % (filename)
        return 0
    
    counter = 0
    header = ""
    line = ""
    found_data = FALSE
    
    data_block = []
    
    #Find block header
    try:
        while TRUE:

            # get header
            line = f.readline()
            line = line.replace(';',' ')
            line = line.strip()
            line = line.upper()
            if line == "": break
            if line != "#HEAD#": continue

            # get name
            line = f.readline()
            line = line.replace(';',' ')
            line = line.strip()
            line = line.upper()
  
            # try finding our header
            if IsRequestedRaceHeader(line, race_id) == TRUE:
                found_data = TRUE
                break
    except:
        f.close()
        print "GetValuePerLevel: wrong file format"
        return 0

    if found_data == FALSE:
        print "GetValuePerLevel: could not find data"
        f.close()
        return 0
    
    value = GetValueFromBlock(f, 60, level, class_id)

    print ">>> V[%f] INPUT[R-%d C-%d LVL-%d]" % (value, race_id, class_id, level)
    f.close()
    
    return value
