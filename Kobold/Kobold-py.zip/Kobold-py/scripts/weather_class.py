# This file contains functions for weather
from Ludmilla import *                # Import Ludmilla namespace
from time import localtime
from random import *                  # Import random generator module
import consts as co                   # Import of constants
reload(co)             
import config as cfg                  # Import of configuration constants
reload(cfg) 
import const_weather as weatherzones  # Import of weather constants
reload(weatherzones)  

printLog("  o Registering Weather Changer")
# ####################################################################################
# Global weather scripts all world zones
#        weather constants can be found in const_weather.py

def UpdateWeather (zoneid, weather):
    if cfg.ENABLE_AUTO_WEATHER == co.FALSE: return
             
    WEATHER_CHANCE = cfg.WEATHER_CAST_CHANCE
    TYPE_CHANCE    = cfg.WEATHER_TYPE_CHANCE

    # build weather variable, since core doesn't return correctly
    if weatherzones.wlist.has_key(zoneid) == 0 :
        weatherzones.wlist[zoneid]=[0,0,0]

    # load weather data from memory 
    old_key      = weatherzones.wlist.get(zoneid)
    old_type     = old_key[0]
    old_amount   = old_key[1]
    old_sound    = old_key[2]

    new_type   = old_type
    new_amount = old_amount
    new_sound  = old_sound
    
    w_change = "No change"
    if (localtime()[3] in (6,7,20,21)) : #sunset and sunrise are foggy; localtime() gives local time. [3] will return hour
        w_change = "Twilight"
        new_type   = co.WEATHER_TYPE_RAIN
        new_amount = co.WEATHER_AMOUNT_FOG
        new_sound  = co.WEATHER_SOUND_NO_SOUND
    else:  
        if WEATHER_CHANCE > randrange(100):

            # Change type occasionaly
            if TYPE_CHANCE > randrange(100) and new_type == co.WEATHER_TYPE_NORMAL: 

                # get default weather according zone
                new_type = ChangeWeather_Type(zoneid)
                w_change = "Changed to"
                new_amount = 0.5 # set initial intensity for new weather

            elif new_type : #change amount if type not NORMAL
                
                # force amount for designated fog area's (fog is state of rain), 25% change to return from fog
                if zoneid in(490,33) :
                    w_change = "Forced fog"
                    new_amount = co.WEATHER_AMOUNT_FOG 
                    if 25 > randrange(100): new_type == co.WEATHER_TYPE_NORMAL
                # Remove fog from other area's (after twilight)
                elif new_amount == co.WEATHER_AMOUNT_FOG:
                    new_amount = 0
                else:
                    new_amount = ChangeWeather_Amount( old_amount )
                    if new_amount > old_amount : 
                        w_change = "Increased"
                    else:
                        w_change = "Decreased"
                      
            # Change to sunny if amount 0 reached
            if new_amount == 0 : 
                new_type = co.WEATHER_TYPE_NORMAL
                w_change = "Return to"
                new_amount = co.WEATHER_AMOUNT_NULL
    
            new_sound = ChangeWeather_Sound (new_type, new_amount)

    print "Weather forcast: %s %s for zone[%d] amount[%f] sound[%s]" % ( w_change, weatherzones.wtypes.get(new_type), zoneid, new_amount, str(new_sound))

    # store current weather data in memory 
    weatherzones.wlist[zoneid]=[new_type, new_amount, new_sound]

    #Cast weather    
    weather.SetWeatherType( new_type )
    weather.SetWeatherAmount( new_amount )
    weather.SetWeatherSound( new_sound )
    weather.UpdateWeatherChanges()

def ChangeWeather_Type(zoneid):

    # get default weather type for given zone
    # to do --> seasonal weather changes ? :p
    new_type = weatherzones.zones.get(zoneid)
    return new_type
    
def ChangeWeather_Amount ( c_amount):

    # random steps of 0.10 - 0.19
    w_change = (randrange(99)+ 100.00)/1000

    # night time max is limited a bit (medium sound level)
    if (localtime()[3]) not in range(7,22):
      max_amount = 0.99
    else:
      max_amount = 0.70

    # random increase(35%) or decrease(65%); weather will return to normal when 0 reached
    if randrange(100) > 65 or c_amount == max_amount :
        new_amount = max((c_amount - w_change),0)
    else:
        new_amount = min((c_amount + w_change),max_amount)
    return new_amount
    
def ChangeWeather_Sound (c_type, c_amount):

    # no sound on sunny weather
    if c_type == co.WEATHER_TYPE_NORMAL: return co.WEATHER_SOUND_NO_SOUND
 
    # get default sounds according weather type
    new_sounds = weatherzones.def_sound.get(c_type)

    if c_amount <= 0.20 : # no sound below this (same as FOG level)
       new_sound = co.WEATHER_SOUND_NO_SOUND
    elif c_amount <= 0.40 :     
      new_sound = new_sounds[0] #light sound
    elif c_amount <= 0.70 :     
      new_sound = new_sounds[1] #medium sound
    else:                       
      new_sound = new_sounds[2] #heavy sound
    return new_sound

# -- EOF --

