# COPYRIGHT (C) 2006 LUMDILLA TEAM
from Ludmilla import *
from random import *
from consts import *
import config as cfg            # Import of configuration constants
reload(cfg)  
import consts as co             # Import of constants
reload(co)   
import support as support # Import of constants (support)
reload(support) 

ENABLE = TRUE = co.TRUE
DISABLE = FALSE = NULL = co.FALSE  

""" This module is used for Functions which return Values to core.
"""

# CalcXP used to calculate XP given by killing Creature
printLog (" o Setting up Core Supporting Modules :")
printLog ("   -> Registering XP module")

def CalcXP(self, victim):    # For use in Server Environment

    # SET GLOBAL CONSTANTS #####################
    # Define Maximum Player Level
    MAXPLAYERLVL =          cfg.XP_MAXPLAYERLVL

    # Random XP gains / losses in 5% amount of XP (1 - Yes, 0 - No)
    XPRAND =                cfg.XP_XPRAND            # Toggles ON/OFF (1/0) XP randomising function            
    RANDXPPERC =            cfg.XP_RANDXPPERC         # Given in Percent (%)

    # Define XP Rate
    XPRATE =                cfg.XP_XPRATE             # Overall XP rate
    DMGXPRATE =             cfg.XP_DMGXPRATE          # XP rate per mob damage point/used for ELITEs only
    MAXLVLUP =              cfg.XP_MAXLVLUP           # Maximum level-up allowed for each kill
    MAXXP =                 cfg.XP_MAXXP              # Maximum gain XP
    XPACCELERATOR =         cfg.XP_XPACCELERATOR      # XP Rate Accelerator, must be ZERO for Player Level min 20 (used to avoid linear dependence)

    # DEBUGGING ################################
    #
    # Logging to server screen (1 - Yes, 0 - No)
    LOG =                   cfg.XP_LOG
    #
    ENTRY =                 victim.GetEntry()

    VICTIM_CREATURE_TYPE =  victim.GetNpcType()
    PLAYERLEVEL =           self.GetLevel()
    MOBLEVEL =              victim.GetLevel()
    ELITE =                 victim.GetElite()
    MOBMINDAMAGE =          victim.GetMinDamage()
    MOBMAXDAMAGE =          victim.GetMaxDamage()
    NPCFLAGS =              victim.GetNpcFlags()

    # INITIAL CHECKS ############################

    if ENTRY == 6491 or \
       ENTRY == 1 or \
       ENTRY == 99999999 or \
       PLAYERLEVEL >= MAXPLAYERLVL or \
       VICTIM_CREATURE_TYPE == 8: return 0

    
    # XP CALCULATOR  ############################
    # Zero Diffrence point #############################

    if         PLAYERLEVEL  <= 9: g = 5.0
    elif 10 <= PLAYERLEVEL <= 20: g = 6.0
    elif 20 <= PLAYERLEVEL <= 29: g = 7.0
    elif 30 <= PLAYERLEVEL <= 39: g = 8.0
    elif 40 <= PLAYERLEVEL <= 44: g = 9.0
    elif 45 <= PLAYERLEVEL <= 49: g = 10.0
    elif 50 <= PLAYERLEVEL <= 54: g = 11.0
    elif 55 <= PLAYERLEVEL <= 70: g = 12.0


    if         PLAYERLEVEL <= 7 : z = 5.0
    elif  8 <= PLAYERLEVEL <= 9 : z = 6.0
    elif 10 <= PLAYERLEVEL <= 11: z = 7.0
    elif 12 <= PLAYERLEVEL <= 15: z = 8.0
    elif 16 <= PLAYERLEVEL <= 19: z = 9.0
    elif 20 <= PLAYERLEVEL <= 29: z = 11.0
    elif 30 <= PLAYERLEVEL <= 39: z = 12.0
    elif 40 <= PLAYERLEVEL <= 44: z = 13.0
    elif 45 <= PLAYERLEVEL <= 49: z = 14.0
    elif 50 <= PLAYERLEVEL <= 54: z = 15.0
    elif 55 <= PLAYERLEVEL <= 59: z = 16.0
    elif 60 <= PLAYERLEVEL <= 70: z = 17.0

    if   MOBLEVEL == PLAYERLEVEL:
      XP = ((PLAYERLEVEL * 5) + 45)
    elif MOBLEVEL >  PLAYERLEVEL:
      XP = ((PLAYERLEVEL * 5) + 45) * (1.00 + 0.25 * (MOBLEVEL - PLAYERLEVEL))
    else:
      if (PLAYERLEVEL - MOBLEVEL) < g:
        XP = (PLAYERLEVEL * 5 + 45) * (1 - float((PLAYERLEVEL-MOBLEVEL)/z))
      else: XP = 0

        
    # XP RATE ACCELERATOR ########################
    if   20 < PLAYERLEVEL < 40:   XPACCELERATOR = 0.05
    elif 40 < PLAYERLEVEL < 60:   XPACCELERATOR = 0.10
    elif 60 < PLAYERLEVEL < 80:   XPACCELERATOR = 0.15
    elif 80 < PLAYERLEVEL < 100:  XPACCELERATOR = 0.20
    XPRATE += XPACCELERATOR
    # ######################################
        
    # MODIFIER ACC. CREATURE ELITE ############################
    DXP = MOBLEVEL * DMGXPRATE * 10
    if      ELITE == 0:                            DXP = 0
    elif    ELITE == co.CREATURE_ELITE_ELITE:      DXP *= 1.5
    elif    ELITE == co.CREATURE_ELITE_RAREELITE:  DXP *= 3
    elif    ELITE == co.CREATURE_ELITE_WORLDBOSS:  DXP *= 10
    elif    ELITE == co.CREATURE_ELITE_RARE:       DXP *= 7
    XP += DXP
        
    # MODIFIER ACCORDING CREATURE TYPE #########################
    if   VICTIM_CREATURE_TYPE == co.CREATURE_TYPE_DRAGONSKIN or \
         VICTIM_CREATURE_TYPE == co.CREATURE_TYPE_GIANT or \
         VICTIM_CREATURE_TYPE == co.CREATURE_TYPE_MECHANICAL or \
         VICTIM_CREATURE_TYPE == co.CREATURE_TYPE_NOTSPECIFIED:         XP *= 1.4

    elif VICTIM_CREATURE_TYPE == co.CREATURE_TYPE_DEMON or \
         VICTIM_CREATURE_TYPE == co.CREATURE_TYPE_ELEMENTAL:            XP *= 1.2
     
    # APPLYING XP RATE
    XP *= XPRATE

    # Subtracts or adds random XP value in range of -5% to +4.99% of XP gained till this stage.
    if MOBLEVEL > 15:
        RANDXPPERC = RANDXPPERC / 100
        if XPRAND: XP += uniform(XP * -RANDXPPERC, XP * RANDXPPERC)
    # ####################################################

    if XP > MAXXP: XP = MAXXP
    if XP <= 0: return 0
    
    # LVL-UP MODULE ############################
    MAXLVLUP -= 1
    N = PLAYERLEVEL + MAXLVLUP
    A = N / 10
    X = N % 10

    # These statistics are extracted from WAD's Level-Up XP rate
    # Need to refer and change to the official stats
    if   X == 1 : Cx = 0
    elif X == 2 : Cx = 0
    elif X == 3 : Cx = 0.5
    elif X == 4 : Cx = 1
    elif X == 5 : Cx = 2
    elif X == 6 : Cx = 3
    elif X == 7 : Cx = 4
    elif X == 8 : Cx = 5.5
    elif X == 9 : Cx = 7
    elif X == 0 : Cx = 9

    Tn = A * ( N - 1 )
    M = (N * ( A + 1 )) + Tn + Cx

    LVLUPXP = 400 * M
    if XP > LVLUPXP: XP = LVLUPXP
    
    # Round XP
    XP = int(XP) 
    
    # SERVER LOG ############################
    if LOG:
        printLog ("CalcXP: |mID: %s |mLVL: %s |mTYP: %s |mELT: %s |pLVL: %s |XP: %s |" % \
              (ENTRY, MOBLEVEL, VICTIM_CREATURE_TYPE, ELITE, PLAYERLEVEL, XP) )
   
    #Returns XP to Core ############################
    return XP
# ###########################################################################################
# CalcGroupXP used to calculate XP given by killing Creature in group
printLog (" o Setting up Core Supporting Modules :")
printLog ("   -> Registering XP Group module")
def CalcGroupXP(group, victim):    # For use in Server Environment

    member_list = group.GetMemberList()
    
    summ_level = 0
    highest_lvl_member = None
    group_size = 0
    
    # Collect information
    for mem_itr in member_list:

        lvl = mem_itr.GetLevel()
        summ_level += lvl # get level's summ
        
        # get highest level member saved
        if highest_lvl_member is not None:
           if lvl > highest_lvl_member.GetLevel(): highest_lvl_member = mem_itr 
        else:
           highest_lvl_member = mem_itr
            
        group_size += 1 # count members
    
    # Check
    if highest_lvl_member is None: return
    if summ_level == 0: return
    
    # Get total XP
    full_xp = CalcXP(highest_lvl_member, victim)
    
    # Distribute XP
    for mem_itr in member_list:
        
        my_xp = full_xp * mem_itr.GetLevel() / summ_level
        
        if mem_itr.isDead() == FALSE:

          mem_itr.GiveXP(my_xp, victim)
        
        # give same ammount to charmed pet
        pet = mem_itr.GetPet()
        if pet is not None:
            if pet.IsCharmed():
                pet.GiveXP(my_xp, victim)
        
        # SERVER LOG ############################
        if cfg.XP_LOG:
            print "CalcGroupXP: |GroupSize: %s |Highest: %s |MyXP: %s " % (group_size, highest_lvl_member.GetLevel(), my_xp)    
        
# ###########################################################################################
# CalcExplorationXP used to calculate exploration XP
print "   -> Registering Exploration XP calculating module"

def CalcExplorationXP (player, area_id, area_level): 
    if area_id == 0: return 0 
    print "CalcExplorationXP: player[%s] area[%d] area_level[%d]" % (player.GetName(), area_id, area_level)
    
    XP = 0
    
    if player.GetLevel() < (area_level - 5):
        percent = 100 - (((player.GetLevel() - area_level) - 5)*5)
        if percent < 0:     percent = 0
        if percent > 100:   percent = 100
        XP = (GetAreaBaseXP(area_level) * percent) / 100
    
    elif player.GetLevel() > (area_level + 5):
        XP = GetAreaBaseXP(player.GetLevel() + 5)
    
    else:
        XP = GetAreaBaseXP(area_level)

    # APPLYING XP RATE
    XP *= cfg.XP_XPRATE
    
    return XP
    
# ###########################################################################################
# GetAreaBaseXP returns base Area XP values
def GetAreaBaseXP (area_level):
    basexp = { 1:5  ,  2:15 ,  3:25 , 4:35  ,  5:45 ,  6:55 ,  7:65 ,  8:70 ,  9:80 
            , 10:85 , 11:90 , 12:90 , 13:90 , 14:100, 15:105, 16:115, 17:125, 18:135
            , 19:145, 20:155, 21:165, 22:175, 23:185, 24:195, 25:200, 26:210, 27:220
            , 28:230, 29:240, 30:245, 31:250, 32:255, 33:265, 34:270, 35:275, 36:280
            , 37:285, 38:285, 39:300, 40:315, 41:330, 42:345, 43:360, 44:375, 45:390
            , 46:405, 47:420, 48:440, 49:455, 50:470, 51:490, 52:510, 53:530, 54:540
            , 55:560, 56:580, 57:600, 58:620, 59:640, 60:660, 61:680, 62:700, 63:720
            , 64:740, 65:760 }
    
    return basexp.get(area_level,50)

# ###########################################################################################
# CalcDR used to calculate DAMAGE REDUCTION (Debug mode, will later be moved to core) 
printLog ("   -> Registering Damage Reduction (DR) module") 
def CalcDR (self, attacker): 

    damage_reduction = 0.0
    
    if (self.IsPlayer() == co.TRUE) and (attacker.IsPlayer() == co.FALSE):
        damage_reduction += GetDRPlayerVsCreature(self, attacker)
 
    elif (self.IsPlayer() == co.TRUE) and (attacker.IsPlayer() == co.TRUE):
        damage_reduction += GetDRPlayerVsPlayer(self, attacker)
    
    elif (self.IsPlayer() == co.FALSE) and (attacker.IsPlayer() == co.FALSE):
        damage_reduction += GetDRCreatureVsCreature(self, attacker)
   
    if damage_reduction > 75.0: damage_reduction = 75.0
    if damage_reduction < 0: damage_reduction = 0

    return damage_reduction

# Creature(pet and guards) versus Creature claculations
def GetDRCreatureVsCreature (self, attacker):

     # DEBUGGING ################################ 
    # 
    # Logging to server screen (1 - Yes, 0 - No) 
    LOG =       cfg.DR_LOG

    attacker_level = attacker.GetLevel()
    mob_armor = self.GetArmorWithMods()
    
    dr = 0.0
    dr = mob_armor / ((85.0 * attacker_level) + mob_armor + 400.0)
    
    # Convert to Real %
    dr *= 100.0
        
    if LOG: 
        print "CalcDR: a_lvl[%d] m_a[%d] | DR[%f]" % (attacker_level, mob_armor, dr)  
        
    # Returns DR
    return dr     
    
# Player versus Creature claculations
def GetDRPlayerVsCreature (self, attacker): 

    # DEBUGGING ################################ 
    # 
    # Logging to server screen (1 - Yes, 0 - No) 
    LOG =       cfg.DR_LOG 
    
    # Define constant / limitation 
    GMLVL =     cfg.DR_GMLVL 
    MAXLVL =    cfg.DR_MAXLVL  
    
    # Mob Settings 
    ENTRY =     attacker.GetEntry() 
    MOBLEVEL =  attacker.GetLevel() 
    
    # Player Settings 
    PLAYERLEVEL =   self.GetLevel() 
    ARMOR =         self.GetArmorWithMods() 
    
    # --------------------------------------------------------------------------------------------------- 
    
    if MOBLEVEL > 65:           MOBLEVEL = 80 
    

    #if PLAYERLEVEL >= GMLVL:    return 1.0 
    if MAXLVL > 70:             MAXLVL = 70 

    if PLAYERLEVEL >= GMLVL :    return 100 

    if PLAYERLEVEL > MAXLVL:    PLAYERLEVEL = MAXLVL 
    
    DR = 0.0
    DR = ARMOR / ((85.0 * MOBLEVEL) + ARMOR + 400.0) #<- This (and only) formula must work also when a player hit a mob, so in that case the ARMOR value become the armor of the mob. 
  
    # Convert to Real %
    DR *= 100.0
        
    if LOG: 
        print "CalcDR: |mID: %s |mLVL: %s |pLVL: %s |DR: %s |" % (ENTRY, MOBLEVEL, PLAYERLEVEL, DR)
        
    # Returns DR
    return DR 

# Player versus Player claculations
def GetDRPlayerVsPlayer (self, attacker): 

    # DEBUGGING ################################ 
    # 
    # Logging to server screen (1 - Yes, 0 - No) 
    LOG =       cfg.DR_LOG 

    attacker_level = attacker.GetLevel()
    victim_armor = self.GetArmorWithMods()
        
    dr = victim_armor / (victim_armor + 400.0 + 85.0 * attacker_level)
    
    # Convert to Real %
    dr *= 100.0
        
    if LOG: 
        print "CalcDR(PvP): a_lvl[%d] v_lvl[%d] v_a[%d] | DR[%f]" % (attacker_level, victim_level, victim_armor, dr)  
        
    # Returns DR
    return dr 

# ###########################################################################################
# Quest XP 
#now quests uses base xp collumn for quests bonus exp
def CalcQuestXP(player, quest_id, quest_behavior, quest_type, quest_level, base_xp):
        
        if   player.GetLevel() - quest_level ==  6 : base_xp *= 0.8
        elif player.GetLevel() - quest_level ==  7 : base_xp *= 0.6
        elif player.GetLevel() - quest_level ==  8 : base_xp *= 0.4
        elif player.GetLevel() - quest_level ==  9 : base_xp *= 0.2
        elif player.GetLevel() - quest_level >= 10 : base_xp *= 0.1 
        base_xp *= cfg.XP_XPRATE
        return int(base_xp)
## EOF ##
