# This file contains predefined Creatures type and family initialisations.
# Functions calculate onle once when DB is loaded and Creatures are precached to Server Environment.
# Health - Mana - Damage functions are intially taken from Kvakvs's great World-Lint

from Ludmilla import *  # Import server environment
from random import *        # Import random generator module
from math import *
import consts as _co_     # Import of constants
reload(_co_)   
import config as _cfg_    # Import of configuration constants
reload(_cfg_)  
import const_skills as _skillco_ # Import of constants (skills)
reload(_skillco_)  
import const_spells as _spellco_ # Import of constants (skills)
reload(_spellco_)  
import const_spellname as _spellname_ # Import of constants (_spellname_)
reload(_spellname_)  
import support as _support_ # Import of constants (support)
reload(_support_)  
import MySQLdb
conn = MySQLdb.connect (host = _cfg_.MYSQL_HOST, user = _cfg_.MYSQL_USER, passwd = _cfg_.MYSQL_PASSWD, db = _cfg_.MYSQL_DB)

ENABLE = TRUE = _co_.TRUE
DISABLE = FALSE = NULL = _co_.FALSE
# TYPE  ################################################################################

#---------------------------------------BEAST-----------------------------------------------------#
def Beast(c, mod):
    pass
    
#---------------------------------------CRITTER-----------------------------------------------------#
def Critter(c, mod):
    mod.SetManaMod(0)
    mod.SetDamageMod(0)

#---------------------------------------DEMON-----------------------------------------------------#
def Demon(c, mod):
    pass
    
#---------------------------------------DRAGON-----------------------------------------------------#
def Dragon(c, mod):
    pass
    
#---------------------------------------ELEMENTAL-----------------------------------------------------#
def Elemental(c, mod):
    pass
    
#---------------------------------------GIANT-----------------------------------------------------#
def Giant(c, mod):
    pass

#---------------------------------------HUMANOID-----------------------------------------------------#
def Humanoid(c, mod):
    pass
    
#---------------------------------------MECHANICAL-----------------------------------------------------#
def Mechanical(c, mod):
    pass

#---------------------------------------NOTSPECIFIED-----------------------------------------------------#
def NotSpecified(c, mod):
    mod.SetManaMod(0)
    
#---------------------------------------UNDEAD-----------------------------------------------------#
def Undead(c, mod):
    pass
    
#---------------------------------------UNSET-----------------------------------------------------#
def UnSet(c, mod):
    mod.SetManaMod(0)
    
    
# FAMILY  ################################################################################

#---------------------------------------BAT----------------------------------------------------------------------#
def Bat(c, mod):
    pass

#---------------------------------------BEAR---------------------------------------------------------------------#
def Bear(c, mod):

    mod.SetManaMod(0)
    
    # Attack time
    c.SetBaseAttackTime(_co_.AT_MELEE__MAINHAND, 2500)
    c.SetBaseAttackTime(_co_.AT_MELEE__OFFHAND, 2500)
    mod.is_attack_time_applied = TRUE
    
    # Base Damage
    c.SetBaseDamageMelee(_co_.AT_MELEE__MAINHAND, 1.0)
    c.SetBaseDamageMelee(_co_.AT_MELEE__OFFHAND, 1.0)
    
#---------------------------------------BOAR--------------------------------------------------------------------#
def Boar(c, mod):

    mod.SetManaMod(0)
    
    # Attack time
    c.SetBaseAttackTime(_co_.AT_MELEE__MAINHAND, 2500)
    c.SetBaseAttackTime(_co_.AT_MELEE__OFFHAND, 2500)
    mod.is_attack_time_applied = TRUE
    
    # Base Damage
    c.SetBaseDamageMelee(_co_.AT_MELEE__MAINHAND, 1.0)
    c.SetBaseDamageMelee(_co_.AT_MELEE__OFFHAND, 1.0)

#---------------------------------------CARRION BIRD--------------------------------------------------------#
def CarrionBird(c, mod):
    pass
    
#---------------------------------------CAT----------------------------------------------------------------------#
def Cat(c, mod):

    # Attack time
    c.SetBaseAttackTime(_co_.AT_MELEE__MAINHAND, 1000)
    c.SetBaseAttackTime(_co_.AT_MELEE__OFFHAND, 1000)
    mod.is_attack_time_applied = TRUE
    
    # Base Damage
    c.SetBaseDamageMelee(_co_.AT_MELEE__MAINHAND, 4.0)
    c.SetBaseDamageMelee(_co_.AT_MELEE__OFFHAND, 4.0)
    
#---------------------------------------CRAB---------------------------------------------------------------------#
def Crab(c, mod):
    pass
    
#---------------------------------------CROCILISK-------------------------------------------------------------#
def Crocilisk(c, mod):
    pass
    
#---------------------------------------GORILLA----------------------------------------------------------------#
def Gorilla(c, mod):
    pass
    
#---------------------------------------HYENA------------------------------------------------------------------#
def Hyena(c, mod):
    pass
#---------------------------------------OWL---------------------------------------------------------------------#
def Owl(c, mod):
    pass
#---------------------------------------RAPTOR----------------------------------------------------------------#
def Raptor(c, mod):
    pass
#---------------------------------------SCORPID--------------------------------------------------------------#
def Scorpid(c, mod):
    pass
#---------------------------------------SPIDER----------------------------------------------------------------#
def Spider(c, mod):
    pass
#---------------------------------------TALLSTRIDER-------------------------------------------------------#
def Tallstrider(c, mod):
    pass
#---------------------------------------TURTLE---------------------------------------------------------------#
def Turtle(c, mod):
    pass
#---------------------------------------WINDSERPENT-----------------------------------------------------#
def WindSerpent(c, mod):
    pass
#---------------------------------------RemoteControl-----------------------------------------------------#
def RemoteControl(c, mod):
    pass
#---------------------------------------Felguard-----------------------------------------------------#
def Felguard(c, mod):
    pass
#---------------------------------------Dragonhawk-----------------------------------------------------#
def Dragonhawk(c, mod):
    pass
#---------------------------------------Ravager-----------------------------------------------------#
def Ravager(c, mod):
    pass
#---------------------------------------NetherRay-----------------------------------------------------#
def NetherRay(c, mod):
    pass
#---------------------------------------Serpent-----------------------------------------------------#
def Serpent(c, mod):
    pass
#---------------------------------------WarpStalker-----------------------------------------------------#
def WarpStalker(c, mod):
    pass
#---------------------------------------Sporebat-----------------------------------------------------#
def Sporebat(c, mod):
    pass
#---------------------------------------WOLF-----------------------------------------------------------------#
def Wolf(c, mod):
    
    # Wolfs do not have Mana
    mod.SetManaMod(0)
    
    # Wolfs have Rage
    c.SetPowerIndex (_co_.POWER_INDEX_RAGE)
    c.SetMaxRage  (100)
    c.SetRage     (100)    
    
    # Pet specific
    if c.isPet(): 
        
        c.SetPowerIndex (_co_.POWER_INDEX_FOCUS)
        c.SetMaxFocus  (100)
        c.SetFocus     (100) 
    
        c.SetClass(_co_.CLASS_WARRIOR)
    
        c.SetAutoLevelAttributes (\
            (25, 15, 22, 15, 22),       # Base Stats for L1
            (2.0, 2.0, 2.5, 1.8, 2.0),  # Stats increase per level
            50, 17, 50, 15)             # Base HP and HP/level, Base Mana and Mana/level
            
        mod.is_base_stats_applied = TRUE
    
#---------------------------------------FELHUNTER-----------------------------------------------------------------#
def Felhunter(c, mod):

    c.SetPowerIndex (_co_.POWER_INDEX_MANA)
    
    if c.isPet(): 
        c.SetClass(_co_.CLASS_MAGE)

        c.SetAutoLevelAttributes (\
            (25, 15, 22, 15, 22),       # Base Stats for L1
            (2.0, 2.0, 2.5, 1.8, 2.0),  # Stats increase per level
            50, 17, 50, 15)             # Base HP and HP/level, Base Mana and Mana/level
    
        mod.is_base_stats_applied = TRUE
    
#---------------------------------------VOIDWALKER-----------------------------------------------------------------#
def Voidwalker(c, mod):

    c.SetPowerIndex (_co_.POWER_INDEX_MANA)
        
    if c.isPet(): 
        c.SetClass(_co_.CLASS_MAGE)

        c.SetAutoLevelAttributes (\
            (20, 20, 20, 20, 21),       # Base Stats for L1
            (4.0, 2.5, 4.0, 1.8, 2.0),  # Stats increase per level
            50, 20, 40, 10)             # Base HP and HP/level, Base Mana and Mana/level
    
        mod.is_base_stats_applied = TRUE
    
#---------------------------------------SUCCUBUS-----------------------------------------------------------------#-class add-
def Succubus(c, mod):

    c.SetPowerIndex (_co_.POWER_INDEX_MANA)
        
    if c.isPet(): 
        c.SetClass(_co_.CLASS_MAGE)

        c.SetAutoLevelAttributes (\
            (22, 16, 23, 19, 19),       # Base Stats for L1
            (2.5, 3.5, 2.5, 1.8, 2.0),  # Stats increase per level
            40, 13, 30, 12)             # Base HP and HP/level, Base Mana and Mana/level
    
        mod.is_base_stats_applied = TRUE
    
#---------------------------------------DOOMGUARD-----------------------------------------------------------------#
def Doomguard(c, mod):

    c.SetPowerIndex (_co_.POWER_INDEX_MANA)
        
    if c.isPet(): 
        c.SetClass(_co_.CLASS_MAGE)

        c.SetAutoLevelAttributes (\
            (25, 15, 22, 15, 22),       # Base Stats for L1
            (2.0, 2.0, 3.0, 1.8, 2.0),  # Stats increase per level
            50, 17, 50, 12)             # Base HP and HP/level, Base Mana and Mana/level
    
        mod.is_base_stats_applied = TRUE
    
#---------------------------------------IMP----------------------------------------------------------------------#
def Imp(c, mod):

    c.SetPowerIndex (_co_.POWER_INDEX_MANA)
        
    if c.isPet(): 
        c.SetClass(_co_.CLASS_MAGE)

        c.SetAutoLevelAttributes (\
            (23, 25, 19, 24, 20),       # Base Stats for L1
            (1.5, 1.5, 2.0, 1.5, 1.5),  # Stats increase per level
            30, 10, 40, 15)             # Base HP and HP/level, Base Mana and Mana/level
    
        mod.is_base_stats_applied = TRUE

# ####################################################################################

# This is the Head function which is called by Core
printLog( " o Registerring Creature Class" )

creature_class_func = {
    _co_.CREATURE_TYPE_UNSET:         UnSet,
    _co_.CREATURE_TYPE_BEAST:         Beast,
    _co_.CREATURE_TYPE_DRAGONSKIN:    Dragon,
    _co_.CREATURE_TYPE_DEMON:         Demon,
    _co_.CREATURE_TYPE_ELEMENTAL:     Elemental,
    _co_.CREATURE_TYPE_GIANT:         Giant,
    _co_.CREATURE_TYPE_UNDEAD:        Undead,
    _co_.CREATURE_TYPE_HUMANOID:      Humanoid,
    _co_.CREATURE_TYPE_CRITTER:       Critter,
    _co_.CREATURE_TYPE_MECHANICAL:    Mechanical,
    _co_.CREATURE_TYPE_NOTSPECIFIED:  NotSpecified,
}

creature_family_func = {
    _co_.CREATURE_FAMILY_WOLF:           Wolf,
    _co_.CREATURE_FAMILY_CAT:            Cat,
    _co_.CREATURE_FAMILY_SPIDER:         Spider,
    _co_.CREATURE_FAMILY_BEAR:           Bear,
    _co_.CREATURE_FAMILY_BOAR:           Boar,
    _co_.CREATURE_FAMILY_CROCILISK:      Crocilisk,
    _co_.CREATURE_FAMILY_CARRION_BIRD:   CarrionBird,
    _co_.CREATURE_FAMILY_CRAB:           Crab,
    _co_.CREATURE_FAMILY_GORILLA:        Gorilla,
    _co_.CREATURE_FAMILY_RAPTOR:         Raptor,
    _co_.CREATURE_FAMILY_TALLSTRIDER:    Tallstrider,
    _co_.CREATURE_FAMILY_FELHUNTER:      Felhunter,
    _co_.CREATURE_FAMILY_VOIDWALKER:     Voidwalker,
    _co_.CREATURE_FAMILY_SUCCUBUS:       Succubus,
    _co_.CREATURE_FAMILY_DOOMGUARD:      Doomguard,
    _co_.CREATURE_FAMILY_SCORPID:        Scorpid,
    _co_.CREATURE_FAMILY_TURTLE:         Turtle,
    _co_.CREATURE_FAMILY_IMP:            Imp,
    _co_.CREATURE_FAMILY_BAT:            Bat,
    _co_.CREATURE_FAMILY_HYENA:          Hyena,
    _co_.CREATURE_FAMILY_OWL:            Owl,
    _co_.CREATURE_FAMILY_WIND_SERPENT:   WindSerpent,
    _co_.CREATURE_FAMILY_REMOTE_CONTROL: RemoteControl,
    _co_.CREATURE_FAMILY_FELGUARD:       Felguard,
    _co_.CREATURE_FAMILY_DRAGONHAWK:     Dragonhawk,
    _co_.CREATURE_FAMILY_RAVAGER:        Ravager,
    _co_.CREATURE_FAMILY_NETHER_RAY:     NetherRay,
    _co_.CREATURE_FAMILY_SERPENT:        Serpent,
    _co_.CREATURE_FAMILY_WARP_STALKER:   WarpStalker,
    _co_.CREATURE_FAMILY_SPOREBAT:       Sporebat,
}

def Init_Creature_Class(c, called_by_core):

    # In case module is disabled we escape from here
    if _cfg_.USE_CREATURE_PY_CLASS == FALSE and called_by_core: return
    
    # first reset Class for creature (will not be recalculated as player) 
    #
    c.SetClass(0)
    
    # Constants Definition
    #
    c_type      = 0
    c_family    = 0
    c_lvl       = 0
    c_entry     = 0
    c_elite     = 0

    # Initialising constants
    #
    c_type   = c.GetType()
    c_family = c.GetFamily()
    c_lvl    = c.GetLevel()
    c_entry  = c.GetEntry()
    c_elite  = c.GetElite()

    
    # We can skip certain creatures and use their DB data or viceversa, recalculate only specific here
    #
    if c_entry == 0: return # Example
    
    # Initialise Modifier
    mod = Modifier()
    mod.c_type      = c_type
    mod.c_family    = c_family
    mod.c_lvl       = c_lvl
    mod.c_entry     = c_entry
    mod.c_elite     = c_elite
    
    # Initialising modifiers (You can assign Modifier for every type/family for more accurate calculations)
    #
    if c_type in creature_class_func:
        apply (creature_class_func [c_type], (c, mod))

    if c_family in creature_family_func:
        apply (creature_family_func [c_family], (c, mod))
    
    # Here may go Common to all calculations
    # DEFAULTS
    c.SetStamina (c.GetStamina())       # Refresh with new multiplier
    c.SetIntellect (c.GetIntellect())   # Refresh with new multiplier
    c.SetAutoLevelScale (1.2, 1.2)
    ELITE_SPAWNTIME_MULTIPLIER = 1.0
    # ---------------------------------------------------------------------------------------------------------------------------------------------------------

    # ELITE CUSTOMALISATION
    if c_elite > 0 :
       
        raid_instance = c.GetMapId() in ( 229, 230, 249, 289, 409, 469, 309, 329, 509, 531, 533,566) # set custom elite modifiers for these instances

        if c_elite == _co_.CREATURE_ELITE_ELITE:       
            ELITE_SPAWNTIME_MULTIPLIER = 4
            c.SetAutoLevelScale (2.0, 2.0)
            mod.SetEliteArmorMod(1.20)
            if raid_instance: 
               mod.SetEliteHealthMod(22.0)
               mod.SetEliteDamageMod(7.0)
               mod.SetEliteManaMod(20.0)
            else:
               mod.SetEliteHealthMod(4.0)
               mod.SetEliteDamageMod(3.5)
               mod.SetEliteManaMod(10.0)
          
        elif c_elite == _co_.CREATURE_ELITE_RAREELITE:
            ELITE_SPAWNTIME_MULTIPLIER = 8
            c.SetAutoLevelScale (3.0, 3.0)
            mod.SetEliteArmorMod(1.25)
            if raid_instance:
               mod.SetEliteHealthMod(26.0)
               mod.SetEliteDamageMod (8.0)
               mod.SetEliteManaMod(10.0)
            else:
               mod.SetEliteHealthMod(6.0)
               mod.SetEliteDamageMod (3.5)
               mod.SetEliteManaMod(5.0)
               
        elif c_elite == _co_.CREATURE_ELITE_WORLDBOSS:
            ELITE_SPAWNTIME_MULTIPLIER = 24
            c.SetAutoLevelScale (16.0, 16.0)
            mod.SetEliteArmorMod(2.0)
            if raid_instance:
               mod.SetEliteHealthMod(80.0)
               mod.SetEliteDamageMod(16.0)
               mod.SetEliteManaMod(20.0)
            else:
               mod.SetEliteHealthMod(38.0)
               mod.SetEliteDamageMod(15.5)
               mod.SetEliteManaMod(10.0)
               
        elif c_elite == _co_.CREATURE_ELITE_RARE:
            ELITE_SPAWNTIME_MULTIPLIER = 8
            c.SetAutoLevelScale (1.5, 1.5)
            mod.SetEliteHealthMod(2.0)
            mod.SetEliteDamageMod (2.5)
            mod.SetEliteArmorMod(1.10)


    # ---------------------------------------------------------------------------------------------------------------------------------------------------------

    # SPAWN TIME # ---------------------------------------------------------------------------------------------------------------------------------------------------------
    v = 300 * ELITE_SPAWNTIME_MULTIPLIER
    c.SetSpawnTime (0, v)
    c.SetSpawnTime (1, v)
    # --------------------------------------------------------------------------------------------------------------------------------------------------------------------

    # HEALTH # ---------------------------------------------------------------------------------------------------------------------------------------------------------
    if mod.is_base_stats_applied == FALSE:
        mo = 1
        if c_lvl >= 10:
            mo = c_lvl / 10
        v = ((42 + (c_lvl-2)*15)*mo) * mod.GetEliteHealthMod() * _cfg_.GLOBAL_HEALTH_MOD
        if c.GetPowerIndex() == _co_.POWER_INDEX_MANA:
            v = v * 0.9
    # Send to Server
        c.SetMaxHealth (v)
        c.SetHealth (v)
    # --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    #ATTACK TIME#--------------------------------------------------------------------------------------------------------------------------------------------------
    
    if mod.is_attack_time_applied == FALSE:
        size = c.GetSize()
        base = 2000
        a_time = (int(size) * 500) + 1500 # smaller creature hits faster
        c.SetBaseAttackTime(_co_.AT_MELEE__MAINHAND, a_time)
        c.SetBaseAttackTime(_co_.AT_MELEE__OFFHAND, a_time)
    # --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    # ATTACK POWER # ----------------------------------------------------------------------------------------------------------------------------------------
    # new formula according new core changes to result in around max 250 dmg for elite creature
    ap = c_lvl * 9.5 * mod.GetDamageMod() * mod.GetEliteDamageMod() * _cfg_.GLOBAL_DAMAGE_MOD
    c.SetAttackPower(ap)
    # --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    # MANA # ---------------------------------------------------------------------------------------------------------------------------------------------------------
    if c.GetPowerIndex() == _co_.POWER_INDEX_MANA:
        # Send to Server
        if mod.is_base_stats_applied == FALSE:
            v = int ((50 + 35*(c_lvl-1) + 0.16*c_lvl*c_lvl) * mod.GetManaMod() * mod.GetEliteManaMod() * _cfg_.GLOBAL_MANA_MOD)
            c.SetMaxMana (v)
            c.SetMana (v)
    # --------------------------------------------------------------------------------------------------------------------------------------------------------------------
            
    #ARMOR#-----------------------------------------------------------------------------------------------------------------------------------------------------------
    armor = c.GetLevel() * 70.0 * mod.GetEliteArmorMod()
    if c_type == _co_.CREATURE_TYPE_HUMANOID: 
        c.SetArmor(armor)
    # --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    #PASSIVE SPELLS#-----------------------------------------------------------------------------------------------------------------------------------------------------------
    CreatureBaseSpells(c, TRUE)
    # --------------------------------------------------------------------------------------------------------------------------------------------------------------------
    
    if called_by_core :
    #FIX NPCFLAGS while  creatures are loaded
    #  if NPC_TEMPL_CHECK set to TRUE it will update Creatures NPCFlag.
    #  if NPC_TEMPL_UPDATE set to TRUE it will update Creature_template also, making it reuired to run NPC_TEMPL_CHECK only one (Set both to false to gain max speed).
        if _cfg_.NPC_FLAG_CHECK == TRUE: FixFlags(c) # add flags & add skillines to trainers depending on Guild and other parameters.
    #-----------------------------------------------------------------------------------------------------------------------------------------------------------

    # Add SkillLines to Trainers
        if _cfg_.NPC_TRAINER_UPDATE == TRUE: ManageTrainer(c) 
          
    #-----------------------------------------------------------------------------------------------------------------------------------------------------------
    
    
# ####################################################################################

def CreatureBaseSpells(c, apply):
    
    if apply:
        c.AddSpell(_spellname_.SPELL_ID_BLOCK_PASSIVE)
        c.AddSpell(_spellname_.SPELL_ID_DODGE_PASSIVE)
        c.AddSpell(_spellname_.SPELL_ID_PARRY_PASSIVE)
    else:
        c.RemoveSpell(_spellname_.SPELL_ID_BLOCK_PASSIVE)
        c.RemoveSpell(_spellname_.SPELL_ID_DODGE_PASSIVE)
        c.RemoveSpell(_spellname_.SPELL_ID_PARRY_PASSIVE)
    
    
# ####################################################################################
# Called on server start if configured
#     if _cfg_.NPC_TEMPL_UPDATE set to TRUE it will update Creature_template also.
def FixFlags(c):
    npc_flags = c.GetNpcFlags()
    c_name  = c.GetName()
    c_guild = c.GetGuild()
    c_entry = c.GetEntry()
    cursor = conn.cursor ()

    # UNIT_NPC_FLAG_GOSSIP = 1 

    # UNIT_NPC_FLAG_QUESTGIVER = 2 
    cursor.execute ("SELECT DISTINCT 1 FROM `creaturequestrelation` WHERE `creaturequestrelation`.`creatureId` = " + str(c_entry))
    row = cursor.fetchone ()
    if row:
        npc_flags |=  _co_.UNIT_NPC_FLAG_QUESTGIVER  # Add flag(s)
    else:
        npc_flags %  _co_.UNIT_NPC_FLAG_QUESTGIVER  # Remove flag otherwise
 
    # UNIT_NPC_FLAG_VENDOR = 4 
    if c.HasSellTables():
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_VENDOR # Add flag if it has SellTables
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_VENDOR # Remove flag otherwise

    # UNIT_NPC_FLAG_TAXIVENDOR = 8
    if c_guild == "Gryphon Master" or c_guild == "Wind Rider Master" or c_guild == "Bat Handler" or c_guild == "Hippogryph Master"\
     or c_guild.endswith == "Flight Master": 
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_TAXIVENDOR # Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_TAXIVENDOR # Remove flag otherwise
    
    # UNIT_NPC_FLAG_TRAINER = 16 
    if c_guild.endswith ("Alchemist") or c_guild.endswith ("Blacksmith") or c_guild.endswith ("Engineer") or c_guild.endswith ("Enchanter") \
        or c_guild.endswith ("Instructor")or c_guild.endswith ("Jewelcrafter") or c_guild.endswith ("Leatherworker") \
        or c_guild.endswith ("Pilot")or c_guild.endswith ("Tailor") or c_guild.endswith ("Trainer") \
        or c_guild == "Superior Cook" or c_guild == "Herbalist" or c_guild == "Skinner" or c_guild == "Weapon Master" :
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_TRAINER # Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_TRAINER # Remove flag otherwise

    # UNIT_NPC_FLAG_SPIRITHEALER = 32 
    if c_name == "Spirit Healer" : 
        npc_flags = _co_.UNIT_NPC_FLAG_SPIRITHEALER # make spirit healer
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_SPIRITHEALER # Remove flag otherwise

    # UNIT_NPC_FLAG_GUARD = 64   
    # don't bother; guards gossip are custom loaded, see startup_qm.py
    
    # UNIT_NPC_FLAG_INNKEEPER = 128
    if c_guild == "Innkeeper": 
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_INNKEEPER # Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_INNKEEPER # Remove flag otherwise

    # UNIT_NPC_FLAG_BANKER = 256
    if c_guild == "Banker": 
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_BANKER  #Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_BANKER # Remove flag otherwise

    # UNIT_NPC_FLAG_PETITIONER = 512
    if c_guild == "Guild Master": 
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_PETITIONER  #Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_PETITIONER # Remove flag otherwise
    
    # UNIT_NPC_FLAG_TABARDVENDOR = 1024
    if c_guild.endswith ("Tabard Designer") or c_guild.endswith ("Tabard Vendor"):
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_TABARDVENDOR  #Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_TABARDVENDOR # Remove flag otherwise

    # UNIT_NPC_FLAG_BATTLEFIELDPERSON = 2048
    if c_guild.endswith ("Battlemaster"): 
        npc_flags |= _co_.UNIT_NPC_FLAG_GOSSIP # add default gossip
        npc_flags |= _co_.UNIT_NPC_FLAG_BATTLEFIELDPERSON # Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_BATTLEFIELDPERSON # Remove flag otherwise

    # UNIT_NPC_FLAG_AUCTIONEER = 4096
    if c_guild == "Auctioneer": 
        npc_flags |= _co_.UNIT_NPC_FLAG_AUCTIONEER  #Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_AUCTIONEER # Remove flag otherwise

    # UNIT_NPC_FLAG_STABLE = 8192
    if c_guild == "Stable Master": 
        npc_flags |= _co_.UNIT_NPC_FLAG_STABLE # Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_STABLE # Remove flag otherwise
      
    # UNIT_NPC_FLAG_ARMORER = 16384 #c_guild.endswith ("Merchant") or 
    if c_guild.endswith ("Armor Merchant") or c_guild.endswith ("Armorer") or c_guild == "Armorsmith": 
        npc_flags |= _co_.UNIT_NPC_FLAG_ARMORER # Add flag
    else:
        npc_flags % _co_.UNIT_NPC_FLAG_ARMORER # Remove flag otherwise

    # Set Flags to NPC
    if c.GetNpcFlags()!= npc_flags :
        print "FixFlags: E[%d]N[%s]G[%s] O[%d] N[%d]" % (c_entry, c_name, c_guild, c.GetNpcFlags(), npc_flags)
        if _cfg_.NPC_TEMPL_UPDATE == TRUE: cursor.execute ("UPDATE `creatures_templ` SET `NPCFlags` = " + str(npc_flags) + " WHERE `creature_id` = " + str(c_entry))
        c.SetNpcFlags( npc_flags ); 
    cursor.close ()

# ####################################################################################
# Called during startup if has trainerflag
#     
def ManageTrainer(trainer):
   
    t_entry = trainer.GetEntry()
    t_level = trainer.GetLevel()
    t_name  = trainer.GetName()
    t_guild = trainer.GetGuild()

    skill_list = []
    
   # Add corresponding Skillines to trainers
    # -------------------------------------------------------------------------------------------------
   
       # -WARRIOR

    if  t_guild == "Warrior Trainer":
        skill_list = [_skillco_.SKILL_ARMS, _skillco_.SKILL_FURY, _skillco_.SKILL_PROTECTION]
        trainer.SetTrainerCharClass(1)
        trainer.SetClass(1)

       # -PALADIN

    elif t_guild == "Paladin Trainer":
        skill_list = [_skillco_.SKILL_RETRIBUTION, _skillco_.SKILL_HOLY_1, _skillco_.SKILL_PROTECTION_1]
        trainer.SetTrainerCharClass(2)
        trainer.SetClass(2)

       # -HUNTER

    elif t_guild == "Hunter Trainer":
        skill_list = [_skillco_.SKILL_BEAST_MASTERY, _skillco_.SKILL_SURVIVAL, _skillco_.SKILL_MARKSMANSHIP]
        trainer.SetTrainerCharClass(3)
        trainer.SetClass(3)

       # -ROGUE

    elif t_guild == "Rogue Trainer":
        skill_list = [_skillco_.SKILL_COMBAT, _skillco_.SKILL_SUBTLETY, _skillco_.SKILL_POISONS, _skillco_.SKILL_ASSASSINATION]
        trainer.SetTrainerCharClass(4)
        trainer.SetClass(4)

       # -PRIEST

    elif t_guild == "Priest Trainer":
        skill_list = [_skillco_.SKILL_SHADOW_MAGIC, _skillco_.SKILL_HOLY, _skillco_.SKILL_DISCIPLINE]
        trainer.SetTrainerCharClass(5)
        trainer.SetClass(5)

       # -SHAMAN

    elif t_guild == "Shaman Trainer":
        skill_list = [_skillco_.SKILL_ENHANCEMENT, _skillco_.SKILL_ELEMENTAL_COMBAT,_skillco_.SKILL_RESTORATION]
        trainer.SetTrainerCharClass(7)
        trainer.SetClass(7)

       # -MAGE

    elif t_guild == "Mage Trainer":
        skill_list = [_skillco_.SKILL_FROST, _skillco_.SKILL_FIRE, _skillco_.SKILL_ARCANE]
        trainer.SetTrainerCharClass(8)
        trainer.SetClass(8)

       # -WARLOCK

    elif t_guild == "Warlock Trainer":
        skill_list = [_skillco_.SKILL_DEMONOLOGY ,_skillco_.SKILL_AFFLICTION, _skillco_.SKILL_DESTRUCTION]
        trainer.SetTrainerCharClass(9)
        trainer.SetClass(9)

       # -DRUID

    elif t_guild == "Druid Trainer":
        skill_list = [_skillco_.SKILL_FERAL_COMBAT, _skillco_.SKILL_RESTORATION_1, _skillco_.SKILL_BALANCE]
        trainer.SetTrainerCharClass(11)
        trainer.SetClass(11)

       # Weapon master
    elif t_guild == "Weapon Master":
        skill_list = [_skillco_.SKILL_SWORDS, _skillco_.SKILL_AXES, _skillco_.SKILL_BOWS, _skillco_.SKILL_GUNS, _skillco_.SKILL_MACES, _skillco_.SKILL_TWO_HANDED_SWORDS, _skillco_.SKILL_STAVES, _skillco_.SKILL_TWO_HANDED_MACES, _skillco_.SKILL_TWO_HANDED_AXES, _skillco_.SKILL_DAGGERS, _skillco_.SKILL_THROWN, _skillco_.SKILL_CROSSBOWS, _skillco_.SKILL_WANDS, _skillco_.SKILL_POLEARMS, _skillco_.SKILL_FIST_WEAPONS]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # FIRST PROFF TRAINERS
    # -ALCHEMIST

    elif t_guild in ("Journeyman Alchemist","Master Alchemist","Expert Alchemist","Artisan Alchemist","Grand Master Alchemist"):
        skill_list = [_skillco_.SKILL_ALCHEMY]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -BLACKSMITHING

    elif t_guild in ("Journeyman Blacksmith","Master Blacksmith","Expert Blacksmith","Artisan Blacksmith","Grand Master Blacksmith"):
        skill_list = [_skillco_.SKILL_BLACKSMITHING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -ENGINEERING

    elif t_guild in ("Journeyman Engineer","Master Engineer","Expert Engineer","Grand Master Engineer","Artisan Engineer"):
        skill_list = [_skillco_.SKILL_ENGINEERING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -ENCHANTING

    elif t_guild in ("Journeyman Enchanter","Master Enchanter","Expert Enchanter","Grand Master Enchanter","Artisan Enchanter"):
        skill_list = [_skillco_.SKILL_ENCHANTING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -JEWELCRAFTING

    elif t_guild in ("Journeyman Jewelcrafter","Grand Master Jewelcrafter","Master Jewelcrafter","Expert Jewelcrafter","Artisan Jewelcrafter"):
        skill_list = [_skillco_.SKILL_JEWELCRAFTING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -HERBALISM

    elif t_guild in ("Superior Herbalist","Apprentice Herbalist","Herbalism Trainer","Herbalist"):
        skill_list = [_skillco_.SKILL_HERBALISM]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -LEATHERWORKING

    elif t_guild in ("Journeyman Leatherworker","Master Leatherworker","Expert Leatherworker","Grand Master Leatherworker","Artisan Leatherworker"):
        skill_list = [_skillco_.SKILL_LEATHERWORKING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -MINING

    elif t_guild in ("Mining Trainer","Miner"):
        skill_list = [_skillco_.SKILL_MINING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -SKINNING

    elif t_guild in ("Skinning Trainer","Grand Master Skinner","Skinner"):
        skill_list = [_skillco_.SKILL_SKINNING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -TAILORING

    elif t_guild in ("Journeyman Tailor","Master Tailor","Expert Tailor","Grand Master Tailor","Artisan Tailor"):
        skill_list = [_skillco_.SKILL_TAILORING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # SECOND PROFF TRAINER
    # -COOKING

    elif t_guild in ("Cooking Trainer","Superior Cook","Cooking Trainer and Supplies"):
        skill_list = [_skillco_.SKILL_COOKING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -FIRST AID TRAINER

    elif t_guild == "First Aid Trainer":
        skill_list = [_skillco_.SKILL_FIRST_AID]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    # -FISHING

    elif t_guild == "Fishing Trainer":
        skill_list = [_skillco_.SKILL_FISHING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)

    elif t_guild == "Pet Trainer":
        skill_list = []
        trainer.SetTrainerCharClass(3)
        trainer.SetClass(0)

    # RIDING TRAINER

    elif t_guild in ("Undead Horse Riding Instructor","Horse Riding Instructor","Wolf Riding Instructor","Ram Riding Instructor","Raptor Riding Trainer","Nightsaber Riding Instructor","Kodo Riding Instructor","Riding Instructor","Mechanostrider Pilot"):
        skill_list = [_skillco_.SKILL_RIDING]
        trainer.SetTrainerCharClass(0)
        trainer.SetClass(0)
   # -------------------------------------------------------------------------------------------------


    # Add result into core
    skills_count = skill_list.__len__()
    if skills_count == 0: return 0

    # Clear previous spells obtained on load from DB
    trainer.ClearTrainerSpells()
    
    # Add skillines
    for skill_id in skill_list:
        trainer.AddTrainerSkillLine(skill_id)

    # Set max level of spell trainer is training
    if t_level < 70: trainer.SetTrainerSpellMaxLvL( t_level ) 
    elif t_level == 70: trainer.SetTrainerSpellMaxLvL (_cfg_.XP_MAXPLAYERLVL)

    if _cfg_.NPC_TEMPL_UPDATE == TRUE:
        cursor = conn.cursor ()
        while skills_count < 20:
            skills_count += 1
            skill_list.append(0)
        print skill_list
        cursor.execute ("SELECT `ID` FROM `trainer` WHERE `creature_Id` = " + str(t_entry))
        row = cursor.fetchone ()
        if row:
            cursor.execute ("UPDATE `trainer` SET `SkillLine1` = " + str(skill_list[0]) + \
                       " ,`SkillLine2` = " + str(skill_list[1]) + \
                       " ,`SkillLine3` = " + str(skill_list[2]) + \
                       " ,`SkillLine4` = " + str(skill_list[3]) + \
                       " ,`SkillLine5` = " + str(skill_list[4]) + \
                       " ,`SkillLine6` = " + str(skill_list[5]) + \
                       " ,`SkillLine7` = " + str(skill_list[6]) + \
                       " ,`SkillLine8` = " + str(skill_list[7]) + \
                       " ,`SkillLine9` = " + str(skill_list[8]) + \
                       " ,`SkillLine10` = " + str(skill_list[9]) + \
                       " ,`SkillLine11` = " + str(skill_list[10]) + \
                       " ,`SkillLine12` = " + str(skill_list[11]) + \
                       " ,`SkillLine13` = " + str(skill_list[12]) + \
                       " ,`SkillLine14` = " + str(skill_list[13]) + \
                       " ,`SkillLine15` = " + str(skill_list[14]) + \
                       " ,`SkillLine16` = " + str(skill_list[15]) + \
                       " ,`SkillLine17` = " + str(skill_list[16]) + \
                       " ,`SkillLine18` = " + str(skill_list[17]) + \
                       " ,`SkillLine19` = " + str(skill_list[18]) + \
                       " ,`SkillLine20` = " + str(skill_list[19]) + \
                       " ,`MaxLvL` = " + str(t_level) + \
                       " ,`Class` = " + str(trainer.GetClass()) + \
                       " WHERE `ID` = " + str(row[0]) )
            print "UpdateTrainerSkillLines: E[%d] N[%s] G[%s] L[%s]" % (t_entry, t_name, t_guild, skill_list)
        else:
            cursor.execute ("INSERT INTO `trainer` SET `SkillLine1` = " + str(skill_list[0]) + \
                       " ,`SkillLine2` = " + str(skill_list[1]) + \
                       " ,`SkillLine3` = " + str(skill_list[2]) + \
                       " ,`SkillLine4` = " + str(skill_list[3]) + \
                       " ,`SkillLine5` = " + str(skill_list[4]) + \
                       " ,`SkillLine6` = " + str(skill_list[5]) + \
                       " ,`SkillLine7` = " + str(skill_list[6]) + \
                       " ,`SkillLine8` = " + str(skill_list[7]) + \
                       " ,`SkillLine9` = " + str(skill_list[8]) + \
                       " ,`SkillLine10` = " + str(skill_list[9]) + \
                       " ,`SkillLine11` = " + str(skill_list[10]) + \
                       " ,`SkillLine12` = " + str(skill_list[11]) + \
                       " ,`SkillLine13` = " + str(skill_list[12]) + \
                       " ,`SkillLine14` = " + str(skill_list[13]) + \
                       " ,`SkillLine15` = " + str(skill_list[14]) + \
                       " ,`SkillLine16` = " + str(skill_list[15]) + \
                       " ,`SkillLine17` = " + str(skill_list[16]) + \
                       " ,`SkillLine18` = " + str(skill_list[17]) + \
                       " ,`SkillLine19` = " + str(skill_list[18]) + \
                       " ,`SkillLine20` = " + str(skill_list[19]) + \
                       " ,`MaxLvL` = " + str(t_level) + \
                       " ,`Class` = " + str(trainer.GetClass()) + \
                       " ,`creature_id` = " + str(t_entry))
            print "InsertTrainerSkillLines: E[%d] N[%s] G[%s] L[%s]" % (t_entry, t_name, t_guild, skill_list)
        cursor.close ()
    else:
        print "AddTrainerSkillLines: E[%d] N[%s] G[%s] L[%s]" % (t_entry, t_name, t_guild, skill_list)

# ####################################################################################
# Modifier Class (used to pass modifiers from functions)
printLog( " o Registerring Creature Class Modifier" )
class Modifier:
    # Standard Modifier
    health      = 1.0
    mana        = 1.0
    damage      = 1.0
    armor       = 1.0
    # Modifier for Elites
    e_health    = 1.0 # Elite
    e_mana      = 1.0 # Elite
    e_damage    = 1.0 # Elite
    e_armor     = 1.0 # Elite
    # Creature Properties
    c_type      = 0
    c_family    = 0
    c_lvl       = 0
    c_entry     = 0
    c_elite     = 0
    is_base_stats_applied = FALSE
    is_attack_time_applied = FALSE
    
    #Set Modifier
    def SetHealthMod(self, v):
        self.health = v
    def SetManaMod(self, v):
        self.mana   = v
    def SetDamageMod(self, v):
        self.damage = v
    def SetArmorMod(self, v):
        self.armor = v
    #Get Modifier
    def GetHealthMod(self):
        return self.health
    def GetManaMod(self):
        return self.mana
    def GetDamageMod(self):
        return self.damage
    def GetArmorMod(self):
        return self.armor
        
    #Set Elite Modifier
    def SetEliteHealthMod(self, v):
        self.e_health = v
    def SetEliteManaMod(self, v):
        self.e_mana   = v
    def SetEliteDamageMod(self, v):
        self.e_damage = v
    def SetEliteArmorMod(self, v):
        self.e_armor = v
    #Get Elite Modifier
    def GetEliteHealthMod(self):
        return self.e_health
    def GetEliteManaMod(self):
        return self.e_mana
    def GetEliteDamageMod(self):
        return self.e_damage
    def GetEliteArmorMod(self):
        return self.e_armor

# ####################################################################################
# Set NPC Flags (correction if DB Part is missing or incorrect)
#

def SetNpcFlagsForNpc(c):
    
    # Get default current Flag from DB
    npc_flags = c.GetNpcFlags()
    guild = c.GetGuild()
    
    guild_name_ends = [" Trainer", " Riding Instructor", " Skinner"]
    guild_name_starts = ["Journeyman", "Expert", "Master", "Artisan", "Grand Master", "Superior", "Apprentice"]
    guild_name_full = ["Herbalist", "Skinner", "Mechanostrider Pilot", "Pet Trainer", "Portal Trainer", "Weapon Master"]
    
    # Select for Correction    
    #innkeepers
    if guild == "Innkeeper" :           npc_flags = _co_.UNIT_NPC_FLAG_INNKEEPER | _co_.UNIT_NPC_FLAG_QUESTGIVER
    #spirithealers
    if c.GetName() == "Spirit Healer" : npc_flags = _co_.UNIT_NPC_FLAG_SPIRITHEALER

    # --------------------------------------------------> Class Trainers
    if guild is None: return

    ''' My Bellygrib becomes Gossip here :) Kosuha
    for g_name in guild_name_ends:
        if guild.endswith (g_name):
            npc_flags = _co_.UNIT_NPC_FLAG_TRAINER | _co_.UNIT_NPC_FLAG_QUESTGIVER
            break
    for g_name in guild_name_starts:
        if guild.startswith (g_name):
            npc_flags = _co_.UNIT_NPC_FLAG_TRAINER | _co_.UNIT_NPC_FLAG_QUESTGIVER
            break
    for g_name in guild_name_full:
        npc_flags = _co_.UNIT_NPC_FLAG_TRAINER | _co_.UNIT_NPC_FLAG_QUESTGIVER
        break
    '''
   
    #BG_master------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------
    if   guild.endswith ("Battlemaster"): npc_flags = _co_.UNIT_NPC_FLAG_GOSSIP 
    
    # This will make AI not be working but will work as simple SpiritHealer
    if   c.GetEntry() == 13116:  c.SetObjectVisibleToDead() # hide from Alive and make visible to Dead (subst for SH Npc flag)
    
    # Set Flags to NPC
    c.SetNpcFlags( npc_flags ); 
        
# ####################################################################################
# used to help Core to select right loot for Skining 
#     
def GenerateLoot_Skinning(c):
    
    '''
    Special Leather
    Chimera leather -ADD
    Core Leather - Requires Skinning greater than 300 -ADD 
    Devilsaur leather -ADD
    Frostsaber leather -ADD
    Primal bat leather -ADD
    Primal tiger leather -ADD
    Thin kodo leather -ADD
    Warbear leather -ADD


    Special Scale
    Scale of Onyxia -ADD
    Black whelp scale -ADD
    Deviate scale -ADD
    Fish Scale -ADD
    Green whelp scale -ADD
    Heavy scorpid scale -ADD
    Perfect deviate scale -ADD
    Red whelp scale -ADD
    Scorpid scale -ADD
    Turtle scale -ADD
    Worn Dragonscale -ADD
    '''
    
    mob_model = c.GetDisplayID()
    
    #Special Leather :
    
    #Chimaera - Chimera leather
    if mob_model in (12682,10810,4269,9560): c.AddItemToLoot( 15423, randrange (3) )

    #Core Hounds - Core Leather
    elif mob_model == 12168: c.AddItemToLoot( 17012, randrange (3) )

    #Devilsaur - Devilsaur leather
    elif mob_model in (5239,5238,5240): c.AddItemToLoot( 15417, randrange (3) )

    #Frostsaber - Frostsaber Leather
    elif mob_model in (9958,11445,11444,9954): c.AddItemToLoot( 15422, randrange (3) )

    #high-level Bats in Zul'Gurub - Primal bat leather
    elif mob_model == 14562: c.AddItemToLoot( 19767, randrange (3) )

    #high-level Tigers in Zul'Gurub - Primal tiger leather
    elif mob_model in (15151,11031): c.AddItemToLoot( 19768, randrange (3) )

    #Kodo - Thin kodo leather
    elif mob_model in (10918,1232,1453,10914,7933,10919,10283,10284): c.AddItemToLoot( 5082, randrange (3) )       

    #high-level Bears - Warbear leather
    elif mob_model in (1082,9276,3201,8838): c.AddItemToLoot( 15419, randrange (3) )       

    #Special Scale :

    # Onixia - Scale of Onyxia
    elif  mob_model == 8570: c.AddItemToLoot( 15410, randrange (3) )

    # Black whelp - Scale
    elif  mob_model in (387,397,399,400,457,487,715,6288): c.AddItemToLoot( 7286, randrange (3) )

    # Deviate - Deviate Scale
    elif mob_model in (1742,4091,1744,949,1746,1747,755,1752,4317,2996,8172,3006,4312,2706,1084,4305,1267,8173): c.AddItemToLoot( 6470, randrange (3) )

    # Fish - Scale
    elif mob_model == 8570: c.AddItemToLoot( 6987, randrange (3) )

    # Green whelp - Scale
    elif  mob_model in (621,622,623,624,694,9582): c.AddItemToLoot( 7392, randrange (3) )

    # Scorpid - Heavy scorpid scale
    elif mob_model in (15384,15383,2864,8970,15385,10985,10984,15327,10983,8550): c.AddItemToLoot( 15408, randrange (3) )

    #Deviate - Perfect deviate scale
    elif mob_model in (1742,4091,1744,949,1746,1747,755,1752,4317,2996,8172,3006,4312,2706,1084,4305,1267,8173): c.AddItemToLoot( 6471, randrange (3) )

    #Scorpid - Scorpid scale
    elif mob_model in (2414,10987,10986,6068,5985,8970,10984,10983): c.AddItemToLoot( 8154, randrange (3) )

    #Turtle - Turtle scale
    elif mob_model in (5027,7114,4829,7836,7839,7840,10947,6368,5127,7837,7046): c.AddItemToLoot( 8167, randrange (3) )

    # Red whelp - Scale
    elif  mob_model in (505,956,6290,8712,8713,9583): c.AddItemToLoot( 7287, randrange (3) )
    
    #Dragon - Worn Dragonscale
    elif mob_model in (715,2554,621,143,8249,397,7903,7863,181,9753,8310,9586,10094,8309,6761,196,10007,6760,2158,9584,7974,7975,6762,6375,10585,10584,625): c.AddItemToLoot( 8165, randrange (3) )

    print "SkinningLoot: Unit[%s] Entry[%d]" % (c.GetName(), c.GetEntry())

# ####################################################################################
# used to help Core to select right loot for PickPocket 
#     
def GenerateLoot_PickPocket(c):
    
    DEFAULT_CHANCE = _cfg_.PICK_POCKET_CHANCE
    
    # Items Table
    MINOR_HEALING_POTION = 118
    LESSER_HEALING_POTION = 858
    GREATER_HEALING_POTION = 1710
    SUPERIOR_HEALING_POTION = 3928
    DISCOLORED_HEALING_POTION = 4596
    MAJOR_HEALING_POTION = 13446
    COMBAT_HEALING_POTION = 18839
    MINOR_MANA_POTION = 2455
    LESSER_MANA_POTION = 3385
    GREATER_MANA_POTION = 6149
    SUPERIOR_MANA_POTION = 13443
    MAJOR_MANA_POTION = 13444
    COMBAT_MANA_POTION = 18841
    
    c_entry = c.GetEntry()
    c_level = c.GetLevel()
    c_type  = c.GetType()
    c_class = c.GetClass()
    item = None
    loot_list = []
 
    print "PickPocketLoot: Unit[%s] Entry[%d]" % (c.GetName(), c_entry)
    
    #list_loot
    potion_list_health = [ MINOR_HEALING_POTION, LESSER_HEALING_POTION, GREATER_HEALING_POTION, 
                           SUPERIOR_HEALING_POTION, DISCOLORED_HEALING_POTION, MAJOR_HEALING_POTION, 
                           COMBAT_HEALING_POTION ]
                    
    potion_list_mana = [ MINOR_MANA_POTION, LESSER_MANA_POTION, GREATER_MANA_POTION, 
                         SUPERIOR_MANA_POTION, MAJOR_MANA_POTION, COMBAT_MANA_POTION ]    
    
    for item_id in potion_list_health:
        item_level = GetItemReqLevelByID(item_id)
        if randrange(100) < DEFAULT_CHANCE:
            if c_level >= item_level:
                item = item_id, randrange(1,2)
                print "PickPocket: adding item_id[%d] to loot" % (item_id)
                loot_list.append( item )
                break
    
    for item_id in potion_list_mana:
        if c.GetPowerIndex() == _co_.POWER_INDEX_MANA:
         item_level = GetItemReqLevelByID(item_id)
         if randrange(100) < DEFAULT_CHANCE:
            if c_level >= item_level:
                item = item_id, randrange(1,2)
                print "PickPocket: adding item_id[%d] to loot" % (item_id)
                loot_list.append( item )
                break                
    
    # Defias Tower Key c Malformed Defias Drone
    if c_entry == 7051:
       item = 7923, randrange(1,2)
       loot_list.append( item )
    
    # Defias Shipping Schedule from Defias Dockmaster
    if c_entry == 6846:
       item = 7675, randrange(1,2)
       loot_list.append( item )

    # clear loot
    c.ClearLootTable();
    # fill loot
    for loot in loot_list:
        c.AddItemToLoot (loot[0], loot[1])

# ####################################################################################
# used to help Core to select right map_id by given guild (BattleGrounds)
#     
def GetBattlefieldMapIdByGuild(gossip):

    guild = gossip.GetGuild()
    map_id = 0
    if   guild == "Warsong Gulch Battlemaster"   : map_id = 489
    elif guild == "Arathi Basin Battlemaster"    : map_id = 529
    elif guild == "Alterac Valley Battlemaster"  : map_id = 30
    elif guild == "Azshara Crater Battlemaster"  : map_id = 37
    elif guild == "Eye of the Storm Battlemaster": map_id = 566

    return map_id

# ####################################################################################
# used to help Core to select right list_id by given gossip (Arenas)
#     
def GetBattlefieldListIdByGossip(gossip):

    guild = gossip.GetGuild()
    list_id = 0

    if guild == "Arena Battlemaster" : list_id = 4 #mapid 559

    return list_id

# ####################################################################################
# Called on Every Pet SETLEVEL event
#     
def OnRecalculatePetStats(pet, oneTimeInit):
    
    print "OnRecalculatePetStats"
    
    # Check On Pet
    if pet.isPet() == FALSE: return FALSE

    # Generate start spells for pet on its creation
    if oneTimeInit == TRUE: 
        GeneratePetStartSpells(pet, oneTimeInit)
        return FALSE # we escape now as stats will later be calculated on SetLevel
    
    class_hp_modifer    = 10
    class_mana_modifer  = 15
    
    # Initialise Family - Type Specific Data, same as does Core on Creature Spawn in the World
    #
    # as we recalculate in core we shall not call it here but later if recalculation does not take place by core
    Init_Creature_Class(pet, FALSE)
        
    # ###########
    if pet.GetType() == _co_.CREATURE_TYPE_BEAST: 
        pet.SetPowerIndex   (_co_.POWER_INDEX_FOCUS)
        pet.SetMaxFocus     (100)
        pet.SetFocus        (100)
        #pet.ModifyMaxHealth ( class_hp_modifer*pet.GetStamina() ) #Ks: adds HP over already added HP set by SetStamina()
        pet.SetHealth       ( pet.GetMaxHealth() )
        pet.SetClass        (_co_.CLASS_WARRIOR)
        print "BEAST"
     
    if pet.GetType() == _co_.CREATURE_TYPE_DEMON:
        #    pet.ModifyMaxHealth ( class_hp_modifer*pet.GetStamina()) #Ks: adds HP over already added HP set by SetStamina()
        pet.SetHealth       ( pet.GetMaxHealth() )        
    
   
    # If we have Class assigned for Pet then just return TRUE to Core making it to calculate Stats by it self
    #
    if pet.GetClass() is not 0: return TRUE
    
    # No Class assigned, then just proceed with customised calculations
    # (you can still assign class to Pet but do not return TRUE to core and it will not try to recalculate)
    
    strength_start  = 23
    agility_start   = 25
    intellect_start = 19
    stamina_start   = 24
    spirit_start    = 20
    hp_start        = stamina_start*10
    mana_start      = intellect_start*15
    
    strength_gain   = 0 
    agility_gain    = 0 
    intellect_gain  = 0 
    stamina_gain    = 0 
    spirit_gain     = 0
    hp_gain         = 0
    mana_gain       = 0
    
    # Initialising constants
    #
    c_type   = pet.GetType()
    c_family = pet.GetFamily()
    c_lvl    = pet.GetLevel()
    c_entry  = pet.GetEntry()
    c_elite  = pet.GetElite()
    
    # just temporary as needs correct values and method of stats recalc
    #
    if c_lvl > 1:
        strength_gain   = 2 * c_lvl 
        agility_gain    = 2 * c_lvl 
        intellect_gain  = 2 * c_lvl 
        stamina_gain    = 2 * c_lvl 
        spirit_gain     = 2 * c_lvl 
        hp_gain         = stamina_gain*10
        mana_gain       = intellect_gain*15
    
    strength   = strength_start  + strength_gain
    agility    = agility_start   + agility_gain
    intellect  = intellect_start + intellect_gain
    stamina    = stamina_start   + stamina_gain
    spirit     = spirit_start    + spirit_gain
    hp         = hp_start        + hp_gain
    mana       = mana_start      + mana_gain
    
    if pet.GetStrength() == 0:  pet.SetStrength  ( strength  )
    if pet.GetAgility() == 0:   pet.SetAgility   ( agility   )
    if pet.GetIntellect() == 0: pet.SetIntellect ( intellect )
    if pet.GetStamina() == 0:   pet.SetStamina   ( stamina   )
    if pet.GetSpirit() == 0:    pet.SetSpirit    ( spirit    )
    if pet.GetMaxHealth() == 0: pet.SetMaxHealth ( hp        )
    if pet.GetMaxMana() == 0:   pet.SetMaxMana   ( mana      )   

    print "PetStats: STR[%d] AGI[%d] INT[%d] STA[%d] SPI[%d] HP[%d] MANA[%d]" % (strength,agility,intellect,stamina,spirit,hp,mana)
    
    # If no Class assigned for Pet, core will not Reset stats and try to Recalculate them
    # if customised values were calculated above, even with class assigned and you do not wish Core to try to recalculate Stats
    # always return FALSE
    #
    return FALSE
    
# ####################################################################################
# Called on Every Pet SETLEVEL event
#     
def GeneratePetStartSpells(pet, oneTimeInit):
    
    print "GeneratePetStartSpells"

    c_family = pet.GetFamily()
    spell_list = []
    
    # Warlock pet's---------------------------------------------------------------------------------------------------------------------------
    if c_family == _co_.CREATURE_FAMILY_IMP:
        spell_list.append(_spellname_.SPELL_ID_FIREBOLT_RANK_1) # FireBolt Rank 1
    
    if c_family == _co_.CREATURE_FAMILY_VOIDWALKER:
        spell_list.append(_spellname_.SPELL_ID_TORMENT_RANK_1) # Torment Rank 1
        
    if c_family == _co_.CREATURE_FAMILY_SUCCUBUS:
        spell_list.append(_spellname_.SPELL_ID_LASH_OF_PAIN_RANK_1) # Lash of Pain rank 1
        
    if c_family == _co_.CREATURE_FAMILY_FELHUNTER:
        spell_list.append(_spellname_.SPELL_ID_DEVOUR_MAGIC_RANK_1) # Devour Magic rank 1
    
    #Hunter pet's-----------------------------------------------------------------------------------------------------------------------------------------------------
    if c_family == _co_.CREATURE_FAMILY_BAT:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_DIVE_RANK_1) #Dive rank 1
        spell_list.append(_spellname_.SPELL_ID_SCREECH_RANK_1) #Screech rank 1
        
    if c_family == _co_.CREATURE_FAMILY_BEAR:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_CLAW_RANK_1_3) #Claw rank 1
    
    if c_family == _co_.CREATURE_FAMILY_BOAR:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_CHARGE_RANK_1_3) #Charge rank 1
        spell_list.append(_spellname_.SPELL_ID_DASH_RANK_1_2) #Dash rank 1
    
    if c_family == _co_.CREATURE_FAMILY_CAT:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_CLAW_RANK_1_3) #Claw rank 1
        spell_list.append(_spellname_.SPELL_ID_DASH_RANK_1_2) #Dash rank 1
        spell_list.append(_spellname_.SPELL_ID_PROWL_RANK_1_3) #Prowl rank 1
        
    if c_family == _co_.CREATURE_FAMILY_CRAB:
        spell_list.append(_spellname_.SPELL_ID_CLAW_RANK_1_3) #Claw rank 1
    
    if c_family == _co_.CREATURE_FAMILY_CROCILISK:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        
    if c_family == _co_.CREATURE_FAMILY_CARRION_BIRD:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_DIVE_RANK_1) #Dive rank 1
        spell_list.append(_spellname_.SPELL_ID_SCREECH_RANK_1) #Screech rank 1
        spell_list.append(_spellname_.SPELL_ID_CLAW_RANK_1_3) #Claw rank 1        
       
    if c_family == _co_.CREATURE_FAMILY_GORILLA:
        spell_list.append(_spellname_.SPELL_ID_THUNDERSTOMP_RANK_1) #Thunderstomp rank 1
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1       
    
    if c_family == _co_.CREATURE_FAMILY_HYENA:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_DASH_RANK_1_2) #Dash rank 1
        
    if c_family == _co_.CREATURE_FAMILY_OWL:
        spell_list.append(_spellname_.SPELL_ID_DIVE_RANK_1) #Dive rank 1
        spell_list.append(_spellname_.SPELL_ID_SCREECH_RANK_1) #Screech rank 1
        spell_list.append(_spellname_.SPELL_ID_CLAW_RANK_1_3) #Claw rank 1           
    
    if c_family == _co_.CREATURE_FAMILY_RAPTOR:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_CLAW_RANK_1_3) #Claw rank 1       
    
    if c_family == _co_.CREATURE_FAMILY_SCORPID:
        spell_list.append(_spellname_.SPELL_ID_CLAW_RANK_1_3) #Claw rank 1  
        spell_list.append(_spellname_.SPELL_ID_SCORPID_POISON_RANK_1) #Scorpid poison rank 1
        
    if c_family == _co_.CREATURE_FAMILY_SPIDER:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        
    if c_family == _co_.CREATURE_FAMILY_TALLSTRIDER:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_DASH_RANK_1_2) #Dash rank 1        
    
    if c_family == _co_.CREATURE_FAMILY_TURTLE:
        spell_list.append(_spellname_.SPELL_ID_SHELL_SHIELD_RANK_1) #Shell shield rank 1
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        
    if c_family == _co_.CREATURE_FAMILY_WIND_SERPENT:
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_DIVE_RANK_1) #Dive rank 1
        spell_list.append(_spellname_.SPELL_ID_LIGHTNING_BREATH_RANK_1) # Lightning breath rank 1        
    
    if c_family == _co_.CREATURE_FAMILY_WOLF:
        spell_list.append(_spellname_.SPELL_ID_FURIOUS_HOWL_RANK_1) #Furiors howl rank 1
        spell_list.append(_spellname_.SPELL_ID_BITE_RANK_1) #Bite rank 1
        spell_list.append(_spellname_.SPELL_ID_DASH_RANK_1_2) #Dash rank 1         
        
    # now add spells we registered
    spells_count = spell_list.__len__()
    
    # check on 0 sized list
    if spells_count == 0: 
        print "no starting spells found for pet[%s]" % (pet.GetName())
        return 
       
    # add
    for itr in spell_list:
     #if pet.GetLevel() >= GetSpellLevel(itr): # does not allow to add start spells to pet
        print "%s: base spell - AddSpell[%d]" % (pet.GetName(), itr)
        if oneTimeInit == TRUE: pet.AddSpell(itr, FALSE) # we will send spell list when new pet is put into world, not now
        else:                   pet.AddSpell(itr, TRUE)
        
    #remove base world spells
    CreatureBaseSpells(pet, FALSE)


# ####################################################################################
# Used to help Core to add skillines specific to class/properties of player on the fly before trainer spells are sent to player
#     
def GetDynamicSkillLines(trainer, player, skillline_list):
    print "GetDynamicSkillLines: Trainer[%s] Player[%s]" % (trainer.GetName(), player.GetName())

    t_guild = trainer.GetGuild()
    t_level = trainer.GetLevel()
    p_level = player.GetLevel()
    p_class = player.GetClass()

    if t_guild == "Weapon Master":
        if p_level >= 1:
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_PALADIN or \
               p_class == _co_.CLASS_ROGUE or \
               p_class == _co_.CLASS_SHAMAN or \
               p_class == _co_.CLASS_MAGE: skillline_list.append(_skillco_.SKILL_MACES)
            #staves
            if p_class == _co_.CLASS_HUNTER or \
               p_class == _co_.CLASS_PRIEST or \
               p_class == _co_.CLASS_SHAMAN or \
               p_class == _co_.CLASS_MAGE or \
               p_class == _co_.CLASS_WARLOCK or \
               p_class == _co_.CLASS_DRUID: skillline_list.append(_skillco_.SKILL_STAVES)
            #first_weapons
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_HUNTER or \
               p_class == _co_.CLASS_ROGUE or \
               p_class == _co_.CLASS_SHAMAN or \
               p_class == _co_.CLASS_DRUID: skillline_list.append(_skillco_.SKILL_FIST_WEAPONS)
            #Daggers    
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_HUNTER or \
               p_class == _co_.CLASS_ROGUE or \
               p_class == _co_.CLASS_PRIEST or \
               p_class == _co_.CLASS_SHAMAN or \
               p_class == _co_.CLASS_MAGE or \
               p_class == _co_.CLASS_WARLOCK or \
               p_class == _co_.CLASS_DRUID: skillline_list.append(_skillco_.SKILL_DAGGERS)
            #BOWS AND CROSSBOWS  
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_HUNTER or \
               p_class == _co_.CLASS_ROGUE:               
              skillline_list.append(_skillco_.SKILL_BOWS)
              skillline_list.append(_skillco_.SKILL_CROSSBOWS)
              skillline_list.append(_skillco_.SKILL_GUNS)
              skillline_list.append(_skillco_.SKILL_THROWN)
            #ONE HAND AXES
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_PALADIN or \
               p_class == _co_.CLASS_HUNTER or \
               p_class == _co_.CLASS_SHAMAN: skillline_list.append(_skillco_.SKILL_AXES)
            # ONE HAND SWORDS
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_PALADIN or \
               p_class == _co_.CLASS_ROGUE or \
               p_class == _co_.CLASS_HUNTER or \
               p_class == _co_.CLASS_MAGE or \
               p_class == _co_.CLASS_WARLOCK: skillline_list.append(_skillco_.SKILL_SWORDS)
            # TWO HAND AXES
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_PALADIN or \
               p_class == _co_.CLASS_HUNTER or \
               p_class == _co_.CLASS_SHAMAN: skillline_list.append(_skillco_.SKILL_TWO_HANDED_AXES)
            # TWO HAND SWORDS  
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_PALADIN or \
               p_class == _co_.CLASS_HUNTER: skillline_list.append(_skillco_.SKILL_TWO_HANDED_SWORDS)
        #polearms
        if p_level >= 20:
            if p_class == _co_.CLASS_WARRIOR or \
               p_class == _co_.CLASS_PALADIN or \
               p_class == _co_.CLASS_HUNTER: skillline_list.append(_skillco_.SKILL_POLEARMS)

    if  t_guild == "Warrior Trainer":
       if p_level >= 6: skillline_list.append(_skillco_.SKILL_DEFENSE)
       if p_level >= 20: skillline_list.append(_skillco_.SKILL_DUAL_WIELD)
       if p_level >= 40: skillline_list.append(_skillco_.SKILL_PLATE_MAIL)

    if t_guild == "Paladin Trainer":
       if p_level >= 8: skillline_list.append(_skillco_.SKILL_DEFENSE)
       if p_level >= 40: skillline_list.append(_skillco_.SKILL_PLATE_MAIL)

    if t_guild == "Hunter Trainer":
       if p_level >= 8: skillline_list.append(_skillco_.SKILL_DEFENSE)
       if p_level >= 20: skillline_list.append(_skillco_.SKILL_DUAL_WIELD)
       if p_level >= 40: skillline_list.append(_skillco_.SKILL_MAIL)

    if t_guild == "Rogue Trainer":
       if p_level >= 10: skillline_list.append(_skillco_.SKILL_DUAL_WIELD)
       if p_level >= 12: skillline_list.append(_skillco_.SKILL_DEFENSE)
       if p_level >= 16: skillline_list.append(_skillco_.SKILL_LOCKPICKING)

    if t_guild == "Shaman Trainer":
       if p_level >= 40: skillline_list.append(_skillco_.SKILL_MAIL)
       if p_level >= 40: skillline_list.append(_skillco_.SKILL_DUAL_WIELD)

    pet = player.GetPet()
    if pet is not None:
        if t_guild == "Pet Trainer":
            if pet.GetFamily() == _co_.CREATURE_FAMILY_BAT: skillline_list.append(_skillco_.SKILL_PET_BAT)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_BEAR: skillline_list.append(_skillco_.SKILL_PET_BEAR)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_BOAR: skillline_list.append(_skillco_.SKILL_PET_BOAR)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_CAT: skillline_list.append(_skillco_.SKILL_PET_CAT)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_CRAB: skillline_list.append(_skillco_.SKILL_PET_CRAB)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_CROCILISK: skillline_list.append(_skillco_.SKILL_PET_CROCILISK)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_CARRION_BIRD: skillline_list.append(_skillco_.SKILL_PET_CARRION_BIRD)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_GORILLA: skillline_list.append(_skillco_.SKILL_PET_GORILLA)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_HYENA: skillline_list.append(_skillco_.SKILL_PET_HYENA)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_OWL: skillline_list.append(_skillco_.SKILL_PET_OWL)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_RAPTOR: skillline_list.append(_skillco_.SKILL_PET_RAPTOR)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_SCORPID: skillline_list.append(_skillco_.SKILL_PET_SCORPID)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_SPIDER: skillline_list.append(_skillco_.SKILL_PET_SPIDER)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_TALLSTRIDER: skillline_list.append(_skillco_.SKILL_PET_TALLSTRIDER)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_TURTLE: skillline_list.append(_skillco_.SKILL_PET_TURTLE)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_WIND_SERPENT: skillline_list.append(_skillco_.SKILL_PET_WIND_SERPENT)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_WOLF: skillline_list.append(_skillco_.SKILL_PET_WOLF)
            elif pet.GetFamily() == _co_.CREATURE_FAMILY_SERPENT: skillline_list.append(_skillco_.SKILL_PET_SERPENT)

    skillline_count = skillline_list.__len__()
    if skillline_count == 0: return
    for skill_id in skillline_list:
        trainer.AddTrainerSkillLine(skill_id)

    trainer.SetTrainerSpellMaxLvL( t_level )

# ####################################################################################
# Used to help Core to select right loot for base loot generation 
#     
def GenerateLoot_Base(self, killer):
    print "Generate_LootFix victim[%s] killer[%s]" % ( self.GetName(), killer.GetName())
    if _cfg_.NPC_LOOTFIX:
        # Loot externaly fetched from sql; quested items filtered out by custom table
        self.ClearLootTable()  # will clear current loot, except quested items
        if killer.IsPlayer() or killer.isPet():
            cursor = conn.cursor ()
            cursor.execute ("SELECT `item_id`, `chance` FROM `creatures_loot` Left Join `quested_items` ON `creatures_loot`.`item_id` = `quested_items`.`Quested_Item` WHERE `creatures_loot`.`creature_id` =  " + str(self.GetEntry()) + " AND `quested_items`.`Quested_Item` IS NULL ")
            rows = cursor.fetchall ()
            for row in rows:
                if row[1]>= randrange(9999) / 100 :
                    self.AddItemToLoot( row[0] , 1 )
            cursor.execute ("SELECT `item_id`, `chance` FROM `world_loot` WHERE `world_loot`.`monster_level` =  " + str(self.GetLevel()) + " AND `world_loot`.`elite` <=  " + str(self.GetElite()))
            rows = cursor.fetchall ()
            for row in rows:
                if row[1]>= randrange(9999) / 100 :
                    self.AddItemToLoot( row[0] , 1 )
            cursor.close ()
        
# -- EOF --
