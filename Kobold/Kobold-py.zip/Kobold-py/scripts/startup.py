# This module is sturtup script.
# Here we are redirecting output and checking for server version.
################################################################################

import sys
from Ludmilla import *
from consts import *                            # Import of constants
import config as cfg                            # Import of configuration constants
reload(cfg)  
import const_weather as weatherzones            # Import of weather constants
reload(weatherzones)  

import MySQLdb
conn = MySQLdb.connect (host = cfg.MYSQL_HOST, user = cfg.MYSQL_USER, passwd = cfg.MYSQL_PASSWD, db = cfg.MYSQL_DB)
################################################################################

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
class OurLogStdErr:
    def write (self, txt):
        printLog (txt, PRINT_ERROR)
        
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
class OurLogStdOut:
    def write (self, txt):
        printLog (txt)

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
def CheckServerVersion():
    # Checking for server build
    if GetServerBuild() < MIN_SERVER_BUILD:
        printLog( "YOU ARE TRYING TO RUN PYTHON SCRIPTS ON OUTDATED SERVER BUILD!\
\nREQUIRED SERVER BUILD: %s\
\nPlease Update your server core before running server!\
\nScripting Engine will be Shut Down!"\
        % (MIN_SERVER_BUILD), PRINT_ERROR )

        killScripting()
       
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
def GetScriptsVersion():
  return SCRIPTS_VERSION

################################################################################
# Startup code here:

# Redirecting errors:
sys.stderr = OurLogStdErr()

# Redirecting output:
sys.stdout = OurLogStdOut()

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
# Checking server version:
CheckServerVersion()

print "Scripts starting..."

# ------------------------------------------------------------------------------
# update player online status, core takes too long
cursor = conn.cursor ()
cursor.execute ("UPDATE char_state SET online_state=0 WHERE online_state=1")
row = cursor.fetchone ()
cursor.close ()
conn.commit ()
conn.close ()
if row:
    print "Reset online players for: %d" % cursor.rowcount

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
# Executed on every Server Start
def OnServerStart(time):
    print "OnServerStart: starting Py supporting services..."
    
   # Start Arenas
    if cfg.ENABLE_BATTLEGROUNDS: StartArenas()
    else: print "Battlegrounds: Disabled."
    
    # Start Arenas
    if cfg.ENABLE_ARENAS: StartArenas()
    else: print "Arenas: Disabled."

    # Chat audit
    if cfg.SERVER_AUDIT_CHAT_MESSAGES: RegisterChatProhibitedPhrases()
    else: print "Chat Audit: Disabled."
    
    # Registration of Zones for Weather changes
    if cfg.ENABLE_AUTO_WEATHER: RegisterWeatherZones()
    else: print "Weather registration: Disabled."

# ----------------------------------------------------------------------------------------------------------------------------------------------------------------
# Executed on every Server Start
def StartBattlegrounds():

    print "BattleGround: initialising ..."
  
    if cfg.ENABLE_ALTERACK_VALLEY:
        print "BattleGround: starting [Alterac Valley]" #PVP Zone 1
        StartNewInstance(30, 0, MAP_TYPE__BATTLEGROUND, 0) # Alterac Valley
    else: print "BattleGround: starting [Alterac Valley]. Disabled."
    
    if cfg.ENABLE_WARSONG_GULCH:
        print "BattleGround: starting [Warsong Gulch]"  #PVP Zone 4
        StartNewInstance(489, 0, MAP_TYPE__BATTLEGROUND, 0) # Warsong Gulch
    else: print "BattleGround: starting [Warsong Gulch]. Disabled."
        
    if cfg.ENABLE_ARATHI_BASIN:
        print "BattleGround: starting [Arathi Basin]"   #PVP Zone 3
        StartNewInstance(529, 0, MAP_TYPE__BATTLEGROUND, 0) # Arathi Basin
    else: print "BattleGround: starting [Arathi Basin]. Disabled."
        
    if cfg.ENABLE_AZSHARA_CRATER:
        print "BattleGround: starting [Azshara Crater]" #Under Development (#PVP Zone 2)
        StartNewInstance(37, 0, MAP_TYPE__BATTLEGROUND, 0) # Azshara Crater
    else: print "BattleGround: starting [Azshara Crater]. Disabled."
        
    print "BattleGround: done."

## ----------------------------------------------------------------------------------------------------------------------------------------------------------------
## Executed on every Server Start
def StartArenas():

    print "Arenas: initialising ..."
    
    if cfg.ENABLE_NAGRAND_ARENA:
        print "Arena: starting [Nagrand Arena]"
        StartNewInstance(559, 0, MAP_TYPE__ARENA, 2)
        StartNewInstance(559, 0, MAP_TYPE__ARENA, 3)
        StartNewInstance(559, 0, MAP_TYPE__ARENA, 5)
    else: print "Arena: starting [Nagrand Arena]. Disabled."
    
    if cfg.ENABLE_BLADES_EDGE_ARENA:
        print "Arena: starting [Blades Edge Arena]"
        StartNewInstance(562, 0, MAP_TYPE__ARENA, 2)
        StartNewInstance(562, 0, MAP_TYPE__ARENA, 3)
        StartNewInstance(562, 0, MAP_TYPE__ARENA, 5)
    else: print "Arena: starting [Blades Edge Arena]. Disabled."        
   
    print "Arenas: done."
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------

    # Chat control
def RegisterChatProhibitedPhrases():
    
    if not cfg.SERVER_AUDIT_CHAT_MESSAGES: return
    
    print "Registering Prohibited Phrases:"
    p = []

    # system
    p.append("script")

    # bad slang
    p.append("script")

    #append to core
    count = 0
    if p is not None:
        for itr in p:
            print "   +[%d]prohibited pharse: [%s]" % (count + 1, itr)
            AddProhibitedChatPhrase(str(itr))
            count += 1
    
    print "Registering Prohibited Phrases: done with %d phrases registered." % (count)
    
# ----------------------------------------------------------------------------------------------------------------------------------------------------------------

# Registration of Zones for Weather changes
# WeatherZones are defined in const_weather.py
def RegisterWeatherZones():
    print "WeatherZones: registering ..."

    #append to core
    for zoneid in weatherzones.zones:
        w_type = weatherzones.zones.get(zoneid)
        RegisterWeatherZone(zoneid)
        print "   -> registering %s for zone %d" % (weatherzones.wtypes.get(w_type), zoneid)

    print "WeatherZones: done with %d zones registered." % (weatherzones.zones.__len__())  

#--- END ---
 
